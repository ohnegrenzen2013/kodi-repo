"""H0rSt Kiosk-Dienst.

x86_64 LibreELEC mit browser.chrome oder browser.chromium:
  Kodi beenden → Chromium im Kiosk-Modus auf http://127.0.0.1:7000 öffnen.

Alle anderen Geräte (ARM, RPi, CoreELEC):
  Netzwerkadresse als Kodi-Dialog anzeigen, damit der Nutzer H0rSt vom Handy
  oder einem anderen Gerät aufrufen kann.
"""

import os
import socket
import subprocess
import time

import xbmc
import xbmcaddon
import xbmcgui

ADDON = xbmcaddon.Addon()
H0RST_URL = "http://127.0.0.1:7000"
WAIT_BEFORE_LAUNCH = 5  # Sekunden nach dem Kodi-Start


def _find_browser_bin() -> str | None:
    """Gibt den Pfad zum Chrome/Chromium-Binary zurück, falls vorhanden."""
    candidates = [
        # browser.chrome (Google Chrome für LibreELEC x86_64)
        "/storage/.kodi/addons/browser.chrome/chrome-bin/google-chrome",
        # browser.chromium
        "/storage/.kodi/addons/browser.chromium/bin/chromium",
        # Systeminstallation (unwahrscheinlich unter LE, aber möglich nach Flatpak)
        "/usr/bin/chromium",
        "/usr/bin/chromium-browser",
        "/usr/bin/google-chrome",
    ]
    for path in candidates:
        if os.path.isfile(path) and os.access(path, os.X_OK):
            return path
    return None


def _local_ip() -> str:
    try:
        with socket.create_connection(("8.8.8.8", 80), timeout=2) as s:
            return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"


def _wait_for_h0rst(timeout: int = 30) -> bool:
    """Wartet, bis der H0rSt-Server antwortet."""
    import urllib.request

    deadline = time.time() + timeout
    while time.time() < deadline:
        try:
            urllib.request.urlopen(H0RST_URL + "/manifest.json", timeout=2)
            return True
        except Exception:
            time.sleep(1)
    return False


def launch_kiosk(browser: str) -> None:
    """Beendet Kodi und öffnet Chromium im Kiosk-Modus."""
    xbmc.log(f"H0rSt Kiosk: starte {browser}", xbmc.LOGINFO)
    xbmc.executebuiltin("Quit")
    time.sleep(2)
    subprocess.Popen(
        [
            browser,
            "--kiosk",
            "--app=" + H0RST_URL,
            "--noerrdialogs",
            "--disable-infobars",
            "--no-first-run",
            "--disable-translate",
        ],
        stdout=subprocess.DEVNULL,
        stderr=subprocess.DEVNULL,
    )


def show_address_dialog(ip: str) -> None:
    """Zeigt die H0rSt-Adresse als Kodi-Dialog an (für ARM-Geräte)."""
    url = f"http://{ip}:7000"
    xbmc.log(f"H0rSt Kiosk: kein Browser verfügbar, zeige Adresse {url}", xbmc.LOGINFO)
    xbmcgui.Dialog().ok(
        "H0rSt",
        f"H0rSt läuft auf diesem Gerät.\n\nAdresse für Jacktook:\n{url}/manifest.json\n\nAuf einem anderen Gerät im Browser öffnen:\n{url}",
    )


def main() -> None:
    monitor = xbmc.Monitor()

    # Kurz warten, damit service.rezeptserver starten kann
    for _ in range(WAIT_BEFORE_LAUNCH):
        if monitor.waitForAbort(1):
            return

    if not _wait_for_h0rst():
        xbmc.log("H0rSt Kiosk: Server nicht erreichbar nach 30s", xbmc.LOGWARNING)
        return

    browser = _find_browser_bin()
    if browser:
        launch_kiosk(browser)
    else:
        ip = _local_ip()
        show_address_dialog(ip)


if __name__ == "__main__":
    main()
