"""KeepADB 1.11.0 (m00sfett, AGPL-3.0-or-later): Wireless Debugging wach halten.

KeepADB schaltet Androids „Wireless debugging“ (Settings.Global.adb_wifi_enabled)
aus der App, einem Widget oder einer Schnelleinstellung und holt es nach Netzwechsel
oder Neustart zurueck – gebunden an eine Netzregel (nur vertraute Zugangspunkte oder
alle WLAN-Netze), einen Kraft-Modus mit Ablauf und einen Webhook, der den geprueften
ADB-Endpunkt meldet. Die drei Privatsphäre-Schalter verstecken Netzname, Adresse und
BSSID in der App, in Meldungen und im Widget.

H0rSt baut die Idee in eigenem Code nach: es merkt sich Regel, vertraute Netze und
Endpunkt, bewertet ein Netz, maskiert Adressen und baut die Befehle zum Schalten.
Geschaltet wird auf dem Geraet (rish/Shizuku oder adb am Computer); H0rSt setzt die
Systemeinstellung nicht selbst. Kein fremder Code, keine APK.
"""

import hashlib
import json
import re
import shlex
import time
from datetime import datetime, timezone

from .netz import NetzFehler, antwort_holen

NAME = "KeepADB"
STAND = "1.11.0"
PAKET = "de.hohnepeople.keepadb"
LIZENZ = "AGPL-3.0-or-later"
URL = "https://github.com/m00sfett/KeepADB"
FDROID = "https://f-droid.org/packages/de.hohnepeople.keepadb/"
RELEASES = "https://github.com/m00sfett/KeepADB/releases"
RECHT = "android.permission.WRITE_SECURE_SETTINGS"
VERTRAG = 2
QUELLE = "h0rst"
NETZ_REGELN = [["vertraut", "Nur vertraute Zugangspunkte"], ["alle", "Alle WLAN-Netze"]]
DAUERN = [["1h", "1 Stunde"], ["24h", "24 Stunden"], ["7d", "7 Tage"], ["30d", "30 Tage"],
          ["unbegrenzt", "Unbegrenzt"]]
SEKUNDEN = {"1h": 3600, "24h": 86400, "7d": 604800, "30d": 2592000}
WIEDERHOLUNG = [5, 15, 30, 60]
FARBEN = {"rot": ("#d01822", "#080604"), "banner": ("#b11218", "#080604"), "gelb": ("#ffd21f", "#080604")}
WERKZEUGE = [
    ("Schalten", "Setzt global adb_wifi_enabled; Android bestaetigt das Einschalten im WLAN selbst."),
    ("Wachdienst", "Holt Wireless Debugging nach Netzwechsel oder Neustart zurueck – nur nach Netzregel."),
    ("Netzregel", "Vertraut heißt: nur eingetragene Zugangspunkte (BSSID, optional nach Name)."),
    ("Kraft-Modus", "Zeitweise in jedem Netz erlaubt, mit Ablauf nach 1 h bis 30 Tagen oder offen."),
    ("Webhook", "Meldet den geprueften Endpunkt als JSON; https wird empfohlen, http nur im eigenen Netz."),
    ("Masken", "Adresse, Netzname und BSSID bleiben auf Wunsch in App, Meldung und Widget verborgen."),
]
BEFEHLE = [
    {"id": "an", "name": "Wireless Debugging einschalten", "vorlage": "settings put global adb_wifi_enabled 1",
     "gate": "ka_schalten", "felder": []},
    {"id": "aus", "name": "Wireless Debugging ausschalten", "vorlage": "settings put global adb_wifi_enabled 0",
     "gate": "ka_schalten", "felder": []},
    {"id": "stand", "name": "Zustand lesen", "vorlage": "settings get global adb_wifi_enabled",
     "gate": "ka_schalten", "felder": []},
    {"id": "recht", "name": "WRITE_SECURE_SETTINGS erteilen",
     "vorlage": "pm grant %s android.permission.WRITE_SECURE_SETTINGS" % PAKET,
     "gate": "ka_schalten", "felder": []},
    {"id": "verbinden", "name": "Vom Computer verbinden", "vorlage": "adb connect {endpunkt}",
     "gate": "ka_schalten", "felder": ["endpunkt"]},
    {"id": "paaren", "name": "Vom Computer paaren", "vorlage": "adb pair {endpunkt} {code}",
     "gate": "ka_paaren", "felder": ["endpunkt", "code"]},
]
_PAAR = re.compile(r"^[A-Za-z0-9_]+(?:\.[A-Za-z0-9_]+)*$")
_ENDPUNKT = re.compile(r"^[A-Za-z0-9._:-]+:\d{1,5}$")
_CODE = re.compile(r"^\d{6}$")
_WLAN = re.compile(r"^[A-Za-z0-9._:/-]{2,120}$")
_MAX_LISTE = 40


class KeepAdbFehler(ValueError):
    pass


def _sauber(wert, laenge=200):
    text = " ".join(str(wert or "").split())
    if not text or len(text) > laenge:
        raise ValueError("Wert fehlt oder ist zu lang.")
    return text


def _pruefe(feld, wert):
    text = _sauber(wert, 120)
    if feld == "paket" and not _PAAR.fullmatch(text):
        raise ValueError("Paketname ungueltig (Beispiel: com.example.app).")
    if feld == "endpunkt" and not _ENDPUNKT.fullmatch(text):
        raise ValueError("Endpunkt ungueltig (Beispiel: 192.168.1.20:41234).")
    if feld == "code" and not _CODE.fullmatch(text):
        raise ValueError("Kopplungscode ungueltig (sechs Ziffern).")
    return text


def liste_lesen(text):
    """Eine Einstellungsliste (Zeilen oder Komma) in vergleichbare Eintraege."""
    roh = str(text or "").replace(",", "\n").replace(";", "\n").splitlines()
    aus = []
    for zeile in roh:
        eintrag = zeile.strip().lower()
        if eintrag and eintrag not in aus:
            aus.append(eintrag)
        if len(aus) >= _MAX_LISTE:
            break
    return aus


def maske_ipv4(text, an):
    teile = str(text or "").split(".")
    return teile[0] + ".*.*.*" if an and len(teile) == 4 and all(teile) else str(text or "")


def maske_ipv6(text, an):
    gruppen = str(text or "").split(":")
    return gruppen[0] + ":***" if an and len(gruppen) > 2 and gruppen[0] else str(text or "")


def maske_bssid(text, an):
    teile = str(text or "").split(":")
    return "%s:*:*:*:*:%s" % (teile[0], teile[-1]) if an and len(teile) == 6 and all(teile) else str(text or "")


def maske_ssid(text, an):
    return "***" if an and str(text or "").strip() else str(text or "")


def maske_host(text, an):
    """Hostnamen (DNS, Tailnet, Webhook-Adresse) ganz verstecken."""
    return "***" if an and str(text or "").strip() else str(text or "")


def endpunkt_zeigen(endpunkt, werte, art="app"):
    """Endpunkt so zeigen, wie es der Schalter fuer diesen Ort erlaubt.

    art ist app (Einstellungen), meldung (Benachrichtigung) oder widget. Wie beim
    Vorbild maskiert H0rSt innerhalb der App nur teilweise (die erste Zahl und der
    Port bleiben sichtbar), in Meldungen und im Widget gar nicht.
    """
    w = werte if isinstance(werte, dict) else {}
    an = bool(str(endpunkt or "").strip()) and w.get("ka_privat_" + art) is True
    text = str(endpunkt or "").strip()
    if not text:
        return ""
    gast, trenner, port = text.rpartition(":")
    if not trenner:
        return maske_host(text, an) if an else text
    if ":" in gast:
        return "%s:***" % gast.split(":")[0] if an else text
    if art != "app" and an:
        return "verborgen"
    maskiert = maske_ipv4(gast, an)
    if an and maskiert == gast:
        maskiert = maske_host(gast, True)
    return "%s:%s" % (maskiert, port)


def kraft(werte, jetzt=None):
    """Kraft-Modus: an, Ablaufzeitpunkt und verbleibende Sekunden."""
    w = werte if isinstance(werte, dict) else {}
    dauer = str(w.get("ka_kraft_dauer") or "1h")
    gestartet = w.get("ka_kraft_start")
    try:
        start = float(gestartet)
    except (TypeError, ValueError):
        return {"an": w.get("ka_kraft_an") is True and dauer == "unbegrenzt", "dauer": dauer, "bis": None,
                "rest": None if dauer != "unbegrenzt" else 0}
    sekunden = SEKUNDEN.get(dauer)
    if sekunden is None:
        return {"an": True, "dauer": dauer, "bis": None, "rest": 0}
    bis = start + sekunden
    nun = float(jetzt) if jetzt is not None else time.time()
    return {"an": w.get("ka_kraft_an") is True and bis > nun, "dauer": dauer, "bis": bis,
            "rest": int(max(bis - nun, 0))}


def entscheidung(netz, werte, jetzt=None):
    """Bewertet ein Netz: darf der Wachdienst hier Wireless Debugging zurueckholen?"""
    w = werte if isinstance(werte, dict) else {}
    if w.get("ka_an") is not True:
        return {"erlaubt": False, "grund": "aus", "text": "KeepADB ist ausgeschaltet."}
    if w.get("ka_wach_an") is not True:
        return {"erlaubt": False, "grund": "wachdienst", "text": "Der Wachdienst ist ausgeschaltet."}
    n = netz if isinstance(netz, dict) else {}
    ssid = str(n.get("ssid") or "").strip().lower()
    bssid = str(n.get("bssid") or "").strip().lower()
    blockiert = liste_lesen(w.get("ka_blockliste"))
    if (ssid and ssid in blockiert) or (bssid and bssid in blockiert):
        if not kraft(w, jetzt)["an"]:
            return {"erlaubt": False, "grund": "blockiert",
                    "text": "Dieses Netz steht auf der Sperrliste; nur der Kraft-Modus greift hier."}
        return {"erlaubt": True, "grund": "kraft",
                "text": "Kraft-Modus: auch in gesperrten Netzen erlaubt."}
    if str(w.get("ka_netz_regel") or "vertraut") == "alle":
        return {"erlaubt": True, "grund": "alle",
                "text": "Netzregel „Alle WLAN-Netze“: erlaubt."}
    namen = liste_lesen(w.get("ka_namen"))
    if bssid and bssid in liste_lesen(w.get("ka_vertraut")):
        return {"erlaubt": True, "grund": "vertraut", "text": "Vertrauter Zugangspunkt (BSSID)."}
    if w.get("ka_namen_trauen") is True and ssid and ssid in namen:
        return {"erlaubt": True, "grund": "name", "text": "Vertrauter Netzname."}
    if not bssid:
        return {"erlaubt": False, "grund": "unbekannt",
                "text": "Die Kennung des Zugangspunkts ist nicht lesbar; der Wachdienst wartet."}
    return {"erlaubt": False, "grund": "fremd",
            "text": "Nicht vertrautes Netz; der Kraft-Modus wuerde hier erlauben."}


def meldung(endpunkt, werte, jetzt=None):
    """Webhook-Nachricht nach dem Vorbild (contract_version 2, Methode wlan-adb)."""
    text = _sauber(endpunkt, 120) if str(endpunkt or "").strip() else ""
    aktiv = bool(text)
    zeit = float(jetzt) if jetzt is not None else time.time()
    stamp = datetime.fromtimestamp(zeit, timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    digest = hashlib.sha256(("wlan-adb|%s|%s" % (text, aktiv)).encode("utf-8")).hexdigest()[:16]
    return {"contract_version": VERTRAG, "method": "wlan-adb", "active": aktiv, "endpoint": text,
            "source": QUELLE, "observed_at": stamp, "event_id": "%s-v2-wlan-adb-%s" % (QUELLE, digest)}


def webhook_url(werte):
    w = werte if isinstance(werte, dict) else {}
    url = str(w.get("ka_webhook_url") or "").strip()
    if not url.startswith(("http://", "https://")):
        raise KeepAdbFehler("Die Webhook-Adresse muss mit http:// oder https:// beginnen.")
    return url[:500]


def melden(endpunkt, werte, holen=None):
    """Schickt die Nachricht an die eingetragene Adresse. Nur bei eingeschaltetem Schalter."""
    w = werte if isinstance(werte, dict) else {}
    if w.get("ka_an") is not True:
        raise KeepAdbFehler("KeepADB ist ausgeschaltet")
    if w.get("ka_webhook_an") is not True:
        raise KeepAdbFehler("Der Webhook ist ausgeschaltet")
    nachricht = meldung(endpunkt, w)
    koerper = json.dumps(nachricht, ensure_ascii=False, sort_keys=True).encode("utf-8")
    sender = holen or antwort_holen
    try:
        status, antwort = sender(webhook_url(w), "POST",
                                 {"Content-Type": "application/json; charset=utf-8",
                                  "User-Agent": "H0rSt-KeepADB"}, koerper, zeitgrenze=15)
    except NetzFehler as fehler:
        raise KeepAdbFehler(str(fehler))
    if status is None or not 200 <= int(status) <= 299:
        raise KeepAdbFehler("Webhook: HTTP %s %s" % (status, str(antwort or "")[:200]))
    return {"gesendet": True, "status": int(status), "nachricht": nachricht,
            "wiederholung": list(WIEDERHOLUNG),
            "hinweis": "Gesendet wurde nur der Endpunkt; die Privatsphaere-Schalter gelten fuer die Anzeige."}


def befehl_bauen(werte=None, op=None, felder=None):
    """Baut einen KeepADB-Befehl; ohne Freigabe bleibt er gesperrt."""
    w = werte if isinstance(werte, dict) else {}
    f = felder if isinstance(felder, dict) else {}
    eintrag = next((b for b in BEFEHLE if b["id"] == op), None)
    if eintrag is None:
        return {"erlaubt": False, "befehl": "", "text": "", "hinweis": "Unbekannter Befehl."}
    if w.get("ka_an") is not True:
        return {"erlaubt": False, "befehl": "", "text": "", "hinweis": "KeepADB ist in den Einstellungen ausgeschaltet."}
    if w.get(eintrag["gate"]) is not True:
        return {"erlaubt": False, "befehl": "", "text": "",
                "hinweis": "Nicht freigegeben (%s einschalten)." % eintrag["gate"]}
    ersetzt = {}
    for name in eintrag["felder"]:
        try:
            ersetzt[name] = shlex.quote(_pruefe(name, f.get(name)))
        except ValueError as fehler:
            return {"erlaubt": False, "befehl": "", "text": "", "hinweis": str(fehler)}
    text = eintrag["vorlage"].format(**ersetzt) if ersetzt else eintrag["vorlage"]
    return {"erlaubt": True, "befehl": text, "text": text,
            "hinweis": "Auf dem Geraet ueber rish/Shizuku oder am Computer mit adb ausfuehren; "
                       "H0rSt setzt die Systemeinstellung nicht selbst."}


def zustand(werte=None):
    w = werte if isinstance(werte, dict) else {}
    return {"name": NAME, "stand": STAND, "paket": str(w.get("ka_paket") or PAKET), "lizenz": LIZENZ,
            "url": URL, "fdroid": FDROID, "releases": RELEASES, "recht": RECHT,
            "an": w.get("ka_an") is True, "wach": w.get("ka_wach_an") is True,
            "regel": str(w.get("ka_netz_regel") or "vertraut"),
            "regeln": [{"id": a, "name": b} for a, b in NETZ_REGELN],
            "dauern": [{"id": a, "name": b} for a, b in DAUERN], "kraft": kraft(w),
            "vertraut": len(liste_lesen(w.get("ka_vertraut"))),
            "namen": len(liste_lesen(w.get("ka_namen"))),
            "gesperrt": len(liste_lesen(w.get("ka_blockliste"))),
            "webhook_an": w.get("ka_webhook_an") is True,
            "webhook": maske_host(str(w.get("ka_webhook_url") or ""), w.get("ka_privat_app") is True),
            "wiederholung": list(WIEDERHOLUNG),
            "werte": {k: w.get(k) for k in ("ka_wach_an", "ka_netz_regel", "ka_namen_trauen", "ka_kraft_an",
                                            "ka_kraft_dauer", "ka_unbekannt_aus", "ka_webhook_an",
                                            "ka_privat_app", "ka_privat_meldung", "ka_privat_widget")},
            "befehle": [{"id": b["id"], "name": b["name"], "felder": list(b["felder"]),
                         "an": w.get(b["gate"]) is True} for b in BEFEHLE],
            "farben": {k: list(v) for k, v in FARBEN.items()},
            "werkzeuge": [{"name": n, "text": t} for n, t in WERKZEUGE]}
