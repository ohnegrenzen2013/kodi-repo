"""nuvio-usenet: H0rSts eigener Usenet-Teil (Go-Hilfsprogramm) finden und ansprechen.

Der Server bleibt Python. NNTP mit vielen gleichzeitigen Verbindungen und yEnc waere hier
zu langsam, darum liegt dieser Teil in Go (`cmd/nuvio-usenet`, Quelle im Repo). H0rSt nutzt
beide Wege, die das Programm anbietet:

  * Einzelaufruf  `nuvio-usenet pruefen --nzb … --zugaenge …` liefert JSON auf der
    Standardausgabe. Braucht keinen Port und keinen Dauerprozess - gut fuer die
    Trefferauswahl.
  * Dauerprozess  `nuvio-usenet dienst` spricht HTTP auf 127.0.0.1. Nur so gehen
    Range-Anfragen, also Streamen waehrend des Ladens.

Das Programm wird **gesucht, nicht mitgeliefert**: alle drei Wege sind erlaubt, in dieser
Reihenfolge (jeder spaetere greift nur, wenn der frueher fehlt):

  1. `prebuilts/nuvio-usenet/<plattform>/nuvio-usenet` im Repo - sofort da, auch ohne CI.
  2. `nuvio-usenet` im Datenordner oder im Suchpfad - dort landet, was ein CI-Release bringt.
  3. Selbst bauen mit dem lokalen Go (`go build ./cmd/nuvio-usenet`) - dafuer braucht es Go
     **und einen C-Compiler**: nntppool entschluesselt yEnc mit rapidyenc, und das ist eine
     C-Bibliothek (cgo). Darum laesst sich das Programm auch nicht einfach fuer andere
     Plattformen uebersetzen - jede braucht ihren eigenen Compiler, die CI baut sie je auf
     einem passenden Laeufer. Auf einem Fernseher oder NAS ist beides meist nicht da.

Gefunden heisst nicht ausgefuehrt: dieses Modul startet nichts von allein. Es sagt, **ob**
und **wo** das Programm liegt; die Oberflaeche entscheidet.
"""

import json
import os
import platform
import shutil
import subprocess

SCHLUESSEL = "nuvio_usenet"
NAME = "nuvio-usenet"
SYMBOL = "📰"
# Wo im Repo die mitgelieferten Dateien liegen.
PREBUILTS = os.path.join("prebuilts", "nuvio-usenet")
# Plattformen, fuer die ein Release Dateien bringt (so heissen die Ordner). Dieselbe Liste
# baut `nuvio-usenet.yml`; ein Test haelt beide zusammen.
PLATTFORMEN = ("linux-amd64", "linux-arm64", "windows-amd64", "darwin-arm64")

# Plattformen, fuer die es kein Programm geben **kann**, mit dem Grund.
#
# rapidyenc (nntppools yEnc-Teil) liefert genau vier fertige C-Bibliotheken mit:
# linux amd64, linux arm64, windows amd64 und eine universelle fuer macOS. Fuer alles andere
# scheitert der Bau beim **Binden** ("undefined reference to rapidyenc_decode_kernel") -
# nicht erst beim Laufen und nicht mit einer Meldung, aus der jemand schlau wird. Gemessen:
# mit `gcc-arm-linux-gnueabihf` und GOARCH=arm bricht genau das ab.
#
# Darum wird hier **vorher** gesagt, dass es nicht geht, statt einen Bau-Befehl anzubieten,
# der nach drei Minuten mit Linkerfehlern endet. Ein alter Raspberry Pi oder ein 32-Bit-
# Fernseher bleibt bei den fremden Diensten (NzbDAV, AltMount, rustnzb).
UNMOEGLICH = {
    "linux-arm": "rapidyenc, der yEnc-Teil, liefert keine C-Bibliothek fuer 32-Bit-ARM "
                 "(armv7). Der Bau scheitert beim Binden, nicht erst beim Laufen.",
    "linux-386": "rapidyenc liefert keine C-Bibliothek fuer 32-Bit-x86.",
    "windows-arm64": "rapidyenc liefert fuer Windows nur eine Bibliothek fuer amd64.",
}

# Plattformen, auf denen sich das Programm **bauen** laesst. Mehr als PLATTFORMEN: die
# macOS-Bibliothek von rapidyenc ist universal (x86_64 und arm64 in einer Datei), also geht
# auch ein Intel-Mac - nur baut die CI dort noch keine Datei. "Kein Release" und "geht nicht"
# sind zwei verschiedene Dinge, und sie durcheinanderzubringen hiesse, jemandem zu sagen, es
# gehe nicht, obwohl es geht.
BAUBAR = PLATTFORMEN + ("darwin-amd64",)
ZEITGRENZE = 20


class NuvioUsenetFehler(ValueError):
    """Etwas an nuvio-usenet oder seinem Aufruf stimmt nicht."""


def wurzel():
    """Das Repo-Verzeichnis, in dem prebuilts/ und cmd/ liegen."""
    return os.path.dirname(os.path.dirname(os.path.abspath(__file__)))


# Den Datenordner gibt es hier absichtlich **nicht** mehr abzuleiten: er steht schon als
# `App.datenordner` und wird in `dienst.baue()` einmal aufgeloest. Eine zweite Ableitung aus
# `verwaltung` las `verwaltung.pfad` - ein Feld, das es nicht gibt (`Verwaltung` hat
# `konfig_pfad`), also kam im Betrieb immer None heraus, und Zugangsdatei, Protokoll und
# Teildateien landeten in der Repo-Wurzel statt im Datenordner. Aufgefallen ist es nur nicht,
# weil der Test sich ein Objekt mit `.pfad` baute: eine Schnittstelle, die es nur im Test gab.


def zwischenordner(datenordner_pfad):
    """Ordner fuer die Teildateien des Dauerprozesses.

    Bewusst **nicht** der Systemordner fuer Zwischendateien: der ist auf manchen Geraeten
    eine RAM-Platte (tmpfs), und ein Spielfilm darin waere genau das, was der
    Zwischenspeicher auf der Platte vermeiden soll.
    """
    return os.path.join(datenordner_pfad, "nuvio-usenet-teile") if datenordner_pfad else ""


def plattform(system=None, maschine=None):
    """Die Plattform in der Schreibweise der Ordner, z. B. "linux-arm64"."""
    s = (system or platform.system()).lower()
    m = (maschine or platform.machine()).lower()
    if s.startswith("win"):
        s = "windows"
    elif s == "darwin":
        s = "darwin"
    else:
        s = "linux"
    if m in ("x86_64", "amd64"):
        m = "amd64"
    elif m in ("aarch64", "arm64", "armv8l"):
        m = "arm64"
    elif m.startswith("arm"):
        m = "arm"
    return "%s-%s" % (s, m)


def dateiname(system=None):
    s = (system or platform.system()).lower()
    return NAME + ".exe" if s.startswith("win") else NAME


def mitgeliefert(wurzel, plattform_name=None, system=None):
    """Pfad der mitgelieferten Datei fuer diese Plattform, sonst None."""
    pfad = os.path.join(wurzel, PREBUILTS, plattform_name or plattform(),
                        dateiname(system))
    return pfad if os.path.isfile(pfad) else None


def im_suchpfad(datenordner=None, system=None):
    """Im Datenordner oder im PATH gefunden, sonst None."""
    name = dateiname(system)
    if datenordner:
        pfad = os.path.join(datenordner, name)
        if os.path.isfile(pfad):
            return pfad
    gefunden = shutil.which(name)
    return gefunden or None


def moeglich(plattform_name=None, system=None):
    """Laesst sich das Programm fuer diese Plattform bauen?"""
    return (plattform_name or plattform(system)) in BAUBAR


def grund(plattform_name=None, system=None):
    """Was einem Programm hier im Weg steht - leer, wenn nichts."""
    name = plattform_name or plattform(system)
    if name in PLATTFORMEN:
        return ""
    if name in BAUBAR:
        return ("Die CI baut fuer %s noch keine Datei. Selbst bauen geht aber: rapidyencs "
                "macOS-Bibliothek deckt beide Architekturen ab." % name)
    return UNMOEGLICH.get(name, "Fuer %s liefert rapidyenc keine C-Bibliothek, und ohne sie "
                                "laesst sich der yEnc-Teil nicht binden." % name)


def go_vorhanden():
    """Ist Go da?"""
    return shutil.which("go") is not None


def cc_vorhanden():
    """Ist ein C-Compiler da? Ohne ihn geht es nicht - rapidyenc ist cgo."""
    return any(shutil.which(c) for c in ("cc", "gcc", "clang"))


def selbst_baubar(plattform_name=None, system=None):
    """Go, ein C-Compiler - und eine Plattform, fuer die rapidyenc eine Bibliothek hat.

    Das Dritte fehlte: ohne die Bibliothek bricht der Bau beim Binden ab, und einen
    Bau-Befehl anzubieten, der nicht gehen kann, ist schlechter als eine klare Auskunft.
    """
    return go_vorhanden() and cc_vorhanden() and moeglich(plattform_name, system)


def finden(wurzel, datenordner=None, plattform_name=None, system=None):
    """Wo liegt das Programm? {pfad, woher} - woher ist mitgeliefert|suchpfad|None.

    Die Reihenfolge ist die aus dem Modulkopf: mitgeliefert zuerst, weil es ohne CI und
    ohne Go da ist.
    """
    pfad = mitgeliefert(wurzel, plattform_name, system)
    if pfad:
        return {"pfad": pfad, "woher": "mitgeliefert"}
    pfad = im_suchpfad(datenordner, system)
    if pfad:
        return {"pfad": pfad, "woher": "suchpfad"}
    return {"pfad": None, "woher": None}


def bau_befehl(ziel=None):
    """Der Befehl, der das Programm hier baut - genau so steht er auch im README."""
    aus = ziel or os.path.join("build", NAME)
    return ["go", "build", "-trimpath", "-o", aus, "./cmd/nuvio-usenet"]


# Gemerkte Fassungen: (pfad, mtime, groesse) -> Meldung. Ohne das forkte `stand()` bei jedem
# GET /api/nuvio_usenet ein 6,5-MB-cgo-Programm, nur um eine Zeichenkette zu erfahren, die
# sich nicht aendert - gemessen 3,3 ms hier, auf Termux mit eMMC eher hundert Millisekunden.
# Dieselbe Datei an gleichem Pfad mit gleicher mtime meldet dieselbe Fassung.
_gemerkt = {}


def _marke(pfad):
    try:
        s = os.stat(pfad)
    except OSError:
        return None
    return (os.path.abspath(pfad), s.st_mtime, s.st_size)


def fassung(pfad, lauf=None):
    """`nuvio-usenet fassung` ausfuehren und das JSON zurueckgeben, sonst None.

    Das Ergebnis wird je Datei gemerkt (siehe `_gemerkt`). `lauf` ist nur fuer Tests da;
    wird es uebergeben, wird nichts gemerkt und nichts aus dem Gedaechtnis genommen.
    """
    if not pfad:
        return None
    if lauf is None:
        marke = _marke(pfad)
        if marke is not None and marke in _gemerkt:
            return _gemerkt[marke]
    starter = lauf or _lauf
    try:
        roh = starter([pfad, "fassung"])
    except Exception:  # noqa: BLE001 - ein fremdes Programm darf H0rSt nicht kippen
        return None
    try:
        wert = json.loads(roh or "{}")
    except (ValueError, TypeError):
        return None
    if not isinstance(wert, dict):
        return None
    if lauf is None and marke is not None:
        _gemerkt[marke] = wert
    return wert


def _lauf(befehl):
    ergebnis = subprocess.run(befehl, capture_output=True, text=True,
                              timeout=ZEITGRENZE, check=False)
    return ergebnis.stdout


def stand(wurzel, datenordner=None, lauf=None, plattform_name=None, system=None):
    """Antwort fuer die Oberflaeche: ob und wo das Programm liegt, und was es meldet."""
    ort = finden(wurzel, datenordner, plattform_name, system)
    gemeldet = fassung(ort["pfad"], lauf) if ort["pfad"] else None
    return {
        "modul": SCHLUESSEL,
        "name": NAME,
        "symbol": SYMBOL,
        "plattform": plattform_name or plattform(system),
        "da": bool(ort["pfad"]),
        "woher": ort["woher"],
        "pfad": ort["pfad"] or "",
        "fassung": (gemeldet or {}).get("fassung", ""),
        "go": (gemeldet or {}).get("go", ""),
        "selbst_baubar": selbst_baubar(plattform_name, system),
        "go_da": go_vorhanden(),
        "cc_da": cc_vorhanden(),
        "bau_befehl": " ".join(bau_befehl()),
        "plattformen": list(PLATTFORMEN),
        "moeglich": moeglich(plattform_name, system),
        "grund": grund(plattform_name, system),
    }


# --- Zugaenge aus H0rSts eigenen NNTP-Anbietern ---------------------------------------------

def zugaenge_aus_daten(daten):
    """Die NNTP-Anbieter aus den Nutzerdaten in der Form, die nuvio-usenet erwartet.

    Dieselbe Quelle wie beim bestehenden Usenet-Streaming (`anbindungen.usenet_server`),
    damit nicht zweimal eingetragen werden muss.
    """
    from . import anbindungen
    liste = []
    for _, _, w in anbindungen.eigene(daten or {}, "nntp"):
        host = str(w.get("host") or "").strip()
        if not host or not w.get("user") or not w.get("pass"):
            continue
        tls = str(w.get("ssl", "1")) == "1"
        port = str(w.get("port") or "").strip()
        if not port.isdigit():
            port = "563" if tls else "119"
        verbindungen = str(w.get("verbindungen") or "").strip()
        liste.append({
            "host": "%s:%s" % (host, port),
            "benutzer": str(w.get("user")),
            "passwort": str(w.get("pass")),
            "verbindungen": int(verbindungen) if verbindungen.isdigit() else 8,
            "tls": tls,
            "ersatz": str(w.get("ersatz", "0")) == "1",
        })
    return liste


def zugaenge_schreiben(ordner, zugaenge):
    """Die Zugaenge als Datei ablegen und den Pfad zurueckgeben.

    Rechte 0600, weil Passwoerter darin stehen - nuvio-usenet verweigert sonst den Start.
    Der Aufrufer loescht die Datei wieder (siehe pruefen()).
    """
    os.makedirs(ordner, exist_ok=True)
    pfad = os.path.join(ordner, "nuvio-usenet-zugaenge.json")
    # Erst mit engen Rechten anlegen, dann schreiben: dazwischen soll nichts lesbar sein.
    kennung = os.open(pfad, os.O_CREAT | os.O_WRONLY | os.O_TRUNC, 0o600)
    with os.fdopen(kennung, "w", encoding="utf-8") as datei:
        json.dump(zugaenge, datei)
    return pfad


def pruefen(programm, nzb_text, zugaenge, ordner, lauf=None, zeitgrenze=None):
    """`nuvio-usenet pruefen` ausfuehren und den Stand zurueckgeben.

    Die NZB geht ueber die Standardeingabe (`--nzb -`), damit sie nicht erst auf die Platte
    muss. Die Zugangsdatei wird danach wieder entfernt - auch wenn es schiefgeht.
    """
    if not programm:
        raise NuvioUsenetFehler("nuvio-usenet ist nicht vorhanden")
    if not zugaenge:
        raise NuvioUsenetFehler("Kein Usenet-Anbieter eingetragen")
    if not str(nzb_text or "").strip():
        raise NuvioUsenetFehler("Keine NZB uebergeben")
    pfad = zugaenge_schreiben(ordner, zugaenge)
    try:
        starter = lauf or _lauf_mit_eingabe
        roh = starter([programm, "pruefen", "--nzb", "-", "--zugaenge", pfad],
                      str(nzb_text), zeitgrenze or ZEITGRENZE)
    finally:
        try:
            os.remove(pfad)
        except OSError:
            pass
    try:
        wert = json.loads(roh or "")
    except (ValueError, TypeError) as fehler:
        raise NuvioUsenetFehler("nuvio-usenet antwortet kein JSON") from fehler
    if not isinstance(wert, dict):
        raise NuvioUsenetFehler("nuvio-usenet antwortet kein JSON-Objekt")
    return wert


def _lauf_mit_eingabe(befehl, eingabe, zeitgrenze):
    ergebnis = subprocess.run(befehl, input=eingabe, capture_output=True, text=True,
                              timeout=zeitgrenze, check=False)
    if ergebnis.returncode != 0:
        # Die Fehlerausgabe ist kurz gehalten und nennt keine Zugangsdaten.
        raise NuvioUsenetFehler((ergebnis.stderr or "nuvio-usenet scheiterte").strip()[:300])
    return ergebnis.stdout
