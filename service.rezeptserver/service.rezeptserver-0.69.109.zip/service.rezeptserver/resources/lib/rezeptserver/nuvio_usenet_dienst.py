"""Den nuvio-usenet-Dauerprozess fuehren und darueber streamen.

`nuvio_usenet.py` sagt, **ob und wo** das Programm liegt. Hier geht es darum, es wirklich
laufen zu lassen - und zwar so, dass H0rSt auch auf einem Fernseher, einem NAS oder in
Termux nicht zum Prozessverwalter wird:

  * **Auf Abruf, nicht dauerhaft.** Gefragt wird nur "antwortet einer?" (`GET /fassung`).
    Antwortet keiner, wird einer gestartet. Der Dienst beendet sich nach `--leerlauf` von
    selbst, sobald niemand mehr etwas abruft. Damit gibt es keine PID-Datei, keine
    Waisenprozesse nach einem harten Ende von H0rSt und keinen Speicherverbrauch, wenn
    niemand schaut.
  * **Ein laufender Dienst wird nur bei passenden Einstellungen uebernommen.** Gefunden
    heisst nicht "der Richtige": auf demselben Rechner kann eine zweite H0rSt-Instanz mit
    **anderen** NNTP-Konten laufen, und wer die Zugangsdaten aendert, darf nicht noch eine
    Viertelstunde mit den alten streamen. Darum bekommt der Dienst beim Start eine Kennung
    seiner Einstellungen (`--kennung`), meldet sie unter `/stand`, und `sicherstellen`
    uebernimmt ihn nur, wenn sie stimmt. Passt sie nicht und ist es der eigene Prozess, wird
    er beendet und neu gestartet. Dasselbe gilt **nach** dem Start: starten zwei Instanzen
    gleichzeitig, gewinnt nur eine den Port, und die andere darf den fremden Dienst nicht
    nehmen - sie versucht den naechsten Port.
  * **Die Kennung ist der Inhalt.** Eine NZB wird einmal angemeldet (`POST /anmelden`) und
    hat danach eine Kennung aus ihrem sha256. Nach einem Neustart des Dienstes antwortet
    `GET /holen/...` mit **404**, und dann wird eben neu angemeldet - kein Ablaufdatum, das
    zwischen zwei Prozessen verhandelt werden muesste.
  * **Kein Proxy fuer den eigenen Rechner.** Die Aufrufe gehen bewusst nicht ueber
    `netz.urllib_holen`: dort steckt der Schutz gegen fremde Adressen (der 127.0.0.1
    richtigerweise sperrt) und die Proxy-Einstellung der Umgebung. Fuer einen Dienst auf
    demselben Rechner ist beides falsch.

Die Zugangsdaten liegen nur so lange als Datei (0600), bis der Dienst sie gelesen hat:
antwortet `/fassung`, ist er an `Verbinden` vorbei, und die Datei wird entfernt.

`Streamer` erfuellt denselben Vertrag wie `dienste_downloads_sabnzbd.NzbDav`
(`streamen() -> (adresse, kopf, dateiname, groesse)`), damit H0rSts bestehender
Wiedergabe-Weg (`/usenet/<schluessel>`) ihn ohne weitere Aenderung durchreicht.
"""

import hashlib
import json
import os
import socket
import subprocess
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

from . import nuvio_usenet
from .dienste_grund import DienstFehler

# Porte, auf denen ein Dienst gesucht und sonst gestartet wird. Mehrere, weil 7700 schon
# belegt sein kann - von einem fremden Programm oder von H0rSt in einer zweiten Instanz.
PORTE = (7700, 7701, 7702, 7703, 7704)
SCHREIBKOPF = {"X-Rezeptserver": "1"}
# Leerlauf, nach dem sich der Dienst selbst beendet (Argument fuer --leerlauf).
LEERLAUF = "15m"
# So lange wird nach dem Start auf die erste Antwort gewartet.
STARTFRIST = 25.0
_TAKT = 0.25
ZEITGRENZE = 15.0
# Groesste Antwort, die hier gelesen wird (Anmeldung mit Dateiliste).
MAX_ANTWORT = 4 << 20
# Keine eigene Endungsliste: `debrid_grund.VIDEO_ENDUNGEN` ist die gepflegte, und sie hat
# Endungen, die eine Kopie schon verloren hatte (.mpeg).

_sperre = threading.Lock()
# Eigene Sperre fuers Starten: ein Abspieler oeffnet mehrere Anfragen gleichzeitig, und ohne
# sie wuerden zwei davon je einen Dienst starten (der zweite auf dem naechsten Port).
_startsperre = threading.Lock()
_prozess = None     # subprocess.Popen des selbst gestarteten Dienstes
_adresse = ""       # "127.0.0.1:7700" des Dienstes, der gerade antwortet


# --- HTTP zum eigenen Rechner --------------------------------------------------------------

def konfig_kennung(zugaenge, ordner=""):
    """Kurze Kennung der Einstellungen, mit denen ein Dienst gestartet wurde.

    Sie wird nur **verglichen**, nie zurueckgerechnet: der Dienst meldet sie unter `/stand`,
    und das verlangt den Pflichtkopf, kommt also nicht aus einem Browser. Ein Prozess, der
    sie dort lesen koennte, kann ohnehin H0rSts Nutzerdaten lesen.
    """
    roh = json.dumps([zugaenge or [], ordner or ""], sort_keys=True, ensure_ascii=False)
    return hashlib.sha256(roh.encode("utf-8")).hexdigest()[:16]


def _bau_oeffner():
    """Eigener Oeffner ohne Proxy **und ohne TLS-Teil**.

    Ohne Proxy, weil ein Dienst auf 127.0.0.1 nicht ueber einen Proxy gehoert. Ohne
    HTTPSHandler, weil dessen Aufbau `ssl.create_default_context()` ruft und damit den
    ganzen CA-Speicher von der Platte liest und auswertet - gemessen 3,2 von 3,5 ms je
    Aufruf, fuer eine Klartextverbindung zum eigenen Rechner, die nie TLS benutzt.

    Einmal gebaut, nicht je Aufruf: `_warten` fragt bis zu 100 mal, `sicherstellen` bis zu
    zwoelf mal. Oeffner sind zustandslos; `netz._OEFFNER` wird im Projekt genauso gehalten.
    """
    # Dieselben Teile, die `build_opener` setzt - nur ohne HTTPSHandler. Der
    # HTTPDefaultErrorHandler muss dabei sein, sonst wird aus einem 404 keine HTTPError,
    # die `ruf` faengt (genau daran ist die erste Fassung gescheitert).
    oeffner = urllib.request.OpenerDirector()
    for teil in (urllib.request.ProxyHandler({}), urllib.request.UnknownHandler(),
                 urllib.request.HTTPHandler(), urllib.request.HTTPDefaultErrorHandler(),
                 urllib.request.HTTPRedirectHandler(), urllib.request.HTTPErrorProcessor()):
        oeffner.add_handler(teil)
    return oeffner


_OEFFNER = _bau_oeffner()


def ruf(adresse, weg, methode="GET", koerper=None, zeitgrenze=ZEITGRENZE):
    """Einen Weg des Dienstes aufrufen und (status, text) zurueckgeben.

    Netzfehler werden **nicht** zu Ausnahmen: "antwortet nicht" ist hier ein Ergebnis,
    nach dem gefragt wird, kein Zwischenfall. HTTP-Fehlercodes kommen als Status zurueck.
    """
    url = "http://%s%s" % (adresse, weg)
    daten = koerper.encode("utf-8") if isinstance(koerper, str) else koerper
    anfrage = urllib.request.Request(url, data=daten, headers=dict(SCHREIBKOPF), method=methode)
    try:
        with _OEFFNER.open(anfrage, timeout=zeitgrenze) as antwort:
            return antwort.status, antwort.read(MAX_ANTWORT).decode("utf-8", "replace")
    except urllib.error.HTTPError as fehler:
        try:
            text = fehler.read(2000).decode("utf-8", "replace")
        except OSError:
            text = ""
        fehler.close()
        return fehler.code, text
    except (urllib.error.URLError, OSError, ValueError):
        return 0, ""


def fassung_vom_dienst(adresse, zeitgrenze=1.0):
    """Die Fassung, die der Dienst an dieser Adresse meldet, sonst None.

    Geprueft wird auch der Inhalt: auf dem Port koennte ein fremdes Programm sitzen, und
    dessen Antwort darf nicht als unser Dienst durchgehen.
    """
    status, text = ruf(adresse, "/fassung", zeitgrenze=zeitgrenze)
    if status != 200:
        return None
    try:
        wert = json.loads(text)
    except ValueError:
        return None
    if not isinstance(wert, dict) or not wert.get("fassung") or not wert.get("go"):
        return None
    return wert


def stand_vom_dienst(adresse, zeitgrenze=2.0):
    """Was /stand meldet (Kennung, Zahl der Dateien), sonst None."""
    status, text = ruf(adresse, "/stand", zeitgrenze=zeitgrenze)
    if status != 200:
        return None
    try:
        wert = json.loads(text)
    except ValueError:
        return None
    return wert if isinstance(wert, dict) else None


def unser_dienst(adresse, kennung):
    """Die Meldung des Dienstes an dieser Adresse, **wenn** es unserer ist, sonst None.

    Eine Funktion fuer eine Zusicherung. Sie stand zweimal da - einmal beim Suchen, einmal
    nach dem Start -, und als sie nur beim Suchen stand, war der Startweg offen (0.69.105).
    `kennung` ist Pflicht und darf None sein, wenn ausdruecklich **nicht** geprueft werden
    soll; wer die Prueffrage stellt, muss die Antwort mitbringen.
    """
    gemeldet = fassung_vom_dienst(adresse)
    if not gemeldet or kennung is None:
        return gemeldet
    stand = stand_vom_dienst(adresse)
    if stand and str(stand.get("kennung") or "") == str(kennung):
        return gemeldet
    return None


def laufender(porte=PORTE, kennung=None):
    """(adresse, fassung) des Dienstes, der schon laeuft, sonst (None, None).

    Kurze Zeitgrenze mit Absicht: das laeuft beim Oeffnen der Einstellungsseite. Ein
    geschlossener Port weist sofort ab, die Grenze trifft nur ein fremdes Programm, das
    annimmt und dann schweigt - und fuenf Porte mal drei Sekunden waeren eine Seite, die
    haengt.
    """
    with _sperre:
        bekannt = _adresse
    reihe = ([bekannt] if bekannt else []) + ["127.0.0.1:%d" % p for p in porte]
    gesehen = set()
    for adresse in reihe:
        if adresse in gesehen:
            continue
        gesehen.add(adresse)
        # Gefunden ist nicht "der Richtige": andere Einstellungen heissen anderer Dienst.
        gemeldet = unser_dienst(adresse, kennung)
        if gemeldet:
            return adresse, gemeldet
    return None, None


def _port_frei(port):
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            s.bind(("127.0.0.1", port))
        except OSError:
            return False
    return True


# --- Starten -------------------------------------------------------------------------------

def _protokoll(datenordner):
    """Datei fuer die Fehlerausgabe des Dienstes. Zu gross geworden -> neu anfangen."""
    pfad = os.path.join(datenordner, "nuvio-usenet.log")
    try:
        if os.path.getsize(pfad) > (1 << 20):
            os.remove(pfad)
    except OSError:
        pass
    return pfad


def starten(programm, zugaenge, datenordner, ordner="", porte=PORTE, starter=None, warten=None,
            leerlauf=LEERLAUF, kennung=None):
    """Den Dienst starten und (adresse, fassung) zurueckgeben.

    Die Zugangsdatei wird mit 0600 geschrieben und **entfernt, sobald der Dienst antwortet** -
    dann hat er sie gelesen. Sie wird auch entfernt, wenn der Start scheitert.
    """
    if not programm:
        raise DienstFehler("nuvio-usenet ist nicht vorhanden")
    if not zugaenge:
        raise DienstFehler("Kein Usenet-Anbieter eingetragen (Anbieter & Addons → Konten, Typ NNTP)")
    eigene = kennung if kennung is not None else konfig_kennung(zugaenge, ordner)
    frei = [p for p in porte if _port_frei(p)]
    if not frei:
        raise DienstFehler("Kein freier Port fuer nuvio-usenet (%s)" % ", ".join(str(p) for p in porte))
    # Der Reihe nach, nicht nur der erste freie Port: `_port_frei` prueft und gibt den Port
    # wieder frei, und zwischen Pruefung und Start kann ihn jemand anderes belegen - eine
    # zweite H0rSt-Instanz, die gerade dasselbe tut. Dann stirbt der eigene Dienst mit
    # "address already in use", und auf dem Port antwortet ein **fremder**. Darum wird nach
    # dem Start die Kennung geprueft und bei Nichtuebereinstimmung der naechste Port
    # genommen (siehe _warten).
    for port in frei:
        adresse = "127.0.0.1:%d" % port
        pfad = nuvio_usenet.zugaenge_schreiben(datenordner, zugaenge)
        befehl = [programm, "dienst", "--adresse", adresse, "--zugaenge", pfad,
                  "--leerlauf", str(leerlauf), "--kennung", eigene]
        if ordner:
            befehl += ["--ordner", ordner]
        try:
            prozess = (starter or _starten)(befehl, _protokoll(datenordner))
        except OSError as fehler:
            _entfernen(pfad)
            raise DienstFehler("nuvio-usenet liess sich nicht starten: %s" % fehler) from fehler
        try:
            gemeldet = (warten or _warten)(adresse, prozess, eigene)
        finally:
            _entfernen(pfad)  # gelesen oder nicht: sie darf nicht liegen bleiben
        if gemeldet:
            with _sperre:
                global _prozess, _adresse
                _prozess, _adresse = prozess, adresse
            return adresse, gemeldet
        _beenden(prozess)
    raise DienstFehler("nuvio-usenet antwortet auf keinem Port (%s) mit der erwarteten Kennung - "
                       "mehr steht in %s"
                       % (", ".join(str(p) for p in frei), _protokoll(datenordner)))


def _starten(befehl, protokoll):
    """Der eigentliche Start. Eigene Sitzung, damit ein Signal an H0rSt keinen laufenden
    Film mitten im Bild abreisst - beenden tut sich der Dienst im Leerlauf selbst."""
    with open(protokoll, "ab") as log:
        return subprocess.Popen(befehl, stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL,
                                stderr=log, start_new_session=True)


def _warten(adresse, prozess, kennung=None, schlafen=time.sleep):
    """Auf die erste Antwort **des eigenen** Dienstes warten, sonst None.

    Dass auf der Adresse etwas antwortet, genuegt nicht: beim Rennen zweier H0rSt-Instanzen
    um denselben Port gewinnt nur eine, und die andere findet dort einen **fremden** Dienst.
    Nahm man den, liefen die eigenen Abrufe ueber dessen NNTP-Konto. Darum wird die Kennung
    verglichen, die der Dienst unter /stand meldet.

    Ist der eigene Prozess vorher weg, wird sofort aufgegeben - das ist genau der Fall
    "address already in use".
    """
    ende = time.monotonic() + STARTFRIST
    while time.monotonic() < ende:
        if fassung_vom_dienst(adresse):
            # Antwortet dort etwas, entscheidet die Kennung - ein fremder Dienst hat den
            # Port gewonnen, und der Aufrufer nimmt den naechsten.
            return unser_dienst(adresse, kennung)
        if prozess is not None and prozess.poll() is not None:
            return None  # schon gestorben; weiter zu warten bringt nichts
        schlafen(_TAKT)
    return None


def _entfernen(pfad):
    try:
        os.remove(pfad)
    except OSError:
        pass


def _beenden(prozess, frist=5):
    if prozess is None or prozess.poll() is not None:
        return
    try:
        prozess.terminate()
        prozess.wait(frist)
    except Exception:  # noqa: BLE001 - beim Aufraeumen darf nichts mehr hochkommen
        try:
            prozess.kill()
        except OSError:
            pass


def sicherstellen(wurzel, datenordner, zugaenge, ordner="", porte=PORTE, **zusatz):
    """(adresse, fassung) eines laufenden Dienstes - erst suchen, dann starten.

    Unter der Startsperre, und **nach** ihr noch einmal gesucht: wartete hier ein zweiter
    Aufruf, hat der erste inzwischen gestartet, und ein zweiter Dienst waere nur Ballast.

    Uebernommen wird nur ein Dienst mit **passender** Kennung. Sonst waere es ein fremder
    (zweite H0rSt-Instanz mit anderen Konten) oder ein veralteter (die Zugangsdaten haben
    sich geaendert), und beide wuerden still das Falsche tun.
    """
    kennung = konfig_kennung(zugaenge, ordner)
    adresse, gemeldet = laufender(porte, kennung)
    if adresse:
        return adresse, gemeldet
    with _startsperre:
        # Noch einmal ueber **alle** Porte, nicht nur die bekannte Adresse: wartete hier ein
        # zweiter Faden, steht sie zwar in `_adresse` - aber eine zweite H0rSt-Instanz ist
        # ein anderer Prozess, und die findet man nur auf den Porten. Die Portsuche ist
        # billig, weil ein geschlossener Port sofort abweist; teuer wird sie nur bei einem
        # fremden Programm, das annimmt und schweigt.
        adresse, gemeldet = laufender(porte, kennung)
        if adresse:
            return adresse, gemeldet
        ort = nuvio_usenet.finden(wurzel, datenordner)
        if not ort["pfad"]:
            raise DienstFehler("nuvio-usenet ist nicht vorhanden. Bauen mit: %s"
                               % " ".join(nuvio_usenet.bau_befehl()))
        # Laeuft ein **eigener** Dienst mit alter Kennung, wird er beendet statt
        # danebengestellt: sonst haelt er Verbindungen beim Anbieter und einen
        # Zwischenspeicher, die niemand mehr benutzt.
        if laeuft():
            beenden()
        return starten(ort["pfad"], zugaenge, datenordner, ordner, porte, kennung=kennung,
                       **zusatz)


def beenden():
    """Den selbst gestarteten Dienst beenden - beim Herunterfahren von H0rSt."""
    with _sperre:
        global _prozess, _adresse
        prozess, _prozess, _adresse = _prozess, None, ""
    _beenden(prozess)


def laeuft():
    """Laeuft ein von H0rSt gestarteter Dienst noch?"""
    with _sperre:
        return _prozess is not None and _prozess.poll() is None


# --- Anmelden und Adressen ----------------------------------------------------------------

def anmelden(adresse, nzb_text):
    """Eine NZB anmelden -> {"kennung", "dateien": [{nr, name, bytes, segmente}]}."""
    if not str(nzb_text or "").strip():
        raise DienstFehler("Keine NZB uebergeben")
    status, text = ruf(adresse, "/anmelden", "POST", nzb_text)
    if status != 200:
        raise DienstFehler("nuvio-usenet hat die NZB nicht angenommen (%s): %s"
                           % (status or "keine Antwort", (text or "").strip()[:200]))
    try:
        wert = json.loads(text)
    except ValueError as fehler:
        raise DienstFehler("nuvio-usenet antwortet kein JSON") from fehler
    if not isinstance(wert, dict) or not wert.get("kennung"):
        raise DienstFehler("nuvio-usenet nennt keine Kennung")
    wert["dateien"] = [d for d in (wert.get("dateien") or []) if isinstance(d, dict)]
    return wert


def beste_videodatei(dateien, staffel=None, folge=None):
    """Die groesste passende Videodatei (ohne Sample). Gibt es keine, die groesste ueberhaupt.

    Mit staffel/folge fallen Dateien weg, die eine *andere* Folge nennen: eine Staffelbox
    enthaelt zehn Folgen, und die groesste davon ist nicht die gewaehlte. Bleibt dabei
    nichts uebrig, enthaelt die NZB die Folge nicht - dann lieber ein Fehler als die falsche.
    """
    from .debrid_grund import VIDEO_ENDUNGEN
    from .usenet_stream_grund import folge_passt
    videos = [d for d in dateien
              if str(d.get("name") or "").lower().endswith(tuple(VIDEO_ENDUNGEN))
              and "sample" not in str(d.get("name") or "").lower()]
    auswahl = videos or list(dateien)
    passend = [d for d in auswahl if folge_passt(d.get("name"), staffel, folge)]
    if not passend:
        return None
    return max(passend, key=lambda d: int(d.get("bytes") or 0))


def holen_adresse(adresse, kennung, nr, name=""):
    """Die GET-Adresse, unter der der Dienst diese Datei ausliefert."""
    weg = "/holen/%s/%d" % (urllib.parse.quote(str(kennung), safe=""), int(nr))
    if name:
        weg += "/" + urllib.parse.quote(str(name), safe="")
    return "http://%s%s" % (adresse, weg)


# --- Streamer: derselbe Vertrag wie NzbDav -------------------------------------------------

class Streamer:
    """Usenet-Streaming ueber H0rSts eigenen Teil - einsetzbar wie NzbDAV oder AltMount.

    Deshalb heisst die Methode `streamen` und gibt (adresse, kopf, dateiname, groesse)
    zurueck: `stremio_debrid.usenet_weiter` reicht das an H0rSts Wiedergabe-Weg weiter, und
    der bedient den Player samt Range-Anfragen. Nichts davon musste dafuer geaendert werden.
    """
    typ = nuvio_usenet.SCHLUESSEL
    typ_name = nuvio_usenet.NAME
    kann = ("nzb",)
    # url gehoert zum Vertrag von app.dienste: oberflaeche_dienste_zentrale._dienst_info
    # liest es fuer **jeden** Eintrag. Ohne das Feld stirbt GET /api/dienste mit einem
    # AttributeError, und der Reiter "Herunterladen" antwortet nicht mehr. Leer ist richtig:
    # dieser Dienst hat keine eingestellte Adresse, er wird bei Bedarf gestartet und laeuft
    # auf einem Port, der erst dann feststeht.
    url = ""

    def __init__(self, wurzel, datenordner, zugaenge, name="", ordner="", nzb_laden=None,
                 **zusatz):
        self.name = name or nuvio_usenet.NAME
        self.wurzel = wurzel
        self.datenordner = datenordner
        self.zugaenge = list(zugaenge or [])
        self.ordner = ordner
        self._nzb_laden = nzb_laden
        self._zusatz = zusatz

    def _dienst(self):
        return sicherstellen(self.wurzel, self.datenordner, self.zugaenge, self.ordner,
                             **self._zusatz)

    def pruefen(self):
        """Nachsehen, **nicht** starten.

        Frueher rief das `_dienst()`, also `sicherstellen()`: eine Pruefliste konnte damit
        einen Prozess starten und in einer einzigen Anfrage auf ihn warten - im schlechten
        Fall gerechnet bis zu zweieinhalb Minuten, weil sich Portsuche (zweimal ueber fuenf
        Porte) und Startfrist (25 s je Port) addieren. Starten gehoert zum ausdruecklichen
        `POST {aktion: "starten"}`.
        """
        kennung = konfig_kennung(self.zugaenge, self.ordner)
        # Dieselben Porte, auf denen auch gestartet wuerde - sonst sieht die Pruefliste
        # einen anderen Bereich als der Streamer.
        adresse, gemeldet = laufender(self._zusatz.get("porte", PORTE), kennung)
        if adresse:
            return "nuvio-usenet %s laeuft auf %s, %d Anbieter" % (
                (gemeldet or {}).get("fassung", "?"), adresse, len(self.zugaenge))
        if not nuvio_usenet.finden(self.wurzel, self.datenordner)["pfad"]:
            raise DienstFehler("nuvio-usenet ist nicht vorhanden. Bauen mit: %s"
                               % " ".join(nuvio_usenet.bau_befehl()))
        return "nuvio-usenet liegt bereit, laeuft gerade nicht, %d Anbieter" % len(self.zugaenge)

    def fertige(self, kategorie="Movies"):
        """Nichts ist vorab eingebunden - hier wird direkt gestreamt, nicht erst gemountet.

        NzbDAV meldet hier seine schon fertigen Jobs (daraus wird das ⚡ in der Streamliste).
        Bei nuvio-usenet gibt es diesen Zwischenschritt nicht, darum immer leer.
        """
        return []

    def nzb_text(self, nzb_url):
        if self._nzb_laden:
            return self._nzb_laden(nzb_url)
        from . import rustnzb
        return rustnzb.nzb_laden(nzb_url)

    def streamen(self, nzb_url, name, kategorie="Movies", wartezeit=None, staffel=None, folge=None):
        """NZB laden, anmelden, die Videodatei als GET-Adresse zurueckgeben.

        kategorie und wartezeit gehoeren zum Vertrag (NzbDAV braucht sie fuers Einbinden);
        hier gibt es kein Einbinden und kein Warten, also werden sie nicht gebraucht.
        staffel/folge waehlen die Folge in einer Staffelbox.
        """
        del kategorie, wartezeit
        from .usenet_stream_grund import folge_text
        adresse, _ = self._dienst()
        try:
            text = self.nzb_text(nzb_url)
        except Exception as fehler:  # noqa: BLE001 - jeder Ladefehler ist hier ein Dienstfehler
            raise DienstFehler("NZB liess sich nicht laden: %s" % fehler) from fehler
        angemeldet = anmelden(adresse, text)
        datei = beste_videodatei(angemeldet["dateien"], staffel, folge)
        if not datei:
            raise DienstFehler("In der NZB steht keine Datei%s" % folge_text(staffel, folge))
        dateiname = str(datei.get("name") or name or "video")
        return (holen_adresse(adresse, angemeldet["kennung"], datei.get("nr") or 0, dateiname),
                dict(SCHREIBKOPF), dateiname, int(datei.get("bytes") or 0))


def streamer_fuer(verwaltung, datenordner_pfad, wurzel_pfad=None, **zusatz):
    """Streamer, wenn das Programm liegt **und** ein NNTP-Konto eingetragen ist, sonst None.

    Ohne Anbieter waere der Eintrag eine leere Verheissung: er stuende in der Streamliste
    und jeder Klick endete im Fehler. Ohne Programm ebenso.
    """
    try:
        daten = verwaltung.daten() if verwaltung is not None else {}
    except Exception:  # noqa: BLE001 - kaputte Nutzerdaten duerfen den Start nicht kippen
        return None
    zugaenge = nuvio_usenet.zugaenge_aus_daten(daten)
    if not zugaenge:
        return None
    wurzel = wurzel_pfad or nuvio_usenet.wurzel()
    # Der Datenordner wird **uebergeben**, nicht erraten: er geht in die Kennung ein, und
    # zwei Ableitungen hiessen zwei Kennungen.
    ordner = datenordner_pfad or wurzel
    if not nuvio_usenet.finden(wurzel, ordner)["pfad"]:
        return None
    return Streamer(wurzel, ordner, zugaenge, ordner=nuvio_usenet.zwischenordner(ordner), **zusatz)
