"""Bruecke: ein Glied des Verbunds als H0rSt-Modul - eine Fassung fuer alle.

Nuvio Mobile hatte als erstes eine eigene Bruecke (/api/nuvio): die App fragt H0rSt, was er
anbietet, und haengt ihn als Quelle ein. NuvioTV und ARVIO koennen dasselbe, also gibt es das
hier nur noch einmal. Welche Routen welche Funktion bedienen, steht allein im Verbund
(verbund.FAEHIGKEITEN); hier steht je Glied nur, welche davon es bedient und wie es sie in
der eigenen App nennt.

  GET  /api/<glied>   Stand: an, adresse, addon, api, funktionen, einstellungen
  POST /api/<glied>   {aktion: einstellungen, <glied>_an, <glied>_adresse}

<glied> ist die Kennung aus verbund.TEILE: nuvio, nuviotv, arvio.
"""

from . import __version__, verbund

MAX_ADRESSE = 300

# Je Glied: welche Faehigkeit es bedient und wie sie in dieser App heisst.
# Die Kennungen links muessen in verbund.FAEHIGKEITEN stehen (ein Test prueft das).
BEDIENT = {
    "nuvio": {
        "katalog": "Start, Entdecken, Suche",
        "streams": "Player, Quellenwahl, Autoplay",
        "addon": "Addons, Manifest, Kataloge, Streams",
        "untertitel": "Untertitelquellen, Sprache, Stil",
        "fortschritt": "Weiterschauen, gesehen, Resume",
        "downloads": "Offline-Speicher, Fortschritt",
        "tracker": "Trakt, SIMKL, MDBList",
        "debrid": "TorBox, Premiumize, Aufloeser",
    },
    "nuviotv": {
        "katalog": "Home, Discover, Search",
        "streams": "Player, Stream-Auswahl, Autoplay",
        "addon": "Addons, Manifest, Kataloge, Streams",
        "untertitel": "Untertitel, Sprache, Sync",
        "fortschritt": "Continue Watching, Library",
        "tracker": "Trakt, SIMKL, MDBList",
        "debrid": "Debrid-Quellen, Cloud",
        "heimserver": "Plex, Jellyfin, Emby, MediaBrowser",
    },
    "arvio": {
        "katalog": "Start, Entdecken, Suche",
        "streams": "Player, Quellenwahl, Autoplay",
        "addon": "Addon-Verwaltung, Manifest, Kataloge",
        "untertitel": "Untertitel, Sprache, Live-KI",
        "fortschritt": "Weiterschauen, Verlauf",
        "downloads": "Offline-Speicher, Fortschritt",
        "tracker": "Trakt, SIMKL, MDBList",
        "debrid": "Debrid-Quellen, Cloud",
        "livetv": "Live-TV, EPG, Xtream",
        "heimserver": "Plex, Jellyfin, Emby",
    },
}


def glieder():
    """Die Kennungen aller Glieder mit eigener Bruecke, in der Reihenfolge des Verbunds."""
    return [t["id"] for t in verbund.TEILE if t.get("modul") and t["id"] in BEDIENT]


def _teil(glied):
    """Das Glied aus dem Verbund, oder ein Fehler, wenn es keine Bruecke hat."""
    t = verbund.teil(glied)
    if t is None or not t.get("modul") or t["id"] not in BEDIENT:
        raise ValueError("Unbekanntes Glied")
    return t


def an_schluessel(glied):
    """Name des Schalters in den Einstellungen (z. B. nuvio_an)."""
    return str(glied) + "_an"


def adresse_schluessel(glied):
    """Name der eigenen Adresse in den Einstellungen (z. B. nuvio_adresse)."""
    return str(glied) + "_adresse"


def funktionen(glied):
    """Die Faehigkeiten, die dieses Glied bedient - mit dem Namen aus der eigenen App."""
    bedient = BEDIENT[_teil(glied)["id"]]
    return [dict(f, app=bedient[f["id"]]) for f in verbund.faehigkeiten(bedient)]


def schalter(glied, werte):
    """Schalter des Glieds aus den gemeinsamen Einstellungen (Standard: an)."""
    w = werte or {}
    adresse = str(w.get(adresse_schluessel(glied)) or "").strip()
    return {"an": w.get(an_schluessel(glied)) is not False, "adresse": adresse[:MAX_ADRESSE]}


def basis_adresse(adresse, ersatz=""):
    """Eigene Adresse (Einstellungen) vor der Adresse der Anfrage; immer mit Slash am Ende."""
    wahl = str(adresse or "").strip()
    if wahl:
        return wahl.rstrip("/") + "/"
    ersatz = str(ersatz or "").strip()
    return ersatz.rstrip("/") + "/" if ersatz else ""


def addon_adresse(basis):
    """Stremio-Addon-Adresse von H0rSt (das Token steckt bereits in der Basis)."""
    return basis + "manifest.json" if basis else ""


def api_basis(basis):
    """Basis fuer die H0rSt-APIs (Token-Praefix bleibt erhalten)."""
    return basis + "api/" if basis else ""


def stand(glied, werte, basis=""):
    """Antwort fuer GET /api/<glied>: was die App verbindet und was H0rSt dafuer anbietet."""
    t = _teil(glied)
    s = schalter(t["id"], werte)
    adresse = basis_adresse(s["adresse"], basis)
    return {
        "modul": t["id"],
        "name": t["name"],
        "symbol": t.get("symbol") or verbund.SYMBOL,
        "version": t.get("app_version") or "",
        "repo": t["repo"],
        "lizenz": t["lizenz"],
        "paket": t["paket"],
        "geraet": t["geraet"],
        "h0rst": __version__,
        "an": s["an"],
        "adresse": adresse,
        "addon": addon_adresse(adresse),
        "api": api_basis(adresse),
        "bruecke": api_basis(adresse) + t["modul"] if adresse else "",
        "verbund": api_basis(adresse) + verbund.SCHLUESSEL if adresse else "",
        "wege": list(t.get("wege") or []),
        "funktionen": [dict(f, an=s["an"]) for f in funktionen(t["id"])],
        "einstellungen": {an_schluessel(t["id"]): s["an"],
                          adresse_schluessel(t["id"]): s["adresse"]},
    }


def einstellungen_pruefen(glied, werte, wunsch):
    """Nur die beiden Modulwerte aus einem POST uebernehmen; unbekannte Felder bleiben weg."""
    t = _teil(glied)
    an, adr = an_schluessel(t["id"]), adresse_schluessel(t["id"])
    neu = dict(werte or {})
    if an in wunsch:
        neu[an] = bool(wunsch.get(an))
    if adr in wunsch:
        adresse = str(wunsch.get(adr) or "").strip()
        if " " in adresse or '"' in adresse or "<" in adresse or ">" in adresse:
            raise ValueError("Ungueltige Adresse")
        neu[adr] = adresse[:MAX_ADRESSE]
    return {an: neu.get(an, True), adr: neu.get(adr, "")}
