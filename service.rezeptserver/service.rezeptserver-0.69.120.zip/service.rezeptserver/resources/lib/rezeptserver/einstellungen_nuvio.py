"""Einstellungen der Bruecken: je Glied des Verbunds ein Schalter und eine Server-Adresse.

Eine Vorlage fuer alle - Nuvio Mobile, NuvioTV und ARVIO docken auf demselben Weg an
(bruecke.py), also sieht ihre Einstellungsseite auch gleich aus.
"""

from . import bruecke, verbund


def _kategorie(glied):
    """Die Einstellungsseite eines Glieds: Schalter und eigene Server-Adresse."""
    t = verbund.teil(glied)
    an, adresse = bruecke.an_schluessel(glied), bruecke.adresse_schluessel(glied)
    return {
        "id": glied, "name": t["name"], "symbol": t.get("symbol") or verbund.SYMBOL,
        "gruppe": "Verbindungen & Geräte",
        "beschreibung": "%s (%s, %s) ist der Client, H0rSt die Quelle. Die App haengt H0rSt als "
                        "Stremio-Addon ein und nutzt zusaetzlich die H0rSt-APIs ueber die Bruecke "
                        "/api/%s. Kein fremder Code laeuft im Server; die App wird bei GitHub geladen."
                        % (t["name"], t["repo"].rsplit("/", 2)[-2] + "/" + t["repo"].rsplit("/", 1)[-1],
                           t["lizenz"], glied),
        "zeilen": [
            {"key": an, "typ": "schalter", "titel": "%s-Modul andocken" % t["name"], "standard": True,
             "hinweis": "Ohne Schalter meldet /api/%s an=false: die App dockt nicht an und wird im "
                        "Verbund abgewiesen.%s Die uebrigen Werte bleiben gespeichert."
                        % (glied, " Der Reiter bleibt dann unsichtbar." if glied == "nuvio" else "")},
            {"key": adresse, "typ": "text", "titel": "Eigene Server-Adresse", "standard": "",
             "platzhalter": "https://h0rst.example/",
             "hinweis": "Leer = die Adresse der Anfrage wird benutzt (samt Token). Fuer unterwegs eine "
                        "feste HTTPS-Adresse eintragen, damit die Addon- und API-Adressen in der App "
                        "stimmen."},
        ],
    }


# Eine Seite je Glied mit Bruecke, in der Reihenfolge des Verbunds.
BRUECKE_KATEGORIEN = [_kategorie(g) for g in bruecke.glieder()]
NUVIO_KATEGORIE = next(k for k in BRUECKE_KATEGORIEN if k["id"] == "nuvio")
