"""Nuvio Mobile: der Client als H0rSt-Modul (ein Repo, voll verdrahtet).

Nuvio Mobile (NuvioMedia/NuvioMobile, GPL-3.0) ist ein Kotlin-Multiplatform-Client
fuer Android und iOS mit Filmen, Serien, Live-TV, Downloads und Plugins. H0rSt
bleibt der Modul-Host: die App haengt H0rSt als Stremio-Addon ein und nutzt die
H0rSt-Schnittstellen fuer Suche, Streams, Untertitel, Downloads, Fortschritt und
Tracker.

Die Mechanik steht in bruecke.py und gilt fuer alle Glieder des Verbunds; dieses
Modul ist nur noch der Name dafuer, damit /api/nuvio bleibt, wie die App es kennt.

  GET  /api/nuvio   Stand: an, addon, api, funktionen, einstellungen
  POST /api/nuvio   {aktion: einstellungen, ...} speichert die Schalter (wie /api/einstellungen)
"""

from . import bruecke, verbund

SCHLUESSEL = "nuvio"
_TEIL = verbund.teil(SCHLUESSEL)
NAME = _TEIL["name"]
SYMBOL = _TEIL["symbol"]
REPO = _TEIL["repo"]
LIZENZ = _TEIL["lizenz"]
PAKET = _TEIL["paket"]
APP_VERSION = _TEIL["app_version"]

AN = bruecke.an_schluessel(SCHLUESSEL)
ADRESSE = bruecke.adresse_schluessel(SCHLUESSEL)

# Was die App mitbringt und welche H0rSt-Schnittstelle es bedient (Bruecke, nicht Kopie).
BEDIENT = bruecke.BEDIENT[SCHLUESSEL]
FUNKTIONEN = bruecke.funktionen(SCHLUESSEL)

basis_adresse = bruecke.basis_adresse
addon_adresse = bruecke.addon_adresse
api_basis = bruecke.api_basis


def schalter(werte):
    """Schalter des Moduls aus den gemeinsamen Einstellungen (Standard: an)."""
    return bruecke.schalter(SCHLUESSEL, werte)


def stand(werte, basis=""):
    """Antwort fuer GET /api/nuvio: was die App verbindet und was H0rSt dafuer anbietet."""
    return bruecke.stand(SCHLUESSEL, werte, basis)


def einstellungen_pruefen(werte, wunsch):
    """Nur die beiden Modulwerte aus einem POST uebernehmen; unbekannte Felder bleiben weg."""
    return bruecke.einstellungen_pruefen(SCHLUESSEL, werte, wunsch)
