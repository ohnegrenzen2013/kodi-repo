"""Bruecken (bruecke.py): Stand der Verdrahtung und Modulschalter je Glied.

Ein Weg fuer alle Glieder des Verbunds - /api/nuvio, /api/nuviotv, /api/arvio.

  GET  /api/<glied>   Stand: an, adresse, addon, api, bruecke, funktionen, einstellungen
  POST /api/<glied>   {aktion: einstellungen, <glied>_an, <glied>_adresse}
"""

import json

from . import bruecke

# Die Pfade, die dieser Mixin bedient: /api/nuvio, /api/nuviotv, /api/arvio.
PFADE = {"/api/" + g: g for g in bruecke.glieder()}


class BrueckeMixin:
    def bruecke_glied(self, pfad):
        """Welches Glied dieser Pfad meint, sonst None."""
        return PFADE.get(str(pfad or ""))

    def bruecke_lesen(self, glied, kopf):
        werte = self._einstellungen_lesen().get("werte") or {}
        basis = ""
        eigene = getattr(self.app, "eigene_basis", None)
        if callable(eigene):
            basis = eigene(kopf or {}) or ""
        try:
            return 200, "application/json", bruecke.stand(glied, werte, basis)
        except ValueError as fehler:
            return 404, "application/json", {"fehler": str(fehler)}

    def bruecke_post(self, glied, koerper, kopf):
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
        except (ValueError, UnicodeDecodeError):
            return 400, "application/json", {"fehler": "JSON-Fehler"}
        if not isinstance(wunsch, dict):
            return 400, "application/json", {"fehler": "JSON-Objekt erwartet"}
        aktion = str(wunsch.get("aktion") or "einstellungen")
        if aktion != "einstellungen":
            return 400, "application/json", {"fehler": "aktion: einstellungen"}
        alt = self._einstellungen_lesen().get("werte") or {}
        try:
            werte = bruecke.einstellungen_pruefen(glied, alt, wunsch)
        except ValueError as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        status, _typ, stand = self._neu_post("/api/einstellungen", json.dumps(werte).encode("utf-8"))
        if status != 200:
            return status, "application/json", stand
        return self.bruecke_lesen(glied, kopf or {})
