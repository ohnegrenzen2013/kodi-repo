"""nuvio-usenet (nuvio_usenet.py): Stand des Hilfsprogramms, NZB pruefen, Dienst fuehren.

  GET  /api/nuvio_usenet                      da?, woher, Fassung, Anbieter, Dauerprozess
  POST /api/nuvio_usenet {aktion: "pruefen", nzb: "<xml>"}   Stand der NZB beim Anbieter
  POST /api/nuvio_usenet {aktion: "starten"}  Dauerprozess sicherstellen (fuer die Pruefung)
  POST /api/nuvio_usenet {aktion: "beenden"}  Dauerprozess beenden

Das Pruefen kostet Verbindungen beim Anbieter und benutzt dessen Zugangsdaten, darum steht
es in RECHT_FUER unter "downloads" - wie die uebrigen NZB-Aktionen. Kinderprofile kommen
ohnehin nicht an /api/-POSTs, die nicht ausdruecklich erlaubt sind.
"""

import json

from . import nuvio_usenet, nuvio_usenet_dienst

# Grenze fuer das NZB-Feld im JSON - dieselbe wie im Go-Teil (nzb.MaxBytes).
#
# Das ist eine **andere** Grenze als die des HTTP-Koerpers: die steht in
# `oberflaeche_grund.MAX_NZB_KOERPER` und wird in `stremio_grund` je Route gesetzt.
# `/api/nuvio_usenet` muss dort aufgefuehrt sein, sonst gilt `MAX_KOERPER` (64 KiB) und jede
# echte NZB wird mit 413 abgewiesen, **bevor** dieser Weg laeuft. Genau so war es: der Test
# ruft `app.bearbeite` im Prozess und sieht das Tor nicht.
MAX_NZB = 64 * 1024 * 1024


class NuvioUsenetMixin:
    def _nu_wurzel(self):
        return nuvio_usenet.wurzel()

    def _nu_datenordner(self):
        """Der Datenordner der App - dieselbe Quelle, die der Streamer benutzt.

        Muss dieselbe sein: der Ordner geht ueber `zwischenordner()` in die Kennung ein.
        Zwei Ableitungen hiessen zwei Kennungen, und dann halten sich der von hier und der
        vom Streamer gestartete Dienst gegenseitig fuer fremd.
        """
        return getattr(self.app, "datenordner", None)

    def _nu_daten(self):
        """Die Nutzerdaten, oder leer. Stand dreimal wortgleich da."""
        verwaltung = getattr(self.app, "verwaltung", None)
        return verwaltung.daten() if verwaltung is not None else {}

    def _nu_ordner(self):
        """Der Ordner fuer Zugangsdatei, Protokoll und Teildateien."""
        return self._nu_datenordner() or self._nu_wurzel()

    def nuvio_usenet_lesen(self):
        stand = nuvio_usenet.stand(self._nu_wurzel(), self._nu_datenordner())
        zugaenge = nuvio_usenet.zugaenge_aus_daten(self._nu_daten())
        # Nur die Zahl, niemals Host oder Zugangsdaten.
        stand["anbieter"] = len(zugaenge)
        stand["bereit"] = bool(stand["da"] and zugaenge)
        # Der Dauerprozess: nur nachsehen, nicht starten. Ein GET darf nichts anwerfen.
        #
        # **Mit** Kennung: ohne sie meldete diese Seite auch einen fremden Dienst (zweite
        # H0rSt-Instanz mit anderen Konten) oder einen veralteten (geaenderte Zugangsdaten)
        # als "laeuft, Fassung X" - genau das, wogegen 0.69.104 geschrieben wurde. Die
        # dritte Pruefstelle, die den Riegel zuerst nicht hatte.
        kennung = nuvio_usenet_dienst.konfig_kennung(
            zugaenge, nuvio_usenet.zwischenordner(self._nu_datenordner()))
        adresse, gemeldet = nuvio_usenet_dienst.laufender(kennung=kennung)
        stand["dienst_adresse"] = adresse or ""
        stand["dienst_fassung"] = (gemeldet or {}).get("fassung", "")
        stand["dienst_eigen"] = nuvio_usenet_dienst.laeuft()
        stand["leerlauf"] = nuvio_usenet_dienst.LEERLAUF
        return 200, "application/json", stand

    def _nu_starten(self):
        """Den Dauerprozess sicherstellen. Im Betrieb geschieht das von selbst beim ersten
        Stream; dieser Weg ist fuer die Einstellungsseite, damit man es vorher pruefen kann."""
        ordner = self._nu_ordner()
        try:
            adresse, gemeldet = nuvio_usenet_dienst.sicherstellen(
                self._nu_wurzel(), ordner, nuvio_usenet.zugaenge_aus_daten(self._nu_daten()),
                nuvio_usenet.zwischenordner(ordner))
        except Exception as fehler:  # noqa: BLE001 - jeder Startfehler ist eine Antwort, kein Absturz
            return 502, "application/json", {"fehler": str(fehler)}
        return 200, "application/json", {"dienst_adresse": adresse,
                                         "dienst_fassung": (gemeldet or {}).get("fassung", ""),
                                         "dienst_eigen": nuvio_usenet_dienst.laeuft()}

    def nuvio_usenet_post(self, koerper):
        try:
            wunsch = json.loads((koerper or b"").decode("utf-8") or "{}")
        except (ValueError, UnicodeDecodeError):
            return 400, "application/json", {"fehler": "JSON-Fehler"}
        if not isinstance(wunsch, dict):
            return 400, "application/json", {"fehler": "JSON-Objekt erwartet"}
        aktion = str(wunsch.get("aktion") or "")
        if aktion == "starten":
            return self._nu_starten()
        if aktion == "beenden":
            nuvio_usenet_dienst.beenden()
            return 200, "application/json", {"dienst_eigen": False, "dienst_adresse": ""}
        if aktion != "pruefen":
            return 400, "application/json", {"fehler": "aktion: pruefen, starten oder beenden"}
        nzb = wunsch.get("nzb") or ""
        if not isinstance(nzb, str):
            return 400, "application/json", {"fehler": "nzb muss Text sein"}
        if len(nzb.encode("utf-8", "replace")) > MAX_NZB:
            return 400, "application/json", {"fehler": "NZB zu gross"}

        ort = nuvio_usenet.finden(self._nu_wurzel(), self._nu_datenordner())
        if not ort["pfad"]:
            return 503, "application/json", {
                "fehler": "nuvio-usenet ist nicht vorhanden",
                "hinweis": " ".join(nuvio_usenet.bau_befehl())}
        try:
            stand = nuvio_usenet.pruefen(ort["pfad"], nzb,
                                         nuvio_usenet.zugaenge_aus_daten(self._nu_daten()),
                                         self._nu_ordner())
        except nuvio_usenet.NuvioUsenetFehler as fehler:
            return 502, "application/json", {"fehler": str(fehler)}
        except Exception as fehler:  # noqa: BLE001 - ein fremdes Programm darf H0rSt nicht kippen
            return 502, "application/json", {"fehler": "nuvio-usenet: %s" % fehler}
        return 200, "application/json", stand


# Einstellungsseite: nur Auskunft, keine Schalter - das Programm wird gefunden, nicht
# eingestellt. Die Anbieter stehen schon unter "Konten".
NUVIO_USENET_KATEGORIE = {
    "id": nuvio_usenet.SCHLUESSEL, "name": "nuvio-usenet", "symbol": nuvio_usenet.SYMBOL,
    "gruppe": "Verbindungen & Geräte",
    "beschreibung": "H0rSts eigener Usenet-Teil (Go, Quelle im Repo unter cmd/nuvio-usenet). "
                    "Prüft, wie viel einer NZB beim Anbieter noch liegt, und setzt Dateien aus "
                    "den Segmenten zusammen – ohne fremden Daemon. Das Programm wird gesucht, "
                    "nicht eingestellt: erst prebuilts/ im Repo, dann Datenordner und Suchpfad, "
                    "sonst selbst bauen (dafür braucht es Go und einen C-Compiler, weil der "
                    "yEnc-Teil eine C-Bibliothek ist – und eine Plattform, für die es sie gibt: "
                    "linux amd64/arm64, Windows amd64 und macOS. 32-Bit-ARM geht nicht, dort "
                    "bleiben die fremden Dienste). Die Anbieter kommen aus „Konten“ (NNTP), "
                    "es muss nichts doppelt eingetragen werden. Stand und Fassung zeigt "
                    "GET /api/nuvio_usenet.",
    "zeilen": [],
}
