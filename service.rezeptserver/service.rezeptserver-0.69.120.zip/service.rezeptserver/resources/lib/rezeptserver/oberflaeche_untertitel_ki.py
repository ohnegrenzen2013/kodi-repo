"""Untertitel uebersetzen lassen (untertitel_ki.py): eine zusaetzliche Spur fuer alle Clients.

  GET /api/untertitel/ki/<typ>/<stremio-id>/<nummer>/<sprache>.vtt

Der Aufrufer nennt **keine** Adresse, sondern die Nummer eines Untertitels aus H0rSts
eigener Liste zu diesem Titel. Die Liste wird hier neu berechnet und der Eintrag daraus
geholt - so kann niemand den Server als Abrufer fuer beliebige Adressen benutzen.

Die Uebersetzung laeuft ueber die KI, die der Nutzer ohnehin eingerichtet hat
(`ki_anbieter`, also Claude, ein OpenAI-kompatibler Dienst, Ollama oder llama.cpp).
Ohne eingerichtete KI gibt es die Spur gar nicht erst.
"""

import hashlib
import re
import urllib.request

from . import einstellungen, ki_anbieter, netz, sprachen, untertitel_ki
from .netz import USER_AGENT

AN = "untertitel_ki_an"
SPRACHE = "untertitel_ki_sprache"
# Nicht groesser als das, was untertitel_ki ueberhaupt annimmt - sonst laedt H0rSt eine
# Datei vollstaendig herunter, nur um sie danach abzulehnen.
MAX_DATEI = untertitel_ki.MAX_ZEICHEN
ZEITGRENZE = 30
# Was in der Spur steht, damit man sie in jedem Player erkennt.
MARKE = "KI"
# Sprachkennung, wie sie in der Adresse stehen darf (muss zu PFAD passen).
_SPRACHE = re.compile(r"^[A-Za-z]{2,3}(-[A-Za-z0-9]{2,8})?$")
# Kurze Pruefsumme der Vorlagen-Adresse: die Liste kann sich zwischen zwei Anfragen
# aendern (eine Quelle faellt aus), dann stimmt die blosse Nummer nicht mehr.
FINGER = 10
PFAD = re.compile(r"^/api/untertitel/ki/([a-z]+)/([^/]+)/(\d{1,3})-([0-9a-f]{%d})/([A-Za-z0-9-]{2,12})\.vtt$"
                  % FINGER)


def finger(url):
    """Kurze, stabile Kennung einer Untertitel-Adresse."""
    return hashlib.sha256(str(url or "").encode("utf-8", "replace")).hexdigest()[:FINGER]


def vorlagen(liste):
    """Die uebersetzbaren Funde - eigene KI-Spuren und leere Eintraege zaehlen nicht mit.

    Beide Seiten (Spurenliste und Abruf) muessen **dieselbe** Reihenfolge sehen, sonst
    zeigt eine Nummer auf den falschen Untertitel.
    """
    return [u for u in (liste or []) if u.get("url") and "/api/untertitel/ki/" not in u["url"]]


def sprache_gueltig(ziel):
    """Nur was auch durch die Route passt - sonst entstuende eine Spur, die immer 404 gibt."""
    return bool(_SPRACHE.match(str(ziel or "")))


def schalter(werte):
    """Ist die Uebersetzung eingeschaltet, und in welche Sprache?"""
    w = werte or {}
    ziel = str(w.get(SPRACHE) or "").strip()
    return {"an": bool(w.get(AN)), "sprache": ziel[:40]}


def ki_bereit(daten):
    """Ist ueberhaupt eine KI eingerichtet? Ohne sie waere jede Spur ein 502."""
    d = daten or {}
    modus = str(d.get("ki_modus") or "cloud")
    if modus == "cloud":
        return bool(d.get("ki_cloud_key") or d.get("claude_api_key"))
    if modus == "lokal":
        return bool(d.get("ki_lokal_url") or d.get("ki_lokal_backend"))
    return bool(d.get("ki_remote_url"))


def modellkennung(daten):
    """Welches Modell uebersetzt hat - gehoert in den Cache-Schluessel, sonst bleibt nach
    einem Anbieterwechsel die alte Uebersetzung stehen. Die echten Schluessel, nicht "ki_modell"."""
    d = daten or {}
    modus = str(d.get("ki_modus") or "")
    for schluessel in ("ki_cloud_modell", "ki_lokal_modell", "ki_remote_modell"):
        if d.get(schluessel):
            return "%s:%s" % (modus, d[schluessel])
    return modus


def zielsprache(werte, wunsch=()):
    """Die gewuenschte Zielsprache: Einstellung, sonst die erste Untertitelsprache."""
    s = schalter(werte)
    if s["sprache"]:
        return s["sprache"]
    return sprachen.normalisiere(wunsch[0]) if wunsch else ""


class UntertitelKiMixin:
    def untertitel_ki_pfad(self, pfad):
        """Zerlegt /api/untertitel/ki/<typ>/<id>/<nummer>-<finger>/<sprache>.vtt, sonst None."""
        treffer = PFAD.match(str(pfad or ""))
        if treffer is None:
            return None
        typ, sid, nummer, kennung, ziel = treffer.groups()
        return {"typ": typ, "sid": sid, "nummer": int(nummer), "finger": kennung, "sprache": ziel}

    def _untertitel_daten(self):
        """Die ganzen Nutzerdaten - dort stehen die KI-Schluessel (ki_modus, ki_cloud_*)."""
        verwaltung = getattr(self.app, "verwaltung", None)
        return verwaltung.daten() if verwaltung else {}

    def _untertitel_werte(self):
        """Die Einstellungswerte - dort stehen die Schalter dieses Moduls."""
        return einstellungen.werte(self._untertitel_daten())

    def _untertitel_holen(self, url):
        """Die Vorlage laden - ueber den gehaerteten Weg, nicht mit blossem urlopen.

        Die Adresse stammt zwar aus H0rSts eigener Liste, aber ein fremdes Addon darf sie
        fuellen. `netz.oeffentlich_oeffnen` prueft das Schema, schliesst private und
        Loopback-Adressen aus und folgt keiner Weiterleitung.
        """
        if not str(url or "").lower().startswith(("http://", "https://")):
            raise untertitel_ki.UntertitelKiFehler("Nur http(s) als Untertitelquelle")
        anfrage = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
        with netz.oeffentlich_oeffnen(anfrage, timeout=ZEITGRENZE) as antwort:
            roh = antwort.read(MAX_DATEI + 1)
        if len(roh) > MAX_DATEI:
            raise untertitel_ki.UntertitelKiFehler("Untertitel zu gross")
        return roh.decode("utf-8", "replace")

    def untertitel_ki_datei(self, pfad, kopf):
        wunsch = self.untertitel_ki_pfad(pfad)
        if wunsch is None:
            return 404, "text/plain", b""
        daten = self._untertitel_daten()
        if not schalter(einstellungen.werte(daten))["an"]:
            return 403, "application/json", {"fehler": "KI-Untertitel sind nicht eingeschaltet"}
        if not ki_bereit(daten):
            return 503, "application/json", {
                "fehler": "Kein KI-Anbieter eingerichtet",
                "hinweis": "Einstellungen → KI & Werkzeuge"}
        hole = getattr(self.app, "untertitel", None)
        if not callable(hole):
            return 404, "text/plain", b""
        liste = vorlagen((hole(wunsch["typ"], wunsch["sid"], kopf) or {}).get("subtitles"))
        vorlage = None
        # Erst an der Nummer, dann an der Pruefsumme: faellt zwischendurch eine Quelle aus,
        # verschiebt sich die Liste - die Pruefsumme findet den Untertitel trotzdem wieder.
        if wunsch["nummer"] < len(liste) and finger(liste[wunsch["nummer"]]["url"]) == wunsch["finger"]:
            vorlage = liste[wunsch["nummer"]]
        else:
            vorlage = next((u for u in liste if finger(u["url"]) == wunsch["finger"]), None)
        if vorlage is None:
            return 404, "application/json", {"fehler": "Diesen Untertitel gibt es nicht"}
        try:
            text = self._untertitel_holen(vorlage["url"])
            vtt = untertitel_ki.uebersetzen(
                text, wunsch["sprache"],
                lambda prompt: ki_anbieter.anfrage(prompt, daten),
                quelle=str(vorlage.get("lang") or ""),
                modell=modellkennung(daten),
                titel="%s %s" % (MARKE, wunsch["sprache"]))
        except untertitel_ki.UntertitelKiFehler as fehler:
            return 502, "application/json", {"fehler": str(fehler)}
        except Exception as fehler:  # noqa: BLE001 - eine Quelle darf den Server nicht kippen
            return 502, "application/json", {"fehler": "Untertitel nicht erreichbar: %s" % fehler}
        return 200, "text/vtt; charset=utf-8", vtt.encode("utf-8")


def spuren(liste, basis, werte, wunsch=(), typ="", sid="", daten=None):
    """Je vorhandenem Untertitel eine KI-Spur anbieten - oder nichts, wenn es aus ist.

    Wird aus `stremio_addon.untertitel()` gerufen, damit **alle** Clients des Verbunds
    die Spur sehen: NuvioTV, Nuvio Mobile und ARVIO ueber das Addon, H0rSt im eigenen Player.
    Die Nummerierung laeuft ueber `vorlagen()` - genau die Liste, die der Abruf auch sieht.
    """
    ziel = zielsprache(werte, wunsch)
    if not schalter(werte)["an"] or not basis or not typ or not sid:
        return []
    if daten is not None and not ki_bereit(daten):
        # Ohne eingerichtete KI gaebe jede Spur nur einen Fehler - dann lieber keine.
        return []
    if not sprache_gueltig(ziel):
        # Freitext wie "Deutsch (DE)" passt nicht durch die Route; eine Spur, die immer
        # 404 gibt, ist schlechter als gar keine.
        return []
    neu = []
    for nummer, u in enumerate(vorlagen(liste)):
        if sprachen.normalisiere(u.get("lang")) == sprachen.normalisiere(ziel):
            continue  # schon in der Zielsprache
        neu.append({
            "id": "ki-%d" % nummer,
            "url": "%sapi/untertitel/ki/%s/%s/%d-%s/%s.vtt"
                   % (basis, typ, sid, nummer, finger(u["url"]), ziel),
            "lang": sprachen.drei(sprachen.normalisiere(ziel)) or ziel,
            "name": "%s %s" % (MARKE, ziel),
        })
    return neu
