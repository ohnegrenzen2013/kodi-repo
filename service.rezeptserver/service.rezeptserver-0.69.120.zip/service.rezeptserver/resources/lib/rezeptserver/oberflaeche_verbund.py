"""Verbund (verbund.py): H0rSt und seine Clients als ein Geraet.

  GET  /api/verbund                                  Stand: Kern, Teile, Faehigkeiten, Geraete
  GET  /api/verbund?kennung=…&nach=N&warten=S        Glied: Auftraege abholen (lange Anfrage)
  POST /api/verbund {aktion: "anmelden", teil, name?, version?, kennung?}
  POST /api/verbund {aktion: "abmelden", kennung}
  POST /api/verbund {aktion: "auftrag", kennung, art, …}  einem Glied etwas auftragen
"""

import json

from . import bruecke, verbund


class VerbundMixin:
    def _verbund_basis(self, kopf):
        """Eigene Adresse samt Token-Praefix, so wie der Client sie erreicht."""
        eigene = getattr(self.app, "eigene_basis", None)
        return (eigene(kopf or {}) or "") if callable(eigene) else ""

    def verbund_lesen(self, kopf, werte=None):
        """Ohne kennung der Stand; mit kennung holt ein Glied seine Auftraege ab."""
        kennung = str((werte or {}).get("kennung") or "")
        if kennung:
            try:
                return 200, "application/json", verbund.auftraege(
                    kennung, (werte or {}).get("nach"), (werte or {}).get("warten") or verbund.WARTEN)
            except ValueError as fehler:
                return 404, "application/json", {"fehler": str(fehler)}
        return 200, "application/json", verbund.stand(self._verbund_basis(kopf))

    def verbund_post(self, koerper, kopf):
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
        except (ValueError, UnicodeDecodeError):
            return 400, "application/json", {"fehler": "JSON-Fehler"}
        if not isinstance(wunsch, dict):
            return 400, "application/json", {"fehler": "JSON-Objekt erwartet"}
        aktion = str(wunsch.get("aktion") or "")
        if aktion == "anmelden":
            # Ein abgedocktes Glied (Schalter <glied>_an) meldet sich nicht an.
            gewollt = str(wunsch.get("teil") or "")
            if gewollt in bruecke.BEDIENT:
                werte = self._einstellungen_lesen().get("werte") or {}
                if not bruecke.schalter(gewollt, werte)["an"]:
                    return 403, "application/json", {"fehler": "Modul ist abgedockt"}
            try:
                kennung = verbund.anmelden(wunsch)
            except ValueError as fehler:
                return 400, "application/json", {"fehler": str(fehler)}
            antwort = verbund.stand(self._verbund_basis(kopf))
            antwort["kennung"] = kennung
            return 200, "application/json", antwort
        if aktion == "abmelden":
            verbund.abmelden(wunsch.get("kennung"))
            return self.verbund_lesen(kopf)
        if aktion == "auftrag":
            try:
                nummer = verbund.auftrag_geben(wunsch.get("kennung"), wunsch)
            except ValueError as fehler:
                return 400, "application/json", {"fehler": str(fehler)}
            antwort = verbund.stand(self._verbund_basis(kopf))
            antwort["auftrag"] = nummer
            return 200, "application/json", antwort
        return 400, "application/json", {"fehler": "aktion: anmelden, abmelden oder auftrag"}
