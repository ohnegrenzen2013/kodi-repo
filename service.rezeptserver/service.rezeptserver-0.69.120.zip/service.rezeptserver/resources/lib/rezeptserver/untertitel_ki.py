"""Untertitel uebersetzen, ohne die Zeiten anzufassen.

Die einzige echte Funktionsluecke der vier Teile war ARVIOs Live-KI-Untertitel: der laufende
Ton wird uebersetzt, waehrend man schaut. Das ist der teuerste Weg zum Ziel - es braucht einen
Dauerstrom zum Anbieter, ein Latenzbudget und Tonzugriff im Player.

Hier steht der guenstige Weg, der fuer fast alle Titel reicht: H0rSt findet ohnehin schon
Untertitel (eigene Rezepte, Addons, SUBSOURCE/SUBDL). Liegt einer in **irgendeiner** Sprache
vor, wird er **einmal** uebersetzt und als zusaetzliche Spur angeboten. Kein Ton, keine
Latenz, ein Bruchteil der Aufrufe - und weil es ueber das Addon-Protokoll laeuft, haben alle
vier Teile des Verbunds etwas davon, nicht nur H0rSts eigener Player.

Die Zeiten der Vorlage bleiben **unberuehrt**: uebersetzt wird nur Text. Antwortet das Modell
mit der falschen Anzahl Zeilen, bleibt dieses Haeppchen im Original stehen - lieber eine
unuebersetzte Stelle als verschobene Untertitel.

Nicht unterstuetzt: .ass/.ssa (Formatierungsbefehle im Text). Die bleiben, wie sie sind.
"""

import hashlib
import re
import threading

SCHLUESSEL = "untertitel_ki"

# Grenzen, damit ein grosser Fund nicht den Server oder den KI-Schluessel aufbraucht.
MAX_ZEICHEN = 512 * 1024
MAX_ZEILEN = 3000
HAEPPCHEN_ZEICHEN = 2500
MAX_HAEPPCHEN = 60
MAX_CACHE = 20

_ZEIT = re.compile(
    r"(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})\s*-->\s*(\d{1,2}):(\d{2}):(\d{2})[,.](\d{1,3})")
_sperre = threading.Lock()
_cache = {}  # schluessel -> vtt-Text


class UntertitelKiFehler(ValueError):
    pass


def _ms(stunde, minute, sekunde, rest):
    return ((int(stunde) * 60 + int(minute)) * 60 + int(sekunde)) * 1000 + int(rest.ljust(3, "0"))


def _zeitstempel(ms):
    ms = max(0, int(ms))
    sekunden, rest = divmod(ms, 1000)
    minuten, sekunde = divmod(sekunden, 60)
    stunde, minute = divmod(minuten, 60)
    return "%02d:%02d:%02d.%03d" % (stunde, minute, sekunde, rest)


def parsen(text):
    """SRT oder VTT in Bloecke zerlegen: [{von, bis, zeilen}]. Unbekanntes ergibt []."""
    roh = str(text or "")
    if len(roh) > MAX_ZEICHEN:
        raise UntertitelKiFehler("Untertitel zu gross")
    roh = roh.replace("\r\n", "\n").replace("\r", "\n").lstrip("﻿")
    bloecke = []
    for stueck in re.split(r"\n\s*\n", roh):
        zeilen = [z for z in stueck.split("\n") if z.strip() != ""]
        if not zeilen:
            continue
        # Eine Kennungszeile davor ueberspringen: SRT nummeriert, WebVTT erlaubt dort
        # **jeden** Text ("intro", "cue-7"). Nur auf Ziffern zu pruefen hat benannte
        # Bloecke stillschweigend verschluckt.
        if len(zeilen) > 1 and not _ZEIT.search(zeilen[0]) and _ZEIT.search(zeilen[1]):
            zeilen = zeilen[1:]
        treffer = _ZEIT.search(zeilen[0]) if zeilen else None
        if treffer is None:
            continue
        inhalt = [z for z in zeilen[1:] if z.strip() != ""]
        if not inhalt:
            continue
        g = treffer.groups()
        bloecke.append({"von": _ms(*g[:4]), "bis": _ms(*g[4:]), "zeilen": inhalt})
        if len(bloecke) > MAX_ZEILEN:
            raise UntertitelKiFehler("Zu viele Untertitelzeilen")
    return bloecke


def als_vtt(bloecke, titel=""):
    """Bloecke als WebVTT - das Format, das jeder der vier Clients versteht."""
    teile = ["WEBVTT" + (" - " + str(titel)[:80] if titel else ""), ""]
    for b in bloecke:
        teile.append("%s --> %s" % (_zeitstempel(b["von"]), _zeitstempel(b["bis"])))
        teile.extend(b["zeilen"])
        teile.append("")
    return "\n".join(teile)


def haeppchen(bloecke, grenze=HAEPPCHEN_ZEICHEN):
    """Bloecke in Portionen teilen, die in eine Anfrage passen."""
    portionen, laufend, zeichen = [], [], 0
    for b in bloecke:
        laenge = sum(len(z) + 1 for z in b["zeilen"])
        if laufend and zeichen + laenge > grenze:
            portionen.append(laufend)
            laufend, zeichen = [], 0
        laufend.append(b)
        zeichen += laenge
    if laufend:
        portionen.append(laufend)
    return portionen


def _prompt(portion, ziel, quelle=""):
    """Eine nummerierte Liste rein, dieselbe nummerierte Liste uebersetzt raus."""
    zeilen = ["%d. %s" % (n + 1, " / ".join(b["zeilen"])) for n, b in enumerate(portion)]
    woher = (" aus dem %s" % quelle) if quelle else ""
    return (
        "Uebersetze die folgenden %d Untertitelzeilen%s ins %s.\n"
        "Regeln:\n"
        "- Gib genau %d Zeilen zurueck, jede mit ihrer Nummer und einem Punkt davor.\n"
        "- Keine Erklaerungen, keine Anrede, keine leeren Zeilen, keine zusaetzlichen Nummern.\n"
        "- Mehrere Sprecher in einer Zeile sind mit ' / ' getrennt; behalte die Trennung bei.\n"
        "- Uebersetze natuerlich und knapp, so lang wie das Original.\n\n%s"
        % (len(portion), woher, ziel, len(portion), "\n".join(zeilen))
    )


def _antwort_zerlegen(text, anzahl):
    """Die nummerierte Antwort zurueckzuordnen. None, wenn sie nicht genau passt.

    Streng in beide Richtungen: zu wenige Zeilen sind ein Fehler, zu viele aber auch.
    Nummeriert ein Modell ueber die Anzahl hinaus, hat es meist eine Zeile aufgeteilt -
    dann passt ab dort jeder Text zur falschen Zeit, und das faellt niemandem auf.
    """
    gefunden = {}
    for zeile in str(text or "").replace("\r", "").split("\n"):
        treffer = re.match(r"\s*(\d{1,4})\s*[.)]\s*(.+?)\s*$", zeile)
        if treffer:
            nummer = int(treffer.group(1))
            if nummer > anzahl or nummer < 1 or nummer in gefunden:
                # Zu gross, zu klein oder doppelt: das Modell hat sich verzaehlt, und ab
                # dort passt der Text zur falschen Zeit. Lieber das Original behalten.
                return None
            gefunden[nummer] = treffer.group(2)
    if len(gefunden) != anzahl:
        return None
    return [gefunden[n] for n in range(1, anzahl + 1)]


def _uebernehmen(portion, uebersetzt):
    """Text ersetzen, Zeiten behalten. Die ' / '-Trennung wird zurueckgebaut."""
    neu = []
    for b, text in zip(portion, uebersetzt):
        zeilen = [t.strip() for t in str(text).split(" / ") if t.strip()]
        neu.append(dict(b, zeilen=zeilen or b["zeilen"]))
    return neu


def _schluessel(text, ziel, modell):
    roh = "%s|%s|%s" % (ziel, modell, text)
    return hashlib.sha256(roh.encode("utf-8", "replace")).hexdigest()


def gemerkt(text, ziel, modell=""):
    """Schon uebersetzt? Liefert den fertigen VTT-Text oder None."""
    with _sperre:
        return _cache.get(_schluessel(text, ziel, modell))


def merken(text, ziel, vtt, modell=""):
    with _sperre:
        if len(_cache) >= MAX_CACHE:
            _cache.pop(next(iter(_cache)))
        _cache[_schluessel(text, ziel, modell)] = vtt


def leeren():
    with _sperre:
        _cache.clear()


def uebersetzen(text, ziel, anfrage, quelle="", modell="", titel="", grenze=HAEPPCHEN_ZEICHEN):
    """Untertitel uebersetzen und als WebVTT zurueckgeben.

    `anfrage(prompt) -> str` ist der KI-Aufruf (in H0rSt: ki_anbieter.anfrage mit der
    Konfiguration des Nutzers). Jedes Haeppchen steht fuer sich: faellt eines aus, bleibt
    genau dieses im Original - die uebrigen sind trotzdem uebersetzt. `grenze` ist die
    Portionsgroesse in Zeichen; kleiner heisst mehr, dafuer kuerzere Anfragen.
    """
    ziel = str(ziel or "").strip()
    if not ziel:
        raise UntertitelKiFehler("Keine Zielsprache")
    fertig = gemerkt(text, ziel, modell)
    if fertig is not None:
        return fertig
    bloecke = parsen(text)
    if not bloecke:
        raise UntertitelKiFehler("Keine Untertitelzeilen gefunden")
    portionen = haeppchen(bloecke, grenze)
    if len(portionen) > MAX_HAEPPCHEN:
        raise UntertitelKiFehler("Untertitel zu lang fuer die Uebersetzung")
    ergebnis, offen = [], 0
    for portion in portionen:
        try:
            antwort = anfrage(_prompt(portion, ziel, quelle))
            zeilen = _antwort_zerlegen(antwort, len(portion))
        except Exception:  # noqa: BLE001 - ein Haeppchen darf den ganzen Lauf nicht kippen
            zeilen = None
        if zeilen is None:
            offen += 1
            ergebnis.extend(portion)
        else:
            ergebnis.extend(_uebernehmen(portion, zeilen))
    if offen == len(portionen):
        raise UntertitelKiFehler("Uebersetzung fehlgeschlagen")
    vtt = als_vtt(ergebnis, titel)
    merken(text, ziel, vtt, modell)
    return vtt
