"""KernMixin-Mixin
"""

from . import debrid_bibliothek
from .oberflaeche_grund import (
    BADGE_BEISPIELE,
    LOGO,
    NetzFehler,
    SEITE,
    __version__,
    assistent,
    collections,
    ed2k,
    kodi_player,
    parse_qs,
    schrift,
    threading,
    unquote,
    verweise,
    vorlagen,
    xdcc,
    youtube,
)
from . import youtube_quellen
from .oberflaeche_kern_post import KernPostMixin

class KernMixin(KernPostMixin):

    # --- Eigenes Hintergrundbild ----------------------------------------------
    HINTERGRUND_TYPEN = {b"\xff\xd8\xff": ".jpg", b"\x89PNG": ".png", b"RIFF": ".webp", b"GIF8": ".gif"}
    def __init__(self, app):
        self.app = app
        self._bilder = {}
        self._wiedergaben = collections.OrderedDict()
        self._hls = collections.OrderedDict()  # HLS ueber den Server: {schluessel: (kopf, hosts, zeit)}
        self._hls_js = None
        self._sperre = threading.Lock()
        self._vx = {}

    def _bildname(self, pfad, profil_id=None):
        """Profilbild je Profil (avatar-<id>), sonst das gemeinsame."""
        name = pfad.rsplit("/", 1)[1]
        if name != "avatar":
            return name
        import re as _re
        if profil_id and _re.match(r"^[a-z0-9]{1,20}$", profil_id):
            return "avatar-" + profil_id
        ich = self.aktuelles_profil()
        return "avatar-" + ich["id"] if ich else "avatar"

    # --- Routing ----------------------------------------------------------
    def bearbeite(self, pfad, abfrage, methode, koerper, kopf):
        """Aeussere Huelle: Profil bestimmen, Kinderprofile begrenzen (kinder.py) und deren Antworten nach Alter filtern."""
        werte = {k: v[0] for k, v in parse_qs(abfrage).items()}
        self.profil_ermitteln(kopf, werte)
        gesperrt = self.kind_pruefen(pfad, methode, werte, koerper)
        if gesperrt:
            return gesperrt
        return self.kind_filtern(self._bearbeite_roh(pfad, abfrage, methode, koerper, kopf))

    def _bearbeite_roh(self, pfad, abfrage, methode, koerper, kopf):
        werte = {k: v[0] for k, v in parse_qs(abfrage).items()}
        # Profil der Anfrage (X-Profil) und seine Rechte (profile.py)
        self.profil_ermitteln(kopf, werte)
        verbot = self.recht_fehlt(pfad, methode)
        if verbot:
            return 403, "application/json", {"fehler": verbot, "recht": True}
        if methode == "POST":
            if kopf.get("X-Rezeptserver") != "1":
                return 403, "application/json", {"fehler": "Header X-Rezeptserver fehlt"}
            return self._post_route(pfad, koerper, kopf, werte)
        if methode != "GET":
            return 405, "application/json", {"fehler": "Methode nicht erlaubt"}
        if pfad in ("/", ""):
            return 200, "text/html", SEITE.replace("{{VERSION}}", __version__)
        if pfad == "/api/fehler" or pfad.startswith("/api/fehler/"):
            return self.fehler_lesen(pfad, werte)
        if pfad == "/api/kodiaddons" or pfad.startswith("/api/kodiaddons/"):
            return self.kodiaddons_lesen(pfad, werte)
        if pfad == "/api/speicher":
            return self.speicher_lesen(werte)
        if pfad == "/api/start":
            return 200, "application/json", self.start_lesen(kopf)
        if pfad == "/api/easynews" or pfad.startswith("/api/easynews/"):
            return self.easynews_lesen(pfad, werte)
        if pfad == "/api/usenet-stream" or pfad.startswith("/api/usenet-stream/"):
            return self.usenet_stream_lesen(pfad, werte, kopf)
        if pfad in ("/api/hintergrund", "/api/avatar"):  # eigenes Hintergrundbild, Profilbild (je Profil)
            datei = self._hintergrund_datei(self._bildname(pfad, werte.get("profil")))
            return ("lokal", datei) if datei else (404, "application/json", {"fehler": "kein eigenes Bild"})
        if pfad == "/api/kameras" or pfad.startswith("/api/kameras/"):
            return self.kameras_lesen(pfad, werte)
        if pfad in ("/api/hue", "/api/hue/suchen"):
            return self.hue_lesen(pfad)
        if pfad in ("/api/chat/raeume", "/api/chat/abholen"):
            return self.chat_lesen(pfad, werte)
        if pfad in ("/api/cast", "/api/cast/suchen"):
            return self.cast_lesen(pfad, werte)
        if pfad == "/api/baukasten":
            return self.baukasten_lesen()
        if pfad == "/api/brause":
            return self.brause_lesen()
        if pfad == "/brause/start":
            return self.brause_start_seite()
        if pfad == "/brause/gx":
            return self.brause_gx_seite()
        if pfad == "/api/vorschlaege":
            return self.vorschlaege_lesen()
        if pfad == "/api/mcp":
            return self.mcp_lesen()
        if pfad == "/api/mcp/server":
            return self.mcp_server_lesen()
        if pfad == "/api/markenerkennung":
            return self.markenerkennung_lesen()
        if pfad == "/api/komplettbackup":
            return self.komplettbackup_lesen()
        if pfad == "/api/nuvio_plugins":
            return self.nuvio_plugins_lesen()
        if pfad == "/api/geraete_abgleich":
            return self.geraete_abgleich_lesen()
        if pfad == "/api/understand_anything":
            return self.understand_anything_lesen()
        if pfad == "/api/sehen":
            return self.sehen_lesen()
        if pfad == "/api/kalender":
            return self.kalender_lesen(werte)
        if pfad == "/api/benachrichtigungen":
            return self.benachrichtigungen_lesen()
        if pfad == "/api/usenet/urteile":
            return self.usenet_urteile_lesen(werte)
        if pfad == "/api/marken":
            return self.marken_lesen(werte)
        if pfad == "/api/simkl":
            return self.simkl_lesen()
        if pfad == "/api/nuvio":
            return self.nuvio_lesen(kopf)
        if pfad == "/api/anime-tracker":
            return self.anime_tracker_lesen()
        if pfad == "/api/traum" or pfad.startswith("/api/traum/"):
            return self.traum_lesen(pfad, werte)
        if pfad == "/api/portal" or pfad.startswith("/api/portal/"):
            return self.portal_lesen(pfad, werte)
        if pfad == "/api/usb":
            return self.usb_lesen()
        if pfad in ("/api/radio", "/api/radio/suche", "/api/radio/strom"):
            return self.radio_lesen(pfad, werte)
        if pfad in ("/api/startanimation", "/api/startanimation/info"):
            return self.startanimation_lesen(pfad)
        if pfad == "/api/web":
            return 200, "application/json", self.web_zustand()
        if pfad == "/api/assistent":
            return 200, "application/json", assistent.baum(self.app.verwaltung.module if self.app.verwaltung else ())
        if pfad == "/api/verweise":
            daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
            return 200, "application/json", {"probleme": verweise.pruefen(daten, self._eingebaut(daten) if self.app.verwaltung else ())}
        if pfad == "/api/module/status":
            return self.modul_status_lesen()
        if pfad == "/api/menue":
            return self.menue_lesen()
        if pfad == "/api/tresor" or pfad == "/api/tresor/liste":
            return self.tresor_lesen(pfad, werte)
        if pfad == "/api/linkreiniger":
            return self.linkreiniger_lesen()
        if pfad in ("/api/spotweb-tools", "/api/usenet-tools"):
            return self.usenet_tools_lesen()
        if pfad == "/api/usb-tools":
            return self.usb_tools_lesen()
        if pfad == "/api/gnunet-tools":
            return self.gnunet_tools_lesen()
        if pfad == "/api/befehl":  # Sprachbefehle per Webhook (Home Assistant, IFTTT -> Google Home)
            return self.befehl_ausfuehren(werte)
        if pfad == "/api/filter":
            return 200, "application/json", self.filter_lesen()
        if pfad == "/api/livetv":
            return 200, "application/json", self.livetv_lesen()
        if pfad == "/api/livetv/jetzt":
            return 200, "application/json", self.jetzt_lesen()
        if pfad == "/api/livetv/guide":
            return 200, "application/json", self.guide_lesen(werte.get("id", ""), werte.get("archiv") == "1")
        if pfad == "/api/livetv/raster":
            return self.raster_lesen(werte.get("ids", ""), werte.get("von", ""), werte.get("bis", ""))
        if pfad == "/api/livetv/archiv":
            return 200, "application/json", self.archiv_lesen(werte.get("id", ""), werte.get("beginn", ""), werte.get("ende", ""))
        if pfad == "/api/livetv/stalker":
            return self.stalker_lesen(werte)
        if pfad == "/api/livetv/sport":
            return self.livetv_sport_lesen(werte)
        if pfad == "/api/livetv/sehen":
            return self.livetv_sehen_lesen()
        if pfad == "/api/links":
            return 200, "application/json", self.links_lesen()
        if pfad == "/api/community-addons":
            return self.community_addons_lesen(werte)
        if pfad == "/api/anbieter":
            return self._verwaltet(self.anbieter_lesen)
        if pfad == "/api/anbieter/export":
            return self._verwaltet(lambda: vorlagen.ausgeben(self.app.verwaltung.daten(), werte.get("geheim") == "1"))
        if pfad == "/api/vx":
            return self._verwaltet(self.vx_lesen)
        if pfad == "/api/debrid":
            return 200, "application/json", self.debrid_lesen()
        if pfad == "/api/debrid/cloud":
            return self.debrid_cloud_lesen(werte)
        if pfad == "/api/debrid/bibliothek":
            try:
                return 200, "application/json", self.debrid_bibliothek_lesen(werte)
            except (ValueError, debrid_bibliothek.DebridFehler, NetzFehler) as fehler:
                return 400, "application/json", {"fehler": str(fehler)}
        if pfad == "/api/rustnzb":
            return 200, "application/json", self.rustnzb_lesen()
        if pfad == "/api/usenet/urteile":
            return 200, "application/json", self.app.usenet_urteile_lesen(werte)
        if pfad == "/api/dienste" or pfad.startswith("/api/dienste/"):
            return self.dienste_lesen(pfad, werte)
        if pfad == "/api/ab18/lesezeichen":
            return self.lesezeichen_lesen(kopf)
        if pfad == "/api/ab18" or pfad.startswith("/api/ab18/"):
            return self.ab18_lesen(pfad, werte, kopf)
        if pfad == "/api/suche_global":
            return self.suche_global_lesen(werte, kopf)
        if pfad == "/api/sicherheit":
            return self._verwaltet(self.sicherheit_lesen)
        if pfad == "/api/afwall" or pfad.startswith("/api/afwall/"):
            return self.afwall_lesen(pfad)
        if pfad == "/api/kodi":
            return self._kodi(lambda: self.kodi_lesen(werte.get("geraet", "")))
        if pfad == "/api/badges":
            return 200, "application/json", dict(self.app.badges.zustand(),
                                                 beispiele=[{"text": t, "badges": self.app.badges.zuordnen(t)} for t in BADGE_BEISPIELE])
        if pfad == "/api/badges/test":
            return 200, "application/json", {"badges": self.app.badges.zuordnen(werte.get("text", "")[:300])}
        if pfad == "/api/waechter":
            return 200, "application/json", self.app.waechter.zustand()
        if pfad == "/api/beobachtungen":
            return 200, "application/json", self.beobachtungen_lesen()
        if pfad == "/api/wiedergabe-check":
            return self.wiedergabe_check_lesen()
        if pfad == "/api/szene" or pfad.startswith("/api/szene/") or pfad == "/api/ofdb":
            return self.szene_lesen(pfad, werte)
        if pfad == "/api/musik" or pfad.startswith("/api/musik/"):
            return self.musik_lesen(pfad, werte)
        if pfad == "/api/youtube":
            from .ab18 import resolver
            return 200, "application/json", {"einstellung": self.app.youtube.einstellung, "ytdlp": resolver.have_resolver(),
                                                 "api_schluessel": bool(youtube_quellen.schluessel(self.app.verwaltung.daten() if self.app.verwaltung else {}))}
        if pfad == "/api/youtube/downloads":
            return 200, "application/json", self.app.youtube_speichern.zustand()
        if pfad.startswith("/api/youtube/datei/"):
            try:
                return "lokal", self.app.youtube_speichern.pfad(unquote(pfad[len("/api/youtube/datei/"):]))
            except youtube.YoutubeFehler as fehler:
                return 404, "application/json", {"fehler": str(fehler)}
        if pfad in ("/api/youtube/suche", "/api/youtube/feed"):
            try:
                if pfad.endswith("feed"):
                    return 200, "application/json", self.app.youtube.feed()
                daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
                schluessel = youtube_quellen.schluessel(daten)
                if schluessel:  # eigener YouTube-Data-API-Schluessel (nur hier im Server)
                    return 200, "application/json", {"videos": youtube_quellen.suchen_api(werte.get("q", ""), schluessel, self.app.youtube.holen), "quelle": "api"}
                try:
                    return 200, "application/json", {"videos": self.app.youtube.suchen(werte.get("q", "")), "quelle": "ytdlp"}
                except youtube.YoutubeFehler as fehler:
                    if "yt-dlp" in str(fehler):
                        raise youtube.YoutubeFehler(str(fehler) + ". Alternative: eigenen YouTube-Data-API-Schlüssel unter Einstellungen → Konten → Eigene YouTube-Reihen eintragen.")
                    raise
            except (youtube.YoutubeFehler, youtube_quellen.QuellenFehler, OSError) as fehler:
                return 400, "application/json", {"fehler": str(fehler)}
        if pfad in ("/api/einstellungen", "/api/telegram", "/api/heimspeicher", "/api/heimspeicher/liste",
                    "/api/heimspeicher/crawl", "/api/dht", "/api/ed2k/suche", "/api/ftpserver", "/api/aktualisierung") \
                or pfad.startswith(("/api/dateisuche/", "/api/aktualisierung/sicherung/", "/api/aktualisierung/app")):
            return self._neu_get(pfad, werte)
        if pfad == "/api/ed2k":
            return 200, "application/json", self.ed2k_lesen(werte.get("ember") == "1")
        if pfad in ("/api/ed2k/listen", "/api/ed2k/server.met", "/api/ed2k/nodes.dat", "/api/ipfilter", "/api/ipfilter/ipfilter.dat"):
            return self.listen_lesen(pfad)
        if pfad in ("/api/anonym", "/api/anonym/release"):
            return self.anonym_lesen(pfad, werte)
        if pfad in ("/api/daumenkino", "/api/daumenkino/projekt", "/api/party"):
            return self.party_lesen(pfad, werte)
        if pfad == "/api/gemeinsam":
            return self.gemeinsam_lesen(werte)
        if pfad in ("/api/fernsteuerung", "/api/fernsteuerung/qr.svg"):
            return self.fernsteuerung_lesen(pfad, werte)
        if pfad in ("/api/kataloge", "/api/katalog"):
            return self.kataloge_lesen(pfad, werte)
        if pfad == "/api/sammlungen":
            return self.sammlungen_lesen(werte)
        if pfad == "/api/reihen":
            return self.reihen_lesen()
        if pfad == "/api/poster":
            return self.poster_lesen()
        if pfad == "/api/trailer":
            return self.trailer_lesen(werte)
        if pfad == "/api/trakt":
            return self.trakt_lesen()
        if pfad == "/api/trakt/kalender":
            return 200, "application/json", self.app.trakt.kalender(self._trakt_profil(), werte.get("tage", 30))
        if pfad == "/api/folgen/bewertung":
            from . import folgen_wertung
            return 200, "application/json", folgen_wertung.fuer_app(self.app, werte)
        if pfad == "/api/dank":
            return self.dank_lesen()
        if pfad == "/api/magicwx":
            return self.magicwx_lesen()
        if pfad == "/api/shizuku":
            return self.shizuku_lesen()
        if pfad == "/api/keepadb":
            return self.keepadb_lesen()
        if pfad == "/api/bilddatensatz":
            return self.bilddatensatz_lesen()
        if pfad in ("/api/brillen", "/api/autostart"):
            return self.brillen_lesen(pfad)
        if pfad in ("/api/gdrive", "/api/gdrive/sicherungen"):
            return self.gdrive_lesen(pfad)
        if pfad in ("/api/appstore", "/api/appstore/suche", "/api/appstore/app", "/api/appstore/repo",
                    "/api/appstore/datei", "/api/appstore/matrix"):
            return self.appstore_lesen(pfad, werte)
        if pfad == "/api/uniqx/analyse":
            return self.uniqx_lesen(werte)
        if pfad == "/api/uniqx/ki_status":
            return self.uniqx_ki_status()
        if pfad == "/api/uniqx/ollama_installieren":
            return self.uniqx_ollama_installieren_lesen()
        if pfad == "/api/uniqx/ollama_modell_holen":
            return self.uniqx_ollama_modell_lesen()
        if pfad == "/api/uniqx/ollama_empfehlung":
            return self.uniqx_ollama_empfehlung_lesen(werte)
        if pfad == "/api/ember/steuerung":
            return self.ember_lesen()
        if pfad == "/api/emuleese":
            return self.emuleese_lesen()
        if pfad == "/api/aiostreams":
            return self.aiostreams_lesen()
        if pfad == "/api/iptvquellen":
            return self.iptvquellen_lesen()
        if pfad == "/api/ed2knetz":
            return self.ed2knetz_lesen()
        if pfad == "/api/kodiquellen":
            return self.kodiquellen_lesen()
        if pfad == "/api/lbry":
            return self.lbry_lesen()
        if pfad == "/api/ipvpn":
            return self.ipvpn_lesen()
        if pfad == "/api/discord":
            return self.discord_lesen()
        if pfad == "/api/qwen-pose":
            return self.qwen_pose_lesen(werte)
        if pfad.startswith("/api/qwen-pose/bild/"):
            return self.qwen_pose_bild(unquote(pfad[len("/api/qwen-pose/bild/"):]))
        if pfad == "/api/videowerkstatt":
            return self.videowerkstatt_lesen(werte)
        if pfad.startswith("/api/videowerkstatt/datei/"):
            return self.videowerkstatt_datei(unquote(pfad[len("/api/videowerkstatt/datei/"):]))
        if pfad == "/api/profile":
            return self.profile_lesen()
        if pfad == "/api/admin":
            return self.admin_lesen()
        if pfad in ("/api/dateien", "/api/dateien/liste", "/api/dateien/datei"):
            return self.dateien_lesen(pfad, werte)
        if pfad in ("/api/omnisearch", "/api/omnisearch/suche", "/api/omnisearch/duplikate"):
            return self.omnisearch_lesen(pfad, werte)
        if pfad == "/api/downloads":
            return self.downloads_lesen()
        if pfad == "/api/cloudstream":
            return self.cloudstream_lesen()
        if pfad == "/api/downloads/datei":
            return self.downloads_datei(werte)
        if pfad.startswith("/api/untertitel/"):
            return self.untertitel_datei(pfad.rsplit("/", 1)[-1])
        if pfad == "/api/ed2k/sammlung.emulecollection":
            return 200, "text/plain", ed2k.sammlung(self._ed2k_links())
        if pfad == "/api/xdcc":
            daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
            return 200, "application/json", dict(self.app.xdcc.zustand(), eigene=xdcc.eigene_pruefe(daten))
        if pfad == "/api/xdcc/suche":
            quellen = [q for q in werte.get("quellen", "").split(",") if q] or None
            daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
            eigene = xdcc.eigene_pruefe(daten)
            namen = dict(xdcc.QUELLEN, **{"eigen:" + e["id"]: e["name"] for e in eigene})
            try:
                treffer, stand = xdcc.suchen_alle(werte.get("q", ""), quellen=quellen, eigene=eigene)
            except (xdcc.XdccFehler, OSError) as fehler:
                return 400, "application/json", {"fehler": str(fehler)}
            for t in treffer:
                t["badges"] = self.app.badges.zuordnen(t["name"])
            return 200, "application/json", {"treffer": treffer, "quellen": {namen.get(q, q): w for q, w in stand.items()}}
        if pfad.startswith("/api/xdcc/datei/"):
            try:
                return "lokal", self.app.xdcc.pfad(unquote(pfad[len("/api/xdcc/datei/"):]))
            except xdcc.XdccFehler as fehler:
                return 404, "application/json", {"fehler": str(fehler)}
        if pfad == "/api/p2p/torrent":
            return self.p2p_torrent_lesen()
        if pfad.startswith("/api/p2p/torrent/datei/"):
            return self.p2p_torrent_datei(pfad)
        if pfad == "/api/kodi/jetzt":
            return self._kodi(lambda: self._kodi_geraet(werte.get("geraet", "")).jetzt())
        if pfad == "/tmdbhelper/players.zip":
            return 200, "application/zip", kodi_player.zip_bauen(self.app.verwaltung.daten() if self.app.verwaltung else {})
        if pfad.startswith("/api/vx/"):
            return self.vx_zugriff(pfad[len("/api/vx/"):], werte)
        if pfad == "/api/suche":
            return 200, "application/json", self.suche(werte.get("q", ""), werte.get("art", "film"))
        if pfad in ("/api/titelsuche", "/api/entdecken", "/api/genres", "/api/titel", "/api/titelstreams",
                   "/api/titeluntertitel"):
            return self.titel_api(pfad, werte)
        if pfad == "/api/streams":
            return 200, "application/json", self.streams(werte.get("id", ""))
        if pfad == "/api/bild":
            return 200, "application/json", self.bild(werte.get("titel", ""), werte.get("jahr", ""))
        if pfad == "/hls.js":
            return 200, "application/javascript", self.hls_js()
        if pfad == "/logo.svg":
            return 200, "image/svg+xml", LOGO
        if pfad.startswith("/schriften/"):
            daten = schrift(pfad[len("/schriften/"):])
            return (200, "font/woff2", daten) if daten else (404, "application/json", {"fehler": "nicht gefunden"})
        if pfad.startswith("/api/hls/"):
            return self.hls_abruf(pfad[len("/api/hls/"):])
        if pfad.startswith("/api/wiedergabe/"):
            ziel = self.wiedergabe_ziel(pfad[len("/api/wiedergabe/"):])
            if ziel is None:
                return 404, "application/json", {"fehler": "Wiedergabe abgelaufen, Stream neu waehlen"}
            return "wiedergabe", ziel
        return 404, "application/json", {"fehler": "nicht gefunden"}
