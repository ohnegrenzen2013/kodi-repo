"""Profile und Rechte in der Oberflaeche (profile.py).

Jede Anfrage traegt den Sitzungsschluessel im Header X-Profil (Dateien und Videos per ?sitzung=…). Daraus wird das
Profil der Anfrage; aendernde Anfragen pruefen das passende Recht (RECHT_FUER). Ohne Profile darf jeder alles.

  GET  /api/profile     Profile, ich, meine Rechte; fuer Admins Verwaltung (Profile, Einladungen, Anfragen)
  GET  /api/admin       Admin-Panel: Mitgliederliste mit Verbrauch und Grenzen, Top-Bereiche, -Module, -Addons, Server-Grenzen
  POST /api/admin       {aktion: server_grenzen, werte} | {aktion: zuruecksetzen, id?}
  POST /api/profile     {aktion: anlegen|anmelden|abmelden|aendern|loeschen|gruppen|einladung_neu|einladung_weg|
                         einladung_einloesen|anfrage|anfrage_entscheiden|eltern_pin|eltern_freigabe|freigabe_ende, …}
                        Kinderprofile (kind, kind_alter) und die Eltern-PIN: oberflaeche_kinder.py
"""

import json
import os
import threading
import time

from . import nutzung, profile

# (Pfad-Anfang, Methode oder None fuer alle, Recht) — absteigend nach Pfadlaenge sortiert, damit spezifischere Eintraege zuerst greifen
RECHT_FUER = sorted([
    ("/api/profile", "GET", None), ("/api/profile", "POST", None),  # prueft profile.py selbst
    ("/api/fehler/melden", "POST", None), ("/api/fehler", None, "einstellungen"),  # melden darf jeder, ansehen/exportieren nicht
    ("/api/kodiaddons/aufrufen", "POST", None), ("/api/kodiaddons/stream", "POST", None),  # nutzen darf jeder mit dem Reiter
    ("/api/kodiaddons/skins_aktiv", "POST", None),  # Heim-Style waehlen darf jeder, war vorher GET (CSRF-Fund)
    ("/api/kodiaddons/einstellungen", "GET", "anbieter"),  # Werte enthalten Passwoerter und Schluessel der Addons
    ("/api/kodiaddons/updates", "GET", "anbieter"),  # repos-Übersicht bleibt bewusst lesbar (siehe test_api_und_rechte), nur ihre Aenderung ist "anbieter"
    ("/api/kodiaddons/", "POST", "anbieter"),  # installieren, Einstellungen, Quellen: Addons sind Programme
    ("/api/heimspeicher/liste", "GET", "dateien"), ("/api/heimspeicher/crawl", "GET", "dateien"),  # Inhalt eines konfigurierten NAS/FTP/WebDAV
    ("/api/speicher/", "POST", "anbieter"), ("/api/speicher", None, "einstellungen"),  # Aufraeumen entfernt auch Kodi-Addons
    ("/api/ab18/freigabe", "POST", "profile"), ("/api/admin", None, "profile"),
    ("/api/tresor", None, "einstellungen"), ("/api/menue", "GET", "einstellungen"),  # Geheimnisse und Menue-Baum
    ("/api/linkreiniger", None, "einstellungen"),  # globale Link-Regeln und optionaler Verlauf
    ("/api/seiten-suche/", "POST", "einstellungen"),  # laedt eine fremde Suchseite (Admin-Werkzeug)
    ("/api/ab18/", None, "ab18"),
    ("/api/community-addons", "POST", "anbieter"), ("/api/anbieter/export", "GET", "anbieter"),  # Export enthaelt Zugangsdaten; GET wird von RECHT_FUER separat erfasst
    ("/api/anbieter/", "POST", "anbieter"), ("/api/senden", "POST", "anbieter"), ("/api/vx/", "POST", "anbieter"),
    ("/api/sicherheit/", "POST", "sicherheit"), ("/api/ipfilter", "POST", "sicherheit"), ("/api/afwall", "POST", "sicherheit"),
    ("/api/anonym/verknuepfen", "POST", "sicherheit"),
    ("/api/usenet-stream/pruefen", "POST", "downloads"),  # fragt NzbDAV/AltMount und Indexer an
    ("/api/beobachtungen", "POST", "downloads"), ("/api/beobachtungen", "GET", "downloads"),  # Beobachtungen zeigen Treffer und Downloader: wie Dienste nur mit Recht "downloads"
    ("/api/wiedergabe-check", "GET", "anbieter"),  # zeigt, welche Anbieter eingerichtet sind
    ("/api/szene", None, "downloads"),  # Release-Infos (xREL/predb) wie Beobachtungen nur mit Recht "downloads"
    ("/api/dienste/seerr", "GET", "downloads"),  # Titel in Seerr suchen: wie Anfragen stellen nur mit Recht "downloads"
    ("/api/dienste/", "POST", "downloads"), ("/api/rustnzb/", "POST", "downloads"), ("/api/debrid/", "POST", "downloads"),
    ("/api/debrid/cloud", "GET", "downloads"),
    ("/api/ember/steuerung", "POST", "downloads"), ("/api/ed2k/listen", "POST", "downloads"), ("/api/ed2k/hochladen", "POST", "downloads"),
    ("/api/ed2knetz", "POST", "downloads"),  # aMule/Rucio pruefen und Kad-Knoten zeigen
    ("/api/iptvquellen", "POST", "anbieter"), ("/api/kodiquellen", "POST", "anbieter"),  # Listen und Quellen aufnehmen
    ("/api/ipvpn", None, "sicherheit"),  # Overlay-Schnittstellen und Befehle
    ("/api/lbry", "POST", None),  # Suche und Wiedergabe darf jeder mit dem Reiter
    ("/api/discord", None, "einstellungen"), ("/api/qwen-pose", None, "einstellungen"),
    ("/api/videowerkstatt", None, "einstellungen"),
    ("/api/nuvio", "POST", "einstellungen"),  # Modulschalter und feste Server-Adresse gelten fuer alle
    ("/api/nuvio_plugins", None, "einstellungen"),  # JS-Plugins mit Fetch-Bridge (NV5-To-Do), nur Admins
    ("/api/geraete_abgleich", None, "einstellungen"),  # Geraete-Abgleich mit anderen Installationen, nur Admins
    ("/api/understand_anything", None, "einstellungen"),  # fuehrt ein fremdes Installationsskript aus, nur Admins
    ("/api/markenerkennung/starten", "POST", "downloads"),  # laedt eine Folge vorübergehend herunter (Bandbreite/Speicher)
    ("/api/omnisearch", None, "dateien"), ("/api/dateien", None, "dateien"),
    ("/api/downloads", None, "downloads"), ("/api/cloudstream", "POST", "einstellungen"),
    ("/api/party", "POST", "party"), ("/api/gemeinsam", "POST", "party"),
    ("/api/aktualisierung", "POST", "aktualisierung"), ("/api/aktualisierung/sicherung", None, "aktualisierung"),
    ("/api/sicherung/", "POST", "aktualisierung"),  # Komplettsicherung enthaelt alle Zugangsdaten; Einspielen ersetzt die ganze Konfiguration
    ("/api/web/", "POST", "einstellungen"), ("/api/verweise/aufraeumen", "POST", "einstellungen"), ("/api/portal/pruefen", "POST", "einstellungen"),
    ("/api/assistent/verknuepfen", "POST", "anbieter"),
    ("/api/ki/", "POST", "einstellungen"),  # KI-Diff verbraucht den API-Schluessel des Admins
    ("/api/uniqx/", None, "einstellungen"),  # Analyse, KI-Generierung, Anwenden: nur Admins
    ("/api/vorschlaege", None, "einstellungen"),  # Warteschlange + Diffs + Vorlagen: nur Admins
    ("/api/mcp", None, "einstellungen"),  # MCP-Server-Verbindung (Phase 2, Schritt 1): nur Admins
    ("/api/mcp/server", None, "einstellungen"),  # H0rSt als MCP-Server (Phase 3): nur Admins
    ("/api/komplettbackup", None, "einstellungen"),  # Komplett-Backup: alle Ordner und Daten, nur Admins
    ("/api/telegram", "POST", "einstellungen"), ("/api/kataloge", "POST", "einstellungen"), ("/api/sammlungen", "POST", "einstellungen"), ("/api/trakt/app", "POST", "einstellungen"), ("/api/simkl/app", "POST", "einstellungen"), ("/api/anime-tracker/app", "POST", "einstellungen"), ("/api/gdrive", None, "einstellungen"), ("/api/appstore", "POST", "einstellungen"), ("/api/heimspeicher", "POST", "einstellungen"),
    ("/api/filter", "POST", "einstellungen"), ("/api/links", "POST", "einstellungen"),  # gelten fuer alle Profile
    ("/api/livetv", "POST", "anbieter"), ("/api/easynews/zugang", "POST", "anbieter"),  # Listen und Zugaenge
    ("/api/badges", "POST", "einstellungen"), ("/api/hintergrund", "POST", "einstellungen"),  # Avatar gilt je Profil
    ("/api/startanimation", "POST", "einstellungen"),
    ("/api/xdcc/", "POST", "downloads"),
    ("/api/youtube/speichern", "POST", "downloads"), ("/api/youtube/datei_weg", "POST", "downloads"),
    ("/api/youtube/abonnieren", "POST", "einstellungen"), ("/api/youtube/abbestellen", "POST", "einstellungen"), ("/api/youtube/einstellungen", "POST", "einstellungen"),
    ("/api/portal/pruefen", "POST", "einstellungen"), ("/api/portal/wecken", "POST", "einstellungen"),  # klopft Ports im Heimnetz ab
    ("/api/web/", "POST", "einstellungen"),  # Webhosting: installieren, bauen, Ordner setzen
    ("/api/ftpserver", "POST", "einstellungen"), ("/api/baukasten", "POST", "einstellungen"), ("/api/sprachsteuerung", "POST", "einstellungen"),
    ("/api/traum/einrichten", "POST", "einstellungen"), ("/api/traum/quelle", "POST", "einstellungen"),
    ("/api/traum/apk", "POST", "einstellungen"), ("/api/traum/modell", "POST", "einstellungen"),
    ("/api/portal/programme", None, "einstellungen"),  # klopft Ports im Heimnetz ab
    ("/api/usb", None, "speicher"),  # USB einhängen/aushängen/sichern; Wiederherstellen prüft zusätzlich "einstellungen"
    ("/api/brause", "POST", "einstellungen"), ("/api/kodi/import", "POST", "einstellungen"), ("/api/waechter", "POST", "einstellungen"),
], key=lambda t: len(t[0]), reverse=True)
# Diese Einstellungen gelten fuer alle (Stremio, Medienserver …) und brauchen das Recht "einstellungen"
GEMEINSAM = {"audio", "untertitel", "dlna_server", "ausschliessen", "eigene_tabs",
             # Usenet-Streaming-Modus: wirkt auf die Stremio-Antworten des Servers, nicht auf ein Profil
             "usenet_modus_an", "usenet_sortierung", "usenet_min_aufloesung", "usenet_max_aufloesung", "usenet_max_gb",
             "usenet_je_aufloesung", "usenet_ausschluss", "usenet_dedupe", "usenet_sofort", "usenet_auto_an",
             "usenet_auto_anzahl", "usenet_ersatzsuche", "usenet_basis_url", "usenet_deutsch",
             "qwen_an", "qwen_url", "qwen_unet", "qwen_clip", "qwen_vae", "qwen_lora", "qwen_lora_staerke",
             "qwen_schritte", "qwen_cfg", "qwen_sampler", "qwen_scheduler", "qwen_breite", "qwen_hoehe",
             "qwen_seed", "qwen_negativ", "qwen_stufe", "qwen_pose", "qwen_nsfw_an", "qwen_anzahl",
             "vw_an", "vw_url", "vw_modell", "vw_breite", "vw_hoehe", "vw_frames", "vw_fps",
             "vw_schritte", "vw_cfg", "vw_sampler", "vw_scheduler", "vw_seed", "vw_anzahl",
             "vw_format", "vw_negativ",
             # IPTV-Quellen, eD2K-Netz, LBRY und IPVPN gelten fuer alle Profile eines Servers
             "iptvquellen_an", "dispatcharr_url", "dispatcharr_key", "ed2knetz_an", "amule_web", "rucio_web",
             "kad_id", "lbry_an", "lbry_daemon", "ipvpn_an", "ipvpn_netz", "ipvpn_knoten", "ipvpn_passwort",
             # AIOStreams ist eine Server-Instanz und gilt fuer alle Profile
             "aiostreams_an", "aiostreams_basis", "aiostreams_manifest", "aiostreams_heimnetz"}
_CACHE_ZEIT = 3.0
PIN_FEHLVERSUCHE = 5  # danach ist das Profil fuer PIN_SPERRE_SEK gesperrt (im Speicher, je Serverstart)
PIN_SPERRE_SEK = 300


class ProfileMixin:

    def _profile_daten(self, frisch=False):
        """Nutzerdaten (kurz zwischengespeichert – jede Anfrage braucht sie fuer das Profil)."""
        if not self.app.verwaltung:
            return {}
        jetzt = time.monotonic()
        cache = getattr(self, "_profile_cache", None)
        if frisch or not cache or jetzt - cache[0] > _CACHE_ZEIT:
            self._profile_cache = cache = (jetzt, self.app.verwaltung.daten())
        return cache[1]

    def _anfrage_lokal(self):
        if not hasattr(self, "_anfrage_daten"):
            self._anfrage_daten = threading.local()
        return self._anfrage_daten

    def profil_ermitteln(self, kopf, werte):
        """Zu Beginn jeder Anfrage: Profil aus X-Profil (oder ?sitzung=) bestimmen."""
        lokal = self._anfrage_lokal()
        token = (kopf.get("X-Profil") if kopf else None) or werte.get("sitzung") or ""
        lokal.token = token
        daten = self._profile_daten()
        lokal.profil = profile.profil_zu(daten, token) if profile.aktiv(daten) else None
        lokal.aktiv = profile.aktiv(daten)
        return lokal.profil

    def _fehlzaehler(self):
        return self.__dict__.setdefault("_pin_fehl", {})

    def _anmelde_bremse(self, pid):
        st = self._fehlzaehler().get(pid)
        if st and st[1] > time.time():
            minuten = int(st[1] - time.time()) // 60 + 1
            raise profile.KeinRecht("Zu viele Fehlversuche – in %d Minuten erneut versuchen." % minuten)

    def _fehlversuch(self, pid):
        fehl = self._fehlzaehler()
        n, bis = fehl.get(pid, (0, 0))
        n += 1
        fehl[pid] = (0, time.time() + PIN_SPERRE_SEK) if n >= PIN_FEHLVERSUCHE else (n, bis)

    def aktuelles_profil(self):
        return getattr(self._anfrage_lokal(), "profil", None)

    def darf(self, recht):
        lokal = self._anfrage_lokal()
        return not getattr(lokal, "aktiv", False) or recht in profile.rechte(getattr(lokal, "profil", None))

    def recht_verboten(self, recht):
        """Fertige 403-Antwort – fuer Module, die je Aktion selbst pruefen (z. B. Assistent)."""
        wer = self.aktuelles_profil()
        return 403, "application/json", {"fehler": "%s darf das nicht (%s)." % (wer["name"] if wer else "Ohne Profil",
                                                                                profile.RECHTE[recht]), "recht": True}

    def recht_fehlt(self, pfad, methode):
        """Fehlermeldung, wenn das Profil der Anfrage das noetige Recht nicht hat, sonst ''."""
        if not getattr(self._anfrage_lokal(), "aktiv", False):
            return ""
        for anfang, art, recht in RECHT_FUER:
            if pfad.startswith(anfang) and (art is None or art == methode):
                if recht and not self.darf(recht):
                    return self.recht_verboten(recht)[2]["fehler"]
                return ""
        return ""

    # --- Routen --------------------------------------------------------------------------------------
    def profile_lesen(self):
        daten = self._profile_daten(frisch=True)
        return 200, "application/json", profile.zustand(daten, self.aktuelles_profil())

    def profile_post(self, koerper):
        try:
            w = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(w, dict):
                raise ValueError("JSON-Objekt erwartet")
            if not self.app.verwaltung:
                raise ValueError("Nutzerdaten nicht verfügbar")
            ich = self.aktuelles_profil()
            a = w.get("aktion")
            ergebnis = {}
            if ich and ich.get("kind") and a not in ("eltern_freigabe", "freigabe_ende", "aendern") and not self.eltern_frei():
                # Kinderprofil: wechseln, abmelden, loeschen, Einladungen … nur mit Eltern-Freigabe
                return 403, "application/json", {"fehler": "Dafür ist die Eltern-PIN nötig.", "eltern_pin": True}
            if a == "eltern_freigabe":
                ergebnis.update(self.eltern_freigabe(self.app.verwaltung.daten(), w.get("pin")))
                return 200, "application/json", dict(profile.zustand(self._profile_daten(frisch=True), ich), **ergebnis)
            if a == "freigabe_ende":
                self.eltern_freigabe_ende()
                return 200, "application/json", dict(profile.zustand(self._profile_daten(frisch=True), ich), freigabe=0)

            def tun(d):
                wer = profile.profil_zu(d, getattr(self._anfrage_lokal(), "token", "")) if profile.aktiv(d) else None
                if a == "anlegen":
                    x = profile.anlegen(d, wer, w)
                    if len(d[profile.SCHLUESSEL]["liste"]) == 1:  # erstes Profil: gleich angemeldet
                        ergebnis["sitzung"] = profile.sitzung_neu(d[profile.SCHLUESSEL], x["id"], time.time)
                    ergebnis["neu"] = x["id"]
                elif a == "anmelden":
                    ziel = w.get("id")
                    self._anmelde_bremse(ziel)
                    try:
                        x, token = profile.anmelden(d, ziel, w.get("pin"))
                    except profile.PinFalsch:
                        self._fehlversuch(ziel)
                        raise
                    self._fehlzaehler().pop(ziel, None)
                    ergebnis.update(sitzung=token, neu=x["id"])
                elif a == "abmelden":
                    profile.abmelden(d, getattr(self._anfrage_lokal(), "token", ""))
                elif a == "aendern":
                    profile.aendern(d, wer, w.get("id") or (wer or {}).get("id"), dict(w.get("werte") or {}, **({"eltern_pin": w["eltern_pin"]} if "eltern_pin" in w else {})))
                elif a == "loeschen":
                    profile.loeschen(d, wer, w.get("id"), eltern_pin=w.get("eltern_pin"))
                elif a == "eltern_pin":
                    profile.eltern_pin_setzen(d, wer, w.get("neu"), alt=w.get("alt"))
                elif a == "gruppen":
                    profile.gruppen_aendern(d, wer, w)
                elif a == "einladung_neu":
                    ergebnis["einladung"] = profile.einladung_neu(d, wer, w)
                elif a == "einladung_weg":
                    profile.einladung_weg(d, wer, w.get("code"))
                elif a == "einladung_einloesen":
                    x, token = profile.einladung_einloesen(d, w.get("code"), w)
                    ergebnis.update(sitzung=token, neu=x["id"])
                elif a == "anfrage":
                    ergebnis["anfrage"] = profile.anfrage(d, w)
                elif a == "anfrage_entscheiden":
                    profile.anfrage_entscheiden(d, wer, w.get("id"), w.get("ja") is True, w.get("rolle") or "mitglied", w.get("gruppen"))
                else:
                    raise profile.ProfilFehler("Unbekannte Aktion")
            self.app.verwaltung.bearbeiten(tun)
            daten = self._profile_daten(frisch=True)
            token = ergebnis.get("sitzung") or getattr(self._anfrage_lokal(), "token", "")
            ich = profile.profil_zu(daten, token) if a != "abmelden" else None
            return 200, "application/json", dict(profile.zustand(daten, ich), **ergebnis)
        except profile.KeinRecht as fehler:
            return 403, "application/json", {"fehler": str(fehler)}
        except (ValueError, UnicodeDecodeError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}

    # --- Admin-Panel -----------------------------------------------------------------------------------
    def _admin_zustand(self):
        daten = self._profile_daten(frisch=True)
        liste = ((daten.get(profile.SCHLUESSEL) or {}).get("liste")) or []
        z = self.app.nutzung.uebersicht([dict(x, rolle_name=profile.ROLLEN.get(x.get("rolle"), "")) for x in liste])
        z["server_grenzen"] = nutzung.server_grenzen(daten.get(nutzung.SERVER_SCHLUESSEL))
        z["server_felder"] = {k: {"name": n, "hinweis": h, "standard": s, "min": a, "max": b}
                              for k, (n, h, s, a, b) in nutzung.SERVER_GRENZEN.items()}
        z["profile_aktiv"] = bool(liste)
        return 200, "application/json", z

    def admin_lesen(self):
        return self._admin_zustand()

    def admin_post(self, koerper):
        try:
            w = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(w, dict):
                raise ValueError("JSON-Objekt erwartet")
            a = w.get("aktion")
            if a == "server_grenzen":
                if not self.app.verwaltung:
                    raise ValueError("Nutzerdaten nicht verfügbar")
                werte = nutzung.server_grenzen(w.get("werte"))

                def tun(d):
                    d[nutzung.SERVER_SCHLUESSEL] = werte
                self.app.verwaltung.bearbeiten(tun)
                nutzung.server_grenzen_anwenden(werte)
                # was an der alten Grenze gescheitert ist, gleich noch einmal laden (die letzte gute Fassung bleibt)
                for abholer in [getattr(self.app, "adressen", None), getattr(self.app, "epg", None)] + list(getattr(self.app, "listen", {}).values()):
                    if abholer is not None and "größer als" in (getattr(abholer, "fehler", "") or ""):
                        if os.path.isfile(abholer.pfad):
                            os.utime(abholer.pfad, (0, 0))
                        abholer.bei_bedarf_erneuern()
            elif a == "zuruecksetzen":
                self.app.nutzung.zuruecksetzen(w.get("id") if isinstance(w.get("id"), str) else None)
            else:
                raise ValueError("Unbekannte Aktion")
            return self._admin_zustand()
        except (ValueError, UnicodeDecodeError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
