"""Vorlage der Oberflaeche "Durchsuchen": HTML, CSS und JS liegen in statisch/seite.*.

HTML, CSS und JavaScript sind thematisch aufgeteilt: seite.html, seite.css und seite.js enthalten die
Grundlage, die weiteren Teile liegen in statisch/seite_html/, statisch/seite_css/ und statisch/seite_js/.
Beim Import werden alle Teile in fester Reihenfolge zu einer Seite zusammengesetzt (eingebettet, also
eine einzige Antwort); danach wird nur noch {{VERSION}} ersetzt."""

import os

_ORDNER = os.path.join(os.path.dirname(os.path.abspath(__file__)), "statisch")

HTML_TEILE = (
    "seite.html",  # Grundlage: Kopf, Start, Suche, erste Bereiche
    "seite_html/01_anbieter_vx_daumenkino.html",
    "seite_html/02_localdream_kodi_youtube.html",
    "seite_html/03_kameras_portal_sicherheit.html",
    "seite_html/03a_nuvio.html",  # Nuvio Mobile: Client zum Modul-Host (Addon- und API-Adresse)
    "seite_html/05_videowerkstatt.html",
    "seite_html/04_dialoge_script.html",
)

CSS_TEILE = (
    "seite.css",  # Grundlage: Tokens, Kopf, Suche, Dialoge
    "seite_css/01_arvio_layout.css",
    "seite_css/02_layout_livetv.css",
    "seite_css/03_heim_styles.css",
    "seite_css/04_stile_1.css",
    "seite_css/05_stile_2.css",
    "seite_css/06_netflix_uniqx.css",
    "seite_css/07_tresor_stammbaum.css",  # Tresor und Menue-StammBaum
    "seite_css/08_brause_gx.css",
    "seite_css/09_nova.css",  # UNiQuanteX: [ "NOVA" @ H0rSt ]
    "seite_css/10_gnunet.css",  # UNiQuanteX: [ "GNUnet" @ H0rSt ] und die Werkzeugliste
    "seite_css/11_sammlungen.css",  # Sammlungen (Collections, ARVIO 2.2)
    "seite_css/12_magicwx.css",  # UNiQuanteX: [ "MagicWX" @ H0rSt ]
    "seite_css/13_bilddatensatz.css",  # lokale Bild-Datensatz-Pflege
    "seite_css/14_shizuku.css",  # UNiQuanteX: [ "Shizuku" @ H0rSt ]
    "seite_css/15_emberp2p.css",  # UNiQuanteX: [ "Ember-P2P" @ H0rSt ]
    "seite_css/16_emuleese.css",  # UNiQuanteX: [ "eSE LiveTV" @ H0rSt ]
    "seite_css/17_omnisearch.css",  # UNiQuanteX: [ "OmniSearch" @ H0rSt ] und Dateisuche
    "seite_css/18_keepadb.css",  # UNiQuanteX: [ "KeepADB" @ H0rSt ]
    "seite_css/19_main_ui.css",  # Aus main uebernommene Oberflaechenregeln
    "seite_css/20_netzquellen.css",  # IPTV-Quellen, eD2K/Kad, LBRY, IPVPN und Kodi-Quellen
    "seite_css/21_appstore.css",  # App-Store: Karten, Unteransichten, Update-Regeln
    "seite_css/22_bildschirm.css",  # Bildschirm einpassen, TV-Fokus und Testrahmen
    "seite_css/23_ladeanimation.css",  # Ladebalken und Skeletons
    "seite_css/24_barrierefreiheit.css",  # Sprungmarke, Kontrast, Systemfarben, Transparenz, Touch-Ziele
    "seite_css/25_videowerkstatt.css",  # Videowerkstatt: Formular, Auftraege, Galerie
    "seite_css/26_kalender.css",  # Release-Kalender der Bibliothek
    "seite_css/27_livetv_sport.css",  # Sport-Events im Live-TV
)
CSS_STIL_DATEI = "seite_css/06_netflix_uniqx.css"

JS_TEILE = (
    "seite.js",  # Grundlage: Adressen, Sitzung, Fehler, Karten
    "seite_js/01_suche_arvio.js",
    "seite_js/02_suche_karten.js",
    "seite_js/03_youtube_bibliothek_netflix.js",
    "seite_js/04_details_streams.js",
    "seite_js/05_details_folgen.js",
    "seite_js/06_details_bereiche.js",  # enthaelt STILE und STIL_NAMEN
    "seite_js/07_heim_anbieter.js",
    "seite_js/08_badges_dienste.js",
    "seite_js/09_kodi_stack.js",
    "seite_js/10_beobachtungen_debrid.js",
    "seite_js/11_vxparser_heimlinks.js",
    "seite_js/12_livetv_sender.js",
    "seite_js/13_livetv_programm.js",
    "seite_js/14_p2p_youtube.js",
    "seite_js/15_xdcc_sicherheit.js",
    "seite_js/16_tor_i2p.js",
    "seite_js/17_ab18_einstellungen.js",
    "seite_js/18_einstellungen_1.js",
    "seite_js/19_einstellungen_2.js",
    "seite_js/20_mcp_vorschlaege.js",
    "seite_js/21_uniqx_brille.js",
    "seite_js/22_dank_aktualisierung.js",
    "seite_js/23_gdrive_backup.js",
    "seite_js/24_downloader_dateien.js",
    "seite_js/25_dateisuche_player.js",
    "seite_js/26_kataloge_ansichten.js",
    "seite_js/27_neu_laden_apps.js",
    "seite_js/27_appstore.js",  # App-Store: Suche, Update-Regeln, eigene Repositories, Matrix
    "seite_js/28_easynews_musik.js",
    "seite_js/29_kameras_profil.js",
    "seite_js/30_fernseher_radio.js",
    "seite_js/31_portal_bereich.js",
    "seite_js/32_portal_fenster.js",
    "seite_js/33_prompt_studio.js",
    "seite_js/34_local_dream.js",
    "seite_js/35_kodi_addons_1.js",
    "seite_js/36_kodi_addons_2.js",
    "seite_js/37_videochat_assistent.js",
    "seite_js/38_baukasten.js",
    "seite_js/39_optionssuche.js",
    "seite_js/40_tasten_sprache.js",
    "seite_js/41_daumenkino.js",
    "seite_js/42_karaoke.js",
    "seite_js/43_gemeinsam_party.js",
    "seite_js/44_dateien.js",
    "seite_js/45_profile_admin.js",
    "seite_js/46_fernsteuerung.js",
    "seite_js/47_kombi.js",
    "seite_js/48_player_hls.js",
    "seite_js/49_ki_anbieter.js",
    "seite_js/50_nach_oben.js",
    "seite_js/51_dienste.js",
    "seite_js/52_tresor.js",
    "seite_js/53_tresor_einstellungen.js",
    "seite_js/54_stammbaum.js",
    "seite_js/55_brause_gx.js",
    "seite_js/56_linkreiniger.js",
    "seite_js/57_boot.js",
    "seite_js/58_seiten_suche.js",
    "seite_js/59_spotweb_tools.js",
    "seite_js/60_usb_tools.js",
    "seite_js/61_gnunet_tools.js",
    "seite_js/62_world_repo.js",
    "seite_js/63_sammlungen.js",
    "seite_js/64_simkl.js",
    "seite_js/65_debrid_cloud.js",
    "seite_js/66_anime_tracker.js",
    "seite_js/67_nativer_downloader.js",
    "seite_js/68_cloudstream.js",
    "seite_js/69_localdream_host.js",
    "seite_js/70_prompt_studio_plus.js",
    "seite_js/71_promptstudio_app.js",
    "seite_js/72_magicwx.js",  # MagicWX: Parameterblock und LocalDream-Anbindung
    "seite_js/73_bilddatensatz.js",  # lokale Bild-Datensatz-Pflege
    "seite_js/74_mtmanager.js",  # MT Manager 2.26.11: APK-MCP-Preset
    "seite_js/75_shizuku.js",  # Shizuku 13.6.0-R4: Rechtebruecke und rish-Befehle
    "seite_js/76_emberp2p.js",  # Ember-P2P: Reiter mit dem Schalter ausblenden
    "seite_js/77_emuleese.js",  # eMule eSE LiveTV: Status und Portal-Reiter
    "seite_js/78_discord_bot.js",  # Discord-Bildbot: Webhook-Versand aus Ab 18
    "seite_js/79_qwen_pose.js",  # Qwen-Image 2.1 Pose Studio (ComfyUI)
    "seite_js/80_omnisearch.js",  # OmniSearch: Dateisuche, Duplikate und Android-Begleit-App
    "seite_js/81_keepadb.js",  # KeepADB: Netzregel, Kraft-Modus, Webhook und Schaltbefehle
    "seite_js/82_nuvio.js",
    "seite_js/83_main_ui.js",  # Aus main uebernommene Oberflaechenfunktionen (Nuvio-Plugins, Geraete-Abgleich, Downloads, Mein Netflix)
    "seite_js/84_iptvquellen.js",  # IPTV-Quellen, freie Listen und Dispatcharr
    "seite_js/85_kodiquellen.js",  # Kodi-Repository, EPG, Senderliste und Builds
    "seite_js/86_ed2knetz.js",  # aMule, Rucio und Kad-Tabelle
    "seite_js/87_lbry.js",  # LBRY/Odysee: Suche und Wiedergabe
    "seite_js/88_ipvpn.js",  # IPVPN-Overlay
    "seite_js/89_screenfit.js",  # Bildschirm einpassen, TV-Modus und Testrahmen
    "seite_js/90_ladeanimation.js",  # Ladebalken und Skeletons
    "seite_js/91_aiostreams.js",  # AIOStreams-Instanz, Manifest und Clients
    "seite_js/92_videowerkstatt.js",  # Videowerkstatt: ComfyUI-Auftraege und Galerie
    "seite_js/93_community_addons.js",  # Kuratierter Stremio-Community-Addon-Katalog
    "seite_js/94_kalender.js",  # Release-Kalender der Bibliothek
    "seite_js/95_livetv_sport.js",  # Sport-Events im Live-TV (ESPN)
)
JS_STIL_DATEI = "seite_js/06_details_bereiche.js"


def _lesen(name):
    with open(os.path.join(_ORDNER, name), encoding="utf-8") as f:
        return f.read()


def css_lesen():
    return "".join(_lesen(name) for name in CSS_TEILE)


HTML = "".join(_lesen(name) for name in HTML_TEILE)
CSS = css_lesen()
JS = "".join(_lesen(name) for name in JS_TEILE)
SEITE = HTML.replace("{{CSS}}", CSS, 1).replace("{{JS}}", JS, 1)
