"""Start auf PC oder Raspberry Pi: python3 -m rezeptserver --help"""

from .__main___grund import *
from .__main___anbieter import anbieter_ausgeben, anbieter_starten, _zugang_abfragen
from .__main___vorlagen import vorlagen_starten
from .__main___selbsttest import selbsttest_starten
from .__main___sicherung import aktualisierung_vorziehen, sicherung_starten


def main(argv=None):
    parser = argparse.ArgumentParser(prog="rezeptserver", description="JSON-Rezepte als Stremio-Addon")
    parser.add_argument("--rezepte", default="rezepte", help="Ordner mit den Rezepten (Standard: ./rezepte)")
    parser.add_argument("--daten", "--konfig", dest="daten", default=konfig.DATEINAME,
                        help="Datenbank mit den Nutzerdaten (Standard: ./%s). Eine konfig.json im selben Ordner "
                             "wird beim ersten Start uebernommen." % konfig.DATEINAME)
    parser.add_argument("--host", default="127.0.0.1",
                        help="127.0.0.1 = nur dieses Geraet (Token trotzdem Pflicht), 0.0.0.0 = ganzes Heimnetz")
    parser.add_argument("--port", type=int, default=7000)
    parser.add_argument("-v", "--ausfuehrlich", action="store_true")
    test = parser.add_argument_group("Selbsttest (ohne Kodi, startet keinen Server)")
    test.add_argument("--test", metavar="TITEL", help='Rezepte mit diesem Suchtext pruefen, z. B. "Big Buck Bunny"')
    test.add_argument("--imdb", metavar="ID", help="statt Suchtext ueber eine IMDb-ID pruefen, z. B. tt1254207")
    test.add_argument("--jahr", type=int, help="Erscheinungsjahr fuer die Jahrespruefung (nur mit --test)")
    test.add_argument("--serie", action="store_true", help="als Serie suchen (IMDb-ID dann als tt...:staffel:folge)")
    sicherung = parser.add_argument_group("Sicherung (startet keinen Server)")
    sicherung.add_argument("--export", metavar="DATEI", help="alle Nutzerdaten als JSON-Sicherung in DATEI schreiben")
    sicherung.add_argument("--import", dest="einlesen", metavar="DATEI",
                           help="Sicherung (oder alte konfig.json) einlesen; ersetzt alle Nutzerdaten")
    sicherung.add_argument("--verschluesseln", action="store_true",
                           help="mit --export: Sicherung mit Passwort verschluesseln (fragt nach dem Passwort)")
    sicherung.add_argument("--zusammenfuehren", action="store_true",
                           help="mit --import: vorhandene Daten behalten, nur Werte aus der Sicherung ueberschreiben")
    verwalten = parser.add_argument_group("Anbieter (startet keinen Server)")
    verwalten.add_argument("--anbieter", action="store_true", help="alle Anbieter nach Kategorie mit Anmeldestatus zeigen")
    verwalten.add_argument("--anbieter-neu", metavar="NAME", help="eigenen Anbieter anlegen, fragt die Zugangsdaten ab")
    verwalten.add_argument("--kategorie", choices=list(anbieter.KATEGORIEN), default="streams",
                           help="mit --anbieter-neu (Standard: streams)")
    verwalten.add_argument("--anmeldung", choices=list(anbieter.EIGENE_ANMELDUNGEN),
                           help="mit --anbieter-neu: api = API-Schluessel, login = Benutzer und Passwort")
    verwalten.add_argument("--anmelden", metavar="ID", help="Zugangsdaten eines Anbieters eingeben oder aendern")
    verwalten.add_argument("--anbieter-weg", metavar="ID", help="eigenen Anbieter samt Zugangsdaten entfernen")
    verwalten.add_argument("--vorlagen", action="store_true",
                           help="Vorlagen zeigen (Usenet-Provider, Indexer, Hoster & Debrid, Stremio-Addons, vxparser ...)")
    verwalten.add_argument("--anbieter-vorlage", metavar="VORLAGE",
                           help="eigenen Anbieter aus einer Vorlage anlegen, fragt die Zugangsdaten ab")
    verwalten.add_argument("--name", help="mit --anbieter-vorlage: eigener Name statt dem der Vorlage")
    verwalten.add_argument("--anbieter-json", metavar="QUELLE",
                           help="Anbieter per JSON hinzufuegen: Datei oder Adresse (Stremio-manifest.json, "
                                "H0rSt-Anbieter-JSON, vxparser urls.json)")
    verwalten.add_argument("--anbieter-export", metavar="DATEI", help="eigene Anbieter als JSON schreiben")
    verwalten.add_argument("--mit-passwoertern", action="store_true",
                           help="mit --anbieter-export: Passwoerter und API-Schluessel mitschreiben")
    verwalten.add_argument("--pruefen", metavar="ID", help="Verbindung eines eigenen Anbieters testen")
    verwalten.add_argument("--freischalten", metavar="LINK", nargs="+",
                           help="Hoster-Links oder Torrents (magnet:… oder infoHash) mit dem Debrid-Konto "
                                "freischalten und die direkten Links zeigen")
    verwalten.add_argument("--vx-links", action="store_true", help="vxparser-Links (Domains & APIs) zeigen")
    verwalten.add_argument("--vx-link", nargs=2, metavar=("SCHLUESSEL", "URL"),
                           help="vxparser-Link setzen (URL \"\" = vxparser-Standard), z. B. megakino https://...")
    verwalten.add_argument("--epg-quelle", metavar="URL",
                           help="XMLTV-Quelle fuer die EPG-Weitergabe unter /epg.xml.gz (\"\" = keine)")
    verwalten.add_argument("--epg-grabber", choices=list(livetv.GRABBER) + ["aus"],
                           help="EPG selbst holen statt aus einer XMLTV-Quelle (magenta = Magenta TV, aus = Quelle nutzen)")
    verwalten.add_argument("--liste", nargs=2, metavar=("NAME", "URL"),
                           help="eigene M3U/M3U8 aus dem Internet aufnehmen (unter /listen/<name>.m3u und in /tv.m3u)")
    verwalten.add_argument("--liste-weg", metavar="NAME", help="eigene Liste entfernen")
    verwalten.add_argument("--xtream", nargs=4, metavar=("NAME", "SERVER", "BENUTZER", "PASSWORT"),
                           help="eigenen Xtream-Zugang als Liste aufnehmen (baut die get.php-M3U-Adresse)")
    verwalten.add_argument("--link", nargs=2, metavar=("NAME", "URL"),
                           help="Heim-Link anlegen (Lesezeichen zu FRITZ!Box, NAS, Cloud ...), zeigt /, Bereich Heim")
    verwalten.add_argument("--link-weg", metavar="NAME", help="Heim-Link entfernen")
    verwalten.add_argument("--links", action="store_true", help="alle Heim-Links zeigen")
    verwalten.add_argument("--ab18", choices=("an", "aus"),
                           help="Rezepte der Kategorie ab18 freigeben oder sperren (Standard: gesperrt)")
    args = parser.parse_args(argv)
    if args.anbieter_neu and not args.anmeldung:
        parser.error("--anbieter-neu braucht --anmeldung api oder --anmeldung login")
    logging.basicConfig(level=logging.DEBUG if args.ausfuehrlich else logging.INFO,
                        format="%(asctime)s %(levelname)s %(message)s")
    if args.export or args.einlesen:
        return sicherung_starten(args)
    if args.vorlagen or args.anbieter_vorlage or args.anbieter_json or args.anbieter_export or args.pruefen \
            or args.vx_links or args.vx_link or args.freischalten:
        return vorlagen_starten(args)
    if args.anbieter or args.anbieter_neu or args.anmelden or args.anbieter_weg or args.ab18 \
            or args.epg_quelle is not None or args.epg_grabber or args.liste or args.liste_weg \
            or args.link or args.link_weg or args.links or args.xtream:
        return anbieter_starten(args)
    if args.test or args.imdb:
        return selbsttest_starten(args)
    aktualisierung_vorziehen(args, argv)
    dienst = Dienst(args.rezepte, args.daten)
    dienst.starte(args.host, args.port)
    try:
        threading.Event().wait()
    except KeyboardInterrupt:
        pass
    finally:
        dienst.stoppe()


if __name__ == "__main__":
    raise SystemExit(main())
