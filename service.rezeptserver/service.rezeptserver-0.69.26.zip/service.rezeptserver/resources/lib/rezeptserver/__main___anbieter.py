"""Anbieter auf der Kommandozeile: anlegen, anmelden, entfernen, EPG, Listen und Links."""

from .__main___grund import (
    anbieter,
    getpass,
    konfig,
    lade_ordner,
    links,
    livetv,
    logging,
)

def _zugang_abfragen(felder):
    """Fragt jedes Feld ab; Enter laesst den bisherigen Wert stehen."""
    werte = {}
    for feld in felder:
        frage = "%s%s%s: " % (feld.get("label") or feld["key"], " (optional)" if feld.get("optional") else "",
                              " [gesetzt, Enter = behalten]" if feld.get("wert") else "")
        wert = (getpass.getpass if feld.get("typ") == "passwort" else input)(frage).strip()
        if wert:
            werte[feld["key"]] = wert
    return werte


def anbieter_ausgeben(eintraege):
    kategorie = None
    for a in eintraege:
        if a["kategorie"] != kategorie:
            kategorie = a["kategorie"]
            print(anbieter.KATEGORIEN[kategorie])
        if a["anmeldung"] == "keine":
            zustand = ""
        elif a["vollstaendig"]:
            zustand = "angemeldet"
        else:
            zustand = "FEHLT: " + ", ".join(f["key"] for f in a["felder"] if not f["wert"].strip()
                                            and not f.get("optional"))
        herkunft = "eigener Anbieter, " + ("Rezepte: " + ", ".join(a["rezepte"]) if a["rezepte"] else "noch kein Rezept") \
            if a["eigen"] else ", ".join(a["rezepte"])
        print("  %-32s %-22s %-18s %s" % ("%s (%s)" % (a["name"], a["id"]), anbieter.ANMELDUNGEN[a["anmeldung"]],
                                        zustand, herkunft))


def anbieter_starten(args):
    logging.getLogger("rezeptserver").setLevel(logging.WARNING)
    module = lade_ordner(args.rezepte)
    try:
        daten = konfig.lade(args.daten)
        if args.anbieter_neu:
            neu = anbieter.hinzufuegen(daten, module, args.anbieter_neu, args.kategorie, args.anmeldung)
            werte = _zugang_abfragen(anbieter.FELDER[args.anmeldung])
            anbieter.zugang_setzen(daten, module, neu, werte)
            konfig.speichere(args.daten, daten)
            print("Anbieter %s angelegt. Eigene Rezepte nutzen ihn mit \"konto\": \"%s\"." % (neu, neu))
        if args.anmelden:
            eintrag = next((a for a in anbieter.liste(module, daten) if a["id"] == args.anmelden), None)
            if eintrag is None:
                raise anbieter.AnbieterFehler("Unbekannter Anbieter: %s" % args.anmelden)
            if not eintrag["felder"]:
                raise anbieter.AnbieterFehler("%s braucht keine Anmeldung" % eintrag["name"])
            anbieter.zugang_setzen(daten, module, args.anmelden, _zugang_abfragen(eintrag["felder"]))
            konfig.speichere(args.daten, daten)
            print("Zugangsdaten fuer %s gespeichert." % eintrag["name"])
        if args.anbieter_weg:
            anbieter.entfernen(daten, args.anbieter_weg)
            konfig.speichere(args.daten, daten)
            print("Anbieter %s entfernt." % args.anbieter_weg)
        if args.epg_quelle is not None:
            daten["livetv"] = livetv.pruefe(dict(daten.get("livetv") or {}, epg_quelle=args.epg_quelle))
            konfig.speichere(args.daten, daten)
            print("EPG-Quelle %s. Laufenden Server neu starten." % ("gespeichert" if args.epg_quelle.strip()
                                                                     else "entfernt"))
        if args.epg_grabber:
            grabber = "" if args.epg_grabber == "aus" else args.epg_grabber
            daten["livetv"] = livetv.pruefe(dict(daten.get("livetv") or {}, epg_grabber=grabber))
            konfig.speichere(args.daten, daten)
            print("EPG %s. Laufenden Server neu starten." % ("von %s" % livetv.GRABBER[grabber] if grabber
                                                           else "wieder aus der EPG-Quelle"))
        if args.liste or args.liste_weg or args.xtream:
            einstellung = livetv.pruefe(daten.get("livetv"))
            listen = einstellung["listen"]
            if args.xtream:
                name, server, benutzer, passwort = args.xtream
                args.liste = [name, livetv.xtream_m3u_url(server, benutzer, passwort)]
            if args.liste_weg:
                weg = livetv.liste_id(args.liste_weg)
                if not any(livetv.liste_id(l["name"]) == weg for l in listen):
                    raise livetv.LiveTvFehler("Keine Liste %s" % args.liste_weg)
                listen = [l for l in listen if livetv.liste_id(l["name"]) != weg]
            if args.liste:
                listen = listen + [{"name": args.liste[0], "url": args.liste[1], "an": True}]
            daten["livetv"] = livetv.pruefe(dict(einstellung, listen=listen))
            konfig.speichere(args.daten, daten)
            if args.liste:
                print("Liste %s aufgenommen: /listen/%s.m3u. Laufenden Server neu starten."
                      % (args.liste[0], livetv.liste_id(args.liste[0])))
                if args.xtream:
                    print("  (Xtream-M3U-Adresse aus den Zugangsdaten gebaut)")
            if args.liste_weg:
                print("Liste %s entfernt." % args.liste_weg)
        if args.link or args.link_weg:
            vorhandene = links.pruefe(daten.get("links"))
            if args.link_weg:
                rest = [l for l in vorhandene if l["name"].lower() != args.link_weg.strip().lower()]
                if len(rest) == len(vorhandene):
                    raise links.LinkFehler("Keinen Link %s gefunden" % args.link_weg)
                vorhandene = rest
            if args.link:
                vorhandene = vorhandene + [{"name": args.link[0], "url": args.link[1]}]
            daten["links"] = links.pruefe(vorhandene)
            konfig.speichere(args.daten, daten)
            print("Heim-Link %s." % ("entfernt" if args.link_weg and not args.link else "gespeichert"))
        if args.links:
            for l in links.pruefe(daten.get("links")):
                print("  [%s] %-24s %s" % (l["gruppe"], l["name"], l["url"]))
        if args.ab18:
            daten[anbieter.AB18] = args.ab18 == "an"
            konfig.speichere(args.daten, daten)
            print("Inhalte ab 18 %s. Laufenden Server neu starten." % ("freigegeben" if daten[anbieter.AB18]
                                                                       else "gesperrt"))
        if args.anbieter:
            anbieter_ausgeben(anbieter.liste(module, daten))
            print("Ab 18: %s" % ("freigegeben" if daten.get(anbieter.AB18) is True
                                 else "gesperrt (freigeben mit --ab18 an)"))
        elif args.anbieter_neu or args.anmelden:
            print("Laufenden Server neu starten, damit er die Zugangsdaten uebernimmt.")
    except (OSError, konfig.DatenFehler, anbieter.AnbieterFehler, livetv.LiveTvFehler, links.LinkFehler) as e:
        print("Fehler: %s" % e)
        return 1
    except (EOFError, KeyboardInterrupt):
        print("\nAbgebrochen, nichts gespeichert.")
        return 1
    return 0


