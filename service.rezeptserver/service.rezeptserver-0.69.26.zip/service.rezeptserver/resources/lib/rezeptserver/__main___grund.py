"""Start auf PC oder Raspberry Pi: python3 -m rezeptserver --help.
Grundlage: Importe und Logger (rezeptserver.__main__.*); die echte Entry-Funktion main liegt in __main__.py."""


import argparse
import getpass
import json
import logging
import os
import threading

from . import anbieter, anbindungen, debrid, konfig, links, livetv, vorlagen, vxparser
from .dienst import Dienst
from .kette import Kette
from .modul import lade_ordner

log = logging.getLogger("rezeptserver")
