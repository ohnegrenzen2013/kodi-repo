"""Selbsttest: Rezepte ueber Suchtext oder IMDb-ID pruefen."""

from .__main___grund import (
    Kette,
    anbieter,
    konfig,
    lade_ordner,
    logging,
)

def selbsttest_starten(args):
    from .selbsttest import lauf

    logging.getLogger("rezeptserver").setLevel(logging.WARNING)
    daten = konfig.lade(args.daten)
    kette = Kette(anbieter.freigegeben(lade_ordner(args.rezepte), daten), daten.get("einstellungen"),
                  daten.get("zeitgrenzen"))
    try:
        streams = lauf(kette, text=args.test, imdb=args.imdb, typ="series" if args.serie else "movie",
                       jahr=args.jahr, konfig_pfad=konfig.datenbank_pfad(args.daten))
    finally:
        kette.schliessen()
    return 0 if streams else 1


