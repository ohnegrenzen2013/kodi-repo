"""Sicherung: einlesen, exportieren (verschluesselt) und Neustart nach der Aktualisierung."""

from .__main___grund import (
    getpass,
    konfig,
    logging,
    os,
)

def sicherung_starten(args):
    db = konfig.datenbank_pfad(args.daten)
    try:
        if args.einlesen:
            passwort = None
            with open(args.einlesen, encoding="utf-8") as f:
                if konfig.ist_verschluesselt(f.read()):
                    passwort = getpass.getpass("Passwort der Sicherung: ")
            anzahl = konfig.importiere(args.daten, args.einlesen, args.zusammenfuehren, passwort)
            print("%s eingelesen (%d Einstellungen) -> %s" % (args.einlesen, anzahl, os.path.abspath(db)))
            print("Laufenden Server neu starten, damit er die Daten uebernimmt.")
        if args.export:
            passwort = None
            if args.verschluesseln:
                passwort = getpass.getpass("Passwort fuer die Sicherung (mind. 8 Zeichen): ")
                if len(passwort) < 8 or passwort != getpass.getpass("Noch einmal: "):
                    print("Fehler: Passwort zu kurz oder nicht gleich")
                    return 1
            konfig.exportiere(args.daten, args.export, passwort)
            print("Alle Nutzerdaten aus %s gesichert -> %s" % (os.path.abspath(db), os.path.abspath(args.export)))
            print("Verschluesselt, Passwort gut aufheben." if passwort else
                  "Die Datei enthaelt Passwoerter im Klartext, sicher aufbewahren (oder --verschluesseln).")
    except (OSError, konfig.DatenFehler) as e:
        print("Fehler: %s" % e)
        return 1
    return 0


def aktualisierung_vorziehen(args, argv):
    """Systemweite Aktualisierung: liegt im Datenordner eine neuere Fassung aus GitHub, damit neu starten.
    Danach darf sich der Server nach einer Aktualisierung selbst neu starten (PC, Pi-Dienst)."""
    import sys
    from . import aktualisierung
    argumente = list(sys.argv[1:] if argv is None else argv)
    datenordner = os.path.dirname(os.path.abspath(konfig.datenbank_pfad(args.daten)))

    def neu_starten(ordner=None):
        ordner = ordner or aktualisierung.bevorzugt(datenordner)
        logging.getLogger("rezeptserver").info("Neustart%s", " mit " + ordner if ordner else "")
        if ordner:
            code = ("import sys, runpy; sys.path.insert(0, sys.argv.pop(1)); "
                    "runpy.run_module('rezeptserver', run_name='__main__', alter_sys=True)")
            os.execv(sys.executable, [sys.executable, "-c", code, ordner] + argumente)
        os.execv(sys.executable, [sys.executable, "-m", "rezeptserver"] + argumente)

    ordner = aktualisierung.bevorzugt(datenordner)
    if ordner:
        neu_starten(ordner)
    aktualisierung.NEUSTART = neu_starten


