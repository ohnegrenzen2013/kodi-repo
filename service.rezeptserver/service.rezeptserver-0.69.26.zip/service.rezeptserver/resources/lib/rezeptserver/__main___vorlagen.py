"""Vorlagen und eigene Anbieter per JSON oder vxparser-Link, Pruefen, Freischalten."""

from .__main___grund import (
    anbieter,
    anbindungen,
    debrid,
    json,
    konfig,
    lade_ordner,
    logging,
    os,
    vorlagen,
    vxparser,
)

from .__main___anbieter import _zugang_abfragen

def vorlagen_starten(args):
    logging.getLogger("rezeptserver").setLevel(logging.WARNING)
    module = lade_ordner(args.rezepte)
    try:
        daten = konfig.lade(args.daten)
        if args.vorlagen:
            kategorie = None
            for v in vorlagen.liste():
                if v["kategorie"] != kategorie:
                    kategorie = v["kategorie"]
                    print(v["kategorie_name"])
                print("  %-28s %-34s %s" % (v["id"], v["name"], v["anmeldung_name"]))
        if args.anbieter_vorlage:
            v = vorlagen.NACH_ID.get(args.anbieter_vorlage)
            if not v:
                raise vorlagen.VorlagenFehler("Unbekannte Vorlage: %s (siehe --vorlagen)" % args.anbieter_vorlage)
            felder = [dict(f, wert=v["werte"].get(f["key"], "")) for f in anbieter.FELDER[v["anmeldung"]]]
            neu = vorlagen.anlegen(daten, module, v["id"], _zugang_abfragen(felder), args.name)
            konfig.speichere(args.daten, daten)
            print("Anbieter %s aus Vorlage %s angelegt." % (neu, v["name"]))
        if args.anbieter_json:
            quelle = args.anbieter_json
            if quelle.lower().startswith(("http://", "https://", "stremio://")):
                roh, adresse = vorlagen.holen_json(quelle)
                adresse = vorlagen.manifest_adresse(adresse) if vorlagen.ist_manifest(roh) and not vorlagen.ist_mhub_manifest(roh) else adresse
            else:
                with open(quelle, encoding="utf-8") as f:
                    roh, adresse = vorlagen.aus_text(f.read()), None
            neu = vorlagen.einlesen(daten, module, roh, adresse)
            konfig.speichere(args.daten, daten)
            print("Hinzugefuegt: %s" % (", ".join(neu) or "nichts"))
        if args.vx_link:
            schluessel, url = args.vx_link
            if schluessel not in vxparser.SCHLUESSEL:
                raise vorlagen.VorlagenFehler("Unbekannter vxparser-Link: %s (siehe --vx-links)" % schluessel)
            vorhanden = next((i for i, e in daten["anbieter"].items()
                              if e.get("vorlage") == vxparser.link_vorlage(schluessel)), None)
            if url.strip():
                vorlagen.anlegen(daten, module, vxparser.link_vorlage(schluessel), {"url": url.strip()})
            elif vorhanden:
                anbieter.entfernen(daten, vorhanden)
            konfig.speichere(args.daten, daten)
            print("vxparser-Link %s %s." % (schluessel, "gesetzt" if url.strip() else "auf Standard"))
        if args.vx_links:
            for l in vxparser.links_uebersicht(daten):
                print("  %-22s %s%s" % (l["schluessel"], l["wert"] or l["standard"] or "-", "  (eigen)" if l["wert"] else ""))
            print("In vxparser als url_list eintragen: http://<h0rst-adresse>/vxparser/urls.json")
        if args.anbieter_export:
            text = json.dumps(vorlagen.ausgeben(daten, args.mit_passwoertern), indent=2, ensure_ascii=False)
            fd = os.open(args.anbieter_export, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
            with os.fdopen(fd, "w", encoding="utf-8") as f:
                f.write(text + "\n")
            print("%d eigene Anbieter -> %s%s" % (len(daten["anbieter"]), args.anbieter_export,
                                               " (mit Passwoertern)" if args.mit_passwoertern else ""))
        if args.pruefen:
            eintrag = daten["anbieter"].get(args.pruefen)
            if not eintrag:
                raise anbieter.AnbieterFehler("%s ist kein eigener Anbieter" % args.pruefen)
            ok, meldung = anbindungen.pruefen(eintrag, {k: str(w) for k, w in
                                                        daten["einstellungen"].get(args.pruefen, {}).items()})
            print("%s: %s" % ("OK" if ok else "FEHLER", meldung))
            if not ok:
                return 1
        if args.freischalten:
            d = debrid.Debrid(debrid.konten(daten))
            if not d.verfuegbar:
                raise anbieter.AnbieterFehler("Kein Debrid-Konto mit API-Schluessel (--vorlagen, Kategorie Hoster & Debrid)")
            fehlgeschlagen = 0
            for link in args.freischalten:
                try:
                    r = d.freischalten(link)
                    print("%s\n  -> %s (%s%s)" % (link, r["url"], r["dienst"],
                                                  ", " + r["dateiname"] if r.get("dateiname") else ""))
                except (debrid.DebridFehler, OSError) as fehler:
                    fehlgeschlagen += 1
                    print("%s\n  FEHLER: %s" % (link, fehler))
            if fehlgeschlagen:
                return 1
        if args.anbieter_vorlage or args.anbieter_json or args.vx_link:
            print("Laufenden Server neu starten (die Oberflaeche uebernimmt Aenderungen sofort).")
    except (OSError, konfig.DatenFehler, anbieter.AnbieterFehler, vorlagen.VorlagenFehler) as e:
        print("Fehler: %s" % e)
        return 1
    except (EOFError, KeyboardInterrupt):
        print("\nAbgebrochen, nichts gespeichert.")
        return 1
    return 0


