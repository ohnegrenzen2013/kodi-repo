"""Bereich "Ab 18": Videoseiten fuer Erwachsene (xHamster, YouPorn, Pornhub, XVideos ...) in H0rSt.

Die Seiten-Module (seiten/) stammen unveraendert aus dem Kodi-Addon plugin.video.sexlist 1.3.0:
Listen ueber die offizielle API der Seite oder ihre offen lesbaren Listenseiten, Abspielen ueber die
API (RedGifs) oder yt-dlp. Statt requests und Kodi stellen http.py, kodiutils.py und resolver.py
dieselbe Schnittstelle bereit; neue Seiten aus dem Addon lassen sich so einfach mitnehmen.

H0rSt fuegt hinzu: Seiten ein-/ausschalten, Hoechstqualitaet, Suche ueber alle Seiten auf einmal,
Merkliste, Verlauf, letzte Suchen, beliebige Videoseite per Link (yt-dlp) und eine optionale PIN.
Nach dem Vorbild der App Blu Movies: Startseite mit dem Neuesten jeder Seite, Genres ueber alle
Seiten, Detailansicht mit Tags und aehnlichen Videos, Mindestlaenge (lange Videos/Filme).
Keine Werbung: H0rSt zeigt nie eine Seite selbst, nur Listen und das Video; Werbe-Hosts sind gesperrt.

NSFW/Ab 18 ist standardmäßig freigegeben (Zensur entfernt).
liefert der Bereich nichts. Alters- und einfache Bot-Schranken werden umgangen (Cookie-Bypass).
Die Einstellungen liegen in den Nutzerdaten unter "ab18_einstellungen".
"""

from .__init___grund import *
from .__init___grund import _FUELLWOERTER, _als_dict, _eigene, _ohne_werbung, _ordner, _passt, _seiten, _text, _video
from .__init___bereich import Ab18
