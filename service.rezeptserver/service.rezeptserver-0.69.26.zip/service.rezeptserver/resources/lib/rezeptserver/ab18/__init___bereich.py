"""Der Bereich selbst: Rezepte, Suche, Merkliste, PIN, Abspielen mit yt-dlp."""

from .__init___grund import (
    Ab18Fehler,
    Gesperrt,
    LAENGEN,
    MAX_MERKLISTE,
    MAX_SUCHEN,
    MAX_VERLAUF,
    OHNE_YTDLP,
    QUALITAETEN,
    SITZUNG,
    SUCH_TREFFER,
    ThreadPoolExecutor,
    _FUELLWOERTER,
    _als_dict,
    _eigene,
    _ohne_werbung,
    _ordner,
    _passt,
    _video,
    alle_seiten,
    http,
    pin_hash,
    pin_stimmt,
    pruefe,
    re,
    resolver,
    secrets,
    threading,
    time,
)

class Ab18:
    def __init__(self, freigegeben=True, einstellungen=None, speichern=None):
        # Standard: freigegeben (Zensur entfernt). Tests/Admin koennen den Bereich gezielt sperren.
        self.freigegeben = bool(freigegeben)
        try:
            self.einstellungen = pruefe(einstellungen)
        except Ab18Fehler:
            self.einstellungen = pruefe(None)
        self._speichern = speichern
        self._sperre = threading.Lock()
        self._sitzungen = {}

    # --- Zugang ------------------------------------------------------------------------
    @property
    def mit_pin(self):
        return bool(self.einstellungen["pin"])

    def entsperrt(self, schluessel):
        if not self.freigegeben:
            return False
        if not self.mit_pin:
            return True
        with self._sperre:
            ablauf = self._sitzungen.get(str(schluessel or ""))
        return bool(ablauf and ablauf > time.time())

    def pruefen(self, schluessel):
        if not self.freigegeben:
            raise Gesperrt("Ab 18 ist nicht freigegeben")
        if not self.entsperrt(schluessel):
            raise Gesperrt("PIN nötig")

    def entsperren(self, pin):
        if not self.freigegeben:
            raise Gesperrt("Ab 18 ist nicht freigegeben")
        if self.mit_pin and not pin_stimmt(pin, self.einstellungen["pin"]):
            time.sleep(1)  # bremst Durchprobieren
            raise Gesperrt("PIN falsch")
        schluessel = secrets.token_urlsafe(24)
        with self._sperre:
            jetzt = time.time()
            self._sitzungen = {k: a for k, a in self._sitzungen.items() if a > jetzt}
            self._sitzungen[schluessel] = jetzt + SITZUNG
        return schluessel

    def sperren(self):
        with self._sperre:
            self._sitzungen.clear()

    # --- Einstellungen -------------------------------------------------------------------
    def _sichern(self):
        if self._speichern:
            self._speichern(dict(self.einstellungen))

    def seite_aktiv(self, seite_id):
        return self.einstellungen["seiten"].get(seite_id, True)

    def alle(self):
        """Eingebaute und eigene Seiten (per Adresse hinzugefuegt)."""
        return alle_seiten() + [_eigene.EigeneSeite(e) for e in self.einstellungen["eigene"]]

    def seiten(self):
        return [s for s in self.alle() if self.seite_aktiv(s.id)]

    def seite(self, seite_id):
        s = next((x for x in self.alle() if x.id == str(seite_id or "")), None)
        if s is None:
            raise Ab18Fehler("Unbekannte Seite: %s" % seite_id)
        if not self.seite_aktiv(s.id):
            raise Ab18Fehler("%s ist ausgeschaltet" % s.name)
        return s

    def zustand(self, schluessel=None):
        offen = self.entsperrt(schluessel)
        antwort = {"freigegeben": self.freigegeben, "pin": self.mit_pin, "entsperrt": offen}
        if not offen:
            return antwort
        ytdlp = resolver.have_resolver()
        e = self.einstellungen
        antwort.update({
            "seiten": [{"id": s.id, "name": s.name, "aktiv": self.seite_aktiv(s.id), "eigen": isinstance(s, _eigene.EigeneSeite),
                        "abspielbar": ytdlp or s.id in OHNE_YTDLP} for s in self.alle()],
            "eigene": e["eigene"], "vorschlaege": _eigene.VORSCHLAEGE,
            "qualitaet": e["qualitaet"], "qualitaeten": list(QUALITAETEN),
            "min_dauer": e["min_dauer"], "laengen": list(LAENGEN),
            "ytdlp": ytdlp, "ytdlp_version": resolver.ytdlp_version() if ytdlp else "",
            "merkliste": e["merkliste"], "verlauf": e["verlauf"], "suchen": e["suchen"]})
        return antwort

    def einstellen(self, daten):
        with self._sperre:
            neu = dict(self.einstellungen)
            if "seiten" in daten:
                if not isinstance(daten["seiten"], dict):
                    raise Ab18Fehler("seiten muss ein Objekt sein")
                bekannt = {s.id for s in self.alle()}
                neu["seiten"] = dict(neu["seiten"])
                for k, v in daten["seiten"].items():
                    if k not in bekannt:
                        raise Ab18Fehler("Unbekannte Seite: %s" % k)
                    neu["seiten"][k] = bool(v)
            if "eigene" in daten:
                neu["eigene"] = daten["eigene"]
            if "qualitaet" in daten:
                neu["qualitaet"] = daten["qualitaet"]
            if "min_dauer" in daten:
                neu["min_dauer"] = daten["min_dauer"]
            if "pin_neu" in daten:
                if self.mit_pin and not pin_stimmt(daten.get("pin_alt", ""), self.einstellungen["pin"]):
                    raise Gesperrt("Bisherige PIN falsch")
                pin = str(daten.get("pin_neu") or "")
                if pin and (not pin.isdigit() or not 4 <= len(pin) <= 12):
                    raise Ab18Fehler("PIN: 4 bis 12 Ziffern")
                neu["pin"] = pin_hash(pin) if pin else ""
                self._sitzungen.clear()
            self.einstellungen = pruefe(neu)
        self._sichern()

    def merken(self, video, weg=False):
        video = _video(video)
        with self._sperre:
            liste = [v for v in self.einstellungen["merkliste"]
                     if (v["seite"], v["id"], v["url"]) != (video["seite"], video["id"], video["url"])]
            if not weg:
                liste.insert(0, video)
            self.einstellungen["merkliste"] = liste[:MAX_MERKLISTE]
        self._sichern()
        return self.einstellungen["merkliste"]

    def gesehen(self, video):
        video = _video(video)
        with self._sperre:
            liste = [v for v in self.einstellungen["verlauf"]
                     if (v["seite"], v["id"], v["url"]) != (video["seite"], video["id"], video["url"])]
            self.einstellungen["verlauf"] = [video] + liste[:MAX_VERLAUF - 1]
        self._sichern()

    def leeren(self, was):
        if was not in ("verlauf", "suchen", "merkliste"):
            raise Ab18Fehler("leeren: verlauf, suchen oder merkliste")
        with self._sperre:
            self.einstellungen[was] = []
        self._sichern()

    def _suche_merken(self, text):
        with self._sperre:
            liste = [s for s in self.einstellungen["suchen"] if s.lower() != text.lower()]
            self.einstellungen["suchen"] = [text] + liste[:MAX_SUCHEN - 1]
        self._sichern()

    # --- Inhalte -------------------------------------------------------------------------
    def menue(self, seite_id):
        s = self.seite(seite_id)
        return {"seite": s.id, "name": s.name, "ordner": [_ordner(f) for f in s.root()]}

    def kategorien(self, seite_id):
        s = self.seite(seite_id)
        gruppen = s.category_groups()
        if gruppen is None:
            gruppen = [("Kategorien", s.categories())]
        return {"seite": s.id, "gruppen": [{"name": name, "eintraege": [_ordner(f) for f in ordner]}
                                           for name, ordner in gruppen]}

    def videos(self, seite_id, reihenfolge=None, suche=None, kategorie=None, seite=1):
        s = self.seite(seite_id)
        try:
            seite = max(1, int(seite or 1))
        except (TypeError, ValueError):
            raise Ab18Fehler("seite muss eine Zahl sein")
        try:
            eintraege, weiter = s.videos(order=reihenfolge or None, query=suche or None,
                                         category=kategorie or None, page=seite)
        except http.HttpError as fehler:
            raise Ab18Fehler("%s: %s" % (s.name, fehler))
        alle = [_als_dict(s, v) for v in eintraege]
        videos = self._lang_genug(alle)
        return {"seite": s.id, "name": s.name, "videos": videos, "weiter": bool(weiter), "nummer": seite,
                "ausgeblendet": len(alle) - len(videos)}

    def _lang_genug(self, videos):
        """Mindestlaenge aus den Einstellungen (unbekannte Laenge faellt dann auch weg)."""
        grenze = self.einstellungen["min_dauer"] * 60
        return [v for v in videos if v["dauer"] >= grenze] if grenze else videos

    def _parallel(self, aufgaben):
        """aufgaben: [(seite, funktion(seite) -> (eintraege, weiter))]. Gleichzeitig, Fehler je Seite."""
        def eine(aufgabe):
            s, funktion = aufgabe
            try:
                eintraege, weiter = funktion(s)
                return {"seite": s.id, "name": s.name, "fehler": "", "weiter": bool(weiter),
                        "videos": self._lang_genug([_als_dict(s, v) for v in eintraege])}
            except Exception as fehler:  # eine Seite darf die anderen nicht aufhalten
                return {"seite": s.id, "name": s.name, "fehler": str(fehler)[:300], "weiter": False, "videos": []}
        if not aufgaben:
            return []
        with ThreadPoolExecutor(max_workers=min(8, len(aufgaben))) as pool:
            return list(pool.map(eine, aufgaben))

    def suche(self, text, seiten_ids=None):
        """Suche ueber alle eingeschalteten Seiten gleichzeitig (oder nur die genannten)."""
        text = " ".join(str(text or "").split())[:200]
        if not text:
            raise Ab18Fehler("Suchbegriff fehlt")
        ziel = [s for s in self.seiten() if not seiten_ids or s.id in seiten_ids]
        ergebnisse = self._parallel([(s, lambda s: s.videos(query=text, page=1)) for s in ziel])
        for e in ergebnisse:
            e["videos"] = e["videos"][:SUCH_TREFFER]
        self._suche_merken(text)
        return {"suche": text, "ergebnisse": ergebnisse}

    def start(self):
        """Startseite wie bei Blu Movies: je Seite eine Reihe mit dem Neuesten."""
        aufgaben = []
        for s in self.seiten():
            listen = [_ordner(f) for f in s.root() if f.params.get("action") == "list"]
            neu = next((o for o in listen if o["name"].startswith("Neu")), listen[0] if listen else None)
            if neu:
                aufgaben.append((s, lambda s, o=neu: s.videos(order=o.get("reihenfolge"), page=1)))
        reihen = self._parallel(aufgaben)
        for r in reihen:
            r["videos"] = r["videos"][:SUCH_TREFFER]
        return {"reihen": reihen}

    def _genre_karte(self):
        """Gleich benannte Kategorien aller eingeschalteten Seiten zusammengefasst: {name: eintrag}."""
        karte = {}
        for s in self.seiten():
            gruppen = s.category_groups()
            if gruppen is None:
                gruppen = [("Kategorien", s.categories())]
            for gruppe, ordner in gruppen:
                for f in ordner:
                    e = karte.setdefault(f.label, {"name": f.label, "gruppe": gruppe, "seiten": {}})
                    e["seiten"][s.id] = _ordner(f)
        return karte

    def genres(self):
        gruppen = {}
        for e in self._genre_karte().values():
            gruppen.setdefault(e["gruppe"], []).append({"name": e["name"], "seiten": list(e["seiten"])})
        return {"gruppen": [{"name": g, "genres": liste} for g, liste in gruppen.items()]}

    def genre(self, name, nummer=1):
        """Ein Genre von allen Seiten, die es haben, abwechselnd gemischt."""
        eintrag = self._genre_karte().get(str(name or ""))
        if eintrag is None:
            raise Ab18Fehler("Unbekanntes Genre: %s" % name)
        try:
            nummer = max(1, int(nummer or 1))
        except (TypeError, ValueError):
            raise Ab18Fehler("nummer muss eine Zahl sein")
        aufgaben = []
        for s in self.seiten():
            o = eintrag["seiten"].get(s.id)
            if o:
                aufgaben.append((s, lambda s, o=o: s.videos(query=o.get("suche"), category=o.get("kategorie"),
                                                            page=nummer)))
        ergebnisse = self._parallel(aufgaben)
        gemischt = []
        for runde in range(max([len(e["videos"]) for e in ergebnisse] or [0])):
            gemischt.extend(e["videos"][runde] for e in ergebnisse if runde < len(e["videos"]))
        return {"name": eintrag["name"], "videos": gemischt, "nummer": nummer,
                "weiter": any(e["weiter"] for e in ergebnisse),
                "fehler": [{"name": e["name"], "fehler": e["fehler"]} for e in ergebnisse if e["fehler"]]}

    def aehnlich(self, seite_id, titel, video_id=""):
        """Aehnliche Videos derselben Seite ueber die markanten Woerter des Titels."""
        s = self.seite(seite_id)
        woerter = [w for w in re.findall(r"[^\W\d_]{3,}", str(titel or "")) if w.lower() not in _FUELLWOERTER]
        if not woerter:
            return {"videos": []}
        try:
            eintraege, _ = s.videos(query=" ".join(woerter[:3]), page=1)
        except http.HttpError as fehler:
            raise Ab18Fehler("%s: %s" % (s.name, fehler))
        videos = [v for v in self._lang_genug([_als_dict(s, v) for v in eintraege]) if v["id"] != str(video_id)]
        return {"videos": videos[:SUCH_TREFFER]}

    # --- Abspielen -----------------------------------------------------------------------
    def aufloesen(self, seite_id, video_id="", seitenadresse=""):
        """Resolved fuer ein Video einer Seite: zuerst ueber deren API, sonst yt-dlp."""
        s = self.seite(seite_id)
        hoehe = self.einstellungen["qualitaet"]
        if seitenadresse and not _passt(s, seitenadresse):
            raise Ab18Fehler("Videoseite gehört nicht zu %s" % s.name)
        ergebnis = None
        if video_id:
            try:
                ergebnis = s.resolve(video_id, max_height=hoehe)
            except http.HttpError as fehler:
                if not seitenadresse:
                    raise Ab18Fehler("%s: %s" % (s.name, fehler))
        if ergebnis is None and seitenadresse:
            if not resolver.have_resolver():
                raise Ab18Fehler("Zum Abspielen von %s fehlt yt-dlp (pip install yt-dlp; in der App eingebaut, "
                                 "in Kodi script.module.yt-dlp)" % s.name)
            ergebnis = resolver.resolve(seitenadresse, max_height=hoehe)
        if ergebnis is None:
            raise Ab18Fehler("%s: keine abspielbare Adresse gefunden" % s.name)
        return _ohne_werbung(ergebnis)

    def link(self, adresse):
        """Beliebige Videoseite ueber yt-dlp (alle Seiten, die yt-dlp kennt)."""
        adresse = str(adresse or "").strip()
        if not adresse.lower().startswith(("http://", "https://")):
            raise Ab18Fehler("Adresse muss mit http(s):// beginnen")
        if http.is_ad_host(adresse):
            raise Ab18Fehler("Werbe-Host gesperrt")
        if not resolver.have_resolver():
            raise Ab18Fehler("Für Links fehlt yt-dlp (pip install yt-dlp; in der App eingebaut)")
        ergebnis = resolver.resolve(adresse, max_height=self.einstellungen["qualitaet"])
        if ergebnis is None:
            raise Ab18Fehler("yt-dlp hat auf dieser Seite kein Video gefunden")
        return _ohne_werbung(ergebnis)


