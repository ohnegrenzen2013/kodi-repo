"""Bereich "Ab 18": Grundlage: Importe, Konstanten, Ab18Fehler/Gesperrt und die Hilfen _text, _video, pruefe, pin_hash/pin_stimmt, alle_seiten, _ordner, _als_dict, _FUELLWOERTER, _ohne_werbung, _passt."""


import hashlib
import re
import hmac
import secrets
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlsplit

from . import http, resolver
from . import seiten as _seiten
from .seiten import eigene as _eigene

SCHLUESSEL = "ab18_einstellungen"
QUALITAETEN = (0, 480, 720, 1080)  # 0 = beste
LAENGEN = (0, 10, 20, 30, 60)  # Mindestlaenge in Minuten, 0 = alle
MAX_MERKLISTE = 500
MAX_VERLAUF = 100
MAX_SUCHEN = 30
SITZUNG = 12 * 3600
PIN_RUNDEN = 120000
SUCH_TREFFER = 24  # je Seite bei der Suche ueber alle Seiten

STANDARD = {"seiten": {}, "qualitaet": 0, "min_dauer": 0, "pin": "", "merkliste": [], "verlauf": [], "suchen": [],
            "eigene": []}
# Seiten, die ohne yt-dlp abspielen (eigene API liefert die Videoadresse)
OHNE_YTDLP = {"redgifs"}
VIDEO_FELDER = ("seite", "id", "titel", "url", "bild", "dauer")


class Ab18Fehler(ValueError):
    pass


class Gesperrt(Ab18Fehler):
    """Nicht freigegeben oder PIN noetig."""


def _text(wert, laenge=500):
    return str(wert if wert is not None else "")[:laenge]


def _video(eintrag):
    """Gespeicherte Form eines Videos (Merkliste, Verlauf): nur bekannte Felder, begrenzt."""
    if not isinstance(eintrag, dict):
        raise Ab18Fehler("Video muss ein Objekt sein")
    video = {"seite": _text(eintrag.get("seite"), 40), "id": _text(eintrag.get("id"), 200),
             "titel": _text(eintrag.get("titel"), 300), "url": _text(eintrag.get("url"), 1000),
             "bild": _text(eintrag.get("bild"), 1000)}
    try:
        video["dauer"] = max(0, int(eintrag.get("dauer") or 0))
    except (TypeError, ValueError):
        video["dauer"] = 0
    if not video["seite"] or not (video["id"] or video["url"]):
        raise Ab18Fehler("Video ohne Seite oder Kennung")
    if video["url"] and not video["url"].lower().startswith(("http://", "https://")):
        raise Ab18Fehler("Videoseite muss mit http(s):// beginnen")
    return video


def pruefe(einstellungen):
    """Bereinigte Einstellungen (fuer Nutzerdaten und Import)."""
    e = dict(STANDARD)
    if isinstance(einstellungen, dict):
        e.update({k: einstellungen[k] for k in STANDARD if k in einstellungen})
    if not isinstance(e["seiten"], dict):
        raise Ab18Fehler("seiten muss die Form {seite: true|false} haben")
    e["seiten"] = {str(k): bool(v) for k, v in e["seiten"].items()}
    try:
        e["qualitaet"] = int(e["qualitaet"] or 0)
    except (TypeError, ValueError):
        raise Ab18Fehler("qualitaet muss eine Zahl sein")
    if e["qualitaet"] not in QUALITAETEN:
        raise Ab18Fehler("qualitaet muss eine von %s sein" % ", ".join(map(str, QUALITAETEN)))
    try:
        e["min_dauer"] = int(e["min_dauer"] or 0)
    except (TypeError, ValueError):
        raise Ab18Fehler("min_dauer muss eine Zahl sein")
    if e["min_dauer"] not in LAENGEN:
        raise Ab18Fehler("min_dauer muss eine von %s sein" % ", ".join(map(str, LAENGEN)))
    e["pin"] = _text(e["pin"], 200)
    for name, grenze in (("merkliste", MAX_MERKLISTE), ("verlauf", MAX_VERLAUF)):
        if not isinstance(e[name], list):
            raise Ab18Fehler("%s muss eine Liste sein" % name)
        e[name] = [_video(v) for v in e[name]][:grenze]
    if not isinstance(e["suchen"], list):
        raise Ab18Fehler("suchen muss eine Liste sein")
    e["suchen"] = [_text(s, 200) for s in e["suchen"] if str(s).strip()][:MAX_SUCHEN]
    try:
        e["eigene"] = _eigene.pruefe(e["eigene"] or [])
    except ValueError as fehler:
        raise Ab18Fehler(str(fehler))
    return e


def pin_hash(pin, salz=None):
    salz = salz or secrets.token_hex(8)
    wert = hashlib.pbkdf2_hmac("sha256", pin.encode("utf-8"), salz.encode("ascii"), PIN_RUNDEN).hex()
    return "%s$%s" % (salz, wert)


def pin_stimmt(pin, gespeichert):
    salz, _, wert = str(gespeichert or "").partition("$")
    if not salz or not wert:
        return False
    return hmac.compare_digest(pin_hash(str(pin or ""), salz), gespeichert)


def alle_seiten():
    return _seiten.all_sites()


def _ordner(folder):
    """Folder aus dem Seiten-Modul -> Eintrag fuer die Oberflaeche."""
    p = folder.params
    art = {"list": "liste", "categories": "kategorien", "search": "suche"}.get(p.get("action"), p.get("action"))
    eintrag = {"name": folder.label, "art": art}
    for quelle, ziel in (("order", "reihenfolge"), ("query", "suche"), ("category", "kategorie")):
        if p.get(quelle):
            eintrag[ziel] = p[quelle]
    return eintrag


def _als_dict(seite, v):
    return {"seite": seite.id, "seite_name": seite.name, "id": v.video_id, "titel": v.title, "url": v.page_url,
            "bild": "" if http.is_ad_host(v.thumb) else v.thumb, "dauer": v.duration, "bewertung": round(v.rating, 1), "aufrufe": v.views,
            "datum": v.date, "info": v.plot[:300] if v.plot else "",
            "vorschau": [b for b in (getattr(v, "previews", None) or []) if not http.is_ad_host(b)][:12],
            "vorschau_video": "" if http.is_ad_host(getattr(v, "preview_video", "") or "") else (getattr(v, "preview_video", "") or "")}


_FUELLWOERTER = {"the", "and", "with", "her", "his", "for", "from", "get", "gets", "got", "she", "him", "you",
                 "your", "who", "while", "after", "into", "this", "that", "der", "die", "das", "und", "mit", "von",
                 "video", "videos", "porn", "sex", "xxx", "hot", "best", "new", "full", "free"}


def _ohne_werbung(ergebnis):
    """Keine Werbung in H0rSt: eine Videoadresse bei einem Werbe-Host wird nicht abgespielt."""
    if http.is_ad_host(ergebnis.url):
        raise Ab18Fehler("Die Seite liefert statt des Videos Werbung; H0rSt spielt das nicht ab")
    return ergebnis


def _passt(seite, adresse):
    """Videoseite gehoert zur Seite (auch Laenderdomains wie xhamster.desi oder de.xhamster.com)."""
    teile = urlsplit(adresse)
    host = (teile.hostname or "").lower()
    if isinstance(seite, _eigene.EigeneSeite):
        eigen = seite.host.replace("www.", "")
        return teile.scheme in ("http", "https") and (host.replace("www.", "") == eigen or host.endswith("." + eigen))
    return teile.scheme in ("http", "https") and seite.id in host.replace("-", "")
