"""Netz fuer die Seiten-Module: dieselbe Schnittstelle wie in plugin.video.sexlist (get, get_json,
is_ad_host, HttpError, ChallengeError), aber nur mit der Standardbibliothek wie der Rest von H0rSt.

Bewusst ohne Umgehung von Schutzseiten: antwortet eine Seite mit einer Bot-Abfrage (Cloudflare o. a.),
wird das als ChallengeError gemeldet und nicht ausgetrickst.

Jede Adresse (auch nach einer Weiterleitung) wird ueber netz.ip_oeffentlich_pruefen() geprueft - wichtig
fuer "Eigene Seiten" (eigene.py), wo die Adresse direkt vom Nutzer kommt; private/interne Ziele sind
gesperrt, auch fuer die eingebauten Seiten unschaedlich, da deren Domains immer oeffentlich sind.
"""

import json
import urllib.error
import urllib.request
from urllib.parse import urlencode, urljoin, urlsplit

from .. import netz

# manche CDNs lehnen Programm-Kennungen ab; das ist die Kennung eines normalen Browsers, keine Tarnung
DEFAULT_UA = ("Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
              "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36")
TIMEOUT = 25
MAX_BYTES = 8 * 1024 * 1024
MAX_WEITERLEITUNGEN = 5

# bekannte Werbe-, Tracking- und Umleitungs-Hosts dieser Seiten (Teilstring)
AD_HOSTS = (
    'rmhfrtnd.com', 'doubleclick.net', 'googlesyndication.com', 'google-analytics.com',
    'googletagmanager.com', 'adnxs.com', 'exoclick.com', 'exosrv.com', 'juicyads.com',
    'trafficjunky.com', 'trafficjunky.net', 'popads.net', 'popcash.net', 'propellerads.com',
    'adsterra.com', 'hilltopads.net', 'adskeeper.com', 'mgid.com', 'outbrain.com',
    'taboola.com', 'pornquick.com', 'camszone.com', 'go.rmhfrtnd.com', 'tsyndicate.com',
    'realsrv.com', 'a-ads.com', 'clickadu.com', 'bidvertiser.com',
)


class HttpError(Exception):
    pass


class ChallengeError(HttpError):
    """Die Seite antwortet mit einer Bot-Abfrage; die wird nicht umgangen."""


class Antwort:
    """Das Wenige von requests.Response, das die Seiten-Module brauchen."""

    def __init__(self, status_code, inhalt, headers, url):
        self.status_code = status_code
        self.content = inhalt
        self.headers = headers
        self.url = url

    @property
    def text(self):
        zeichensatz = "utf-8"
        if self.headers is not None and hasattr(self.headers, "get_content_charset"):
            zeichensatz = self.headers.get_content_charset() or "utf-8"
        return self.content.decode(zeichensatz, errors="replace")

    def json(self):
        return json.loads(self.text)


def is_ad_host(url):
    url = (url or '').lower()
    return any(h in url for h in AD_HOSTS)


def _holen(url, kopf):
    """Ein Abruf ohne automatische Weiterleitung: (status, inhalt, header, ziel).

    Die Verbindung geht an die in get() gepruefte Adresse, der Name wird nicht noch einmal aufgeloest."""
    try:
        with netz.oeffentlich_oeffnen(urllib.request.Request(url, headers=kopf), timeout=TIMEOUT) as antwort:
            inhalt = antwort.read(MAX_BYTES + 1)
            if len(inhalt) > MAX_BYTES:
                raise HttpError('Antwort zu groß: %s' % url)
            return antwort.status, inhalt, antwort.headers, None
    except urllib.error.HTTPError as fehler:
        try:
            inhalt = fehler.read(64 * 1024)
        except OSError:
            inhalt = b''
        finally:
            fehler.close()
        return fehler.code, inhalt, fehler.headers, fehler.headers.get('Location') if fehler.headers else None


def _pruefe_abfrage(status, inhalt, headers):
    if status in (403, 503):
        marke = ((headers.get('cf-mitigated') if headers is not None else '') or '').lower()
        anfang = inhalt[:500].decode('utf-8', 'replace').lower()
        if marke == 'challenge' or 'cf-challenge' in anfang or 'just a moment' in anfang:
            raise ChallengeError('Die Seite verlangt eine Bot-Prüfung. H0rSt umgeht solchen Schutz nicht.')


def get(url, params=None, headers=None, referer=None):
    if params:
        url += ('&' if '?' in url else '?') + urlencode(params)
    kopf = {'User-Agent': DEFAULT_UA, 'Accept-Language': 'en-US,en;q=0.9'}
    if referer:
        kopf['Referer'] = referer
    kopf.update(headers or {})
    for _ in range(MAX_WEITERLEITUNGEN + 1):
        if is_ad_host(url):
            raise HttpError('Werbe-Host gesperrt: %s' % url)
        if urlsplit(url).scheme not in ("http", "https"):
            raise HttpError('Adresse mit fremdem Schema abgelehnt: %s' % url.split('?')[0])
        try:
            netz.ip_oeffentlich_pruefen(url)
        except netz.NichtOeffentlich as fehler:
            raise HttpError(str(fehler))
        try:
            status, inhalt, antwort_kopf, ziel = _holen(url, kopf)
        except HttpError:
            raise
        except (urllib.error.URLError, OSError, ValueError) as fehler:
            raise HttpError('Abruf fehlgeschlagen: %s' % fehler)
        if status in (301, 302, 303, 307, 308) and ziel:
            url = urljoin(url, ziel)
            continue
        _pruefe_abfrage(status, inhalt, antwort_kopf)
        if status >= 400:
            raise HttpError('HTTP %s bei %s' % (status, url.split('?')[0]))
        return Antwort(status, inhalt, antwort_kopf, url)
    raise HttpError('Zu viele Weiterleitungen: %s' % url)


def get_json(url, params=None, headers=None, referer=None):
    antwort = get(url, params=params, headers=headers, referer=referer)
    try:
        return antwort.json()
    except ValueError:
        raise HttpError('JSON erwartet, aber etwas anderes bekommen von %s' % url.split('?')[0])
