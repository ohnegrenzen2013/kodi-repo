"""Ersatz fuer die Kodi-Helfer der Seiten-Module: nur Protokoll und Einstellungen."""

import logging

log_ = logging.getLogger("rezeptserver")
_STUFEN = {0: logging.DEBUG, 1: logging.INFO, 2: logging.WARNING, 3: logging.ERROR}


def log(text, stufe=1):
    log_.log(_STUFEN.get(stufe, logging.INFO), "Ab 18: %s", text)


def setting(name, standard=""):
    return standard
