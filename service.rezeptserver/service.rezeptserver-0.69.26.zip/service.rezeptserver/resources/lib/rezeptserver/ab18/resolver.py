"""Stream-Adresse zu einer Videoseite: ueber die eigene API der Seite (RedGifs) oder ueber yt-dlp.

yt-dlp ist optional (pip install yt-dlp; in der App eingebaut, in Kodi script.module.yt-dlp). Es bekommt
die oeffentliche Videoseite und liefert die Adresse des Videos; Werbung, Pop-ups und Vorspann der Seite
kommen so nie beim Player an. Geschuetzte Endpunkte der Seiten baut H0rSt nicht nach.
"""

import urllib.error
import urllib.request

from . import http, kodiutils

MAX_PROBEN = 4  # so viele Fassungen werden hoechstens angefragt


def _ytdlp():
    try:
        from yt_dlp import YoutubeDL
        return YoutubeDL
    except Exception:
        return None


def have_resolver():
    return _ytdlp() is not None


def ytdlp_version():
    try:
        from yt_dlp.version import __version__
        return __version__
    except Exception:
        return ""


class Resolved(object):
    __slots__ = ('url', 'headers', 'is_hls', 'mime', 'height')

    def __init__(self, url, headers=None, is_hls=False, mime='', height=0):
        self.url = url
        self.headers = headers or {}
        self.is_hls = is_hls
        self.mime = mime
        self.height = int(height or 0)


def _ist_hls(f):
    return 'm3u8' in (f.get('protocol') or '').lower() or (f.get('url') or '').split('?')[0].endswith('.m3u8')


def _candidates(info, max_height):
    """Fassungen bis max_height, beste zuerst. Bei gleicher Hoehe gewinnt eine einzelne Datei (MP4) vor
    HLS, weil sie in jedem Browser laeuft und ueber H0rSt samt Referer weitergereicht werden kann."""
    formats = info.get('formats') or []
    if not formats:
        if info.get('url'):
            return [{'url': info['url'], 'protocol': info.get('protocol', ''),
                     'http_headers': info.get('http_headers', {}), 'height': info.get('height') or 0}]
        return []

    def ok(f):
        if not f.get('url') or f.get('vcodec') == 'none':  # ohne Bild (nur Ton)
            return False
        if f.get('acodec') == 'none' and f.get('vcodec') not in (None, '') and any(
                x.get('acodec') not in (None, 'none') for x in formats if x.get('vcodec') != 'none'):
            return False  # stummes Videostueck, wenn es Fassungen mit Ton gibt
        h = f.get('height') or 0
        return max_height <= 0 or h <= max_height

    kandidaten = [f for f in formats if ok(f)] or [f for f in formats if f.get('url')]
    kandidaten.sort(key=lambda f: (f.get('height') or 0, not _ist_hls(f), f.get('tbr') or 0), reverse=True)
    return kandidaten


def _pick_format(info, max_height):
    kandidaten = _candidates(info, max_height)
    return kandidaten[0] if kandidaten else None


def _erreichbar(url, kopf):
    """Kurze Probe (1 Byte): manche Seiten nennen Dateien, die laengst weg sind (YouPorn/RedTube: 410)."""
    kopf = dict(kopf or {})
    kopf.setdefault('User-Agent', http.DEFAULT_UA)
    kopf['Range'] = 'bytes=0-0'
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers=kopf), timeout=8) as antwort:
            return antwort.status < 400
    except urllib.error.HTTPError as fehler:
        fehler.close()
        return fehler.code == 416  # Bereich nicht erfuellbar, die Datei gibt es aber
    except (urllib.error.URLError, OSError, ValueError):
        return False


def _choose(info, max_height):
    """Erste erreichbare Fassung; antwortet keine, die beste (der Player soll es selbst versuchen)."""
    kandidaten = _candidates(info, max_height)
    for f in kandidaten[:MAX_PROBEN]:
        if _erreichbar(f['url'], f.get('http_headers') or info.get('http_headers')):
            return f
        kodiutils.log('Fassung nicht erreichbar, nehme die naechste: %s' % f['url'].split('?')[0], 1)
    return kandidaten[0] if kandidaten else None


def resolve(page_url, max_height=0):
    """Resolved oder None (yt-dlp fehlt oder findet nichts)."""
    if http.is_ad_host(page_url):
        kodiutils.log('Werbe-Host wird nicht aufgeloest: %s' % page_url, 2)
        return None
    YoutubeDL = _ytdlp()
    if YoutubeDL is None:
        return None
    optionen = {'quiet': True, 'no_warnings': True, 'noplaylist': True, 'skip_download': True,
                'user_agent': http.DEFAULT_UA}
    from .. import sicherheit
    try:
        proxy = sicherheit.NETZWEG.ytdlp_proxy()  # yt-dlp baut eigene Verbindungen: Netzweg mitgeben
    except sicherheit.Gesperrt as fehler:
        kodiutils.log(str(fehler), 2)
        return None
    if proxy:
        optionen['proxy'] = proxy
    try:
        with YoutubeDL(optionen) as ydl:
            info = ydl.extract_info(page_url, download=False)
    except Exception as fehler:
        kodiutils.log('yt-dlp fehlgeschlagen fuer %s: %s' % (page_url, fehler), 2)
        return None
    if not info:
        return None
    if 'entries' in info:  # Playlist -> erster Eintrag
        eintraege = [e for e in info['entries'] if e]
        if not eintraege:
            return None
        info = eintraege[0]
    fmt = _choose(info, max_height)
    if not fmt or not fmt.get('url'):
        return None
    kopf = dict(fmt.get('http_headers') or info.get('http_headers') or {})
    kopf.setdefault('User-Agent', http.DEFAULT_UA)
    return Resolved(url=fmt['url'], headers=kopf, is_hls=_ist_hls(fmt), height=fmt.get('height') or 0)
