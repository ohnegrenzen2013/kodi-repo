# -*- coding: utf-8 -*-
"""Registry of available sites.

To add a site: create ``sites/<name>.py`` exposing a module-level ``SITE``
instance of a :class:`base.Site` subclass, then import and register it here.
The main menu and all routing pick it up automatically.
"""
from .eporner import SITE as _eporner
from .redtube import SITE as _redtube
from .pornhub import SITE as _pornhub
from .redgifs import SITE as _redgifs
from .xhamster import SITE as _xhamster
from .xvideos import SITE as _xvideos
from .xnxx import SITE as _xnxx
from .youporn import SITE as _youporn

# Order here is the order shown in the main menu.
_REGISTRY = [
    _eporner,
    _redtube,
    _pornhub,
    _redgifs,
    _xhamster,
    _xvideos,
    _xnxx,
    _youporn,
    # Add more sites here. Prefer ones with an official API or plainly readable
    # listings; no protection-bypass modules.
]

_BY_ID = {s.id: s for s in _REGISTRY}


def all_sites():
    return list(_REGISTRY)


def get(site_id):
    return _BY_ID.get(site_id)
