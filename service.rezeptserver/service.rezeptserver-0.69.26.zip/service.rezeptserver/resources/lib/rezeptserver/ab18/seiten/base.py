# -*- coding: utf-8 -*-
"""Common interface every site module implements.

Adding a new site = adding one module that subclasses ``Site`` and registers
itself in ``sites/__init__.py``. The router never needs to change.
"""


def _zahl(wert, art, standard):
    """int()/float() gegen kaputte Werte aus der Antwort einer fremden Seite (z. B. "n/a" statt einer Zahl)
    absichern - ein einzelner Treffer mit so einem Feld darf nicht die ganze Trefferliste abbrechen."""
    try:
        return art(wert or standard)
    except (TypeError, ValueError):
        return standard


class VideoItem(object):
    """A single playable video as the router expects it."""

    __slots__ = ('site_id', 'video_id', 'title', 'page_url', 'thumb',
                 'duration', 'plot', 'rating', 'views', 'date', 'previews', 'preview_video')

    def __init__(self, site_id, video_id, title, page_url, thumb='',
                 duration=0, plot='', rating=0.0, views=0, date='', previews=None, preview_video=''):
        self.site_id = site_id
        self.video_id = video_id
        self.title = title
        self.page_url = page_url          # the public watch page; resolved at play time
        self.thumb = thumb
        self.duration = _zahl(duration, int, 0)  # seconds
        self.plot = plot
        self.rating = _zahl(rating, float, 0.0)  # 0..10
        self.views = _zahl(views, int, 0)
        self.date = date                   # 'YYYY-MM-DD' if known
        self.previews = list(previews or [])  # more frames for a moving preview
        self.preview_video = preview_video    # short muted clip, if the site offers one


class Folder(object):
    """A navigable folder entry shown in a site's menus."""

    __slots__ = ('label', 'params', 'thumb')

    def __init__(self, label, params, thumb=''):
        self.label = label
        self.params = params   # dict merged into the plugin:// URL
        self.thumb = thumb


class Site(object):
    # subclasses set these
    id = ''
    name = ''
    needs_login = False

    # ---- menus -------------------------------------------------------------
    def root(self):
        """Top-level folders for this site (Newest, Top, Categories, Search...).
        Return a list of :class:`Folder`."""
        raise NotImplementedError

    def categories(self):
        """Return a flat list of :class:`Folder` (one per category).

        Used only when :meth:`category_groups` returns ``None``.
        """
        return []

    def category_groups(self):
        """Optional grouped categories.

        Return a list of ``(group_label, [Folder, ...])`` tuples, or ``None`` to
        use the flat :meth:`categories` instead.
        """
        return None

    # ---- listings ----------------------------------------------------------
    def videos(self, order=None, query=None, category=None, page=1):
        """Return ``(items, has_next)`` where items is a list of :class:`VideoItem`."""
        raise NotImplementedError

    # ---- playback ----------------------------------------------------------
    def resolve(self, video_id, max_height=0):
        """Optional direct stream lookup through the site's own API.

        Return a :class:`resources.lib.resolver.Resolved`, or ``None`` to let
        the router fall back to yt-dlp on the public watch page.
        """
        return None
