# -*- coding: utf-8 -*-
"""Eigene Seiten fuer "Ab 18": eine Videoseite per Adresse hinzufuegen, ohne Programmieren.

Eine eigene Seite besteht aus Name, Startadresse (Liste mit dem Neuesten) und optional einer Such-Adresse mit
{q} fuer den Suchbegriff und {seite} fuer die Seitenzahl. H0rSt liest aus der Listenseite die Links, die ein
Vorschaubild enthalten und nach einer Videoseite aussehen (oder zum eigenen Muster passen), samt Titel, Bild und
Laenge. Abgespielt wird die Videoseite ueber yt-dlp, das die meisten Videoseiten kennt.

Noch einfacher: nur eine Adresse eingeben (erkennen()). H0rSt ruft sie ab und findet selbst Name, Videoliste,
Seitenzahlen ({seite}) und Suche (Suchformular oder OpenSearch). Liefert die Adresse JSON (eine API, z. B. die
Webmaster-API einer Seite), sucht H0rSt darin die Liste und die Felder fuer Link, Titel, Bild und Dauer ("art": "json").

Gespeichert in den Ab-18-Einstellungen unter "eigene": [{"id", "name", "start", "suche", "muster", "art", "felder"}] –
damit in den Nutzerdaten und in jeder Sicherung.
Bot-Schranken (Cloudflare u. a.) werden nicht umgangen; solche Seiten melden einen Fehler.
"""
import html
import json
import re
from urllib.parse import parse_qsl, quote_plus, urlencode, urljoin, urlsplit, urlunsplit

from .. import http
from .base import Folder, Site, VideoItem
from .eigene_json import *  # noqa: F403
from .eigene_json import _PFAD, _dauer  # noqa: F401


# so sehen Videoseiten meist aus: /video/…, /videos/…, /watch/…, view_video.php?viewkey=…, /v/…, /embed/…
STANDARD_MUSTER = r"/(video|videos|watch|view_video|movies?|v|clip|clips|embed)[/\-_.=?]|/\d{4,}[/\-]|[?&](viewkey|v|id)="
_LINK = re.compile(r"<a\s([^>]*?)href\s*=\s*[\"']([^\"'#]+)[\"']([^>]*)>(.*?)</a>", re.I | re.S)
_BILD = re.compile(r"<img\s[^>]*?(?:data-src|data-original|data-thumb|data-lazy-src|data-mediumthumb|src)\s*=\s*[\"']([^\"']+\.(?:jpe?g|png|webp|gif)[^\"']*)[\"']", re.I)
_ATTR = re.compile(r"(?:title|alt|aria-label)\s*=\s*[\"']([^\"']{3,300})[\"']", re.I)
_ID = re.compile(r"[^a-z0-9]")


def kennung(name):
    return "eigen_" + (_ID.sub("", str(name or "").lower())[:20] or "seite")




def videos_lesen(seite_html, basis, muster=None, site_id="eigen"):
    """Listenseite -> [VideoItem]: Links mit Vorschaubild, die nach einer Videoseite aussehen."""
    muster = re.compile(muster or STANDARD_MUSTER, re.I)
    host = (urlsplit(basis).hostname or "").lower().replace("www.", "")
    gesehen, ergebnis = set(), []
    for m in _LINK.finditer(seite_html):
        attribute, innen = m.group(1) + " " + m.group(3), m.group(4)
        bild = _BILD.search(innen)
        if not bild:
            continue
        ziel = urljoin(basis, html.unescape(m.group(2)).strip())
        zhost = (urlsplit(ziel).hostname or "").lower().replace("www.", "")
        if not ziel.startswith(("http://", "https://")) or (zhost != host and not zhost.endswith("." + host)):
            continue
        if not muster.search(urlsplit(ziel).path + ("?" + urlsplit(ziel).query if urlsplit(ziel).query else "")):
            continue
        if ziel in gesehen or http.is_ad_host(ziel):
            continue
        gesehen.add(ziel)
        titel = _ATTR.search(attribute) or _ATTR.search(innen)
        titel = html.unescape(titel.group(1)).strip() if titel else \
            " ".join(html.unescape(re.sub(r"<[^>]+>", " ", innen)).split())[:200]
        if not titel:
            titel = urlsplit(ziel).path.rstrip("/").rsplit("/", 1)[-1].replace("-", " ").replace("_", " ")[:200]
        umgebung = re.sub(r"<[^>]+>", " ", seite_html[max(0, m.start() - 50):m.end() + 300])
        ergebnis.append(VideoItem(site_id, ziel, titel, ziel, thumb=urljoin(basis, html.unescape(bild.group(1))),
                                  duration=_dauer(re.sub(r"<[^>]+>", " ", innen)) or _dauer(umgebung)))
    return ergebnis




# --- Erkennen: aus einer Adresse eine eigene Seite machen ------------------------------------------
_SEITEN_PARAM = ("page", "p", "seite", "pg", "pagenum", "page_num", "start_page")
_SUCH_PARAM = ("q", "s", "k", "query", "search", "search_text", "search_query", "keyword", "keywords", "what", "term", "text")


def _seiten_vorlage(url):
    """{seite} in eine Adresse setzen, die schon eine Seitenzahl hat (?page=1, /2/, /page/3)."""
    t = urlsplit(url)
    teile = parse_qsl(t.query, keep_blank_values=True)
    for i, (k, v) in enumerate(teile):
        if k.lower() in _SEITEN_PARAM and v.isdigit():
            teile[i] = (k, "SEITE")
            return urlunsplit(t._replace(query=urlencode(teile))).replace("SEITE", "{seite}")
    m = re.search(r"(/(?:page/)?)(\d{1,4})(/?)$", t.path)
    if m and t.path.count("/") > 1:
        return urlunsplit(t._replace(path=t.path[:m.start(2)] + "{seite}" + t.path[m.end(2):]))
    return ""


def _naechste_seite(text, basis):
    """Adresse der zweiten Seite: rel=next, ein Link "2" oder "Next/Weiter/›/»"."""
    m = re.search(r"<(?:link|a)\s[^>]*rel\s*=\s*[\"']next[\"'][^>]*>", text, re.I)
    if m:
        h = re.search(r"href\s*=\s*[\"']([^\"']+)", m.group(0), re.I)
        if h:
            return urljoin(basis, html.unescape(h.group(1)))
    for m in _LINK.finditer(text):
        innen = " ".join(re.sub(r"<[^>]+>", " ", m.group(4)).split()).lower()
        if innen in ("2", "next", "weiter", "nächste", "›", "»", "next page", "next »", "→"):
            return urljoin(basis, html.unescape(m.group(2)))
    return ""


def _vorlage_aus_zwei(erste, zweite):
    """Aus Seite 1 und Seite 2 die Vorlage mit {seite} machen."""
    if not zweite:
        return _seiten_vorlage(erste)
    v = _seiten_vorlage(zweite)
    if v:
        return v
    stellen = [m.start() for m in re.finditer(r"(?<!\d)2(?!\d)", zweite)]
    return zweite[:stellen[-1]] + "{seite}" + zweite[stellen[-1] + 1:] if stellen else ""


def _such_vorlage(text, basis):
    """Such-Adresse mit {q}: erst OpenSearch, dann ein Suchformular."""
    m = re.search(r"<link\s[^>]*opensearchdescription[^>]*>", text, re.I)
    if m:
        h = re.search(r"href\s*=\s*[\"']([^\"']+)", m.group(0), re.I)
        if h:
            try:
                osd = http.get(urljoin(basis, html.unescape(h.group(1)))).text
                u = re.search(r"<Url\s[^>]*type\s*=\s*[\"']text/html[\"'][^>]*template\s*=\s*[\"']([^\"']+)", osd, re.I) or \
                    re.search(r"<Url\s[^>]*template\s*=\s*[\"']([^\"']+)[^>]*type\s*=\s*[\"']text/html", osd, re.I)
                if u:
                    vorlage = re.sub(r"\{startPage\??\}", "\x01", html.unescape(u.group(1)).replace("{searchTerms}", "\x00"))
                    vorlage = re.sub(r"\{[a-zA-Z:]+\??\}", "", vorlage)  # weitere OpenSearch-Platzhalter fallen weg
                    return vorlage.replace("\x00", "{q}").replace("\x01", "{seite}")
            except http.HttpError:
                pass
    for f in re.finditer(r"<form\b([^>]*)>(.*?)</form>", text, re.I | re.S):
        kopf, innen = f.group(1), f.group(2)
        if re.search(r"method\s*=\s*[\"']?post", kopf, re.I):
            continue
        feld = None
        for i in re.finditer(r"<input\b[^>]*>", innen, re.I):
            name = re.search(r"name\s*=\s*[\"']([^\"']+)", i.group(0), re.I)
            typ = re.search(r"type\s*=\s*[\"']?(\w+)", i.group(0), re.I)
            if name and ((typ and typ.group(1).lower() == "search") or name.group(1).lower() in _SUCH_PARAM):
                feld = name.group(1)
                break
        if not feld:
            continue
        aktion = re.search(r"action\s*=\s*[\"']([^\"']*)", kopf, re.I)
        ziel = urljoin(basis, html.unescape(aktion.group(1)) if aktion and aktion.group(1) else basis)
        return ziel + ("&" if "?" in ziel else "?") + quote_plus(feld) + "={q}"
    return ""


def _name(text, url):
    for muster in (r"<meta\s[^>]*property\s*=\s*[\"']og:site_name[\"'][^>]*content\s*=\s*[\"']([^\"']+)",
                   r"<meta\s[^>]*content\s*=\s*[\"']([^\"']+)[\"'][^>]*property\s*=\s*[\"']og:site_name",
                   r"<title[^>]*>([^<]{2,120})</title>"):
        m = re.search(muster, text or "", re.I)
        if m:
            name = re.split(r"\s+[-|–:•]\s+", html.unescape(m.group(1)).strip())
            return (min(name, key=len) if len(name) > 1 else name[0])[:40]
    return (urlsplit(url).hostname or "Seite").replace("www.", "").split(".")[0].capitalize()


def erkennen(url):
    """Adresse -> Vorschlag {name, start, suche, muster, art, felder, probe: [Videos], hinweise: [...]}"""
    url = str(url or "").strip()
    if not url.lower().startswith(("http://", "https://")):
        raise ValueError("Adresse mit http(s):// eingeben")
    if http.is_ad_host(url):
        raise ValueError("Werbe-Host gesperrt")
    a = http.get(url)
    basis, text = a.url or url, a.text
    art = (a.headers.get("Content-Type", "") if a.headers is not None else "") or ""
    hinweise = []
    if "json" in art.lower() or text.lstrip()[:1] in ("{", "["):
        try:
            daten = json.loads(text)
        except ValueError:
            daten = None
        if daten is not None:
            felder = json_felder(daten)
            if not felder:
                raise ValueError("Die Adresse liefert JSON, aber keine erkennbare Videoliste (Link, Titel, Bild)")
            probe = json_videos(daten, felder, "probe", basis)
            start = _seiten_vorlage(url) or url
            q = [k for k, _ in parse_qsl(urlsplit(url).query) if k.lower() in _SUCH_PARAM]
            suche = ""
            if q:
                t = urlsplit(start)
                teile = [(k, "SUCHE" if k == q[0] else v) for k, v in parse_qsl(t.query, keep_blank_values=True)]
                suche = urlunsplit(t._replace(query=urlencode(teile))).replace("SUCHE", "{q}").replace("%7Bseite%7D", "{seite}")
            hinweise.append("API (JSON) erkannt: Liste „%s“, Felder %s." % (felder.get("liste") or "oben", ", ".join(
                "%s=%s" % (k, v) for k, v in felder.items() if k != "liste")))
            if "{seite}" not in start:
                hinweise.append("Keine Seitenzahl in der Adresse – „Mehr laden“ gibt es nur mit page=1 o. ä.")
            return {"name": _name("", url), "start": start, "suche": suche, "muster": "", "art": "json", "felder": felder,
                    "probe": [_probe(v) for v in probe[:8]], "anzahl": len(probe), "hinweise": hinweise}
    probe = videos_lesen(text, basis, None, "probe")
    if not probe:
        hinweise.append("Auf dieser Seite fand H0rSt keine Videolinks mit Vorschaubild – eine Listenseite (z. B. „Neueste“) "
                        "nehmen oder unten ein Muster angeben.")
    start = _vorlage_aus_zwei(basis, _naechste_seite(text, basis))
    if start and start.replace("{seite}", "1") != basis and not _seiten_vorlage(basis):
        hinweise.append("Seitenzahl erkannt: „%s“." % start)
    suche = _such_vorlage(text, basis)
    hinweise.append("Suche erkannt." if suche else "Keine Suche gefunden – ohne Such-Adresse gibt es nur die Liste.")
    return {"name": _name(text, basis), "start": start or basis, "suche": suche, "muster": "", "art": "html", "felder": {},
            "probe": [_probe(v) for v in probe[:8]], "anzahl": len(probe), "hinweise": hinweise}


def _probe(v):
    return {"titel": v.title, "url": v.page_url, "bild": v.thumb, "dauer": v.duration}


class EigeneSeite(Site):
    def __init__(self, eintrag):
        self.id = eintrag["id"]
        self.name = eintrag["name"]
        self.start = eintrag["start"]
        self.suche_url = eintrag.get("suche") or ""
        self.muster = eintrag.get("muster") or ""
        self.art = eintrag.get("art") or "html"
        self.felder = eintrag.get("felder") or {}
        self.host = (urlsplit(self.start).hostname or "").lower()

    def root(self):
        ordner = [Folder("Neueste", {"action": "list", "order": "neu"})]
        if self.suche_url:
            ordner.append(Folder("Suche", {"action": "search"}))
        return ordner

    def _adresse(self, query, page):
        if query:
            if not self.suche_url:
                return None
            url = self.suche_url.replace("{q}", quote_plus(query))
        else:
            url = self.start
        if "{seite}" in url:
            return url.replace("{seite}", str(page))
        if page > 1:
            return None  # ohne {seite} gibt es nur die erste Seite
        return url

    def videos(self, order=None, query=None, category=None, page=1):
        url = self._adresse(query, page)
        if not url:
            return [], False
        antwort = http.get(url)
        if self.art == "json":
            items = json_videos(antwort.json(), self.felder, self.id, antwort.url or url)
        else:
            items = videos_lesen(antwort.text, antwort.url or url, self.muster, self.id)
        weiter = "{seite}" in (self.suche_url if query else self.start) and bool(items)
        return items, weiter


def pruefe(liste):
    """Eigene Seiten aus den Einstellungen pruefen (Adressen, Muster)."""
    if not isinstance(liste, list) or len(liste) > 30:
        raise ValueError("eigene: Liste mit höchstens 30 Seiten")
    ergebnis, ids = [], set()
    for e in liste:
        if not isinstance(e, dict):
            raise ValueError("eigene Seite muss ein Objekt sein")
        name = " ".join(str(e.get("name") or "").split())[:40]
        start = str(e.get("start") or "").strip()
        suche = str(e.get("suche") or "").strip()
        muster = str(e.get("muster") or "").strip()[:300]
        if not name or not start.lower().startswith(("http://", "https://")):
            raise ValueError("Eigene Seite braucht Name und Startadresse (http/https)")
        if suche and (not suche.lower().startswith(("http://", "https://")) or "{q}" not in suche):
            raise ValueError("Such-Adresse muss mit http(s):// beginnen und {q} enthalten")
        if http.is_ad_host(start):
            raise ValueError("Werbe-Host gesperrt")
        if muster:
            try:
                re.compile(muster, re.I)
            except re.error as f:
                raise ValueError("Muster ungültig: %s" % f)
        sid = str(e.get("id") or "") if str(e.get("id") or "").startswith("eigen_") else kennung(name)
        while sid in ids:
            sid += "x"
        ids.add(sid)
        art = "json" if e.get("art") == "json" else "html"
        felder = {}
        if art == "json":
            roh = e.get("felder") if isinstance(e.get("felder"), dict) else {}
            felder = {k: str(roh[k])[:80] for k in ("liste", "url", "titel", "bild", "dauer") if roh.get(k) and _PFAD.match(str(roh[k]))}
            if "url" not in felder:
                raise ValueError("%s: bei einer API-Seite fehlt das Feld für den Link" % name)
        ergebnis.append({"id": sid[:40], "name": name, "start": start[:500], "suche": suche[:500], "muster": muster, "art": art, "felder": felder})
    return ergebnis


# Vorschlaege zum Antippen: Seiten mit offen lesbaren Listen, die yt-dlp abspielen kann (ohne Gewaehr)
VORSCHLAEGE = [
    {"name": "SpankBang", "start": "https://spankbang.com/new_videos/{seite}/",
     "suche": "https://spankbang.com/s/{q}/{seite}/"},
    {"name": "PornTrex", "start": "https://www.porntrex.com/latest-updates/{seite}/",
     "suche": "https://www.porntrex.com/search/{q}/{seite}/"},
    {"name": "HQporner", "start": "https://hqporner.com/hdporn/{seite}", "suche": "https://hqporner.com/?q={q}"},
    {"name": "TNAFlix", "start": "https://www.tnaflix.com/new/{seite}", "suche": "https://www.tnaflix.com/search?what={q}&page={seite}"},
    {"name": "Motherless", "start": "https://motherless.com/videos/recent?page={seite}",
     "suche": "https://motherless.com/term/videos/{q}?page={seite}"},
]
