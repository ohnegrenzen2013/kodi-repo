"""Eigene Ab-18-Seite, JSON-Teil: Listen und Felder in einer API erkennen und Videos lesen.

json_wert(), json_felder() und json_videos() raten Liste und Felder (Link, Titel, Bild, Dauer) in einer
JSON-Antwort. Die HTML-Liste, das Erkennen und die Seite selbst stehen in eigene.py.
"""

import html
import re
from urllib.parse import urljoin

from .. import http
from .base import VideoItem

_DAUER = re.compile(r"\b(?:(\d{1,2}):)?(\d{1,2}):(\d{2})\b")


def _dauer(text):
    m = _DAUER.search(text)
    if not m:
        return 0
    return int(m.group(1) or 0) * 3600 + int(m.group(2)) * 60 + int(m.group(3))


# --- JSON (API) ---------------------------------------------------------------------------------
JSON_FELDER = {
    "url": ("url", "link", "page_url", "video_url", "watch_url", "permalink", "href", "embed_url", "embed"),
    "titel": ("title", "name", "titel", "headline", "description"),
    "bild": ("default_thumb.src", "default_thumb", "thumb", "thumbnail", "thumbnail_url", "thumb_url", "image", "poster",
             "preview", "urls.poster", "urls.thumbnail", "thumbs.0.src", "thumbs.0"),
    "dauer": ("length_sec", "duration", "length", "dauer", "runtime"),
}
_PFAD = re.compile(r"^[A-Za-z0-9_\-]+(\.[A-Za-z0-9_\-]+){0,5}$")


def json_wert(obj, pfad):
    """Punkt-Pfad wie "default_thumb.src" oder "thumbs.0.src" lesen; None, wenn es ihn nicht gibt."""
    for teil in str(pfad or "").split("."):
        if isinstance(obj, list) and teil.isdigit() and int(teil) < len(obj):
            obj = obj[int(teil)]
        elif isinstance(obj, dict) and teil in obj:
            obj = obj[teil]
        else:
            return None
    return obj


def _listen(daten, pfad="", tiefe=0):
    """Alle Listen von Objekten im JSON: [(pfad, liste)]."""
    if tiefe > 4:
        return []
    funde = []
    if isinstance(daten, list) and daten and all(isinstance(x, dict) for x in daten[:5]):
        funde.append((pfad, daten))
    elif isinstance(daten, dict):
        for k, v in daten.items():
            if isinstance(v, (dict, list)):
                funde += _listen(v, (pfad + "." if pfad else "") + k, tiefe + 1)
    return funde


def json_felder(daten):
    """Liste und Felder raten: die groesste Objektliste, deren Eintraege eine Adresse haben."""
    beste = None
    for pfad, liste in _listen(daten):
        probe = liste[0]
        felder = {"liste": pfad}
        for feld, kandidaten in JSON_FELDER.items():
            for k in kandidaten:
                w = json_wert(probe, k)
                if (feld == "dauer" and isinstance(w, (int, float, str)) and str(w)) or (feld != "dauer" and isinstance(w, str) and w.strip()):
                    if feld in ("url", "bild") and not re.match(r"^(https?:)?//|^/", w.strip()):
                        continue
                    felder[feld] = k
                    break
        if "url" in felder and (not beste or len(liste) > beste[0]):
            beste = (len(liste), felder)
    return beste[1] if beste else None


def json_videos(daten, felder, site_id, basis):
    liste = json_wert(daten, felder.get("liste")) if felder.get("liste") else daten
    items = []
    for e in liste if isinstance(liste, list) else []:
        if not isinstance(e, dict):
            continue
        ziel = json_wert(e, felder.get("url"))
        if not isinstance(ziel, str) or not ziel.strip():
            continue
        ziel = urljoin(basis, ziel.strip())
        if not ziel.startswith(("http://", "https://")) or http.is_ad_host(ziel):
            continue
        titel = json_wert(e, felder.get("titel")) if felder.get("titel") else ""
        bild = json_wert(e, felder.get("bild")) if felder.get("bild") else ""
        dauer = json_wert(e, felder.get("dauer")) if felder.get("dauer") else 0
        if isinstance(dauer, str):
            dauer = _dauer(dauer) or (int(dauer) if dauer.isdigit() else 0)
        items.append(VideoItem(site_id, ziel, html.unescape(str(titel or ""))[:200] or ziel.rsplit("/", 1)[-1], ziel,
                               thumb=urljoin(basis, bild) if isinstance(bild, str) and bild else "",
                               duration=int(dauer or 0) if isinstance(dauer, (int, float)) else 0))
    return items
