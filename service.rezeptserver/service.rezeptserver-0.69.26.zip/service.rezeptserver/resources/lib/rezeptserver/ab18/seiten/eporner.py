# -*- coding: utf-8 -*-
"""eporner.com site module.

Uses the site's *official public JSON API* (https://www.eporner.com/api/)
for all browsing, searching and metadata. Playback is handled generically by
resources/lib/resolver.py (yt-dlp), so this module never touches protected
stream endpoints.

All category labels refer to legal adult (18+) content. "Teen" is the site's
standard 18+ category label; nothing here targets minors.
"""
from .base import Site, VideoItem, Folder
from .. import http


def _frames(thumbs, limit=12):
    """List of preview frames from the API's "thumbs" (dicts with "src" or plain strings)."""
    out = []
    for t in thumbs or []:
        src = t.get('src', '') if isinstance(t, dict) else str(t or '')
        if src.startswith('http') and src not in out:
            out.append(src)
    return out[:limit]

API = 'https://www.eporner.com/api/v2/video/search/'
PER_PAGE = 30

# The API's ``order`` parameter. Quality-first orders come first.
ORDERS = [
    ('Top bewertet', 'top-rated'),
    ('Top (Woche)', 'top-weekly'),
    ('Top (Monat)', 'top-monthly'),
    ('Beliebteste', 'most-popular'),
    ('Neueste', 'latest'),
    ('Längste', 'longest'),
]

# Grouped 18+ categories. Each entry is (german_label, api_query).
# eporner search is keyword based, so a category is just a curated query.
CATEGORY_GROUPS = [
    ('Alter (18+)', [
        ('Teen (18+)', 'teen'),
        ('College', 'college'),
        ('MILF', 'milf'),
        ('Reife Frauen', 'mature'),
        ('Oma', 'granny'),
    ]),
    ('Körpertyp', [
        ('Schlank', 'skinny'),
        ('Kurvig', 'curvy'),
        ('Mollig (BBW)', 'bbw'),
        ('Dick', 'chubby'),
        ('Große Brüste', 'big tits'),
    ]),
    ('Herkunft', [
        ('Deutsch', 'german'),
        ('Asiatisch', 'asian'),
        ('Ebony', 'ebony'),
        ('Latina', 'latina'),
        ('Indisch', 'indian'),
    ]),
    ('Kink / Fetisch', [
        ('BDSM', 'bdsm'),
        ('Fetisch', 'fetish'),
        ('Bondage', 'bondage'),
        ('Hardcore', 'hardcore'),
        ('Rough', 'rough'),
        ('Hentai', 'hentai'),
        ('Öffentlich', 'public'),
        ('POV', 'pov'),
    ]),
    ('Allgemein', [
        ('Amateur', 'amateur'),
        ('Anal', 'anal'),
        ('Blowjob', 'blowjob'),
        ('Blond', 'blonde'),
        ('Lesben', 'lesbian'),
        ('Dreier', 'threesome'),
        ('Creampie', 'creampie'),
        ('Vintage', 'vintage'),
    ]),
]


class EpornerSite(Site):
    id = 'eporner'
    name = 'ePorner'

    def root(self):
        folders = [Folder(label, {'action': 'list', 'site': self.id, 'order': order})
                   for label, order in ORDERS]
        folders.append(Folder('Kategorien', {'action': 'categories', 'site': self.id}))
        folders.append(Folder('Suche', {'action': 'search', 'site': self.id}))
        return folders

    def category_groups(self):
        groups = []
        for group_label, entries in CATEGORY_GROUPS:
            folders = [Folder(label, {'action': 'list', 'site': self.id, 'query': query})
                       for label, query in entries]
            groups.append((group_label, folders))
        return groups

    def videos(self, order=None, query=None, category=None, page=1):
        params = {
            'query': query or '',
            'per_page': PER_PAGE,
            'page': int(page),
            'thumbsize': 'big',
            # When the user picked a category (a query) but no explicit order,
            # rank by quality by default.
            'order': order or ('top-weekly' if query else 'latest'),
            'format': 'json',
        }
        data = http.get_json(API, params=params, referer='https://www.eporner.com/')
        items = []
        for v in data.get('videos', []):
            thumb = ''
            dt = v.get('default_thumb') or {}
            if isinstance(dt, dict):
                thumb = dt.get('src', '')
            if not thumb and v.get('thumbs'):
                thumb = v['thumbs'][0].get('src', '')
            try:
                rating = float(v.get('rate') or 0) * 2.0  # API gives a 0..5 star value
            except (TypeError, ValueError):
                rating = 0.0
            items.append(VideoItem(
                site_id=self.id,
                video_id=v.get('id', ''),
                title=v.get('title', 'Ohne Titel'),
                page_url=v.get('url', ''),
                thumb=thumb,
                duration=v.get('length_sec', 0),
                plot=v.get('keywords', ''),
                rating=min(rating, 10.0),
                views=v.get('views', 0),
                date=(v.get('added', '') or '')[:10],
                previews=_frames(v.get('thumbs')),
            ))
        total_pages = int(data.get('total_pages', 1) or 1)
        has_next = int(page) < total_pages
        return items, has_next


SITE = EpornerSite()
