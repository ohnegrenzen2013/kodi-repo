# -*- coding: utf-8 -*-
"""pornhub.com site module.

Uses Pornhub's *official Webmasters API* (https://www.pornhub.com/webmasters/)
for all browsing, searching and metadata. Playback is delegated to
resources/lib/resolver.py (yt-dlp maintains a Pornhub extractor), so this module
never touches protected stream endpoints.

Unlike the other sites, the Webmasters API supports real category filtering via
``category=<name>`` (case-insensitive), combined with ``ordering`` and ``page``.

Notes from testing the live API:
* ``rating`` is a 0..100 number; divide by 10 for Kodi's 0..10 scale.
* ``duration`` is an "MM:SS" (or "H:MM:SS") string.
* Valid ``ordering`` values used here: rating, mostviewed, newest.

All category labels refer to legal adult (18+) content. "Teen" is the site's
standard 18+ label; nothing here targets minors.
"""
from .base import Site, VideoItem, Folder
from .. import http


def _frames(thumbs, limit=12):
    """List of preview frames from the API's "thumbs" (dicts with "src" or plain strings)."""
    out = []
    for t in thumbs or []:
        src = t.get('src', '') if isinstance(t, dict) else str(t or '')
        if src.startswith('http') and src not in out:
            out.append(src)
    return out[:limit]

SEARCH = 'https://www.pornhub.com/webmasters/search'
PER_PAGE = 30

ORDERS = [
    ('Top bewertet', 'rating'),
    ('Meistgesehen', 'mostviewed'),
    ('Neueste', 'newest'),
]

# Grouped 18+ categories -> (german_label, real_pornhub_category_name).
CATEGORY_GROUPS = [
    ('Alter (18+)', [
        ('Teen (18+)', 'teen'),
        ('18-25', '18-25'),
        ('MILF', 'milf'),
        ('Reife Frauen', 'mature'),
        ('Oma', 'granny'),
    ]),
    ('Körpertyp', [
        ('Schlank', 'small-tits'),
        ('Kurvig', 'bbw'),
        ('Große Brüste', 'big-tits'),
        ('PAWG', 'pawg'),
    ]),
    ('Herkunft', [
        ('Deutsch', 'german'),
        ('Asiatisch', 'asian'),
        ('Japanisch', 'japanese'),
        ('Ebony', 'ebony'),
        ('Latina', 'latina'),
        ('Indisch', 'indian'),
    ]),
    ('Kink / Fetisch', [
        ('BDSM', 'bdsm'),
        ('Fetisch', 'fetish'),
        ('Bondage', 'bondage'),
        ('Rough Sex', 'rough-sex'),
        ('Hentai', 'hentai'),
        ('Öffentlich', 'public'),
        ('POV', 'pov'),
        ('Squirt', 'squirt'),
        ('Gangbang', 'gangbang'),
        ('Verbal', 'verified-amateurs'),
    ]),
    ('Allgemein', [
        ('Amateur', 'amateur'),
        ('Anal', 'anal'),
        ('Blowjob', 'blowjob'),
        ('Blond', 'blonde'),
        ('Lesben', 'lesbian'),
        ('Dreier', 'threesome'),
        ('Creampie', 'creampie'),
        ('Cumshot', 'cumshot'),
        ('Interracial', 'interracial'),
        ('Verifizierte Paare', 'verified-couples'),
    ]),
]


def _duration_to_seconds(text):
    try:
        parts = [int(p) for p in str(text).split(':')]
    except (TypeError, ValueError):
        return 0
    seconds = 0
    for p in parts:
        seconds = seconds * 60 + p
    return seconds


class PornhubSite(Site):
    id = 'pornhub'
    name = 'Pornhub'

    def root(self):
        folders = [Folder(label, {'action': 'list', 'site': self.id, 'order': order})
                   for label, order in ORDERS]
        folders.append(Folder('Kategorien', {'action': 'categories', 'site': self.id}))
        folders.append(Folder('Suche', {'action': 'search', 'site': self.id}))
        return folders

    def category_groups(self):
        groups = []
        for group_label, entries in CATEGORY_GROUPS:
            folders = [Folder(label, {'action': 'list', 'site': self.id, 'category': cat})
                       for label, cat in entries]
            groups.append((group_label, folders))
        return groups

    def videos(self, order=None, query=None, category=None, page=1):
        params = {
            'ordering': order or ('rating' if (query or category) else 'mostviewed'),
            'page': int(page),
            'thumbsize': 'large',
        }
        if query:
            params['search'] = query
        if category:
            params['category'] = category
        data = http.get_json(SEARCH, params=params, referer='https://www.pornhub.com/')
        raw = data.get('videos', []) or []
        items = []
        for v in raw:
            thumb = v.get('default_thumb') or v.get('thumb') or ''
            try:
                rating = float(v.get('rating') or 0) / 10.0  # API gives 0..100
            except (TypeError, ValueError):
                rating = 0.0
            cats = v.get('categories') or []
            if cats and isinstance(cats[0], dict):
                cats = [c.get('category', '') for c in cats]
            items.append(VideoItem(
                site_id=self.id,
                video_id=str(v.get('video_id', '')),
                title=v.get('title', 'Ohne Titel'),
                page_url=v.get('url', ''),
                thumb=thumb,
                duration=_duration_to_seconds(v.get('duration')),
                plot=', '.join(c for c in cats if c),
                rating=min(rating, 10.0),
                views=v.get('views', 0),
                date=(v.get('publish_date', '') or '')[:10],
                previews=_frames(v.get('thumbs')),
            ))
        has_next = len(items) >= PER_PAGE
        return items, has_next


SITE = PornhubSite()
