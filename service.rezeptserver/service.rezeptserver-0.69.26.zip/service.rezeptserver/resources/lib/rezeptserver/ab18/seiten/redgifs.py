# -*- coding: utf-8 -*-
"""redgifs.com site module.

Uses RedGifs' *official API* (https://api.redgifs.com/v2/). The API hands out a
free temporary bearer token (``/v2/auth/temporary``) that this module fetches and
caches; no account or login is involved. Playback uses the plain MP4 URLs the
API itself returns for each clip (``urls.hd`` / ``urls.sd``), fetched fresh via
``/v2/gifs/{id}`` at play time, so this site needs no yt-dlp.

Notes from testing the live API:
* ``duration`` is already in seconds (int).
* ``order`` values used: top, trending, latest.
* Items are short clips; many have no audio.

All tags/labels refer to legal adult (18+) content; nothing here targets minors.
"""
import time

from .base import Site, VideoItem, Folder
from .. import http, kodiutils
from ..resolver import Resolved

AUTH = 'https://api.redgifs.com/v2/auth/temporary'
SEARCH = 'https://api.redgifs.com/v2/gifs/search'
GIF = 'https://api.redgifs.com/v2/gifs/%s'
WATCH = 'https://www.redgifs.com/watch/%s'
PER_PAGE = 40
_TOKEN_TTL = 23 * 3600  # refresh well before the ~24h expiry

ORDERS = [
    ('Top bewertet', 'top'),
    ('Trending', 'trending'),
    ('Neueste', 'latest'),
]

CATEGORY_GROUPS = [
    ('Beliebt', [
        ('Amateur', 'amateur'),
        ('Verifiziert', 'verified'),
        ('Homemade', 'homemade'),
    ]),
    ('Körpertyp', [
        ('Schlank', 'skinny'),
        ('Kurvig', 'curvy'),
        ('Mollig (BBW)', 'bbw'),
        ('Große Brüste', 'big tits'),
        ('Booty', 'booty'),
    ]),
    ('Herkunft', [
        ('Deutsch', 'german'),
        ('Asiatisch', 'asian'),
        ('Ebony', 'ebony'),
        ('Latina', 'latina'),
    ]),
    ('Kink / Fetisch', [
        ('Fetisch', 'fetish'),
        ('BDSM', 'bdsm'),
        ('Öffentlich', 'public'),
        ('POV', 'pov'),
        ('Cosplay', 'cosplay'),
        ('Hentai', 'hentai'),
    ]),
    ('Allgemein', [
        ('Anal', 'anal'),
        ('Blowjob', 'blowjob'),
        ('Lesben', 'lesbian'),
        ('Dreier', 'threesome'),
        ('Creampie', 'creampie'),
        ('Blond', 'blonde'),
    ]),
]


class RedgifsSite(Site):
    id = 'redgifs'
    name = 'RedGifs'

    def __init__(self):
        self._token = ''
        self._token_at = 0

    def _auth_header(self, force=False):
        now = time.time()
        if force or not self._token or (now - self._token_at) > _TOKEN_TTL:
            data = http.get_json(AUTH, referer='https://www.redgifs.com/')
            self._token = data.get('token', '')
            self._token_at = now
            kodiutils.log('RedGifs: fetched temporary token', 0)
        return {'Authorization': 'Bearer ' + self._token}

    def _api_get(self, url, params=None):
        try:
            return http.get_json(url, params=params, headers=self._auth_header(),
                                 referer='https://www.redgifs.com/')
        except http.HttpError:
            # Token may have expired: refresh once and retry.
            return http.get_json(url, params=params, headers=self._auth_header(force=True),
                                 referer='https://www.redgifs.com/')

    def root(self):
        folders = [Folder(label, {'action': 'list', 'site': self.id, 'order': order})
                   for label, order in ORDERS]
        folders.append(Folder('Kategorien', {'action': 'categories', 'site': self.id}))
        folders.append(Folder('Suche', {'action': 'search', 'site': self.id}))
        return folders

    def category_groups(self):
        groups = []
        for group_label, entries in CATEGORY_GROUPS:
            folders = [Folder(label, {'action': 'list', 'site': self.id, 'query': query})
                       for label, query in entries]
            groups.append((group_label, folders))
        return groups

    def videos(self, order=None, query=None, category=None, page=1):
        params = {
            'search_text': query or '',
            'order': order or 'top',
            'count': PER_PAGE,
            'page': int(page),
        }
        # The search endpoint requires a non-empty search_text; fall back to a
        # broad term for the top-level "newest/top/trending" browsing folders.
        if not params['search_text']:
            params['search_text'] = 'porn'
        data = self._api_get(SEARCH, params=params)

        raw = data.get('gifs', []) or []
        items = []
        for g in raw:
            urls = g.get('urls') or {}
            thumb = urls.get('poster') or urls.get('thumbnail') or ''
            gid = g.get('id', '')
            tags = g.get('tags') or []
            items.append(VideoItem(
                site_id=self.id,
                video_id=str(gid),
                title=(g.get('description') or ', '.join(tags[:4]) or gid or 'Clip'),
                page_url=WATCH % gid,
                thumb=thumb,
                duration=int(g.get('duration') or 0),
                plot=', '.join(tags),
                rating=0.0,  # API exposes likes/views, not a 0..10 rating
                views=g.get('views', 0),
                date='',
                preview_video=urls.get('sd') or urls.get('vthumbnail') or '',
            ))
        total_pages = int(data.get('pages', 1) or 1)
        has_next = int(page) < total_pages
        return items, has_next

    def resolve(self, video_id, max_height=0):
        gif = self._api_get(GIF % video_id).get('gif') or {}
        urls = gif.get('urls') or {}
        hd, sd = urls.get('hd'), urls.get('sd')
        # 'hd' is the source resolution; 'sd' is the smaller "-mobile" encode.
        too_tall = max_height > 0 and int(gif.get('height') or 0) > max_height
        url = (sd or hd) if too_tall else (hd or sd)
        if not url:
            return None
        return Resolved(url=url, headers={'User-Agent': http.DEFAULT_UA}, mime='video/mp4')


SITE = RedgifsSite()
