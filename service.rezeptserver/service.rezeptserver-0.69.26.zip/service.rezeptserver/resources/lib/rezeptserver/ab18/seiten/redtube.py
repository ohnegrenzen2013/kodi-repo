# -*- coding: utf-8 -*-
"""redtube.com site module.

Uses RedTube's *official public API* (https://api.redtube.com/) for all browsing,
searching and metadata. Playback is delegated to resources/lib/resolver.py
(yt-dlp, which maintains a RedTube extractor), so this module never touches
protected stream endpoints.

Notes from testing the live API:
* The ``category`` search parameter does not actually filter (it returns a
  promo feed and ignores ``ordering``). Real filtering works via ``search=<kw>``,
  so categories are implemented as curated keyword queries, like the other sites.
* ``rating`` is a 0..100 string; divide by 10 for Kodi's 0..10 scale.
* ``duration`` is an "MM:SS" (or "H:MM:SS") string.

All category labels refer to legal adult (18+) content. "Teen" is the site's
standard 18+ label; nothing here targets minors.
"""
from .base import Site, VideoItem, Folder
from .. import http


def _frames(thumbs, limit=12):
    """List of preview frames from the API's "thumbs" (dicts with "src" or plain strings)."""
    out = []
    for t in thumbs or []:
        src = t.get('src', '') if isinstance(t, dict) else str(t or '')
        if src.startswith('http') and src not in out:
            out.append(src)
    return out[:limit]

API = 'https://api.redtube.com/'
PER_PAGE = 20  # the API returns 20 per page

# Quality-first orderings (API ``ordering`` values).
ORDERS = [
    ('Top bewertet', 'rating'),
    ('Meistgesehen', 'mostviewed'),
    ('Neueste', 'newest'),
]

# Grouped 18+ categories -> (german_label, search_query).
CATEGORY_GROUPS = [
    ('Alter (18+)', [
        ('Teen (18+)', 'teen'),
        ('College', 'college'),
        ('MILF', 'milf'),
        ('Reife Frauen', 'mature'),
        ('Oma', 'granny'),
    ]),
    ('Körpertyp', [
        ('Schlank', 'skinny'),
        ('Kurvig', 'curvy'),
        ('Mollig (BBW)', 'bbw'),
        ('Große Brüste', 'big tits'),
        ('Small Tits', 'small tits'),
    ]),
    ('Herkunft', [
        ('Deutsch', 'german'),
        ('Asiatisch', 'asian'),
        ('Japanisch', 'japanese'),
        ('Ebony', 'ebony'),
        ('Latina', 'latina'),
        ('Indisch', 'indian'),
    ]),
    ('Kink / Fetisch', [
        ('BDSM', 'bdsm'),
        ('Fetisch', 'fetish'),
        ('Bondage', 'bondage'),
        ('Hardcore', 'hardcore'),
        ('Rough', 'rough sex'),
        ('Hentai', 'hentai'),
        ('Öffentlich', 'public'),
        ('POV', 'pov'),
        ('Squirting', 'squirting'),
        ('Gangbang', 'gangbang'),
    ]),
    ('Allgemein', [
        ('Amateur', 'amateur'),
        ('Anal', 'anal'),
        ('Blowjob', 'blowjob'),
        ('Blond', 'blonde'),
        ('Lesben', 'lesbian'),
        ('Dreier', 'threesome'),
        ('Creampie', 'creampie'),
        ('Cumshot', 'cumshot'),
        ('Interracial', 'interracial'),
    ]),
]


def _duration_to_seconds(text):
    try:
        parts = [int(p) for p in str(text).split(':')]
    except (TypeError, ValueError):
        return 0
    seconds = 0
    for p in parts:
        seconds = seconds * 60 + p
    return seconds


class RedtubeSite(Site):
    id = 'redtube'
    name = 'RedTube'

    def root(self):
        folders = [Folder(label, {'action': 'list', 'site': self.id, 'order': order})
                   for label, order in ORDERS]
        folders.append(Folder('Kategorien', {'action': 'categories', 'site': self.id}))
        folders.append(Folder('Suche', {'action': 'search', 'site': self.id}))
        return folders

    def category_groups(self):
        groups = []
        for group_label, entries in CATEGORY_GROUPS:
            folders = [Folder(label, {'action': 'list', 'site': self.id, 'query': query})
                       for label, query in entries]
            groups.append((group_label, folders))
        return groups

    def videos(self, order=None, query=None, category=None, page=1):
        params = {
            'data': 'redtube.Videos.searchVideos',
            'output': 'json',
            'search': query or '',
            'ordering': order or ('rating' if query else 'newest'),
            'page': int(page),
            'thumbsize': 'big',
        }
        data = http.get_json(API, params=params, referer='https://www.redtube.com/')
        raw = data.get('videos', []) or []
        items = []
        for entry in raw:
            v = entry.get('video', entry)
            thumb = v.get('default_thumb') or v.get('thumb') or ''
            if not thumb and v.get('thumbs'):
                thumb = v['thumbs'][0].get('src', '') if isinstance(v['thumbs'][0], dict) else ''
            try:
                rating = float(v.get('rating') or 0) / 10.0  # API gives 0..100
            except (TypeError, ValueError):
                rating = 0.0
            tags = v.get('tags') or []
            if tags and isinstance(tags[0], dict):
                tags = [t.get('tag_name', '') for t in tags]
            items.append(VideoItem(
                site_id=self.id,
                video_id=str(v.get('video_id', '')),
                title=v.get('title', 'Ohne Titel'),
                page_url=v.get('url', ''),
                thumb=thumb,
                duration=_duration_to_seconds(v.get('duration')),
                plot=', '.join(t for t in tags if t),
                rating=min(rating, 10.0),
                views=v.get('views', 0),
                date=(v.get('publish_date', '') or '')[:10],
                previews=_frames(v.get('thumbs')),
            ))
        # The API caps results; treat a full page as "there may be more".
        has_next = len(items) >= PER_PAGE
        return items, has_next


SITE = RedtubeSite()
