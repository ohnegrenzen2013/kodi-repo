# -*- coding: utf-8 -*-
"""xhamster.com site module.

xHamster has no public API, but every listing page is openly readable (no
login, no anti-bot challenge) and embeds its video list as JSON in
``window.initials``. This module reads only that JSON. Playback is delegated to
resources/lib/resolver.py (yt-dlp maintains an xHamster extractor), so this
module never touches protected stream endpoints.

URL scheme (page number is 1-based, page 1 has no suffix):
* Sections:   ``/<order>/<page>``  e.g. ``/best/monthly/2``
* Categories: ``/categories/<slug>/best/<page>``
* Search:     ``/search/<query>?page=<page>``

Notes from testing the live pages:
* The list sits at a different JSON path per page type, so it is located by
  shape (a list of dicts with ``pageURL`` and ``duration``).
* ``duration`` is in seconds, ``created`` a Unix timestamp.
* Thumbnails are WebP only (signed URLs, other formats return 403); Kodi 20+
  displays them.

If the page carries no video list (e.g. a regional age-verification page),
an error is reported instead of trying to get around it.

All category labels refer to legal adult (18+) content. "Teen" is the site's
standard 18+ label; nothing here targets minors.
"""
import datetime
import json
import re

try:
    from urllib.parse import quote_plus
except ImportError:  # pragma: no cover
    from urllib import quote_plus

from .base import Site, VideoItem, Folder
from .. import http

BASE = 'https://xhamster.com'
PER_PAGE = 40  # pages carry 46; treat anything near that as "may have more"

ORDERS = [
    ('Beste des Monats', 'best/monthly'),
    ('Meistgesehen (Monat)', 'most-viewed/monthly'),
    ('Beste aller Zeiten', 'best'),
    ('Neueste', 'newest'),
]

# Grouped 18+ categories -> (german_label, real_xhamster_category_slug).
CATEGORY_GROUPS = [
    ('Alter (18+)', [
        ('Teen (18+)', 'teen'),
        ('College', 'college'),
        ('MILF', 'milf'),
        ('Reife Frauen', 'mature'),
        ('Oma', 'granny'),
    ]),
    ('Körpertyp', [
        ('Schlank', 'skinny'),
        ('Mollig (BBW)', 'bbw'),
        ('Große Brüste', 'big-tits'),
        ('Small Tits', 'small-tits'),
        ('PAWG', 'pawg'),
    ]),
    ('Herkunft', [
        ('Deutsch', 'german'),
        ('Asiatisch', 'asian'),
        ('Japanisch', 'japanese'),
        ('Ebony', 'ebony'),
        ('Latina', 'latina'),
        ('Indisch', 'indian'),
    ]),
    ('Kink / Fetisch', [
        ('BDSM', 'bdsm'),
        ('Fetisch', 'fetish'),
        ('Bondage', 'bondage'),
        ('Rough Sex', 'rough-sex'),
        ('Hentai', 'hentai'),
        ('Öffentlich', 'public-sex'),
        ('POV', 'pov'),
        ('Squirting', 'squirting'),
        ('Gangbang', 'gangbang'),
    ]),
    ('Allgemein', [
        ('Amateur', 'amateur'),
        ('Homemade', 'homemade'),
        ('Anal', 'anal'),
        ('Blowjob', 'blowjob'),
        ('Blond', 'blonde'),
        ('Lesben', 'lesbian'),
        ('Dreier', 'threesome'),
        ('Creampie', 'creampie'),
        ('Cumshot', 'cumshot'),
        ('Interracial', 'interracial'),
    ]),
]

_INITIALS = re.compile(r'window\.initials\s*=\s*(\{.*?\});\s*</script>', re.S)


def _find_video_list(node, tiefe=0):
    """Depth-first search for the first list of video dicts. Depth-limited like eigene.py's _listen() -
    an unusually deeply nested response must not cause a RecursionError."""
    if tiefe > 20:
        return None
    if isinstance(node, dict):
        children = node.values()
    elif isinstance(node, list):
        if node and isinstance(node[0], dict) and 'pageURL' in node[0] and 'duration' in node[0]:
            return node
        children = node
    else:
        return None
    for child in children:
        found = _find_video_list(child, tiefe + 1)
        if found is not None:
            return found
    return None


def _date(timestamp):
    try:
        return datetime.date.fromtimestamp(int(timestamp)).strftime('%Y-%m-%d')
    except (TypeError, ValueError, OverflowError, OSError):
        return ''


class XhamsterSite(Site):
    id = 'xhamster'
    name = 'xHamster'

    def root(self):
        folders = [Folder(label, {'action': 'list', 'site': self.id, 'order': order})
                   for label, order in ORDERS]
        folders.append(Folder('Kategorien', {'action': 'categories', 'site': self.id}))
        folders.append(Folder('Suche', {'action': 'search', 'site': self.id}))
        return folders

    def category_groups(self):
        groups = []
        for group_label, entries in CATEGORY_GROUPS:
            folders = [Folder(label, {'action': 'list', 'site': self.id, 'category': slug})
                       for label, slug in entries]
            groups.append((group_label, folders))
        return groups

    def videos(self, order=None, query=None, category=None, page=1):
        page = int(page)
        params = None
        if query:
            path = '/search/%s' % quote_plus(query)
            if page > 1:
                params = {'page': page}
        else:
            if category:
                path = '/categories/%s/best' % category
            else:
                path = '/' + (order or ORDERS[0][1])
            if page > 1:
                path += '/%d' % page
        resp = http.get(BASE + path, params=params, referer=BASE + '/')

        m = _INITIALS.search(resp.text)
        try:
            data = json.loads(m.group(1)) if m else None
        except ValueError:
            data = None
        if data is None:
            raise http.HttpError('xHamster lieferte keine Videoliste '
                                 '(evtl. Altersprüfung oder Regionssperre).')

        items = []
        for v in _find_video_list(data) or []:
            if v.get('videoType', 'video') != 'video':
                continue
            page_url = v.get('pageURL', '')
            if not page_url or http.is_ad_host(page_url):
                continue
            items.append(VideoItem(
                site_id=self.id,
                video_id=str(v.get('id', '')),
                title=v.get('title') or 'Ohne Titel',
                page_url=page_url,
                thumb=v.get('thumbURL') or v.get('imageURL') or '',
                duration=v.get('duration', 0),
                plot=(v.get('landing') or {}).get('name') or '',
                views=v.get('views', 0),
                date=_date(v.get('created')),
            ))

        pagination = data.get('pagination')
        if isinstance(pagination, dict) and 'next' in pagination:
            has_next = bool(pagination.get('next'))
        else:
            has_next = len(items) >= PER_PAGE
        return items, has_next


SITE = XhamsterSite()
