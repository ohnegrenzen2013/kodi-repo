# -*- coding: utf-8 -*-
"""xnxx.com site module.

XNXX has no public API, but its listing pages are openly readable HTML (no
login, no anti-bot challenge). They use the same engine as XVideos and are
parsed by :mod:`xvbase`. Playback is delegated to resources/lib/resolver.py
(yt-dlp maintains an XNXX extractor), so this module never touches protected
stream endpoints.

URL scheme (page index is 0-based on the site, ``/0`` is omitted):
* Best of the month: ``/best/<YYYY-MM>/<index>``
* Most viewed:       ``/hits/<index>``
* Search:            ``/search/<query>/<index>`` (relevance)

XNXX listings show a like percentage, used as the rating (0..10).
"""
try:
    from urllib.parse import quote_plus
except ImportError:  # pragma: no cover
    from urllib import quote_plus

from .base import Site, Folder
from . import xvbase

BASE = 'https://www.xnxx.com'

ORDERS = [
    ('Beste des Monats', 'best'),
    ('Meistgesehen', 'hits'),
]


class XnxxSite(Site):
    id = 'xnxx'
    name = 'XNXX'

    def root(self):
        folders = [Folder(label, {'action': 'list', 'site': self.id, 'order': order})
                   for label, order in ORDERS]
        folders.append(Folder('Kategorien', {'action': 'categories', 'site': self.id}))
        folders.append(Folder('Suche', {'action': 'search', 'site': self.id}))
        return folders

    def category_groups(self):
        return xvbase.category_groups(self.id)

    def videos(self, order=None, query=None, category=None, page=1):
        index = int(page) - 1
        if query:
            path = '/search/%s' % quote_plus(query)
        elif order == 'hits':
            path = '/hits'
        else:
            path = '/best/%s' % xvbase.previous_month()
        if index:
            path += '/%d' % index
        html = xvbase.fetch(BASE, path)
        items = xvbase.parse_listing(html, self.id, BASE)
        return items, bool(items) and xvbase.has_page(html, index + 1)


SITE = XnxxSite()
