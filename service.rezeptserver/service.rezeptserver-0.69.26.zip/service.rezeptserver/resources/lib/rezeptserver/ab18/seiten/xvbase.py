# -*- coding: utf-8 -*-
"""Shared listing parser for the XVideos engine (xvideos.com and xnxx.com).

Neither site has a public API, but their listing pages are plain, openly
readable HTML (no login, no anti-bot challenge). This module only reads those
listings; playback goes through yt-dlp like the other non-API sites, so no
protected stream endpoint is ever touched.

Each video on a listing page sits in a ``thumb-block`` element. The two sites
(and different page types on XVideos) use slightly different markup inside
that block, so the parser extracts each field with a small, tolerant regex
per block instead of relying on one exact layout.

All category labels refer to legal adult (18+) content. "Teen" is the sites'
standard 18+ label; nothing here targets minors.
"""
import datetime
import re

try:
    from html import unescape
except ImportError:  # pragma: no cover
    from HTMLParser import HTMLParser
    unescape = HTMLParser().unescape

from .base import Folder, VideoItem
from .. import http

# Grouped 18+ categories -> (german_label, search_query). Both sites filter
# reliably by keyword search, so categories are curated queries.
CATEGORY_GROUPS = [
    ('Alter (18+)', [
        ('Teen (18+)', 'teen'),
        ('College', 'college'),
        ('MILF', 'milf'),
        ('Reife Frauen', 'mature'),
        ('Oma', 'granny'),
    ]),
    ('Körpertyp', [
        ('Schlank', 'skinny'),
        ('Kurvig', 'curvy'),
        ('Mollig (BBW)', 'bbw'),
        ('Große Brüste', 'big tits'),
        ('Small Tits', 'small tits'),
    ]),
    ('Herkunft', [
        ('Deutsch', 'german'),
        ('Asiatisch', 'asian'),
        ('Japanisch', 'japanese'),
        ('Ebony', 'ebony'),
        ('Latina', 'latina'),
        ('Indisch', 'indian'),
    ]),
    ('Kink / Fetisch', [
        ('BDSM', 'bdsm'),
        ('Fetisch', 'fetish'),
        ('Bondage', 'bondage'),
        ('Rough', 'rough sex'),
        ('Hentai', 'hentai'),
        ('Öffentlich', 'public'),
        ('POV', 'pov'),
        ('Squirting', 'squirting'),
        ('Gangbang', 'gangbang'),
    ]),
    ('Allgemein', [
        ('Amateur', 'amateur'),
        ('Anal', 'anal'),
        ('Blowjob', 'blowjob'),
        ('Blond', 'blonde'),
        ('Lesben', 'lesbian'),
        ('Dreier', 'threesome'),
        ('Creampie', 'creampie'),
        ('Cumshot', 'cumshot'),
        ('Interracial', 'interracial'),
    ]),
]

_BLOCK_SPLIT = re.compile(r'<div[^>]+class="[^"]*\bthumb-block\b')
_LINK = re.compile(r'href="(/video[.-]([a-z0-9]+)/[^"]+)"')
_TITLE = re.compile(r'title="([^"]+)"')
_THUMB = re.compile(r'data-src="(https://[^"]+\.jpg)"')
_VIEWS = re.compile(r'([\d.]+)\s*([kKmM]?)\s*(?:<span class="(?:sprfluous|views-text|icon-f icf-eye)|</span><span class="views-text)')
_VIEWS_COUNT = re.compile(r'class="views-count">([\d.]+)\s*([kKmM]?)<')
_RATING = re.compile(r'>\s*(\d{1,3})%\s*<')
_HOURS = re.compile(r'(\d+)\s*h\b')
_MINUTES = re.compile(r'(\d+)\s*min')
_SECONDS = re.compile(r'(\d+)\s*sec')
_TAGS = re.compile(r'<[^>]+>')


def previous_month():
    """'YYYY-MM' of last month: the newest complete "best of the month" list."""
    first = datetime.date.today().replace(day=1)
    return (first - datetime.timedelta(days=1)).strftime('%Y-%m')


def category_groups(site_id):
    groups = []
    for group_label, entries in CATEGORY_GROUPS:
        folders = [Folder(label, {'action': 'list', 'site': site_id, 'query': query})
                   for label, query in entries]
        groups.append((group_label, folders))
    return groups


def _count(number, suffix):
    try:
        value = float(number)
    except ValueError:
        return 0
    return int(value * {'k': 1e3, 'm': 1e6}.get(suffix.lower(), 1))


def _duration(block):
    # Look only at the metadata text, so "1080p" or titles cannot match.
    meta = block.split('thumb-under', 1)[-1]
    meta = _TAGS.sub(' ', meta)
    seconds = 0
    for rx, factor in ((_HOURS, 3600), (_MINUTES, 60), (_SECONDS, 1)):
        m = rx.search(meta)
        if m:
            seconds += int(m.group(1)) * factor
    return seconds


def parse_listing(html, site_id, base_url):
    """Return a list of :class:`VideoItem` from an XVideos-engine listing page."""
    items = []
    seen = set()
    for block in _BLOCK_SPLIT.split(html)[1:]:
        link = _LINK.search(block)
        if not link:
            continue
        path, video_id = link.group(1), link.group(2)
        if video_id in seen:
            continue
        seen.add(video_id)
        page_url = base_url + path
        if http.is_ad_host(page_url):
            continue

        under = block.split('thumb-under', 1)[-1]
        title = _TITLE.search(under)
        thumb = _THUMB.search(block)
        views = _VIEWS_COUNT.search(under) or _VIEWS.search(under)
        rating = _RATING.search(under)
        items.append(VideoItem(
            site_id=site_id,
            video_id=video_id,
            title=unescape(title.group(1)) if title else 'Ohne Titel',
            page_url=page_url,
            thumb=unescape(thumb.group(1)) if thumb else '',
            duration=_duration(block),
            views=_count(*views.groups()) if views else 0,
            rating=int(rating.group(1)) / 10.0 if rating else 0.0,
        ))
    return items


def has_page(html, index):
    """True if the pagination links to the 0-based page ``index``.

    The sites write page links either as ``.../<index>`` or ``...&p=<index>``.
    """
    tails = ('/%d' % index, 'p=%d' % index)
    for href in re.findall(r'href="([^"]+)"', html):
        href = unescape(href)
        if not href.startswith('/video') and href.endswith(tails):
            return True
    return False


def fetch(base_url, path, params=None):
    resp = http.get(base_url + path, params=params, referer=base_url + '/')
    return resp.text
