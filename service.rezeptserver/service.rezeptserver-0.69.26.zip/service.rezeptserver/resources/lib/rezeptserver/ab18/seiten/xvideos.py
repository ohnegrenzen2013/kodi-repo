# -*- coding: utf-8 -*-
"""xvideos.com site module.

XVideos has no public API, but its listing pages are openly readable HTML (no
login, no anti-bot challenge). They are parsed by :mod:`xvbase`, shared with
XNXX. Playback is delegated to resources/lib/resolver.py (yt-dlp maintains an
XVideos extractor), so this module never touches protected stream endpoints.

URL scheme (page index is 0-based on the site):
* Best of the month: ``/best/<YYYY-MM>/<index>``
* Newest:            ``/`` for the first page, then ``/new/<index>``
* Search:            ``/?k=<query>&p=<index>`` (relevance)
"""
from .base import Site, Folder
from . import xvbase

BASE = 'https://www.xvideos.com'

ORDERS = [
    ('Beste des Monats', 'best'),
    ('Neueste', 'new'),
]


class XvideosSite(Site):
    id = 'xvideos'
    name = 'XVideos'

    def root(self):
        folders = [Folder(label, {'action': 'list', 'site': self.id, 'order': order})
                   for label, order in ORDERS]
        folders.append(Folder('Kategorien', {'action': 'categories', 'site': self.id}))
        folders.append(Folder('Suche', {'action': 'search', 'site': self.id}))
        return folders

    def category_groups(self):
        return xvbase.category_groups(self.id)

    def videos(self, order=None, query=None, category=None, page=1):
        index = int(page) - 1
        params = None
        if query:
            path = '/'
            params = {'k': query}
            if index:
                params['p'] = index
        elif order == 'new':
            path = '/new/%d' % index if index else '/'
        else:
            path = '/best/%s/%d' % (xvbase.previous_month(), index)
        html = xvbase.fetch(BASE, path, params)
        items = xvbase.parse_listing(html, self.id, BASE)
        return items, bool(items) and xvbase.has_page(html, index + 1)


SITE = XvideosSite()
