# -*- coding: utf-8 -*-
"""youporn.com site module.

YouPorn's old Webmasters API is gone (404), but its listing pages are openly
readable HTML (no login, no anti-bot challenge). This module parses those
listings. Playback is delegated to resources/lib/resolver.py (yt-dlp maintains
a YouPorn extractor), so this module never touches protected stream endpoints.

URL scheme (``?page=<n>``, 1-based, on all of them):
* Sections:   ``/top_rated/``, ``/most_viewed/``, ``/browse/time/``
* Categories: ``/category/<slug>/rating/``
* Search:     ``/search/?query=<query>``

Each video is an ``<article class="video-box" data-video-id=...>``; the page
announces a following page with ``<link rel="next">``. Views ("572K") and the
like percentage ("83%") come from the card; the percentage is used as rating.

All category labels refer to legal adult (18+) content. "Teens" is the site's
standard 18+ label; nothing here targets minors.
"""
import re

try:
    from html import unescape
except ImportError:  # pragma: no cover
    from HTMLParser import HTMLParser
    unescape = HTMLParser().unescape

from .base import Site, VideoItem, Folder
from .. import http

BASE = 'https://www.youporn.com'

ORDERS = [
    ('Top bewertet', 'top_rated'),
    ('Meistgesehen', 'most_viewed'),
    ('Neueste', 'browse/time'),
]

# Grouped 18+ categories -> (german_label, real_youporn_category_slug).
CATEGORY_GROUPS = [
    ('Alter (18+)', [
        ('Teen (18+)', 'teens'),
        ('College', 'college'),
        ('MILF', 'milf'),
        ('Reife Frauen', 'mature'),
    ]),
    ('Körpertyp', [
        ('Mollig (BBW)', 'bbw'),
        ('Große Brüste', 'bigtits'),
        ('Small Tits', 'small-tits'),
        ('Großer Hintern', 'bigass'),
    ]),
    ('Herkunft', [
        ('Deutsch', 'german'),
        ('Europäisch', 'european'),
        ('Asiatisch', 'asian'),
        ('Japanisch', 'japanese'),
        ('Ebony', 'ebony'),
        ('Latina', 'latina'),
        ('Indisch', 'indian'),
    ]),
    ('Kink / Fetisch', [
        ('Fetisch', 'fetish'),
        ('Bondage', 'bondage'),
        ('Rough', 'rough'),
        ('Hentai', 'hentai'),
        ('Öffentlich', 'public'),
        ('POV', 'pov'),
        ('Squirting', 'squirting'),
        ('Gangbang', 'gangbang'),
    ]),
    ('Allgemein', [
        ('Amateur', 'amateur'),
        ('Verifizierte Amateure', 'verifiedamateurs'),
        ('Anal', 'anal'),
        ('Blowjob', 'blowjob'),
        ('Blond', 'blonde'),
        ('Lesben', 'lesbian'),
        ('Dreier', 'threesome'),
        ('Creampie', 'creampie'),
        ('Cumshot', 'cumshot'),
        ('Interracial', 'interracial'),
        ('Massage', 'massage'),
    ]),
]

_ARTICLE_SPLIT = re.compile(r'<article\s+class="[^"]*\bvideo-box\b')
_VIDEO_ID = re.compile(r'data-video-id="(\d+)"')
_LINK = re.compile(r'href="(/watch/\d+/[^"]*)"')
_TITLE = re.compile(r'aria-label="([^"]+)"')
_THUMB = re.compile(r'data-src="(https://[^"]+)"')
_DURATION = re.compile(r'video-duration[^>]*>\s*<span>\s*([\d:]+)\s*<')
_VIEWS = re.compile(r'Views:\s*</span>\s*([\d.,]+)\s*([KkMm]?)')
_RATING = re.compile(r'Rating:\s*</span>\s*(\d{1,3})%')
_NEXT = re.compile(r'<link\s+rel="next"')


def _duration_to_seconds(text):
    seconds = 0
    for part in text.split(':'):
        seconds = seconds * 60 + int(part)
    return seconds


def _count(number, suffix):
    try:
        value = float(number.replace(',', ''))
    except ValueError:
        return 0
    return int(value * {'k': 1e3, 'm': 1e6}.get(suffix.lower(), 1))


class YoupornSite(Site):
    id = 'youporn'
    name = 'YouPorn'

    def root(self):
        folders = [Folder(label, {'action': 'list', 'site': self.id, 'order': order})
                   for label, order in ORDERS]
        folders.append(Folder('Kategorien', {'action': 'categories', 'site': self.id}))
        folders.append(Folder('Suche', {'action': 'search', 'site': self.id}))
        return folders

    def category_groups(self):
        groups = []
        for group_label, entries in CATEGORY_GROUPS:
            folders = [Folder(label, {'action': 'list', 'site': self.id, 'category': slug})
                       for label, slug in entries]
            groups.append((group_label, folders))
        return groups

    def videos(self, order=None, query=None, category=None, page=1):
        page = int(page)
        params = {}
        if query:
            path = '/search/'
            params['query'] = query
        elif category:
            path = '/category/%s/rating/' % category
        else:
            path = '/%s/' % (order or ORDERS[0][1])
        if page > 1:
            params['page'] = page
        html = http.get(BASE + path, params=params or None, referer=BASE + '/').text

        items = []
        seen = set()
        for block in _ARTICLE_SPLIT.split(html)[1:]:
            vid = _VIDEO_ID.search(block)
            link = _LINK.search(block)
            if not vid or not link or vid.group(1) in seen:
                continue
            seen.add(vid.group(1))
            title = _TITLE.search(block)
            thumb = _THUMB.search(block)
            duration = _DURATION.search(block)
            views = _VIEWS.search(block)
            rating = _RATING.search(block)
            items.append(VideoItem(
                site_id=self.id,
                video_id=vid.group(1),
                title=unescape(title.group(1)) if title else 'Ohne Titel',
                page_url=BASE + link.group(1),
                thumb=unescape(thumb.group(1)) if thumb else '',
                duration=_duration_to_seconds(duration.group(1)) if duration else 0,
                views=_count(*views.groups()) if views else 0,
                rating=int(rating.group(1)) / 10.0 if rating else 0.0,
            ))
        return items, bool(items) and bool(_NEXT.search(html))


SITE = YoupornSite()
