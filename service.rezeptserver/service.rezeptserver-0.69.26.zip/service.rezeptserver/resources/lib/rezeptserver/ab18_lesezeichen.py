"""Ab 18 - Lesezeichen: eine reine Adressliste des Nutzers (kein Vorschlagsverzeichnis, kein Abruf, keine Vorschaubilder).

Gespeichert wird in den Nutzerdaten unter "ab18_lesezeichen": {"an": bool, "liste": [{id, name, url}]}. H0rSt ruft die
Adressen nie selbst auf; ein Tipp oeffnet sie im Browser des Geraets (Android: ACTION_VIEW). Der Bereich ist ab Werk aus,
wird nur mit Eltern-/Erwachsenen-PIN geoeffnet und fuer Kinderprofile komplett gesperrt (oberflaeche_lesezeichen.py)."""

import re
import secrets
from urllib.parse import urlsplit

SCHLUESSEL = "ab18_lesezeichen"
MAX_EINTRAEGE = 200
MAX_URL = 500
MAX_NAME = 80
_STEUER = re.compile(r"[\x00-\x20\x7f]")


class LesezeichenFehler(ValueError):
    pass


def lesen(daten):
    """Bereinigte Kopie des Bereichs (kaputte Eintraege fliegen raus)."""
    roh = (daten or {}).get(SCHLUESSEL)
    roh = roh if isinstance(roh, dict) else {}
    liste = []
    for e in roh.get("liste") if isinstance(roh.get("liste"), list) else []:
        try:
            liste.append({"id": str(e["id"])[:40], "name": name_pruefen(e.get("name"), e["url"]), "url": url_pruefen(e["url"])})
        except (LesezeichenFehler, KeyError, TypeError, AttributeError):
            continue
    return {"an": roh.get("an") is True, "liste": liste[:MAX_EINTRAEGE]}


def _schreiben(daten, bereich):
    daten[SCHLUESSEL] = bereich


def url_pruefen(url):
    """Nur http(s)://host/..., ohne Zugangsdaten in der Adresse, ohne Leer- und Steuerzeichen."""
    url = str(url or "").strip()
    if not url or len(url) > MAX_URL or _STEUER.search(url):
        raise LesezeichenFehler("Adresse fehlt, ist zu lang oder enthält Leerzeichen")
    teile = urlsplit(url)
    if teile.scheme not in ("http", "https") or not teile.hostname:
        raise LesezeichenFehler("Adresse muss mit http:// oder https:// beginnen")
    if teile.username is not None or teile.password is not None:
        raise LesezeichenFehler("Adressen mit Benutzer und Passwort sind nicht erlaubt")
    try:
        _ = teile.port  # wirft ValueError bei ungueltigem Port
    except ValueError:
        raise LesezeichenFehler("Ungültiger Port")
    return url


def name_pruefen(name, url):
    name = " ".join(str(name or "").split())[:MAX_NAME]
    return name or (urlsplit(str(url)).hostname or "Lesezeichen")


def einstellen(daten, an):
    b = lesen(daten)
    b["an"] = an is True
    _schreiben(daten, b)
    return b["an"]


def hinzu(daten, name, url):
    b = lesen(daten)
    url = url_pruefen(url)
    if any(e["url"] == url for e in b["liste"]):
        raise LesezeichenFehler("Diese Adresse ist schon eingetragen")
    if len(b["liste"]) >= MAX_EINTRAEGE:
        raise LesezeichenFehler("Höchstens %d Lesezeichen" % MAX_EINTRAEGE)
    eintrag = {"id": secrets.token_hex(6), "name": name_pruefen(name, url), "url": url}
    b["liste"].append(eintrag)
    _schreiben(daten, b)
    return eintrag


def umbenennen(daten, kennung, name):
    b = lesen(daten)
    for e in b["liste"]:
        if e["id"] == str(kennung):
            e["name"] = name_pruefen(name, e["url"])
            _schreiben(daten, b)
            return e
    raise LesezeichenFehler("Lesezeichen nicht gefunden")


def weg(daten, kennung):
    b = lesen(daten)
    neu = [e for e in b["liste"] if e["id"] != str(kennung)]
    if len(neu) == len(b["liste"]):
        raise LesezeichenFehler("Lesezeichen nicht gefunden")
    b["liste"] = neu
    _schreiben(daten, b)
