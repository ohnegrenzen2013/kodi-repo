"""Bereich "Sicherheit" -> afwall: Netz-Freigaben je App (WLAN, Mobilfunk, VPN, Roaming).

Nach dem Vorbild von AFWall+ (https://github.com/ukanth/afwall, GPL-2.0-or-later). H0rSt merkt sich für jede
App, auf welchen Netzen sie ins Internet darf, und erzeugt daraus ein iptables-Skript. Ausgeführt wird das
Skript dort, wo es Root gibt: in der H0rSt-App auf Android (die App ruft `su` auf) oder auf PC/Pi (der Server
läuft als root). Ohne Root zeigt H0rSt nur die Regeln und das Skript zum Kopieren.

Zwei Betriebsarten wie bei AFWall+:
  * blacklist ("Angekreuzte Apps werden gesperrt"): erlaubt ist, was ein Netz benutzen darf, der Rest wird
    auf dem jeweiligen Netz gesperrt. Ab Werk an.
  * whitelist ("Nur angekreuzte Apps dürfen ins Netz"): nur die angekreuzten Apps kommen durch, alles andere
    wird gesperrt (root bleibt erlaubt, sonst würde das Gerät verstummen).

Profile (z. B. "Zuhause" und "Unterwegs") halten je einen eigenen Satz Regeln. Die App-Liste kommt von der
Android-App (Paketname, Name, System-App ja/nein, UID) und liegt in den Nutzerdaten unter "afwall".

  GET  /api/afwall                    Stand: Einstellungen, Profile, Apps mit Regeln, iptables-Skript, Root ja/nein
  GET  /api/afwall/export             Regeln als JSON zum Sichern
  POST /api/afwall                    {aktiv|modus|profil|systemfilter|apps|regel|regeln|alle|profil_*|importieren}
  POST /api/afwall/apps               {apps} von der Android-App
  POST /api/afwall/anwenden           {einstellungen} speichern und Skript setzen oder zum Kopieren zurückgeben

Das Skript richtet die Ketten afwall und afwall_<netz> ein und hängt sie an OUTPUT. Gesperrt wird über
`-m owner --uid-owner <uid>`. Apps ohne UID (noch nicht von der App gemeldet) werden ausgelassen.
"""

import logging
import os
import subprocess
import time

from .afwall_grund import *  # noqa: F403
from .afwall_grund import _apps, _beruecksichtigt  # noqa: F401

log = logging.getLogger("rezeptserver")

NETZ_NAMEN = {"wlan": "WLAN", "mobil": "Mobilfunk", "vpn": "VPN", "roaming": "Roaming"}
# Ausgabe-Schnittstelle je Netz (iptables -o): WLAN, Mobilfunk (rmnet/ccmni), VPN-Tunnel, Roaming wie Mobilfunk.
SCHNITTSTELLEN = {"wlan": "wlan0+", "mobil": "rmnet+", "vpn": "tun+", "roaming": "rmnet+"}


STANDARD = {
    "aktiv": False,
    "modus": "blacklist",
    "profil": "standard",
    "systemfilter": False,
    "apps": [],       # [{paket, name, system, uid}] von der Android-App
    "profile": {},    # eigene Profile: {id: {name, regeln}}
}


# Laufender Stand der letzten Anwendung (Server als root).
STATUS = {"aktiv": False, "zeit": 0, "fehler": "", "hinweis": ""}


# --- Regeln und Skript ---------------------------------------------------------------------------
def _ausgewaehlt(profile, pid, paket, netz):
    return bool(((profile.get(pid) or {}).get("regeln") or {}).get(paket, {}).get(netz))


def plan(e):
    """iptables-Zeilen und Zähler aus den Einstellungen bauen."""
    e = e if "profile" in e else pruefe(e)
    profile = e["profile"]
    pid, modus = e["profil"], e["modus"]
    zeilen = ["#!/system/bin/sh",
              "# H0rSt afwall – erzeugt aus den Regeln (%s). Nicht von Hand ändern." % MODI[modus],
              "# Profil: %s" % (profile.get(pid) or {}).get("name", pid),
              "A=afwall"]
    zaehler = {"regeln": 0, "blockiert": 0, "apps": 0}
    for netz in NETZE:
        zeilen += ["iptables -N afwall_%s 2>/dev/null" % netz, "iptables -F afwall_%s" % netz]
    zeilen += ["iptables -N $A 2>/dev/null", "iptables -F $A",
               "iptables -D OUTPUT -j $A 2>/dev/null", "iptables -A OUTPUT -j $A"]
    for netz in NETZE:
        zeilen.append("iptables -A $A -o %s -j afwall_%s" % (SCHNITTSTELLEN[netz], netz))
    for app in e["apps"]:
        if not _beruecksichtigt(e, app):
            continue
        uid = app.get("uid") or 0
        for netz in NETZE:
            aus = _ausgewaehlt(profile, pid, app["paket"], netz)
            if not aus and modus == "blacklist":
                continue
            if not uid:  # ohne UID kann iptables die App nicht zuordnen
                continue
            gesperrt = aus if modus == "blacklist" else not aus
            ziel = "REJECT" if gesperrt else "RETURN"
            zeilen.append("iptables -A afwall_%s -m owner --uid-owner %d -j %s" % (netz, uid, ziel))
            zaehler["regeln"] += 1
            if ziel == "REJECT":
                zaehler["blockiert"] += 1
        zaehler["apps"] += 1
    if modus == "whitelist":  # nur Angekreuztes darf, root bleibt erlaubt
        for netz in NETZE:
            zeilen.append("iptables -A afwall_%s -m owner --uid-owner 0 -j RETURN" % netz)
            zeilen.append("iptables -A afwall_%s -j REJECT" % netz)
            zaehler["blockiert"] += 1
    zeilen.append("# %d Regeln, %d Sperren" % (zaehler["regeln"], zaehler["blockiert"]))
    return zeilen, zaehler


def skript(e):
    zeilen, _ = plan(e)
    return "\n".join(zeilen) + "\n"


def wurzel():
    """Läuft der Server als root? Nur dann kann er iptables selbst setzen."""
    return hasattr(os, "geteuid") and os.geteuid() == 0


def _system_ausfuehren(text):
    if os.name != "posix":
        return False, "Nur auf Linux (PC, Pi) oder in der App auf Android mit Root möglich"
    try:
        lauf = subprocess.run(["sh", "-c", text], capture_output=True, text=True, timeout=30)
    except FileNotFoundError:
        return False, "sh nicht gefunden"
    except subprocess.SubprocessError as fehler:
        return False, str(fehler)[:300]
    if lauf.returncode != 0:
        return False, (lauf.stderr or "iptables-Fehler").strip()[:300]
    return True, ""


def anwenden(e, ausfuehren=None):
    """Regeln setzen. `ausfuehren(text)` überschreibt den Aufruf (App, Tests). Gibt {ok, meldung, skript}."""
    text = skript(e)
    if ausfuehren is None:
        if not wurzel():
            STATUS.update(aktiv=False, zeit=0, fehler="Ohne Root kann H0rSt die Regeln nicht selbst setzen.",
                          hinweis="In der App anwenden oder das Skript auf einem Gerät mit Root ausführen.")
            return {"ok": False, "meldung": STATUS["fehler"], "skript": text}
        ausfuehren = _system_ausfuehren
    try:
        ok, meldung = ausfuehren(text)
    except Exception as fehler:  # noqa: BLE001 – Netz, Rechte, kaputtes Skript
        ok, meldung = False, str(fehler)[:300]
    if ok:
        STATUS.update(aktiv=True, zeit=int(time.time()), fehler="", hinweis="")
        log.info("afwall: Regeln gesetzt")
    else:
        STATUS.update(aktiv=False, fehler=meldung or "Unbekannter Fehler", hinweis="")
        log.info("afwall: Regeln nicht gesetzt (%s)", meldung)
    return {"ok": ok, "meldung": meldung, "skript": text}


def beim_start(daten):
    """Beim Serverstart die gespeicherten Regeln erneut setzen, wenn "aktiv" und root (PC, Pi). Gibt die Einstellung."""
    e = pruefe((daten or {}).get(SCHLUESSEL))
    if e["aktiv"] and wurzel():
        anwenden(e)
    return e


# --- Zustand -------------------------------------------------------------------------------------
def zustand(daten, apps=None):
    e = pruefe((daten or {}).get(SCHLUESSEL))
    if apps is not None:
        e["apps"] = _apps(apps)
    profile = e["profile"]
    pid = e["profil"]
    liste = []
    for app in e["apps"]:
        liste.append(dict(app, regel={netz: _ausgewaehlt(profile, pid, app["paket"], netz) for netz in NETZE}))
    _, zaehler = plan(e)
    return {
        "einstellungen": {k: e[k] for k in ("aktiv", "modus", "profil", "systemfilter")},
        "modi": [{"id": k, "name": v} for k, v in MODI.items()],
        "netze": [{"id": n, "name": NETZ_NAMEN[n]} for n in NETZE],
        "profile": [{"id": p, "name": v["name"], "eigene": v["eigene"], "aktiv": p == pid} for p, v in profile.items()],
        "apps": liste,
        "zaehler": zaehler,
        "skript": skript(e),
        "wurzel": wurzel(),
        "status": dict(STATUS),
    }
