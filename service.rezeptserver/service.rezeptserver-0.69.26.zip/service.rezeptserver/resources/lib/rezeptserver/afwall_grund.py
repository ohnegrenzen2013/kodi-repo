"""afwall, Grundlage: Einstellungen pruefen und Aenderungen an den Nutzerdaten.

Paket-/UID-Pruefung, Regeln je Profil, pruefe(), aendern() samt Profilpflege und exportieren(). Das
iptables-Skript und seine Anwendung stehen in afwall.py.
"""

import re

SCHLUESSEL = "afwall"

# Netze (Spalten), die je App einzeln erlaubt oder gesperrt werden können.
NETZE = ("wlan", "mobil", "vpn", "roaming")
MODI = {"blacklist": "Angekreuzte Apps werden gesperrt", "whitelist": "Nur angekreuzte Apps dürfen ins Netz"}

# Ab Werk vorhandene Profile; eigene Profile kommen in den Nutzerdaten dazu.
PROFILE_STANDARD = {
    "standard": "Standard",
    "zuhause": "Zuhause (WLAN)",
    "unterwegs": "Unterwegs (Mobilfunk)",
}

_PAKET = re.compile(r"^[A-Za-z0-9_][A-Za-z0-9_.]{0,119}$")


class AfwallFehler(ValueError):
    pass


# --- Einstellungen ------------------------------------------------------------------------------
def _paket(roh):
    roh = str(roh or "").strip()
    if not _PAKET.match(roh):
        raise AfwallFehler("Ungültiger Paketname: %s" % (roh[:40] or "–"))
    return roh


def _uid(roh):
    try:
        wert = int(roh)
    except (TypeError, ValueError):
        return 0
    return wert if 0 <= wert <= 999999 else 0


def _apps(roh):
    """App-Liste der Android-App: Paketname, Anzeigename, System-App, UID."""
    liste = []
    gesehen = set()
    for x in (roh or [])[:4000]:
        if not isinstance(x, dict):
            continue
        try:
            paket = _paket(x.get("paket"))
        except AfwallFehler:
            continue
        if paket in gesehen:
            continue
        gesehen.add(paket)
        liste.append({"paket": paket, "name": " ".join(str(x.get("name") or paket).split())[:80],
                      "system": x.get("system") is True, "uid": _uid(x.get("uid"))})
    return liste


def _regeln(roh):
    """Regeln je Paket und Netz: {paket: {netz: bool}}."""
    regeln = {}
    for paket, werte in (roh or {}).items():
        try:
            paket = _paket(paket)
        except AfwallFehler:
            continue
        if not isinstance(werte, dict):
            continue
        sauber = {netz: werte.get(netz) is True for netz in NETZE}
        if any(sauber.values()):
            regeln[paket] = sauber
    return regeln


def _profile(roh):
    """Profile zusammenführen: die Standard-Profile zuerst, danach eigene. Regeln aller Profile bleiben."""
    profile = {}
    eigene = roh if isinstance(roh, dict) else {}
    for pid, name in PROFILE_STANDARD.items():
        eintrag = eigene.get(pid) or {}
        profile[pid] = {"name": name, "eigene": False, "regeln": _regeln(eintrag.get("regeln"))}
    for pid, eintrag in eigene.items():
        pid = str(pid or "").strip()
        if not pid or pid in PROFILE_STANDARD or not re.match(r"^[a-z0-9_]{1,30}$", pid):
            continue
        name = " ".join(str((eintrag or {}).get("name") or pid).split())[:60]
        profile[pid] = {"name": name, "eigene": True, "regeln": _regeln((eintrag or {}).get("regeln"))}
    return profile


def pruefe(roh):
    roh = roh if isinstance(roh, dict) else {}
    profile = _profile(roh.get("profile"))
    return {
        "aktiv": roh.get("aktiv") is True,
        "modus": roh.get("modus") if roh.get("modus") in MODI else "blacklist",
        "profil": roh.get("profil") if roh.get("profil") in profile else "standard",
        "systemfilter": roh.get("systemfilter") is True,
        "apps": _apps(roh.get("apps")),
        "profile": profile,
    }


def _beruecksichtigt(e, app):
    """System-Apps nur, wenn der Systemfilter an ist."""
    return not app.get("system") or e["systemfilter"]


# --- Änderungen an den Nutzerdaten ----------------------------------------------------------------
def _regeln_von(profile, pid):
    return profile.setdefault(pid, {"name": pid, "eigene": pid not in PROFILE_STANDARD, "regeln": {}})["regeln"]


def aendern(daten, wunsch):
    """Änderung unter "afwall": {aktiv|modus|profil|systemfilter|apps|regel|regeln|alle|profil_anlegen|
    profil_umbenennen|profil_weg|importieren}. Gibt die geprüfte Einstellung zurück."""
    if not isinstance(wunsch, dict):
        raise AfwallFehler("JSON-Objekt erwartet")
    fertig = pruefe(daten.get(SCHLUESSEL))
    profile = fertig["profile"]
    pid = fertig["profil"]
    if "importieren" in wunsch:
        neu = pruefe(wunsch.get("importieren"))
        daten[SCHLUESSEL] = _speicherbar(neu)
        return neu
    if "aktiv" in wunsch:
        fertig["aktiv"] = wunsch["aktiv"] is True
    if "modus" in wunsch:
        if wunsch["modus"] not in MODI:
            raise AfwallFehler("modus: blacklist oder whitelist")
        fertig["modus"] = wunsch["modus"]
    if "systemfilter" in wunsch:
        fertig["systemfilter"] = wunsch["systemfilter"] is True
    if "apps" in wunsch:
        fertig["apps"] = _apps(wunsch["apps"])
    if "profil" in wunsch:
        if wunsch["profil"] not in profile:
            raise AfwallFehler("Unbekanntes Profil")
        fertig["profil"] = pid = wunsch["profil"]
    if "profil_anlegen" in wunsch:
        neu = wunsch["profil_anlegen"] if isinstance(wunsch["profil_anlegen"], dict) else {}
        x = str(neu.get("id") or "").strip().lower()
        if not re.match(r"^[a-z0-9_]{1,30}$", x) or x in profile:
            raise AfwallFehler("Profil-Kennung schon vergeben oder ungültig")
        profile[x] = {"name": " ".join(str(neu.get("name") or x).split())[:60] or x, "eigene": True, "regeln": {}}
        fertig["profil"] = pid = x
    if "profil_umbenennen" in wunsch:
        x = wunsch["profil_umbenennen"] if isinstance(wunsch["profil_umbenennen"], dict) else {}
        ziel = x.get("id")
        if ziel not in profile or not profile[ziel]["eigene"]:
            raise AfwallFehler("Nur eigene Profile lassen sich umbenennen")
        profile[ziel]["name"] = " ".join(str(x.get("name") or ziel).split())[:60] or ziel
    if "profil_weg" in wunsch:
        if pid not in profile or not profile[pid]["eigene"]:
            raise AfwallFehler("Nur eigene Profile lassen sich entfernen")
        del profile[pid]
        fertig["profil"] = pid = "standard"
    if "regel" in wunsch:
        r = wunsch["regel"] if isinstance(wunsch["regel"], dict) else {}
        paket = _paket(r.get("paket"))
        for netz in NETZE:
            if netz in r:
                _regeln_von(profile, pid).setdefault(paket, {})[netz] = r[netz] is True
    if "regeln" in wunsch:
        r = wunsch["regeln"] if isinstance(wunsch["regeln"], dict) else {}
        paket = _paket(r.get("paket"))
        eintrag = _regeln_von(profile, pid).setdefault(paket, {})
        for netz in NETZE:
            if netz in r:
                eintrag[netz] = r[netz] is True
    if "alle" in wunsch:
        wert = wunsch["alle"] is True
        regeln = _regeln_von(profile, pid)
        for app in fertig["apps"]:
            if not _beruecksichtigt(fertig, app):
                continue
            if wert:
                regeln[app["paket"]] = dict.fromkeys(NETZE, True)
            else:
                regeln.pop(app["paket"], None)
    fertig["profile"] = profile
    daten[SCHLUESSEL] = _speicherbar(fertig)
    return pruefe(daten[SCHLUESSEL])


def _speicherbar(e):
    """Nur die Regeln der Profile sichern, die welche haben oder eigene sind."""
    return {
        "aktiv": e["aktiv"], "modus": e["modus"], "profil": e["profil"], "systemfilter": e["systemfilter"],
        "apps": e["apps"],
        "profile": {pid: {"name": p["name"], "regeln": p["regeln"]}
                    for pid, p in e["profile"].items() if p["eigene"] or p["regeln"]},
    }


def exportieren(daten):
    e = pruefe((daten or {}).get(SCHLUESSEL))
    return {"format": "h0rst-afwall", "version": 1, "aktiv": e["aktiv"], "modus": e["modus"],
            "profil": e["profil"], "systemfilter": e["systemfilter"],
            "profile": {pid: {"name": p["name"], "regeln": p["regeln"]} for pid, p in e["profile"].items()}}
