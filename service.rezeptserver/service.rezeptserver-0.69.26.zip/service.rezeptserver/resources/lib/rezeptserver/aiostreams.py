"""AIOStreams: eine eigene Instanz fuer Stremio, ARVIO, Nuvio Mobile und Nuvio TV.

Vorbilder: alpinezx/easy-aiostreams (MIT) installiert eine AIOStreams-Instanz mit
Docker, Caddy und Login in einem Befehl; Viren070/AIOStreams (AGPL-3.0) buendelt
Stremio-Addons, Debrid und Usenet zu einem einzigen Addon.

H0rSt startet nichts und speichert keine Zugangsdaten. Es prueft die vom Nutzer
eingetragene manifest.json, zeigt Installationsbefehle und die Hinweise fuer die
Clients und kann die manifest.json als eigenes Stremio-Addon uebernehmen. Damit
kommen die Streams aus AIOStreams in H0rSt, Stremio, ARVIO, Nuvio Mobile und
Nuvio TV an.
"""

import json
import re
from urllib.parse import quote, urlsplit, urlunsplit

from .netz import Abrufer, NetzFehler, oeffentlich_holen, urllib_holen

NAME = "AIOStreams"
REPO = "https://github.com/Viren070/AIOStreams"
LIZENZ = "AGPL-3.0"
INSTALLER = "Easy AIOStreams"
INSTALLER_REPO = "https://github.com/alpinezx/easy-aiostreams"
INSTALLER_LIZENZ = "MIT"
DOKU = "https://docs.aiostreams.viren070.me"
CONFIGURE_PFAD = "/stremio/configure"
DASHBOARD_PFAD = "/dashboard"
ZEITGRENZE = 12.0
MAX_KATALOGE = 200


class AioStreamsFehler(ValueError):
    pass


_SCHEMA = re.compile(r"^[A-Za-z][A-Za-z0-9+.-]*:")


def _teile(text):
    text = str(text or "").strip()
    if text.lower().startswith("stremio://"):
        text = "https://" + text[len("stremio://"):]
    if text and "://" not in text:
        if _SCHEMA.match(text) or any(zeichen.isspace() for zeichen in text):
            return None
        text = "https://" + text
    try:
        teile = urlsplit(text)
        host = teile.hostname
        teile.port  # noqa: B018 - ungueltige Ports werfen ValueError
    except ValueError:
        return None
    if teile.scheme not in ("http", "https") or not host or teile.username or teile.password:
        return None
    return teile


def basis_url(wert):
    """Basis-Adresse ohne Schraegstrich am Ende; "" bei ungueltiger Eingabe."""
    teile = _teile(wert)
    if not teile:
        return ""
    pfad = teile.path.rstrip("/")
    for endung in ("/stremio/configure", "/dashboard", "/configure"):
        if pfad.lower().endswith(endung):
            pfad = pfad[:-len(endung)]
            break
    return urlunsplit((teile.scheme, teile.netloc, pfad, "", ""))


def manifest_url(wert):
    """Vollstaendige manifest.json. Eine Basis-Adresse allein reicht nicht, weil die
    Konfiguration in Pfad und Passwort steckt; dann kommt "" zurueck."""
    teile = _teile(wert)
    if not teile:
        return ""
    pfad = teile.path.rstrip("/")
    if pfad.lower().endswith(".json"):
        return urlunsplit((teile.scheme, teile.netloc, pfad, teile.query, ""))
    if pfad.lower().endswith(("/stremio/configure", "/dashboard", "/configure")):
        return ""
    if "/stremio/" in pfad:
        return urlunsplit((teile.scheme, teile.netloc, pfad + "/manifest.json", teile.query, ""))
    return ""


def gleiche(erste, zweite):
    a, b = manifest_url(erste), manifest_url(zweite)
    return bool(a) and a == b


def _host(url):
    return (urlsplit(url).hostname or "").lower()


def _ist_manifest(roh):
    return isinstance(roh, dict) and isinstance(roh.get("id"), str) and "resources" in roh \
        and ("types" in roh or "catalogs" in roh)


def _holen(heimnetz, holen=None):
    if holen is not None:
        return holen
    return urllib_holen if heimnetz else oeffentlich_holen()


def manifest_lesen(url, heimnetz=False, holen=None):
    """Manifest abrufen und zusammenfassen. heimnetz erlaubt private Adressen (SSRF-Schutz aus)."""
    adresse = manifest_url(url)
    if not adresse:
        raise AioStreamsFehler("Vollstaendige manifest.json eintragen, z. B. "
                               "https://aio.example.com/stremio/<uuid>/<passwort>/manifest.json")
    abrufer = Abrufer([_host(adresse)], holen=_holen(heimnetz, holen), zeitgrenze=ZEITGRENZE)
    try:
        text = abrufer.abruf(adresse)
    except (NetzFehler, ValueError) as fehler:
        raise AioStreamsFehler("Manifest nicht erreichbar: %s" % fehler)
    try:
        roh = json.loads(text)
    except ValueError:
        raise AioStreamsFehler("Unter der Adresse antwortet kein JSON.")
    if not _ist_manifest(roh):
        raise AioStreamsFehler("Unter der Adresse liegt keine Stremio-manifest.json.")
    hinweise = roh.get("behaviorHints") if isinstance(roh.get("behaviorHints"), dict) else {}
    if hinweise.get("configurationRequired") is True:
        raise AioStreamsFehler("Diese manifest.json ist noch nicht eingerichtet. In AIOStreams "
                               "speichern und die Adresse aus „Save & Install“ nehmen.")
    ressourcen = []
    for eintrag in roh.get("resources") or []:
        name = eintrag if isinstance(eintrag, str) else eintrag.get("name") if isinstance(eintrag, dict) else ""
        if name and name not in ressourcen:
            ressourcen.append(str(name)[:40])
    typen = [str(t)[:20] for t in roh.get("types") or [] if isinstance(t, str)][:20]
    kataloge = [k for k in roh.get("catalogs") or [] if isinstance(k, dict)]
    return {"name": str(roh.get("name") or roh.get("id") or NAME)[:80], "id": str(roh["id"])[:120],
            "version": str(roh.get("version") or "")[:40], "beschreibung": str(roh.get("description") or "")[:400],
            "logo": str(roh.get("logo") or "")[:1000], "typen": typen, "ressourcen": ressourcen,
            "kataloge": min(len(kataloge), MAX_KATALOGE)}


def kunden(adresse=""):
    """Installationswege fuer die vier Clients. ARVIO und Nuvio nehmen dieselbe manifest.json."""
    ohne = adresse.split("://", 1)[1] if adresse and "://" in adresse else ""
    return [
        {"id": "stremio", "name": "Stremio", "url": "stremio://" + ohne if ohne else "",
         "hinweis": "Öffnet Stremio und installiert das Addon. Alternativ die manifest.json unter "
                    "Addons → Community-Addons → Addon installieren einfügen."},
        {"id": "stremio-web", "name": "Stremio Web",
         "url": "https://web.stremio.com/#/addons?addon=" + quote(adresse, safe="") if adresse else "",
         "hinweis": "Im Browser öffnen; die manifest.json lässt sich dort ebenfalls einfügen."},
        {"id": "arvio", "name": "ARVIO", "url": adresse,
         "hinweis": "Einstellungen → Addons → Addon per URL hinzufügen, dann die manifest.json einfügen. "
                    "ARVIO liest Kataloge, Streams, Metadaten und Untertitel wie aus Stremio."},
        {"id": "nuvio", "name": "Nuvio Mobile / Nuvio TV", "url": adresse,
         "hinweis": "Addons → Addon hinzufügen und die manifest.json einfügen. Nuvio Mobile und Nuvio TV "
                    "sprechen dasselbe Stremio-Protokoll."},
    ]


def befehle(werte=None):
    """Einrichtung als Befehlsliste; ohne Passwoerter oder Schluessel."""
    werte = werte if isinstance(werte, dict) else {}
    basis = basis_url(werte.get("aiostreams_basis"))
    return [
        {"titel": "Easy AIOStreams installieren (VPS oder Heimrechner, empfohlen)",
         "befehl": "sudo mkdir -p /opt/aiostreams && cd /opt/aiostreams\n"
                   "sudo curl -fsSL https://raw.githubusercontent.com/alpinezx/easy-aiostreams/"
                   "refs/heads/main/scripts/core/setup-aiostreams.sh -o setup-aiostreams.sh\n"
                   "sudo bash setup-aiostreams.sh",
         "hinweis": "Für einen VPS mit Domain (Docker, Caddy, HTTPS und Login). Auf einem Heimrechner "
                    "fragt das Skript nach dem Weg über einen Cloudflare Tunnel."},
        {"titel": "Oder die offizielle Docker-Variante",
         "befehl": "curl -O https://raw.githubusercontent.com/Viren070/AIOStreams/main/compose.yaml\n"
                   "curl -o .env https://raw.githubusercontent.com/Viren070/AIOStreams/main/.env.sample\n"
                   "# SECRET_KEY in .env setzen (64 Hex-Zeichen), dann:\n"
                   "docker compose up -d",
         "hinweis": "Ohne fertige Domain: AIOStreams lauscht standardmäßig auf Port 3000."},
        {"titel": "Konfigurieren und manifest.json holen",
         "befehl": (basis + CONFIGURE_PFAD) if basis else "<basis-adresse>" + CONFIGURE_PFAD,
         "hinweis": "Im Browser öffnen, Dienste und Addons wählen, mit einem Passwort speichern und unter "
                    "„Save & Install“ die manifest.json kopieren. Diese Adresse enthält den verschlüsselten "
                    "Konfigurationstoken – wie ein Passwort behandeln."},
    ]


def zustand(werte=None, pruefen=False, holen=None):
    werte = werte if isinstance(werte, dict) else {}
    an = werte.get("aiostreams_an") is not False
    basis = basis_url(werte.get("aiostreams_basis"))
    roh_manifest = str(werte.get("aiostreams_manifest") or "").strip()
    manifest = manifest_url(roh_manifest)
    heimnetz = werte.get("aiostreams_heimnetz") is True
    fehler = ""
    if str(werte.get("aiostreams_basis") or "").strip() and not basis:
        fehler = "Basis-Adresse ist keine gültige http(s)-Adresse."
    elif roh_manifest and not manifest:
        fehler = "Manifest-Adresse: die vollständige manifest.json aus „Save & Install“ eintragen."
    if not an:
        meldung = "Ausgeschaltet – AIOStreams wird nicht geprüft."
    elif fehler:
        meldung = fehler
    elif not manifest:
        meldung = ("Basis-Adresse gespeichert. Für Prüfung und Übernahme noch die vollständige "
                   "manifest.json eintragen." if basis else
                   "Noch keine Adresse eingetragen. Installation und manifest.json stehen unten.")
    else:
        meldung = "Manifest gespeichert – noch nicht geprüft."
    stand = {"name": NAME, "an": an, "basis": basis, "manifest": manifest, "heimnetz": heimnetz,
             "basis_gesetzt": bool(basis), "manifest_gesetzt": bool(manifest), "meldung": meldung,
             "befehle": befehle(werte), "kunden": kunden(manifest),
             "urls": {"configure": basis + CONFIGURE_PFAD if basis else "",
                      "dashboard": basis + DASHBOARD_PFAD if basis else ""},
             "installer": {"name": INSTALLER, "repo": INSTALLER_REPO, "lizenz": INSTALLER_LIZENZ},
             "offiziell": {"name": NAME, "repo": REPO, "lizenz": LIZENZ}, "doku": DOKU}
    if pruefen:
        if not an:
            raise AioStreamsFehler("AIOStreams ist in den Einstellungen ausgeschaltet.")
        if fehler:
            raise AioStreamsFehler(fehler)
        info = manifest_lesen(manifest, heimnetz, holen)
        stand["manifest_info"] = info
        stand["meldung"] = "%s %s ist erreichbar – %s Kataloge, %s." % (
            info.get("name") or NAME, info.get("version") or "", info.get("kataloge", 0),
            ", ".join(info.get("ressourcen") or []) or "keine Ressourcen")
    return stand
