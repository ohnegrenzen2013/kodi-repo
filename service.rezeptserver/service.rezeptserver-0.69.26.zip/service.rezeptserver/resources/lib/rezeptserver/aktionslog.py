"""Aktivitaetsprotokoll: was H0rSt in der Dienste-Zentrale und im Stack-Assistenten getan hat (ohne Geheimnisse).

Vorbild fuer den Gedanken ist das Protokoll von nzbfast und der iOS-App "Silo UNM" (Verhalten, kein Code): jede Aktion
mit Zeit, Art und Ziel, damit man nachvollziehen kann, was passiert ist. Hier steht nur, was H0rSt selbst ausloest
(Download hinzufuegen, pausieren, Anfrage, Assistent) - die Meldungen von NZBGet selbst kommen live von dort.

  * bereinigen(text)   entfernt Passwoerter ({{...}}), Schluessel (apikey=, password=, token=), Zugangsdaten in Adressen
  * AktionsLog         Ringpuffer (letzte 300 Eintraege) in aktionen.json neben den Nutzerdaten
"""

import json
import os
import re
import threading
import time

MAX_EINTRAEGE = 300
MAX_TEXT = 240
_MUSTER = (
    (re.compile(r"\{\{[^{}]*\}\}"), "{{…}}"),
    (re.compile(r"(?i)\b(api[-_ ]?key|apikey|password|passwd|pass|passwort|token|secret|pw|sitzung|key)(\s*[=:]\s*)[^\s&;,\"']+"), r"\1\2<geheim>"),
    (re.compile(r"(?i)(://)[^/\s:@]+:[^/\s@]+@"), r"\1<zugang>@"),
    (re.compile(r"(?i)\b(Bearer|Basic)\s+[A-Za-z0-9._~+/=-]{8,}"), r"\1 <geheim>"),
)


def bereinigen(text):
    text = " ".join(str(text if text is not None else "").split())
    for muster, ersatz in _MUSTER:
        text = muster.sub(ersatz, text)
    return text[:MAX_TEXT]


class AktionsLog:
    def __init__(self, ordner, uhr=time.time):
        self.datei = os.path.join(ordner, "aktionen.json") if ordner else ""
        self.uhr = uhr
        self._sperre = threading.Lock()

    def _lesen(self):
        if not self.datei:
            return []
        try:
            with open(self.datei, encoding="utf-8") as f:
                liste = json.load(f)
        except (OSError, ValueError):
            return []
        return liste if isinstance(liste, list) else []

    def eintragen(self, art, text, ok=True, wer=""):
        """art: kurzes Wort (hinzufuegen, pausieren, assistent ...); text wird bereinigt."""
        eintrag = {"zeit": int(self.uhr()), "art": bereinigen(art)[:40], "text": bereinigen(text), "ok": bool(ok),
                   "wer": bereinigen(wer)[:40]}
        if not self.datei:
            return eintrag
        with self._sperre:
            liste = (self._lesen() + [eintrag])[-MAX_EINTRAEGE:]
            try:
                os.makedirs(os.path.dirname(self.datei) or ".", exist_ok=True)
                with open(self.datei + ".neu", "w", encoding="utf-8") as f:
                    json.dump(liste, f, ensure_ascii=False)
                os.replace(self.datei + ".neu", self.datei)
            except OSError:
                pass  # Protokoll ist Beiwerk: nie die Aktion selbst kippen
        return eintrag

    def lesen(self, anzahl=100):
        with self._sperre:
            return list(reversed(self._lesen()[-max(1, min(int(anzahl), MAX_EINTRAEGE)):]))
