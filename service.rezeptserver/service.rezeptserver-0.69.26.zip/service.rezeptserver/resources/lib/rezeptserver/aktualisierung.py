"""Aktualisierung aus GitHub: H0rSt und die Rezepte bleiben auf dem Stand des Repos, auf allen Geraeten.

Quelle ist ein GitHub-Repo (Standard: das H0rSt-Repo) und ein Zweig. Fuer private Repos braucht es ein Token
(GitHub → Settings → Developer settings → Fine-grained token, nur "Contents: Read" fuer dieses Repo).

  * Pruefen: letzter Commit des Zweigs und die Version in rezeptserver/__init__.py.
  * Aktualisieren: das Repo als ZIP laden, rezeptserver/ und rezepte/ nach <Datenordner>/aktuell/ entpacken,
    jede .py-Datei uebersetzen (Syntaxpruefung) und erst dann gegen die bisherige Fassung tauschen. Die vorige
    bleibt als aktuell.alt fuer "Zurueck". Der Programmordner selbst wird nie veraendert (auf dem Pi ist er
    schreibgeschuetzt, in der App und in Kodi gehoert er dem Paket).
  * Systemweit: Jeder Startweg (python -m rezeptserver / Pi-Dienst, Kodi-Addon, Android-App) nimmt die Fassung
    aus aktuell/, wenn sie neuer ist als die eingebaute. Ein neueres App- oder Addon-Paket gewinnt also wieder.
  * Automatisch: alle paar Stunden pruefen und melden (Telegram, App) oder gleich installieren. Der Server startet
    danach neu, wo das geht (PC, Pi); in Kodi und in der App wirkt es beim naechsten Start des Dienstes.

Langzeitbetrieb: "wartung" zeigt fuer jeden Baustein (Python, Betriebssystem, Datenbank, PHP ...) das Support-Ende und
warnt ein halbes Jahr vorher; automatische Sicherungen (taeglich/woechentlich, die letzten n, dazu vor jedem Update)
liegen in <Datenordner>/sicherungen – so muss man das System nie neu aufsetzen.

Nutzerdaten "aktualisierung": {"repo", "zweig", "token", "auto": "aus"|"melden"|"installieren", "stunden",
                               "sicherung": "aus"|"taeglich"|"woechentlich", "behalten"}
Stand in <Datenordner>/aktuell/stand.json: {"sha", "version", "zeit", "repo", "zweig"}

App (APK): Python-Teile kommen ueber aktuell/, die App selbst (Player, Codecs wie Media3 und FFmpeg, WireGuard)
nur mit einem neuen Paket. Der Android-Build legt jede APK von main als Release "app-<version>-<commit>" ab
(Text mit "sha: ..."); die neueste davon zaehlt.
app_pruefen() vergleicht deren Commit mit dem der installierten App, app_laden() holt die APK (mit Token, auch aus
privaten Repos) nach <Datenordner>/h0rst-app.apk; die App installiert sie dann selbst.
"""

import sqlite3

from .aktualisierung_grund import *
from .aktualisierung_grund import _REPO, _SHA, _VERSION, _VERSION_APP, __version__, _asset_laden, _stand
from .aktualisierung_kern import KernMixin as _KernMixin
from .aktualisierung_sicherung import SicherungMixin as _SicherungMixin
from .aktualisierung_github import GithubMixin as _GithubMixin
from .aktualisierung_app import AppMixin as _AppMixin
from .aktualisierung_hintergrund import HintergrundMixin as _HintergrundMixin
from .archiv import ZIP_FEHLER


NEUSTART = None  # vom Startweg gesetzt (siehe __main__): erneuter Start nach einem Update


class Aktualisierung(_KernMixin, _SicherungMixin, _GithubMixin, _AppMixin, _HintergrundMixin):
    """Aktualisierung aus GitHub: Pruefen, Installieren, Zurueck, Sicherungen und Hintergrundlauf."""

    def zustand(self):
        e = self.einstellung
        stand = self.stand()
        return {"repo": e["repo"], "zweig": e["zweig"], "token_gesetzt": bool(e["token"]), "auto": e["auto"],
                "stunden": e["stunden"], "auto_werte": list(AUTO), "stunden_werte": list(STUNDEN),
                "sicherung": e["sicherung"], "behalten": e["behalten"], "sicherung_werte": list(SICHERUNGEN),
                "sicherungen": self.sicherungen(), "wartung": wartung(self.letzte.get("version", "")),
                "laufend": __version__, "installiert": stand, "zurueck": os.path.isdir(self.ordner + ".alt"),
                "letzte": self.letzte, "fehler": self.fehler, "fehler_art": self.fehler_art, "laeuft": self.laeuft, "plattform": plattform(),
                "neustart": NEUSTART is not None}

    def installieren(self):
        """Laden, pruefen, tauschen. Gibt den neuen Stand zurueck."""
        with self._sperre:
            if self.laeuft:
                raise UpdateFehler("Läuft schon")
            self.laeuft = True
        try:
            info = self.pruefen()
            try:
                self.sichern("vor-update")  # die Nutzerdaten vor jedem Update sichern
            except (OSError, sqlite3.Error) as fehler:
                log.warning("Sicherung vor dem Update: %s", fehler)
            roh = self._zip_laden()
            try:
                archiv = zipfile.ZipFile(io.BytesIO(roh))
            except zipfile.BadZipFile:
                raise UpdateFehler("Download ist kein ZIP")
            except ZIP_FEHLER as fehler:
                raise UpdateFehler("Download ist kein ZIP: %s" % fehler)
            os.makedirs(self.datenordner, exist_ok=True)
            neu = tempfile.mkdtemp(prefix="aktuell-neu-", dir=self.datenordner)
            try:
                anzahl = 0
                groesse = 0
                try:
                    for eintrag in archiv.infolist():
                        teile = eintrag.filename.split("/", 1)
                        if len(teile) < 2 or not teile[1].startswith(("rezeptserver/", "rezepte/")) or eintrag.is_dir():
                            continue
                        rel = os.path.normpath(teile[1])
                        if rel.startswith("..") or os.path.isabs(rel) or "__pycache__" in rel:
                            continue
                        groesse += max(eintrag.file_size, 0)
                        if groesse > MAX_ENTPACKT:  # Bremsklotz gegen Kompressionsbomben
                            raise UpdateFehler("Archiv zu groß beim Entpacken")
                        ziel = os.path.join(neu, rel)
                        os.makedirs(os.path.dirname(ziel), exist_ok=True)
                        with archiv.open(eintrag) as quelle, open(ziel, "wb") as datei:
                            shutil.copyfileobj(quelle, datei)
                        anzahl += 1
                except UpdateFehler:
                    raise
                except ZIP_FEHLER as fehler:
                    # beschaedigte Daten fallen oft erst beim Lesen auf (CRC, gepatchter Deflate-Strom)
                    raise UpdateFehler("Archiv ist beschädigt: %s" % fehler)
                finally:
                    archiv.close()
                version = version_in(neu)
                if not version or not os.path.isfile(os.path.join(neu, "rezeptserver", "__main__.py")):
                    raise UpdateFehler("Im Repo fehlt rezeptserver/ (falsches Repo?)")
                for wurzel, _, dateien in os.walk(os.path.join(neu, "rezeptserver")):
                    for name in dateien:
                        if name.endswith(".py"):
                            try:
                                py_compile.compile(os.path.join(wurzel, name), doraise=True,
                                                   cfile=os.path.join(tempfile.gettempdir(), "h0rst-pruefung.pyc"))
                            except py_compile.PyCompileError as fehler:
                                raise UpdateFehler("Neue Fassung hat einen Fehler in %s: %s" % (name, str(fehler)[:200]))
                with open(os.path.join(neu, "stand.json"), "w", encoding="utf-8") as f:
                    json.dump({"sha": info.get("sha", ""), "version": version, "zeit": int(self.uhr()),
                               "repo": self.einstellung["repo"], "zweig": self.einstellung["zweig"], "dateien": anzahl}, f)
                alt = self.ordner + ".alt"
                shutil.rmtree(alt, ignore_errors=True)
                if os.path.isdir(self.ordner):
                    os.replace(self.ordner, alt)
                try:
                    os.replace(neu, self.ordner)
                except OSError:
                    if os.path.isdir(alt) and not os.path.isdir(self.ordner):
                        os.replace(alt, self.ordner)  # die bisherige Fassung bleibt aktiv
                    raise
            except Exception:
                shutil.rmtree(neu, ignore_errors=True)
                raise
            self.letzte = dict(info, neu=False)
            log.info("Aktualisiert auf %s (%s), %d Dateien", version, info.get("sha", ""), anzahl)
            ereignisse.melden("update", "H0rSt %s installiert (%s)%s" % (version, info.get("nachricht", ""),
                              "" if NEUSTART else " – wirkt beim nächsten Start"), True)
            if NEUSTART:
                threading.Timer(2.0, NEUSTART).start()  # Antwort an die Oberflaeche geht vorher raus
            return self.stand()
        except UpdateFehler as fehler:
            self.fehler, self.fehler_art = str(fehler), fehler.art
            raise
        finally:
            self.laeuft = False

    def zurueck(self):
        """Vorige Fassung wieder aktiv machen (oder, ohne Sicherung, die eingebaute)."""
        alt = self.ordner + ".alt"
        if os.path.isdir(alt):
            zwischen = self.ordner + ".tausch"
            shutil.rmtree(zwischen, ignore_errors=True)
            if os.path.isdir(self.ordner):
                os.replace(self.ordner, zwischen)
            os.replace(alt, self.ordner)
            if os.path.isdir(zwischen):
                os.replace(zwischen, alt)
        else:
            shutil.rmtree(self.ordner, ignore_errors=True)
        if NEUSTART:
            threading.Timer(2.0, NEUSTART).start()
        return self.zustand()

    def entfernen(self):
        """Zur eingebauten Fassung zurueck (aktuell/ und Sicherung loeschen)."""
        shutil.rmtree(self.ordner, ignore_errors=True)
        shutil.rmtree(self.ordner + ".alt", ignore_errors=True)
        if NEUSTART:
            threading.Timer(2.0, NEUSTART).start()
        return self.zustand()
