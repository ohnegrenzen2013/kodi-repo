"""AppMixin-Mixin der Aktualisierung."""

from .aktualisierung_grund import (
    API,
    APP_DATEI,
    APP_TAG,
    MAX_APK,
    MAX_ZIP,
    UpdateFehler,
    _SHA,
    _VERSION_APP,
    __version__,
    _asset_laden,
    antwort_holen,
    json,
    os,
    re,
)

class AppMixin:

    # --- App (APK) aus dem Release "app" -------------------------------------------------------
    # Ein Release traegt die H0rSt-App (rezeptserver-<version>.apk, mit der Brause darin). Aeltere Releases
    # haben noch eigene Brause-APKs (h0rst-brause-<version>-<abi>.apk); die werden nie als App genommen.
    @staticmethod
    def _ist_app(name):
        return name.endswith(".apk") and "brause" not in name

    def _neueste(self, passt):
        releases = [r for r in json.loads(self._api("/releases?per_page=30")) or []
                    if isinstance(r, dict) and not r.get("draft") and re.match(r"^%s(-|$)" % APP_TAG, str(r.get("tag_name") or ""))
                    and any(passt(str(a.get("name", ""))) for a in r.get("assets") or [])]
        if not releases:
            return None, None
        rel = max(releases, key=lambda r: str(r.get("published_at") or r.get("created_at") or ""))
        return rel, next(a for a in rel["assets"] if passt(str(a.get("name", ""))))

    def app_pruefen(self, eigene_sha=""):
        """{"version", "sha", "datum", "groesse", "name", "neu"}: die neueste gebaute App und ob sie neuer ist."""
        rel, apk = self._neueste(self._ist_app)
        if not rel:
            raise UpdateFehler("Noch keine gebaute App (Release „%s-…“) im Repo" % APP_TAG)
        text = str(rel.get("body") or "")
        m, v = _SHA.search(text), _VERSION_APP.search(text)
        sha = m.group(1).lower() if m else ""
        eigene = str(eigene_sha or "").lower()
        return {"version": v.group(1) if v else "", "sha": sha[:12], "datum": str(rel.get("published_at") or "")[:10],
                "groesse": int(apk.get("size") or 0), "name": apk.get("name", ""), "id": apk.get("id"),
                "neu": bool(sha and eigene and not sha.startswith(eigene[:12]) and not eigene.startswith(sha[:12]))}

    def _asset_speichern(self, asset_id, datei):
        url = API % self.einstellung["repo"] + "/releases/assets/%s" % asset_id
        if self.holen is not antwort_holen:
            status, roh = self.holen(url, "GET", self._kopf("application/octet-stream"), None, 300)
            if status != 200:
                raise UpdateFehler("Download: HTTP %d" % status)
        else:
            roh = _asset_laden(url, self._kopf("application/octet-stream"))
        if len(roh) > MAX_APK or not roh.startswith(b"PK"):
            raise UpdateFehler("Download ist keine APK")
        os.makedirs(self.datenordner, exist_ok=True)
        ziel = os.path.join(self.datenordner, datei)
        with open(ziel + ".neu", "wb") as f:
            f.write(roh)
        os.replace(ziel + ".neu", ziel)
        return ziel

    def app_laden(self):
        """APK nach <Datenordner>/h0rst-app.apk laden. Gibt den Pfad zurueck."""
        return self._asset_speichern(self.app_pruefen()["id"], APP_DATEI)

    def _zip_laden(self):
        url = API % self.einstellung["repo"] + "/zipball/%s" % self.einstellung["zweig"]
        if self.holen is not antwort_holen:
            status, roh = self.holen(url, "GET", self._kopf(), None, 120)
        else:
            import urllib.error
            import urllib.request
            # GitHub leitet auf codeload.github.com weiter; das Token gilt nur fuer api.github.com
            anfrage = urllib.request.Request(url, headers=dict(self._kopf(), **{"User-Agent": "H0rSt/" + __version__}))
            try:
                with urllib.request.urlopen(anfrage, timeout=120) as a:
                    roh, status = a.read(MAX_ZIP + 1), a.status
            except urllib.error.HTTPError as fehler:
                fehler.close()
                raise UpdateFehler("Download: HTTP %d" % fehler.code)
            except (urllib.error.URLError, OSError) as fehler:
                raise UpdateFehler("Download fehlgeschlagen: %s" % fehler)
        if status != 200:
            raise UpdateFehler("Download: HTTP %d" % status)
        if len(roh) > MAX_ZIP:
            raise UpdateFehler("ZIP zu groß")
        return roh
