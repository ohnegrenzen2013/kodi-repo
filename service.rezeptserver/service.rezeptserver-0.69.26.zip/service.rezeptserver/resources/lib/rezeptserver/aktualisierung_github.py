"""GithubMixin-Mixin der Aktualisierung."""

from .aktualisierung_grund import (
    API,
    NetzFehler,
    UpdateFehler,
    UpdateTokenFehlt,
    _VERSION,
    __version__,
    json,
    version_tupel,
)

class GithubMixin:

    # --- GitHub ---------------------------------------------------------------------------------
    def _kopf(self, art="application/vnd.github+json"):
        k = {"Accept": art, "X-GitHub-Api-Version": "2022-11-28"}
        if self.einstellung["token"]:
            k["Authorization"] = "Bearer " + self.einstellung["token"]
        return k

    def _api(self, pfad, art="application/vnd.github+json"):
        url = API % self.einstellung["repo"] + pfad
        try:
            status, text = self.holen(url, "GET", self._kopf(art), None, 30)
        except NetzFehler as fehler:
            raise UpdateFehler("GitHub nicht erreichbar: %s" % fehler)
        if status == 404:
            fehler = UpdateTokenFehlt if not self.einstellung["token"] else UpdateFehler
            raise fehler("Repo oder Zweig nicht gefunden. Ist das Repo privat? Dann ein Token mit "
                         "Lesezugriff (Contents: Read) eintragen.")
        if status in (401, 403):
            raise UpdateFehler("GitHub lehnt ab (HTTP %d): Token ungültig, abgelaufen oder Abruf-Grenze erreicht." % status)
        if status != 200:
            raise UpdateFehler("GitHub: HTTP %d" % status)
        return text

    def pruefen(self):
        """Neuester Stand des Zweigs: {"sha", "version", "datum", "nachricht", "neu"}."""
        e = self.einstellung
        commit = json.loads(self._api("/commits/%s" % e["zweig"]))
        version_text = self._api("/contents/rezeptserver/__init__.py?ref=%s" % e["zweig"], "application/vnd.github.raw")
        m = _VERSION.search(version_text if isinstance(version_text, str) else version_text.decode("utf-8", "replace"))
        version = m.group(1) if m else ""
        sha = str(commit.get("sha") or "")
        stand = self.stand()
        installiert_sha = stand.get("sha", "")
        neu = version_tupel(version) > version_tupel(__version__) or (
            bool(installiert_sha) and sha != installiert_sha and version_tupel(version) >= version_tupel(__version__))
        info = commit.get("commit") or {}
        self.letzte = {"sha": sha[:12], "version": version, "datum": str((info.get("committer") or {}).get("date") or "")[:10],
                       "nachricht": str(info.get("message") or "").split("\n", 1)[0][:200], "neu": neu,
                       "zeit": int(self.uhr())}
        self.fehler = self.fehler_art = ""
        return self.letzte
