"""Grundlage der Aktualisierung: Konstanten, Versions-/Einstellungshelfer und die Bauteile.
Alles hier wird samt Importen wieder exportiert (rezeptserver.aktualisierung.*)."""


import io
import json
import logging
import os
import py_compile
import re
import shutil
import tempfile
import threading
import time
import zipfile

from . import __version__, ereignisse
from .netz import NetzFehler, antwort_holen

log = logging.getLogger("rezeptserver")

SCHLUESSEL = "aktualisierung"
STANDARD = {"repo": "CR0C0d0C/modulhorst", "zweig": "main", "token": "", "auto": "melden", "stunden": 12,
            "sicherung": "woechentlich", "behalten": 8}
SICHERUNGEN = ("aus", "taeglich", "woechentlich")
SICHERUNG_ORDNER = "sicherungen"
# Support-Enden (Sicherheitsupdates) der Bausteine, Stand 2026; danach auf die naechste Linie wechseln
SUPPORT_PYTHON = {(3, 8): "2024-10-31", (3, 9): "2025-10-31", (3, 10): "2026-10-31", (3, 11): "2027-10-31",
                  (3, 12): "2028-10-31", (3, 13): "2029-10-31", (3, 14): "2030-10-31"}
SUPPORT_DEBIAN = {"11": ("Debian 11 (bullseye, LTS)", "2026-08-31"), "12": ("Debian 12 (bookworm, LTS)", "2028-06-30"),
                  "13": ("Debian 13 (trixie, LTS)", "2030-06-30")}
SUPPORT_DOCKER = [("MariaDB 11.4 (LTS)", "2029-05-29", "H0RST_DB_NAME"), ("PHP 8.3 (Webserver)", "2027-12-31", "H0RST_WEB_ORDNER")]
AUTO = ("aus", "melden", "installieren")
STUNDEN = (3, 6, 12, 24, 72)
ORDNER = "aktuell"
API = "https://api.github.com/repos/%s"
MAX_ZIP = 200 * 1024 * 1024
MAX_ENTPACKT = 1024 * 1024 * 1024  # entpackt (das Repo selbst braucht weit weniger)
APP_TAG = "app"
APP_DATEI = "h0rst-app.apk"
MAX_APK = 300 * 1024 * 1024
_SHA = re.compile(r"sha:\s*([0-9a-f]{7,40})", re.I)
_REPO = re.compile(r"^[\w.-]{1,100}/[\w.-]{1,100}$")
_VERSION = re.compile(r'__version__\s*=\s*"([^"]+)"')


_VERSION_APP = re.compile(r"version:\s*([0-9][0-9.]*)", re.I)


def _asset_laden(url, kopf):
    """Release-Datei von GitHub: die API leitet auf einen signierten Speicher-Link weiter, der kein Token
    vertraegt – deshalb der Weiterleitung von Hand ohne Authorization folgen."""
    import urllib.error
    import urllib.request

    class _NichtFolgen(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *args, **kwargs):
            return None

    kopf = dict(kopf, **{"User-Agent": "H0rSt/" + __version__})
    try:
        try:
            with urllib.request.build_opener(_NichtFolgen).open(urllib.request.Request(url, headers=kopf), timeout=60) as a:
                return a.read(MAX_APK + 1)
        except urllib.error.HTTPError as umleitung:
            umleitung.close()
            ziel = umleitung.headers.get("Location") if umleitung.code in (301, 302, 303, 307, 308) else None
            if not ziel:
                raise UpdateFehler("Download: HTTP %d" % umleitung.code)
        with urllib.request.urlopen(urllib.request.Request(ziel, headers={"User-Agent": kopf["User-Agent"]}), timeout=300) as a:
            return a.read(MAX_APK + 1)
    except urllib.error.HTTPError as fehler:
        fehler.close()
        raise UpdateFehler("Download: HTTP %d" % fehler.code)
    except (urllib.error.URLError, OSError) as fehler:
        raise UpdateFehler("Download fehlgeschlagen: %s" % fehler)


class UpdateFehler(ValueError):
    art = ""


class UpdateTokenFehlt(UpdateFehler):
    art = "token"


def version_tupel(text):
    try:
        return tuple(int(x) for x in re.findall(r"\d+", str(text or ""))[:4])
    except ValueError:
        return ()


def version_in(ordner):
    """Version der Fassung in <ordner>/rezeptserver/__init__.py oder ''."""
    try:
        with open(os.path.join(ordner, "rezeptserver", "__init__.py"), encoding="utf-8") as f:
            m = _VERSION.search(f.read())
        return m.group(1) if m else ""
    except OSError:
        return ""


def bevorzugt(datenordner, eingebaut=__version__):
    """Ordner mit einer neueren Fassung als der eingebauten (fuer sys.path) oder None."""
    ordner = os.path.join(datenordner or ".", ORDNER)
    neu = version_in(ordner)
    return ordner if neu and version_tupel(neu) > version_tupel(eingebaut) else None


def rezepte_ordner(rezepte, datenordner):
    """Rezepte aus der Aktualisierung: in den Rezept-Ordner uebernehmen oder, wenn der schreibgeschuetzt ist
    (Pi), direkt aus aktuell/rezepte laden. Gibt den zu ladenden Ordner zurueck."""
    neu = os.path.join(datenordner or ".", ORDNER, "rezepte")
    if not os.path.isdir(neu) or not bevorzugt_aktiv(datenordner):
        return rezepte
    from .dienst import rezepte_uebernehmen
    try:
        rezepte_uebernehmen(neu, rezepte)
        return rezepte
    except OSError:
        return neu


def bevorzugt_aktiv(datenordner):
    """Laeuft gerade die Fassung aus aktuell/ (gleiche Version wie die laufende)?"""
    neu = version_in(os.path.join(datenordner or ".", ORDNER))
    return bool(neu) and version_tupel(neu) == version_tupel(__version__)


def pruefe(roh):
    e = dict(STANDARD)
    if isinstance(roh, dict):
        e.update({k: roh[k] for k in STANDARD if k in roh})
    e["repo"] = str(e["repo"] or "").strip().strip("/")
    if e["repo"].startswith("https://github.com/"):
        e["repo"] = e["repo"][len("https://github.com/"):].replace(".git", "").strip("/")
    if not _REPO.match(e["repo"]):
        raise UpdateFehler("Repo in der Form besitzer/name, z. B. CR0C0d0C/modulhorst")
    e["zweig"] = re.sub(r"[^\w./-]", "", str(e["zweig"] or "main"))[:100] or "main"
    e["token"] = str(e["token"] or "").strip()[:300]
    if e["auto"] not in AUTO:
        raise UpdateFehler("auto: aus, melden oder installieren")
    try:
        e["stunden"] = int(e["stunden"])
    except (TypeError, ValueError):
        raise UpdateFehler("stunden muss eine Zahl sein")
    if e["stunden"] not in STUNDEN:
        e["stunden"] = 12
    if e["sicherung"] not in SICHERUNGEN:
        e["sicherung"] = "woechentlich"
    try:
        e["behalten"] = max(1, min(100, int(e["behalten"])))
    except (TypeError, ValueError):
        e["behalten"] = 8
    return e


def _stand(bis, heute=None):
    import datetime
    heute = heute or datetime.date.today()
    tage = (datetime.date.fromisoformat(bis) - heute).days
    return "abgelaufen" if tage < 0 else "bald" if tage < 183 else "ok"


def wartung(neueste_version="", heute=None):
    """Bausteine mit Version, Support-Ende und Stand (ok, bald, abgelaufen) und einem Hinweis, was zu tun ist."""
    import platform
    import sys
    teile = []
    py = sys.version_info[:2]
    bis = SUPPORT_PYTHON.get(py)
    if bis:
        teile.append({"name": "Python %d.%d" % py, "bis": bis, "stand": _stand(bis, heute),
                      "hinweis": "Läuft im Docker-Image bzw. auf dem System. Rechtzeitig vorher auf eine neuere Python-Version wechseln "
                                 "(Docker: neues H0rSt-Image; Pi: Systemaktualisierung)."})
    try:
        with open("/etc/os-release", encoding="utf-8") as f:
            os_info = dict(l.strip().split("=", 1) for l in f if "=" in l)
        kennung = os_info.get("VERSION_ID", "").strip('"')
        if os_info.get("ID", "").strip('"') in ("debian", "raspbian") and kennung in SUPPORT_DEBIAN:
            name, bis = SUPPORT_DEBIAN[kennung]
            teile.append({"name": name, "bis": bis, "stand": _stand(bis, heute),
                          "hinweis": "Sicherheitsupdates kommen automatisch (unattended-upgrades, siehe pi/installieren.sh). "
                                     "Vor dem Ende auf die nächste Debian-Version heben (apt full-upgrade), Daten bleiben."})
    except (OSError, ValueError):
        pass
    for name, bis, kennzeichen in SUPPORT_DOCKER:
        if os.environ.get(kennzeichen):
            teile.append({"name": name, "bis": bis, "stand": _stand(bis, heute),
                          "hinweis": "Docker-Image bekommt Sicherheitsupdates automatisch (Watchtower). Vor dem Ende die Version "
                                     "in docker-compose.yml anheben."})
    neu = version_tupel(neueste_version) > version_tupel(__version__)
    teile.append({"name": "H0rSt %s" % __version__, "bis": "", "stand": "bald" if neu else "ok",
                  "hinweis": ("Neue Version %s im Repo – „Aktualisieren“." % neueste_version) if neu else
                  "Aktualisiert sich aus GitHub (siehe oben), ohne Neuinstallation."})
    teile.append({"name": "Betrieb", "bis": "", "stand": "ok", "hinweis": "%s · %s" % (platform.system() or "?", platform.machine() or "?")})
    return teile


def plattform():
    import sys
    if "xbmc" in sys.modules:
        return "kodi"
    if "ANDROID_ROOT" in os.environ or "com.chaquo.python" in sys.modules:
        return "android"
    return "server"
