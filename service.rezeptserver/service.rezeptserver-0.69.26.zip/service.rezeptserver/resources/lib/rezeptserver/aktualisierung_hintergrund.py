"""HintergrundMixin-Mixin der Aktualisierung."""

from .aktualisierung_grund import (
    UpdateFehler,
    ereignisse,
    log,
    plattform,
    threading,
)

class HintergrundMixin:

    # --- Hintergrund ----------------------------------------------------------------------------
    def starten(self):
        if self._faden and self._faden.is_alive():
            return
        self._halt.clear()
        self._faden = threading.Thread(target=self._schleife, name="aktualisierung", daemon=True)
        self._faden.start()

    def stoppen(self):
        self._halt.set()

    def _schleife(self):
        if self._halt.wait(120):  # erst den Start in Ruhe lassen
            return
        while not self._halt.is_set():
            e = self.einstellung
            try:
                if self.sicherung_faellig():
                    self.sichern()
            except Exception as fehler:  # noqa: BLE001 – eine Sicherung darf den Hintergrundthread nicht beenden
                log.warning("Automatische Sicherung: %s", fehler)
            nebenbei = getattr(self, "nebenbei", None)  # z. B. Orte nach Google Drive spiegeln
            if nebenbei:
                try:
                    nebenbei()
                except Exception as fehler:  # noqa: BLE001 – stoert die Aktualisierung nie
                    log.warning("Hintergrundaufgabe: %s", fehler)
            if e["auto"] != "aus" and self.uhr() - self._geprueft >= e["stunden"] * 3600 - 60:
                self._geprueft = self.uhr()
                try:
                    info = self.pruefen()
                    if info["neu"] and self._gemeldet != info["sha"]:
                        if e["auto"] == "installieren" and plattform() != "android":
                            self.installieren()
                        else:
                            ereignisse.melden("update", "Neue H0rSt-Version %s im Repo: %s" % (info["version"], info["nachricht"]), True)
                        self._gemeldet = info["sha"]  # erst nach Erfolg: ein gescheiterter Versuch wird beim naechsten Mal wiederholt
                except UpdateFehler as fehler:
                    self.fehler = str(fehler)
                    self.fehler_art = fehler.art
                    log.info("Aktualisierung: %s", fehler)
                except Exception as fehler:  # noqa: BLE001 – Netz-, JSON- oder Plattenfehler duerfen den Hintergrundthread nicht beenden
                    self.fehler, self.fehler_art = str(fehler) or type(fehler).__name__, ""
                    log.warning("Aktualisierung: %s", fehler)
            if self._halt.wait(min(self.einstellung["stunden"] * 3600, 6 * 3600)):  # Sicherungen auch bei langem Abstand
                return
