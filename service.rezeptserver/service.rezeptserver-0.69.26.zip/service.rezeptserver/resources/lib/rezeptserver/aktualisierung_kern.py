"""KernMixin-Mixin der Aktualisierung."""

from .aktualisierung_grund import (
    ORDNER,
    STANDARD,
    UpdateFehler,
    antwort_holen,
    json,
    os,
    pruefe,
    threading,
    time,
)

class KernMixin:
    def __init__(self, datenordner, einstellung=None, speichern=None, holen=None, uhr=time.time):
        self.ordner = os.path.join(datenordner or ".", ORDNER)
        self.datenordner = datenordner or "."
        try:
            self.einstellung = pruefe(einstellung)
        except UpdateFehler:
            self.einstellung = pruefe(None)
        self._speichern = speichern
        self.holen = holen or antwort_holen  # holen(url, methode, kopf, daten, zeitgrenze) -> (status, text|bytes)
        self.uhr = uhr
        self.letzte = {}        # Ergebnis der letzten Pruefung
        self.fehler = ""
        self.fehler_art = ""    # "token": nur das Token fehlt (Hinweis, kein Fehler)
        self.laeuft = False
        self._sperre = threading.Lock()
        self._halt = threading.Event()
        self._faden = None
        self._gemeldet = ""
        self._geprueft = 0

    # --- Einstellungen und Stand ---------------------------------------------------------------
    def stand(self):
        try:
            with open(os.path.join(self.ordner, "stand.json"), encoding="utf-8") as f:
                return json.load(f)
        except (OSError, ValueError):
            return {}

    def einstellen(self, neu):
        if not isinstance(neu, dict):
            raise UpdateFehler("JSON-Objekt erwartet")
        e = dict(self.einstellung)
        for k, w in neu.items():
            if k == "token_weg":
                if w:
                    e["token"] = ""
            elif k == "token":
                if str(w or "").strip():
                    e["token"] = w
            elif k in STANDARD:
                e[k] = w
            else:
                raise UpdateFehler("Unbekannte Einstellung: %s" % k)
        self.einstellung = pruefe(e)
        if self._speichern:
            self._speichern(dict(self.einstellung))
        return self.zustand()
