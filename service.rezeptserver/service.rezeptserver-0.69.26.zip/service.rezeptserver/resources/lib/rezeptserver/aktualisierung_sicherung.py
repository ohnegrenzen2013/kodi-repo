"""SicherungMixin-Mixin der Aktualisierung."""

from .aktualisierung_grund import (
    SICHERUNG_ORDNER,
    UpdateFehler,
    log,
    os,
    re,
    time,
)

class SicherungMixin:

    # --- Automatische Sicherungen ---------------------------------------------------------------
    def _sicherung_ordner(self):
        return os.path.join(self.datenordner, SICHERUNG_ORDNER)

    def sicherungen(self):
        ordner = self._sicherung_ordner()
        if not os.path.isdir(ordner):
            return []
        namen = sorted((n for n in os.listdir(ordner) if re.match(r"^h0rst-sicherung-[\d-]+(?:-vor-update)?\.json$", n)), reverse=True)
        return [{"name": n, "groesse": os.path.getsize(os.path.join(ordner, n)),
                 "zeit": int(os.path.getmtime(os.path.join(ordner, n)))} for n in namen]

    def sichern(self, anlass=""):
        """Komplettsicherung der Nutzerdaten nach <Datenordner>/sicherungen (nur fuer den Besitzer lesbar)."""
        from . import konfig
        db = os.path.join(self.datenordner, konfig.DATEINAME)
        if not os.path.isfile(db):
            return ""
        ordner = self._sicherung_ordner()
        os.makedirs(ordner, mode=0o700, exist_ok=True)
        name = time.strftime("h0rst-sicherung-%Y-%m-%d-%H%M%S", time.localtime(self.uhr())) + ("-vor-update" if anlass else "") + ".json"
        konfig.exportiere(db, os.path.join(ordner, name))
        for alt in self.sicherungen()[self.einstellung["behalten"]:]:
            try:
                os.remove(os.path.join(ordner, alt["name"]))
            except OSError:
                pass
        log.info("Sicherung angelegt: %s", name)
        weiter = getattr(self, "nach_sicherung", None)  # z. B. Google Drive (gdrive.py)
        if weiter:
            try:
                weiter(os.path.join(ordner, name))
            except Exception as fehler:  # noqa: BLE001 – die lokale Sicherung steht, das Hochladen ist Beiwerk
                log.warning("Nach der Sicherung: %s", fehler)
        return name

    def sicherung_pfad(self, name):
        if not re.match(r"^h0rst-sicherung-[\d-]+(?:-vor-update)?\.json$", str(name or "")):
            raise UpdateFehler("Ungültige Sicherung")
        pfad = os.path.join(self._sicherung_ordner(), name)
        if not os.path.isfile(pfad):
            raise UpdateFehler("Sicherung gibt es nicht")
        return pfad

    def sicherung_faellig(self):
        e = self.einstellung
        if e["sicherung"] == "aus":
            return False
        letzte = self.sicherungen()
        abstand = 86400 if e["sicherung"] == "taeglich" else 7 * 86400
        return not letzte or self.uhr() - letzte[0]["zeit"] >= abstand - 600
