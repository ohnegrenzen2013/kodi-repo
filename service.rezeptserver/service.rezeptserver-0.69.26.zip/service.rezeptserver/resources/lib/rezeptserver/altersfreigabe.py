"""Altersfreigabe fuer Kinderprofile (ARVIO 2.3: Profile mit Altersgrenze).

Die Freigabe eines Titels kommt von TMDb (Zertifizierung je Land): die deutsche FSK-Angabe hat Vorrang, fehlt sie, gilt
die amerikanische (MPAA / TV-Rating), jeweils auf die naechsthoehere FSK-Stufe aufgerundet. **Unbekannt wird
ausgeblendet** - auch ohne TMDb-Schluessel, ohne IMDb-Kennung oder wenn TMDb gerade nicht antwortet.

  * Stufen: 0, 6, 12, 16, 18. Die Grenze eines Kinderprofils ist eine dieser Stufen; erlaubt ist alles bis einschliesslich.
  * Zwischenspeicher in einer Datei (altersfreigabe.json im Datenordner): bekannte Werte 90 Tage, "unbekannt" 7 Tage;
    ein Netzfehler wird nie gemerkt.
  * karten_filtern() findet Titelkarten ({id: tt…, typ: movie|series}) in jeder Antwort und entfernt, was nicht
    freigegeben ist. Folgenlisten und andere Listen bleiben unberuehrt.
"""

import json
import logging
import os
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor, TimeoutError as ZeitUeberschritten

log = logging.getLogger("rezeptserver")

STUFEN = (0, 6, 12, 16, 18)
GRENZEN_WAHL = (0, 6, 12, 16)  # was ein Elternteil einstellen kann (18 waere "alles")
BEKANNT_SEK = 90 * 86400
UNBEKANNT_SEK = 7 * 86400
MAX_EINTRAEGE = 20000
WARTEZEIT_SEK = 25.0
_IMDB = re.compile(r"^(tt\d{1,10})(?::\d{1,4}:\d{1,5})?$")
_USA = {"G": 0, "TV-Y": 0, "TV-G": 0, "PG": 6, "TV-Y7": 6, "TV-Y7-FV": 6, "TV-PG": 6, "PG-13": 12, "TV-14": 16, "R": 16,
        "NC-17": 18, "TV-MA": 18}


def alter_aus_text(land, roh):
    """Eine einzelne Zertifizierung ('FSK 12', 'PG-13' …) -> FSK-Stufe oder None."""
    text = " ".join(str(roh or "").split()).upper()
    if not text:
        return None
    if land == "DE":
        if "OHNE" in text:
            return 0
        zahl = re.fullmatch(r"(?:FSK[ -]?|AB )?(\d{1,2})", text)
        if zahl and int(zahl.group(1)) in STUFEN:
            return int(zahl.group(1))
        return None
    if land == "US":
        return _USA.get(text)
    return None


def alter_aus_zertifizierungen(zertifizierungen):
    """{'DE': '12', 'US': 'R'} -> 12 (DE zuerst, dann US); None, wenn keine verwertbare Angabe da ist."""
    for land in ("DE", "US"):
        alter = alter_aus_text(land, (zertifizierungen or {}).get(land))
        if alter is not None:
            return alter
    return None


def _basis(typ, sid):
    m = _IMDB.match(str(sid or ""))
    if not m or typ not in ("movie", "series"):
        return None
    return typ, m.group(1)


class Altersfreigabe:
    def __init__(self, tmdb, schluessel, pfad=None, uhr=time.time):
        self.tmdb = tmdb
        self.schluessel = schluessel  # Funktion -> TMDb-API-Schluessel ('' = keiner)
        self.pfad = pfad
        self.uhr = uhr
        self._sperre = threading.Lock()
        self._speicher = {}  # "movie:tt1" -> [alter oder None, Zeit]
        self._pool = ThreadPoolExecutor(max_workers=6, thread_name_prefix="alter")
        self._laden()

    # --- Zwischenspeicher -----------------------------------------------------------------------
    def _laden(self):
        if not self.pfad or not os.path.isfile(self.pfad):
            return
        try:
            with open(self.pfad, encoding="utf-8") as f:
                roh = json.load(f)
            self._speicher = {k: v for k, v in roh.items() if isinstance(v, list) and len(v) == 2}
        except (OSError, ValueError):
            log.warning("Altersfreigabe: Zwischenspeicher nicht lesbar - wird neu aufgebaut")

    def _sichern(self):
        if not self.pfad:
            return
        try:
            os.makedirs(os.path.dirname(self.pfad) or ".", exist_ok=True)
            tmp = self.pfad + ".tmp"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self._speicher, f)
            os.replace(tmp, self.pfad)
        except OSError as fehler:
            log.warning("Altersfreigabe: Speichern fehlgeschlagen: %s", fehler)

    # --- Abfrage --------------------------------------------------------------------------------
    def alter(self, typ, sid):
        """FSK-Stufe des Titels oder None (unbekannt / nicht ermittelbar)."""
        basis = _basis(typ, sid)
        key = self.schluessel()
        if not basis or not key:
            return None
        name = "%s:%s" % basis
        jetzt = self.uhr()
        with self._sperre:
            alt = self._speicher.get(name)
        if alt and jetzt - alt[1] < (BEKANNT_SEK if alt[0] is not None else UNBEKANNT_SEK):
            return alt[0]
        try:
            alter = alter_aus_zertifizierungen(self.tmdb.zertifizierungen(basis[0], basis[1], key))
        except Exception as fehler:  # noqa: BLE001 - nie raten: ausblenden, aber nichts merken
            log.info("Altersfreigabe %s: %s", name, fehler)
            return None
        with self._sperre:
            if len(self._speicher) >= MAX_EINTRAEGE:
                self._speicher.clear()
            self._speicher[name] = [alter, jetzt]
            self._sichern()
        return alter

    def erlaubt(self, typ, sid, grenze):
        alter = self.alter(typ, sid)
        return alter is not None and alter <= int(grenze)

    # --- Filter ---------------------------------------------------------------------------------
    def karten_filtern(self, antwort, grenze):
        """Kopie der Antwort ohne Titelkarten, die ueber der Grenze liegen oder unbekannt sind."""
        karten = set()
        self._sammeln(antwort, karten)
        ergebnis = {}
        if karten:
            termine = {k: self._pool.submit(self.erlaubt, k[0], k[1], grenze) for k in karten}
            ende = time.monotonic() + WARTEZEIT_SEK
            for k, f in termine.items():
                try:
                    ergebnis[k] = bool(f.result(timeout=max(0.01, ende - time.monotonic())))
                except (ZeitUeberschritten, Exception):  # noqa: BLE001
                    ergebnis[k] = False
        return self._ohne(antwort, ergebnis)

    @staticmethod
    def _karte(x):
        return isinstance(x, dict) and x.get("typ") in ("movie", "series") and isinstance(x.get("id"), str)

    def _sammeln(self, x, karten):
        if isinstance(x, dict):
            for v in x.values():
                self._sammeln(v, karten)
        elif isinstance(x, list):
            for e in x:
                if self._karte(e):
                    karten.add((e["typ"], e["id"]))
                else:
                    self._sammeln(e, karten)

    def _ohne(self, x, ergebnis):
        if isinstance(x, dict):
            return {k: self._ohne(v, ergebnis) for k, v in x.items()}
        if isinstance(x, list):
            return [self._ohne(e, ergebnis) for e in x if not (self._karte(e) and not ergebnis.get((e["typ"], e["id"]), False))]
        return x
