"""Eigene Anbieter nutzbar machen: was der Server mit welchem Typ selbst anfaengt.

  newznab        Usenet-Indexer: Finder und Aufloeser. Streams sind NZB-Dateien; Stremio spielt sie mit
                 den Usenet-Servern (typ nntp) direkt ab (Stream-Felder nzbUrl und servers).
  torznab        Torrent-Indexer (Prowlarr, Jackett): Finder und Aufloeser, Streams als infoHash.
  nntp           Usenet-Server fuer die NZB-Streams.
  xtream         Xtream-Zugang: Filme und Serien als Finder und Aufloeser (Live-TV ueber Live-TV-Listen).
  vxparser       wie xtream, dazu der eigene Bereich in der Oberflaeche.
  jellyfin/emby/plex  eigener Medienserver: Finder (IMDb-Nummer, sonst Titel und Jahr) und Aufloeser (Direct Play).
  stremio-addon  fremdes Stremio-Addon: dessen Streams und Untertitel zu IMDb-IDs kommen dazu.
  mhub-addon     fremdes mHub-Addon (MediaHubMX-Protokoll v2): dessen Quellen, Untertitel und Suchkataloge kommen dazu.
  debrid         Verbindungstest; Zugangsdaten fuer eigene Rezepte (konto).
  sabnzbd/nzbget NZB-Treffer an den Downloader schicken.
  vxparser-link  Link fuer vxparser (/vxparser/urls.json).

Finder und Aufloeser entstehen als Module wie aus einem Rezept (Rolle, konto, darf.netz = Domain der
eingetragenen Adresse); die Kette behandelt sie wie alle anderen.
"""

from .anbindungen_grund import *
from .anbindungen_anbieter import *
from .anbindungen_stremio import *
from .anbindungen_mhub import *
from .anbindungen_pruefen import *
from .anbindungen_downloader import *
from .anbindungen_grund import _AUFLOESUNG, _HASH, _api_adresse, _basis, _enthaelt_woerter, _felder, _host, _synthetisch, _werte
from .anbindungen_anbieter import _indexer_module, _xtream_module
from .anbindungen_stremio import _ressource
from .anbindungen_pruefen import _nntp_pruefen
