"""Eigene Anbieter als Module: Newznab/Torznab-Indexer, Xtream/vxparser und die Usenet-Server."""

from .anbindungen_grund import (
    ET,
    MAX_TREFFER,
    NEWZNAB_NS,
    NetzFehler,
    TORZNAB_NS,
    XTREAM_ZWISCHENSPEICHER,
    _AUFLOESUNG,
    _HASH,
    _api_adresse,
    _basis,
    _enthaelt_woerter,
    _felder,
    _host,
    _synthetisch,
    eigene,
    json,
    log,
    parsedate_to_datetime,
    quote,
    re,
    threading,
    time,
    urlencode,
    vxparser,
)
from .anbindungen_heimserver import heimserver_module
from . import usenet_stream
from .kette import FehlendeEinstellung


def _verbindung_abgelehnt(fehler):
    """Steckt ein "Connection refused" in der Fehlerkette? (urllib verpackt es in URLError und NetzFehler)"""
    while fehler is not None:
        if isinstance(fehler, ConnectionRefusedError) or isinstance(getattr(fehler, "reason", None), ConnectionRefusedError):
            return True
        fehler = fehler.__cause__ or fehler.__context__
    return False


def newznab_parameter(anfrage, torznab=False):
    art = anfrage.get("art")
    imdb = str((anfrage.get("ids") or {}).get("imdb") or "")
    parameter = {}
    if art == "serie" and anfrage.get("staffel") is not None:
        parameter.update(t="tvsearch", q=anfrage.get("titel") or anfrage.get("text", ""),
                         season=anfrage["staffel"], ep=anfrage.get("folge", ""), cat="5000")
    elif art == "film" and imdb.startswith("tt"):
        parameter.update(t="movie", imdbid=imdb[2:], cat="2000")
    else:
        parameter.update(t="search", q=anfrage.get("text") or anfrage.get("titel", ""),
                         cat="5000" if art == "serie" else "2000")
    if torznab and parameter["t"] == "search":
        parameter.pop("cat")  # nicht jeder Tracker kennt die Newznab-Kategorien
    return parameter


def newznab_lesen(text, torznab=False):
    """Items eines Newznab/Torznab-RSS -> Treffer-Rohdaten."""
    try:
        wurzel = ET.fromstring(text.encode("utf-8") if isinstance(text, str) else text)
    except ET.ParseError as fehler:
        raise NetzFehler("Antwort ist kein Newznab-XML: %s" % fehler)
    if wurzel.tag == "error":
        raise NetzFehler("Indexer meldet Fehler %s: %s" % (wurzel.get("code"), wurzel.get("description")))
    ergebnis = []
    for item in wurzel.iter("item"):
        attribute = {}
        for ns in (NEWZNAB_NS, TORZNAB_NS):
            for a in item.findall("{%s}attr" % ns):
                attribute[a.get("name")] = a.get("value")
        anhang = item.find("enclosure")
        link = item.findtext("link") or (anhang.get("url") if anhang is not None else "")
        groesse = attribute.get("size") or (anhang.get("length") if anhang is not None else "") or \
            item.findtext("size") or ""
        datum = ""
        try:
            datum = int(parsedate_to_datetime(item.findtext("pubDate") or "").timestamp())
        except (TypeError, ValueError, IndexError):
            pass
        eintrag = {"titel": (item.findtext("title") or "").strip(), "link": (link or "").strip(),
                   "guid": (item.findtext("guid") or "").strip(), "groesse": groesse, "datum": datum}
        # Zusatzangaben, die Newznab-Indexer und Spotweb oft mitliefern (nur anzeigen, nichts davon ist Pflicht)
        for feld, schluessel in (("gruppe", "group"), ("grabs", "grabs"), ("kommentare", "comments"), ("poster", "poster")):
            if attribute.get(schluessel):
                eintrag[feld] = str(attribute[schluessel])[:200]
        kategorie = item.findtext("category")
        if kategorie:
            eintrag["kategorie"] = kategorie.strip()[:80]
        if torznab:
            infohash = attribute.get("infohash") or ""
            magnet = attribute.get("magneturl") or (link if link.startswith("magnet:") else "")
            if not infohash and magnet:
                gefunden = _HASH.search(magnet)
                infohash = gefunden.group(1) if gefunden else ""
            eintrag.update(infohash=infohash.lower(), magnet=magnet, seeder=attribute.get("seeders", ""))
        ergebnis.append(eintrag)
    return ergebnis


def _indexer_module(anbieter_id, eintrag, werte, torznab):
    url = _basis(werte.get("url"))
    api = _api_adresse(url)
    name = eintrag["name"]

    def stufe(parameter, eingabe, host):
        """Eine Anfrage an den Indexer -> Treffer."""
        rohe = newznab_lesen(host.abruf(api + "?" + urlencode(parameter)), torznab)
        titel = eingabe.get("titel") or eingabe.get("text") or ""
        treffer = []
        for r in rohe:
            if not r["titel"] or (parameter["t"] == "search" and not _enthaelt_woerter(r["titel"], titel)):
                continue
            if torznab and not r.get("infohash"):
                continue  # ohne infoHash kann Stremio den Torrent nicht abspielen
            if not torznab and not r["link"]:
                continue
            t = {"titel": r["titel"], "ref": r.get("infohash") or r["guid"] or r["link"], "quelle": anbieter_id,
                 "groesse": r["groesse"], "datum": r["datum"]}
            aufloesung = _AUFLOESUNG.search(r["titel"])
            if aufloesung:
                t["aufloesung"] = aufloesung.group(1).lower()
            if torznab:
                t.update(infohash=r["infohash"], magnet=r.get("magnet", ""), seeder=r.get("seeder", ""))
            else:
                t["nzb"] = r["link"]
            treffer.append(t)
            if len(treffer) >= MAX_TREFFER:
                break
        return treffer

    def finden(eingabe, einstellungen, host):
        # Ohne Schalter genau eine Anfrage wie bisher. Im Usenet-Streaming-Modus (eingabe["ersatzsuche"]) folgen
        # Ersatzstufen, wenn die erste nichts bringt: andere Kennung, dann Text (usenet_stream.suchplan).
        plan = usenet_stream.suchplan(eingabe, torznab) if eingabe.get("ersatzsuche") else [newznab_parameter(eingabe, torznab)]
        erster_fehler = None
        for nummer, p in enumerate(plan):
            parameter = dict(p, apikey=einstellungen.get("api_key", ""))
            if not torznab:
                parameter["extended"] = "1"
            try:
                treffer = stufe(parameter, eingabe, host)
            except NetzFehler as fehler:
                if len(plan) == 1:
                    raise
                erster_fehler = erster_fehler or fehler
                log.info("%s: Suchstufe %d fehlgeschlagen (%s)", name, nummer + 1, fehler)
                continue
            if treffer:
                if nummer:
                    log.info("%s: Ersatzsuche (Stufe %d) fand %d Treffer", name, nummer + 1, len(treffer))
                return treffer
        if erster_fehler:
            raise erster_fehler
        return []

    def aufloesen(treffer, einstellungen, host):
        if torznab:
            if not treffer.get("infohash"):
                return []
            return [{"url": treffer.get("magnet") or "magnet:?xt=urn:btih:" + treffer["infohash"],
                     "infohash": treffer["infohash"], "aufloesung": treffer.get("aufloesung", "")}]
        return [{"url": treffer["nzb"], "nzb": True, "aufloesung": treffer.get("aufloesung", "")}] \
            if treffer.get("nzb") else []

    gemeinsam = {"konto": anbieter_id, "einstellungen": _felder("url_api"),
                 "darf": {"netz": [_host(url)], "geheimnisse": ["api_key"]}, "rang": 40}
    return [_synthetisch(dict(gemeinsam, id=anbieter_id + "-finder", name=name, rolle="finder", nimmt="anfrage",
                              gibt="treffer"), finden),
            _synthetisch(dict(gemeinsam, id=anbieter_id + "-aufloeser", name=name, rolle="aufloeser",
                              nimmt="treffer", gibt="stream", passt_zu={"quelle": anbieter_id}), aufloesen)]


def _xtream_module(anbieter_id, eintrag, werte, ist_vx):
    url = vxparser.adresse_pruefen(werte.get("url") or (vxparser.STANDARD_ADRESSE if ist_vx else ""))
    name = eintrag["name"]
    cache = {}
    sperre = threading.Lock()

    def zugang(einstellungen):
        if ist_vx:
            return vxparser.BENUTZER, vxparser.BENUTZER
        return einstellungen.get("user", ""), einstellungen.get("pass", "")

    def liste(host, aktion, einstellungen):
        benutzer, passwort = zugang(einstellungen)
        with sperre:
            alt = cache.get(aktion)
            if alt and time.time() - alt[0] < XTREAM_ZWISCHENSPEICHER:
                return alt[1]
        try:
            roh = json.loads(host.abruf("%s/player_api.php?%s" % (url, urlencode(
                {"username": benutzer, "password": passwort, "action": aktion}))))
        except NetzFehler as fehler:
            # der eingebaute vxparser ist nur nicht gestartet: kein Fehler, sondern wie eine fehlende Einstellung
            if ist_vx and _verbindung_abgelehnt(fehler):
                raise FehlendeEinstellung("vxparser laeuft nicht (in der App unten „Starten“)") from fehler
            raise
        roh = roh if isinstance(roh, list) else []
        with sperre:
            cache[aktion] = (time.time(), roh)
        return roh

    def finden(eingabe, einstellungen, host):
        serie = eingabe.get("art") == "serie"
        titel = eingabe.get("titel") or eingabe.get("text") or ""
        treffer = []
        for e in liste(host, "get_series" if serie else "get_vod_streams", einstellungen):
            if not isinstance(e, dict) or not _enthaelt_woerter(str(e.get("name") or ""), titel):
                continue
            t = {"titel": str(e.get("name")), "quelle": anbieter_id,
                 "poster": str(e.get("cover") or e.get("stream_icon") or "")}
            if serie:
                t.update(ref="serie:%s" % e.get("series_id"), serie_id=str(e.get("series_id")))
                if eingabe.get("staffel") is not None:
                    t.update(staffel=eingabe["staffel"], folge=eingabe.get("folge"))
                jahr = str(e.get("releaseDate") or "")[:4]
            else:
                t.update(ref="vod:%s" % e.get("stream_id"), stream_id=str(e.get("stream_id")),
                         ext=str(e.get("container_extension") or "mp4"))
                jahr = str(e.get("year") or e.get("releaseDate") or "")[:4]
            if jahr.isdigit():
                t["jahr"] = int(jahr)
            if e.get("genre"):
                t["genre"] = str(e["genre"])
            treffer.append(t)
            if len(treffer) >= MAX_TREFFER:
                break
        return treffer

    def adresse(pfad, einstellungen, sid, ext):
        benutzer, passwort = zugang(einstellungen)
        ext = ext if re.match(r"^[A-Za-z0-9]{1,5}$", str(ext or "")) else "mp4"
        return "%s/%s/%s/%s/%s.%s" % (url, pfad, quote(benutzer, safe=""), quote(passwort, safe=""), sid, ext)

    def aufloesen(treffer, einstellungen, host):
        if treffer.get("stream_id"):
            return [{"url": adresse("movie", einstellungen, treffer["stream_id"], treffer.get("ext"))}]
        if not treffer.get("serie_id"):
            return []
        benutzer, passwort = zugang(einstellungen)
        info = json.loads(host.abruf("%s/player_api.php?%s" % (url, urlencode(
            {"username": benutzer, "password": passwort, "action": "get_series_info",
             "series_id": treffer["serie_id"]}))))
        episoden = info.get("episodes") if isinstance(info, dict) else None
        streams = []
        for staffel, folgen in (episoden.items() if isinstance(episoden, dict) else []):
            for f in folgen if isinstance(folgen, list) else []:
                if not isinstance(f, dict):
                    continue
                nummer = f.get("episode_num")
                if treffer.get("staffel") is not None and (str(staffel) != str(treffer["staffel"])
                                                           or str(nummer) != str(treffer.get("folge"))):
                    continue
                streams.append({"url": adresse("series", einstellungen, f.get("id"), f.get("container_extension")),
                                "aufloesung": "S%sE%s %s" % (staffel, nummer, f.get("title") or "")})
        return streams[:MAX_TREFFER]

    gemeinsam = {"konto": anbieter_id, "rang": 45,
                 "einstellungen": _felder("url" if ist_vx else "url_login"),
                 "darf": {"netz": [_host(url)], "geheimnisse": [] if ist_vx else ["pass"]}}
    return [_synthetisch(dict(gemeinsam, id=anbieter_id + "-finder", name=name, rolle="finder", nimmt="anfrage",
                              gibt="treffer"), finden),
            _synthetisch(dict(gemeinsam, id=anbieter_id + "-aufloeser", name=name, rolle="aufloeser",
                              nimmt="treffer", gibt="stream", passt_zu={"quelle": anbieter_id}), aufloesen)]


def _binsearch_module(anbieter_id, eintrag):
    """binsearch.info als Indexer: freie Usenet-Suche ohne Konto, Treffer wie bei Newznab (NZB-Streams)."""
    from . import binsearch
    name = eintrag["name"]

    def finden(eingabe, einstellungen, host):
        titel = eingabe.get("titel") or eingabe.get("text") or ""
        text = eingabe.get("text") or titel
        if eingabe.get("art") == "film" and eingabe.get("jahr") and str(eingabe["jahr"]) not in text:
            text = "%s %s" % (text, eingabe["jahr"])
        treffer = []
        for r in binsearch.suchen(text, host.abruf):
            if not _enthaelt_woerter(r["titel"], titel):
                continue
            t = {"titel": r["titel"], "ref": r["id"], "quelle": anbieter_id, "groesse": r["groesse"], "nzb": r["nzb"]}
            aufloesung = _AUFLOESUNG.search(r["titel"])
            if aufloesung:
                t["aufloesung"] = aufloesung.group(1).lower()
            treffer.append(t)
        return treffer[:MAX_TREFFER]

    def aufloesen(treffer, einstellungen, host):
        return [{"url": treffer["nzb"], "nzb": True, "aufloesung": treffer.get("aufloesung", "")}] if treffer.get("nzb") else []

    gemeinsam = {"konto": anbieter_id, "einstellungen": [], "darf": {"netz": ["binsearch.info"]}, "rang": 45}
    return [_synthetisch(dict(gemeinsam, id=anbieter_id + "-finder", name=name, rolle="finder", nimmt="anfrage",
                              gibt="treffer"), finden),
            _synthetisch(dict(gemeinsam, id=anbieter_id + "-aufloeser", name=name, rolle="aufloeser",
                              nimmt="treffer", gibt="stream", passt_zu={"quelle": anbieter_id}), aufloesen)]


def module(daten):
    """Module (Finder und Aufloeser) aus den eigenen Anbietern mit Typ newznab, torznab, binsearch, xtream, vxparser,
    jellyfin, emby und plex."""
    ergebnis = []
    for typ in ("newznab", "torznab", "binsearch", "xtream", "vxparser", "jellyfin", "emby", "plex"):
        for anbieter_id, eintrag, werte in eigene(daten, typ):
            try:
                if typ == "binsearch":
                    ergebnis.extend(_binsearch_module(anbieter_id, eintrag))
                elif typ in ("jellyfin", "emby", "plex"):
                    if _host(werte.get("url")):
                        ergebnis.extend(heimserver_module(anbieter_id, eintrag, werte, typ))
                elif typ in ("newznab", "torznab"):
                    if not _host(werte.get("url")):
                        continue  # ohne Adresse unvollstaendig, die Kette laesst ihn ohnehin aus
                    ergebnis.extend(_indexer_module(anbieter_id, eintrag, werte, typ == "torznab"))
                else:
                    if typ == "xtream" and not _host(werte.get("url")):
                        continue
                    ergebnis.extend(_xtream_module(anbieter_id, eintrag, werte, typ == "vxparser"))
            except (ValueError, vxparser.VxFehler) as fehler:
                log.warning("Anbieter %s: %s", anbieter_id, fehler)
    return ergebnis


def usenet_server(daten):
    """NNTP-Server fuer Stremio: nntps://benutzer:passwort@host:port/verbindungen."""
    server = []
    for _, _, w in eigene(daten, "nntp"):
        host = w.get("host", "").strip()
        if not host or not w.get("user") or not w.get("pass"):
            continue
        port = w.get("port", "").strip() or ("563" if w.get("ssl", "1") == "1" else "119")
        verbindungen = w.get("verbindungen", "").strip() or "8"
        server.append("%s://%s:%s@%s:%s/%s" % ("nntps" if w.get("ssl", "1") == "1" else "nntp",
                                               quote(w["user"], safe=""), quote(w["pass"], safe=""), host,
                                               port if port.isdigit() else "563",
                                               verbindungen if verbindungen.isdigit() else "8"))
    return server
