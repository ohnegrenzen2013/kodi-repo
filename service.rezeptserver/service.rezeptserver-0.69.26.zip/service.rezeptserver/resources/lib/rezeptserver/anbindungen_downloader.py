"""NZB bzw. Magnet an einen Download- oder Torrent-Client uebergeben."""

from .anbindungen_grund import (
    NetzFehler,
    urllib_holen,
)

def nzb_senden(eintrag, werte, nzb_url, name, holen=urllib_holen, oeffnen_nzb=None):
    """NZB an einen Download-Client (rustnzb, NZBGet, SABnzbd). H0rSt laedt die NZB selbst und laedt sie hoch:
    der API-Schluessel des Indexers bleibt hier, und es klappt auch, wenn der Client den Indexer nicht erreicht."""
    from . import dienste, rustnzb
    typ = eintrag.get("typ")
    if typ not in dienste.NZB_CLIENTS:
        raise NetzFehler("%s ist kein Usenet-Downloader" % eintrag.get("name"))
    try:
        daten = oeffnen_nzb(nzb_url) if oeffnen_nzb else rustnzb.nzb_laden(nzb_url)
        client = dienste.KLASSEN[typ](eintrag.get("name", typ), werte,
                                      None if holen is urllib_holen else dienste.aus_antwort(holen))
        client.nzb_hinzufuegen(name, daten)
    except (rustnzb.RustnzbFehler, dienste.DienstFehler) as fehler:
        raise NetzFehler(str(fehler))
    return "an %s übergeben" % client.typ_name


def torrent_senden(eintrag, werte, magnet, holen=None):
    """Magnet-Link an einen Torrent-Client (qBittorrent, Transmission, Deluge)."""
    from . import dienste
    typ = eintrag.get("typ")
    if typ not in dienste.TORRENT_CLIENTS:
        raise NetzFehler("%s ist kein Torrent-Client" % eintrag.get("name"))
    if not str(magnet).startswith("magnet:"):
        raise NetzFehler("Kein Magnet-Link")
    try:
        client = dienste.KLASSEN[typ](eintrag.get("name", typ), werte, holen)
        client.torrent_hinzufuegen(magnet)
    except dienste.DienstFehler as fehler:
        raise NetzFehler(str(fehler))
    return "an %s übergeben" % client.typ_name
