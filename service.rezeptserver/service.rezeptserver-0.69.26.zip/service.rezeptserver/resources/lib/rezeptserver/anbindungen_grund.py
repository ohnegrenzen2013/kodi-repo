"""Grundbausteine der Anbindungen: Importe, Konstanten und gemeinsame Helfer.
Alles hier wird samt Importen wieder exportiert (rezeptserver.anbindungen.*), damit die
Aufteilung nach aussen unsichtbar bleibt."""


import json
import logging
import re
import socket
import ssl
import threading
import time
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor, wait
from email.utils import parsedate_to_datetime
from urllib.parse import quote, urlencode, urlsplit

from . import sicherheit, vxparser
from .modul import Modul
from .netz import Abrufer, NetzFehler, oeffentlich_holen, urllib_holen
from .schritte import _enthaelt_woerter

log = logging.getLogger("rezeptserver")

NEWZNAB_NS = "http://www.newznab.com/DTD/2010/feeds/attributes/"
TORZNAB_NS = "http://torznab.com/schemas/2015/feed"
MAX_TREFFER = 60
XTREAM_ZWISCHENSPEICHER = 900
ADDON_ZEIT = 8.0
_AUFLOESUNG = re.compile(r"(?i)\b(2160p|1080p|720p|576p|480p)\b")
_HASH = re.compile(r"(?i)\b(?:urn:btih:)?([0-9a-f]{40})\b")


def _werte(daten, anbieter_id):
    return {k: str(w) for k, w in ((daten.get("einstellungen") or {}).get(anbieter_id) or {}).items()}


def eigene(daten, typ):
    """[(id, eintrag, werte)] der eigenen Anbieter eines Typs."""
    return [(i, e, _werte(daten, i)) for i, e in sorted((daten.get("anbieter") or {}).items())
            if e.get("typ") == typ]


def _basis(url):
    url = str(url or "").strip().rstrip("/")
    if url and "://" not in url:
        url = "https://" + url
    return url


def _host(url):
    return (urlsplit(_basis(url)).hostname or "").lower()


def _synthetisch(daten, funktion):
    m = Modul(dict(daten, spec="0.1", version="1.0.0", skript="<eingebaut>"), None)
    m._skript_funktion = funktion
    return m


def _felder(anmeldung):
    from .anbieter import FELDER
    return [dict(f) for f in FELDER[anmeldung]]


# --- Newznab / Torznab ----------------------------------------------------------

def _api_adresse(url):
    url = _basis(url)
    return url if url.endswith("/api") else url + "/api"


# --- Verbindungstest --------------------------------------------------------------------------

DEBRID = {
    "realdebrid": ("https://api.real-debrid.com/rest/1.0/user", "bearer"),
    "alldebrid": ("https://api.alldebrid.com/v4/user?agent=h0rst", "bearer"),
    "premiumize": ("https://www.premiumize.me/api/account/info", "apikey"),
    "torbox": ("https://api.torbox.app/v1/api/user/me", "bearer"),
    "debridlink": ("https://debrid-link.com/api/v2/account/infos", "bearer"),
}
