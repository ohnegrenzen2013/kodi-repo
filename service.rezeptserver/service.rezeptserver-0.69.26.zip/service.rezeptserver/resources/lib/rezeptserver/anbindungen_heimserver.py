"""Eigene Medienserver als Quelle: Jellyfin, Emby und Plex (Idee aus ARVIO, "Home Server").

Der Finder sucht den Film oder die Serie in der Mediathek des eigenen Servers, am liebsten ueber die IMDb-Nummer
(ProviderIds bei Jellyfin/Emby, Guid bei Plex), sonst ueber Titel und Jahr. Der Aufloeser liefert die Datei direkt,
ohne Umwandeln (Direct Play) – jede Fassung (MediaSource bzw. Media) ist ein eigener Stream.

Zugang: Adresse und API-Schluessel (Jellyfin/Emby: Dashboard → API-Schluessel; Plex: X-Plex-Token). Der Schluessel
steckt in der Stream-Adresse, damit jeder Player sie ohne eigene Kopfzeilen abspielen kann – wie das Passwort bei Xtream.
"""

from .anbindungen_grund import MAX_TREFFER, _basis, _enthaelt_woerter, _felder, _host, _synthetisch, json, quote, re, urlencode

ARTEN = {"jellyfin": "Jellyfin", "emby": "Emby", "plex": "Plex"}
_KENNUNG = 'MediaBrowser Client="H0rSt", Device="H0rSt", DeviceId="h0rst", Version="1"'
_ENDUNG = re.compile(r"^[a-z0-9]{2,5}$")


def jellyfin_kopf(token):
    # X-Emby-Token kennen Emby und aeltere Jellyfin-Versionen, Authorization die neueren
    return {"Accept": "application/json", "X-Emby-Token": token, "Authorization": '%s, Token="%s"' % (_KENNUNG, token)}


def plex_kopf(token):
    return {"Accept": "application/json", "X-Plex-Token": token}


def _imdb_von(eingabe):
    return str((eingabe.get("ids") or {}).get("imdb") or "")


def passt(eingabe, titel, jahr, imdb):
    """Gleiche IMDb-Nummer entscheidet; ohne sie muessen alle Woerter des Titels passen und das Jahr hoechstens 1 abweichen."""
    soll = _imdb_von(eingabe)
    if soll and imdb:
        return soll == imdb
    if not _enthaelt_woerter(titel, eingabe.get("titel") or eingabe.get("text") or ""):
        return False
    try:
        return not (eingabe.get("jahr") and jahr and abs(int(jahr) - int(eingabe["jahr"])) > 1)
    except (TypeError, ValueError):
        return True


def aufloesung(hoehe):
    try:
        hoehe = int(hoehe)
    except (TypeError, ValueError):
        return ""
    for grenze, name in ((2000, "2160p"), (1000, "1080p"), (700, "720p"), (1, "480p")):
        if hoehe >= grenze:
            return name
    return ""


def _endung(container):
    """Erste Endung aus z. B. "mov,mp4,m4a"; nur harmlose Zeichen."""
    erste = str(container or "").split(",")[0].strip().lower()
    return erste if _ENDUNG.match(erste) else ""


def _treffer(anbieter_id, eingabe, kennung, titel, jahr):
    t = {"titel": titel, "quelle": anbieter_id, "ref": kennung, "server_id": kennung.split(":", 1)[1]}
    if jahr:
        t["jahr"] = int(jahr)
    if eingabe.get("art") == "serie" and eingabe.get("staffel") is not None:
        t.update(staffel=eingabe["staffel"], folge=eingabe.get("folge"))
    if _imdb_von(eingabe):
        t["imdb"] = _imdb_von(eingabe)
    return t


def _jellyfin_module(anbieter_id, url, name):
    def finden(eingabe, einstellungen, host):
        serie = eingabe.get("art") == "serie"
        abfrage = {"Recursive": "true", "IncludeItemTypes": "Series" if serie else "Movie", "Limit": "20",
                   "SearchTerm": eingabe.get("titel") or eingabe.get("text") or "", "Fields": "ProviderIds,ProductionYear"}
        daten = json.loads(host.abruf("%s/Items?%s" % (url, urlencode(abfrage)), header=jellyfin_kopf(einstellungen["api_key"])))
        treffer = []
        for e in (daten.get("Items") if isinstance(daten, dict) else None) or []:
            if not isinstance(e, dict) or not e.get("Id"):
                continue
            ids = {str(k).lower(): str(v) for k, v in (e.get("ProviderIds") or {}).items()}
            if passt(eingabe, str(e.get("Name") or ""), e.get("ProductionYear"), ids.get("imdb")):
                treffer.append(_treffer(anbieter_id, eingabe, "%s:%s" % ("serie" if serie else "film", e["Id"]),
                                        str(e.get("Name") or ""), e.get("ProductionYear")))
        return treffer[:MAX_TREFFER]

    def aufloesen(treffer, einstellungen, host):
        token = einstellungen["api_key"]
        kennung = str(treffer.get("server_id") or "")
        if not kennung:
            return []
        if str(treffer.get("ref", "")).startswith("serie:"):
            if treffer.get("staffel") is None:
                return []
            daten = json.loads(host.abruf("%s/Shows/%s/Episodes?%s" % (url, quote(kennung, safe=""), urlencode(
                {"Season": treffer["staffel"], "Fields": "MediaSources"})), header=jellyfin_kopf(token)))
            folgen = [f for f in (daten.get("Items") or []) if isinstance(f, dict)
                      and str(f.get("IndexNumber")) == str(treffer.get("folge"))
                      and str(f.get("ParentIndexNumber", treffer["staffel"])) == str(treffer["staffel"])]
        else:
            daten = json.loads(host.abruf("%s/Items?%s" % (url, urlencode({"Ids": kennung, "Fields": "MediaSources"})),
                                          header=jellyfin_kopf(token)))
            folgen = [f for f in (daten.get("Items") or []) if isinstance(f, dict)]
        streams = []
        for f in folgen:
            for quelle in f.get("MediaSources") or [{"Id": f.get("Id")}]:
                if not isinstance(quelle, dict) or not f.get("Id"):
                    continue
                video = next((s for s in quelle.get("MediaStreams") or [] if isinstance(s, dict) and s.get("Type") == "Video"), {})
                endung = _endung(quelle.get("Container"))
                parameter = {"Static": "true", "MediaSourceId": quelle.get("Id") or f["Id"], "ApiKey": token, "api_key": token}
                streams.append({"url": "%s/Videos/%s/stream%s?%s" % (url, quote(str(f["Id"]), safe=""),
                                                                    "." + endung if endung else "", urlencode(parameter)),
                                "aufloesung": aufloesung(video.get("Height")) or str(quelle.get("Name") or "")})
        return streams[:MAX_TREFFER]

    return finden, aufloesen


def _plex_module(anbieter_id, url, name):
    def finden(eingabe, einstellungen, host):
        serie = eingabe.get("art") == "serie"
        abfrage = {"query": eingabe.get("titel") or eingabe.get("text") or "", "limit": "20", "includeGuids": "1"}
        daten = json.loads(host.abruf("%s/hubs/search?%s" % (url, urlencode(abfrage)), header=plex_kopf(einstellungen["api_key"])))
        treffer = []
        for hub in ((daten.get("MediaContainer") or {}).get("Hub") if isinstance(daten, dict) else None) or []:
            if not isinstance(hub, dict) or hub.get("type") != ("show" if serie else "movie"):
                continue
            for e in hub.get("Metadata") or []:
                if not isinstance(e, dict) or not e.get("ratingKey"):
                    continue
                imdb = next((str(g.get("id"))[7:] for g in e.get("Guid") or []
                             if isinstance(g, dict) and str(g.get("id", "")).startswith("imdb://")), "")
                if passt(eingabe, str(e.get("title") or ""), e.get("year"), imdb):
                    treffer.append(_treffer(anbieter_id, eingabe, "%s:%s" % ("serie" if serie else "film", e["ratingKey"]),
                                            str(e.get("title") or ""), e.get("year")))
        return treffer[:MAX_TREFFER]

    def aufloesen(treffer, einstellungen, host):
        token = einstellungen["api_key"]
        kennung = quote(str(treffer.get("server_id") or ""), safe="")
        if not kennung:
            return []
        if str(treffer.get("ref", "")).startswith("serie:"):
            if treffer.get("staffel") is None:
                return []
            daten = json.loads(host.abruf("%s/library/metadata/%s/allLeaves" % (url, kennung), header=plex_kopf(token)))
            eintraege = [f for f in (daten.get("MediaContainer") or {}).get("Metadata") or [] if isinstance(f, dict)
                         and str(f.get("parentIndex")) == str(treffer["staffel"]) and str(f.get("index")) == str(treffer.get("folge"))]
        else:
            daten = json.loads(host.abruf("%s/library/metadata/%s?includeGuids=1" % (url, kennung), header=plex_kopf(token)))
            eintraege = [f for f in (daten.get("MediaContainer") or {}).get("Metadata") or [] if isinstance(f, dict)]
            imdb = str(treffer.get("imdb") or "")
            guids = {str(g.get("id")) for f in eintraege for g in f.get("Guid") or [] if isinstance(g, dict)}
            if imdb and any(g.startswith("imdb://") for g in guids) and "imdb://" + imdb not in guids:
                return []  # die Suche fand nur einen gleichnamigen Film
        streams = []
        for f in eintraege:
            for medium in f.get("Media") or []:
                for teil in (medium.get("Part") or []) if isinstance(medium, dict) else []:
                    schluessel = str(teil.get("key") or "") if isinstance(teil, dict) else ""
                    if not schluessel.startswith("/"):
                        continue
                    hoehe = str(medium.get("videoResolution") or "").lower()
                    streams.append({"url": "%s%s?%s" % (url, schluessel, urlencode({"X-Plex-Token": token})),
                                    "aufloesung": "2160p" if hoehe == "4k" else (hoehe + "p" if hoehe.isdigit() else hoehe)})
        return streams[:MAX_TREFFER]

    return finden, aufloesen


def heimserver_module(anbieter_id, eintrag, werte, art):
    """Finder und Aufloeser fuer einen eigenen Jellyfin-, Emby- oder Plex-Server."""
    url = _basis(werte.get("url"))
    name = eintrag.get("name") or ARTEN[art]
    finden, aufloesen = (_plex_module if art == "plex" else _jellyfin_module)(anbieter_id, url, name)
    gemeinsam = {"konto": anbieter_id, "rang": 40, "einstellungen": _felder("url_api"),
                 "darf": {"netz": [_host(url)], "geheimnisse": ["api_key"]}}
    return [_synthetisch(dict(gemeinsam, id=anbieter_id + "-finder", name=name, rolle="finder", nimmt="anfrage",
                              gibt="treffer"), finden),
            _synthetisch(dict(gemeinsam, id=anbieter_id + "-aufloeser", name=name, rolle="aufloeser",
                              nimmt="treffer", gibt="stream", passt_zu={"quelle": anbieter_id}), aufloesen)]


def pruefen(art, werte, abrufer):
    """Verbindungstest: (ok, meldung)."""
    url = _basis(werte.get("url"))
    token = werte.get("api_key", "")
    if art == "plex":
        daten = json.loads(abrufer.abruf(url + "/library/sections", header=plex_kopf(token)))
        bereiche = [b.get("title") for b in (daten.get("MediaContainer") or {}).get("Directory") or [] if isinstance(b, dict)]
        return True, "Plex antwortet, %d Mediatheken: %s" % (len(bereiche), ", ".join(map(str, bereiche)))
    info = json.loads(abrufer.abruf(url + "/System/Info", header=jellyfin_kopf(token)))
    return True, "%s %s antwortet (%s)" % (ARTEN[art], info.get("Version", ""), info.get("ServerName", ""))
