"""Verbindungstest fuer eigene Anbieter (Indexer, Xtream, Addon, NNTP, Debrid)."""

from .anbindungen_anbieter import (
    newznab_lesen,
)
from .anbindungen_grund import (
    Abrufer,
    DEBRID,
    NetzFehler,
    _api_adresse,
    _basis,
    _host,
    json,
    sicherheit,
    ssl,
    urlencode,
    urllib_holen,
    vxparser,
)
from . import anbindungen_heimserver as heimserver
from .anbindungen_mhub import MhubAddons
from .anbindungen_stremio import (
    StremioAddons,
)
from .nntp_pruefung import NntpFehler, _nntp_verbinden

def _nntp_pruefen(werte, zeit=10.0):
    try:
        nntp = _nntp_verbinden(werte, zeit)
    except NntpFehler as fehler:
        return False, str(fehler)
    try:
        return True, "Anmeldung erfolgreich (%s:%d)" % (nntp.host, nntp.port)
    finally:
        nntp.schliessen()


def pruefen(eintrag, werte, holen=urllib_holen):
    """Verbindungstest fuer einen eigenen Anbieter. Gibt (ok, meldung) zurueck, wirft nie."""
    typ = eintrag.get("typ", "")
    try:
        if typ in ("wireguard",) + sicherheit.WEG_TYPEN:
            return sicherheit.anbieter_pruefen(eintrag, werte)
        if typ == "nntp":
            return _nntp_pruefen(werte)
        url = _basis(werte.get("url"))
        if typ in ("newznab", "torznab"):
            text = Abrufer([_host(url)], holen=holen).abruf(
                _api_adresse(url) + "?" + urlencode({"t": "caps", "apikey": werte.get("api_key", "")}))
            if "<caps" not in text:
                return False, "Keine Newznab/Torznab-Antwort: " + text[:120]
            treffer = Abrufer([_host(url)], holen=holen).abruf(
                _api_adresse(url) + "?" + urlencode({"t": "search", "q": "test", "limit": "1",
                                                     "apikey": werte.get("api_key", "")}))
            newznab_lesen(treffer, typ == "torznab")
            return True, "Indexer antwortet, API-Schlüssel gültig"
        if typ in ("jellyfin", "emby", "plex"):
            return heimserver.pruefen(typ, werte, Abrufer([_host(url)], holen=holen))
        if typ in ("xtream", "vxparser"):
            benutzer, passwort = (vxparser.BENUTZER, vxparser.BENUTZER) if typ == "vxparser" else \
                (werte.get("user", ""), werte.get("pass", ""))
            z = vxparser.Client(werte.get("url") or vxparser.STANDARD_ADRESSE, benutzer, passwort,
                                holen=holen).zustand()
            if not z["erreichbar"]:
                return False, z["fehler"]
            k = z["kategorien"]
            return True, "Erreichbar: %s Live-, %s Film-, %s Serien-Kategorien" % (k.get("live"), k.get("vod"),
                                                                                  k.get("serie"))
        if typ == "stremio-addon":
            addon = StremioAddons([{"id": "test", "name": "test", "url": werte.get("url", ""),
                                    "heimnetz_erlaubt": werte.get("heimnetz_erlaubt") == "1"}], holen=holen)
            try:
                if not addon.addons:
                    return False, "Ungültige Adresse"
                m = addon.manifest(addon.addons[0])
            finally:
                addon.schliessen()
            if not m.get("id"):
                return False, "Keine manifest.json unter dieser Adresse"
            namen = [r if isinstance(r, str) else r.get("name") for r in m.get("resources") or []]
            return True, "%s %s: %s" % (m.get("name", m["id"]), m.get("version", ""), ", ".join(map(str, namen)))
        if typ == "mhub-addon":
            addon = MhubAddons([{"id": "test", "name": "test", "url": werte.get("url", ""),
                                "heimnetz_erlaubt": werte.get("heimnetz_erlaubt") == "1"}], holen=holen)
            try:
                if not addon.addons:
                    return False, "Ungültige Adresse"
                m = addon.manifest(addon.addons[0])
            finally:
                addon.schliessen()
            if not m.get("id"):
                return False, "Kein mhub-addon.json unter dieser Adresse (mHub-Protokoll v2)"
            return True, "%s %s: %s" % (m.get("name", m["id"]), m.get("version", ""), ", ".join(map(str, m.get("resources") or [])))
        if typ == "debrid":
            vorlage = eintrag.get("vorlage", "")
            if vorlage not in DEBRID:
                return False, "Für diesen Dienst gibt es keinen Test"
            adresse, art = DEBRID[vorlage]
            header = {}
            if art == "bearer":
                header["Authorization"] = "Bearer " + werte.get("api_key", "")
            else:
                adresse += "?" + urlencode({"apikey": werte.get("api_key", "")})
            text = Abrufer([_host(adresse)], holen=holen).abruf(adresse, header=header)
            daten = json.loads(text)
            if isinstance(daten, dict) and (daten.get("status") in ("error", False) or daten.get("success") is False
                                            or daten.get("error")):
                return False, "Dienst lehnt ab: %s" % (daten.get("error") or daten.get("message") or daten)[:160]
            return True, "API-Schlüssel gültig"
        from . import dienste
        if typ in dienste.KLASSEN and typ != "rustnzb":
            try:
                return True, dienste.KLASSEN[typ](eintrag.get("name", typ), werte,
                                                  None if holen is urllib_holen else dienste.aus_antwort(holen)).pruefen()
            except dienste.DienstFehler as fehler:
                return False, str(fehler)
        if typ == "rustnzb":
            from . import rustnzb
            try:
                s = rustnzb.Client(werte, holen=None if holen is urllib_holen else holen).status()
            except rustnzb.RustnzbFehler as fehler:
                return False, str(fehler)
            mediathek = "Mediathek an" if s.get("webdav_enabled") else (
                "Mediathek aus ([dav] enabled = true)" if s.get("webdav_available") else "ohne Mediathek (Build ohne webdav)")
            return True, "rustnzb %s, %s Jobs in der Warteschlange, %s" % (s.get("version", "?"), s.get("queue_size", 0),
                                                                          mediathek)
        if typ == "vxparser-link":
            return (True, "Wird über /vxparser/urls.json an vxparser weitergegeben") if url else (False, "Adresse fehlt")
        return False, "Für diesen Anbieter gibt es keinen Test"
    except (NetzFehler, OSError, ValueError, KeyError, ssl.SSLError) as fehler:
        return False, str(fehler)[:300]
