"""Fremde Stremio-Addons: Manifest, Suchkataloge, Streams und Untertitel zu einer ID."""

from .anbindungen_grund import (
    ADDON_ZEIT,
    Abrufer,
    NetzFehler,
    ThreadPoolExecutor,
    _host,
    eigene,
    json,
    log,
    oeffentlich_holen,
    quote,
    re,
    threading,
    time,
    urllib_holen,
    wait,
)

def _durchstoeberbar(katalog):
    """Ein Katalog, den man ohne Suchbegriff durchblaettern kann (Typ movie/series, Pflicht-Extras hoechstens
    {genre}) -> {typ, katalog, name, genres, genre_pflicht, blaettern} oder None, wenn ungeeignet (z. B. reiner
    Suchkatalog, Pflicht-Extra ausser genre, oder genre-Pflicht ohne feste Optionen)."""
    if not isinstance(katalog, dict) or katalog.get("type") not in ("movie", "series") or not katalog.get("id"):
        return None
    extras = [e for e in katalog.get("extra") or [] if isinstance(e, dict)]
    pflicht = {e.get("name") for e in extras if e.get("isRequired")} | set(katalog.get("extraRequired") or [])
    if pflicht - {"genre"}:
        return None
    genre_extra = next((e for e in extras if e.get("name") == "genre"), None)
    genres = [g for g in (genre_extra or {}).get("options") or [] if isinstance(g, str)][:100]
    if "genre" in pflicht and not genres:
        return None
    unterstuetzt = {e.get("name") for e in extras} | set(katalog.get("extraSupported") or [])
    return {"typ": katalog["type"], "katalog": str(katalog["id"]), "name": str(katalog.get("name") or katalog["id"])[:60],
            "genres": genres, "genre_pflicht": "genre" in pflicht, "blaettern": "skip" in unterstuetzt}


def _hosts(basis):
    """Erlaubte Hosts. strem.io und stremio.com leiten aufeinander um und gelten als dasselbe Addon."""
    host = _host(basis)
    if host in ("strem.io", "stremio.com") or host.endswith((".strem.io", ".stremio.com")):
        return ["strem.io", "stremio.com"]
    return [host]


def _such_kataloge(kataloge):
    """Kataloge, die eine Suche anbieten. Gibt es welche mit „search“ in der Id, nur die – sonst höchstens vier.
    So wird ein Addon nicht bei jedem Tastendruck auf allen Trend-Listen abgefragt (HTTP 429)."""
    passende = []
    for k in kataloge or []:
        if not isinstance(k, dict) or k.get("type") not in ("movie", "series") or not k.get("id"):
            continue
        extra = [e.get("name") for e in k.get("extra") or [] if isinstance(e, dict)]
        if "search" in extra or "search" in (k.get("extraSupported") or []):
            passende.append(k)
    such = [k for k in passende if "search" in str(k.get("id")).lower()]
    return such or passende[:4]


def _ressource(manifest, name, typ, sid):
    """Bietet das Addon die Ressource fuer diesen Typ und diese ID an?"""
    for r in manifest.get("resources") or []:
        if isinstance(r, str) and r == name:
            typen, praefixe = manifest.get("types") or [], manifest.get("idPrefixes")
        elif isinstance(r, dict) and r.get("name") == name:
            typen = r.get("types") or manifest.get("types") or []
            praefixe = r.get("idPrefixes", manifest.get("idPrefixes"))
        else:
            continue
        if typ in typen and (not praefixe or any(sid.startswith(p) for p in praefixe)):
            return True
    return False


class StremioAddons:
    """Fremde Stremio-Addons: Streams und Untertitel zu einer ID einsammeln (parallel, mit Zeitgrenze)."""

    def __init__(self, addons, holen=urllib_holen, zeitgrenze=ADDON_ZEIT):
        self.addons = []
        for a in addons:
            url = str(a.get("url") or "")
            if url.lower().startswith("stremio://"):
                url = "https://" + url[len("stremio://"):]
            basis = re.sub(r"/manifest\.json$", "", url.strip().rstrip("/"))
            if basis.startswith(("http://", "https://")) and _host(basis):
                self.addons.append({"id": a["id"], "name": a["name"], "basis": basis,
                                    "heimnetz_erlaubt": bool(a.get("heimnetz_erlaubt"))})
        self.holen = holen
        self.zeitgrenze = zeitgrenze
        self.zaehler = None  # nutzung.Nutzung.zaehler (setzt die App)
        self._manifeste = {}
        self._sperre = threading.Lock()
        self._pool = ThreadPoolExecutor(max_workers=6, thread_name_prefix="addon") if self.addons else None

    def _abrufer(self, addon):
        holen = self.holen if addon.get("heimnetz_erlaubt") else oeffentlich_holen(self.holen)
        return Abrufer(_hosts(addon["basis"]), holen=holen, zeitgrenze=self.zeitgrenze)

    def manifest(self, addon):
        with self._sperre:
            alt = self._manifeste.get(addon["id"])
            if alt and time.time() - alt[0] < 3600:
                return alt[1]
        try:
            m = json.loads(self._abrufer(addon).abruf(addon["basis"] + "/manifest.json"))
        except (NetzFehler, ValueError) as fehler:
            log.warning("Stremio-Addon %s: Manifest nicht lesbar: %s", addon["name"], fehler)
            m = {}
        with self._sperre:
            self._manifeste[addon["id"]] = (time.time(), m if isinstance(m, dict) else {})
        return self._manifeste[addon["id"]][1]

    def _hole(self, addon, art, typ, sid):
        manifest = self.manifest(addon)
        erlaubt = _ressource(manifest, art, typ, sid)
        if not erlaubt and art == "stream":
            kataloge = manifest.get("catalogs") or []
            erlaubt = any(isinstance(k, dict) and k.get("type") == typ and k.get("id") for k in kataloge)
        if not erlaubt:
            return []
        try:
            text = self._abrufer(addon).abruf("%s/%s/%s/%s.json" % (addon["basis"], art, quote(typ, safe=""),
                                                                     quote(sid, safe=":")))
            daten = json.loads(text) if text and str(text).strip() else {}
        except NetzFehler as fehler:
            if "HTTP 404" in str(fehler):
                return []
            raise
        liste = daten.get("streams" if art == "stream" else "subtitles") if isinstance(daten, dict) else None
        return [e for e in liste or [] if isinstance(e, dict)]

    def _sammeln(self, art, typ, sid):
        if not self._pool:
            return []
        zukuenfte = {self._pool.submit(self._hole, a, art, typ, sid): a for a in self.addons}
        fertig, offen = wait(zukuenfte, timeout=self.zeitgrenze)
        for z in offen:
            log.warning("Stremio-Addon %s: Zeitgrenze ueberschritten", zukuenfte[z]["name"])
            self._zaehlen(art, zukuenfte[z], fehler=True)
        ergebnis = []
        for a in self.addons:  # Reihenfolge wie eingetragen
            for z, addon in zukuenfte.items():
                if addon is a and z in fertig:
                    try:
                        liste = z.result()
                    except Exception as fehler:
                        log.warning("Stremio-Addon %s: %s", a["name"], fehler)
                        self._zaehlen(art, a, fehler=True)
                        continue
                    ergebnis.extend((a, e) for e in liste)
                    self._zaehlen(art, a, len(liste))
        return ergebnis

    def _zaehlen(self, art, addon, treffer=0, fehler=False):
        """Rangliste der Addons im Admin-Panel (nutzung.py): nur Stream-Abfragen."""
        if art == "stream" and getattr(self, "zaehler", None):
            try:
                self.zaehler("addons", addon["name"], treffer, fehler)
            except Exception:
                pass

    def _katalog_hole(self, addon, katalog, text):
        typ, kid = katalog
        try:
            text = self._abrufer(addon).abruf("%s/catalog/%s/%s/search=%s.json" % (
                addon["basis"], quote(typ, safe=""), quote(kid, safe=""), quote(text, safe="")))
            daten = json.loads(text) if text and str(text).strip() else {}
        except NetzFehler as fehler:
            if "HTTP 404" in str(fehler):
                return []
            raise
        metas = daten.get("metas") if isinstance(daten, dict) else None
        return [dict(m, type=m.get("type") or typ) for m in metas or [] if isinstance(m, dict) and m.get("id")]

    def katalog_suche(self, text):
        """Suchkataloge der Addons (Katalog mit extra "search") -> [(addon, meta)], wie ARVIO."""
        if not self._pool:
            return []
        auftraege = []
        for addon in self.addons:
            for k in _such_kataloge(self.manifest(addon).get("catalogs")):
                auftraege.append((addon, self._pool.submit(self._katalog_hole, addon, (k["type"], k["id"]), text)))
        fertig, _ = wait([z for _, z in auftraege], timeout=self.zeitgrenze)
        gedrosselt = set()
        ergebnis = []
        for addon, z in auftraege:
            if z in fertig:
                try:
                    ergebnis.extend((addon, m) for m in z.result()[:40])
                except Exception as fehler:
                    if "HTTP 429" in str(fehler):
                        if addon["id"] in gedrosselt:
                            continue
                        gedrosselt.add(addon["id"])
                    log.warning("Stremio-Addon %s: Suche: %s", addon["name"], fehler)
        return ergebnis

    def katalog_liste(self):
        """Durchstoeberbare Kataloge aller Addons (ohne Suchbegriff), Reihenfolge wie eingetragen.
        -> [{"addon", "addon_name", "typ", "katalog", "name", "genres", "genre_pflicht", "blaettern"}]."""
        if not self._pool:
            return []
        auftraege = {self._pool.submit(self.manifest, a): a for a in self.addons}
        fertig, offen = wait(auftraege, timeout=self.zeitgrenze)
        for z in offen:
            log.warning("Stremio-Addon %s: Zeitgrenze ueberschritten (Katalogliste)", auftraege[z]["name"])
        ergebnis = []
        for addon in self.addons:
            for z, a in auftraege.items():
                if a is not addon or z not in fertig:
                    continue
                try:
                    manifest = z.result()
                except Exception as fehler:
                    log.warning("Stremio-Addon %s: %s", addon["name"], fehler)
                    continue
                for k in manifest.get("catalogs") or []:
                    info = _durchstoeberbar(k)
                    if info:
                        ergebnis.append(dict(info, addon=addon["id"], addon_name=addon["name"]))
        return ergebnis

    def katalog_holen(self, addon_id, typ, katalog, genre="", skip=0):
        """Ein durchstoeberbarer Katalog eines Addons, ohne Suchbegriff -> [meta]. Wirft ValueError bei
        unbekanntem Addon/Katalog oder einem Genre, das der Katalog nicht anbietet."""
        addon = next((a for a in self.addons if a["id"] == addon_id), None)
        if not addon:
            raise ValueError("Unbekanntes Addon: %s" % addon_id)
        info = next((d for d in (_durchstoeberbar(k) for k in self.manifest(addon).get("catalogs") or []) if d
                     and d["typ"] == typ and d["katalog"] == katalog), None)
        if not info:
            raise ValueError("Unbekannter oder nicht durchstoeberbarer Katalog: %s/%s" % (typ, katalog))
        if genre and genre not in info["genres"]:
            raise ValueError("Genre nicht in diesem Katalog: %s" % genre)
        if not genre and info["genre_pflicht"]:
            genre = info["genres"][0]
        extra = []
        if genre:
            extra.append("genre=" + quote(genre, safe=""))
        if info["blaettern"]:
            try:
                skip = max(0, min(10000, int(skip or 0)))
            except (TypeError, ValueError):
                skip = 0
            if skip:
                extra.append("skip=%d" % skip)
        pfad = "%s/catalog/%s/%s%s.json" % (addon["basis"], quote(typ, safe=""), quote(katalog, safe=""),
                                            "/" + "&".join(extra) if extra else "")
        daten = json.loads(self._abrufer(addon).abruf(pfad))
        metas = daten.get("metas") if isinstance(daten, dict) else None
        return [dict(m, type=m.get("type") or typ) for m in metas or [] if isinstance(m, dict) and m.get("id")][:100]

    def streams(self, typ, sid):
        streams = []
        for addon, s in self._sammeln("stream", typ, sid):
            if not any(s.get(k) for k in ("url", "infoHash", "ytId", "externalUrl", "nzbUrl")):
                continue
            s = dict(s)
            s["name"] = "\n".join(x for x in (addon["name"], str(s.get("name") or "")) if x)
            streams.append(s)
        return streams

    def untertitel(self, typ, sid):
        return [dict(u, id="%s-%s" % (a["id"], u.get("id", n))) for n, (a, u) in
                enumerate(self._sammeln("subtitles", typ, sid)) if u.get("url")]

    def schliessen(self):
        if self._pool:
            self._pool.shutdown(wait=False)


def stremio_addons(daten, holen=urllib_holen):
    return StremioAddons([{"id": i, "name": e["name"], "url": w.get("url", ""),
                           "heimnetz_erlaubt": w.get("heimnetz_erlaubt") == "1"}
                          for i, e, w in eigene(daten, "stremio-addon") if w.get("url")], holen=holen)
