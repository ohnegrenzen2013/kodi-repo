"""Anime-Tracker: AniList, MyAnimeList und Kitsu (Watchlist und Fortschritt aus H0rSt).

H0rSt speichert Titel mit IMDb-Kennungen; die Anime-Dienste mit MAL-/AniList-/Kitsu-IDs. Beim Abgleich sucht
H0rSt den Titel einmal je Sitzung beim Dienst (Titel + Jahr) und merkt sich die Zuordnung. Geschrieben werden
Merkliste (plan to watch), laufende Folgen und gesehene Filme - dieselben Staende wie in H0rSt.

Anmeldung:
  AniList  persoenlicher API-Token (anilist.co/settings/developer)
  MAL      Client ID/Secret der MAL-App + Code von der Freigabeseite (PKCE)
  Kitsu    Client ID/Secret der Kitsu-App + Benutzer/Passwort (OAuth password grant)

Nutzerdaten "anime_tracker": {"app": {"mal_client_id","mal_client_secret","mal_redirect",
                                      "kitsu_client_id","kitsu_client_secret"},
                              "konten": {"<profil>": {"anilist|mal|kitsu": {...}}}}
"""

import base64
import hashlib
import json
import secrets
import threading
import time
from urllib.parse import urlencode

from . import __version__
from .netz import NetzFehler, antwort_holen

DIENSTE = ("anilist", "mal", "kitsu")
NAMEN = {"anilist": "AniList", "mal": "MyAnimeList", "kitsu": "Kitsu"}
ANILIST = "https://graphql.anilist.co"
MAL_API = "https://api.myanimelist.net/v2"
MAL_AUTH = "https://myanimelist.net/v1/oauth2"
KITSU = "https://kitsu.io/api/edge"
KITSU_TOKEN = "https://kitsu.io/api/oauth/token"
SCHLUESSEL = "anime_tracker"
MAX_TITEL = 30  # je Abgleich; Titelsuche ist der teuerste Teil
UA = "Rezeptserver/" + __version__


class AnimeFehler(ValueError):
    pass


def _kopf(anbieter, token, json_koerper=False):
    if anbieter == "kitsu":
        k = {"Accept": "application/vnd.api+json", "User-Agent": UA}
        if json_koerper:
            k["Content-Type"] = "application/vnd.api+json"
    else:
        k = {"Accept": "application/json", "User-Agent": UA}
        if json_koerper:
            k["Content-Type"] = "application/json"
    if token:
        k["Authorization"] = "Bearer " + token
    return k


class AnimeTracker:
    def __init__(self, verwaltung, holen=None, uhr=None):
        self._verwaltung = verwaltung
        self.holen = holen or antwort_holen
        self.uhr = uhr or time.time
        self._wartend = {}   # profil -> {anbieter, verifier}
        self._map = {}       # (anbieter, titel-id) -> fremde Kennung
        self._sperre = threading.Lock()

    # --- Nutzerdaten ---------------------------------------------------------------
    @staticmethod
    def _abschnitt(daten):
        a = daten.get(SCHLUESSEL) if isinstance(daten.get(SCHLUESSEL), dict) else {}
        a.setdefault("app", {})
        a.setdefault("konten", {})
        daten[SCHLUESSEL] = a
        return a

    def _daten(self):
        v = self._verwaltung()
        if v is None:
            raise AnimeFehler("Nutzerdaten nicht verfügbar")
        return v

    def _konto_setzen(self, profil, anbieter, aenderung):
        def tun(d):
            konten = self._abschnitt(d)["konten"]
            konto = dict(konten.get(profil) or {})
            teil = dict(konto.get(anbieter) or {})
            aenderung(teil)
            if teil:
                konto[anbieter] = teil
            else:
                konto.pop(anbieter, None)
            if konto:
                konten[profil] = konto
            else:
                konten.pop(profil, None)
        self._daten().bearbeiten(tun)

    def _konten(self, daten, profil):
        return ((daten.get(SCHLUESSEL) or {}).get("konten") or {}).get(profil) or {}

    def stand(self, daten, profil):
        a = daten.get(SCHLUESSEL) if isinstance(daten.get(SCHLUESSEL), dict) else {}
        app = a.get("app") or {}
        konten = self._konten(daten, profil)
        ergebnis = {"anbieter": {}}
        for name in DIENSTE:
            konto = konten.get(name) or {}
            ergebnis["anbieter"][name] = {"name": NAMEN[name], "verbunden": bool(konto.get("access_token") or konto.get("token")),
                                          "benutzer": konto.get("benutzer", ""), "zuletzt": konto.get("zuletzt", 0),
                                          "fehler": konto.get("fehler", "")}
        ergebnis["app"] = {"mal_client_id": app.get("mal_client_id", ""), "mal_redirect": app.get("mal_redirect", ""),
                           "mal_gesetzt": bool(app.get("mal_client_secret")),
                           "kitsu_client_id": app.get("kitsu_client_id", ""),
                           "kitsu_gesetzt": bool(app.get("kitsu_client_secret"))}
        return ergebnis

    @staticmethod
    def app_setzen(daten, wunsch):
        app = AnimeTracker._abschnitt(daten)["app"]
        for feld in ("mal_client_id", "mal_client_secret", "mal_redirect", "kitsu_client_id", "kitsu_client_secret"):
            if feld in wunsch:
                wert = str(wunsch.get(feld) or "").strip()
                if wert:
                    app[feld] = wert[:500]
        return {"app": {k: (bool(v) if "secret" in k else v) for k, v in app.items()}}

    # --- Anmeldung -----------------------------------------------------------------
    def verbinden_start(self, profil, anbieter):
        if anbieter not in DIENSTE:
            raise AnimeFehler("Unbekannter Anbieter")
        if anbieter == "anilist":
            return {"art": "token", "hinweis": "Persönlichen Token von anilist.co/settings/developer eintragen."}
        app = self._app(anbieter)
        if anbieter == "mal":
            verifier = secrets.token_urlsafe(64)
            challenge = base64.urlsafe_b64encode(hashlib.sha256(verifier.encode("ascii")).digest()).decode("ascii").rstrip("=")
            redirect = app.get("mal_redirect") or "urn:ietf:wg:oauth:2.0:oob"
            url = MAL_AUTH + "/authorize?" + urlencode({"response_type": "code", "client_id": app["mal_client_id"],
                                                        "code_challenge": challenge, "code_challenge_method": "S256",
                                                        "redirect_uri": redirect})
            self._wartend[profil] = {"anbieter": "mal", "verifier": verifier, "redirect": redirect}
            return {"art": "code", "url": url}
        return {"art": "login", "hinweis": "Kitsu-Benutzer und Passwort der App."}

    def verbinden_fertig(self, profil, anbieter, daten):
        if anbieter == "anilist":
            token = str(daten.get("token") or "").strip()
            if not token:
                raise AnimeFehler("Token fehlt")
            benutzer = self._anilist_benutzer(token)
            self._konto_setzen(profil, "anilist", lambda k: (k.clear(), k.update(token=token, benutzer=benutzer, zuletzt=0, fehler="")))
            return {"verbunden": True, "benutzer": benutzer}
        if anbieter == "mal":
            app, w = self._app("mal"), self._wartend.get(profil) or {}
            if w.get("anbieter") != "mal":
                raise AnimeFehler("Erst „Mit MAL verbinden“ starten")
            code = str(daten.get("code") or "").strip()
            if not code:
                raise AnimeFehler("Code fehlt")
            form = {"grant_type": "authorization_code", "code": code, "client_id": app["mal_client_id"],
                    "code_verifier": w["verifier"], "redirect_uri": w["redirect"]}
            if app.get("mal_client_secret"):
                form["client_secret"] = app["mal_client_secret"]
            status, d = self._rufen("POST", MAL_AUTH + "/token", None, form=form)
            if status != 200 or not isinstance(d, dict) or not d.get("access_token"):
                raise AnimeFehler("MAL lehnt den Code ab (HTTP %d)" % status)
            benutzer = self._mal_benutzer(d["access_token"])
            self._wartend.pop(profil, None)
            self._konto_setzen(profil, "mal", lambda k: (k.clear(), k.update(self._tokens(d), benutzer=benutzer, zuletzt=0, fehler="")))
            return {"verbunden": True, "benutzer": benutzer}
        app = self._app("kitsu")
        form = {"grant_type": "password", "username": str(daten.get("benutzer") or ""), "password": str(daten.get("passwort") or ""),
                "client_id": app["kitsu_client_id"], "client_secret": app["kitsu_client_secret"]}
        status, d = self._rufen("POST", KITSU_TOKEN, None, form=form)
        if status != 200 or not isinstance(d, dict) or not d.get("access_token"):
            raise AnimeFehler("Kitsu lehnt die Anmeldung ab (HTTP %d)" % status)
        benutzer = self._kitsu_benutzer(d["access_token"])
        self._konto_setzen(profil, "kitsu", lambda k: (k.clear(), k.update(self._tokens(d), benutzer=benutzer, zuletzt=0, fehler="")))
        return {"verbunden": True, "benutzer": benutzer}

    def trennen(self, profil, anbieter):
        self._wartend.pop(profil, None)
        self._konto_setzen(profil, anbieter, lambda k: k.clear())
        return {"verbunden": False}

    def _app(self, anbieter):
        daten = self._daten().daten()
        app = ((daten.get(SCHLUESSEL) or {}).get("app") or {})
        if anbieter == "mal" and not (app.get("mal_client_id") and app.get("mal_client_secret")):
            raise AnimeFehler("MAL-App fehlt: Client ID und Secret eintragen")
        if anbieter == "kitsu" and not (app.get("kitsu_client_id") and app.get("kitsu_client_secret")):
            raise AnimeFehler("Kitsu-App fehlt: Client ID und Secret eintragen")
        return app

    def _tokens(self, d):
        return {"access_token": str(d.get("access_token") or ""), "refresh_token": str(d.get("refresh_token") or ""),
                "ablauf": float(d.get("created_at") or self.uhr()) + float(d.get("expires_in") or 3600)}

    # --- HTTP ----------------------------------------------------------------------
    def _rufen(self, methode, url, token, inhalt=None, form=None, json_koerper=None):
        kopf = _kopf("kitsu" if "kitsu" in url else "mal", token, json_koerper is not None)
        daten = None
        if form is not None:
            kopf["Content-Type"] = "application/x-www-form-urlencoded"
            daten = urlencode(form)
        elif json_koerper is not None:
            daten = json.dumps(json_koerper)
        try:
            status, text = self.holen(url, methode, kopf, daten)
        except NetzFehler as fehler:
            raise AnimeFehler("Dienst nicht erreichbar: %s" % fehler)
        try:
            return status, json.loads(text) if text and text.strip() else None
        except ValueError:
            raise AnimeFehler("Unerwartete Antwort (HTTP %d)" % status)

    def _anilist(self, query, token, variables=None):
        status, d = self._rufen("POST", ANILIST, token, json_koerper={"query": query, "variables": variables or {}})
        if status != 200 or not isinstance(d, dict) or d.get("errors"):
            raise AnimeFehler("AniList: %s" % ((d or {}).get("errors") or "HTTP %d" % status))
        return d.get("data") or {}

    def _anilist_benutzer(self, token):
        d = self._anilist("query { Viewer { name } }", token)
        return str(((d.get("Viewer") or {}).get("name")) or "")

    def _mal_benutzer(self, token):
        status, d = self._rufen("GET", MAL_API + "/users/@me", token)
        return str((d or {}).get("name") or "") if status == 200 else ""

    def _kitsu_benutzer(self, token):
        status, d = self._rufen("GET", KITSU + "/users?filter[self]=true", token)
        try:
            return str(((d.get("data") or [])[0].get("attributes") or {}).get("name") or "")
        except (IndexError, AttributeError):
            return ""

    # --- Abgleich ------------------------------------------------------------------
    def abgleichen(self, profil):
        daten = self._daten().daten()
        konten = self._konten(daten, profil)
        listen = self._hier(daten, profil)
        ergebnis = {}
        for anbieter in DIENSTE:
            konto = konten.get(anbieter) or {}
            if not (konto.get("access_token") or konto.get("token")):
                continue
            try:
                anzahl = self._senden(anbieter, konto, listen, daten)
                self._konto_setzen(profil, anbieter, lambda k: k.update(zuletzt=int(self.uhr()), fehler=""))
                ergebnis[anbieter] = {"ok": True, "titel": anzahl}
            except AnimeFehler as fehler:
                self._konto_setzen(profil, anbieter, lambda k, text=str(fehler): k.update(fehler=text[:300]))
                ergebnis[anbieter] = {"ok": False, "fehler": str(fehler)}
        return ergebnis

    @staticmethod
    def _hier(daten, profil):
        from . import sehen
        return sehen.lesen(daten, profil)

    def _senden(self, anbieter, konto, listen, daten):
        token = konto.get("access_token") or konto.get("token")
        anzahl = 0
        gesehen = 0
        for art in ("merkliste", "verlauf", "weiterschauen"):
            for k in listen[art]:
                if gesehen >= MAX_TITEL:
                    return anzahl
                if art == "weiterschauen" and k.get("naechste"):
                    continue
                if not str(k.get("id") or "").startswith("tt"):
                    continue
                gesehen += 1
                try:
                    if anbieter == "anilist":
                        anzahl += self._anilist_senden(token, k, art)
                    elif anbieter == "mal":
                        anzahl += self._mal_senden(token, k, art)
                    else:
                        anzahl += self._kitsu_senden(token, k, art)
                except AnimeFehler:
                    raise
                except Exception:  # noqa: BLE001 – ein Titel darf den Abgleich nicht stoppen
                    continue
        return anzahl

    def _treffer(self, anbieter, karte, token):
        """Fremde Kennung zu einem H0rSt-Titel, einmal je Sitzung gesucht."""
        schluessel = (anbieter, karte["id"])
        with self._sperre:
            if schluessel in self._map:
                return self._map[schluessel]
        titel = str(karte.get("titel") or "").strip()
        if not titel:
            return None
        kennung = None
        if anbieter == "anilist":
            d = self._anilist("query($s:String){Page(perPage:3){media(type:ANIME,search:$s){id idMal title{romaji english}}}}", token, {"s": titel})
            media = ((d.get("Page") or {}).get("media") or [])
            if media:
                kennung = media[0].get("id")
        elif anbieter == "mal":
            status, d = self._rufen("GET", MAL_API + "/anime?" + urlencode({"q": titel, "limit": 1, "fields": "id,title"}), token)
            if status == 200 and (d or {}).get("data"):
                kennung = ((d["data"][0] or {}).get("node") or {}).get("id")
        else:
            status, d = self._rufen("GET", KITSU + "/anime?" + urlencode({"filter[text]": titel, "page[limit]": 1}), token)
            if status == 200 and (d or {}).get("data"):
                kennung = (d["data"][0] or {}).get("id")
        with self._sperre:
            self._map[schluessel] = kennung
        return kennung

    @staticmethod
    def _folge(video):
        teile = str(video or "").split(":")
        if len(teile) >= 3 and teile[-1].isdigit() and teile[-2].isdigit():
            return max(0, int(teile[-1]) - 1)
        return 0

    def _anilist_senden(self, token, karte, art):
        media_id = self._treffer("anilist", karte, token)
        if not media_id:
            return 0
        status = {"merkliste": "PLANNING", "verlauf": "COMPLETED", "weiterschauen": "CURRENT"}[art]
        variablen = {"mediaId": media_id, "status": status}
        if art == "weiterschauen":
            variablen["progress"] = self._folge(karte.get("video"))
        self._anilist("mutation($mediaId:Int,$status:MediaListStatus,$progress:Int){SaveMediaListEntry(mediaId:$mediaId,status:$status,progress:$progress){id}}",
                      token, variablen)
        return 1

    def _mal_senden(self, token, karte, art):
        mal_id = self._treffer("mal", karte, token)
        if not mal_id:
            return 0
        felder = {"status": {"merkliste": "plan_to_watch", "verlauf": "completed", "weiterschauen": "watching"}[art]}
        if art == "weiterschauen":
            felder["num_watched_episodes"] = self._folge(karte.get("video"))
        self._rufen("PUT", "%s/anime/%s/my_list_status" % (MAL_API, mal_id), token, form=felder)
        return 1

    def _kitsu_senden(self, token, karte, art):
        kitsu_id = self._treffer("kitsu", karte, token)
        if not kitsu_id:
            return 0
        user_id = self._kitsu_user_id(token)
        if not user_id:
            return 0
        status, d = self._rufen("GET", KITSU + "/library-entries?" + urlencode(
            {"filter[userId]": user_id, "filter[animeId]": kitsu_id}), token)
        eintrag = ((d or {}).get("data") or [{}])[0] if status == 200 else {}
        zustand = {"merkliste": "planned", "verlauf": "completed", "weiterschauen": "current"}[art]
        attribute = {"status": zustand}
        if art == "weiterschauen":
            attribute["progress"] = self._folge(karte.get("video"))
        if eintrag.get("id"):
            koerper = {"data": {"id": eintrag["id"], "type": "libraryEntries", "attributes": attribute}}
            code, _ = self._rufen("PATCH", KITSU + "/library-entries/" + str(eintrag["id"]), token, json_koerper=koerper)
            return 1 if code < 400 else 0
        koerper = {"data": {"type": "libraryEntries", "attributes": attribute,
                            "relationships": {"user": {"data": {"type": "users", "id": user_id}},
                                              "anime": {"data": {"type": "anime", "id": str(kitsu_id)}}}}}
        code, _ = self._rufen("POST", KITSU + "/library-entries", token, json_koerper=koerper)
        return 1 if code < 400 else 0

    def _kitsu_user_id(self, token):
        status, d = self._rufen("GET", KITSU + "/users?filter[self]=true", token)
        try:
            return str(((d.get("data") or [])[0] or {}).get("id") or "")
        except (IndexError, AttributeError):
            return ""
