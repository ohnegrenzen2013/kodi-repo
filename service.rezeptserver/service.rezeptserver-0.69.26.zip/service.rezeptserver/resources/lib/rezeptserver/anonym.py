"""Tor & I2P (Bereich "Sicherheit"): Werkzeuge, laufende Dienste, Verknuepfen, Einrichtung und OnionCat-Adressen.

  * Werkzeuge: Orbot (Tor auf Android), I2P (Java-Router), i2pd, i2pd-tools, MuWire (Dateien teilen ueber I2P),
    I2PChat, OnionCat/GarliCat (IPv6 ueber Tor/I2P) und "I2P in Private Browsing" (Firefox/Brause). Je Werkzeug:
    wofuer, auf welchen Geraeten, was es braucht (Port) und die neueste Fassung von GitHub zum Herunterladen.
  * Dienste: H0rSt prueft auf seinem Rechner, welche Tor- und I2P-Ports offen sind (SOCKS 9050, HTTP-Proxy 4444,
    SOCKS 4447, SAM 7656, I2CP 7654, Konsolen 7657/7070) – daran sieht man, welches Werkzeug sofort laeuft.
  * Verknuepfen: legt die passende Verbindung an (Vorlage tor, i2p oder i2p-http) und setzt sie als Weg fuer
    .onion bzw. .i2p (sicherheit.py). Danach erreicht H0rSt .onion- und .i2p-Adressen.
  * Einrichtung: Bausteine fuer i2pd.conf/tunnels.conf, den Java-Router, torrc/Orbot und OnionCat. H0rSt selbst als
    .onion- oder .i2p-Seite gibt es nur mit Token – sonst stuende die Oberflaeche ohne Schutz im Netz.
  * Adressen: .onion (v3 und v2) und .b32.i2p in die IPv6-Adresse von OnionCat bzw. GarliCat umrechnen.
"""

import base64
import ipaddress
import json
import re
import socket
import threading
import time
import urllib.request

from .netz import USER_AGENT

# id: (Name, Port, wofuer)
DIENSTE = {
    "tor_socks": ("Tor SOCKS", 9050, "Orbot oder tor – Weg für .onion"),
    "tor_http": ("Orbot HTTP-Proxy", 8118, "Tor als HTTP-Proxy (Orbot)"),
    "i2p_http": ("I2P HTTP-Proxy", 4444, "Java-I2P und i2pd – .i2p im Browser"),
    "i2p_socks": ("I2P SOCKS", 4447, "i2pd – Weg für .i2p"),
    "sam": ("SAM", 7656, "Schnittstelle für I2PChat und andere I2P-Programme"),
    "i2cp": ("I2CP", 7654, "Schnittstelle für MuWire"),
    "konsole_java": ("I2P-Konsole (Java)", 7657, "Einstellungen des Java-Routers im Browser"),
    "konsole_i2pd": ("i2pd-Webkonsole", 7070, "Zustand von i2pd im Browser"),
}
_GH = "https://github.com/"
WERKZEUGE = [
    {"id": "orbot", "netz": "tor", "name": "Orbot", "repo": "guardianproject/orbot-android",
     "text": "Tor für Android: verschlüsselt über drei Stationen, öffnet .onion-Seiten. H0rSt nutzt Orbot als Weg "
             "(SOCKS 9050) und startet es mit einem Tipp.",
     "geraete": ["Android"], "pakete": ["org.torproject.android"], "braucht": ["tor_socks"],
     "seite": "https://orbot.app", "laden": "https://orbot.app/de/download/", "lizenz": "BSD-3-Clause"},
    {"id": "i2p", "netz": "i2p", "name": "I2P (Java-Router)", "repo": "i2p/i2p.i2p",
     "text": "Der ursprüngliche I2P-Router mit Konsole, Adressbuch, Torrent (I2PSnark) und Mail. Bringt HTTP-Proxy 4444, "
             "SAM und I2CP mit – damit laufen MuWire, I2PChat und die Browser-Erweiterung.",
     "geraete": ["Windows", "macOS", "Linux", "Android"], "pakete": ["net.i2p.android", "net.i2p.android.router"],
     "braucht": ["i2p_http", "konsole_java"], "konsole": "http://127.0.0.1:7657/",
     "seite": "https://geti2p.net/de/", "laden": "https://geti2p.net/de/download", "lizenz": "verschiedene (frei)"},
    {"id": "i2pd", "netz": "i2p", "name": "i2pd (PurpleI2P)", "repo": "PurpleI2P/i2pd",
     "text": "Schlanker I2P-Router in C++, ideal für Handy und Pi. SOCKS 4447 und HTTP-Proxy 4444 sind an; SAM und "
             "I2CP für I2PChat und MuWire schaltet die Einrichtung unten frei.",
     "geraete": ["Android", "Linux", "Windows", "macOS"], "pakete": ["org.purplei2p.i2pd"],
     "braucht": ["i2p_socks", "konsole_i2pd"], "konsole": "http://127.0.0.1:7070/",
     "seite": "https://i2pd.website", "laden": "https://f-droid.org/packages/org.purplei2p.i2pd/", "lizenz": "BSD-3-Clause"},
    {"id": "i2pd_tools", "netz": "i2p", "name": "i2pd-tools", "repo": "PurpleI2P/i2pd-tools",
     "text": "Werkzeuge zum Einrichten: keygen (Schlüssel für eine eigene .i2p-Seite), vain (Wunschadresse), regaddr "
             "(Adresse im Adressbuch anmelden), keyinfo (Adresse eines Schlüssels zeigen), b33address, routerinfo.",
     "geraete": ["Linux", "Windows"], "befehle": ["./keygen h0rst.dat", "./vain h0rst --threads 4", "./keyinfo h0rst.dat",
                                                  "./regaddr h0rst.dat meinname.i2p"],
     "seite": _GH + "PurpleI2P/i2pd-tools", "lizenz": "BSD-3-Clause"},
    {"id": "muwire", "netz": "i2p", "name": "MuWire", "repo": "zlatinb/muwire",
     "text": "Dateien anonym teilen und suchen – wie eMule, aber über I2P. Verbindet sich über I2CP (7654) mit dem "
             "Java-Router oder i2pd; den Rechner kennt dabei niemand.",
     "geraete": ["Windows", "macOS", "Linux"], "braucht": ["i2cp"], "seite": _GH + "zlatinb/muwire",
     "lizenz": "GPL-3.0"},
    {"id": "i2pchat", "netz": "i2p", "name": "I2PChat", "repo": "i2pchat/i2pchat",
     "text": "Chat Ende-zu-Ende verschlüsselt über I2P, ohne Server und ohne Telefonnummer; auch Dateien. Braucht SAM "
             "(7656) am Router.",
     "geraete": ["Windows", "Linux"], "braucht": ["sam"], "seite": _GH + "i2pchat/i2pchat", "lizenz": "GPL-2.0"},
    {"id": "onioncat", "netz": "beide", "name": "OnionCat / GarliCat", "repo": "rahra/onioncat",
     "text": "VPN über Tor oder I2P: jeder Teilnehmer bekommt eine IPv6-Adresse aus seiner .onion- bzw. .b32.i2p-Adresse, "
             "dann laufen beliebige Programme (SSH, Spiele, Dateifreigaben) anonym. Rechner unten.",
     "geraete": ["Linux", "macOS", "Windows"], "seite": "https://www.onioncat.org", "lizenz": "GPL-3.0"},
    {"id": "i2pipb", "netz": "i2p", "name": "I2P in Private Browsing", "repo": "eyedeekay/I2P-in-Private-Browsing-Mode-Firefox",
     "text": "Firefox-Erweiterung: .i2p-Seiten in eigenen, abgeschotteten Tabs über den I2P-HTTP-Proxy (4444), mit Zugriff "
             "auf die Router-Konsole. Steht in der Brause unter den vorgeschlagenen Erweiterungen.",
     "geraete": ["Firefox", "Brause"], "braucht": ["i2p_http"],
     "seite": "https://addons.mozilla.org/de/firefox/addon/i2p-in-private-browsing/", "lizenz": "MIT"},
]
NACH_ID = {w["id"]: w for w in WERKZEUGE}
CACHE = 6 * 3600
# OnionCat-Netze: Tor fd87:d87e:eb43::/48, I2P (GarliCat) fd60:db4d:ddb5::/48 – dahinter 80 Bit der Adresse
PRAEFIX = {"tor": bytes.fromhex("fd87d87eeb43"), "i2p": bytes.fromhex("fd60db4dddb5")}
_B32 = re.compile(r"^[a-z2-7]+$")


class AnonymFehler(ValueError):
    pass


# --- Dienste ------------------------------------------------------------------------------------
def _offen(port, host="127.0.0.1", zeit=0.4):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(zeit)
    try:
        return s.connect_ex((host, port)) == 0
    except OSError:
        return False
    finally:
        s.close()


def dienste(pruefen=None):
    """{id: {name, port, text, offen}} – alle Ports gleichzeitig, damit es schnell geht."""
    pruefen = pruefen or _offen
    ergebnis = {}

    def eins(did, port):
        ergebnis[did] = pruefen(port)
    faeden = [threading.Thread(target=eins, args=(did, d[1]), daemon=True) for did, d in DIENSTE.items()]
    for f in faeden:
        f.start()
    for f in faeden:
        f.join(2)
    return {did: {"name": d[0], "port": d[1], "text": d[2], "offen": bool(ergebnis.get(did))} for did, d in DIENSTE.items()}


def zustand(daten=None, pruefen=None):
    """Werkzeuge mit "bereit" (alle benoetigten Dienste offen), Dienste, und welche Wege gesetzt sind."""
    d = dienste(pruefen)
    werkzeuge = []
    for w in WERKZEUGE:
        braucht = [dict(d[b], id=b) for b in w.get("braucht", [])]
        werkzeuge.append(dict(w, braucht=braucht, bereit=bool(braucht) and all(b["offen"] for b in braucht)))
    e = ((daten or {}).get("sicherheit") or {})
    eigene = (daten or {}).get("anbieter") or {}
    name = lambda k: (eigene.get(e.get(k)) or {}).get("name", "") if e.get(k) else ""
    return {"werkzeuge": werkzeuge, "dienste": d, "wege": {"onion": name("onion"), "i2p": name("i2p"), "weg": name("weg")},
            "i2p_router": "i2pd" if d["i2p_socks"]["offen"] else ("java" if d["i2p_http"]["offen"] else "")}


# --- Releases -------------------------------------------------------------------------------------
def _art(name):
    n = name.lower()
    if n.endswith(".apk"):
        return "Android"
    if n.endswith((".exe", ".msi")) or "win" in n:
        return "Windows"
    if n.endswith((".dmg", ".pkg")):
        return "macOS"
    if n.endswith((".deb", ".rpm", ".appimage")):
        return "Linux"
    if n.endswith(".jar"):
        return "Java (alle Systeme)"
    if n.endswith((".tar.gz", ".tar.bz2", ".tar.xz", ".zip")):
        return "Quellcode/Archiv"
    return "Sonstige"


class Releases:
    """Neueste Fassung je Werkzeug von GitHub, 6 Stunden zwischengespeichert."""

    def __init__(self, holen=None, uhr=time.time):
        self.holen = holen
        self.uhr = uhr
        self._stand = {}
        self._sperre = threading.Lock()

    def _laden(self, url):
        if self.holen:
            return self.holen(url)
        anfrage = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Accept": "application/vnd.github+json"})
        with urllib.request.urlopen(anfrage, timeout=15) as a:
            return a.read(1024 * 1024).decode("utf-8")

    def neueste(self, wid):
        w = NACH_ID.get(wid)
        if not w:
            raise AnonymFehler("Unbekanntes Werkzeug")
        with self._sperre:
            zeit, daten = self._stand.get(wid, (0, None))
        if daten and self.uhr() - zeit < CACHE:
            return daten
        seite = _GH + w["repo"] + "/releases"
        try:
            r = json.loads(self._laden("https://api.github.com/repos/%s/releases/latest" % w["repo"]))
            dateien = [{"name": a.get("name", ""), "art": _art(a.get("name", "")), "url": a.get("browser_download_url", ""),
                        "groesse": a.get("size", 0)} for a in r.get("assets") or []
                       if not a.get("name", "").endswith((".asc", ".sig", ".sha256", ".txt", ".md"))]
            daten = {"version": r.get("tag_name", ""), "datum": str(r.get("published_at", ""))[:10],
                     "seite": r.get("html_url") or seite, "dateien": dateien[:40], "fehler": ""}
        except Exception as fehler:  # kein Release (nur Quellcode), Netz, Grenze der GitHub-API
            keins = "404" in str(fehler)
            daten = {"version": "", "datum": "", "seite": _GH + w["repo"] if keins else seite, "dateien": [],
                     "fehler": "Keine fertigen Dateien – nur Quellcode auf GitHub" if keins else str(fehler)[:200]}
        with self._sperre:
            self._stand[wid] = (self.uhr(), daten)
        return daten


# --- Einrichtung ----------------------------------------------------------------------------------
def _port(port):
    try:
        port = int(port)
    except (TypeError, ValueError):
        raise AnonymFehler("Port fehlt")
    if not 1 <= port <= 65535:
        raise AnonymFehler("Port 1–65535")
    return port


def konfig(art, port=7000, token=False):
    """Bausteine zum Einrichten: {titel, teile: [{datei, text}], hinweis}."""
    port = _port(port)
    seite_noetig = art in ("i2pd_seite", "java_seite", "tor_seite")
    if seite_noetig and not token:
        raise AnonymFehler("H0rSt läuft ohne Token – als .onion- oder .i2p-Seite stünde die Oberfläche für jeden offen. "
                           "Erst H0rSt im Heimnetz-Modus mit Token starten.")
    if art == "i2pd":
        return {"titel": "i2pd: SAM und I2CP einschalten (für I2PChat und MuWire)", "teile": [
            {"datei": "i2pd.conf", "text": "[httpproxy]\nenabled = true\nport = 4444\n\n[socksproxy]\nenabled = true\nport = 4447\n\n"
                                          "[sam]\nenabled = true\naddress = 127.0.0.1\nport = 7656\n\n"
                                          "[i2cp]\nenabled = true\naddress = 127.0.0.1\nport = 7654\n"}],
            "hinweis": "In der App PurpleI2P: Einstellungen → i2pd.conf bearbeiten; auf Linux /etc/i2pd/i2pd.conf. "
                       "Danach i2pd neu starten."}
    if art == "i2pd_seite":
        return {"titel": "H0rSt als .i2p-Seite (i2pd)", "teile": [
            {"datei": "tunnels.conf", "text": "[h0rst]\ntype = http\nhost = 127.0.0.1\nport = %d\nkeys = h0rst.dat\n" % port},
            {"datei": "i2pd-tools (optional)", "text": "./keygen h0rst.dat        # eigener Schlüssel\n"
                                                     "./vain h0rst             # oder: Wunschanfang der Adresse\n"
                                                     "./keyinfo h0rst.dat      # zeigt die .b32.i2p-Adresse"}],
            "hinweis": "h0rst.dat in den Datenordner von i2pd legen (ohne Datei erzeugt i2pd selbst einen Schlüssel). Die "
                       "Adresse steht danach in der i2pd-Webkonsole unter „I2P tunnels“. Aufruf mit /<token>/ dahinter."}
    if art == "java":
        return {"titel": "Java-I2P: SAM einschalten (für I2PChat)", "teile": [
            {"datei": "Router-Konsole", "text": "http://127.0.0.1:7657/configclients\n→ „SAM application bridge“ starten und "
                                               "„beim Start ausführen“ anhaken"}],
            "hinweis": "HTTP-Proxy (4444) und I2CP (7654, für MuWire) sind beim Java-Router schon an."}
    if art == "java_seite":
        return {"titel": "H0rSt als .i2p-Seite (Java-I2P)", "teile": [
            {"datei": "Router-Konsole", "text": "http://127.0.0.1:7657/i2ptunnelmgr\n→ Neuer Server-Tunnel: HTTP\n"
                                               "   Ziel: 127.0.0.1  Port: %d\n   „Automatisch starten“ anhaken" % port}],
            "hinweis": "Die .b32.i2p-Adresse steht danach im Tunnel-Manager. Aufruf mit /<token>/ dahinter."}
    if art == "tor_seite":
        return {"titel": "H0rSt als .onion-Seite (Tor/Orbot)", "teile": [
            {"datei": "torrc", "text": "HiddenServiceDir /var/lib/tor/h0rst/\nHiddenServicePort 80 127.0.0.1:%d\n" % port},
            {"datei": "Orbot", "text": "Orbot → Mehr (More) → Onion-Dienste (Hosted Services) → ＋\n   Name: H0rSt   Lokaler Port: %d   Onion-Port: 80" % port}],
            "hinweis": "Die Adresse steht danach in /var/lib/tor/h0rst/hostname bzw. in Orbot. Aufruf mit /<token>/ dahinter."}
    if art == "onioncat":
        return {"titel": "OnionCat (Tor) und GarliCat (I2P)", "teile": [
            {"datei": "torrc", "text": "HiddenServiceDir /var/lib/tor/onioncat/\nHiddenServicePort 8060 127.0.0.1:8060\n"},
            {"datei": "Tor: starten", "text": "ocat -H <letzte 16 Zeichen der eigenen .onion>\n"
                                             "# Gegenstellen in /etc/hosts:  <IPv6>  <volle .onion-Adresse>"},
            {"datei": "tunnels.conf (i2pd)", "text": "[garlicat-in]\ntype = server\nhost = 127.0.0.1\nport = 8060\ninport = 8060\n"
                                                    "keys = garlicat.dat\n\n[garlicat-socks]\ntype = socks\naddress = 127.0.0.1\nport = 9051\n"},
            {"datei": "I2P: starten", "text": "ocat -I <erste 16 Zeichen der eigenen .b32.i2p>"}],
            "hinweis": "Die IPv6-Adressen rechnet der Rechner unten aus. v3-Onions passen nicht ganz in IPv6 – deshalb die "
                       "hosts-Einträge (siehe OnionCat-Anleitung „Onioncat and V3 Hidden Services“)."}
    raise AnonymFehler("art: i2pd, i2pd_seite, java, java_seite, tor_seite oder onioncat")


# --- Adressen -------------------------------------------------------------------------------------
def adresse(text):
    """.onion (v3/v2) oder .b32.i2p -> {art, netz, kennung, ipv6, befehl, hosts}."""
    a = str(text or "").strip().lower()
    a = re.sub(r"^[a-z]+://", "", a).split("/", 1)[0].split(":", 1)[0]
    if a.endswith(".onion"):
        name = a[:-6].rsplit(".", 1)[-1]  # Unteradressen weg
        if not _B32.match(name) or len(name) not in (16, 56):
            raise AnonymFehler("Keine gültige .onion-Adresse (16 oder 56 Zeichen a–z, 2–7)")
        netz, kennung = "tor", name[-16:]
        art = "Onion v3" if len(name) == 56 else "Onion v2 (veraltet)"
    elif a.endswith(".b32.i2p"):
        name = a[:-8]
        if not _B32.match(name) or len(name) < 52:
            raise AnonymFehler("Keine gültige .b32.i2p-Adresse (52 Zeichen a–z, 2–7)")
        netz, kennung, art = "i2p", name[:16], "I2P (b32)"
    else:
        raise AnonymFehler("Adresse mit .onion oder .b32.i2p am Ende")
    ipv6 = str(ipaddress.IPv6Address(PRAEFIX[netz] + base64.b32decode(kennung.upper())))
    voll = name + (".onion" if netz == "tor" else ".b32.i2p")
    v3 = netz == "tor" and len(name) == 56
    return {"art": art, "netz": netz, "kennung": kennung, "ipv6": ipv6, "adresse": voll,
            "befehl": ("ocat -I " if netz == "i2p" else ("ocat -H " if v3 else "ocat ")) + kennung,
            "hosts": "%s %s" % (ipv6, voll) if v3 or netz == "i2p" else ""}
