"""App-Store: Kennungen zerlegen und App-Details samt Versionen laden."""

import re
from urllib.parse import quote, urljoin, urlsplit

from .appstore_grund import (
    CODEBERG,
    FDROID,
    GITHUB,
    GITLAB,
    HOSTS,
    IZZY,
    QUELLEN,
    StoreFehler,
    _PAKET,
    _REPO,
    _gitlab_pfad_gueltig,
    _text,
    abi_von,
)
from .netz import NetzFehler


class AppMixin:
    @staticmethod
    def _zerlegen(app_id):
        quelle, _, rest = str(app_id or "").partition(":")
        if quelle in ("fdroid", "izzy") and _PAKET.match(rest):
            return quelle, rest
        if quelle in ("github", "codeberg") and _REPO.match(rest):
            return quelle, rest
        if quelle == "gitlab" and _gitlab_pfad_gueltig(rest):
            return quelle, rest
        if quelle == "apkmb" and rest:
            # slug or direct id
            rest = rest.strip().lower()
            rest = re.sub(r"[^a-z0-9\-_.]+", "-", rest).strip("-_.")[:60]
            if not rest:
                raise StoreFehler("Unbekannte App")
            return quelle, rest
        raise StoreFehler("Unbekannte App")

    def app(self, app_id):
        """{id, quelle, name, paket?, seite, versionen: [{version, code?, datum, apks: [{name, url, groesse, abi}]}], vertrauen?}"""
        quelle, kennung = self._zerlegen(app_id)
        if quelle in ("fdroid", "izzy"):
            basis = FDROID if quelle == "fdroid" else IZZY
            d = self._json("%s/api/v1/packages/%s" % (basis, quote(kennung)), fehlt_ok=True)
            if not d:
                raise StoreFehler("Gibt es bei %s nicht" % QUELLEN[quelle])
            empfohlen = int(d.get("suggestedVersionCode") or 0)
            versionen, gesehen = [], set()
            for p in d.get("packages") or []:
                code = str(p.get("versionCode") or "") if isinstance(p, dict) else ""
                if not code.isdigit() or code in gesehen:  # F-Droid nennt manche Fassungen doppelt
                    continue
                gesehen.add(code)
                versionen.append(
                    {
                        "version": str(p.get("versionName") or code),
                        "code": int(code),
                        "empfohlen": int(code) == empfohlen,
                        "apks": [
                            {
                                "name": "%s_%s.apk" % (kennung, code),
                                "abi": "",
                                "url": "%s/repo/%s_%s.apk" % (basis, kennung, code),
                            }
                        ],
                    }
                )
            info = self._izzy_index().get(kennung, {}) if quelle == "izzy" else {}
            return {
                "id": app_id,
                "quelle": quelle,
                "paket": kennung,
                "name": info.get("name") or kennung,
                "versionen": versionen[:15],
                "seite": "%s/packages/%s/" % (FDROID, kennung)
                if quelle == "fdroid"
                else "https://apt.izzysoft.de/fdroid/index/apk/" + kennung,
            }
        if quelle == "github":
            repo = self._json("%s/repos/%s" % (GITHUB, kennung), self._github_kopf())
            releases = self._json("%s/repos/%s/releases?per_page=15" % (GITHUB, kennung), self._github_kopf()) or []
        elif quelle == "codeberg":
            repo = self._json("%s/repos/%s" % (CODEBERG, kennung))
            releases = self._json("%s/repos/%s/releases?limit=15" % (CODEBERG, kennung)) or []
        elif quelle == "gitlab":
            pfad = quote(kennung, safe="")
            repo = self._json("%s/projects/%s?license=true" % (GITLAB, pfad))
            releases = self._json("%s/projects/%s/releases?per_page=15" % (GITLAB, pfad)) or []
        elif quelle == "apkmb":
            return self._apkmb_app(kennung, app_id)
        else:
            repo = None
            releases = []
        versionen = []
        for rel in releases if isinstance(releases, list) else []:
            if not isinstance(rel, dict) or rel.get("draft"):
                continue
            apks = self._release_apks(quelle, rel)
            if apks:
                versionen.append(
                    {
                        "version": str(rel.get("tag_name") or rel.get("name") or ""),
                        "datum": str((rel.get("published_at") or rel.get("released_at")) or "")[:10],
                        "vorab": bool(rel.get("prerelease") or rel.get("upcoming_release")),
                        "apks": apks,
                        "notizen": _text(rel.get("body") or rel.get("description"), 600),
                    }
                )
        if quelle == "gitlab":
            app = self._gitlab_projekt(dict(repo or {}, release_counter=len(versionen)))
        else:
            app = self._repo_app(quelle, dict(repo or {}, release_counter=len(versionen)))
        app["versionen"] = versionen
        return app

    def _release_apks(self, quelle, rel):
        """APK-Eintraege eines Releases - je Quelle anderes Datenformat (GitLab hat "assets.links",
        kein Groessenfeld; GitHub/Codeberg haben "assets" direkt, mit "size")."""
        if quelle == "gitlab":
            apks = []
            for lnk in ((rel.get("assets") or {}).get("links") or []):
                if not isinstance(lnk, dict):
                    continue
                url = str(lnk.get("url") or "")
                dateiname = str(lnk.get("name") or "") or url.rsplit("/", 1)[-1]
                if not dateiname.lower().endswith(".apk"):
                    continue
                if (urlsplit(url).hostname or "") not in HOSTS["gitlab"]:
                    continue  # nur gitlab.com-gehostete Assets, siehe HOSTS-Kommentar
                apks.append({"name": dateiname, "url": url, "groesse": 0, "abi": abi_von(dateiname)})
            return apks
        return [
            {
                "name": str(a.get("name")),
                "url": str(a.get("browser_download_url") or ""),
                "groesse": int(a.get("size") or 0),
                "abi": abi_von(str(a.get("name"))),
            }
            for a in rel.get("assets") or []
            if isinstance(a, dict) and str(a.get("name", "")).lower().endswith(".apk")
        ]

    def eigener_repo_app(self, repo):
        """Fuer ein eingetragenes eigenes Repository (appstore.eigene_repos): bei github/gitlab/codeberg
        wie app() fuer genau dieses eine Projekt; bei fdroid_katalog die Liste der Apps im Repo-Index
        (gleiches index-v1.json-Format wie _izzy_index(), hier gegen eine beliebige, admin-eingetragene
        Basis-Adresse statt der festen IZZY-Konstante - deshalb ueber _json_oeffentlich() mit echter
        SSRF-Pruefung, nicht _json())."""
        typ, url = repo.get("typ"), str(repo.get("url") or "")
        if typ in ("github", "gitlab", "codeberg"):
            return self.app("%s:%s" % (typ, urlsplit(url).path.strip("/")))
        if typ != "fdroid_katalog":
            raise StoreFehler("Unbekannter Repo-Typ")
        basis = url.rstrip("/")
        roh = self._json_oeffentlich(basis + "/index-v1.json")
        apps = []
        for a in (roh or {}).get("apps") or []:
            if not isinstance(a, dict) or not a.get("packageName"):
                continue
            lokal = a.get("localized") if isinstance(a.get("localized"), dict) else {}
            sprachen = [lokal[k] for k in ("de-DE", "de", "en-US", "en") if isinstance(lokal.get(k), dict)] + [
                v for v in lokal.values() if isinstance(v, dict)
            ]

            def feld(name):  # je Sprache stehen nicht alle Felder; das erste vorhandene zaehlt
                return a.get(name) or next((x[name] for x in sprachen if x.get(name)), "")

            apps.append(
                {
                    "id": "fdroid_katalog:%s:%s" % (repo.get("id"), a["packageName"]),
                    "quelle": "fdroid_katalog",
                    "paket": a["packageName"],
                    "name": _text(feld("name") or a["packageName"], 80),
                    "beschreibung": _text(feld("summary"), 200),
                    "symbol": "%s/icons-640/%s" % (basis, a["icon"]) if a.get("icon") else "",
                }
            )
            if len(apps) >= 200:
                break
        return {"id": repo.get("id"), "name": repo.get("name") or "F-Droid-Katalog", "typ": "fdroid_katalog",
                "seite": basis, "apps": apps}

    def _apkmb_app(self, slug, app_id):
        try:
            status, html = self.holen("https://apkmb.com/" + slug, "GET", {"Accept": "text/html"}, None)
        except NetzFehler as fehler:
            raise StoreFehler(str(fehler)[:200])
        if status >= 400:
            raise StoreFehler("apkmb.com antwortet mit HTTP %d" % status)
        from html import unescape

        content = html or ""
        titel = slug.replace("-", " ").title()
        # Try to extract title from h1
        m = re.search(r"<h1[^>]*>(.*?)</h1>", content, re.S)
        if m:
            titel = unescape(re.sub(r"<[^>]+>", " ", m.group(1))).strip()
        # Find APK download links - apkmb often links to app.apkmb.com or has direct .apk links
        versionen = []
        apks_found = []
        # Look for links ending in .apk
        for m in re.finditer(r'href="([^"]+\.apk[^"]*)"', content, re.I):
            url = m.group(1)
            # Make absolute if relative
            if url.startswith("//"):
                url = "https:" + url
            elif url.startswith("/"):
                url = "https://apkmb.com" + url
            elif not url.startswith("https://"):
                url = urljoin("https://apkmb.com/" + slug, url)
            teile = urlsplit(url)
            if teile.scheme != "https" or (teile.hostname or "") not in HOSTS["apkmb"]:
                continue  # fremde Server werden bei "laden" ohnehin abgelehnt
            name = teile.path.split("/")[-1] or "app.apk"
            apks_found.append({"name": name, "url": url, "groesse": 0, "abi": abi_von(name)})
        # Also look for download buttons pointing to app.apkmb.com
        if not apks_found:
            for m in re.finditer(r'href="(https://app\.apkmb\.com/[^"]+)"', content):
                url = m.group(1)
                teile = urlsplit(url)
                name = teile.path.split("/")[-1] or url.split("/")[-1]
                apks_found.append({"name": name, "url": url, "groesse": 0, "abi": abi_von(name)})
        # Group by version if multiple
        if apks_found:
            # If multiple apks for same version (TV vs Mobile), keep both
            # just add as single version with all apks
            first_name = apks_found[0]["name"]
            vm = re.findall(r"v?(\d+\.\d+(?:\.\d+)?)", first_name)
            vstr = vm[0] if vm else "1.0"
            versionen.append({"version": vstr, "datum": "", "apks": apks_found[:10], "vorab": False})
        else:
            # Try to construct from Blu Movies example pattern if slug contains known names
            # but we need to be flexible
            versionen.append({"version": "latest", "datum": "", "apks": [], "vorab": False})
        return {
            "id": app_id,
            "quelle": "apkmb",
            "name": _text(titel, 80),
            "paket": "",
            "versionen": versionen,
            "seite": "https://apkmb.com/" + slug,
        }
