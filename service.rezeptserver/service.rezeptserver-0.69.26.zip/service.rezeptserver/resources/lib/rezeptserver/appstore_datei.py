"""App-Store: APK laden, aufraeumen, ausliefern und Updates ermitteln."""

import os
import re
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import quote, urlsplit

from . import ereignisse
from .appstore_grund import (
    FDROID,
    HINTERGRUND_ABSTAND,
    HOSTS,
    IZZY,
    QUELLEN,
    SCHLUESSEL,
    StoreFehler,
    _PAKET,
    eigene_repos,
    version_neuer,
)


class DateiMixin:
    # --- Laden -------------------------------------------------------------------------------------------------------
    def laden(self, app_id, url, name):
        """APK nach <Datenordner>/appstore laden; gibt {pfad, name, groesse} zurueck."""
        quelle, _ = self._zerlegen(app_id)
        teile = urlsplit(str(url or ""))
        if teile.scheme != "https" or (teile.hostname or "") not in HOSTS[quelle]:
            raise StoreFehler("Diese Adresse gehört nicht zu %s" % QUELLEN[quelle])
        os.makedirs(self.ordner, exist_ok=True)
        datei = re.sub(r"[^\w.-]", "_", str(name or "app.apk"))[:120]
        if not datei.lower().endswith(".apk"):
            datei += ".apk"
        ziel = os.path.join(self.ordner, datei)
        roh = ziel + ".neu"
        try:
            endziel = self.laden_roh(url, roh)
            if endziel and (urlsplit(endziel).hostname or "") not in HOSTS[quelle]:
                raise StoreFehler("Download wurde auf einen fremden Server umgeleitet")
            with open(roh, "rb") as f:
                if f.read(2) != b"PK":
                    raise StoreFehler("Download ist keine APK")
            os.replace(roh, ziel)
        except BaseException:
            try:
                os.remove(roh)
            except OSError:
                pass
            raise
        self._aufraeumen(behalten=datei)
        return {"pfad": ziel, "name": datei, "groesse": os.path.getsize(ziel)}

    def _aufraeumen(self, behalten="", anzahl=5):
        """Nur die letzten APKs behalten (sie sind gross)."""
        try:
            apks = sorted(
                (n for n in os.listdir(self.ordner) if n.lower().endswith(".apk") and n != behalten),
                key=lambda n: os.path.getmtime(os.path.join(self.ordner, n)),
                reverse=True,
            )
            for alt in apks[anzahl - 1 :]:
                os.remove(os.path.join(self.ordner, alt))
        except OSError:
            pass

    def datei(self, name):
        pfad = os.path.join(self.ordner, os.path.basename(str(name or "")))
        if not pfad.lower().endswith(".apk") or not os.path.isfile(pfad):
            raise StoreFehler("Datei gibt es nicht")
        return pfad

    # --- Updates -----------------------------------------------------------------------------------------------------
    def updates(self, installiert, daten=None):
        """installiert: {paket: {code, version, name}}. Gibt [{paket, name, quelle, id, alt, neu}] zurueck.
        einstellungen_je_app (appstore.aendern()): ausgeschlossene Pakete werden nie gemeldet; eine
        uebersprungene Version wird nicht erneut gemeldet (eine noch neuere schon - echter Versions-
        vergleich, kein pauschales Stummschalten); quelle_fest beschraenkt die Pruefung auf eine Quelle,
        sonst entscheidet bevorzugte_quelle bei mehreren Treffern (Trust-Score bleibt Tie-Breaker ohne
        Praeferenz, wie bei der Suche)."""
        if not isinstance(installiert, dict):
            raise StoreFehler("Liste der installierten Apps erwartet")
        je_app_alle = (
            (((daten or {}).get(SCHLUESSEL) or {}).get("einstellungen_je_app") or {})
            if isinstance((daten or {}).get(SCHLUESSEL), dict)
            else {}
        )
        pakete = [
            p for p in list(installiert)[:400]
            if _PAKET.match(str(p)) and not (je_app_alle.get(p) or {}).get("ausgeschlossen")
        ]
        beobachtet = (
            (((daten or {}).get(SCHLUESSEL) or {}).get("beobachtet") or {})
            if isinstance((daten or {}).get(SCHLUESSEL), dict)
            else {}
        )
        try:
            izzy = self._izzy_index()
        except StoreFehler:
            izzy = {}

        def pruefen(paket):
            info = installiert.get(paket)
            info = info if isinstance(info, dict) else {}
            je_app = je_app_alle.get(paket) or {}
            try:
                code = int(info.get("code") or 0)
            except (TypeError, ValueError):
                code = 0
            if beobachtet.get(paket):
                try:
                    a = self.app(beobachtet[paket])
                    neu = next((v for v in a["versionen"] if not v.get("vorab")), None)
                    if (
                        neu
                        and info.get("version")
                        and version_neuer(neu["version"], info["version"])
                        and neu["version"] != je_app.get("uebersprungene_version")
                    ):
                        return {
                            "paket": paket,
                            "name": a["name"],
                            "quelle": a["quelle"],
                            "id": a["id"],
                            "alt": info.get("version"),
                            "neu": neu["version"],
                        }
                except StoreFehler:
                    pass
                return None
            quellen = [
                (q, b) for q, b in (("fdroid", FDROID), ("izzy", IZZY))
                if not je_app.get("quelle_fest") or je_app["quelle_fest"] == q
            ]
            treffer = []
            for quelle, basis in quellen:
                if quelle == "izzy" and paket not in izzy:
                    continue
                try:
                    d = self._json("%s/api/v1/packages/%s" % (basis, quote(paket)), fehlt_ok=True)
                except StoreFehler:
                    continue
                if not d:
                    continue
                empfohlen = int(d.get("suggestedVersionCode") or 0)
                if not (code and empfohlen > code):
                    continue
                neu = next(
                    (
                        str(p.get("versionName"))
                        for p in d.get("packages") or []
                        if int(p.get("versionCode") or 0) == empfohlen
                    ),
                    str(empfohlen),
                )
                if neu == je_app.get("uebersprungene_version"):
                    continue
                treffer.append(
                    {
                        "paket": paket,
                        "name": info.get("name") or paket,
                        "quelle": quelle,
                        "id": "%s:%s" % (quelle, paket),
                        "alt": info.get("version") or str(code),
                        "neu": neu,
                    }
                )
            if not treffer:
                return None
            bevorzugt = next((t for t in treffer if t["quelle"] == je_app.get("bevorzugte_quelle")), None)
            return bevorzugt or treffer[0]

        with ThreadPoolExecutor(max_workers=8) as pool:
            return [u for u in pool.map(pruefen, pakete) if u]

    # --- Hintergrund-Pruefung ----------------------------------------------------------------------------------------
    def hintergrund_faellig(self):
        """Muster komplettbackup_lauf.py::faellig(): Zeitstempel-Vergleich + Doppellauf-Schutz."""
        s = self._einstellungen()
        return self.uhr() - float(s.get("hintergrund_zeit") or 0) > HINTERGRUND_ABSTAND and not self._hintergrund_laeuft

    def hintergrund_pruefen(self):
        """Prueft den zuletzt von der App gemeldeten Installations-Schnappschuss (letzte_installierte_liste)
        gegen die Quellen, zusaetzlich beobachtete Projekte, deren letzte bekannte Version aus dem Verlauf
        stammt, falls sie (noch) nicht im Schnappschuss stehen - nie erfundene Daten als Ausgangspunkt.
        Ergebnis wird zwischengespeichert (fuer die Oberflaeche) und ueber ereignisse.melden() gemeldet."""
        with self._hintergrund_sperre:
            if self._hintergrund_laeuft:
                return []
            self._hintergrund_laeuft = True
        try:
            v = self._verwaltung()
            if v is None:
                return []
            daten = v.daten()
            s = daten.get(SCHLUESSEL) if isinstance(daten.get(SCHLUESSEL), dict) else {}
            installiert = dict(s.get("letzte_installierte_liste") or {})
            for paket, _app_id in (s.get("beobachtet") or {}).items():
                if not _PAKET.match(str(paket)) or paket in installiert:
                    continue
                letzter = next(
                    (e for e in s.get("verlauf") or [] if isinstance(e, dict) and e.get("paket") == paket and e.get("version")),
                    None,
                )
                if letzter:
                    installiert[paket] = {"code": 0, "version": letzter["version"], "name": letzter.get("name") or paket}
            ergebnis = self.updates(installiert, daten) if installiert else []
            # Eigene Repositories (V2/V3): der Server kennt ihren aktuellen Stand immer direkt, kein
            # Schnappschuss noetig - gemeldet wird nur eine neue Version seit dem letzten Hintergrund-Lauf
            # (beim allerersten Sehen eines Repos wird nur die Basis gemerkt, nie sofort "neu" behauptet).
            bekannte_versionen = dict(s.get("eigene_repos_versionen") or {})
            neue_versionen = {}
            for repo in eigene_repos(daten):
                if not repo.get("aktiv", True) or repo.get("typ") == "fdroid_katalog":
                    continue  # ein Katalog enthaelt viele Apps, keine sinnvolle einzelne "neue Version"
                try:
                    a = self.eigener_repo_app(repo)
                except StoreFehler:
                    continue
                neu = next((x for x in a.get("versionen") or [] if not x.get("vorab")), None)
                if not neu:
                    continue
                neue_versionen[repo["id"]] = neu["version"]
                alt = bekannte_versionen.get(repo["id"])
                if alt and version_neuer(neu["version"], alt):
                    ergebnis.append({"paket": "", "name": a.get("name"), "quelle": repo["typ"],
                                      "id": repo["id"], "alt": alt, "neu": neu["version"]})
            v.bearbeiten(lambda d: self._hintergrund_setzen(d, ergebnis, neue_versionen))
            if ergebnis:
                ereignisse.melden("update", "%d App-Update(s) verfügbar" % len(ergebnis), True)
            return ergebnis
        finally:
            with self._hintergrund_sperre:
                self._hintergrund_laeuft = False

    def _hintergrund_setzen(self, daten, ergebnis, neue_versionen):
        s = dict(daten.get(SCHLUESSEL) or {})
        s["hintergrund_zeit"] = int(self.uhr())
        s["hintergrund_ergebnis"] = ergebnis
        s["eigene_repos_versionen"] = dict(s.get("eigene_repos_versionen") or {}, **neue_versionen)
        daten[SCHLUESSEL] = s
        return ergebnis
