"""App-Store: Konstanten, Vertrauenswert, Versionsvergleich und roher Dateidownload."""

import hashlib
import math
import re
import time
import urllib.error
import urllib.request
from urllib.parse import urlsplit

from .netz import USER_AGENT

SCHLUESSEL = "appstore"
FDROID = "https://f-droid.org"
FDROID_SUCHE = "https://search.f-droid.org/api/search_apps"
IZZY = "https://apt.izzysoft.de/fdroid"
GITHUB = "https://api.github.com"
CODEBERG = "https://codeberg.org/api/v1"
GITLAB = "https://gitlab.com/api/v4"
QUELLEN = {
    "fdroid": "F-Droid",
    "izzy": "IzzyOnDroid",
    "github": "GitHub",
    "codeberg": "Codeberg",
    "apkmb": "APKMB",
    "gitlab": "GitLab",
}
# von wo eine APK kommen darf (je Quelle); GitHub leitet auf seine Ablage um
HOSTS = {
    "fdroid": ("f-droid.org",),
    "izzy": ("apt.izzysoft.de",),
    "github": ("github.com", "objects.githubusercontent.com", "release-assets.githubusercontent.com"),
    "codeberg": ("codeberg.org",),
    "apkmb": ("apkmb.com", "app.apkmb.com", "www.apkmb.com"),
    # GitLab-Release-Links koennen auf jede beliebige Adresse zeigen (selbst gesetzt beim Anlegen des Links) -
    # nur auf gitlab.com selbst gehostete Assets zulassen, alles andere ablehnen (siehe laden()).
    "gitlab": ("gitlab.com",),
}
ZEIT = 1800  # Zwischenspeicher fuer Antworten
IZZY_ZEIT = 24 * 3600  # Index von IzzyOnDroid einmal am Tag
MAX_APK = 400 * 1024 * 1024
MAX_VERLAUF = 200
MAX_FAVORITEN = 300
MAX_SCHNAPPSCHUSS = 400  # Deckel fuer den von der App gemeldeten Installations-Schnappschuss
HINTERGRUND_ABSTAND = 6 * 3600  # fest, kein neuer Konfigurationsparameter fuer einen reinen Schnappschuss-Abgleich
MAX_EIGENE_REPOS = 12  # analog eigene_quelle.MAX_QUELLEN
REPO_TYPEN = ("github", "gitlab", "codeberg", "fdroid_katalog")
_REPO_HOST = {"github": "github.com", "gitlab": "gitlab.com", "codeberg": "codeberg.org"}
# wie eigene_quelle.py::_LOKALER_HOST - reine String-Pruefung beim Speichern (kein Netzzugriff hier),
# die echte SSRF-Pruefung (DNS/IP) passiert erst beim Abruf (netz.oeffentlich_holen(), V3)
_LOKALER_HOST = re.compile(
    r"^(localhost|127\.\d{1,3}\.\d{1,3}\.\d{1,3}|10\.\d{1,3}\.\d{1,3}\.\d{1,3}|192\.168\.\d{1,3}\.\d{1,3}|"
    r"172\.(1[6-9]|2\d|3[01])\.\d{1,3}\.\d{1,3}|0\.0\.0\.0|\[?::1\]?)$", re.I)
ABIS = ("arm64-v8a", "armeabi-v7a", "x86_64", "x86")
_ABI_WORTE = {
    "arm64-v8a": ("arm64", "aarch64", "armv8", "arm64-v8a"),
    "armeabi-v7a": ("armeabi", "armv7", "arm32", "armeabi-v7a"),
    "x86_64": ("x86_64", "x64", "amd64"),
    "x86": ("x86", "i686"),
}
_PAKET = re.compile(r"^[A-Za-z][\w]*(\.[A-Za-z_][\w]*)+$")
_REPO = re.compile(r"^[\w-][\w.-]*/(?!\.\.?$)[\w.-]+$")  # besitzer/projekt, ohne "." und ".." als Teil
_GITLAB_SEGMENT = re.compile(r"^[\w.-]+$")


class StoreFehler(ValueError):
    pass


def _gitlab_pfad_gueltig(pfad):
    """GitLab-Projektpfade duerfen beliebig viele Gruppen-/Untergruppen-Ebenen haben (anders als GitHub/Codeberg)."""
    teile = str(pfad or "").split("/")
    return len(teile) >= 2 and all(_GITLAB_SEGMENT.match(t) and t not in (".", "..") for t in teile)


def _quelle_pruefen(quelle):
    """Fuer quelle_bevorzugen/quelle_festnageln: nur die Quellen, bei denen updates() tatsaechlich
    zwischen mehreren Treffern waehlt (fdroid/izzy - beobachtete Projekte haben ohnehin nur eine feste
    Quelle). Leer loescht die Einstellung wieder."""
    quelle = str(quelle or "")
    if quelle and quelle not in ("fdroid", "izzy"):
        raise StoreFehler("Quelle: fdroid/izzy")
    return quelle


def _ssrf_pruefen_host(url):
    host = urlsplit(url).hostname or ""
    if _LOKALER_HOST.match(host) or host.endswith(".local"):
        raise StoreFehler("Private/interne Adressen sind nicht erlaubt")


def eigene_repos(daten):
    """[{"id","name","typ","url","aktiv"}, ...] - Backfill "aktiv" fuer aeltere Eintraege (Standard an)."""
    liste = ((daten or {}).get(SCHLUESSEL) or {}).get("eigene_repos") or []
    return [dict(r, aktiv=bool(r.get("aktiv", True))) for r in liste if isinstance(r, dict) and r.get("url") and r.get("id")]


def _eigener_repo_pruefen(roh):
    """Nur strukturierte Quellen: eine Projekt-URL bei GitHub/GitLab/Codeberg, oder ein F-Droid-kompatibler
    Katalog-Index auf einem beliebigen oeffentlichen Host - keine beliebige APK-Download-Seite (eigenes,
    hier bewusst ausgelassenes Scraping-Risiko)."""
    roh = roh if isinstance(roh, dict) else {}
    typ = roh.get("typ") if roh.get("typ") in REPO_TYPEN else None
    if not typ:
        raise StoreFehler("Typ: " + "/".join(REPO_TYPEN))
    url = str(roh.get("url") or "").strip()[:500]
    if not re.match(r"^https?://[^\s/]+", url):
        raise StoreFehler("Adresse mit http(s):// eingeben")
    _ssrf_pruefen_host(url)
    if typ == "fdroid_katalog":
        url = url.rstrip("/")
    else:
        host = (urlsplit(url).hostname or "").lower().replace("www.", "")
        if host != _REPO_HOST[typ]:
            raise StoreFehler("Adresse muss auf %s liegen" % _REPO_HOST[typ])
        pfad = urlsplit(url).path.strip("/")
        gueltig = _gitlab_pfad_gueltig(pfad) if typ == "gitlab" else bool(_REPO.match(pfad))
        if not gueltig:
            raise StoreFehler("Ungültiger Projektpfad (Besitzer/Projekt)")
        url = "https://%s/%s" % (host, pfad)
    name = _text(roh.get("name"), 60) or (urlsplit(url).hostname or "Repo")
    aktiv = bool(roh.get("aktiv", True))
    repo_id = typ + ":" + hashlib.sha1(url.encode()).hexdigest()[:16]
    return {"id": repo_id, "name": name, "typ": typ, "url": url, "aktiv": aktiv}


def vertrauen(sterne, tage_seit_push, releases, forks, lizenz, archiviert):
    """Vertrauenswert 0–100 eines Projekts: Beliebtheit, Pflege, Releases, Forks, Lizenz."""
    punkte = min(35.0, 12.0 * math.log10(1 + max(0, sterne)))
    punkte += 25 if tage_seit_push <= 30 else 18 if tage_seit_push <= 180 else 10 if tage_seit_push <= 365 else 3
    punkte += min(20, 2 * max(0, releases))
    punkte += min(10.0, 4.0 * math.log10(1 + max(0, forks)))
    punkte += 10 if lizenz else 0
    if archiviert:
        punkte -= 30
    return int(max(0, min(100, round(punkte))))


def abi_von(name):
    n = name.lower()
    for abi in ABIS:  # arm64 vor armeabi, x86_64 vor x86
        if any(w in n for w in _ABI_WORTE[abi]):
            return abi
    return ""


def apk_waehlen(apks, abi=""):
    """Passende APK: genau die Architektur des Geraets, sonst eine fuer alle (ohne Architektur im Namen), sonst die erste."""
    if not apks:
        return None
    if abi:
        genau = [a for a in apks if a.get("abi") == abi]
        if genau:
            return genau[0]
    alle = [a for a in apks if not a.get("abi") or "universal" in a["name"].lower()]
    return (alle or apks)[0]


def version_neuer(a, b):
    """Ist Version a neuer als b? Zahlen werden als Zahlen verglichen ("v1.10" > "1.9")."""

    def teile(v):
        return [int(t) if t.isdigit() else t for t in re.findall(r"\d+|[a-z]+", str(v).lower().lstrip("v"))]

    ta, tb = teile(a), teile(b)
    for x, y in zip(ta, tb):
        if x == y:
            continue
        if isinstance(x, int) and isinstance(y, int):
            return x > y
        if isinstance(x, int) != isinstance(y, int):
            return isinstance(x, int)  # 1.0.1 > 1.0-beta
        return x > y
    return len(ta) > len(tb) and isinstance(ta[len(tb)], int)


def _tage_seit(iso, jetzt):
    try:
        return max(0, int((jetzt - time.mktime(time.strptime(str(iso)[:19], "%Y-%m-%dT%H:%M:%S"))) // 86400))
    except ValueError:
        return 9999


def _text(wert, laenge):
    return " ".join(str(wert or "").split())[:laenge]


def roh_laden(url, ziel, grenze=MAX_APK):
    """Datei in Stuecken laden; folgt Weiterleitungen (urllib). Gibt die endgueltige Adresse zurueck."""
    anfrage = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    try:
        with urllib.request.urlopen(anfrage, timeout=120) as a, open(ziel, "wb") as f:
            groesse = 0
            while True:
                stueck = a.read(1 << 20)
                if not stueck:
                    return a.geturl()
                groesse += len(stueck)
                if groesse > grenze:
                    raise StoreFehler("APK zu groß (über %d MB)" % (grenze // (1024 * 1024)))
                f.write(stueck)
    except (urllib.error.URLError, OSError) as fehler:
        raise StoreFehler("Download fehlgeschlagen: %s" % getattr(fehler, "reason", fehler))
