"""App-Store: Netzzugriff, Zwischenspeicher und Suche in allen Quellen."""

import json
import os
import re
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import quote, urlencode, urlsplit

from .appstore_grund import (
    CODEBERG,
    FDROID,
    FDROID_SUCHE,
    GITHUB,
    GITLAB,
    IZZY,
    IZZY_ZEIT,
    QUELLEN,
    SCHLUESSEL,
    ZEIT,
    StoreFehler,
    _PAKET,
    _REPO,
    _gitlab_pfad_gueltig,
    _tage_seit,
    _text,
    vertrauen,
)
from .netz import NetzFehler, oeffentlich_holen


class SucheMixin:
    # --- Netz ------------------------------------------------------------------------------------------------------
    def _einstellungen(self):
        v = self._verwaltung()
        d = v.daten() if v is not None else {}
        return d.get(SCHLUESSEL) if isinstance(d.get(SCHLUESSEL), dict) else {}

    def _json(self, url, kopf=None, fehlt_ok=False):
        with self._sperre:
            alt = self._speicher.get(url)
            if alt and self.uhr() - alt[0] < ZEIT:
                return alt[1]
        try:
            status, text = self.holen(url, "GET", dict({"Accept": "application/json"}, **(kopf or {})), None)
        except NetzFehler as fehler:
            raise StoreFehler(str(fehler))
        if status == 404 and fehlt_ok:
            daten = None
        elif status == 403 and "api.github.com" in url:
            raise StoreFehler("GitHub-Abfragegrenze erreicht – später nochmal, oder einen GitHub-Token eintragen")
        elif status >= 400:
            raise StoreFehler("%s antwortet mit HTTP %d" % (urlsplit(url).hostname, status))
        else:
            try:
                daten = json.loads(text)
            except ValueError:
                raise StoreFehler("Keine gültige Antwort von %s" % urlsplit(url).hostname)
        with self._sperre:
            if len(self._speicher) > 500:
                self._speicher.clear()
            self._speicher[url] = (self.uhr(), daten)
        return daten

    def _json_oeffentlich(self, url):
        """Wie _json(), aber fuer eine admin-eingetragene Adresse (nicht eine feste Host-Konstante wie
        GITHUB/GITLAB/CODEBERG) - mit echter SSRF-Pruefung (DNS/IP, netz.oeffentlich_holen()) vor jedem
        Abruf, nicht nur den bekannten Plattform-Hosts."""
        with self._sperre:
            alt = self._speicher.get(url)
            if alt and self.uhr() - alt[0] < ZEIT:
                return alt[1]
        try:
            status, text = oeffentlich_holen(self.holen)(url, methode="GET", header={"Accept": "application/json"}, daten=None)
        except NetzFehler as fehler:
            raise StoreFehler(str(fehler))
        if status >= 400:
            raise StoreFehler("%s antwortet mit HTTP %d" % (urlsplit(url).hostname, status))
        try:
            daten = json.loads(text)
        except ValueError:
            raise StoreFehler("Keine gültige Antwort von %s" % urlsplit(url).hostname)
        with self._sperre:
            if len(self._speicher) > 500:
                self._speicher.clear()
            self._speicher[url] = (self.uhr(), daten)
        return daten

    def _github_kopf(self):
        token = str(self._einstellungen().get("github_token") or "")
        return {"Accept": "application/vnd.github+json", **({"Authorization": "Bearer " + token} if token else {})}

    # --- IzzyOnDroid: Index einmal am Tag, kompakt auf der Platte ----------------------------------------------------
    def _izzy_index(self):
        pfad = os.path.join(self.ordner, "izzy.json")
        with self._izzy_sperre:
            if self._izzy and self.uhr() - self._izzy[0] < IZZY_ZEIT:
                return self._izzy[1]
            try:
                if self.uhr() - os.path.getmtime(pfad) < IZZY_ZEIT:
                    with open(pfad, encoding="utf-8") as f:
                        self._izzy = (os.path.getmtime(pfad), json.load(f))
                        return self._izzy[1]
            except (OSError, ValueError):
                pass
            os.makedirs(self.ordner, exist_ok=True)
            roh_pfad = os.path.join(self.ordner, "izzy-index.json")
            try:  # gut 16 MB: als Datei laden, nicht in den Speicher fuer Antworten
                self.laden_roh(IZZY + "/repo/index-v1.json", roh_pfad, 64 * 1024 * 1024)
                with open(roh_pfad, encoding="utf-8") as f:
                    roh = json.load(f)
            except (OSError, ValueError) as fehler:
                raise StoreFehler("Index von IzzyOnDroid nicht lesbar: %s" % fehler)
            finally:
                try:
                    os.remove(roh_pfad)
                except OSError:
                    pass
            apps = {}
            for a in (roh or {}).get("apps") or []:
                if not isinstance(a, dict) or not a.get("packageName"):
                    continue
                lokal = a.get("localized") if isinstance(a.get("localized"), dict) else {}
                sprachen = [lokal[k] for k in ("de-DE", "de", "en-US", "en") if isinstance(lokal.get(k), dict)] + [
                    v for v in lokal.values() if isinstance(v, dict)
                ]

                def feld(name):  # je Sprache stehen nicht alle Felder; das erste vorhandene zaehlt
                    return a.get(name) or next((x[name] for x in sprachen if x.get(name)), "")

                apps[a["packageName"]] = {
                    "name": _text(feld("name") or a["packageName"], 80),
                    "beschreibung": _text(feld("summary"), 200),
                    "symbol": "%s/repo/icons-640/%s" % (IZZY, a["icon"]) if a.get("icon") else "",
                    "code": int(a.get("suggestedVersionCode") or 0),
                }
            with open(pfad + ".neu", "w", encoding="utf-8") as f:
                json.dump(apps, f)
            os.replace(pfad + ".neu", pfad)
            self._izzy = (self.uhr(), apps)
            return apps

    # --- Suche -----------------------------------------------------------------------------------------------------
    def suchen(self, text, quellen=None):
        text = _text(text, 80)
        if len(text) < 2:
            raise StoreFehler("Mindestens zwei Zeichen")
        quellen = [q for q in (quellen or QUELLEN) if q in QUELLEN]
        arbeit = {
            "fdroid": self._fdroid_suche,
            "izzy": self._izzy_suche,
            "github": self._github_suche,
            "codeberg": self._codeberg_suche,
            "apkmb": self._apkmb_suche,
            "gitlab": self._gitlab_suche,
        }
        ergebnisse, fehler = [], {}
        with ThreadPoolExecutor(max_workers=5) as pool:
            zukunft = {q: pool.submit(arbeit[q], text) for q in quellen}
            for q, z in zukunft.items():
                try:
                    ergebnisse.extend(z.result())
                except StoreFehler as f:
                    fehler[q] = str(f)
        # dieselbe App aus mehreren F-Droid-Repos: einmal zeigen, F-Droid zuerst
        gesehen, liste = set(), []
        for e in ergebnisse:
            schluessel = e.get("paket") or e["id"]
            if schluessel in gesehen:
                continue
            gesehen.add(schluessel)
            liste.append(e)
        woerter = text.lower().split()
        liste.sort(key=lambda e: (-sum(w in e["name"].lower() for w in woerter), -(e.get("vertrauen") or 60)))
        return {"apps": liste, "fehler": fehler}

    def _fdroid_suche(self, text):
        d = self._json(FDROID_SUCHE + "?" + urlencode({"q": text, "lang": "de"}))
        apps = []
        for a in (d or {}).get("apps") or []:
            m = re.search(r"/packages/([\w.]+)/?$", str(a.get("url") or ""))
            if m and _PAKET.match(m.group(1)):
                apps.append(
                    {
                        "id": "fdroid:" + m.group(1),
                        "quelle": "fdroid",
                        "paket": m.group(1),
                        "name": _text(a.get("name"), 80),
                        "beschreibung": _text(a.get("summary"), 200),
                        "symbol": str(a.get("icon") or ""),
                        "seite": "%s/packages/%s/" % (FDROID, m.group(1)),
                    }
                )
        return apps[:25]

    def _izzy_suche(self, text):
        woerter = text.lower().split()
        apps = []
        for paket, a in self._izzy_index().items():
            heu = (a["name"] + " " + a["beschreibung"] + " " + paket).lower()
            if all(w in heu for w in woerter):
                apps.append(
                    {
                        "id": "izzy:" + paket,
                        "quelle": "izzy",
                        "paket": paket,
                        "name": a["name"],
                        "beschreibung": a["beschreibung"],
                        "symbol": a["symbol"],
                        "seite": "https://apt.izzysoft.de/fdroid/index/apk/" + paket,
                    }
                )
        return apps[:25]

    def _repo_app(self, quelle, r):
        jetzt = self.uhr()
        return {
            "id": "%s:%s" % (quelle, r["full_name"]),
            "quelle": quelle,
            "name": _text(r.get("name"), 80),
            "beschreibung": _text(r.get("description"), 200),
            "symbol": str((r.get("owner") or {}).get("avatar_url") or ""),
            "seite": str(r.get("html_url") or ""),
            "sterne": int(r.get("stargazers_count") or r.get("stars_count") or 0),
            "vertrauen": vertrauen(
                int(r.get("stargazers_count") or r.get("stars_count") or 0),
                _tage_seit(r.get("pushed_at") or r.get("updated_at"), jetzt),
                int(r.get("release_counter") or 0),
                int(r.get("forks_count") or 0),
                bool(r.get("license")),
                bool(r.get("archived")),
            ),
        }

    def _github_suche(self, text):
        d = self._json(
            GITHUB
            + "/search/repositories?"
            + urlencode({"q": "%s topic:android" % text, "sort": "stars", "per_page": 20}),
            self._github_kopf(),
        )
        return [
            self._repo_app("github", r)
            for r in (d or {}).get("items") or []
            if isinstance(r, dict) and _REPO.match(str(r.get("full_name")))
        ]

    def _codeberg_suche(self, text):
        d = self._json(
            CODEBERG + "/repos/search?" + urlencode({"q": text, "limit": 20, "sort": "stars", "order": "desc"})
        )
        return [
            self._repo_app("codeberg", r)
            for r in (d or {}).get("data") or []
            if isinstance(r, dict) and _REPO.match(str(r.get("full_name")))
        ]

    def _gitlab_projekt(self, r):
        """GitLab nennt seine Felder anders als GitHub/Codeberg (star_count statt stargazers_count,
        last_activity_at statt pushed_at) - eigenes Mapping statt eine Vereinheitlichung zu erzwingen."""
        jetzt = self.uhr()
        return {
            "id": "gitlab:" + str(r.get("path_with_namespace")),
            "quelle": "gitlab",
            "name": _text(r.get("name"), 80),
            "beschreibung": _text(r.get("description"), 200),
            "symbol": str(r.get("avatar_url") or ""),
            "seite": str(r.get("web_url") or ""),
            "sterne": int(r.get("star_count") or 0),
            "vertrauen": vertrauen(
                int(r.get("star_count") or 0),
                _tage_seit(r.get("last_activity_at"), jetzt),
                int(r.get("release_counter") or 0),
                int(r.get("forks_count") or 0),
                bool(r.get("license")),
                bool(r.get("archived")),
            ),
        }

    def _gitlab_suche(self, text):
        d = self._json(
            GITLAB
            + "/projects?"
            + urlencode({"search": text, "order_by": "star_count", "sort": "desc", "per_page": 20, "license": "true"})
        )
        return [
            self._gitlab_projekt(r)
            for r in (d or [])
            if isinstance(r, dict) and _gitlab_pfad_gueltig(r.get("path_with_namespace"))
        ]

    def _apkmb_suche(self, text):
        try:
            status, html = self.holen("https://apkmb.com/?s=" + quote(text), "GET", {"Accept": "text/html"}, None)
        except NetzFehler as fehler:
            raise StoreFehler(str(fehler))
        if status >= 400:
            return []
        from html import unescape
        apps = []
        content = html or ""
        for m in re.finditer(r'<a[^>]+href="https://apkmb\.com/([^/"]+?)/?"[^>]*>([^<]+)</a>', content):
            slug = m.group(1)
            if slug in ("tag", "category", "page", "author", "wp-content", "search", "wp-json") or "?" in slug or slug.startswith("#"):
                continue
            titel = unescape(re.sub(r'<[^>]+>', ' ', m.group(2))).strip()
            if not titel or len(titel) > 80:
                titel = slug.replace('-', ' ').title()
            apps.append({"id": "apkmb:" + slug, "quelle": "apkmb", "name": _text(titel, 80),
                         "beschreibung": "", "symbol": "", "seite": "https://apkmb.com/" + slug})
            if len(apps) >= 20:
                break
        return apps
