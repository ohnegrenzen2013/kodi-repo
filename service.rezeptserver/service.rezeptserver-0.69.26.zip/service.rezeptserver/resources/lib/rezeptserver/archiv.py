"""Gemeinsame Fehlerarten beim Lesen von ZIP- und gzip-Daten (defekte Downloads).

Ein Download kann auf viele Arten kaputt sein: unbekanntes ZIP-Verfahren,
verschluesselte Eintraege, abgeschnittene Daten, ein gepatchter Deflate-Strom
oder eine falsche Pruefsumme. Die Module fangen dieselben Ausnahmen ab; hier
stehen sie einmal, damit die Listen nicht auseinanderlaufen.
"""

import zipfile
import zlib

# Beim Oeffnen und Lesen von ZIP-Dateien.
ZIP_FEHLER = (zipfile.BadZipFile, NotImplementedError, EOFError, zlib.error,
              RuntimeError, UnicodeDecodeError, ValueError)

# gzip.BadGzipFile ist ein OSError und damit mit abgedeckt.
GZIP_FEHLER = (EOFError, zlib.error, OSError)
