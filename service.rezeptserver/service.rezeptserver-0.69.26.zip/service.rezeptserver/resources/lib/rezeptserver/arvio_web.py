"""ARVIO Web selbst hosten (Next.js/Node). Installation, Prüfung, Erreichbarkeit."""

import io
import json
import os
import re
import shutil
import threading
import zipfile

from .archiv import ZIP_FEHLER
from .netz import USER_AGENT

ARVIO_ZIP = "https://github.com/ProdigyV21/ARVIO/archive/refs/heads/main.zip"
NAME = "arvio"
MAX_ZIP = 200 * 1024 * 1024
MAX_ENTPACKT = 1024 * 1024 * 1024
_bau_sperre = threading.Lock()


class ArvioFehler(ValueError):
    pass


def _abruf(url, holen=None, grenze=MAX_ZIP):
    if holen:
        daten = holen(url)
        if len(daten) > grenze:
            raise ArvioFehler("Download zu groß")
        return daten
    import urllib.error
    import urllib.request

    anfrage = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 " + USER_AGENT})
    try:
        with urllib.request.urlopen(anfrage, timeout=120) as a:
            daten = a.read(grenze + 1)
    except urllib.error.HTTPError as fehler:
        fehler.close()
        raise ArvioFehler("Download fehlgeschlagen: HTTP %d" % fehler.code)
    except (urllib.error.URLError, OSError) as fehler:
        raise ArvioFehler("Download fehlgeschlagen: %s" % getattr(fehler, "reason", fehler))
    if len(daten) > grenze:
        raise ArvioFehler("Download zu groß")
    return daten


def _entpacken(roh, ziel, oben=None):
    try:
        archiv = zipfile.ZipFile(io.BytesIO(roh))
    except zipfile.BadZipFile:
        raise ArvioFehler("Download ist kein ZIP")
    except ZIP_FEHLER as fehler:
        # z. B. unbekannte ZIP-Version oder verschluesselte Eintraege im Kopf
        raise ArvioFehler("Download ist kein ZIP: %s" % fehler)
    ziel = os.path.realpath(ziel)
    anzahl = 0
    groesse = 0
    try:
        for eintrag in archiv.infolist():
            name = eintrag.filename
            if oben:
                if not name.startswith(oben):
                    continue
                name = name[len(oben):]
            if not name or name.endswith("/"):
                continue
            pfad = os.path.realpath(os.path.join(ziel, name))
            if not pfad.startswith(ziel + os.sep):
                continue
            groesse += max(eintrag.file_size, 0)
            if groesse > MAX_ENTPACKT:
                raise ArvioFehler("Archiv zu groß beim Entpacken")
            os.makedirs(os.path.dirname(pfad), exist_ok=True)
            with archiv.open(eintrag) as r, open(pfad, "wb") as w:
                shutil.copyfileobj(r, w)
            anzahl += 1
    except ArvioFehler:
        raise
    except ZIP_FEHLER as fehler:
        # beschaedigte oder unvollstaendige Daten fallen erst beim Lesen auf (CRC, gepatchter Deflate-Strom)
        raise ArvioFehler("Archiv ist beschädigt: %s" % fehler)
    finally:
        archiv.close()
    return anzahl


def pruefe(ordner):
    if not ordner:
        return {"vorhanden": False, "version": ""}
    basis = os.path.join(ordner, NAME)
    vorhanden = os.path.isdir(basis) and os.path.isfile(os.path.join(basis, "package.json"))
    version = ""
    if vorhanden:
        try:
            with open(os.path.join(basis, "package.json"), encoding="utf-8") as f:
                d = json.load(f)
            version = str(d.get("version") or "")[:30]
        except Exception:
            version = ""
    return {"vorhanden": vorhanden, "version": version}


def erreichbar(adresse, timeout=3):
    if not adresse:
        return None
    import urllib.error
    import urllib.request

    if not re.match(r"^https?://", adresse, re.I):
        return False
    try:
        with urllib.request.urlopen(urllib.request.Request(adresse, method="HEAD", headers={"User-Agent": USER_AGENT}), timeout=timeout):
            return True
    except urllib.error.HTTPError as fehler:
        fehler.close()
        return fehler.code < 500
    except (urllib.error.URLError, OSError, ValueError):
        return False


def installieren(ordner, tmdb=None, holen=None):
    if not ordner:
        raise ArvioFehler("Kein Webordner angegeben")
    basis = os.path.join(ordner, NAME)
    if os.path.isfile(basis):
        raise ArvioFehler("Der Platz für ARVIO ist eine Datei statt eines Ordners: %s" % basis)
    # eine Sperre fuer Installieren und Bauen: nie tauscht eine Installation den Ordner unter einem laufenden Build weg
    with _bau_sperre:
        zeilen = str(tmdb).strip().splitlines() if tmdb else []
        tmdb = zeilen[0][:200] if zeilen else ""  # eine Zeile, sonst geraet .env.local durcheinander
        # TMDb-Schlüssel aus einer vorhandenen Installation retten (Reinstallation ohne Eingabe löscht ihn sonst)
        if not tmdb:
            try:
                with open(os.path.join(basis, ".env.local"), encoding="utf-8") as f:
                    for zeile in f:
                        if zeile.strip().startswith("TMDB_API_KEY="):
                            alt = zeile.split("=", 1)[1].strip()
                            if alt:
                                tmdb = alt[:200]
                            break
            except (OSError, UnicodeDecodeError):
                pass
        roh = _abruf(ARVIO_ZIP, holen)
        # erst komplett woanders entpacken, dann tauschen – eine kaputte Neue darf die alte nicht zerstören
        neu = basis + ".neu"
        try:
            if os.path.islink(neu) or os.path.isfile(neu):
                os.remove(neu)
            elif os.path.isdir(neu):
                shutil.rmtree(neu)
            os.makedirs(neu, exist_ok=True)
        except OSError as fehler:
            raise ArvioFehler("Nebenordner %s lässt sich nicht anlegen: %s" % (neu, fehler))
        try:
            anzahl = _entpacken(roh, neu, oben="ARVIO-main/")
            if not anzahl:
                raise ArvioFehler("Installation fehlgeschlagen (keine Dateien im Archiv)")
        except BaseException:
            shutil.rmtree(neu, ignore_errors=True)
            raise
        env_pfad = os.path.join(neu, ".env.local")
        # eigene Zeilen des Nutzers behalten: erst eine Datei aus dem Archiv, sonst die der alten Installation
        bestehend = ""
        for quelle in (env_pfad, os.path.join(basis, ".env.local")):
            if os.path.isfile(quelle):
                try:
                    with open(quelle, encoding="utf-8") as f:
                        bestehend = f.read()
                except (OSError, UnicodeDecodeError):
                    bestehend = ""
                break
        neu_zeilen = []
        for z in bestehend.splitlines():
            if z.strip().startswith("TMDB_API_KEY="):
                if tmdb:
                    neu_zeilen.append("TMDB_API_KEY=%s" % tmdb)
                else:
                    neu_zeilen.append(z)
            else:
                neu_zeilen.append(z)
        if tmdb and not any(z.strip().startswith("TMDB_API_KEY=") for z in neu_zeilen):
            neu_zeilen.append("TMDB_API_KEY=%s" % tmdb)
        if not any(z.strip().startswith("NEXT_PUBLIC_SELF_HOSTED=") for z in neu_zeilen):
            neu_zeilen.append("NEXT_PUBLIC_SELF_HOSTED=true")
        with open(env_pfad, "w", encoding="utf-8") as f:
            f.write("\n".join(neu_zeilen) + "\n")
        # alten Ordner beiseitelegen, neuen einsetzen; scheitert der Tausch, kommt der alte zurueck
        alt = basis + ".alt"
        try:
            shutil.rmtree(alt, ignore_errors=True)
            if os.path.lexists(basis):
                os.replace(basis, alt)
            os.replace(neu, basis)
        except OSError as fehler:
            if os.path.lexists(alt) and not os.path.lexists(basis):
                try:
                    os.replace(alt, basis)
                except OSError:
                    pass
            shutil.rmtree(neu, ignore_errors=True)
            raise ArvioFehler("ARVIO-Ordner lässt sich nicht ersetzen: %s" % fehler)
        shutil.rmtree(alt, ignore_errors=True)
        p = pruefe(ordner)
        return {"pfad": basis, "version": p.get("version") or "", "weiter": "arvio/"}


def bauen(ordner):
    """npm install + npm run build im ARVIO-Ordner ausführen (optional, wenn Node/npm da)."""
    if not ordner:
        raise ArvioFehler("Kein Webordner angegeben")
    basis = os.path.join(ordner, NAME)
    if not os.path.isdir(basis):
        raise ArvioFehler("ARVIO ist nicht installiert")
    if not _bau_sperre.acquire(blocking=False):
        raise ArvioFehler("Es läuft gerade ein Build oder eine Installation – bitte warten")
    try:
        import shutil as _sh
        import subprocess
        npm = _sh.which("npm")
        if not npm:
            raise ArvioFehler("npm ist nicht installiert")
        for befehl in ([npm, "install", "--no-audit", "--no-fund"], [npm, "run", "build"]):
            try:
                subprocess.check_call(befehl, cwd=basis, timeout=600)
            except subprocess.CalledProcessError as fehler:
                raise ArvioFehler("Bauen fehlgeschlagen: %s" % fehler)
            except subprocess.TimeoutExpired:
                raise ArvioFehler("Bauen dauert zu lange (Timeout)")
        return pruefe(ordner)
    finally:
        _bau_sperre.release()
