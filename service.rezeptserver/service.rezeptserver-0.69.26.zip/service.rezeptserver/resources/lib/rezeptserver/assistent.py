"""Hinzufuegen-Assistent: ein Fragenkatalog als Baum fuer alles, was man H0rSt hinzufuegen kann.

Was? (Filme & Serien, Herunterladen, Live-TV, Zuhause, Sicherheit, Reiter, per Adresse) -> Wer/Woher? (die passenden
Vorlagen und Bausteine) -> Zugang (Felder der Vorlage) -> Pruefen -> Verknuepfen. Der Baum entsteht aus den Vorlagen
(vorlagen.py), den mitgelieferten Anbietern (Rezepte) und den Bausteinen (Heimspeicher, Kameras, eigene Reiter ...),
neue Vorlagen erscheinen also von selbst. Jede Antwort fuehrt entweder zur naechsten Frage oder zu einem Ziel:
  {"art": "vorlage", "vorlage": id}      eigener Anbieter aus einer Vorlage
  {"art": "zugang", "id": konto}         Zugangsdaten eines mitgelieferten Anbieters (z. B. Easynews)
  {"art": "json"}                        Stremio-Addon oder Anbieter-JSON per Adresse
  {"art": "heimspeicher", "speicher": a} Speicher (AiCloud, Nextcloud, FTP ...)
  {"art": "kamera", "kamera": vorschlag} IP-Kamera
  {"art": "liste"}                       M3U-Liste fuer Live-TV
  {"art": "reiter", "vorlage": id|""}    eigener Reiter (App oder Webseite)
  {"art": "link"}                        Heim-Link
  {"art": "bereich", "bereich": b}       Einrichtung im Bereich selbst (Hue koppeln, Cast suchen)
Nach dem Anlegen schlaegt "verknuepfungen" passende naechste Schritte vor.
"""

from . import anbieter, einstellungen, heimspeicher, kameras, vorlagen


def _vorlagen(filter_):
    return [v for v in vorlagen.VORLAGEN if filter_(v)]


def _option(name, symbol="", hinweis="", weiter=None, ziel=None):
    o = {"name": name, "symbol": symbol, "hinweis": hinweis}
    if weiter:
        o["weiter"] = weiter
    if ziel:
        o["ziel"] = ziel
    return o


def _aus_vorlagen(liste, eigene=None):
    optionen = [_option(v["name"], "", v["hinweis"][:140], ziel={"art": "vorlage", "vorlage": v["id"]})
                for v in liste if not v["id"].startswith(("vxparser:",))]
    if eigene:
        optionen.append(eigene)
    return optionen


def baum(module=()):
    """Fragenkatalog: {"start": "was", "knoten": {id: {"frage", "hinweis", "optionen"}}}."""
    eingebaut = [a for a in anbieter.liste(list(module), {}) if a["felder"]]
    k = {}
    k["was"] = {"frage": "Was möchtest du hinzufügen?", "hinweis": "Wähle, worum es geht – danach fragt H0rSt nur noch, was dazu passt.",
                "optionen": [
                    _option("Filme & Serien", "🎬", "Quellen für Streams: Easynews, Usenet, Debrid, Stremio-Addons …", "quellen"),
                    _option("Herunterladen", "⬇", "Downloader (NZBGet, qBittorrent, Router …) und Medienverwaltung", "laden"),
                    _option("Live-TV", "📡", "Xtream-Zugang, M3U-Listen, vxparser", "tv"),
                    _option("Zuhause & Geräte", "🏠", "Speicher, Kameras, Licht, Google Home, Pi-hole, Kodi", "zuhause"),
                    _option("Sicherheit", "🛡", "VPN (WireGuard), Tor, I2P, Proxy", "sicherheit"),
                    _option("Reiter & Apps", "🧩", "Eigener Reiter für eine App oder Webseite", "reiter"),
                    _option("Per Adresse oder Datei", "🔗", "Stremio-Addon-Adresse oder Anbieter-JSON einfügen", ziel={"art": "json"}),
                ]}
    k["quellen"] = {"frage": "Woher sollen Filme und Serien kommen?", "hinweis": "Mehrere Quellen gehen gleichzeitig; H0rSt zeigt alle Treffer zusammen.",
                    "optionen": [
                        _option("Usenet", "📰", "Easynews, Usenet-Provider, NZB-Indexer", "usenet"),
                        _option("Debrid-Dienst", "⚡", "Real-Debrid, AllDebrid, Premiumize, TorBox …", "debrid"),
                        _option("Hoster-Konto", "☁", "1fichier, Rapidgator, DDownload …", "hoster"),
                        _option("Stremio-Addon", "🧩", "Torrentio, Comet, MediaFusion … per Adresse", "addons"),
                        _option("Torrent-Indexer", "🧲", "Prowlarr, Jackett (Torznab)", "torrent"),
                        _option("Metadaten & Untertitel", "ℹ", "TMDb, OpenSubtitles", "meta"),
                    ]}
    easy = next((a for a in eingebaut if a["id"] == "easynews"), None)
    k["usenet"] = {"frage": "Welche Art von Usenet-Zugang?", "hinweis": "Easynews streamt direkt; Provider und Indexer arbeiten zusammen (Indexer findet, Provider liefert).",
                   "optionen": ([_option("Easynews-Konto", "★", "Streams direkt aus der Easynews-Suche, nur Benutzer und Passwort",
                                         ziel={"art": "zugang", "id": "easynews"})] if easy else []) + [
                       _option("Usenet-Provider (Server)", "🖧", "Eweka, Newshosting, Tweaknews … – liefert die Dateien", "nntp"),
                       _option("NZB-Indexer", "🔎", "binsearch (ohne Konto), NZBGeek, DrunkenSlug, NZBHydra2 … – findet die Dateien", "indexer")]}
    k["nntp"] = {"frage": "Welcher Usenet-Provider?", "hinweis": "Zugangsdaten stehen im Kundenbereich des Providers.",
                 "optionen": _aus_vorlagen(_vorlagen(lambda v: v["typ"] == "nntp"))}
    k["indexer"] = {"frage": "Welcher Indexer?", "hinweis": "Den API-Schlüssel findest du im Profil des Indexers – "
                                                            "binsearch sucht ohne Konto.",
                    "optionen": _aus_vorlagen(_vorlagen(lambda v: v["typ"] in ("binsearch", "newznab")))}
    k["debrid"] = {"frage": "Welcher Debrid-Dienst?", "hinweis": "API-Schlüssel aus dem Kontobereich des Dienstes.",
                   "optionen": _aus_vorlagen(_vorlagen(lambda v: v["typ"] == "debrid"))}
    k["hoster"] = {"frage": "Welcher Hoster?", "hinweis": "Für Hoster-Links, die H0rSt mit deinem Konto direkt abspielt.",
                   "optionen": _aus_vorlagen(_vorlagen(lambda v: v["kategorie"] == "hoster" and v["typ"] != "debrid"))}
    k["addons"] = {"frage": "Welches Addon?", "hinweis": "Stremio-Addon (manifest.json) oder mHub-Addon (mhub-addon.json) – Adresse einfügen.",
                   "optionen": _aus_vorlagen(_vorlagen(lambda v: v["typ"] in ("stremio-addon", "mhub-addon")),
                                             _option("Andere Addon-Adresse", "🔗", "z. B. https://torrentio.strem.fun/…/manifest.json oder https://…/mhub-addon.json",
                                                     ziel={"art": "json"}))}
    k["torrent"] = {"frage": "Welcher Torrent-Indexer?", "hinweis": "Adresse und API-Schlüssel aus Prowlarr bzw. Jackett.",
                    "optionen": _aus_vorlagen(_vorlagen(lambda v: v["typ"] == "torznab"))}
    k["meta"] = {"frage": "Was soll ergänzt werden?", "hinweis": "Ohne Schlüssel geht es auch – mit Schlüssel gibt es Bilder und Untertitel.",
                 "optionen": [_option(a["name"], "ℹ", "Schlüssel kostenlos beim Dienst", ziel={"art": "zugang", "id": a["id"]})
                              for a in eingebaut if a["kategorie"] in ("metadaten", "untertitel")]}
    k["laden"] = {"frage": "Was möchtest du einrichten?", "hinweis": "Downloader bekommen NZBs und Magnet-Links aus der Suche; die Medienverwaltung sortiert deine Sammlung.",
                  "optionen": [_option("Downloader", "⬇", "NZBGet, SABnzbd, NzbDAV, AltMount, rustnzb, qBittorrent, Transmission, Deluge, ASUS Download Master", "downloader"),
                               _option("Medienverwaltung", "🗂", "Sonarr, Radarr, Lidarr, Seerr, Prowlarr, Tautulli, Bazarr", "medien")]}
    k["downloader"] = {"frage": "Welcher Downloader?", "hinweis": "Adresse und Zugang der Weboberfläche des Programms.",
                       "optionen": _aus_vorlagen(_vorlagen(lambda v: v["kategorie"] == "downloader"))}
    k["medien"] = {"frage": "Welches Programm?", "hinweis": "Der API-Schlüssel steht in den Einstellungen des Programms (General).",
                   "optionen": _aus_vorlagen(_vorlagen(lambda v: v["kategorie"] == "medien" and v["typ"] not in ("pihole", "kodi")))}
    k["tv"] = {"frage": "Welche Art von Fernsehen?", "hinweis": "Öffentlich-rechtliche und kostenlose Sender sind schon dabei.",
               "optionen": [_option("Xtream-Zugang", "📺", "Server, Benutzer, Passwort deines IPTV-Anbieters", ziel={"art": "vorlage", "vorlage": "xtream"}),
                            _option("M3U-Liste per Adresse", "📄", "Eine Senderliste (.m3u/.m3u8), die du nutzen darfst", ziel={"art": "liste"}),
                            _option("vxparser", "🧰", "vxparser-Server im Heimnetz", ziel={"art": "vorlage", "vorlage": "vxparser"})]}
    k["heimserver"] = {"frage": "Welcher Medienserver?", "hinweis": "Filme und Folgen aus deiner Mediathek erscheinen bei der Suche als Quelle.",
                       "optionen": _aus_vorlagen(_vorlagen(lambda v: v["kategorie"] == "heimserver"))}
    k["zuhause"] = {"frage": "Was gibt es bei dir zu Hause?", "hinweis": "H0rSt verbindet sich im Heimnetz direkt mit den Geräten.",
                    "optionen": [_option("Speicher", "💾", "ASUS AiCloud, Nextcloud, Synology, FTP, offenes Verzeichnis", "speicher"),
                                 _option("Medienserver", "🎬", "Jellyfin, Emby oder Plex: deine Mediathek als Quelle", "heimserver"),
                                 _option("IP-Kamera", "📷", "MJPEG, Einzelbild, HLS oder RTSP", "kamera"),
                                 _option("Philips Hue", "💡", "Lampen über die Hue-Bridge", ziel={"art": "bereich", "bereich": "licht"}),
                                 _option("Google Home / Chromecast", "📺", "Lautsprecher, Nest Hub, Chromecast, Google TV",
                                         ziel={"art": "bereich", "bereich": "licht", "cast": True}),
                                 _option("Pi-hole", "🧱", "Werbe- und Trackerfilter fürs Netz", ziel={"art": "vorlage", "vorlage": "pihole"}),
                                 _option("Kodi", "🎞", "Kodi fernsteuern und Streams senden", ziel={"art": "vorlage", "vorlage": "kodi"}),
                                 _option("Heim-Link", "🔖", "Lesezeichen zu Router, NAS, Weboberflächen", ziel={"art": "link"}),
                                 _option("Webseite oder Forum", "🌐", "phpMyAdmin, phpBB, WordPress, WoltLab Burning Board",
                                         ziel={"art": "bereich", "bereich": "webhosting"})]}
    k["speicher"] = {"frage": "Welcher Speicher?", "hinweis": "Danach Adresse, Benutzer und Passwort.",
                     "optionen": [_option(a["name"], "💾", a["hinweis"][:140], ziel={"art": "heimspeicher", "speicher": sid})
                                  for sid, a in heimspeicher.ARTEN.items()]}
    k["kamera"] = {"frage": "Welche Kamera?", "hinweis": "Die Adresse steht in der Anleitung oder App der Kamera.",
                   "optionen": [_option(v["name"], "📷", kameras.ARTEN[v["art"]], ziel={"art": "kamera", "kamera": n})
                                for n, v in enumerate(kameras.VORSCHLAEGE)]
                   + [_option("Andere Kamera", "📷", "Adresse selbst eintragen", ziel={"art": "kamera", "kamera": -1})]}
    k["sicherheit"] = {"frage": "Was möchtest du einrichten?", "hinweis": "Danach kannst du es gleich als Netzweg für alle Abrufe verwenden.",
                       "optionen": [_option("VPN (WireGuard)", "🔒", "Mullvad, Proton, AirVPN, FRITZ!Box …", "wireguard"),
                                    _option("Tor / I2P", "🧅", "Anonym über Orbot bzw. i2pd", "anonym"),
                                    _option("Proxy (SOCKS5/HTTP)", "↪", "Proxy deines VPN-Anbieters oder eigener", "proxy")]}
    k["wireguard"] = {"frage": "Welcher VPN-Anbieter?", "hinweis": "Die Konfigurationsdatei (.conf) erzeugst du beim Anbieter.",
                      "optionen": _aus_vorlagen(_vorlagen(lambda v: v["typ"] == "wireguard"))}
    k["anonym"] = {"frage": "Tor oder I2P?", "hinweis": "Die Apps Orbot (Tor) bzw. i2pd müssen laufen.",
                   "optionen": _aus_vorlagen(_vorlagen(lambda v: v["typ"] in ("tor", "i2p")))}
    k["proxy"] = {"frage": "Welcher Proxy?", "hinweis": "Server und Port vom Anbieter.",
                  "optionen": _aus_vorlagen(_vorlagen(lambda v: v["typ"] in ("socks5", "http-proxy")))}
    k["reiter"] = {"frage": "Was soll der Reiter zeigen?", "hinweis": "Eigene Reiter erscheinen oben und lassen sich verschieben.",
                   "optionen": [_option(v["name"], v.get("symbol", ""), v.get("text", ""), ziel={"art": "reiter", "vorlage": v["id"]})
                                for v in einstellungen.EIGENE_VORLAGEN]
                   + [_option("Andere App oder Webseite", "➕", "Paketname oder Adresse selbst eintragen", ziel={"art": "reiter", "vorlage": ""})]}
    # leere Knoten (z. B. ohne Rezepte) nicht anbieten
    for knoten in k.values():
        knoten["optionen"] = [o for o in knoten["optionen"] if "ziel" in o or (o.get("weiter") in k and k[o["weiter"]]["optionen"])]
    return {"start": "was", "knoten": k}


def verknuepfungen(typ, daten):
    """Passende naechste Schritte nach dem Anlegen eines Anbieters dieses Typs: [{"was", "text"}]."""
    eigene = list((daten.get("anbieter") or {}).values())
    hat = lambda t: any(e.get("typ") == t for e in eigene)
    v = []
    if typ == "nntp" and hat("rustnzb"):
        v.append({"was": "rustnzb_server", "text": "In rustnzb als Server eintragen (für NZB-Streams und Downloads)"})
    if typ == "nntp" and not hat("binsearch"):
        v.append({"was": "binsearch", "text": "binsearch als freie Usenet-Suche dazunehmen – ohne Konto, sofort"})
    if typ == "nntp" and (hat("nzbdav") or hat("altmount")):
        v.append({"was": "bereich:dienste", "text": "Den Provider auch in NzbDAV/AltMount eintragen (dort unter Settings → "
                                                    "Usenet), dann streamen NZB-Treffer ohne Download"})
    if typ in ("nzbdav", "altmount") and not hat("newznab") and not hat("binsearch"):
        v.append({"was": "binsearch", "text": "binsearch als freie Usenet-Suche dazunehmen – damit es etwas zu streamen gibt"})
    if typ == "nntp" and not hat("newznab") and not any(k == "easynews" for k in daten.get("einstellungen") or {}):
        v.append({"was": "weiter:indexer", "text": "Noch einen NZB-Indexer hinzufügen – damit es etwas zu finden gibt"})
    if typ == "newznab" and not hat("nntp"):
        v.append({"was": "weiter:nntp", "text": "Noch einen Usenet-Provider hinzufügen – der liefert die gefundenen Dateien"})
    if typ in ("xtream", "vxparser"):
        v.append({"was": "livetv", "text": "Als Live-TV-Senderliste aufnehmen (für IPTV-Apps und Live-TV)"})
    if typ in ("socks5", "http-proxy", "tor", "i2p"):
        v.append({"was": "netzweg", "text": "Als Netzweg verwenden – alle Abrufe laufen dann darüber"})
    if typ == "wireguard":
        v.append({"was": "bereich:sicherheit", "text": "Im Reiter Sicherheit verbinden"})
    if typ in ("nzbget", "sabnzbd", "nzbdav", "altmount", "rustnzb", "qbittorrent", "transmission", "deluge", "downloadmaster", "pihole",
               "sonarr", "radarr", "lidarr", "seerr", "prowlarr", "tautulli", "bazarr", "kodi"):
        v.append({"was": "bereich:dienste", "text": "Im Reiter Herunterladen ansehen"})
    if typ in ("stremio-addon", "mhub-addon", "debrid", "newznab", "torznab", "binsearch", "nzbdav", "altmount") or typ == "nntp":
        v.append({"was": "bereich:filme", "text": "Gleich einen Film suchen und die neuen Quellen sehen"})
    return v
