"""autostart.py – Gestaffelter Start von Modulen/Diensten beim H0rSt-Start.

Problem: Werden alle Dienste gleichzeitig gestartet, ueberlastet das den Prozessor
(besonders auf schwacher Hardware wie Pi oder Android). Loesung: jede Komponente
bekommt einen Zeitversatz in Sekunden relativ zur jeweils vorherigen.

Eintrag-Format:
  {
    "id":    str  – eindeutige Kennung (Modul-ID oder frei gewaehlter Name),
    "name":  str  – Anzeigename,
    "aktiv": bool – soll beim naechsten Start mitgestartet werden?,
    "sek":   int  – Sekunden Wartezeit nach dem vorherigen Eintrag (>= 0).
  }

Konfig-Schluessel: "autostart" (Liste der Eintraege, in Startreihenfolge).

Schnittstelle:
  GET  /api/autostart -> {eintraege, hinweis, gesamt_sek}
  POST /api/autostart {eintraege: [...]} -> 200 / 400

Dieses Modul berechnet nur; tatsaechlich verzögertes Starten macht die App selbst
(Android) oder die Verwaltungsschicht (Python, beim Einlesen der Konfig).
"""
from __future__ import annotations

HINWEIS = (
    "Legt fest, welche Dienste beim Start von H0rSt hochfahren und wie lange "
    "dazwischen gewartet wird. Groesserer Abstand = weniger Spitzen-Last. "
    "0 Sekunden heisst: sofort nach dem vorherigen."
)

_MIN_SEK = 0
_MAX_SEK = 300  # 5 Minuten Maximalversatz pro Schritt
_MAX_EINTRAEGE = 50


class AutostartFehler(ValueError):
    pass


# ---------------------------------------------------------------------------
# Standard-Vorbelegung (leer – die App befuellt das beim ersten Einrichten)
# ---------------------------------------------------------------------------
STANDARD: list[dict] = []


def _pruefen(eintraege: list) -> list:
    """Validiert und normalisiert eine Eintragsliste; wirft AutostartFehler bei Fehler."""
    if not isinstance(eintraege, list):
        raise AutostartFehler("eintraege muss eine Liste sein")
    if len(eintraege) > _MAX_EINTRAEGE:
        raise AutostartFehler(f"Zu viele Eintraege (max. {_MAX_EINTRAEGE})")
    ids = set()
    ergebnis = []
    for i, e in enumerate(eintraege):
        if not isinstance(e, dict):
            raise AutostartFehler(f"Eintrag {i} ist kein Objekt")
        eid = str(e.get("id") or "").strip()
        if not eid:
            raise AutostartFehler(f"Eintrag {i}: id fehlt")
        if eid in ids:
            raise AutostartFehler(f"Doppelte id: {eid!r}")
        ids.add(eid)
        name = str(e.get("name") or eid).strip()
        aktiv = bool(e.get("aktiv", True))
        try:
            sek = int(e.get("sek", 0))
        except (TypeError, ValueError):
            raise AutostartFehler(f"Eintrag {i}: sek muss eine Zahl sein")
        if not (_MIN_SEK <= sek <= _MAX_SEK):
            raise AutostartFehler(f"Eintrag {i}: sek muss zwischen {_MIN_SEK} und {_MAX_SEK} liegen")
        ergebnis.append({"id": eid, "name": name, "aktiv": aktiv, "sek": sek})
    return ergebnis


def zustand(daten: dict) -> dict:
    """Gibt den aktuellen Autostart-Zustand (aus konfig.json) zurueck."""
    roh = daten.get("autostart") or []
    try:
        eintraege = _pruefen(roh)
    except AutostartFehler:
        eintraege = []
    gesamt = sum(e["sek"] for e in eintraege if e.get("aktiv"))
    return {
        "eintraege": eintraege,
        "hinweis": HINWEIS,
        "gesamt_sek": gesamt,
    }


def speichern(daten: dict, eintraege: list) -> dict:
    """Validiert und schreibt die Eintragsliste in daten["autostart"].

    Gibt das normalisierte zustand()-Dict zurueck.
    Wirft AutostartFehler bei ungueltigem Input (nicht speichern).
    """
    normalisiert = _pruefen(eintraege)
    daten["autostart"] = normalisiert
    gesamt = sum(e["sek"] for e in normalisiert if e.get("aktiv"))
    return {
        "eintraege": normalisiert,
        "hinweis": HINWEIS,
        "gesamt_sek": gesamt,
    }
