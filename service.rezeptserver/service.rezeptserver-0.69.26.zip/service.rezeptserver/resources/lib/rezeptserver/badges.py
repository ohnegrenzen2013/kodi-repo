"""Stream-Badges wie in Nuvio: Regex-Regeln erkennen 4K, HDR, Dolby Vision, Atmos, Codec, Sprache ... im
Release-Namen und zeigen sie als farbige Marke oder Bild an den Streams.

Format (kompatibel zu Nuvios "Fusion badges", z. B. NardBadges, BetterFormatter, Minimalist):
  {"groups": [{"id", "name", "color", "borderColor"}],
   "filters": [{"id", "groupId", "name", "pattern", "imageURL", "tagColor", "borderColor", "textColor",
                "tagStyle", "isEnabled"}]}
Farben sind #AARRGGBB (Android) oder #RRGGBB. Die Regeln laufen auf dem Server (Python versteht "(?i)" am
Anfang, Browser nicht). Ab Werk gilt der eingebaute H0rSt-Satz; bis zu drei Sets lassen sich per Adresse
importieren (taeglich neu geladen, zwischengespeichert neben den Nutzerdaten).
Einstellungen in den Nutzerdaten unter "badges": {"an": true, "eigene": true, "urls": [...]}.
"""

import json
import logging
import os
import re
import threading
import time
import urllib.request

from .netz import USER_AGENT

log = logging.getLogger("rezeptserver")

SCHLUESSEL = "badges"
STANDARD = {"an": True, "eigene": True, "urls": []}
MAX_URLS = 3
MAX_JSON = 2 * 1024 * 1024
MAX_FILTER = 500
MAX_JE_STREAM = 10
ALTER = 24 * 3600
ORDNER = "badges"
# bekannte Sets aus der Nuvio-Gemeinschaft (siehe nuvio.wiki/settings/badges)
VORSCHLAEGE = [
    {"name": "NardBadges (mit Bildern, 100+)", "url": "https://raw.githubusercontent.com/vowl313/NardBadges/refs/heads/main/NardBadges.json"},
    {"name": "NardBadges Slim", "url": "https://raw.githubusercontent.com/vowl313/NardBadges/refs/heads/main/NardBadges_Slim.json"},
    {"name": "Minimalist (weiß)", "url": "https://raw.githubusercontent.com/sweatycab/nuvio-minimalist-badges/main/badges-white.json"},
    {"name": "Minimalist (gemischt)", "url": "https://raw.githubusercontent.com/sweatycab/nuvio-minimalist-badges/main/badges-mixed.json"},
]


def _f(fid, gruppe, name, muster, farbe):
    return {"id": fid, "groupId": gruppe, "name": name, "pattern": muster, "tagColor": farbe, "textColor": "#FF00160D",
            "borderColor": farbe, "tagStyle": "filled", "isEnabled": True, "type": "filter", "imageURL": ""}


_NICHT_NIEDRIGER = r"(?!.*(?:1080[pi]|720p|480p))"
# eingebauter H0rSt-Satz: schlicht, im Farbschema der Oberflaeche, ohne Bilder (laeuft auch ohne Internet)
EIGENE = {
    "groups": [{"id": "h-aufl", "name": "Auflösung"}, {"id": "h-quelle", "name": "Quelle"}, {"id": "h-bild", "name": "Bild"},
               {"id": "h-codec", "name": "Codec"}, {"id": "h-ton", "name": "Ton"}, {"id": "h-kanal", "name": "Kanäle"},
               {"id": "h-sprache", "name": "Sprache"}, {"id": "h-warn", "name": "Hinweis"}],
    "filters": [
        _f("h-4k", "h-aufl", "4K", r"(?i)(?=.*\b(?:2160[pi]|4k|uhd)\b)" + _NICHT_NIEDRIGER, "#FF00D588"),
        _f("h-1080", "h-aufl", "1080p", r"(?i)\b1080[pi]\b", "#FF6FE3B4"),
        _f("h-720", "h-aufl", "720p", r"(?i)\b720p\b", "#FFB8F0D9"),
        _f("h-sd", "h-aufl", "SD", r"(?i)\b(?:480p|576p|sd|dvdrip)\b", "#FFA3A3A3"),
        _f("h-remux", "h-quelle", "Remux", r"(?i)\bremux\b", "#FFFFD166"),
        _f("h-bluray", "h-quelle", "BluRay", r"(?i)\b(?:blu-?ray|bdrip|brrip|bd25|bd50)\b(?!.*remux)", "#FFFFE29A"),
        _f("h-webdl", "h-quelle", "WEB-DL", r"(?i)\bweb-?dl\b", "#FF9AD0FF"),
        _f("h-webrip", "h-quelle", "WEBRip", r"(?i)\bweb-?rip\b", "#FFB9DCFF"),
        _f("h-hdtv", "h-quelle", "HDTV", r"(?i)\bhdtv\b", "#FFD0D0D0"),
        _f("h-dv", "h-bild", "Dolby Vision", r"(?i)\b(?:dv|dovi|dolby[ .-]?vision)\b", "#FFC9A0FF"),
        _f("h-hdr10p", "h-bild", "HDR10+", r"(?i)\bhdr10(?:\+|plus)", "#FFFFB066"),
        _f("h-hdr", "h-bild", "HDR", r"(?i)\bhdr(?:10)?\b(?!\+|plus)", "#FFFFC58A"),
        _f("h-av1", "h-codec", "AV1", r"(?i)\bav1\b", "#FFE0E0E0"),
        _f("h-hevc", "h-codec", "HEVC", r"(?i)\b(?:hevc|[hx][ .]?265)\b", "#FFE0E0E0"),
        _f("h-avc", "h-codec", "H.264", r"(?i)\b(?:avc|[hx][ .]?264)\b", "#FFC8C8C8"),
        _f("h-atmos", "h-ton", "Atmos", r"(?i)\batmos\b", "#FF7FD1FF"),
        _f("h-truehd", "h-ton", "TrueHD", r"(?i)\btrue-?hd\b", "#FF9FDCFF"),
        _f("h-dtsx", "h-ton", "DTS:X", r"(?i)\bdts[ .:-]?x\b", "#FF9FDCFF"),
        _f("h-dtshd", "h-ton", "DTS-HD MA", r"(?i)\bdts[ .-]?hd(?:[ .-]?ma)?\b", "#FFB5E4FF"),
        _f("h-dts", "h-ton", "DTS", r"(?i)\bdts\b(?![ .:-]?(?:x|hd))", "#FFC8EBFF"),
        _f("h-ddp", "h-ton", "DD+", r"(?i)\b(?:ddp|dd\+|e-?ac-?3|eac3)(?=\d|\b)", "#FFC8EBFF"),
        _f("h-dd", "h-ton", "DD", r"(?i)\b(?:dd|ac-?3)(?=[257]\.?[01]|\b)(?!\+)", "#FFD8F1FF"),
        _f("h-71", "h-kanal", "7.1", r"(?i)(?<!\d)(?<!\d\.)7[ .]1(?!\d)", "#FFEDEDED"),
        _f("h-51", "h-kanal", "5.1", r"(?i)(?<!\d)(?<!\d\.)5[ .]1(?!\d)", "#FFEDEDED"),
        _f("h-de", "h-sprache", "Deutsch", r"(?i)\b(?:german|deutsch|ger)\b(?!.*\b(?:dl|dual)\b)", "#FFFFE08A"),
        _f("h-dl", "h-sprache", "DE + EN", r"(?i)\b(?:german|ger)\b.*\b(?:dl|dual)\b|\bdual[ .-]?audio\b", "#FFFFE08A"),
        _f("h-multi", "h-sprache", "Multi", r"(?i)\bmulti\b", "#FFFFE9B3"),
        _f("h-cam", "h-warn", "Kino-Mitschnitt", r"(?i)\b(?:cam|camrip|hdcam|ts|telesync|hdts|tc|telecine)\b", "#FFFFB066"),
    ],
}


class BadgeFehler(ValueError):
    pass


def pruefe(roh):
    e = dict(STANDARD)
    if isinstance(roh, dict):
        e.update({k: roh[k] for k in STANDARD if k in roh})
    e["an"] = e["an"] is not False
    e["eigene"] = e["eigene"] is not False
    urls = e["urls"] if isinstance(e["urls"], list) else []
    urls = [str(u).strip() for u in urls if str(u).strip()]
    if len(urls) > MAX_URLS:
        raise BadgeFehler("Höchstens %d Badge-Sets" % MAX_URLS)
    for u in urls:
        if not u.lower().startswith(("http://", "https://")):
            raise BadgeFehler("Adresse muss mit http(s):// beginnen: %s" % u)
        if "github.com/" in u and "/blob/" in u:
            raise BadgeFehler("Bitte die Raw-Adresse nehmen (raw.githubusercontent.com), nicht die GitHub-Seite")
    e["urls"] = urls
    return e


def farbe(wert):
    """#AARRGGBB (Android) oder #RRGGBB -> CSS #RRGGBBAA bzw. #RRGGBB; ungueltig -> ''."""
    w = str(wert or "").strip()
    if re.match(r"^#[0-9a-fA-F]{8}$", w):
        return "#" + w[3:] + w[1:3]
    if re.match(r"^#[0-9a-fA-F]{6}$", w):
        return w
    return ""


def kompilieren(satz, quelle=""):
    """Set -> [(regex, badge)] in Gruppen-Reihenfolge; kaputte Regeln werden uebersprungen."""
    if not isinstance(satz, dict) or not isinstance(satz.get("filters"), list):
        raise BadgeFehler("%s: kein Badge-Set (filters fehlt)" % (quelle or "JSON"))
    gruppen = {g.get("id"): (i, g) for i, g in enumerate(satz.get("groups") or []) if isinstance(g, dict)}
    regeln = []
    for f in satz["filters"][:MAX_FILTER]:
        if not isinstance(f, dict) or f.get("isEnabled") is False or not f.get("pattern"):
            continue
        try:
            rx = re.compile(str(f["pattern"]))
        except re.error:
            continue
        rang, gruppe = gruppen.get(f.get("groupId"), (len(gruppen), {}))
        bild = str(f.get("imageURL") or "")
        regeln.append((rang, rx, {
            "name": str(f.get("name") or "")[:40], "gruppe": str(gruppe.get("name") or "")[:40],
            "bild": bild if bild.lower().startswith("https://") else "",
            "farbe": farbe(f.get("tagColor")), "rand": farbe(f.get("borderColor") or gruppe.get("borderColor")),
            "text": farbe(f.get("textColor")) or "#ededed"}))
    regeln.sort(key=lambda r: r[0])
    return [(rx, b) for _, rx, b in regeln]


def _holen_standard(url):
    with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": USER_AGENT}), timeout=30) as a:
        return a.read(MAX_JSON + 1)


class Badges:
    """Haelt die Regeln (eingebaut + importiert) und ordnet Streams Badges zu."""

    def __init__(self, einstellung=None, ordner=None, holen=None):
        self.ordner = os.path.join(ordner or ".", ORDNER)
        self.holen = holen or _holen_standard
        self._sperre = threading.Lock()
        self.zustaende = {}
        self.setzen(einstellung)  # nur Zwischenspeicher; Nachladen: im_hintergrund_laden()

    def setzen(self, einstellung, laden=False):
        """Einstellung uebernehmen. laden=False: nur Zwischenspeicher (schnell, z. B. beim Start)."""
        self.einstellung = pruefe(einstellung)
        eigene = kompilieren(EIGENE, "H0rSt") if self.einstellung["eigene"] else []
        importiert = []
        for url in self.einstellung["urls"]:
            importiert.extend(self._set(url, laden))
        # importierte Sets zuerst (Nuvio-Optik), danach die eigenen fuer alles, was sie nicht abdecken
        with self._sperre:
            self.regeln = importiert + eigene

    def im_hintergrund_laden(self):
        """Veraltete oder fehlende Sets nachladen, ohne den Aufrufer warten zu lassen."""
        if self.einstellung["urls"]:
            einstellung = dict(self.einstellung)
            threading.Thread(target=self.setzen, args=(einstellung, True), name="badges", daemon=True).start()

    def _datei(self, url):
        import hashlib
        return os.path.join(self.ordner, hashlib.sha1(url.encode("utf-8")).hexdigest()[:16] + ".json")

    def _set(self, url, laden=True):
        datei = self._datei(url)
        alt = None
        try:
            frisch = time.time() - os.path.getmtime(datei) < ALTER
            with open(datei, encoding="utf-8") as f:
                alt = json.load(f)
            if frisch or not laden:
                return self._merken(url, kompilieren(alt, url), "")
        except (OSError, ValueError, BadgeFehler):
            pass
        if not laden:
            return self._merken(url, [], "wird geladen …")
        try:
            roh = self.holen(url)
            if len(roh) > MAX_JSON:
                raise BadgeFehler("größer als 2 MB")
            satz = json.loads(roh.decode("utf-8-sig"))
            regeln = kompilieren(satz, url)
            os.makedirs(self.ordner, exist_ok=True)
            with open(datei, "w", encoding="utf-8") as f:
                json.dump(satz, f)
            return self._merken(url, regeln, "")
        except Exception as fehler:
            if alt is not None:
                return self._merken(url, kompilieren(alt, url), "nicht erneuerbar: %s" % fehler)
            log.warning("Badges %s: %s", url, fehler)
            return self._merken(url, [], str(fehler)[:200])

    def _merken(self, url, regeln, fehler):
        self.zustaende[url] = {"url": url, "anzahl": len(regeln), "fehler": fehler}
        return regeln

    def zuordnen(self, text):
        """Badges zu einem Release-Namen; je Name einmal, hoechstens MAX_JE_STREAM."""
        if not self.einstellung["an"] or not text:
            return []
        with self._sperre:
            regeln = list(self.regeln)
        gefunden, namen = [], set()
        for rx, badge in regeln:
            schluessel = badge["name"].lower()
            if schluessel in namen:
                continue
            try:
                if rx.search(text):
                    gefunden.append(badge)
                    namen.add(schluessel)
            except (re.error, RecursionError):
                continue
            if len(gefunden) >= MAX_JE_STREAM:
                break
        return gefunden

    def zustand(self):
        return {"einstellung": self.einstellung, "vorschlaege": VORSCHLAEGE,
                "sets": [self.zustaende.get(u, {"url": u, "anzahl": 0, "fehler": ""}) for u in self.einstellung["urls"]],
                "eigene_anzahl": len(EIGENE["filters"])}
