"""Benachrichtigungen (Vorbild Netflix): neue Folgen fuer Serien in Weiterschauen/Merkliste. Muster wie
sehen.py's verlauf - Vorne-Einfuegen, Deckel auf MAX_LISTE, eine Liste je Profil.

Einzige Quelle: ein Vergleich der aktuellen Cinemeta-Folgenzahl jeder Serie gegen den zuletzt bekannten
Stand (eigener, kleiner Zwischenspeicher je Profil+Serie). Kein Push, keine externe Quelle - die Liste
wird bei jedem Seitenaufruf neu abgeglichen (pruefen()). Eine Serie, die zum ersten Mal geprueft wird,
merkt sich nur ihren Stand, ohne zu benachrichtigen (sonst waere jede schon laenger bekannte Serie beim
allerersten Check faelschlich "neu").
"""

import time

SCHLUESSEL = "benachrichtigungen"
STAND_SCHLUESSEL = "benachrichtigungen_stand"
MAX_LISTE = 50


def lesen(daten, profil_id=""):
    return list(daten.get(SCHLUESSEL, {}).get(profil_id or "", []))


def pruefen(daten, profil_id, serien, entdecken, uhr=time.time):
    """serien: Karten (mit "id"/"typ"/"titel") aus Weiterschauen/Merkliste. Gibt die neu entstandenen
    Eintraege zurueck (leer, wenn nichts Neues) - wirft nie, eine einzelne kaputte Serie darf den
    restlichen Abgleich nicht abbrechen."""
    profil_id = profil_id or ""
    stand = daten.setdefault(STAND_SCHLUESSEL, {}).setdefault(profil_id, {})
    liste = daten.setdefault(SCHLUESSEL, {}).setdefault(profil_id, [])
    neu = []
    gesehen = set()
    for s in serien or []:
        if not isinstance(s, dict) or s.get("typ") != "series":
            continue
        sid = s.get("id")
        if not sid or sid in gesehen:
            continue
        gesehen.add(sid)
        try:
            info = entdecken.details("series", sid)
        except Exception:  # Cinemeta nicht erreichbar/Titel weg - diese Serie einfach ueberspringen
            continue
        anzahl = len(info.get("folgen") or [])
        bekannt = stand.get(sid)
        stand[sid] = anzahl
        if bekannt is not None and anzahl > bekannt:
            eintrag = {"id": "%s:%d:%d" % (sid, anzahl, int(uhr())), "titel": s.get("titel") or info.get("titel") or "",
                       "text": "Neue Folge verfügbar", "zeit": uhr()}
            liste.insert(0, eintrag)
            neu.append(eintrag)
    del liste[MAX_LISTE:]
    return neu
