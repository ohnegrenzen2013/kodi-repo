"""Beobachtungen (Idee: autofetch.de): Suchen einmal anlegen, H0rSt prueft regelmaessig und meldet neue Treffer.

Autofetch beschreibt: Suchanfragen einmal definieren, Quellen (Mediathek, RSS/JSON-Feeds, GitHub-Releases, GitLab,
eigene Indexer ...) wiederholt pruefen, auch wenn ein Inhalt erst spaeter erscheint ("warten auf Verfuegbarkeit"),
und passende Treffer als Job an einen verbundenen Client uebergeben - der Server steuert, der Client laedt.
Hier: eigene Umsetzung (nichts von autofetch uebernommen, kein Konto dort noetig) mit offenen, dokumentierten Quellen:

  feed       RSS 2.0 / Atom (Adresse vom Nutzer)                         W3C/IETF-Standard (RFC 4287)
  json       JSON Feed 1.0/1.1 (Adresse vom Nutzer)                      jsonfeed.org, Spezifikation offen
  github     Releases oeffentlicher Repos (api.github.com, ohne Token)   docs.github.com/rest/releases
  gitlab     Releases oeffentlicher Projekte (gitlab.com/api/v4)         docs.gitlab.com/api/releases
  mediathek  MediathekViewWeb-API (oeffentlich-rechtliche Mediatheken)   github.com/mediathekview (MIT)
  indexer    die eigenen Newznab-Indexer des Nutzers (Schluessel bleiben dort)

Alles ist ab Werk AUS. Es gibt keine mitgelieferten Quellen. Beim ersten Lauf werden vorhandene Treffer nur gelistet
(Status "vorhanden"), nie automatisch uebergeben; automatisch an den eigenen Downloader gehen nur NEUE Treffer und
hoechstens MAX_UEBERGABE je Lauf. "Einmalig" beendet eine Beobachtung nach dem ersten neuen Treffer.
Einstellungen (inkl. Adressen, die Zugangsschluessel tragen koennen) liegen in den Nutzerdaten unter "beobachtungen";
der Stand (gesehen, Treffer) in beobachtungen.json - Adressen mit Schluessel-Parametern kommen dort NICHT hinein.
"""

import json
import logging
import os
import re
import threading
import time
from urllib.parse import quote, urlencode, urlsplit

from .beobachtungen_grund import *
from .beobachtungen_grund import _GEHEIM, _GITLAB, _REPO, _kennung, _text
from .beobachtungen_quellen import *
from .beobachtungen_quellen import _art_von, _kind

log = logging.getLogger("rezeptserver")


class Beobachtungen:
    """Prueft die Beobachtungen im Hintergrund. holen(url, methode, header, daten, zeitgrenze) -> (status, text);
    indexer(text) -> Liste {titel, nzb_url, datum, groesse}; uebergabe(ziel, treffer, beobachtung) -> Meldung (wirft bei Fehler)."""

    def __init__(self, verwaltung, ordner, holen=None, indexer=None, uebergabe=None, uhr=time.time):
        self.verwaltung = verwaltung
        self.pfad = os.path.join(ordner, DATEI) if ordner else None
        self._holen = holen
        self.indexer = indexer
        self.uebergabe = uebergabe
        self.uhr = uhr
        self._sperre = threading.RLock()
        self._halt = threading.Event()
        self._faden = None
        self._stand = self._laden()
        self._speicher = {}      # nur im Speicher: Adressen mit Schluessel-Parametern (kennung -> url)
        self.laeuft_gerade = False

    # --- Stand ----------------------------------------------------------------------------------------------
    def _laden(self):
        try:
            with open(self.pfad, encoding="utf-8") as f:
                d = json.load(f)
            return d if isinstance(d, dict) else {}
        except (OSError, TypeError, ValueError):
            return {}

    def _sichern(self):
        if not self.pfad:
            return
        try:
            temp = self.pfad + ".neu"
            with open(temp, "w", encoding="utf-8") as f:
                json.dump(self._stand, f, ensure_ascii=False)
            os.replace(temp, self.pfad)
        except OSError as fehler:
            log.warning("Beobachtungen: Stand nicht speicherbar: %s", fehler)

    def einstellung(self):
        daten = self.verwaltung.daten() if self.verwaltung else {}
        return pruefe(daten.get(SCHLUESSEL))

    def _speichern_einstellung(self, e):
        e = pruefe(e)
        self.verwaltung.bearbeiten(lambda d: d.__setitem__(SCHLUESSEL, e))
        return e

    # --- Anzeige --------------------------------------------------------------------------------------------
    def zustand(self):
        e = self.einstellung()
        liste = []
        with self._sperre:
            for b in e["liste"]:
                s = self._stand.get(b["id"]) or {}
                liste.append(dict(b, quelle=url_zeigen(b["quelle"]), quelle_geheim=hat_geheimnis(b["quelle"]) if b["quelle"] else False,
                                  letzte_pruefung=s.get("pruefung"), fehler=s.get("fehler", ""), anzahl_gesehen=len(s.get("gesehen") or []),
                                  treffer=[dict(t, url=url_zeigen(self._speicher.get(t["id"]) or t.get("url") or ""),
                                                uebergabefaehig=bool(self._speicher.get(t["id"]) or t.get("url")))
                                           for t in (s.get("treffer") or [])]))
        return {"an": e["an"], "minuten": e["minuten"], "minuten_stufen": list(MINUTEN), "arten": ARTEN, "liste": liste,
                "laeuft": self.laeuft_gerade, "uebergabe": self.uebergabe is not None}

    # --- Aendern --------------------------------------------------------------------------------------------
    def einstellen(self, neu):
        e = self.einstellung()
        for k in ("an", "minuten"):
            if k in neu:
                e[k] = neu[k]
        self._speichern_einstellung(e)
        return self.zustand()

    def speichern(self, roh):
        e = self.einstellung()
        roh = dict(roh)
        alt_id = next((a for a in e["liste"] if a["id"] == str(roh.get("id") or "")), None)
        if alt_id and not str(roh.get("quelle") or "").strip():
            roh["quelle"] = alt_id["quelle"]  # Adresse mit Schluessel wird nie angezeigt: leer lassen = behalten
        b = pruefe_eine(roh)
        for i, alt in enumerate(e["liste"]):
            if alt["id"] == b["id"]:
                e["liste"][i] = b
                break
        else:
            if len(e["liste"]) >= MAX_BEOBACHTUNGEN:
                raise BeobachtungFehler("Höchstens %d Beobachtungen" % MAX_BEOBACHTUNGEN)
            e["liste"].append(b)
        self._speichern_einstellung(e)
        with self._sperre:
            if b["id"] in self._stand and roh.get("neu_beginnen"):
                self._stand.pop(b["id"], None)
                self._sichern()
        return self.zustand()

    def loeschen(self, kennung):
        e = self.einstellung()
        e["liste"] = [b for b in e["liste"] if b["id"] != kennung]
        self._speichern_einstellung(e)
        with self._sperre:
            self._stand.pop(kennung, None)
            for t in [k for k in self._speicher if k.startswith(kennung)]:
                self._speicher.pop(t, None)
            self._sichern()
        return self.zustand()

    # --- Pruefen --------------------------------------------------------------------------------------------
    def _abruf(self, url, methode="GET", header=None, daten=None):
        from .netz import Abrufer, oeffentlich_holen, urllib_holen
        holen = self._holen or oeffentlich_holen(urllib_holen)
        return Abrufer([urlsplit(url).hostname or ""], holen=holen, zeitgrenze=20.0).abruf(url, methode, header, daten)

    def _kandidaten(self, b):
        art = b["art"]
        if art == "feed":
            return feed_lesen(self._abruf(b["quelle"], header={"Accept": "application/rss+xml, application/atom+xml, application/xml"}))
        if art == "json":
            return jsonfeed_lesen(self._abruf(b["quelle"], header={"Accept": "application/feed+json, application/json"}))
        if art == "github":
            url = "https://api.github.com/repos/%s/releases?%s" % (b["quelle"], urlencode({"per_page": 20}))
            return github_lesen(self._abruf(url, header={"Accept": "application/vnd.github+json", "X-GitHub-Api-Version": "2022-11-28"}), b["quelle"])
        if art == "gitlab":
            url = "https://gitlab.com/api/v4/projects/%s/releases?%s" % (quote(b["quelle"], safe=""), urlencode({"per_page": 20}))
            return gitlab_lesen(self._abruf(url, header={"Accept": "application/json"}), b["quelle"])
        if art == "mediathek":
            text = self._abruf("https://mediathekviewweb.de/api/query", "POST", {"Content-Type": "text/plain"}, mediathek_anfrage(b["suche"]))
            return mediathek_lesen(text)
        if art == "indexer":
            if self.indexer is None:
                raise BeobachtungFehler("Indexer-Suche nicht verfügbar")
            return [{"id": _kennung("ix", t.get("nzb_url")), "titel": t["titel"], "url": t["nzb_url"], "datum": str(t.get("datum") or ""),
                     "groesse": t.get("groesse") or 0, "art": "nzb"} for t in self.indexer(b["suche"])[:MAX_ITEMS] if t.get("nzb_url") and t.get("titel")]
        return []

    def pruefen_eine(self, b):
        """Eine Beobachtung pruefen. Gibt (neue, fehler) zurueck."""
        start = self.uhr()
        zeit = time.strftime("%Y-%m-%d %H:%M", time.localtime(start))
        try:
            kandidaten = self._kandidaten(b)
            fehler = ""
        except Exception as f:  # eine Quelle darf ausfallen
            kandidaten, fehler = [], re.sub(r"(?:https?|magnet):\S+", lambda m: url_zeigen(m.group(0)), str(f))[:240]
        with self._sperre:
            s = self._stand.setdefault(b["id"], {})
            s["pruefung"] = zeit
            s["fehler"] = fehler
            s["naechste"] = start + (b["minuten"] or self.einstellung()["minuten"]) * 60
            if fehler:
                self._sichern()
                return [], fehler
            erste = "gesehen" not in s
            gesehen = list(s.get("gesehen") or [])
            bekannt = set(gesehen)
            neue = []
            for k in kandidaten:
                if k["id"] in bekannt:
                    continue
                if not passt(k["titel"], b["suche"]):
                    continue
                if b["min_mb"] and k.get("groesse") and k["groesse"] < b["min_mb"] * 1048576:
                    continue
                bekannt.add(k["id"])
                gesehen.append(k["id"])
                neue.append(k)
            s["gesehen"] = gesehen[-MAX_GESEHEN:]
            treffer = list(s.get("treffer") or [])
            for k in neue:
                geheim = hat_geheimnis(k["url"])
                if geheim:
                    self._speicher[k["id"]] = k["url"]
                treffer.insert(0, {"id": k["id"], "titel": k["titel"], "url": "" if geheim else k["url"], "datum": k["datum"], "groesse": k["groesse"],
                                   "art": k["art"], "gefunden": zeit, "status": "vorhanden" if erste else "neu"})
            s["treffer"] = treffer[:MAX_TREFFER]
            self._sichern()
        if neue and not erste:
            if b["einmalig"]:
                self._beenden(b["id"])
            if b["uebergeben"] and b["ziel"] and self.uebergabe:
                for k in neue[:MAX_UEBERGABE]:
                    if k["art"] != "info":
                        self.uebergeben(b["id"], k["id"])
        return neue, ""

    def _beenden(self, kennung):
        def aus(d):
            e = pruefe(d.get(SCHLUESSEL))
            for b in e["liste"]:
                if b["id"] == kennung:
                    b["an"] = False
            d[SCHLUESSEL] = e
        try:
            self.verwaltung.bearbeiten(aus)
        except Exception:
            log.exception("Beobachtungen: einmalig beenden")

    def uebergeben(self, bid, tid, ziel=None):
        """Einen Treffer an den Downloader geben (auf Klick oder automatisch bei neuen Treffern)."""
        if not self.uebergabe:
            raise BeobachtungFehler("Kein Downloader verfügbar")
        b = next((x for x in self.einstellung()["liste"] if x["id"] == bid), None)
        if b is None:
            raise BeobachtungFehler("Beobachtung gibt es nicht (mehr)")
        with self._sperre:
            s = self._stand.get(bid) or {}
            t = next((x for x in (s.get("treffer") or []) if x["id"] == tid), None)
            if t is None:
                raise BeobachtungFehler("Treffer gibt es nicht (mehr)")
            url = self._speicher.get(tid) or t.get("url")
        if not url:
            raise BeobachtungFehler("Die Adresse trägt einen Schlüssel und liegt nur im Speicher – nach einem Neustart bitte „Jetzt prüfen“ und neu anlegen")
        ziel = ziel or b["ziel"]
        if not ziel:
            raise BeobachtungFehler("Kein Downloader gewählt")
        try:
            meldung = self.uebergabe(ziel, dict(t, url=url), b)
            status = "übergeben"
        except Exception as f:
            meldung, status = str(f)[:160], "fehler"
        with self._sperre:
            t["status"] = status
            t["meldung"] = meldung
            self._sichern()
        if status == "fehler":
            raise BeobachtungFehler(meldung)
        return meldung

    def pruefen(self, nur=None):
        """Alle (oder eine) Beobachtungen pruefen; wird auch mit "an" aus ausgeloest, wenn der Nutzer es verlangt."""
        e = self.einstellung()
        self.laeuft_gerade = True
        try:
            for b in e["liste"]:
                if nur and b["id"] != nur:
                    continue
                if not nur and not b["an"]:
                    continue
                self.pruefen_eine(b)
        finally:
            self.laeuft_gerade = False
        return self.zustand()

    def faellig(self):
        e = self.einstellung()
        jetzt = self.uhr()
        ergebnis = []
        for b in e["liste"]:
            if b["an"] and jetzt >= (self._stand.get(b["id"]) or {}).get("naechste", 0):
                ergebnis.append(b)
        return ergebnis if e["an"] else []

    # --- im Hintergrund -------------------------------------------------------------------------------------
    def starten(self):
        if self._faden is None and self.verwaltung:
            self._halt.clear()
            self._faden = threading.Thread(target=self._schleife, name="beobachtungen", daemon=True)
            self._faden.start()

    def stoppen(self):
        self._halt.set()

    def _schleife(self):
        self._halt.wait(90)
        while not self._halt.is_set():
            try:
                for b in self.faellig():
                    if self._halt.is_set():
                        break
                    self.pruefen_eine(b)
                    self._halt.wait(2)  # keine Anfragen-Salve an die Quellen
            except Exception:
                log.exception("Beobachtungen")
            self._halt.wait(60)
