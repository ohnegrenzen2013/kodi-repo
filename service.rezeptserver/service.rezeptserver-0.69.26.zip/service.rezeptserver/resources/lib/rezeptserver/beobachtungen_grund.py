"""Beobachtungen: Konstanten, Fehler und gemeinsame Pruefungen."""

import hashlib
import os
import re
import time
from urllib.parse import urlsplit


SCHLUESSEL = "beobachtungen"
DATEI = "beobachtungen.json"
ARTEN = {"feed": "RSS-/Atom-Feed", "json": "JSON-Feed", "github": "GitHub-Releases", "gitlab": "GitLab-Releases",
         "mediathek": "Mediathek (ÖR)", "indexer": "Meine Indexer (Usenet)"}
MINUTEN = (15, 30, 60, 180, 720, 1440)
STANDARD = {"an": False, "minuten": 60, "liste": []}
MAX_BEOBACHTUNGEN = 30
MAX_GESEHEN = 600
MAX_TREFFER = 60
MAX_UEBERGABE = 5
MAX_ITEMS = 200
_GEHEIM = re.compile(r"(?i)^(api_?key|apikey|key|token|passkey|pass|password|auth|secret|rsskey|sig|signature|i|r)$")
_REPO = re.compile(r"^[A-Za-z0-9_.-]{1,100}/[A-Za-z0-9_.-]{1,100}$")
_GITLAB = re.compile(r"^[A-Za-z0-9_.-]+(?:/[A-Za-z0-9_.-]+){1,8}$")


class BeobachtungFehler(ValueError):
    pass


def hat_geheimnis(url):
    """true, wenn die Adresse einen Zugangsschluessel als Parameter traegt (dann nie auf die Platte, nie in die Antwort)."""
    try:
        teile = urlsplit(url)
    except ValueError:
        return True
    if teile.username or teile.password:
        return True
    return any(_GEHEIM.match(p.split("=", 1)[0]) for p in teile.query.split("&") if p)


def url_zeigen(url):
    """Adresse fuer die Oberflaeche: ohne Parameter, wenn einer nach Schluessel aussieht."""
    if not url:
        return ""
    return urlsplit(url)._replace(query="", fragment="", netloc=urlsplit(url).hostname or "").geturl() if hat_geheimnis(url) else url


def _kennung(*teile):
    return hashlib.sha1("\x1f".join(str(t) for t in teile).encode("utf-8", "replace")).hexdigest()[:16]


def _text(wert, grenze):
    return " ".join(str(wert or "").split())[:grenze]


def pruefe_eine(roh, vorhandene_ids=()):
    if not isinstance(roh, dict):
        raise BeobachtungFehler("Beobachtung muss ein Objekt sein")
    art = str(roh.get("art") or "")
    if art not in ARTEN:
        raise BeobachtungFehler("Art muss eine von %s sein" % ", ".join(ARTEN))
    quelle = str(roh.get("quelle") or "").strip()[:500]
    if art in ("feed", "json"):
        t = urlsplit(quelle)
        if t.scheme not in ("http", "https") or not t.hostname:
            raise BeobachtungFehler("Adresse des Feeds muss mit http:// oder https:// beginnen")
    elif art == "github":
        quelle = re.sub(r"^https?://(www\.)?github\.com/", "", quelle).strip("/")
        quelle = re.sub(r"\.git$", "", quelle)
        quelle = "/".join(quelle.split("/")[:2])
        if not _REPO.match(quelle) or any(not p.strip(".") for p in quelle.split("/")):
            raise BeobachtungFehler("GitHub: bitte „besitzer/repo“ eintragen")
    elif art == "gitlab":
        quelle = re.sub(r"^https?://(www\.)?gitlab\.com/", "", quelle).strip("/")
        if not _GITLAB.match(quelle) or any(not p.strip(".") for p in quelle.split("/")):
            raise BeobachtungFehler("GitLab: bitte „gruppe/projekt“ (gitlab.com) eintragen")
    else:
        quelle = ""
    suche = _text(roh.get("suche"), 200)
    if art in ("mediathek", "indexer") and len(suche) < 2:
        raise BeobachtungFehler("Suchbegriff eintragen (mindestens 2 Zeichen)")
    kennung = str(roh.get("id") or "")
    if not re.match(r"^[0-9a-f]{8,16}$", kennung):
        kennung = _kennung(art, quelle, suche, time.time(), os.urandom(4).hex())
    minuten = roh.get("minuten")
    try:
        minuten = int(minuten) if minuten not in (None, "") else 0
    except (TypeError, ValueError):
        raise BeobachtungFehler("minuten muss eine Zahl sein")
    if minuten and minuten not in MINUTEN:
        raise BeobachtungFehler("minuten muss eine von %s sein" % ", ".join(map(str, MINUTEN)))
    try:
        min_mb = max(0, min(int(roh.get("min_mb") or 0), 200000))
    except (TypeError, ValueError):
        raise BeobachtungFehler("min_mb muss eine Zahl sein")
    return {"id": kennung, "name": _text(roh.get("name"), 80) or (suche or url_zeigen(quelle))[:60] or ARTEN[art], "art": art,
            "quelle": quelle, "suche": suche, "an": roh.get("an") is not False, "einmalig": roh.get("einmalig") is True,
            "uebergeben": roh.get("uebergeben") is True, "ziel": _text(roh.get("ziel"), 64),
            "kategorie": _text(roh.get("kategorie"), 40), "minuten": minuten, "min_mb": min_mb}


def pruefe(roh):
    e = {"an": False, "minuten": STANDARD["minuten"], "liste": []}
    if isinstance(roh, dict):
        e["an"] = roh.get("an") is True
        if roh.get("minuten") is not None:
            try:
                e["minuten"] = int(roh["minuten"])
            except (TypeError, ValueError):
                raise BeobachtungFehler("minuten muss eine Zahl sein")
        liste = roh.get("liste") or []
        if not isinstance(liste, list):
            raise BeobachtungFehler("liste muss eine Liste sein")
        if len(liste) > MAX_BEOBACHTUNGEN:
            raise BeobachtungFehler("Höchstens %d Beobachtungen" % MAX_BEOBACHTUNGEN)
        ids = set()
        for w in liste:
            b = pruefe_eine(w)
            if b["id"] in ids:
                raise BeobachtungFehler("Doppelte Kennung")
            ids.add(b["id"])
            e["liste"].append(b)
    if e["minuten"] not in MINUTEN:
        raise BeobachtungFehler("minuten muss eine von %s sein" % ", ".join(map(str, MINUTEN)))
    return e


def passt(titel, suche):
    """Alle Woerter muessen im Titel stehen; "-wort" schliesst aus; "ohne Suche" passt immer."""
    t = str(titel or "").lower()
    for wort in str(suche or "").lower().split():
        if wort.startswith("-") and len(wort) > 1:
            if wort[1:] in t:
                return False
        elif wort not in t:
            return False
    return True
