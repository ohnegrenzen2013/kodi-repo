"""Beobachtungen: RSS, JSON-Feed, GitHub, GitLab und Mediathek lesen."""

import json
import re
import xml.etree.ElementTree as ET

from .beobachtungen_grund import BeobachtungFehler, MAX_ITEMS, _kennung, _text


# --- Quellen: jede liefert [{"id", "titel", "url", "datum", "groesse", "art": nzb|torrent|link|info}] ----------------
def _kind(el):
    return el.tag.rsplit("}", 1)[-1] if isinstance(el.tag, str) else ""


def _art_von(url, typ=""):
    u = (url or "").lower().split("?")[0]
    if u.startswith("magnet:") or u.endswith(".torrent") or "bittorrent" in (typ or ""):
        return "torrent"
    if u.endswith(".nzb") or "nzb" in (typ or ""):
        return "nzb"
    return "link"


def feed_lesen(text):
    """RSS 2.0 oder Atom. DOCTYPE/ENTITY werden abgelehnt (keine Entity-Tricks)."""
    if re.search(r"<!(DOCTYPE|ENTITY)", text[:4000] + text[-200:], re.I):
        raise BeobachtungFehler("Feed mit DOCTYPE/ENTITY wird nicht gelesen")
    try:
        wurzel = ET.fromstring(text.strip().encode("utf-8"))
    except ET.ParseError as fehler:
        raise BeobachtungFehler("Kein gültiger Feed: %s" % fehler)
    ergebnis = []
    for item in wurzel.iter():
        if _kind(item) not in ("item", "entry"):
            continue
        feld = {}
        enc = None
        for k in item:
            n = _kind(k)
            if n == "link" and k.get("href"):
                if k.get("rel") == "enclosure":
                    enc = enc or (k.get("href"), k.get("type") or "", k.get("length") or "")
                elif k.get("rel") in (None, "alternate"):
                    feld.setdefault("link", k.get("href"))
            elif n == "enclosure" and k.get("url"):
                enc = enc or (k.get("url"), k.get("type") or "", k.get("length") or "")
            elif n in ("title", "link", "guid", "id", "pubDate", "updated", "published") and (k.text or "").strip():
                feld.setdefault(n, k.text.strip())
        titel = _text(feld.get("title"), 300)
        url = enc[0] if enc else feld.get("link", "")
        if not titel or not url.startswith(("http://", "https://", "magnet:")):
            continue
        groesse = int(enc[2]) if enc and enc[2].isdigit() else 0
        ergebnis.append({"id": _kennung(feld.get("guid") or feld.get("id") or url), "titel": titel, "url": url,
                         "datum": feld.get("pubDate") or feld.get("updated") or feld.get("published") or "", "groesse": groesse,
                         "art": _art_von(url, enc[1] if enc else "")})
        if len(ergebnis) >= MAX_ITEMS:
            break
    return ergebnis


def jsonfeed_lesen(text):
    try:
        d = json.loads(text)
    except ValueError:
        raise BeobachtungFehler("Kein gültiger JSON-Feed")
    if not isinstance(d, dict) or not isinstance(d.get("items"), list):
        raise BeobachtungFehler("Kein JSON-Feed (Feld „items“ fehlt)")
    ergebnis = []
    for i in d["items"][:MAX_ITEMS]:
        if not isinstance(i, dict):
            continue
        anhang = next((a for a in (i.get("attachments") or []) if isinstance(a, dict) and str(a.get("url", "")).startswith(("http://", "https://"))), None)
        url = (anhang or {}).get("url") or i.get("url") or i.get("external_url") or ""
        titel = _text(i.get("title") or i.get("summary"), 300)
        if not titel or not str(url).startswith(("http://", "https://")):
            continue
        g = (anhang or {}).get("size_in_bytes")
        ergebnis.append({"id": _kennung(i.get("id") or url), "titel": titel, "url": url, "datum": str(i.get("date_published") or ""),
                         "groesse": g if isinstance(g, int) else 0, "art": _art_von(url, (anhang or {}).get("mime_type", ""))})
    return ergebnis


def github_lesen(text, repo):
    try:
        d = json.loads(text)
    except ValueError:
        raise BeobachtungFehler("GitHub hat keine gültige Antwort gegeben")
    if not isinstance(d, list):
        raise BeobachtungFehler("GitHub: %s" % _text(d.get("message") if isinstance(d, dict) else "unerwartete Antwort", 120))
    ergebnis = []
    for r in d[:30]:
        if not isinstance(r, dict) or r.get("draft"):
            continue
        tag = _text(r.get("tag_name"), 80)
        name = _text(r.get("name") or tag, 120)
        assets = [a for a in (r.get("assets") or []) if isinstance(a, dict) and str(a.get("browser_download_url", "")).startswith("https://")]
        if not assets:
            ergebnis.append({"id": _kennung("gh", repo, r.get("id")), "titel": "%s %s" % (repo, name), "url": r.get("html_url") or "",
                             "datum": r.get("published_at") or "", "groesse": 0, "art": "info"})
        for a in assets[:30]:
            ergebnis.append({"id": _kennung("gh", repo, r.get("id"), a.get("id") or a.get("name")),
                             "titel": "%s %s · %s" % (repo, name, _text(a.get("name"), 120)), "url": a["browser_download_url"],
                             "datum": r.get("published_at") or "", "groesse": a.get("size") if isinstance(a.get("size"), int) else 0,
                             "art": "link"})
    return ergebnis[:MAX_ITEMS]


def gitlab_lesen(text, projekt):
    try:
        d = json.loads(text)
    except ValueError:
        raise BeobachtungFehler("GitLab hat keine gültige Antwort gegeben")
    if not isinstance(d, list):
        raise BeobachtungFehler("GitLab: %s" % _text(d.get("message") if isinstance(d, dict) else "unerwartete Antwort", 120))
    ergebnis = []
    for r in d[:30]:
        if not isinstance(r, dict):
            continue
        tag = _text(r.get("tag_name"), 80)
        name = _text(r.get("name") or tag, 120)
        links = [a for a in ((r.get("assets") or {}).get("links") or []) if isinstance(a, dict) and str(a.get("url", "")).startswith("https://")]
        if not links:
            ergebnis.append({"id": _kennung("gl", projekt, tag), "titel": "%s %s" % (projekt, name),
                             "url": ((r.get("_links") or {}).get("self") or ""), "datum": r.get("released_at") or "", "groesse": 0, "art": "info"})
        for a in links[:30]:
            ergebnis.append({"id": _kennung("gl", projekt, tag, a.get("url")), "titel": "%s %s · %s" % (projekt, name, _text(a.get("name"), 120)),
                             "url": a["url"], "datum": r.get("released_at") or "", "groesse": 0, "art": "link"})
    return ergebnis[:MAX_ITEMS]


def mediathek_anfrage(suche):
    """Abfrage an MediathekViewWeb (wie das Rezept mediathek-finder): Titel und Thema, neueste zuerst, keine Zukunft."""
    return json.dumps({"queries": [{"fields": ["title", "topic"], "query": suche}], "sortBy": "timestamp", "sortOrder": "desc",
                       "future": False, "offset": 0, "size": 50})


def mediathek_lesen(text):
    try:
        d = json.loads(text)
        liste = d["result"]["results"]
    except (ValueError, KeyError, TypeError):
        raise BeobachtungFehler("Mediathek hat keine gültige Antwort gegeben")
    ergebnis = []
    for r in liste[:MAX_ITEMS]:
        if not isinstance(r, dict):
            continue
        url = r.get("url_video_hd") or r.get("url_video") or r.get("url_video_low") or ""
        titel = _text("%s · %s (%s)" % (r.get("title"), r.get("topic"), r.get("channel")), 300)
        if not url.startswith("https://") and not url.startswith("http://") or not r.get("title"):
            continue
        ergebnis.append({"id": _kennung("mv", r.get("id") or url), "titel": titel, "url": url, "datum": str(r.get("timestamp") or ""),
                         "groesse": r.get("size") if isinstance(r.get("size"), int) else 0, "art": "link"})
    return ergebnis
