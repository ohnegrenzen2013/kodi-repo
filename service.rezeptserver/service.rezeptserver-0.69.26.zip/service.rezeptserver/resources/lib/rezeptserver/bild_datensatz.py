"""Bild-Datensatz: lokale Bilder pruefen, entdoppeln und in train/test aufteilen.

Vorbild ist der Ablauf von alex000kim/nsfw_data_scraper (MIT): Kategorien als
Ordner, kaputte Bilder aussortieren, Duplikate erkennen, eine feste Anzahl je
Klasse als Testmenge abtrennen und den Rest als Trainingsmenge kopieren oder
verschieben. H0rSt uebernimmt nur diesen lokalen Teil. Die Download- und
Scraper-Skripte des Vorbilds sind bewusst nicht enthalten: H0rSt oeffnet keine
Url-Listen und laedt keine fremden Bilder. Die Klassen sind frei einstellbar.
"""

import hashlib
import json
import os
import random
import shutil
import time

FORMATE = (".jpg", ".jpeg", ".png", ".webp", ".bmp")
MAX_KLASSEN = 20
MAX_DATEIEN = 200000
KOPF = {".jpg": (b"\xff\xd8\xff",), ".jpeg": (b"\xff\xd8\xff",),
        ".png": (b"\x89PNG\r\n\x1a\n",), ".webp": (b"RIFF",), ".bmp": (b"BM",)}


class DatensatzFehler(ValueError):
    pass


def _text(wert, laenge):
    return " ".join(str(wert or "").split())[:laenge]


def _name(wert, standard):
    name = os.path.basename(str(wert or "").replace("\\", "/")).strip().strip(".")
    name = "".join(c for c in name if c.isalnum() or c in "-_. ")
    name = " ".join(name.split()).strip(" .")
    return name[:80] or standard


def _ordner(wert, standard):
    name = "".join(c for c in _name(wert, "") if c.isalnum() or c in "-_")[:40]
    return name or standard


def _im_ziel(ziel, pfad):
    ziel, pfad = os.path.realpath(ziel), os.path.realpath(pfad)
    return pfad == ziel or pfad.startswith(ziel + os.sep)


def klassen(roh):
    """Klassenordner aus "neutral, drawings" oder einer Liste; nur sichere Namen."""
    teile = roh if isinstance(roh, (list, tuple)) else str(roh or "").replace(";", ",").split(",")
    ergebnis = []
    for teil in teile:
        name = "".join(c for c in str(teil).strip().lower() if c.isalnum() or c in "-_")[:40]
        if name and name not in ergebnis:
            ergebnis.append(name)
    if not ergebnis:
        raise DatensatzFehler("Mindestens eine Klasse wie „neutral, drawings“ angeben")
    if len(ergebnis) > MAX_KLASSEN:
        raise DatensatzFehler("Hoechstens %d Klassen" % MAX_KLASSEN)
    return ergebnis


def _pfad(roh, name):
    pfad = str(roh or "").strip()
    if not pfad or "://" in pfad:
        raise DatensatzFehler("%s: lokalen Ordner angeben" % name)
    pfad = os.path.realpath(os.path.abspath(os.path.expanduser(pfad)))
    if pfad == os.path.abspath(os.sep) or len(pfad.strip(os.sep).split(os.sep)) < 2:
        raise DatensatzFehler("%s: zu allgemein – bitte einen eigenen Ordner waehlen" % name)
    return pfad


def _zahl(wert, standard, klein, gross):
    try:
        zahl = float(str(wert).replace(",", "."))
        if not (-float("inf") < zahl < float("inf")):
            return standard
        return max(klein, min(gross, int(zahl)))
    except (TypeError, ValueError, OverflowError):
        return standard


def _formate(roh):
    teile = str(roh or "").replace(";", ",").replace(" ", ",").split(",")
    ergebnis = []
    for teil in teile:
        endung = "." + teil.strip().lower().lstrip(".")
        if endung in FORMATE and endung not in ergebnis:
            ergebnis.append(endung)
    return ergebnis or list(FORMATE)


def _kopf_ok(pfad, endung):
    try:
        with open(pfad, "rb") as f:
            kopf = f.read(16)
    except OSError:
        return False
    return any(kopf.startswith(muster) for muster in KOPF.get(endung, ()))


def _wahlen(werte):
    """Einstellungen in typisierte Werte; Quelle und Ziel bleiben Pfade."""
    quelle = _pfad(werte.get("bildds_quelle"), "Quellordner")
    ziel = _pfad(werte.get("bildds_ziel"), "Zielordner")
    if quelle == ziel:
        raise DatensatzFehler("Quell- und Zielordner muessen verschieden sein")
    if ziel.startswith(quelle + os.sep) or quelle.startswith(ziel + os.sep):
        raise DatensatzFehler("Quell- und Zielordner duerfen nicht ineinander liegen")
    return {"quelle": quelle, "ziel": ziel, "klassen": klassen(werte.get("bildds_klassen")),
            "rekursiv": werte.get("bildds_rekursiv") is not False, "versteckte": werte.get("bildds_versteckte") is True,
            "formate": _formate(werte.get("bildds_formate")),
            "min_kb": _zahl(werte.get("bildds_min_kb"), 1, 0, 1024 * 1024),
            "max_mb": _zahl(werte.get("bildds_max_mb"), 50, 1, 2048),
            "max_dateien": _zahl(werte.get("bildds_max_dateien"), 20000, 1, MAX_DATEIEN),
            "test_anzahl": _zahl(werte.get("bildds_test_anzahl"), 1000, 0, MAX_DATEIEN),
            "modus": "verschieben" if werte.get("bildds_modus") == "verschieben" else "kopieren",
            "duplikate": werte.get("bildds_duplikate") is not False, "seed": _zahl(werte.get("bildds_seed"), 42, 0, 2 ** 31 - 1),
            "probe": werte.get("bildds_probe") is not False, "bericht": _name(werte.get("bildds_bericht"), "bericht.json"),
            "max_klasse": _zahl(werte.get("bildds_max_klasse"), 0, 0, MAX_DATEIEN),
            "aufteilen": werte.get("bildds_aufteilen") is not False,
            "train": _ordner(werte.get("bildds_train"), "train"), "test": _ordner(werte.get("bildds_test"), "test"),
            "umbenennen": werte.get("bildds_umbenennen") is True, "prefix": _ordner(werte.get("bildds_prefix"), "")}


def _dateien(ordner, w):
    try:
        namen = os.listdir(ordner)
    except OSError:
        return []
    for name in sorted(namen):
        pfad = os.path.join(ordner, name)
        if os.path.islink(pfad):
            continue
        if os.path.isdir(pfad):
            if w["rekursiv"] and not (name.startswith(".") and not w["versteckte"]):
                for weiter in _dateien(pfad, w):
                    yield weiter
            continue
        if name.startswith(".") and not w["versteckte"]:
            continue
        if os.path.splitext(name)[1].lower() in w["formate"]:
            yield pfad


def _hash(pfad):
    h = hashlib.sha256()
    try:
        with open(pfad, "rb") as f:
            while True:
                block = f.read(1 << 20)
                if not block:
                    break
                h.update(block)
    except OSError:
        return ""
    return h.hexdigest()


def plan(werte):
    """Nur lesen: zaehlen, pruefen, Duplikate finden und die Testmenge bestimmen."""
    w = _wahlen(werte)
    if not os.path.isdir(w["quelle"]):
        raise DatensatzFehler("Quellordner nicht gefunden: %s" % w["quelle"])
    zufall = random.Random(w["seed"])
    gesehen, klassen_daten, gesamt, gescannt = set(), {}, 0, 0
    for klasse in w["klassen"]:
        ordner = os.path.join(w["quelle"], klasse)
        gelesen = geprueft = 0
        bilder = []
        for pfad in _dateien(ordner, w):
            if gescannt >= w["max_dateien"]:
                break
            gescannt += 1
            gelesen += 1
            if not _kopf_ok(pfad, os.path.splitext(pfad)[1].lower()):
                continue
            groesse = os.path.getsize(pfad)
            if groesse < w["min_kb"] * 1024 or groesse > w["max_mb"] * 1024 * 1024:
                continue
            if w["duplikate"]:
                kennung = _hash(pfad)
                if not kennung or kennung in gesehen:
                    continue
                gesehen.add(kennung)
            geprueft += 1
            if w["max_klasse"] and len(bilder) >= w["max_klasse"]:
                continue
            bilder.append(pfad)
            gesamt += 1
        zufall.shuffle(bilder)
        test = bilder[:w["test_anzahl"]] if w["aufteilen"] else []
        train = bilder[len(test):] if w["aufteilen"] else bilder
        klassen_daten[klasse] = {"ordner": ordner, "gelesen": gelesen, "geprueft": geprueft,
                                 "train": train, "test": test}
    return {"w": w, "klassen": klassen_daten, "gesamt": gesamt,
            "probe": w["probe"], "zeit": int(time.time())}


def _zielname(ziel, klasse, name, nummer, w):
    endung = os.path.splitext(name)[1].lower()
    if w["umbenennen"]:
        basis = "%s%06d" % (w["prefix"], nummer)
    else:
        basis = os.path.splitext(name)[0]
    kandidat = os.path.join(ziel, klasse, basis + endung)
    nr = 1
    while os.path.exists(kandidat):
        kandidat = os.path.join(ziel, klasse, "%s-%d%s" % (basis, nr, endung))
        nr += 1
    if not _im_ziel(ziel, kandidat):
        raise DatensatzFehler("Zielpfad ausserhalb des Zielordners: %s" % kandidat)
    return kandidat


def _ablegen(pfad, ziel, klasse, nummer, w):
    os.makedirs(os.path.join(ziel, klasse), exist_ok=True)
    neu = _zielname(ziel, klasse, os.path.basename(pfad), nummer, w)
    try:
        shutil.copy2(pfad, neu)
    except OSError:
        try:
            os.remove(neu)
        except OSError:
            pass
        raise
    if w["modus"] == "verschieben":
        try:
            os.remove(pfad)
        except OSError as fehler:
            return neu, "Quelle nicht entfernt: %s" % fehler
    return neu, ""


def ausfuehren(werte):
    """Planen und – wenn probe aus ist – train/test anlegen; schreibt einen Bericht."""
    p = plan(werte)
    w = p["w"]
    bericht = {"zeit": time.strftime("%Y-%m-%dT%H:%M:%S"), "quelle": w["quelle"], "ziel": w["ziel"],
               "klassen": {}, "modus": w["modus"], "probe": w["probe"], "seed": w["seed"]}
    if w["probe"]:
        bericht["klassen"] = {k: {"train": len(v["train"]), "test": len(v["test"]), "geprueft": v["geprueft"]} for k, v in p["klassen"].items()}
        return bericht
    nummer = 0
    try:
        os.makedirs(w["ziel"], exist_ok=True)
        for klasse, daten in p["klassen"].items():
            ziele = []
            for name, liste in ((w["train"], daten["train"]), (w["test"], daten["test"])) if w["aufteilen"] else ((w["train"], daten["train"]),):
                ordner = os.path.join(w["ziel"], name)
                for pfad in liste:
                    nummer += 1
                    try:
                        ziel, warnung = _ablegen(pfad, ordner, klasse, nummer, w)
                        ziele.append(ziel)
                        if warnung:
                            bericht.setdefault("fehler", []).append("%s: %s" % (pfad, warnung))
                    except OSError as fehler:
                        bericht.setdefault("fehler", []).append("%s: %s" % (pfad, fehler))
            bericht["klassen"][klasse] = {"train": len(daten["train"]) if w["aufteilen"] else len(daten["train"]),
                                         "test": len(daten["test"]) if w["aufteilen"] else 0,
                                         "geprueft": daten["geprueft"], "geschrieben": len(ziele)}
    except OSError as fehler:
        raise DatensatzFehler("Zielordner: %s" % fehler)
    bericht["bericht"] = os.path.join(w["ziel"], w["bericht"])
    if not _im_ziel(w["ziel"], bericht["bericht"]):
        raise DatensatzFehler("Berichtspfad ausserhalb des Zielordners: %s" % bericht["bericht"])
    try:
        with open(bericht["bericht"], "w", encoding="utf-8") as f:
            json.dump(bericht, f, ensure_ascii=False, indent=2)
    except OSError as fehler:
        bericht["bericht"] = "nicht geschrieben: %s" % fehler
    return bericht


def zustand(werte):
    """Kurzer Stand fuer die Einstellungsseite, ohne Ordner zu lesen."""
    return {"an": werte.get("bildds_an") is True, "quelle": str(werte.get("bildds_quelle") or ""),
            "ziel": str(werte.get("bildds_ziel") or ""), "klassen": str(werte.get("bildds_klassen") or ""),
            "test_anzahl": str(werte.get("bildds_test_anzahl") or ""), "modus": str(werte.get("bildds_modus") or "kopieren"),
            "probe": werte.get("bildds_probe") is not False, "formate": list(FORMATE),
            "hinweis": "Nur lokale, eigene oder lizenzierte Bilder. H0rSt laedt nichts herunter und oeffnet keine Url-Listen."}
