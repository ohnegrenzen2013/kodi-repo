"""binsearch.info: freie Usenet-Suche ohne Konto (sucht in den Betreffzeilen der Binaer-Newsgroups).

  * suchen(): Trefferseite lesen (je Seite 25; Betreff, Groesse, Vollstaendigkeit, Newsgroup, Alter)
  * NZB: https://www.binsearch.info/nzb?<id>=on liefert die NZB direkt (application/x-nzb)
  * In H0rSt ein Indexer wie jeder Newznab-Indexer (anbindungen: Typ "binsearch"); zusaetzlich bietet H0rSt
    binsearch als Newznab-Schnittstelle unter /binsearch/api an – fuer NZBHydra2, Prowlarr, Sonarr und Radarr.

Die Seite wird ohne Skript ausgeliefert (Next.js rendert auf dem Server); aendert binsearch den Aufbau, liefert
lesen() einfach nichts und der Indexer meldet "keine Treffer".
"""

import html
import re
import threading
import time
from email.utils import formatdate
from urllib.parse import quote_plus, urlencode
from xml.sax.saxutils import escape

BASIS = "https://www.binsearch.info"
PRO_SEITE = 25
_ZEILE = re.compile(r"<tr>(.*?)</tr>", re.S)
_ID = re.compile(r'<input type="checkbox"[^>]*name="([A-Za-z0-9_=\-]{8,120})"')
_BETREFF = re.compile(r'<a[^>]*href="/details/[^"]*"[^>]*>(.*?)</a>', re.S)
_SPANS = re.compile(r'<span class="([^"]*)"[^>]*>(.*?)</span>', re.S)
_GRUPPE = re.compile(r'href="/search\?group=([^"&]+)"')
_ALTER = re.compile(r'<td class="min-w-20">([^<]*)</td>')
_GROESSE = re.compile(r"^\s*([\d.]+)\s*([KMGT]?B)\s*$", re.I)
_DATEI = re.compile(r'"([^"]+)"')
_ENDUNG = re.compile(r"(\.(?:part\d+\.)?(?:rar|r\d\d|zip|7z|nzb|par2|vol\d+\+\d+\.par2|\d{3}|nfo|sfv))+$", re.I)


class BinsearchFehler(ValueError):
    pass


def _text(roh):
    return html.unescape(re.sub(r"<!--.*?-->|<[^>]+>", "", roh)).strip()


def _bytes(text):
    m = _GROESSE.match(text or "")
    if not m:
        return 0
    return int(float(m.group(1)) * 1024 ** "BKMGT".index(m.group(2).upper()[0] if len(m.group(2)) > 1 else "B"))


def _tage(alter):
    m = re.match(r"\s*(\d+)\s*(minute|hour|day|week|month|year)", str(alter or ""), re.I)
    if not m:
        return None
    faktor = {"minute": 1 / 1440, "hour": 1 / 24, "day": 1, "week": 7, "month": 30, "year": 365}[m.group(2).lower()]
    return int(m.group(1)) * faktor


def titel(betreff):
    """Lesbarer Name aus dem Betreff: Dateiname in Anfuehrungszeichen ohne Archiv-Endungen."""
    m = _DATEI.search(betreff)
    name = (m.group(1) if m else re.sub(r"\byEnc\b.*$", "", betreff)).strip()
    return _ENDUNG.sub("", name).strip(" .-_") or betreff.strip()


def lesen(seite):
    """HTML der Trefferseite -> [{"id", "betreff", "titel", "groesse", "dateien", "vollstaendig", "gruppe", "alter", "tage", "nzb"}]."""
    treffer = []
    for zeile in _ZEILE.findall(seite or ""):
        kennung, betreff = _ID.search(zeile), _BETREFF.search(zeile)
        if not (kennung and betreff):
            continue
        groesse, dateien, vollstaendig = 0, 0, True
        for klasse, inhalt in _SPANS.findall(zeile):
            text = _text(inhalt)
            if _GROESSE.match(text) and not groesse:
                groesse = _bytes(text)
            elif re.search(r"\bfiles?\b", text, re.I):
                zahl = re.match(r"\s*(\d+)", text)
                dateien = int(zahl.group(1)) if zahl else 0
                vollstaendig = "incomplete" not in klasse.split() and "incomplete" not in text.lower()
        gruppe = _GRUPPE.search(zeile)
        alter = _ALTER.search(zeile)
        b = _text(betreff.group(1))
        treffer.append({"id": kennung.group(1), "betreff": b, "titel": titel(b), "groesse": groesse, "dateien": dateien,
                        "vollstaendig": vollstaendig, "gruppe": html.unescape(gruppe.group(1)) if gruppe else "",
                        "alter": _text(alter.group(1)) if alter else "", "tage": _tage(alter.group(1)) if alter else None,
                        "nzb": nzb_adresse(kennung.group(1))})
    return treffer


def nzb_adresse(kennung):
    return "%s/nzb?%s=on" % (BASIS, quote_plus(kennung))


def such_adresse(text, seite=1):
    werte = {"q": " ".join(str(text or "").split())[:200]}
    if seite > 1:
        werte["page"] = str(seite)
    return "%s/search?%s" % (BASIS, urlencode(werte))


# --- Hoeflichkeit: binsearch bietet weder API noch RSS an (Stand 31.10.2026: /api, /rss und eine Nutzungsbedingungen-Seite
# gibt es nicht; robots.txt erlaubt normale Abrufe). H0rSt liest deshalb nur die normale Trefferseite und macht dabei
# keine Massenabfragen: hoechstens eine Anfrage alle MIN_ABSTAND Sekunden fuer das ganze Programm, gleiche Suchen
# kommen 10 Minuten aus dem Speicher, und mehr als MAX_WARTEND gleichzeitig Wartende werden abgewiesen.
MIN_ABSTAND = 6.0
MAX_WARTEND = 3
CACHE_SEKUNDEN = 600
_sperre = threading.Lock()
_zustand = {"naechste": 0.0, "wartend": 0, "cache": {}}


def _drosseln(uhr=time.monotonic, schlafen=time.sleep):
    with _sperre:
        if _zustand["wartend"] >= MAX_WARTEND:
            raise BinsearchFehler("binsearch wird zu oft gefragt – bitte kurz warten (höchstens eine Suche alle %d s)" % int(MIN_ABSTAND))
        _zustand["wartend"] += 1
        jetzt = uhr()
        start = max(jetzt, _zustand["naechste"])
        _zustand["naechste"] = start + MIN_ABSTAND
    try:
        if start > jetzt:
            schlafen(start - jetzt)
    finally:
        with _sperre:
            _zustand["wartend"] -= 1


def suchen(text, abruf, seite=1, nur_vollstaendig=True, uhr=time.monotonic, schlafen=time.sleep):
    """abruf(url) -> HTML-Text (z. B. Abrufer.abruf, beschraenkt auf binsearch.info). Gedrosselt und zwischengespeichert."""
    if len(" ".join(str(text or "").split())) < 2:
        return []
    adresse = such_adresse(text, seite)
    jetzt = uhr()
    with _sperre:
        cache = _zustand["cache"]
        for k in [k for k, (t, _) in cache.items() if jetzt - t > CACHE_SEKUNDEN]:
            del cache[k]
        treffer = cache.get(adresse, (0, None))[1]
    if treffer is None:
        _drosseln(uhr, schlafen)
        treffer = lesen(abruf(adresse))
        with _sperre:
            if len(_zustand["cache"]) >= 50:
                _zustand["cache"].pop(next(iter(_zustand["cache"])))
            _zustand["cache"][adresse] = (uhr(), treffer)
    return [t for t in treffer if t["vollstaendig"] or not nur_vollstaendig]


# --- Newznab-Schnittstelle (/binsearch/api) fuer NZBHydra2, Prowlarr, Sonarr, Radarr ----------------------------
CAPS = ('<?xml version="1.0" encoding="UTF-8"?>\n<caps><server version="1.0" title="binsearch ueber H0rSt"/>'
        '<limits max="%d" default="%d"/><registration available="no" open="no"/><searching>'
        '<search available="yes" supportedParams="q"/><tv-search available="yes" supportedParams="q,season,ep"/>'
        '<movie-search available="yes" supportedParams="q,imdbid"/></searching><categories>'
        '<category id="2000" name="Movies"/><category id="5000" name="TV"/><category id="7000" name="Other"/>'
        '</categories></caps>' % (PRO_SEITE, PRO_SEITE))


def newznab_suchtext(werte, titel_von_imdb=None):
    """Newznab-Parameter -> Suchtext fuer binsearch (imdbid ueber titel_von_imdb zu "Titel Jahr")."""
    text = " ".join(str(werte.get("q") or "").split())
    if not text and werte.get("imdbid") and titel_von_imdb:
        text = titel_von_imdb("tt" + str(werte["imdbid"]).lstrip("t"))
    staffel, folge = str(werte.get("season") or ""), str(werte.get("ep") or "")
    if text and staffel.isdigit():
        text += " S%02d" % int(staffel) + ("E%02d" % int(folge) if folge.isdigit() else "")
    return text


def newznab_xml(treffer, kategorie="2000", offset=0, uhr=time.time):
    items = []
    for t in treffer:
        tage = t.get("tage")
        datum = formatdate(uhr() - tage * 86400 if tage is not None else uhr(), usegmt=True)
        items.append('<item><title>%s</title><guid isPermaLink="false">%s</guid><link>%s</link><pubDate>%s</pubDate>'
                     '<category>%s</category><description>%s</description><enclosure url="%s" length="%d" type="application/x-nzb"/>'
                     '<newznab:attr name="category" value="%s"/><newznab:attr name="size" value="%d"/>'
                     '<newznab:attr name="files" value="%d"/><newznab:attr name="group" value="%s"/></item>'
                     % (escape(t["titel"]), escape(t["id"]), escape(t["nzb"]), datum, kategorie, escape(t["betreff"]), escape(t["nzb"]),
                        t["groesse"], kategorie, t["groesse"], t["dateien"], escape(t["gruppe"])))
    return ('<?xml version="1.0" encoding="UTF-8"?>\n<rss version="2.0" xmlns:newznab="http://www.newznab.com/DTD/2010/feeds/attributes/">'
            '<channel><title>binsearch (H0rSt)</title><description>binsearch.info ueber H0rSt</description>'
            '<newznab:response offset="%d" total="%d"/>%s</channel></rss>' % (offset, offset + len(treffer), "".join(items)))


def newznab_fehler(code, text):
    return '<?xml version="1.0" encoding="UTF-8"?>\n<error code="%d" description="%s"/>' % (code, escape(text))
