"""Brause – m0dul: der Browser-Baustein von H0rSt (App "H0rSt Brause" auf Basis von Mozilla GeckoView).

Hier liegt, was die Brause von H0rSt holt und was in jeder H0rSt-Oberflaeche gepflegt werden kann:
  * Lesezeichen (Titel, Adresse, Ordner, Favorit) – Favoriten stehen in der Brause oben
  * Erweiterungen (.xpi-Adressen, z. B. von addons.mozilla.org) – die Brause installiert sie nach Rueckfrage
  * Startseite, Suchmaschine, Tracking-Schutz (Standard oder streng)

Nutzerdaten "brause": {"lesezeichen": [...], "erweiterungen": [...], "startseite", "suchmaschine", "schutz"}
"""

import copy
import hashlib
import re
from urllib.parse import urlsplit

SCHLUESSEL = "brause"
MAX_LESEZEICHEN = 500
MAX_ERWEITERUNGEN = 50
MAX_START_KACHELN = 18
_KACHEL_FARBEN = ("#ef4444", "#f97316", "#eab308", "#22c55e", "#06b6d4", "#3b82f6", "#8b5cf6", "#ec4899")
SUCHMASCHINEN = {
    "duckduckgo": ("DuckDuckGo", "https://duckduckgo.com/?q=%s"),
    "startpage": ("Startpage", "https://www.startpage.com/do/search?q=%s"),
    "brave": ("Brave Search", "https://search.brave.com/search?q=%s"),
    "ecosia": ("Ecosia", "https://www.ecosia.org/search?q=%s"),
    "qwant": ("Qwant", "https://www.qwant.com/?q=%s"),
    "google": ("Google", "https://www.google.com/search?q=%s"),
    "bing": ("Bing", "https://www.bing.com/search?q=%s"),
}
# freie, bewaehrte Erweiterungen fuer Firefox auf Android (signiert, von addons.mozilla.org)
_AMO = "https://addons.mozilla.org/firefox/downloads/latest/%s/latest.xpi"
VORSCHLAEGE = [
    {"name": "uBlock Origin", "url": _AMO % "ublock-origin", "text": "Werbe- und Trackerblocker"},
    {"name": "Dark Reader", "url": _AMO % "darkreader", "text": "Dunkler Modus für jede Seite"},
    {"name": "SponsorBlock", "url": _AMO % "sponsorblock", "text": "Sponsor-Abschnitte in YouTube überspringen"},
    {"name": "Privacy Badger", "url": _AMO % "privacy-badger17", "text": "Lernender Tracker-Schutz der EFF"},
    {"name": "Bitwarden", "url": _AMO % "bitwarden-password-manager", "text": "Passwortmanager"},
    {"name": "Consent-O-Matic", "url": _AMO % "consent-o-matic", "text": "Cookie-Banner automatisch beantworten"},
    {"name": "I2P in Private Browsing", "url": _AMO % "i2p-in-private-browsing",
     "text": ".i2p-Seiten in abgeschotteten Tabs; braucht einen laufenden I2P-Router (HTTP-Proxy 4444)"},
]
GX_SEITEN = [
    {"name": "GX Corner", "symbol": "🎮", "url": "https://www.operagx.gg/"},
    {"name": "Twitch", "symbol": "🟣", "url": "https://www.twitch.tv/"},
    {"name": "Discord", "symbol": "💬", "url": "https://discord.com/app"},
    {"name": "WhatsApp", "symbol": "🟢", "url": "https://web.whatsapp.com/"},
    {"name": "Telegram", "symbol": "✈", "url": "https://web.telegram.org/"},
    {"name": "YouTube Music", "symbol": "🎵", "url": "https://music.youtube.com/"},
    {"name": "Spotify", "symbol": "🎧", "url": "https://open.spotify.com/"},
]
GX_STANDARD = {"akzent": "#ff2b4a", "startseite": "gx", "seitenleiste": True, "corner": True,
               "dunkel": True, "speicher_sparen": False, "daten_sparen": False,
               "seiten": copy.deepcopy(GX_SEITEN)}
GX_LINKS = {
    "seite": "https://www.opera.com/de/gx",
    "android": "https://download.opera.com/download/get/?partner=www&nothanks=yes&product=android-gx"
               "&download_url=https%3A%2F%2Foperagx.gg%2Fmobile-lp-android",
    "windows": "https://www.opera.com/de/gx",
    "macos": "https://www.opera.com/de/gx",
    "linux": "https://www.opera.com/de/gx",
}
STANDARD = {"startseite": "https://duckduckgo.com/", "suchmaschine": "duckduckgo", "schutz": "standard",
            "spatial_nav": False, "modus": "klassisch", "gx": copy.deepcopy(GX_STANDARD),
            "lesezeichen": [], "erweiterungen": []}


class BrauseFehler(ValueError):
    pass


def _gx_seite(roh):
    if not isinstance(roh, dict):
        raise BrauseFehler("GX-Seite als Objekt")
    name = " ".join(str(roh.get("name") or "").split())[:40]
    if not name:
        raise BrauseFehler("GX-Seite braucht einen Namen")
    return {"name": name, "url": _web(roh.get("url")), "symbol": str(roh.get("symbol") or "•")[:4]}


def _gx(roh):
    alt = roh if isinstance(roh, dict) else {}
    e = copy.deepcopy(GX_STANDARD)
    if re.match(r"^#[0-9a-fA-F]{6}$", str(alt.get("akzent") or "")):
        e["akzent"] = str(alt["akzent"]).lower()
    start = str(alt.get("startseite") or "gx").strip()
    if start == "gx" or not start:
        e["startseite"] = "gx"
    else:
        try:
            e["startseite"] = _web(start)
        except BrauseFehler:
            pass
    for k in ("seitenleiste", "corner", "dunkel", "speicher_sparen", "daten_sparen"):
        if isinstance(alt.get(k), bool):
            e[k] = alt[k]
    seiten, gesehen = [], set()
    for x in (alt.get("seiten") if isinstance(alt.get("seiten"), list) else []):
        try:
            l = _gx_seite(x)
        except BrauseFehler:
            continue
        if l["url"] not in gesehen and len(seiten) < 12:
            gesehen.add(l["url"])
            seiten.append(l)
    e["seiten"] = seiten or copy.deepcopy(GX_SEITEN)
    return e


def _web(url, xpi=False):
    url = str(url or "").strip()
    teile = urlsplit(url)
    if teile.scheme not in (("https",) if xpi else ("http", "https")) or not teile.hostname:
        raise BrauseFehler("Erweiterungen nur per https://-Adresse" if xpi else "Adresse mit http(s)://")
    return url[:2000]


def _lesezeichen(roh):
    if not isinstance(roh, dict):
        raise BrauseFehler("Lesezeichen als Objekt")
    url = _web(roh.get("url"))
    titel = " ".join(str(roh.get("titel") or "").split())[:200] or urlsplit(url).hostname
    return {"titel": titel, "url": url, "ordner": " ".join(str(roh.get("ordner") or "").split())[:60],
            "favorit": roh.get("favorit") is True}


def pruefe(roh):
    """Gespeicherte Werte; kaputte Eintraege fallen weg, fehlende bekommen den Standard."""
    roh = roh if isinstance(roh, dict) else {}
    e = copy.deepcopy(STANDARD)
    e["lesezeichen"], e["erweiterungen"] = [], []
    try:
        e["startseite"] = _web(roh.get("startseite")) if roh.get("startseite") else STANDARD["startseite"]
    except BrauseFehler:
        pass
    if roh.get("suchmaschine") in SUCHMASCHINEN:
        e["suchmaschine"] = roh["suchmaschine"]
    if roh.get("schutz") in ("standard", "streng"):
        e["schutz"] = roh["schutz"]
    e["spatial_nav"] = roh.get("spatial_nav") is True
    e["modus"] = "gx" if roh.get("modus") == "gx" else "klassisch"
    e["gx"] = _gx(roh.get("gx"))
    gesehen = set()
    for x in (roh.get("lesezeichen") or [])[:MAX_LESEZEICHEN]:
        try:
            l = _lesezeichen(x)
        except BrauseFehler:
            continue
        if l["url"] not in gesehen:
            gesehen.add(l["url"])
            e["lesezeichen"].append(l)
    for x in (roh.get("erweiterungen") or [])[:MAX_ERWEITERUNGEN]:
        try:
            url = _web((x or {}).get("url"), xpi=True)
        except (BrauseFehler, AttributeError):
            continue
        name = " ".join(str(x.get("name") or "").split())[:80] or re.sub(r"\.xpi$", "", url.rsplit("/", 1)[-1])
        if all(y["url"] != url for y in e["erweiterungen"]):
            e["erweiterungen"].append({"name": name, "url": url})
    return e


def gx_daten(e):
    """Was die GX-Corner-Seite braucht: Akzent, Shortcuts und feste Ziele."""
    gx = e.get("gx") if isinstance(e.get("gx"), dict) else _gx(None)
    return {"akzent": gx.get("akzent", "#ff2b4a"), "corner": gx.get("corner", True),
            "seiten": gx.get("seiten") or copy.deepcopy(GX_SEITEN),
            "dunkel": gx.get("dunkel", True)}


def start_kacheln(e, max_anzahl=MAX_START_KACHELN):
    """Quick-Link-Kacheln fuer die Brause-Startseite: Favoriten zuerst, sonst alle Lesezeichen (nach Ordner/Titel).
    Kein Thumbnail-Abruf – nur Anfangsbuchstabe und eine aus der Adresse errechnete Farbe, macht die Seite
    ressourcenleicht (kein zusaetzlicher Netzzugriff beim Anzeigen)."""
    liste = sorted(e.get("lesezeichen") or [], key=lambda l: (not l.get("favorit"), l.get("ordner", ""), l.get("titel", "")))
    kacheln = []
    for l in liste[:max_anzahl]:
        buchstabe = (l["titel"][:1] or "?").upper()
        farbe = _KACHEL_FARBEN[int(hashlib.md5(l["url"].encode("utf-8")).hexdigest(), 16) % len(_KACHEL_FARBEN)]
        kacheln.append({"titel": l["titel"], "url": l["url"], "buchstabe": buchstabe, "farbe": farbe})
    return kacheln


def fuer_brause(e):
    """Was die Brause (App) und die Oberflaeche lesen: Werte plus Such-Vorlage, Suchmaschinen, Vorschlaege."""
    return dict(e, suche=SUCHMASCHINEN[e["suchmaschine"]][1],
                suchmaschinen=[[k, v[0]] for k, v in SUCHMASCHINEN.items()], vorschlaege=VORSCHLAEGE,
                gx_seiten=copy.deepcopy(GX_SEITEN), gx_links=copy.deepcopy(GX_LINKS))


def aendern(daten, wunsch):
    """Eine Aenderung uebernehmen: {"aktion": lesezeichen|lesezeichen_weg|favorit|erweiterung|erweiterung_weg|
    einstellungen, …}. Gibt die neuen Werte zurueck (fuer_brause)."""
    if not isinstance(wunsch, dict):
        raise BrauseFehler("JSON-Objekt erwartet")
    e = pruefe(daten.get(SCHLUESSEL))
    aktion = wunsch.get("aktion")
    if aktion == "lesezeichen":  # neu oder ersetzen (gleiche Adresse)
        l = _lesezeichen(wunsch)
        alt = next((x for x in e["lesezeichen"] if x["url"] == l["url"]), None)
        if alt and "favorit" not in wunsch:
            l["favorit"] = alt["favorit"]
        e["lesezeichen"] = [x for x in e["lesezeichen"] if x["url"] != l["url"]] + [l]
        if len(e["lesezeichen"]) > MAX_LESEZEICHEN:
            raise BrauseFehler("Höchstens %d Lesezeichen" % MAX_LESEZEICHEN)
    elif aktion == "lesezeichen_weg":
        e["lesezeichen"] = [x for x in e["lesezeichen"] if x["url"] != str(wunsch.get("url") or "")]
    elif aktion == "favorit":
        for x in e["lesezeichen"]:
            if x["url"] == str(wunsch.get("url") or ""):
                x["favorit"] = wunsch.get("an") is True
    elif aktion == "erweiterung":
        url = _web(wunsch.get("url"), xpi=True)
        if len(e["erweiterungen"]) >= MAX_ERWEITERUNGEN:
            raise BrauseFehler("Höchstens %d Erweiterungen" % MAX_ERWEITERUNGEN)
        name = " ".join(str(wunsch.get("name") or "").split())[:80] or url.rsplit("/", 1)[-1]
        e["erweiterungen"] = [x for x in e["erweiterungen"] if x["url"] != url] + [{"name": name, "url": url}]
    elif aktion == "erweiterung_weg":
        e["erweiterungen"] = [x for x in e["erweiterungen"] if x["url"] != str(wunsch.get("url") or "")]
    elif aktion == "einstellungen":
        if "startseite" in wunsch:
            e["startseite"] = _web(wunsch["startseite"])
        if "suchmaschine" in wunsch:
            if wunsch["suchmaschine"] not in SUCHMASCHINEN:
                raise BrauseFehler("Unbekannte Suchmaschine")
            e["suchmaschine"] = wunsch["suchmaschine"]
        if "schutz" in wunsch:
            if wunsch["schutz"] not in ("standard", "streng"):
                raise BrauseFehler("Schutz: standard oder streng")
            e["schutz"] = wunsch["schutz"]
        if "spatial_nav" in wunsch:
            e["spatial_nav"] = wunsch["spatial_nav"] is True
        if "modus" in wunsch:
            if wunsch["modus"] not in ("klassisch", "gx"):
                raise BrauseFehler("Modus: klassisch oder gx")
            e["modus"] = wunsch["modus"]
        if "gx" in wunsch:
            if not isinstance(wunsch["gx"], dict):
                raise BrauseFehler("GX-Einstellungen als Objekt")
            e["gx"] = _gx(dict(e.get("gx") or {}, **wunsch["gx"]))
    else:
        raise BrauseFehler("Unbekannte Aktion")
    daten[SCHLUESSEL] = e
    return fuer_brause(e)
