"""brillen.py – HeyCyan-kompatible Smart-Glasses-Anbindung.

Quellen:
  ebowwa HeyCyanSmartGlassesSDK   https://github.com/ebowwa/HeyCyanSmartGlassesSDK   MIT
  FerSaiyan CyanBridge             https://github.com/FerSaiyan/Alternative-HeyCyan-App-and-SDK   MIT

UNiQuanteX-Bewertung:
  - Beide kommen als Dank-Eintrag (vorbild / dabei).
  - Kein Style-Klon: CyanBridge hat keine belegbare Open-Source-Palette;
    ebowwa SDK hat keine eigene UI.

Was hier gebaut ist: der Modell-Katalog fuer das Brille-Tab, rein aus den
dokumentierten Quellen nachgebaut, kein kopierter Code.

Schnittstelle: GET /api/brillen -> {modelle, endpunkte, quellen, runtimes, hinweis}
"""

# ---------------------------------------------------------------------------
# Laufzeitumgebungen (aus CyanBridge README / android/CyanBridge/docs)
# ---------------------------------------------------------------------------
RUNTIMES = [
    {"id": "llamacpp", "name": "llama.cpp", "endung": ".gguf",
     "url": "https://github.com/ggerganov/llama.cpp",
     "hinweis": "Quantisierte GGUF-Modelle, laeuft direkt auf dem Geraet."},
    {"id": "litertlm", "name": "LiteRT-LM", "endung": ".litertlm / .task",
     "url": "https://github.com/google/ai-edge-litert",
     "hinweis": "Googles On-Device-Runtime fuer quantisierte Modelle (ehem. TFLite)."},
]

# ---------------------------------------------------------------------------
# Modell-Katalog (aus CyanBridge android/CyanBridge/docs/local-models.md)
# Quelle: https://github.com/FerSaiyan/Alternative-HeyCyan-App-and-SDK
# Stand: 2025-04-xx (letzte gepruefter Commit, README-Version)
# ---------------------------------------------------------------------------
MODELLE = [
    {
        "id": "qwen25_05b_q4",
        "name": "Qwen 2.5 0.5B Instruct (Q4)",
        "runtime": "llamacpp",
        "endung": ".gguf",
        "groesse_mb": 400,
        "url": "https://huggingface.co/Qwen/Qwen2.5-0.5B-Instruct-GGUF",
        "hinweis": "Kleinstes Modell, laeuft auf fast jedem Android-Geraet.",
    },
    {
        "id": "gemma4_e2b_litertlm",
        "name": "Gemma 4 E2B IT (LiteRT-LM)",
        "runtime": "litertlm",
        "endung": ".litertlm",
        "groesse_mb": 1200,
        "url": "https://huggingface.co/google/gemma-4-e2b-it",
        "hinweis": "Googles Embedded-Modell fuer On-Device-Inferenz.",
    },
    {
        "id": "gemma4_e4b_litertlm",
        "name": "Gemma 4 E4B IT (LiteRT-LM)",
        "runtime": "litertlm",
        "endung": ".litertlm",
        "groesse_mb": 2400,
        "url": "https://huggingface.co/google/gemma-4-e4b-it",
        "hinweis": "Groesseres Gemma-Embedded-Modell, bessere Qualitaet.",
    },
    {
        "id": "qwen25_15b_q4",
        "name": "Qwen 2.5 1.5B Instruct (Q4)",
        "runtime": "llamacpp",
        "endung": ".gguf",
        "groesse_mb": 950,
        "url": "https://huggingface.co/Qwen/Qwen2.5-1.5B-Instruct-GGUF",
        "hinweis": "Gutes Preis-Leistungs-Verhaeltnis fuer On-Device.",
    },
]

# ---------------------------------------------------------------------------
# Endpunkt-Typen (aus CyanBridge README)
# ---------------------------------------------------------------------------
ENDPUNKT_TYPEN = [
    {"id": "lokal", "name": "Lokal (llama.cpp / LiteRT-LM)",
     "hinweis": "Modell liegt auf dem Geraet, kein Netz noetig."},
    {"id": "gemini_live", "name": "Gemini Live",
     "hinweis": "Google-API-Schluessel erforderlich."},
    {"id": "openai_kompatibel", "name": "OpenAI-kompatibler Endpunkt",
     "hinweis": "Jeder Endpunkt mit /v1/chat/completions, z.B. Ollama oder LM Studio."},
]

# ---------------------------------------------------------------------------
# Quellen fuer das Brille-Tab (Dank und Lizenz)
# ---------------------------------------------------------------------------
QUELLEN = [
    {
        "id": "heycyan_ebowwa",
        "name": "HeyCyanSmartGlassesSDK (ebowwa)",
        "url": "https://github.com/ebowwa/HeyCyanSmartGlassesSDK",
        "lizenz": "MIT",
        "was": "BLE-SDK fuer HeyCyan-kompatible Smart Glasses (iOS Objective-C + Android Kotlin). "
               "Liefert Hardwareprotokoll und Verbindungslogik.",
    },
    {
        "id": "cyanbridge_fersaiyan",
        "name": "CyanBridge (FerSaiyan)",
        "url": "https://github.com/FerSaiyan/Alternative-HeyCyan-App-and-SDK",
        "lizenz": "MIT",
        "was": "Alternative Android-App fuer HeyCyan-Glasses: lokale LLM-Inferenz (llama.cpp, LiteRT-LM), "
               "Gemini Live und OpenAI-kompatibler Endpunkt. Kein Style-Klon: Palette nicht belegbar.",
    },
]

HINWEIS = (
    "Die Brille-Funktion verbindet H0rSt mit HeyCyan-kompatiblen Smart Glasses. "
    "Lokale Modelle laufen direkt auf dem Android-Geraet, Netz ist dafuer nicht noetig. "
    "Die Einrichtung erfolgt in der Android-App unter CyanBridge."
)


def zustand():
    """Gibt den Brille-Katalog zurueck: Modelle, Endpunkte, Runtimes, Quellen."""
    return {
        "modelle": MODELLE,
        "endpunkte": ENDPUNKT_TYPEN,
        "runtimes": RUNTIMES,
        "quellen": QUELLEN,
        "hinweis": HINWEIS,
        "anzahl_modelle": len(MODELLE),
    }
