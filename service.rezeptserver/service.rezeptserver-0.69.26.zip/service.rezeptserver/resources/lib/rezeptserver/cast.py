"""Google Home, Nest und Chromecast steuern (Cast-Protokoll v2, nur Python-Standardbibliothek).

  * Finden: mDNS-Anfrage nach _googlecast._tcp.local im Heimnetz (Name, Modell, IP, Port).
  * Abspielen: der "Default Media Receiver" (App CC1AD845) laedt eine Adresse – Filme, Folgen, Live-TV, Musik von
    H0rSt (Adressen auf 127.0.0.1 schreibt die Oberflaeche auf die Heimnetz-Adresse um). Lautsprecher spielen den Ton.
  * Steuern: Pause, Weiter, Stopp, Lautstaerke, Stumm, Stand.
Verbindung: TLS auf Port 8009 (die Geraete haben eigene Zertifikate, Pruefung wie bei allen Cast-Apps aus),
Nachrichten als Protobuf "CastMessage" mit JSON-Inhalt. Keine Cloud, kein Google-Konto noetig.
"""

import json
import random
import socket
import ssl
import struct
import time

APP_MEDIA = "CC1AD845"
NS_VERBINDUNG = "urn:x-cast:com.google.cast.tp.connection"
NS_HERZ = "urn:x-cast:com.google.cast.tp.heartbeat"
NS_EMPFAENGER = "urn:x-cast:com.google.cast.receiver"
NS_MEDIEN = "urn:x-cast:com.google.cast.media"
MDNS = ("224.0.0.251", 5353)
DIENST = "_googlecast._tcp.local"
TYPEN = {".m3u8": "application/x-mpegURL", ".mpd": "application/dash+xml", ".mp4": "video/mp4", ".m4v": "video/mp4",
         ".webm": "video/webm", ".mkv": "video/x-matroska", ".ts": "video/mp2t", ".mp3": "audio/mpeg", ".mp2": "audio/mpeg",
         ".m4a": "audio/mp4", ".m4b": "audio/mp4", ".aac": "audio/aac", ".flac": "audio/flac", ".ogg": "audio/ogg",
         ".oga": "audio/ogg", ".opus": "audio/ogg", ".weba": "audio/webm", ".wav": "audio/wav", ".mka": "audio/x-matroska",
         ".ac3": "audio/ac3", ".eac3": "audio/eac3", ".jpg": "image/jpeg", ".png": "image/png"}


class CastFehler(ValueError):
    pass


# --- mDNS: Geraete finden ------------------------------------------------------------------------
def _name_lesen(d, i, tiefe=0):
    teile = []
    while i < len(d):
        laenge = d[i]
        if laenge == 0:
            return ".".join(teile), i + 1
        if laenge & 0xC0 == 0xC0:  # Verweis (Kompression)
            ziel = ((laenge & 0x3F) << 8) | d[i + 1]
            if tiefe > 10:
                raise CastFehler("mDNS: Schleife")
            rest, _ = _name_lesen(d, ziel, tiefe + 1)
            return ".".join(teile + ([rest] if rest else [])), i + 2
        teile.append(d[i + 1:i + 1 + laenge].decode("utf-8", "replace"))
        i += 1 + laenge
    raise CastFehler("mDNS: Name zu kurz")


def mdns_anfrage():
    kopf = struct.pack(">HHHHHH", 0, 0, 1, 0, 0, 0)
    name = b"".join(bytes([len(t)]) + t.encode("ascii") for t in DIENST.split(".")) + b"\x00"
    return kopf + name + struct.pack(">HH", 12, 0x8001)  # PTR, Klasse IN mit "Antwort direkt an mich"


def mdns_lesen(d):
    """Antwortpaket -> {"ptr": [...], "srv": {name: (ziel, port)}, "a": {host: ip}, "txt": {name: {k: v}}}."""
    erg = {"ptr": [], "srv": {}, "a": {}, "txt": {}}
    _, flags, fragen, antworten, autoritaet, zusatz = struct.unpack(">HHHHHH", d[:12])
    i = 12
    for _ in range(fragen):
        _, i = _name_lesen(d, i)
        i += 4
    for _ in range(antworten + autoritaet + zusatz):
        name, i = _name_lesen(d, i)
        typ, _, _, laenge = struct.unpack(">HHIH", d[i:i + 10])
        i += 10
        roh = d[i:i + laenge]
        if typ == 12:
            erg["ptr"].append(_name_lesen(d, i)[0])
        elif typ == 33:
            port = struct.unpack(">H", roh[4:6])[0]
            erg["srv"][name] = (_name_lesen(d, i + 6)[0], port)
        elif typ == 1 and laenge == 4:
            erg["a"][name] = socket.inet_ntoa(roh)
        elif typ == 16:
            werte, j = {}, 0
            while j < len(roh):
                n = roh[j]
                eintrag = roh[j + 1:j + 1 + n].decode("utf-8", "replace")
                k, _, v = eintrag.partition("=")
                werte[k] = v
                j += 1 + n
            erg["txt"][name] = werte
        i += laenge
    return erg


def suchen(dauer=2.5, sock=None, uhr=time.monotonic):
    """Cast-Geraete im Heimnetz: [{"name", "modell", "ip", "port", "id"}]."""
    s = sock or socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        if sock is None:
            s.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 2)
            s.bind(("0.0.0.0", 0))
        s.settimeout(0.3)
        anfrage = mdns_anfrage()
        s.sendto(anfrage, MDNS)
        gesammelt = {"ptr": [], "srv": {}, "a": {}, "txt": {}}
        ende, nochmal = uhr() + dauer, uhr() + dauer / 2
        while uhr() < ende:
            if nochmal and uhr() > nochmal:
                s.sendto(anfrage, MDNS)
                nochmal = None
            try:
                daten, absender = s.recvfrom(9000)
            except socket.timeout:
                continue
            except OSError:
                break
            try:
                teil = mdns_lesen(daten)
            except (CastFehler, struct.error, IndexError):
                continue
            gesammelt["ptr"] += teil["ptr"]
            for k in ("srv", "a", "txt"):
                gesammelt[k].update(teil[k])
            for name in teil["ptr"] + list(teil["srv"]):  # Antwort ohne A-Satz: Absender-IP
                ziel = teil["srv"].get(name, ("", 0))[0]
                if ziel and ziel not in gesammelt["a"]:
                    gesammelt["a"][ziel] = absender[0]
    finally:
        if sock is None:
            s.close()
    geraete = {}
    for name in set(gesammelt["ptr"]) | set(gesammelt["srv"]):
        if not name.endswith(DIENST) or name not in gesammelt["srv"]:
            continue
        ziel, port = gesammelt["srv"][name]
        ip = gesammelt["a"].get(ziel)
        if not ip:
            continue
        txt = gesammelt["txt"].get(name, {})
        geraete[ip] = {"name": txt.get("fn") or name.split(".")[0], "modell": txt.get("md", ""), "ip": ip, "port": port,
                       "id": txt.get("id", ip)}
    return sorted(geraete.values(), key=lambda g: g["name"].lower())


# --- Cast-Verbindung ---------------------------------------------------------------------------
def _varint(n):
    roh = bytearray()
    while True:
        b = n & 0x7F
        n >>= 7
        roh.append(b | (0x80 if n else 0))
        if not n:
            return bytes(roh)


def _feld_text(nummer, text):
    roh = text.encode("utf-8")
    return _varint((nummer << 3) | 2) + _varint(len(roh)) + roh


def nachricht_bauen(quelle, ziel, namensraum, daten):
    return (b"\x08\x00" + _feld_text(2, quelle) + _feld_text(3, ziel) + _feld_text(4, namensraum) + b"\x28\x00"
            + _feld_text(6, json.dumps(daten, separators=(",", ":"))))


def nachricht_lesen(roh):
    """CastMessage -> (quelle, ziel, namensraum, json-daten)."""
    felder, i = {}, 0
    try:
        while i < len(roh):
            schluessel, i = _varint_lesen(roh, i)
            nummer, art = schluessel >> 3, schluessel & 7
            if art == 0:
                wert, i = _varint_lesen(roh, i)
            elif art == 2:
                laenge, i = _varint_lesen(roh, i)
                if i + laenge > len(roh):
                    raise IndexError
                wert = roh[i:i + laenge]
                i += laenge
            else:
                raise CastFehler("Protobuf: unbekannte Feldart")
            felder[nummer] = wert
    except IndexError:
        raise CastFehler("Protobuf: Nachricht abgeschnitten")
    try:
        daten = json.loads(felder.get(6, b"{}").decode("utf-8")) if isinstance(felder.get(6), bytes) else {}
    except ValueError:
        daten = {}
    text = lambda n: felder.get(n, b"").decode("utf-8", "replace") if isinstance(felder.get(n), bytes) else ""
    return text(2), text(3), text(4), daten


def _varint_lesen(roh, i):
    wert, verschiebung = 0, 0
    while True:
        b = roh[i]
        i += 1
        wert |= (b & 0x7F) << verschiebung
        if not b & 0x80:
            return wert, i
        verschiebung += 7


class Verbindung:
    """Eine kurze Sitzung mit einem Geraet (verbinden, Befehle, schliessen)."""

    def __init__(self, ip, port=8009, zeit=8, oeffnen=None):
        self.zeit = zeit
        self.nummer = random.randint(1, 100000)
        if oeffnen:
            self.s = oeffnen(ip, port)
        else:
            roh = socket.create_connection((ip, port), timeout=zeit)
            kontext = ssl.create_default_context()
            kontext.check_hostname, kontext.verify_mode = False, ssl.CERT_NONE  # Geraete-Zertifikat ist selbst signiert
            self.s = kontext.wrap_socket(roh)
        self.senden("receiver-0", NS_VERBINDUNG, {"type": "CONNECT"})

    def schliessen(self):
        try:
            self.s.close()
        except OSError:
            pass

    def __enter__(self):
        return self

    def __exit__(self, *a):
        self.schliessen()

    def senden(self, ziel, namensraum, daten, quelle="sender-0"):
        roh = nachricht_bauen(quelle, ziel, namensraum, daten)
        self.s.sendall(struct.pack(">I", len(roh)) + roh)

    def _lesen_genau(self, n):
        puffer = b""
        while len(puffer) < n:
            teil = self.s.recv(n - len(puffer))
            if not teil:
                raise CastFehler("Gerät hat die Verbindung beendet")
            puffer += teil
        return puffer

    def lesen(self):
        laenge = struct.unpack(">I", self._lesen_genau(4))[0]
        if laenge > 1 << 20:
            raise CastFehler("Antwort zu groß")
        return nachricht_lesen(self._lesen_genau(laenge))

    def anfrage(self, ziel, namensraum, daten, warte_auf):
        """Befehl mit requestId senden und auf die Antwort mit einem der Typen warten (PING beantworten)."""
        self.nummer += 1
        daten = dict(daten, requestId=self.nummer)
        self.senden(ziel, namensraum, daten)
        ende = time.monotonic() + self.zeit
        while time.monotonic() < ende:
            quelle, _, ns, antwort = self.lesen()
            if ns == NS_HERZ and antwort.get("type") == "PING":
                self.senden(quelle, NS_HERZ, {"type": "PONG"})
                continue
            if antwort.get("type") in ("LOAD_FAILED", "LOAD_CANCELLED", "INVALID_REQUEST", "LAUNCH_ERROR"):
                raise CastFehler("Gerät lehnt ab: %s" % antwort.get("type"))
            if antwort.get("type") in warte_auf and (antwort.get("requestId") in (self.nummer, 0, None)):
                return antwort
        raise CastFehler("Keine Antwort vom Gerät")

    def empfaenger(self):
        return self.anfrage("receiver-0", NS_EMPFAENGER, {"type": "GET_STATUS"}, ("RECEIVER_STATUS",))["status"]

    def medien_app(self, starten=False):
        """transportId der laufenden Medien-App (bei starten: Default Media Receiver starten)."""
        status = self.empfaenger()
        for a in status.get("applications") or []:
            if NS_MEDIEN in [n.get("name") for n in a.get("namespaces") or []]:
                self.senden(a["transportId"], NS_VERBINDUNG, {"type": "CONNECT"})
                return a["transportId"], status
        if not starten:
            return None, status
        status = self.anfrage("receiver-0", NS_EMPFAENGER, {"type": "LAUNCH", "appId": APP_MEDIA}, ("RECEIVER_STATUS",))["status"]
        for _ in range(10):
            for a in status.get("applications") or []:
                if a.get("appId") == APP_MEDIA and a.get("transportId"):
                    self.senden(a["transportId"], NS_VERBINDUNG, {"type": "CONNECT"})
                    return a["transportId"], status
            time.sleep(0.5)
            status = self.empfaenger()
        raise CastFehler("Medien-App startet nicht")

    def medien_status(self, transport):
        antwort = self.anfrage(transport, NS_MEDIEN, {"type": "GET_STATUS"}, ("MEDIA_STATUS",))
        liste = antwort.get("status") or []
        return liste[0] if liste else {}


def inhaltstyp(url):
    pfad = url.split("?", 1)[0].lower()
    for endung, typ in TYPEN.items():
        if pfad.endswith(endung):
            return typ
    if "/api/hls/" in pfad or "m3u8" in pfad:
        return "application/x-mpegURL"
    return "video/mp4"


def abspielen(ip, url, titel="", bild="", live=False, port=8009, oeffnen=None, mime=None):
    with Verbindung(ip, port, oeffnen=oeffnen) as v:
        transport, _ = v.medien_app(starten=True)
        medien = {"contentId": url, "contentUrl": url, "streamType": "LIVE" if live else "BUFFERED",
                  "contentType": mime or inhaltstyp(url),
                  "metadata": {"metadataType": 3 if (mime or "").startswith("audio/") else 0, "title": titel or "H0rSt", "images": [{"url": bild}] if bild else []}}
        antwort = v.anfrage(transport, NS_MEDIEN, {"type": "LOAD", "media": medien, "autoplay": True},
                            ("MEDIA_STATUS",))
        status = (antwort.get("status") or [{}])[0]
        return {"zustand": status.get("playerState", ""), "titel": titel}


def steuern(ip, was, wert=None, port=8009, oeffnen=None):
    """was: pause, weiter, stopp, lautstaerke (wert 0-100), stumm (wert bool), stand."""
    with Verbindung(ip, port, oeffnen=oeffnen) as v:
        if was in ("lautstaerke", "stumm"):
            lautst = {"level": max(0, min(100, int(wert))) / 100.0} if was == "lautstaerke" else {"muted": bool(wert)}
            status = v.anfrage("receiver-0", NS_EMPFAENGER, {"type": "SET_VOLUME", "volume": lautst}, ("RECEIVER_STATUS",))["status"]
            return _stand(status, {})
        transport, status = v.medien_app()
        if not transport:
            if was == "stand":
                return _stand(status, {})
            raise CastFehler("Auf dem Gerät läuft gerade nichts")
        medien = v.medien_status(transport)
        if was == "stand":
            return _stand(status, medien)
        sitzung = medien.get("mediaSessionId")
        if sitzung is None:
            raise CastFehler("Auf dem Gerät läuft gerade nichts")
        typ = {"pause": "PAUSE", "weiter": "PLAY", "stopp": "STOP"}.get(was)
        if not typ:
            raise CastFehler("Unbekannter Befehl")
        antwort = v.anfrage(transport, NS_MEDIEN, {"type": typ, "mediaSessionId": sitzung}, ("MEDIA_STATUS",))
        return _stand(status, (antwort.get("status") or [{}])[0])


def _stand(empfaenger, medien):
    lautst = empfaenger.get("volume") or {}
    app = (empfaenger.get("applications") or [{}])[0]
    meta = (medien.get("media") or {}).get("metadata") or {}
    return {"app": app.get("displayName", ""), "zustand": medien.get("playerState", ""), "titel": meta.get("title", ""),
            "lautstaerke": round(float(lautst.get("level") or 0) * 100), "stumm": bool(lautst.get("muted"))}
