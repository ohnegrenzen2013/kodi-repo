"""CloudStream-Repositories verwalten: Repositories und Extensions lesen, pruefen und .cs3-Dateien laden.

H0rSt fuehrt CloudStream-Extensions NICHT aus (das sind Android-DEX-Dateien mit CloudStream-API). Diese
Verwaltung holt nur Repository-Listen, zeigt Name/Version/Sprache/Groesse und laedt eine Extension mit
SHA-256-Pruefung in den Datenordner - zum Beispiel fuer eine CloudStream-Installation auf demselben Geraet.
"""

import hashlib
import json
import os
import re
import threading

from .netz import NetzFehler, antwort_holen, antwort_holen_roh, oeffentlich_antwort_holen, oeffentlich_antwort_holen_roh

MAX_REPOS = 30
MAX_PLUGINS = 500
MAX_DATEI = 30 * 1024 * 1024


class CloudStreamFehler(ValueError):
    pass


class CloudStreamRepos:
    def __init__(self, datenordner, holen=None, holen_roh=None):
        self.ordner = os.path.join(datenordner or ".", "cloudstream")
        self.holen = holen or oeffentlich_antwort_holen(antwort_holen)
        self.holen_roh = holen_roh or oeffentlich_antwort_holen_roh(antwort_holen_roh)
        self._sperre = threading.Lock()
        self._repos = []   # [{url, name, plugins:[...]}]

    @staticmethod
    def _url(wert):
        url = str(wert or "").strip()
        if url.startswith("cloudstreamrepo://"):
            url = "https://" + url[len("cloudstreamrepo://"):]
        if not url.lower().startswith(("http://", "https://")):
            raise CloudStreamFehler("Nur http:// und https://")
        return url

    def _json(self, url):
        try:
            status, text = self.holen(url, "GET", {"Accept": "application/json"}, None)
        except NetzFehler as fehler:
            raise CloudStreamFehler(str(fehler))
        if status >= 400:
            raise CloudStreamFehler("HTTP %d bei %s" % (status, url))
        try:
            return json.loads(text)
        except ValueError:
            raise CloudStreamFehler("Kein JSON unter %s" % url)

    def hinzufuegen(self, url, name=""):
        url = self._url(url)
        repo = self._json(url)
        if not isinstance(repo, dict) or not isinstance(repo.get("pluginLists"), list):
            raise CloudStreamFehler("Kein CloudStream-Repository (pluginLists fehlt)")
        eintrag = {"url": url, "name": str(name or repo.get("name") or url)[:100], "plugins": []}
        for liste in repo["pluginLists"][:MAX_REPOS]:
            try:
                daten = self._json(str(liste))
            except CloudStreamFehler:
                continue
            for roh in (daten if isinstance(daten, list) else [])[:MAX_PLUGINS]:
                if not isinstance(roh, dict) or not roh.get("url") or not roh.get("internalName"):
                    continue
                eintrag["plugins"].append({"url": str(roh["url"]), "name": str(roh.get("name") or roh["internalName"])[:100],
                                           "internalName": str(roh["internalName"])[:100], "version": roh.get("version"),
                                           "language": str(roh.get("language") or ""), "description": str(roh.get("description") or "")[:500],
                                           "fileSize": roh.get("fileSize"), "fileHash": str(roh.get("fileHash") or ""),
                                           "icon": str(roh.get("iconUrl") or ""), "status": roh.get("status", 1)})
        with self._sperre:
            self._repos = [r for r in self._repos if r["url"] != url][:MAX_REPOS - 1] + [eintrag]
        return eintrag

    def liste(self):
        with self._sperre:
            return [{"url": r["url"], "name": r["name"], "plugins": [dict(p) for p in r["plugins"]]} for r in self._repos]

    def entfernen(self, url):
        with self._sperre:
            vorher = len(self._repos)
            self._repos = [r for r in self._repos if r["url"] != self._url(url)]
        if len(self._repos) == vorher:
            raise CloudStreamFehler("Repository nicht gefunden")
        return {"ok": True}

    def _plugin(self, url):
        for repo in self._repos:
            for p in repo["plugins"]:
                if p["url"] == url:
                    return p
        raise CloudStreamFehler("Extension nicht in einem hinzugefuegten Repository")

    def installieren(self, url):
        plugin = self._plugin(str(url or ""))
        ziel_url = str(plugin["url"] or "")
        if not ziel_url.lower().startswith(("http://", "https://")):
            raise CloudStreamFehler("Extension-Adresse muss http:// oder https:// sein")
        try:
            status, daten = self.holen_roh(ziel_url, "GET", {"User-Agent": "Rezeptserver-CloudStream"}, None,
                                           grenze=MAX_DATEI + 1)
        except NetzFehler as fehler:
            raise CloudStreamFehler(str(fehler))
        if status != 200 or not daten:
            raise CloudStreamFehler("Download fehlgeschlagen (HTTP %d)" % status)
        if len(daten) > MAX_DATEI:
            raise CloudStreamFehler("Extension groesser als 30 MB")
        erwartet = str(plugin.get("fileHash") or "")
        if erwartet.startswith("sha256-"):
            ist = "sha256-" + hashlib.sha256(daten).hexdigest()
            if ist != erwartet:
                raise CloudStreamFehler("SHA-256 passt nicht (Datei beschaedigt oder veraendert)")
        os.makedirs(self.ordner, exist_ok=True)
        name = re.sub(r"[^\w.-]+", "_", plugin["internalName"]) + ".cs3"
        pfad = os.path.join(self.ordner, name)
        with open(pfad, "wb") as f:
            f.write(daten)
        return {"ok": True, "pfad": pfad, "name": name, "groesse": len(daten), "hash": erwartet or ""}
