"""Kuratierter Stremio-Community-Addon-Katalog.

Quelle ist der offizielle Community-Katalog von Cinemeta
(https://v3-cinemeta.strem.io/addon_catalog/all/community.json). Die Datei
community_addons.json haelt eine gepruefte Auswahl ohne Adult-Kennzeichnung;
installiert wird nur ein Eintrag aus dieser Liste, ueber den bestehenden Weg
anbieter.hinzufuegen(..., typ="stremio-addon"). Fremde Addons sind Programme mit
den Rechten von H0rSt; die Oberflaeche weist darauf hin.
"""

import json
import os
from urllib.parse import urlsplit

from . import anbieter

DATEI = os.path.join(os.path.dirname(os.path.abspath(__file__)), "community_addons.json")
_cache = None


def daten():
    global _cache
    if _cache is None:
        with open(DATEI, encoding="utf-8") as f:
            _cache = json.load(f)
    return _cache


def _adresse(url):
    try:
        teile = urlsplit(str(url or ""))
    except ValueError:
        return ""
    if teile.scheme not in ("http", "https") or not teile.hostname:
        return ""
    return str(url)


def alle():
    ergebnis = []
    for eintrag in daten().get("addons") or []:
        manifest = eintrag.get("manifest") or {}
        url = _adresse(eintrag.get("transportUrl"))
        if not url or not manifest.get("id") or not str(manifest.get("name") or "").strip():
            continue
        if (manifest.get("behaviorHints") or {}).get("adult"):
            continue
        ergebnis.append({"transportUrl": url, "manifest": manifest})
    return ergebnis


def liste(suche="", typ=""):
    text = " ".join(str(suche or "").lower().split())
    ergebnis = []
    for eintrag in alle():
        m = eintrag["manifest"]
        if typ and typ not in (m.get("types") or []):
            continue
        heu = " ".join(str(m.get(k) or "") for k in ("id", "name", "description")).lower()
        if text and text not in heu:
            continue
        ergebnis.append(eintrag)
    return ergebnis


def finde(url):
    url = _adresse(url)
    return next((e for e in alle() if e["transportUrl"] == url), None)


def installiert(daten_):
    vorhanden = {}
    werte = (daten_ or {}).get("einstellungen") or {}
    for anbieter_id, eintrag in ((daten_ or {}).get("anbieter") or {}).items():
        if eintrag.get("typ") != "stremio-addon":
            continue
        url = _adresse((werte.get(anbieter_id) or {}).get("url"))
        if url:
            vorhanden[url] = anbieter_id
    return vorhanden


def installieren(daten_, module, url):
    eintrag = finde(url)
    if not eintrag:
        raise anbieter.AnbieterFehler("Addon steht nicht im kuratierten Community-Katalog")
    if eintrag["transportUrl"] in installiert(daten_):
        raise anbieter.AnbieterFehler("Addon ist schon eingetragen")
    name = str(eintrag["manifest"].get("name") or "").strip()
    anbieter_id = anbieter.freie_id(daten_, module, name)
    anbieter.hinzufuegen(daten_, module, name, "addons", "url", {"url": eintrag["transportUrl"]},
                         typ="stremio-addon", anbieter_id=anbieter_id)
    return anbieter_id


def entfernen(daten_, anbieter_id):
    anbieter.entfernen(daten_, str(anbieter_id or ""))
    return True
