"""Crawler und FTP-Suche.

  * Crawler: durchsucht einen Heimspeicher (WebDAV/AiCloud, FTP, offenes Verzeichnis) Ordner fuer Ordner nach
    Dateinamen, in der Breite zuerst, mit Grenzen fuer Tiefe, Ordnerzahl und Zeit. So findet man den Film auf der
    Router-Platte, der NAS oder in einem offenen Verzeichnis, ohne sich durchzuklicken.
  * Offene Verzeichnisse: Webseiten mit Dateiliste ("Index of /", Apache, nginx, lighttpd, Caddy). Gelesen werden
    nur Links auf Unterordner und Dateien derselben Adresse; nie nach oben, nie auf fremde Hosts.
  * FTP-Suche ueber den NAPALM FTP Indexer (searchftps.net): sucht in den Dateilisten oeffentlicher FTP-Server.
    Aus der Ergebnisseite werden alle ftp://-Adressen gelesen; abgespielt wird ueber den FTP-Client von H0rSt.
    Blockt die Seite die Abfrage (Cloudflare), meldet H0rSt das und bietet die Suche im Browser an.
"""

from .crawler_ftp import *
from .crawler_grund import *
from .crawler_web import *
from .crawler_ftp import _MAMONT_TREFFER, _MAMONT_ZEILE, _MAMONT_WEITER, _mamont_groesse
from .crawler_grund import _FTP, _GROESSE, _LINK, _bytes
from .crawler_web import _ERGEBNIS, _HREF, _SEITE_ENDUNGEN, _abrufen, _endung
