"""FTP-Suche ueber NAPALM und Mamont."""

import html
import posixpath
import re
import urllib.error
import urllib.request
from urllib.parse import unquote, urlencode, urlsplit

from .crawler_grund import CrawlerFehler, NAPALM, _FTP, _GROESSE, _bytes
from .netz import USER_AGENT


# --- NAPALM FTP Indexer -----------------------------------------------------------------------
def napalm_adresse(text):
    """Suchadresse fuer den Browser (und fuer die Abfrage)."""
    return NAPALM + "?" + urlencode({"action": "result", "args": "k=%s&t=and&o=date-desc&s=0" % text})


def napalm_lesen(seite):
    """Alle ftp://-Adressen einer Ergebnisseite, mit Groesse, wenn sie daneben steht."""
    treffer, gesehen = [], set()
    for m in _FTP.finditer(seite):
        url = html.unescape(m.group(0)).rstrip(".,;)")
        if url in gesehen or url.endswith("/"):
            continue
        gesehen.add(url)
        t = urlsplit(url)
        name = unquote(posixpath.basename(t.path))
        if not name:
            continue
        umgebung = re.sub(r"<[^>]+>", " ", seite[m.end():m.end() + 400])
        g = _GROESSE.search(umgebung)
        from .heimspeicher import art_von
        treffer.append({"name": name, "url": url, "server": t.hostname or "", "pfad": unquote(t.path),
                        "groesse": _bytes(g) if g else 0, "art": art_von(name)})
    return treffer


def napalm_suchen(text, holen=None):
    text = " ".join(str(text or "").split())[:120]
    if len(text) < 3:
        raise CrawlerFehler("Suchbegriff zu kurz (mindestens 3 Zeichen)")
    url = napalm_adresse(text)
    try:
        if holen:
            seite = holen(url)
        else:
            anfrage = urllib.request.Request(url, headers={
                "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) " + USER_AGENT, "Accept": "text/html"})
            with urllib.request.urlopen(anfrage, timeout=20) as a:
                seite = a.read(4 * 1024 * 1024).decode("utf-8", "replace")
    except urllib.error.HTTPError as f:
        f.close()
        if f.code in (403, 429, 503):
            raise CrawlerFehler("Der NAPALM FTP Indexer lässt automatische Abfragen von hier nicht zu (HTTP %d, "
                                "Cloudflare). Die Suche im Browser öffnen." % f.code)
        raise CrawlerFehler("NAPALM: HTTP %d" % f.code)
    except (urllib.error.URLError, OSError) as f:
        raise CrawlerFehler("NAPALM nicht erreichbar: %s" % str(getattr(f, "reason", f))[:150])
    if "cf-error-details" in seite or "challenge-platform" in seite:
        raise CrawlerFehler("Der NAPALM FTP Indexer verlangt eine Browser-Prüfung (Cloudflare). Die Suche im Browser öffnen.")
    return napalm_lesen(seite)


def browser_adresse(text):
    return napalm_adresse(" ".join(str(text or "").split())[:120])


# --- Mamont (mmnt.net / mmnt.ru): Verzeichnis und Suche oeffentlicher FTP-Server, ergaenzt NAPALM -----------------
MAMONT = "https://www.mmnt.ru/int/get"
_MAMONT_TREFFER = re.compile(r'<a href="(ftp://[^"]+)" target=_blank>', re.I)
_MAMONT_ZEILE = re.compile(r"<tr><td><tt>(?:&nbsp;)*([^<]*)</td><td><tt><nobr>(?:&nbsp;)*([^<]*)</td><td><tt><nobr>(?:&nbsp;)*([^<]*)"
                           r"</td><td><tt><nobr>(?:&nbsp;)*([^<]*)</td>", re.I)
_MAMONT_WEITER = re.compile(r'HREF="/int/get\?([^"]*ot=\d+[^"]*)">Next page', re.I)


def mamont_adresse(text, ab=""):
    """Suchadresse; ab = Abfrageteil des "Next page"-Links (samt Sitzung sd und Versatz ot)."""
    if ab and re.match(r"^[\w=&.%+-]+$", ab):
        return MAMONT + "?" + ab
    return MAMONT + "?" + urlencode({"in": "f", "st": text})


def _mamont_groesse(text):
    m = re.search(r"\[([\d ]+) bytes\]", text)
    if m:
        return int(m.group(1).replace(" ", ""))
    m = re.match(r"\s*([\d.]+)\s*([KMGT]?)b", text, re.I)
    if not m:
        return 0
    return int(float(m.group(1)) * 1024 ** ("_KMGT".index(m.group(2).upper() or "_")))


def mamont_lesen(seite):
    """Ergebnisseite -> Treffer wie bei NAPALM (name, url, server, pfad, groesse, art) plus Land und Aenderungsdatum."""
    from .heimspeicher import art_von
    treffer, gesehen = [], set()
    for m in _MAMONT_TREFFER.finditer(seite):
        url = html.unescape(m.group(1))
        if url in gesehen or url.endswith("/"):
            continue
        gesehen.add(url)
        t = urlsplit(url)
        name = unquote(posixpath.basename(t.path))
        if not name:
            continue
        z = _MAMONT_ZEILE.search(seite, m.end(), m.end() + 1500)
        land, _, geaendert, groesse = (html.unescape(x).strip() for x in z.groups()) if z else ("", "", "", "")
        treffer.append({"name": name, "url": url, "server": t.hostname or "", "pfad": unquote(t.path),
                        "groesse": _mamont_groesse(groesse), "art": art_von(name), "land": land, "geaendert": geaendert,
                        "quelle": "Mamont"})
    weiter = _MAMONT_WEITER.search(seite)
    return treffer, html.unescape(weiter.group(1)) if weiter else ""


def mamont_suchen(text, holen=None, ab=""):
    """Mamont-FTP-Suche: (treffer, naechstes "ab" oder "")."""
    text = " ".join(str(text or "").split())[:120]
    if len(text) < 3:
        raise CrawlerFehler("Suchbegriff zu kurz (mindestens 3 Zeichen)")
    url = mamont_adresse(text, ab)
    try:
        if holen:
            seite = holen(url)
        else:
            anfrage = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 (X11; Linux x86_64) " + USER_AGENT})
            with urllib.request.urlopen(anfrage, timeout=25) as a:
                seite = a.read(4 * 1024 * 1024).decode("cp1251", "replace")
    except urllib.error.HTTPError as f:
        f.close()
        raise CrawlerFehler("Mamont: HTTP %d" % f.code)
    except (urllib.error.URLError, OSError) as f:
        raise CrawlerFehler("Mamont nicht erreichbar: %s" % str(getattr(f, "reason", f))[:150])
    return mamont_lesen(seite)


def ftp_suchen(text, holen_napalm=None, holen_mamont=None, ab=""):
    """NAPALM und Mamont zusammen: {treffer, fehler, quellen, weiter}. Eine Quelle darf ausfallen."""
    treffer, fehler, quellen, weiter = [], [], [], ""
    if not ab:
        try:
            n = napalm_suchen(text, holen_napalm)
            for t in n:
                t["quelle"] = "NAPALM"
            treffer += n
            quellen.append("NAPALM %d" % len(n))
        except CrawlerFehler as f:
            if "zu kurz" in str(f):
                raise
            fehler.append(str(f))
    try:
        m, weiter = mamont_suchen(text, holen_mamont, ab)
        bekannt = {t["url"] for t in treffer}
        treffer += [t for t in m if t["url"] not in bekannt]
        quellen.append("Mamont %d" % len(m))
    except CrawlerFehler as f:
        if "zu kurz" in str(f):
            raise
        fehler.append(str(f))
    return {"treffer": treffer, "fehler": " · ".join(fehler) if not treffer else "", "hinweis": " · ".join(fehler),
            "quellen": quellen, "weiter": weiter}
