"""Crawler: gemeinsame Konstanten, Fehler und Breitensuche."""

import re
import time
from collections import deque

MAX_ORDNER = 400
MAX_TIEFE = 10
MAX_ZEIT = 45.0
MAX_TREFFER = 500
NAPALM = "https://www.searchftps.net/"
_LINK = re.compile(r"""<a\s[^>]*?href\s*=\s*["']([^"'#]+)["'][^>]*>(.*?)</a>""", re.I | re.S)
_FTP = re.compile(r"""ftps?://[^\s"'<>]+""", re.I)
_GROESSE = re.compile(r"(\d+(?:[.,]\d+)?)\s*([KMGT])i?B?\b", re.I)


class CrawlerFehler(ValueError):
    pass


def woerter(text):
    return [w for w in re.split(r"[\s._\-]+", str(text or "").lower()) if w]


def passt(name, such):
    n = " ".join(woerter(name))
    return all(w in n for w in such)


def crawlen(speicher, text, liste, nur_medien=False, max_ordner=MAX_ORDNER, max_zeit=MAX_ZEIT, uhr=time.monotonic):
    """Breitensuche ueber liste(speicher, pfad) -> Eintraege. Gibt {"treffer", "ordner", "fertig", "fehler"}."""
    such = woerter(text)
    if not such or sum(len(w) for w in such) < 2:
        raise CrawlerFehler("Suchbegriff zu kurz")
    start, treffer, fehler = uhr(), [], []
    schlange, gesehen, ordner = deque([("/", 0)]), {"/"}, 0
    while schlange and ordner < max_ordner and uhr() - start < max_zeit and len(treffer) < MAX_TREFFER:
        pfad, tiefe = schlange.popleft()
        ordner += 1
        try:
            eintraege = liste(speicher, pfad)
        except Exception as f:
            fehler.append("%s: %s" % (pfad, str(f)[:120]))
            continue
        for e in eintraege:
            if e["ordner"]:
                if tiefe + 1 <= MAX_TIEFE and e["pfad"] not in gesehen:
                    gesehen.add(e["pfad"])
                    schlange.append((e["pfad"], tiefe + 1))
                if passt(e["name"], such) and not nur_medien:
                    treffer.append(e)
            elif passt(e["name"], such) and (not nur_medien or e["art"] in ("video", "audio")):
                treffer.append(e)
    return {"treffer": treffer[:MAX_TREFFER], "ordner": ordner, "fertig": not schlange,
            "sekunden": round(uhr() - start, 1), "fehler": fehler[:5]}


def _bytes(m):
    zahl = float(m.group(1).replace(",", "."))
    return int(zahl * 1024 ** ("KMGT".index(m.group(2).upper()) + 1))
