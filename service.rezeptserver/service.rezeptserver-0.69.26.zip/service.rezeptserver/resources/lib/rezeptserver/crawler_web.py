"""Offene Verzeichnisse, Suchmaschine und Web-Crawler."""

import html
import posixpath
import re
import time
import urllib.error
import urllib.request
from collections import deque
from urllib.parse import unquote, urlencode, urljoin, urlsplit

from .crawler_grund import CrawlerFehler, MAX_TREFFER, MAX_ZEIT, _GROESSE, _LINK, _bytes
from .netz import USER_AGENT


# --- Offene Verzeichnisse ----------------------------------------------------------------------
def _abrufen(speicher, url, holen=None):
    from .heimspeicher import kopf, oeffner
    if holen:
        return holen(url)
    try:
        anfrage = urllib.request.Request(url, headers=dict(kopf(speicher), Accept="text/html,*/*"))
        with oeffner(speicher.get("zertifikat") == "eigenes").open(anfrage, timeout=20) as a:
            if "html" not in (a.headers.get("Content-Type") or "text/html"):
                raise CrawlerFehler("Keine Dateiliste (kein HTML)")
            return a.read(4 * 1024 * 1024).decode(a.headers.get_content_charset() or "utf-8", "replace")
    except urllib.error.HTTPError as f:
        f.close()
        raise CrawlerFehler("HTTP %d" % f.code)
    except (urllib.error.URLError, OSError) as f:
        raise CrawlerFehler("Nicht erreichbar: %s" % str(getattr(f, "reason", f))[:150])


def verzeichnis(speicher, pfad="/", holen=None):
    """Eine "Index of"-Seite -> Eintraege wie bei WebDAV (Groesse, wenn die Seite sie nennt)."""
    from .heimspeicher import SpeicherFehler, adresse, art_von, pfad_sauber
    pfad = pfad_sauber(pfad)
    url = adresse(speicher, pfad)
    if not url.endswith("/"):
        url += "/"
    try:
        text = _abrufen(speicher, url, holen)
    except CrawlerFehler as f:
        raise SpeicherFehler(str(f))
    basis = urlsplit(url)
    eintraege, gesehen = [], set()
    for m in _LINK.finditer(text):
        href = html.unescape(m.group(1)).strip()
        if not href or href.startswith(("?", "mailto:", "javascript:")):
            continue
        ziel = urlsplit(urljoin(url, href))
        if ziel.netloc != basis.netloc or ziel.query or not ziel.path.startswith(basis.path) or ziel.path == basis.path:
            continue  # nach oben, fremd, Sortier-Links
        rest = unquote(ziel.path[len(basis.path):])
        ordner = rest.endswith("/")
        name = rest.rstrip("/")
        if not name or "/" in name or name in gesehen:
            continue
        gesehen.add(name)
        nachher = text[m.end():m.end() + 200]
        g = _GROESSE.search(re.sub(r"<[^>]+>", " ", nachher).split("\n", 1)[0]) if not ordner else None
        eintraege.append({"name": name, "pfad": pfad_sauber(posixpath.join(pfad, name)), "ordner": ordner,
                          "groesse": _bytes(g) if g else 0, "zeit": 0, "typ": "",
                          "art": "ordner" if ordner else art_von(name)})
    eintraege.sort(key=lambda e: (not e["ordner"], e["name"].lower()))
    return eintraege


# --- Suchmaschine fuer offene Verzeichnisse ----------------------------------------------------
# Wie die bekannten "Open Directory"-Suchen: eine Suchmaschine nach "Index of"-Seiten fragen, die den Begriff und
# passende Dateiendungen nennen. Die Treffer oeffnet H0rSt als offenes Verzeichnis (Crawler, Abspielen).
SUCHMASCHINE = "https://html.duckduckgo.com/html/"
ENDUNGEN = {"video": "mkv|mp4|avi|m4v|webm", "audio": "mp3|flac|m4a|ogg|opus", "bilder": "jpg|jpeg|png|gif|webp",
            "buecher": "pdf|epub|mobi|azw3|cbz", "software": "iso|zip|7z|rar|exe|apk|deb", "alle": ""}
_ERGEBNIS = re.compile(r"""class="result__a"[^>]*href="([^"]+)"[^>]*>(.*?)</a>""", re.S)


def dork(text, art="video", pub=False):
    teile = ['intitle:"index of"', '"%s"' % text.replace('"', "")]
    if ENDUNGEN.get(art):
        teile.append("(%s)" % ENDUNGEN[art])
    if pub:
        teile.append("inurl:pub")
    teile.append("-html -htm -php -asp -jsp")
    return " ".join(teile)


def verzeichnisse_suchen(text, art="video", pub=False, holen=None):
    """Offene Verzeichnisse zu einem Begriff -> [{"url", "titel", "host"}]."""
    from urllib.parse import parse_qs
    text = " ".join(str(text or "").split())[:100]
    if len(text) < 3:
        raise CrawlerFehler("Suchbegriff zu kurz (mindestens 3 Zeichen)")
    if art not in ENDUNGEN:
        raise CrawlerFehler("Unbekannte Art")
    formular = urlencode({"q": dork(text, art, pub)}).encode("ascii")
    try:
        if holen:
            seite = holen(SUCHMASCHINE, formular)
        else:
            anfrage = urllib.request.Request(SUCHMASCHINE, data=formular, headers={
                "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) " + USER_AGENT,
                "Content-Type": "application/x-www-form-urlencoded"})
            with urllib.request.urlopen(anfrage, timeout=20) as a:
                seite = a.read(2 * 1024 * 1024).decode("utf-8", "replace")
    except urllib.error.HTTPError as f:
        f.close()
        raise CrawlerFehler("Suchmaschine: HTTP %d" % f.code)
    except (urllib.error.URLError, OSError) as f:
        raise CrawlerFehler("Suchmaschine nicht erreichbar: %s" % str(getattr(f, "reason", f))[:150])
    treffer, gesehen = [], set()
    for m in _ERGEBNIS.finditer(seite):
        url = html.unescape(m.group(1))
        if "duckduckgo.com/l/" in url:  # Weiterleitung: Ziel steckt in uddg
            url = (parse_qs(urlsplit(url).query).get("uddg") or [""])[0]
        if url.startswith("//"):
            url = "https:" + url
        t = urlsplit(url)
        if t.scheme not in ("http", "https") or not t.hostname or url in gesehen:
            continue
        gesehen.add(url)
        titel = " ".join(html.unescape(re.sub(r"<[^>]+>", "", m.group(2))).split())
        if "index of" not in titel.lower():
            continue  # Foren, Reddit & Co.: keine Dateiliste
        if not url.endswith("/"):
            url = url.rsplit("/", 1)[0] + "/" if "." in posixpath.basename(t.path) else url + "/"
        treffer.append({"url": url, "titel": titel[:200], "host": t.hostname})
    return treffer


# --- Web-Crawler ------------------------------------------------------------------------------
# Folgt den Links einer Website (nur derselbe Host, Breite zuerst), beachtet robots.txt, wartet zwischen den
# Abrufen und sammelt Links auf Dateien der gewuenschten Art. Grenzen fuer Seiten, Tiefe und Zeit.
WEB_SEITEN = 150
WEB_TIEFE = 4
WEB_PAUSE = 0.3
_HREF = re.compile(r"""(?:href|src)\s*=\s*["']([^"'#\s]+)["']""", re.I)
_SEITE_ENDUNGEN = ("", ".html", ".htm", ".php", ".asp", ".aspx", ".jsp", ".shtml")


def _endung(pfad):
    name = posixpath.basename(pfad)
    return ("." + name.rsplit(".", 1)[1].lower()) if "." in name else ""


def webcrawl(start, art="video", seiten=WEB_SEITEN, tiefe=WEB_TIEFE, max_zeit=MAX_ZEIT, holen=None,
             pause=WEB_PAUSE, uhr=time.monotonic):
    """Website ab start durchsuchen -> {"dateien": [{"url", "name", "art", "seite"}], "seiten", "fertig", ...}."""
    import urllib.robotparser
    from .heimspeicher import art_von
    start = str(start or "").strip()
    basis = urlsplit(start)
    if basis.scheme not in ("http", "https") or not basis.hostname:
        raise CrawlerFehler("Startadresse muss mit http:// oder https:// beginnen")
    if art not in ENDUNGEN:
        raise CrawlerFehler("Unbekannte Art")
    endungen = tuple("." + e for e in ENDUNGEN[art].split("|")) if ENDUNGEN[art] else None
    kennung = "Mozilla/5.0 (compatible; H0rSt-Crawler) " + USER_AGENT
    roboter = urllib.robotparser.RobotFileParser()
    if not holen:
        try:
            anfrage = urllib.request.Request("%s://%s/robots.txt" % (basis.scheme, basis.netloc), headers={"User-Agent": kennung})
            with urllib.request.urlopen(anfrage, timeout=10) as a:
                roboter.parse(a.read(256 * 1024).decode("utf-8", "replace").splitlines())
        except Exception:
            roboter.parse([])  # keine robots.txt: alles erlaubt
    else:
        roboter.parse([])

    def abrufen(url):
        if holen:
            return holen(url)
        anfrage = urllib.request.Request(url, headers={"User-Agent": kennung, "Accept": "text/html"})
        with urllib.request.urlopen(anfrage, timeout=15) as a:
            if "html" not in (a.headers.get("Content-Type") or ""):
                return ""
            return a.read(3 * 1024 * 1024).decode(a.headers.get_content_charset() or "utf-8", "replace")

    anfang, schlange, gesehen = uhr(), deque([(start, 0)]), {start}
    dateien, bekannt, besucht, fehler = [], set(), 0, []
    while schlange and besucht < seiten and uhr() - anfang < max_zeit and len(dateien) < MAX_TREFFER:
        url, stufe = schlange.popleft()
        if not roboter.can_fetch(kennung, url):
            continue
        try:
            text = abrufen(url)
        except Exception as f:
            fehler.append("%s: %s" % (url, str(getattr(f, "reason", f))[:100]))
            continue
        besucht += 1
        for m in _HREF.finditer(text or ""):
            ziel = urljoin(url, html.unescape(m.group(1)))
            t = urlsplit(ziel)
            if t.scheme not in ("http", "https"):
                continue
            endung = _endung(t.path)
            name = unquote(posixpath.basename(t.path))
            if endung and endung not in _SEITE_ENDUNGEN:
                if (endungen is None or endung in endungen) and ziel not in bekannt:
                    bekannt.add(ziel)
                    dateien.append({"url": ziel, "name": name, "art": art_von(name), "seite": url})
            elif t.netloc == basis.netloc and stufe + 1 <= tiefe:
                sauber = ziel.split("#", 1)[0]
                if sauber not in gesehen:
                    gesehen.add(sauber)
                    schlange.append((sauber, stufe + 1))
        if pause and schlange:
            time.sleep(pause)
    return {"dateien": dateien, "seiten": besucht, "fertig": not schlange, "sekunden": round(uhr() - anfang, 1),
            "fehler": fehler[:5]}
