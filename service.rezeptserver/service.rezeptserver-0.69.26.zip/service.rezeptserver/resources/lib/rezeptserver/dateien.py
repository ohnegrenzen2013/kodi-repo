"""Dateibrowser fuer die Downloads auf dem H0rSt-Rechner und Ablage auf externem Speicher.

  * Orte: XDCC- und YouTube-Downloads, der eigene FTP-Ordner, Embers Download-Ordner, die Ablage und eigene Orte.
    Dazu erkannte externe Speicher: USB-Platten und SD-Karten unter /media, /mnt und /run/media (Linux, Pi) oder
    die App-Ordner auf SD-Karte und USB-Stick, die Android ohne Root und ohne Sonderrechte freigibt
    (getExternalFilesDirs, von der App gemeldet).
  * Aktionen: auflisten, abspielen/herunterladen, umbenennen, verschieben (auch zwischen Orten), loeschen, neuer Ordner.
    Jeder Pfad bleibt in seinem Ort – auch ueber symbolische Links kommt man nicht hinaus.
  * Ablage: wohin H0rSt selbst laedt (XDCC, YouTube; der FTP-Server zeigt sie mit). Eigene Orte und die Ablage
    setzen nur Profile mit dem Recht "speicher" (Profile).

Nutzerdaten "dateien": {"ablage": "", "orte": [{"name", "pfad"}]}
"""

import glob
import os
import shutil
import time

SCHLUESSEL = "dateien"
MAX_ORTE = 12
MAX_EINTRAEGE = 2000


class DateiFehler(ValueError):
    pass


def pruefe(roh):
    roh = roh if isinstance(roh, dict) else {}
    orte = []
    for o in (roh.get("orte") or [])[:MAX_ORTE]:
        pfad = str(o.get("pfad") or "")[:500] if isinstance(o, dict) else ""
        if os.path.isabs(pfad):
            orte.append({"name": " ".join(str(o.get("name") or "").split())[:40] or os.path.basename(pfad.rstrip("/\\")) or pfad,
                         "pfad": pfad})
    ablage = str(roh.get("ablage") or "")[:500]
    return {"ablage": ablage, "orte": orte}


def _schreibbar(pfad):
    return bool(pfad) and os.path.isdir(pfad) and os.access(pfad, os.W_OK | os.X_OK)


def externe_erkennen(wurzeln=("/media", "/mnt", "/run/media"), mountpoint=os.path.ismount):
    """Eingehaengte externe Speicher (Linux/Pi): /media/<name>, /media/<nutzer>/<name>, /mnt/<name>, /run/media/<nutzer>/<name>."""
    funde = []
    for w in wurzeln:
        for p in sorted(glob.glob(os.path.join(w, "*")) + glob.glob(os.path.join(w, "*", "*"))):
            if os.path.isdir(p) and mountpoint(p) and p not in funde:
                funde.append(p)
    return [{"name": "Extern: " + os.path.basename(p), "pfad": p, "art": "extern", "schreibbar": _schreibbar(p)} for p in funde]


def _groesse(pfad):
    try:
        return os.path.getsize(pfad)
    except OSError:
        return 0


def frei(pfad):
    try:
        u = shutil.disk_usage(pfad)
        return {"frei": u.free, "gesamt": u.total}
    except OSError:
        return {"frei": None, "gesamt": None}


class Dateien:
    def __init__(self, feste_orte, einstellung=None, externe=externe_erkennen, uhr=time.time):
        self.feste_orte = feste_orte  # () -> [(id, name, pfad)]
        self.einstellung = pruefe(einstellung)
        self.externe = externe
        self.app_orte = []  # von der App gemeldete Speicher (Android, ohne Root)
        self.uhr = uhr

    def orte(self):
        liste = [{"id": i, "name": n, "pfad": p, "art": "download"} for i, n, p in self.feste_orte() if p]
        for o in liste:  # die eigenen Download-Ordner von H0rSt gibt es immer
            if o["id"] in ("xdcc", "youtube") and not os.path.isdir(o["pfad"]):
                try:
                    os.makedirs(o["pfad"], exist_ok=True)
                except OSError:
                    pass
        if self.einstellung["ablage"]:
            liste.insert(0, {"id": "ablage", "name": "Ablage", "pfad": self.einstellung["ablage"], "art": "ablage"})
        liste += [{"id": "eigen%d" % i, "name": o["name"], "pfad": o["pfad"], "art": "eigen"} for i, o in enumerate(self.einstellung["orte"])]
        bekannt = {os.path.realpath(o["pfad"]) for o in liste}
        for n, e in enumerate(list(self.externe()) + self.app_orte):
            if os.path.realpath(e["pfad"]) not in bekannt:
                bekannt.add(os.path.realpath(e["pfad"]))
                liste.append(dict(e, id="extern%d" % n))
        for o in liste:
            o["da"] = os.path.isdir(o["pfad"])
            o["schreibbar"] = _schreibbar(o["pfad"])
            o.update(frei(o["pfad"]) if o["da"] else {"frei": None, "gesamt": None})
        return liste

    def _ort(self, oid):
        o = next((x for x in self.orte() if x["id"] == oid), None)
        if not o or not o["da"]:
            raise DateiFehler("Ort nicht gefunden oder nicht eingehängt")
        return o

    def pfad(self, oid, rel=""):
        """Absoluter Pfad im Ort – nie ausserhalb (auch nicht ueber Symlinks)."""
        o = self._ort(oid)
        wurzel = os.path.realpath(o["pfad"])
        rel = str(rel or "").replace("\\", "/").lstrip("/")
        ziel = os.path.realpath(os.path.join(wurzel, rel))
        if ziel != wurzel and not ziel.startswith(wurzel.rstrip(os.sep) + os.sep):
            raise DateiFehler("Pfad liegt außerhalb des Ortes")
        return ziel

    def liste(self, oid, rel=""):
        ordner = self.pfad(oid, rel)
        if not os.path.isdir(ordner):
            raise DateiFehler("Kein Ordner")
        from .heimspeicher import art_von
        eintraege = []
        try:
            namen = sorted(os.listdir(ordner), key=str.lower)
        except OSError as fehler:
            raise DateiFehler("Nicht lesbar: %s" % fehler.strerror)
        for name in namen[:MAX_EINTRAEGE]:
            voll = os.path.join(ordner, name)
            ist_ordner = os.path.isdir(voll)
            try:
                zeit = int(os.path.getmtime(voll))
            except OSError:
                zeit = 0
            eintraege.append({"name": name, "ordner": ist_ordner, "groesse": 0 if ist_ordner else _groesse(voll), "zeit": zeit,
                              "art": "ordner" if ist_ordner else art_von(name), "unfertig": name.endswith((".part", ".ytdl", ".!qB", ".tmp"))})
        eintraege.sort(key=lambda e: (not e["ordner"], e["name"].lower()))
        rel = os.path.relpath(ordner, os.path.realpath(self._ort(oid)["pfad"]))
        return {"ort": oid, "pfad": "" if rel == "." else rel.replace(os.sep, "/"), "eintraege": eintraege, "mehr": len(namen) > MAX_EINTRAEGE}

    def datei(self, oid, rel):
        p = self.pfad(oid, rel)
        if not os.path.isfile(p):
            raise DateiFehler("Keine Datei")
        return p

    @staticmethod
    def _name(name):
        name = str(name or "").strip()
        if not name or name in (".", "..") or "/" in name or "\\" in name or "\x00" in name or len(name) > 255:
            raise DateiFehler("Ungültiger Name")
        return name

    def umbenennen(self, oid, rel, neu):
        alt = self.pfad(oid, rel)
        if alt == os.path.realpath(self._ort(oid)["pfad"]):
            raise DateiFehler("Den Ort selbst nicht umbenennen")
        ziel = os.path.join(os.path.dirname(alt), self._name(neu))
        if os.path.exists(ziel):
            raise DateiFehler("Den Namen gibt es schon")
        os.rename(alt, ziel)

    def verschieben(self, oid, rel, ziel_ort, ziel_rel):
        quelle = self.pfad(oid, rel)
        if quelle == os.path.realpath(self._ort(oid)["pfad"]):
            raise DateiFehler("Den Ort selbst nicht verschieben")
        ordner = self.pfad(ziel_ort, ziel_rel)
        if not os.path.isdir(ordner):
            raise DateiFehler("Ziel ist kein Ordner")
        ziel = os.path.join(ordner, os.path.basename(quelle))
        if os.path.exists(ziel):
            raise DateiFehler("Am Ziel gibt es „%s“ schon" % os.path.basename(quelle))
        if (ordner + os.sep).startswith(quelle + os.sep):
            raise DateiFehler("Einen Ordner nicht in sich selbst verschieben")
        shutil.move(quelle, ziel)

    def loeschen(self, oid, rel):
        p = self.pfad(oid, rel)
        if p == os.path.realpath(self._ort(oid)["pfad"]):
            raise DateiFehler("Den Ort selbst nicht löschen")
        if os.path.isdir(p) and not os.path.islink(p):
            shutil.rmtree(p)
        else:
            os.remove(p)

    def ordner_neu(self, oid, rel, name):
        p = os.path.join(self.pfad(oid, rel), self._name(name))
        if os.path.exists(p):
            raise DateiFehler("Den Namen gibt es schon")
        os.makedirs(p)

    def ablage_pruefen(self, pfad):
        pfad = str(pfad or "").strip()
        if not pfad:
            return ""
        if not os.path.isabs(pfad):
            raise DateiFehler("Ablage braucht einen vollständigen Pfad")
        try:
            os.makedirs(pfad, exist_ok=True)
        except OSError as fehler:
            raise DateiFehler("Ablage nicht anlegbar: %s" % fehler.strerror)
        if not _schreibbar(pfad):
            raise DateiFehler("In %s darf H0rSt nicht schreiben" % pfad)
        return os.path.realpath(pfad)


def aendern(daten, wunsch, dateien_obj):
    """{ablage: pfad} | {ort_dazu: {name, pfad}} | {ort_weg: pfad} in den Nutzerdaten."""
    e = pruefe(daten.get(SCHLUESSEL))
    if "ablage" in wunsch:
        e["ablage"] = dateien_obj.ablage_pruefen(wunsch["ablage"])
    if isinstance(wunsch.get("ort_dazu"), dict):
        pfad = str(wunsch["ort_dazu"].get("pfad") or "").strip()
        if not os.path.isabs(pfad) or not os.path.isdir(pfad):
            raise DateiFehler("Ort muss ein vorhandener Ordner sein (vollständiger Pfad)")
        if len(e["orte"]) >= MAX_ORTE:
            raise DateiFehler("Höchstens %d eigene Orte" % MAX_ORTE)
        e["orte"] = [o for o in e["orte"] if o["pfad"] != pfad] + [{"name": wunsch["ort_dazu"].get("name") or "", "pfad": pfad}]
    if "ort_weg" in wunsch:
        e["orte"] = [o for o in e["orte"] if o["pfad"] != wunsch["ort_weg"]]
    daten[SCHLUESSEL] = pruefe(e)
    return daten[SCHLUESSEL]


def anwenden(app, einstellung):
    """Einstellung uebernehmen; mit Ablage laden XDCC und YouTube nach <Ablage>/xdcc bzw. <Ablage>/youtube."""
    e = pruefe(einstellung)
    app.dateien.einstellung = e
    standard = getattr(app, "_standard_ablagen", None)
    if standard is None:
        standard = app._standard_ablagen = {"xdcc": app.xdcc.ordner, "youtube": app.youtube_speichern.ordner}
    for teil, ziel in (("xdcc", app.xdcc), ("youtube", app.youtube_speichern)):
        pfad = standard[teil]
        if e["ablage"] and _schreibbar(e["ablage"]):
            pfad = os.path.join(e["ablage"], teil)
            try:
                os.makedirs(pfad, exist_ok=True)
            except OSError:
                pfad = standard[teil]
        ziel.ordner = pfad
        if getattr(app, "ftp_server", None) is not None:
            app.ftp_server.ordner[teil] = pfad
    return e
