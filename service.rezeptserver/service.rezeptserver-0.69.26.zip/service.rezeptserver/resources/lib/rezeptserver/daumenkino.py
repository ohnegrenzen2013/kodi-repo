"""Daumenkino – m0dul: kleine Bildfolgen aus Videos, Fotos, Kamera oder Zeichnungen, zum Blaettern, als GIF/WebM
oder als Druckbogen zum Ausschneiden.

Die Oberflaeche macht die Bilder (Canvas) und schickt fertige Projekte: {id, name, fps, bilder: [{bild, text}]},
bild als data:-URL (JPEG/PNG/WebP). H0rSt legt sie im Datenordner unter daumenkino/<id>.json ab – damit stehen sie auf
allen Geraeten bereit. Jedes Projekt laesst sich als Datei (.h0rstkino) sichern und wieder einlesen (die Oberflaeche
schickt die Datei dann einfach als neues Projekt).

  GET  /api/daumenkino                 Liste {projekte: [{id, name, fps, anzahl, zeit, vorschau}]}
  GET  /api/daumenkino/projekt?id=…    ein Projekt
  POST /api/daumenkino                 {aktion: speichern, projekt} -> {id} | {aktion: loeschen, id}
"""

import json
import os
import re
import secrets
import threading
import time

ORDNER = "daumenkino"
MAX_BILDER = 150
MAX_BILD = 600 * 1024        # je Bild (data:-URL)
MAX_PROJEKT = 16 * 1024 * 1024
MAX_PROJEKTE = 60
_BILD = re.compile(r"^data:image/(jpeg|png|webp);base64,[A-Za-z0-9+/=]+$")


class DaumenkinoFehler(ValueError):
    pass


class Daumenkino:
    def __init__(self, datenordner, uhr=time.time):
        self.ordner = os.path.join(datenordner or ".", ORDNER)
        self.uhr = uhr
        self._sperre = threading.Lock()

    def _pfad(self, pid):
        if not re.match(r"^[a-z0-9]{6,20}$", str(pid or "")):
            raise DaumenkinoFehler("Unbekanntes Projekt")
        return os.path.join(self.ordner, pid + ".json")

    def _lesen(self, pid):
        try:
            with open(self._pfad(pid), encoding="utf-8") as f:
                return json.load(f)
        except (OSError, ValueError):
            raise DaumenkinoFehler("Projekt nicht gefunden")

    def liste(self):
        projekte = []
        try:
            namen = sorted(n for n in os.listdir(self.ordner) if n.endswith(".json"))
        except OSError:
            namen = []
        for n in namen:
            try:
                p = self._lesen(n[:-5])
            except DaumenkinoFehler:
                continue
            bilder = p.get("bilder") or []
            projekte.append({"id": p.get("id"), "name": p.get("name"), "fps": p.get("fps"), "anzahl": len(bilder),
                             "zeit": p.get("zeit", 0), "vorschau": bilder[0]["bild"] if bilder else ""})
        projekte.sort(key=lambda p: -p["zeit"])
        return {"projekte": projekte}

    def projekt(self, pid):
        return self._lesen(pid)

    def speichern(self, roh):
        if not isinstance(roh, dict):
            raise DaumenkinoFehler("Projekt fehlt")
        bilder = []
        for b in (roh.get("bilder") or [])[:MAX_BILDER]:
            bild = str((b or {}).get("bild") or "")
            if len(bild) > MAX_BILD or not _BILD.match(bild):
                raise DaumenkinoFehler("Bild %d ist kaputt oder zu groß (höchstens %d KB)" % (len(bilder) + 1, MAX_BILD // 1024))
            bilder.append({"bild": bild, "text": " ".join(str(b.get("text") or "").split())[:120]})
        if not bilder:
            raise DaumenkinoFehler("Ein Daumenkino braucht mindestens ein Bild")
        if sum(len(b["bild"]) for b in bilder) > MAX_PROJEKT:
            raise DaumenkinoFehler("Zu groß – weniger oder kleinere Bilder")
        try:
            fps = max(1, min(30, int(roh.get("fps") or 8)))
        except (TypeError, ValueError):
            fps = 8
        pid = str(roh.get("id") or "")
        with self._sperre:
            os.makedirs(self.ordner, exist_ok=True)
            if not pid or not os.path.isfile(self._pfad(pid)):
                if len([n for n in os.listdir(self.ordner) if n.endswith(".json")]) >= MAX_PROJEKTE:
                    raise DaumenkinoFehler("Höchstens %d Daumenkinos – erst eins löschen" % MAX_PROJEKTE)
                pid = secrets.token_hex(5)
            projekt = {"id": pid, "name": " ".join(str(roh.get("name") or "").split())[:60] or "Daumenkino",
                       "fps": fps, "zeit": int(self.uhr()), "bilder": bilder}
            pfad = self._pfad(pid)
            with open(pfad + ".neu", "w", encoding="utf-8") as f:
                json.dump(projekt, f)
            os.replace(pfad + ".neu", pfad)
        return {"id": pid, "anzahl": len(bilder)}

    def loeschen(self, pid):
        try:
            os.remove(self._pfad(pid))
        except OSError:
            pass
        return self.liste()
