"""Hoster-Links ueber Debrid-Dienste freischalten (Real-Debrid, AllDebrid, Premiumize, TorBox, Debrid-Link).

Ein Hoster-Link (z. B. rapidgator.net/file/..., 1fichier.com/?...) wird mit dem eigenen Debrid-Konto in einen
direkten Download-/Stream-Link umgewandelt. Genutzt werden alle eigenen Anbieter vom Typ debrid mit
API-Schluessel, in der Reihenfolge ihrer ID; scheitert einer, kommt der naechste.

Welche Links Hoster-Links sind, sagen die Hoster-Listen der Dienste (zwoelf Stunden zwischengespeichert,
im Hintergrund geladen), bis dahin eine mitgelieferte Liste bekannter Hoster.

Torrents (Magnet-Link oder infoHash) schalten die Dienste genauso frei: Magnet hinzufuegen, bei Staffelpaketen
die passende Folge waehlen (sonst die groesste Videodatei), warten, bis der Dienst die Datei hat (bei Torrents im
Cache des Dienstes sofort), direkten Link holen. Dann laeuft ein Torrent in jedem Player, ohne P2P auf dem Geraet.

Streams mit Hoster-Links bekommen eine Adresse dieses Servers (/debrid/<link>.<signatur>), die erst beim
Abspielen freischaltet und auf den direkten Link weiterleitet. Die Signatur verhindert, dass der Server
fremde Links freischaltet.
"""

from .debrid_grund import *
from .debrid_hoster import *
from .debrid_torrent import *
from .debrid_kern import *
from .debrid_grund import _BTIH, _HASH40, _grund, _json, _passt, _warten_bis
from .debrid_hoster import _ad_freischalten, _ad_hoster, _dl_freischalten, _dl_hoster, _pm_freischalten, _pm_hoster, _rd_freischalten, _rd_hoster, _tb_freischalten, _tb_hoster
from .debrid_torrent import _ad_dateien, _ad_torrent, _dl_torrent, _pm_torrent, _rd_torrent, _tb_torrent
