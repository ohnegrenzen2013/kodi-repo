"""Debrid-Cloud-Bibliothek: zeigt, was im Debrid-Konto schon liegt (Torrents, Usenet, Web-Downloads), ohne
erneut zu suchen oder etwas neu hinzuzufuegen - Vorbild NuvioMobiles TorboxCloudLibraryProviderApi.kt.

Bisher nur TorBox: Real-Debrid/AllDebrid/Premiumize/Debrid-Link haben in H0rSt kein geprueftes Gegenstueck
zu TorBoxs drei symmetrischen "mylist"-Endpunkten (/torrents/mylist, /usenet/mylist, /webdl/mylist) - ein
zweiter Dienst waere erfunden statt belegt.
"""

from .debrid_grund import DebridFehler, _grund, _json, urlencode

DIENST = "torbox"
# H0rSt-Name der Art -> (TorBox-URL-Teil, Feldname fuer requestdl)
ARTEN = {"torrents": ("torrents", "torrent_id"), "usenet": ("usenet", "usenet_id"), "web": ("webdl", "web_id")}


def liste(schluessel, art, holen):
    """Alle Eintraege einer Art im TorBox-Konto, neueste zuerst."""
    pfad, _ = ARTEN.get(art) or (None, None)
    if not pfad:
        raise ValueError("unbekannte Art: %s" % art)
    status, text = holen("https://api.torbox.app/v1/api/%s/mylist?bypass_cache=true" % pfad, "GET",
                         {"Authorization": "Bearer " + schluessel})
    d = _json(status, text, "TorBox")
    if not isinstance(d, dict) or not d.get("success"):
        raise DebridFehler("TorBox: %s" % _grund(d, status, "detail", "error"))
    eintraege = d.get("data")
    if isinstance(eintraege, dict):
        eintraege = [eintraege]
    ergebnis = []
    for e in eintraege or []:
        if not isinstance(e, dict) or e.get("id") is None:
            continue
        dateien = [{"id": f.get("id"), "name": str(f.get("short_name") or f.get("name") or "").rsplit("/", 1)[-1],
                    "groesse": f.get("size")}
                   for f in e.get("files") or [] if isinstance(f, dict) and f.get("id") is not None]
        ergebnis.append({
            "id": e.get("id"), "name": str(e.get("name") or ""),
            "fertig": bool(e.get("download_finished") or e.get("download_present") or e.get("cached")),
            "status": str(e.get("download_state") or ""), "groesse": e.get("size"),
            "erstellt": str(e.get("created_at") or ""), "dateien": dateien,
        })
    ergebnis.sort(key=lambda e: e["erstellt"], reverse=True)
    return ergebnis


def aufloesen(schluessel, art, eintrag_id, datei_id, holen):
    """Direkte Download-Adresse fuer eine bereits fertige Datei (kein erneutes Hinzufuegen/Warten wie beim
    gewoehnlichen Freischalten eines neuen Links/Torrents)."""
    pfad, feld = ARTEN.get(art) or (None, None)
    if not pfad:
        raise ValueError("unbekannte Art: %s" % art)
    status, text = holen("https://api.torbox.app/v1/api/%s/requestdl?" % pfad + urlencode(
        {"token": schluessel, feld: eintrag_id, "file_id": datei_id, "zip_link": "false"}), "GET")
    d = _json(status, text, "TorBox")
    if not isinstance(d, dict) or not d.get("success") or not isinstance(d.get("data"), str) or not d["data"]:
        raise DebridFehler("TorBox: %s" % _grund(d, status, "detail", "error"))
    return d["data"]
