"""Debrid-Cloud-Bibliothek: Torrents, Usenet- und Web-Downloads aus TorBox und Premiumize auflisten und abspielen.

Vorbild ist Nuvios Cloud-Bibliothek (NuvioTV, GPL-3.0); der Code hier ist eigen geschrieben. Die Dateien bleiben beim
Debrid-Dienst, H0rSt holt nur die Liste und beim Abspielen einen frischen Direktlink.
"""

from urllib.parse import urlencode

from .debrid_grund import DebridFehler, VIDEO_ENDUNGEN, _grund, _json
from .netz import NetzFehler

TORBOX = "https://api.torbox.app/v1/api"
PREMIUMIZE = "https://www.premiumize.me/api"
MAX_EINTRAEGE = 300
MAX_DATEIEN = 100
ARTEN = {"torrent": "torrents", "usenet": "usenet", "web": "webdl", "datei": "file"}
VIDEO_MIME = ("video/",)


def _name(wert):
    return str(wert or "").replace("\\", "/").rsplit("/", 1)[-1]


def _video_datei(name, mime=""):
    return str(name or "").lower().endswith(VIDEO_ENDUNGEN) or str(mime or "").lower().startswith(VIDEO_MIME)


def _fortschritt(wert):
    """0..1, egal ob der Dienst 0..1 oder Prozent liefert."""
    try:
        z = float(wert or 0)
    except (TypeError, ValueError):
        return 0.0
    return max(0.0, min(1.0, z / 100.0 if z > 1 else z))


def _torbox(schluessel, art, holen):
    pfad = ARTEN.get(art)
    if not pfad:
        raise DebridFehler("Unbekannte Cloud-Art: %s" % art)
    status, text = holen("%s/%s/mylist" % (TORBOX, pfad), "GET", {"Authorization": "Bearer " + schluessel})
    d = _json(status, text, "TorBox")
    if status >= 400 or not isinstance(d, dict) or not d.get("success"):
        raise DebridFehler("TorBox: %s" % _grund(d, status, "detail", "error"))
    eintraege = []
    for roh in (d.get("data") or [])[:MAX_EINTRAEGE]:
        if not isinstance(roh, dict):
            continue
        kennung = str(roh.get("id") if roh.get("id") is not None else roh.get("hash") or "")
        if not kennung:
            continue
        dateien = []
        for f in (roh.get("files") or [])[:MAX_DATEIEN]:
            if not isinstance(f, dict):
                continue
            name = _name(f.get("short_name") or f.get("name") or f.get("absolute_path"))
            if not name:
                continue
            mime = str(f.get("mimetype") or f.get("mime_type") or "")
            fid = str(f.get("id") if f.get("id") is not None else "")
            dateien.append({"id": fid, "name": name, "groesse": int(f.get("size") or 0),
                            "mime": mime, "abspielbar": bool(fid) and _video_datei(name, mime)})
        eintraege.append({"anbieter": "", "dienst": "TorBox", "art": art, "id": kennung,
                          "name": str(roh.get("name") or kennung), "status": str(roh.get("download_state") or roh.get("status") or ""),
                          "groesse": int(roh.get("size") or roh.get("total_size") or 0),
                          "fortschritt": 1.0 if roh.get("download_finished") or roh.get("download_present") else _fortschritt(roh.get("progress")),
                          "dateien": dateien})
    return eintraege


def _premiumize(schluessel, holen):
    status, text = holen(PREMIUMIZE + "/item/listall", "GET", {"Authorization": "Bearer " + schluessel})
    d = _json(status, text, "Premiumize")
    if status >= 400 or not isinstance(d, dict) or str(d.get("status") or "").lower() == "error":
        raise DebridFehler("Premiumize: %s" % _grund(d, status, "message", "code"))
    gruppen = {}
    for f in (d.get("files") or [])[:MAX_DATEIEN * 4]:
        if not isinstance(f, dict):
            continue
        pfad = str(f.get("path") or "").strip().strip("/")
        name = _name(f.get("name") or pfad)
        if not name:
            continue
        mime = str(f.get("mime_type") or "")
        fid = str(f.get("id") or "")
        teile = [t for t in pfad.split("/") if t]
        top = teile[0] if len(teile) > 1 else name
        kennung = ("folder:" + top) if len(teile) > 1 else ("file:" + (fid or name))
        gruppe = gruppen.setdefault(kennung, {"anbieter": "", "dienst": "Premiumize", "art": "datei", "id": kennung,
                                              "name": top, "status": "Bereit", "groesse": 0, "fortschritt": 1.0,
                                              "dateien": []})
        gruppe["groesse"] += int(f.get("size") or 0)
        gruppe["dateien"].append({"id": fid, "name": name, "groesse": int(f.get("size") or 0), "mime": mime,
                                  "link": str(f.get("link") or ""), "abspielbar": bool(fid) and _video_datei(name, mime)})
    return list(gruppen.values())[:MAX_EINTRAEGE]


def liste(konten, holen, nur=None):
    """Cloud-Bibliotheken aller passenden Konten: {anbieter, eintraege, fehler}."""
    anbieter, eintraege, fehler = [], [], {}
    for anbieter_id, name, dienst, schluessel in konten:
        if nur and anbieter_id != nur:
            continue
        if dienst not in ("torbox", "premiumize"):
            continue
        anbieter.append({"id": anbieter_id, "name": name, "dienst": dienst})
        try:
            if dienst == "torbox":
                neu = _torbox(schluessel, "torrent", holen) + _torbox(schluessel, "usenet", holen) + \
                    _torbox(schluessel, "web", holen)
            else:
                neu = _premiumize(schluessel, holen)
        except (DebridFehler, NetzFehler, ValueError, KeyError, AttributeError) as f:
            fehler[anbieter_id] = str(f)
            continue
        for e in neu:
            e["anbieter"] = anbieter_id
            e["dienst"] = name
        eintraege.extend(neu)
    eintraege.sort(key=lambda e: str(e.get("name") or "").lower())
    return {"anbieter": anbieter, "eintraege": eintraege[:MAX_EINTRAEGE], "fehler": fehler}


def link(konten, holen, anbieter_id, art, item_id, datei_id=""):
    """Frischen Direktlink fuer eine Cloud-Datei holen: {url, dateiname, groesse}."""
    konto = next((k for k in konten if k[0] == anbieter_id), None)
    if not konto:
        raise DebridFehler("Debrid-Konto nicht gefunden")
    _, name, dienst, schluessel = konto
    item_id, datei_id = str(item_id or ""), str(datei_id or "")
    if not item_id:
        raise DebridFehler("Cloud-Eintrag fehlt")
    if dienst == "torbox":
        pfad = ARTEN.get(art)
        if not pfad or art == "datei":
            raise DebridFehler("TorBox-Cloud-Art unbekannt")
        werte = {"token": schluessel, "file_id": datei_id, "zip_link": "false"}
        werte[{"torrent": "torrent_id", "usenet": "usenet_id", "web": "web_id"}[art]] = item_id
        status, text = holen("%s/%s/requestdl?%s" % (TORBOX, pfad, urlencode(werte)), "GET",
                             {"Authorization": "Bearer " + schluessel})
        d = _json(status, text, "TorBox")
        if status >= 400 or not isinstance(d, dict) or not d.get("success") or not isinstance(d.get("data"), str):
            raise DebridFehler("TorBox: %s" % _grund(d, status, "detail", "error"))
        return {"url": d["data"], "dateiname": _name(d.get("file_name") or ""), "groesse": 0, "dienst": name}
    if dienst == "premiumize":
        fid = datei_id or (item_id[5:] if item_id.startswith("file:") else "")
        if not fid:
            raise DebridFehler("Premiumize-Datei fehlt")
        status, text = holen(PREMIUMIZE + "/item/details?" + urlencode({"id": fid}), "GET",
                             {"Authorization": "Bearer " + schluessel})
        d = _json(status, text, "Premiumize")
        if status >= 400 or not isinstance(d, dict) or str(d.get("status") or "").lower() == "error" or not d.get("link"):
            raise DebridFehler("Premiumize: %s" % _grund(d, status, "message", "code"))
        return {"url": str(d["link"]), "dateiname": _name(d.get("name") or ""),
                "groesse": int(d.get("size") or 0), "dienst": name}
    raise DebridFehler("Dieser Dienst hat keine Cloud-Bibliothek")
