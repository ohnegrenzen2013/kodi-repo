"""Grundbausteine der Debrid-Dienste: Importe, Konstanten und gemeinsame Helfer.
Alles hier wird samt Importen wieder exportiert (rezeptserver.debrid.*), damit die
Aufteilung nach aussen unsichtbar bleibt."""


import base64
import hashlib
import hmac
import json
import logging
import re
import secrets
import threading
import time
from collections import OrderedDict
from urllib.parse import urlencode, urlsplit

from .netz import NetzFehler, antwort_holen

log = logging.getLogger("rezeptserver")

AGENT = "h0rst"
HOSTER_DAUER = 12 * 3600
LINK_DAUER = 20 * 60
MAX_LINKS = 500
WARTEN = 12.0  # Sekunden fuer Dienste, die erst noch laden (AllDebrid "delayed", TorBox)
WARTEN_TORRENT = 25.0  # Sekunden, bis ein Torrent beim Dienst fertig sein muss (im Cache: sofort)
VIDEO_ENDUNGEN = (".mkv", ".mp4", ".avi", ".m4v", ".ts", ".m2ts", ".mov", ".wmv", ".webm", ".mpg", ".mpeg")
_HASH40 = re.compile(r"(?i)^[0-9a-f]{40}$")
_BTIH = re.compile(r"(?i)xt=urn:btih:([0-9a-z]{32,40})")
NAMEN = {"realdebrid": "Real-Debrid", "alldebrid": "AllDebrid", "premiumize": "Premiumize", "torbox": "TorBox",
         "debridlink": "Debrid-Link"}
# bekannte Hoster, bis die Listen der Dienste geladen sind
BEKANNTE_HOSTER = {
    "1fichier.com", "alterupload.com", "cjoint.net", "desfichiers.com", "dfichiers.com", "megadl.fr", "mesfichiers.org",
    "piecejointe.net", "pjointe.com", "tenvoi.com", "dl4free.com", "rapidgator.net", "rg.to", "ddownload.com",
    "ddl.to", "nitroflare.com", "nitro.download", "turbobit.net", "katfile.com", "filefactory.com", "uploaded.net",
    "ul.to", "mega.nz", "mega.co.nz", "mediafire.com", "uptobox.com", "hitfile.net", "fikper.com", "filestore.me",
    "clicknupload.org", "clicknupload.click", "usersdrive.com", "alfafile.net", "fireget.com", "wupfile.com",
    "hexload.com", "filespace.com", "uploadgig.com", "drop.download", "mexa.sh", "worldbytez.com", "kshared.com",
    "darkibox.com", "filedot.to", "isra.cloud", "elitefile.net", "file.al", "dailyuploads.net", "uploadrar.com",
    "voe.sx", "streamtape.com", "doodstream.com", "dood.watch", "mixdrop.co", "filemoon.sx", "vidoza.net",
    "upstream.to", "streamwish.com", "vidguard.to",
}


class DebridFehler(Exception):
    pass


# Debrid-APIs melden Fehler im JSON der Fehlerantwort
debrid_holen = antwort_holen


def _json(status, text, dienst):
    try:
        return json.loads(text)
    except ValueError:
        raise DebridFehler("%s: unerwartete Antwort (HTTP %d)" % (dienst, status))


def _grund(d, status, *felder):
    """Fehlergrund aus der Antwort eines Dienstes, sonst der HTTP-Status."""
    if isinstance(d, dict):
        for feld in felder:
            wert = d.get(feld)
            if isinstance(wert, dict):
                wert = wert.get("message") or wert.get("code")
            if wert:
                return str(wert)[:200]
    return "HTTP %d" % status


def host_von(url):
    host = (urlsplit(str(url or "")).hostname or "").lower()
    return host[4:] if host.startswith("www.") else host


def _passt(host, domains):
    teile = host.split(".")
    return any(".".join(teile[i:]) in domains for i in range(len(teile) - 1))


# --- Torrents ---------------------------------------------------------------------------------
# torrent(schluessel, magnet, staffel, folge, holen, warten) -> {"url", "dateiname", "groesse"}

def ist_torrent(link):
    link = str(link or "").strip()
    return link.lower().startswith("magnet:") or bool(_HASH40.match(link))


def magnet_von(link):
    """infoHash oder Magnet-Link -> (magnet, hash in Kleinbuchstaben)."""
    link = str(link or "").strip()
    if _HASH40.match(link):
        return "magnet:?xt=urn:btih:" + link.lower(), link.lower()
    treffer = _BTIH.search(link)
    if not link.lower().startswith("magnet:") or not treffer:
        raise DebridFehler("Kein gültiger Magnet-Link")
    kennung = treffer.group(1)
    if len(kennung) == 32:  # Base32 -> hex
        kennung = base64.b32decode(kennung.upper()).hex()
    return link, kennung.lower()


def datei_waehlen(dateien, staffel=None, folge=None):
    """[(kennung, pfad, groesse)] -> die passende Videodatei: bei Staffel/Folge die passende Folge,
    sonst die groesste (ohne Samples)."""
    videos = [d for d in dateien if str(d[1]).lower().endswith(VIDEO_ENDUNGEN)
              and "sample" not in str(d[1]).lower().rsplit("/", 1)[-1]] or list(dateien)
    if not videos:
        raise DebridFehler("Der Torrent enthält keine Dateien")
    if staffel is not None and folge is not None:
        s, f = int(staffel), int(folge)
        muster = re.compile(r"(?i)(?:s0*%d[ ._-]*e0*%d(?!\d)|(?<!\d)%dx0*%d(?!\d)|(?:folge|episode|ep)[ ._-]*0*%d(?!\d))"
                            % (s, f, s, f, f))
        passend = [d for d in videos if muster.search(str(d[1]).rsplit("/", 1)[-1])]
        if passend:
            return max(passend, key=lambda d: int(d[2] or 0))
        if len(videos) > 1:
            raise DebridFehler("Folge S%02dE%02d nicht im Torrent gefunden" % (s, f))
    return max(videos, key=lambda d: int(d[2] or 0))


def _warten_bis(ende, schritt=2.0):
    if time.time() >= ende:
        return False
    time.sleep(min(schritt, max(0.0, ende - time.time())))
    return True
