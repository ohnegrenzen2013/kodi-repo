"""Hoster freischalten je Dienst: Real-Debrid, AllDebrid, Premiumize, TorBox und Debrid-Link."""

from .debrid_grund import (
    AGENT,
    DebridFehler,
    WARTEN,
    _grund,
    _json,
    host_von,
    json,
    time,
    urlencode,
)

def _rd_freischalten(schluessel, link, holen):
    status, text = holen("https://api.real-debrid.com/rest/1.0/unrestrict/link", "POST",
                         {"Authorization": "Bearer " + schluessel,
                          "Content-Type": "application/x-www-form-urlencoded"}, urlencode({"link": link}))
    d = _json(status, text, "Real-Debrid")
    if status >= 400 or not isinstance(d, dict) or not d.get("download"):
        raise DebridFehler("Real-Debrid: %s" % _grund(d, status, "error"))
    return {"url": d["download"], "dateiname": d.get("filename") or "", "groesse": d.get("filesize")}


def _rd_hoster(schluessel, holen):
    status, text = holen("https://api.real-debrid.com/rest/1.0/hosts/domains", "GET",
                         {"Authorization": "Bearer " + schluessel})
    d = _json(status, text, "Real-Debrid")
    return [x for x in d if isinstance(x, str)] if isinstance(d, list) else []


def _ad_freischalten(schluessel, link, holen):
    kopf = {"Authorization": "Bearer " + schluessel}
    status, text = holen("https://api.alldebrid.com/v4/link/unlock?" + urlencode(
        {"agent": AGENT, "apikey": schluessel, "link": link}), "GET", kopf)
    d = _json(status, text, "AllDebrid")
    if not isinstance(d, dict) or d.get("status") != "success":
        raise DebridFehler("AllDebrid: %s" % _grund(d, status, "error"))
    daten = d.get("data") or {}
    url = daten.get("link") or ""
    if not url and daten.get("delayed"):
        # manche Hoster bereitet AllDebrid erst vor: kurz nachfragen
        ende = time.time() + WARTEN
        while time.time() < ende and not url:
            time.sleep(1.5)
            status, text = holen("https://api.alldebrid.com/v4/link/delayed?" + urlencode(
                {"agent": AGENT, "apikey": schluessel, "id": daten["delayed"]}), "GET", kopf)
            warte = (_json(status, text, "AllDebrid").get("data") or {})
            if warte.get("status") == 3:
                raise DebridFehler("AllDebrid: Link konnte nicht vorbereitet werden")
            url = warte.get("link") or ""
        if not url:
            raise DebridFehler("AllDebrid bereitet den Link noch vor, gleich noch einmal versuchen")
    if not url:
        raise DebridFehler("AllDebrid: kein Link in der Antwort")
    return {"url": url, "dateiname": daten.get("filename") or "", "groesse": daten.get("filesize")}


def _ad_hoster(schluessel, holen):
    status, text = holen("https://api.alldebrid.com/v4/hosts/domains?" + urlencode({"agent": AGENT}), "GET",
                         {"Authorization": "Bearer " + schluessel})
    daten = (_json(status, text, "AllDebrid").get("data") or {})
    return [x for teil in ("hosts", "streams", "redirectors") for x in daten.get(teil) or [] if isinstance(x, str)]


def _pm_freischalten(schluessel, link, holen):
    status, text = holen("https://www.premiumize.me/api/transfer/directdl?" + urlencode({"apikey": schluessel}),
                         "POST", {"Content-Type": "application/x-www-form-urlencoded"}, urlencode({"src": link}))
    d = _json(status, text, "Premiumize")
    if not isinstance(d, dict) or d.get("status") != "success":
        raise DebridFehler("Premiumize: %s" % _grund(d, status, "message"))
    dateien = [f for f in d.get("content") or [] if isinstance(f, dict) and f.get("link")]
    if not dateien:
        raise DebridFehler("Premiumize: keine Datei in der Antwort")
    groesste = max(dateien, key=lambda f: int(f.get("size") or 0))
    return {"url": groesste["link"], "dateiname": str(groesste.get("path") or "").split("/")[-1],
            "groesse": groesste.get("size")}


def _pm_hoster(schluessel, holen):
    status, text = holen("https://www.premiumize.me/api/services/list?" + urlencode({"apikey": schluessel}), "GET")
    d = _json(status, text, "Premiumize")
    return [x for x in d.get("directdl") or [] if isinstance(x, str)] if isinstance(d, dict) else []


def _tb_freischalten(schluessel, link, holen):
    status, text = holen("https://api.torbox.app/v1/api/webdl/createwebdownload", "POST",
                         {"Authorization": "Bearer " + schluessel,
                          "Content-Type": "application/x-www-form-urlencoded"}, urlencode({"link": link}))
    d = _json(status, text, "TorBox")
    if not isinstance(d, dict) or not d.get("success"):
        raise DebridFehler("TorBox: %s" % _grund(d, status, "detail", "error"))
    web_id = (d.get("data") or {}).get("webdownload_id")
    if web_id is None:
        raise DebridFehler("TorBox: keine Download-ID in der Antwort")
    ende = time.time() + WARTEN
    while True:
        status, text = holen("https://api.torbox.app/v1/api/webdl/requestdl?" + urlencode(
            {"token": schluessel, "web_id": web_id, "zip_link": "false"}), "GET")
        d = _json(status, text, "TorBox")
        if isinstance(d, dict) and d.get("success") and isinstance(d.get("data"), str) and d["data"]:
            return {"url": d["data"], "dateiname": "", "groesse": None}
        if time.time() >= ende:
            raise DebridFehler("TorBox lädt die Datei noch (%s), gleich noch einmal versuchen"
                               % _grund(d, status, "detail"))
        time.sleep(2)


def _tb_hoster(schluessel, holen):
    status, text = holen("https://api.torbox.app/v1/api/webdl/hosters", "GET", {"Authorization": "Bearer " + schluessel})
    d = _json(status, text, "TorBox")
    domains = []
    for h in (d.get("data") if isinstance(d, dict) else None) or []:
        if isinstance(h, dict):
            for feld in ("domains", "domain", "url"):
                wert = h.get(feld)
                for x in wert if isinstance(wert, list) else [wert]:
                    if isinstance(x, str) and x:
                        domains.append(host_von(x) if "://" in x else x.lower())
    return domains


def _dl_freischalten(schluessel, link, holen):
    status, text = holen("https://debrid-link.com/api/v2/downloader/add", "POST",
                         {"Authorization": "Bearer " + schluessel, "Content-Type": "application/json"},
                         json.dumps({"url": link}))
    d = _json(status, text, "Debrid-Link")
    wert = d.get("value") if isinstance(d, dict) else None
    if not isinstance(d, dict) or not d.get("success") or not isinstance(wert, dict) or not wert.get("downloadUrl"):
        raise DebridFehler("Debrid-Link: %s" % _grund(d, status, "error"))
    return {"url": wert["downloadUrl"], "dateiname": wert.get("name") or "", "groesse": wert.get("size")}


def _dl_hoster(schluessel, holen):
    kopf = {"Authorization": "Bearer " + schluessel}
    status, text = holen("https://debrid-link.com/api/v2/downloader/domains", "GET", kopf)
    d = _json(status, text, "Debrid-Link")
    domains = [x for x in (d.get("value") if isinstance(d, dict) else None) or [] if isinstance(x, str)]
    if domains:
        return domains
    status, text = holen("https://debrid-link.com/api/v2/downloader/hosts", "GET", kopf)
    d = _json(status, text, "Debrid-Link")
    return [x for h in (d.get("value") if isinstance(d, dict) else None) or [] if isinstance(h, dict)
            for x in h.get("domains") or [] if isinstance(x, str)]


DIENSTE = {"realdebrid": (_rd_freischalten, _rd_hoster), "alldebrid": (_ad_freischalten, _ad_hoster),
           "premiumize": (_pm_freischalten, _pm_hoster), "torbox": (_tb_freischalten, _tb_hoster),
           "debridlink": (_dl_freischalten, _dl_hoster)}
