"""Debrid-Konten sowie das Freischalten mit signierten Adressen (/debrid/<link>.<signatur>)."""

from .debrid_grund import (
    BEKANNTE_HOSTER,
    DebridFehler,
    HOSTER_DAUER,
    LINK_DAUER,
    MAX_LINKS,
    NetzFehler,
    OrderedDict,
    WARTEN_TORRENT,
    _passt,
    base64,
    debrid_holen,
    hashlib,
    hmac,
    host_von,
    ist_torrent,
    log,
    magnet_von,
    secrets,
    threading,
    time,
)
from .debrid_hoster import (
    DIENSTE,
)
from .debrid_torrent import (
    TORRENT,
)

def konten(daten):
    """[(id, name, dienst, api_key)] aller nutzbaren Debrid-Anbieter, nach ID sortiert."""
    werte = daten.get("einstellungen") or {}
    ergebnis = []
    for anbieter_id, e in sorted((daten.get("anbieter") or {}).items()):
        schluessel = str((werte.get(anbieter_id) or {}).get("api_key", "")).strip()
        if e.get("typ") == "debrid" and e.get("vorlage") in DIENSTE and schluessel:
            ergebnis.append((anbieter_id, e["name"], e["vorlage"], schluessel))
    return ergebnis


class Debrid:
    def __init__(self, konten_=(), holen=None):
        self.konten = list(konten_)
        self.holen = holen or debrid_holen
        self.geheimnis = secrets.token_bytes(16)  # signiert /debrid/-Adressen, gilt bis zum Neustart
        self._hoster = {}  # dienst -> (zeit, set)
        self._links = OrderedDict()
        self._sperre = threading.Lock()
        self._laedt = False
        self._geladen = threading.Event()  # gesetzt, sobald kein Laden laeuft
        self._geladen.set()

    @property
    def verfuegbar(self):
        return bool(self.konten)

    def uebernehmen(self, neu):
        """Neue Konten nach geaenderten Anbietern; Geheimnis und geladene Hoster bleiben."""
        neu.geheimnis = self.geheimnis
        neu._hoster = dict(self._hoster)
        return neu

    # --- Hoster erkennen ----------------------------------------------------------------
    def _hoster_laden(self):
        try:
            for _, name, dienst, schluessel in self.konten:
                with self._sperre:
                    alt = self._hoster.get(dienst)
                if alt and time.time() - alt[0] < HOSTER_DAUER:
                    continue
                try:
                    domains = {d.lower().lstrip(".") for d in DIENSTE[dienst][1](schluessel, self.holen) if d}
                except (DebridFehler, NetzFehler, ValueError, AttributeError) as fehler:
                    log.warning("%s: Hoster-Liste nicht ladbar: %s", name, fehler)
                    domains = set()
                with self._sperre:
                    self._hoster[dienst] = (time.time(), domains or (alt[1] if alt else set()))
        finally:
            self._laedt = False
            self._geladen.set()

    def hoster(self, warten=False):
        """Alle bekannten Hoster-Domains (Listen der Dienste plus mitgelieferte)."""
        if not self.konten:
            return set()
        with self._sperre:
            veraltet = any(d not in self._hoster or time.time() - self._hoster[d][0] >= HOSTER_DAUER
                           for _, _, d, _ in self.konten)
            starten = veraltet and not self._laedt
            if starten:
                self._laedt = True
                self._geladen.clear()
        if starten:
            if warten:
                self._hoster_laden()
            else:
                threading.Thread(target=self._hoster_laden, name="debrid-hoster", daemon=True).start()
        elif warten and veraltet:
            self._geladen.wait(60)  # laedt schon im Hintergrund: darauf warten statt die alte Liste zu nehmen
        with self._sperre:
            ergebnis = set(BEKANNTE_HOSTER)
            for _, domains in self._hoster.values():
                ergebnis |= domains
        return ergebnis

    def ist_hoster(self, url, domains=None):
        if not self.konten or not str(url or "").lower().startswith(("http://", "https://")):
            return False
        return _passt(host_von(url), domains if domains is not None else self.hoster())

    # --- Freischalten -------------------------------------------------------------------
    def freischalten(self, link, nur=None, staffel=None, folge=None, warten=WARTEN_TORRENT):
        """Hoster-Link oder Torrent (Magnet/infoHash) -> {"url", "dateiname", "groesse", "dienst"}; probiert die
        Konten der Reihe nach. Bei Torrents waehlen staffel/folge die Datei in Staffelpaketen."""
        link = str(link or "").strip()
        torrent = ist_torrent(link)
        if torrent:
            link, _ = magnet_von(link)
        elif not link.lower().startswith(("http://", "https://")):
            raise DebridFehler("Kein Link (http://, https:// oder magnet:)")
        konten_ = [k for k in self.konten if not nur or k[0] == nur]
        if not konten_:
            raise DebridFehler("Kein Debrid-Dienst mit API-Schlüssel eingetragen (Anbieter → Hoster & Debrid)")
        merken = (link, nur, staffel, folge)
        with self._sperre:
            alt = self._links.get(merken)
            if alt and time.time() - alt[0] < LINK_DAUER:
                return alt[1]
        fehler = []
        for anbieter_id, name, dienst, schluessel in konten_:
            try:
                if torrent:
                    ergebnis = TORRENT[dienst](schluessel, link, staffel, folge, self.holen, warten)
                else:
                    ergebnis = DIENSTE[dienst][0](schluessel, link, self.holen)
            except (DebridFehler, NetzFehler, ValueError, KeyError, AttributeError) as f:
                fehler.append(str(f))
                continue
            ergebnis = dict(ergebnis, dienst=name, anbieter=anbieter_id)
            with self._sperre:
                self._links[merken] = (time.time(), ergebnis)
                while len(self._links) > MAX_LINKS:
                    self._links.popitem(last=False)
            log.info("%s hat %s freigeschaltet", name, "einen Torrent" if torrent else "einen Link von " + host_von(link))
            return ergebnis
        raise DebridFehler("; ".join(fehler))

    # --- signierte Adressen /debrid/<link>.<signatur> -----------------------------------------
    def schluessel(self, link):
        roh = base64.urlsafe_b64encode(link.encode("utf-8")).decode("ascii").rstrip("=")
        signatur = hmac.new(self.geheimnis, roh.encode("ascii"), hashlib.sha256).digest()[:18]
        return roh + "." + base64.urlsafe_b64encode(signatur).decode("ascii")

    # dieselbe Signatur fuer andere Server-Adressen (z. B. /usenet/ fuer rustnzb)
    def verpacken(self, text):
        return self.schluessel(text)

    def auspacken(self, schluessel):
        return self.link_aus(schluessel)

    def link_aus(self, schluessel):
        """Signierten Schluessel pruefen; gibt den Hoster-Link zurueck oder None."""
        roh, _, signatur = str(schluessel).partition(".")
        erwartet = base64.urlsafe_b64encode(
            hmac.new(self.geheimnis, roh.encode("ascii", "ignore"), hashlib.sha256).digest()[:18]).decode("ascii")
        if not roh or not hmac.compare_digest(signatur.encode("ascii", "ignore"), erwartet.encode("ascii")):
            return None
        try:
            return base64.urlsafe_b64decode((roh + "=" * (-len(roh) % 4)).encode("ascii")).decode("utf-8")
        except (ValueError, UnicodeDecodeError):
            return None

    # --- Cloud-Bibliothek ---------------------------------------------------------------
    def cloud_liste(self, nur=None):
        """Torrents, Usenet- und Web-Downloads der Debrid-Konten (TorBox/Premiumize)."""
        from . import debrid_cloud
        return debrid_cloud.liste(self.konten, self.holen, nur)

    def cloud_link(self, anbieter_id, art, item_id, datei_id=""):
        """Frischen Direktlink fuer eine Datei aus der Cloud-Bibliothek holen."""
        from . import debrid_cloud
        return debrid_cloud.link(self.konten, self.holen, anbieter_id, art, item_id, datei_id)
