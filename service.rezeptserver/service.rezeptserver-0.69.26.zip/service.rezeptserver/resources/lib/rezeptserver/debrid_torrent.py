"""Torrents und Magnete je Dienst freischalten und die passende Datei auswaehlen."""

from .debrid_grund import (
    AGENT,
    DebridFehler,
    VIDEO_ENDUNGEN,
    _grund,
    _json,
    _warten_bis,
    datei_waehlen,
    json,
    magnet_von,
    secrets,
    time,
    urlencode,
)
from .debrid_hoster import (
    _ad_freischalten,
    _rd_freischalten,
)

def _rd_torrent(schluessel, magnet, staffel, folge, holen, warten):
    kopf = {"Authorization": "Bearer " + schluessel}
    form = dict(kopf, **{"Content-Type": "application/x-www-form-urlencoded"})
    basis = "https://api.real-debrid.com/rest/1.0"
    _, kennung = magnet_von(magnet)
    # schon im Konto? (z. B. dieselbe Staffel fuer eine andere Folge)
    status, text = holen(basis + "/torrents?limit=100", "GET", kopf)
    liste = _json(status, text, "Real-Debrid") if status == 200 else []
    vorhanden = next((t for t in liste if isinstance(t, dict) and str(t.get("hash", "")).lower() == kennung
                      and t.get("status") not in ("magnet_error", "error", "virus", "dead")), None)
    if vorhanden:
        tid = vorhanden["id"]
    else:
        status, text = holen(basis + "/torrents/addMagnet", "POST", form, urlencode({"magnet": magnet}))
        d = _json(status, text, "Real-Debrid")
        if status >= 400 or not d.get("id"):
            raise DebridFehler("Real-Debrid: %s" % _grund(d, status, "error"))
        tid = d["id"]
    ende = time.time() + warten
    while True:
        status, text = holen(basis + "/torrents/info/" + tid, "GET", kopf)
        info = _json(status, text, "Real-Debrid")
        if status >= 400:
            raise DebridFehler("Real-Debrid: %s" % _grund(info, status, "error"))
        zustand = info.get("status")
        dateien = [(f.get("id"), f.get("path", ""), f.get("bytes", 0)) for f in info.get("files") or []]
        if zustand == "waiting_files_selection":
            # alle Videos auswaehlen: dann laesst sich ein Staffelpaket fuer jede Folge wiederverwenden
            videos = [d for d in dateien if str(d[1]).lower().endswith(VIDEO_ENDUNGEN)] or dateien
            status, text = holen(basis + "/torrents/selectFiles/" + tid, "POST", form,
                                 urlencode({"files": ",".join(str(d[0]) for d in videos)}))
            if status >= 400:
                raise DebridFehler("Real-Debrid: %s" % _grund(_json(status, text, "Real-Debrid"), status, "error"))
            continue
        if zustand == "downloaded":
            gewaehlt = [(f.get("id"), f.get("path", ""), f.get("bytes", 0)) for f in info.get("files") or []
                        if f.get("selected")]
            ziel = datei_waehlen(gewaehlt, staffel, folge)
            links = info.get("links") or []
            stelle = [d[0] for d in gewaehlt].index(ziel[0])  # Links in der Reihenfolge der gewaehlten Dateien
            if stelle >= len(links):
                raise DebridFehler("Real-Debrid: kein Link für %s" % ziel[1])
            ergebnis = _rd_freischalten(schluessel, links[stelle], holen)
            return dict(ergebnis, dateiname=ergebnis["dateiname"] or ziel[1].rsplit("/", 1)[-1])
        if zustand in ("magnet_error", "error", "virus", "dead"):
            raise DebridFehler("Real-Debrid: Torrent fehlerhaft (%s)" % zustand)
        if not _warten_bis(ende):
            raise DebridFehler("Real-Debrid lädt den Torrent noch (%s %%), gleich noch einmal versuchen"
                               % info.get("progress", 0))


def _ad_dateien(baum, pfad=""):
    """AllDebrid-Dateibaum {n, s, l, e} -> [(link, pfad, groesse)]."""
    ergebnis = []
    for knoten in baum or []:
        name = "%s/%s" % (pfad, knoten.get("n", "")) if pfad else knoten.get("n", "")
        if knoten.get("e"):
            ergebnis.extend(_ad_dateien(knoten["e"], name))
        elif knoten.get("l"):
            ergebnis.append((knoten["l"], name, knoten.get("s", 0)))
    return ergebnis


def _ad_torrent(schluessel, magnet, staffel, folge, holen, warten):
    kopf = {"Authorization": "Bearer " + schluessel}
    basis = "https://api.alldebrid.com/v4"
    status, text = holen(basis + "/magnet/upload?" + urlencode({"agent": AGENT, "apikey": schluessel, "magnets[]": magnet}),
                         "GET", kopf)
    d = _json(status, text, "AllDebrid")
    if d.get("status") != "success":
        raise DebridFehler("AllDebrid: %s" % _grund(d, status, "error"))
    eintrag = ((d.get("data") or {}).get("magnets") or [{}])[0]
    if eintrag.get("error"):
        raise DebridFehler("AllDebrid: %s" % _grund(eintrag, status, "error"))
    mid = eintrag.get("id")
    ende = time.time() + warten
    while True:
        # v4.1 ist der Nachfolger des als veraltet markierten v4/magnet/status
        status, text = holen("https://api.alldebrid.com/v4.1/magnet/status?" + urlencode(
            {"agent": AGENT, "apikey": schluessel, "id": mid}), "GET", kopf)
        info = ((_json(status, text, "AllDebrid").get("data") or {}).get("magnets") or {})
        if isinstance(info, list):
            info = info[0] if info else {}
        code = int(info.get("statusCode") or 0)
        if code == 4:  # Ready
            dateien = [(l.get("link"), l.get("filename", ""), l.get("size", 0)) for l in info.get("links") or []
                       if isinstance(l, dict) and l.get("link")]
            if not dateien:  # neuere API: Dateien ueber magnet/files
                status, text = holen(basis + "/magnet/files?" + urlencode({"agent": AGENT, "apikey": schluessel,
                                                                           "id[]": mid}), "GET", kopf)
                magnete = (_json(status, text, "AllDebrid").get("data") or {}).get("magnets") or []
                dateien = _ad_dateien((magnete[0] if magnete else {}).get("files"))
            ziel = datei_waehlen(dateien, staffel, folge)
            ergebnis = _ad_freischalten(schluessel, ziel[0], holen)
            return dict(ergebnis, dateiname=ergebnis["dateiname"] or ziel[1].rsplit("/", 1)[-1])
        if code > 4:
            raise DebridFehler("AllDebrid: %s" % (info.get("status") or "Torrent fehlerhaft"))
        if not _warten_bis(ende):
            raise DebridFehler("AllDebrid lädt den Torrent noch (%s), gleich noch einmal versuchen"
                               % (info.get("status") or "in Arbeit"))


def _pm_torrent(schluessel, magnet, staffel, folge, holen, warten):
    status, text = holen("https://www.premiumize.me/api/transfer/directdl?" + urlencode({"apikey": schluessel}), "POST",
                         {"Content-Type": "application/x-www-form-urlencoded"}, urlencode({"src": magnet}))
    d = _json(status, text, "Premiumize")
    if d.get("status") == "success" and d.get("content"):
        dateien = [(f.get("link"), f.get("path", ""), f.get("size", 0)) for f in d["content"]
                   if isinstance(f, dict) and f.get("link")]
        ziel = datei_waehlen(dateien, staffel, folge)
        return {"url": ziel[0], "dateiname": ziel[1].rsplit("/", 1)[-1], "groesse": ziel[2]}
    # nicht im Cache: als Transfer anlegen, Premiumize laedt ihn
    status, text = holen("https://www.premiumize.me/api/transfer/create?" + urlencode({"apikey": schluessel}), "POST",
                         {"Content-Type": "application/x-www-form-urlencoded"}, urlencode({"src": magnet}))
    neu = _json(status, text, "Premiumize")
    if neu.get("status") != "success":
        raise DebridFehler("Premiumize: %s" % _grund(neu, status, "message"))
    raise DebridFehler("Premiumize hat den Torrent nicht im Cache und lädt ihn jetzt, später noch einmal versuchen")


def _tb_torrent(schluessel, magnet, staffel, folge, holen, warten):
    kopf = {"Authorization": "Bearer " + schluessel}
    basis = "https://api.torbox.app/v1/api/torrents"
    grenze = "h0rst" + secrets.token_hex(8)
    koerper = ('--%s\r\nContent-Disposition: form-data; name="magnet"\r\n\r\n%s\r\n--%s--\r\n'
               % (grenze, magnet, grenze)).encode("utf-8")
    status, text = holen(basis + "/createtorrent", "POST",
                         dict(kopf, **{"Content-Type": "multipart/form-data; boundary=" + grenze}), koerper)
    d = _json(status, text, "TorBox")
    tid = (d.get("data") or {}).get("torrent_id") if isinstance(d.get("data"), dict) else None
    if not d.get("success") or tid is None:
        raise DebridFehler("TorBox: %s" % _grund(d, status, "detail", "error"))
    ende = time.time() + warten
    while True:
        status, text = holen(basis + "/mylist?" + urlencode({"id": tid, "bypass_cache": "true"}), "GET", kopf)
        info = _json(status, text, "TorBox").get("data") or {}
        if isinstance(info, list):
            info = info[0] if info else {}
        if info.get("download_finished") or info.get("download_present"):
            dateien = [(f.get("id"), f.get("name") or f.get("short_name", ""), f.get("size", 0))
                       for f in info.get("files") or []]
            ziel = datei_waehlen(dateien, staffel, folge)
            status, text = holen(basis + "/requestdl?" + urlencode({"token": schluessel, "torrent_id": tid,
                                                                   "file_id": ziel[0], "zip_link": "false"}), "GET")
            r = _json(status, text, "TorBox")
            if not r.get("success") or not isinstance(r.get("data"), str):
                raise DebridFehler("TorBox: %s" % _grund(r, status, "detail", "error"))
            return {"url": r["data"], "dateiname": ziel[1].rsplit("/", 1)[-1], "groesse": ziel[2]}
        if not _warten_bis(ende):
            raise DebridFehler("TorBox lädt den Torrent noch (%s), gleich noch einmal versuchen"
                               % (info.get("download_state") or "in Arbeit"))


def _dl_torrent(schluessel, magnet, staffel, folge, holen, warten):
    kopf = {"Authorization": "Bearer " + schluessel, "Content-Type": "application/json"}
    basis = "https://debrid-link.com/api/v2/seedbox"
    status, text = holen(basis + "/add", "POST", kopf, json.dumps({"url": magnet, "async": True}))
    d = _json(status, text, "Debrid-Link")
    wert = d.get("value") if isinstance(d.get("value"), dict) else None
    if not d.get("success") or not wert:
        raise DebridFehler("Debrid-Link: %s" % _grund(d, status, "error"))
    ende = time.time() + warten
    while True:
        fertig = [(f.get("downloadUrl"), f.get("name", ""), f.get("size", 0)) for f in wert.get("files") or []
                  if f.get("downloadUrl") and int(f.get("downloadPercent") or 0) >= 100]
        if fertig:
            ziel = datei_waehlen(fertig, staffel, folge)
            return {"url": ziel[0], "dateiname": ziel[1].rsplit("/", 1)[-1], "groesse": ziel[2]}
        if not _warten_bis(ende):
            raise DebridFehler("Debrid-Link lädt den Torrent noch (%s %%), gleich noch einmal versuchen"
                               % wert.get("downloadPercent", 0))
        status, text = holen(basis + "/list?" + urlencode({"ids": wert.get("id")}), "GET", kopf)
        liste = _json(status, text, "Debrid-Link").get("value") or []
        wert = liste[0] if liste else wert


TORRENT = {"realdebrid": _rd_torrent, "alldebrid": _ad_torrent, "premiumize": _pm_torrent, "torbox": _tb_torrent,
           "debridlink": _dl_torrent}
