"""Deutsch-Wertung fuer Release-Namen (Vorbild: Usenet-Kompass, MIT-Lizenz, Kapitel 6.4 "Deutsche Sprachprofile").

Der Usenet-Kompass bewertet in Sonarr/Radarr per Custom Formats mit Punkten: German DL +1500, German +1000, German
Forced +200, verlustfreier Ton +100, x264 bei 1080p +50, Kinomitschnitt -10000. Hier derselbe Gedanke fuer H0rSts
eigene Release-Auswahl (Usenet-Streaming, Indexer-Suche, manuelle Suche): ein Release-Name wird gelesen, nicht das
Netz gefragt. Der Code ist eigen geschrieben; uebernommen ist nur das Punkteschema.

Unterschiede zum Kompass, bewusst:
  * Die Punkte werden nicht addiert, wenn ein Release "German" und "DL" traegt: es zaehlt der hoehere Wert (1500),
    nicht 2500. Fuer die Reihenfolge macht das keinen Unterschied.
  * "WEB-DL" zaehlt nicht als "DL" (Dual Language). Der Kompass-Ausdruck hielt "German.1080p.WEB-DL" faelschlich
    fuer ein Dual-Language-Release.
  * "LD"/"MD" (Line/Mic Dubbed) zaehlen nur zusammen mit einer deutschen Kennung als Kinomitschnitt.
"""

import re

PUNKTE = {"German DL": 1500, "German": 1000, "German Forced": 200, "Lossless": 100, "x264": 50, "Minderwertig": -10000}
MODI = {"aus": "Aus (nur die normale Reihenfolge)",
        "bevorzugen": "Deutsch bevorzugen (German DL vor German vor Original), Kinomitschnitte ausschließen",
        "nur": "Nur Deutsch (German und German DL), Kinomitschnitte ausschließen"}
SCHWELLE_DEUTSCH = 1000

_G = r"(?<![a-z0-9])"
_E = r"(?![a-z0-9])"
_DEUTSCH = re.compile(_G + r"(german|deutsch|ger|ger[. _-]?dub(?:bed)?|german[. _-]?dub(?:bed)?)" + _E, re.I)
_DUAL = re.compile(_G + r"(dl|dual|dual[. _-]?audio|multi|multi[. _-]?audio)" + _E, re.I)
_WEBDL = re.compile(r"(?i)web[-. _]?dl")
_FORCED = re.compile(_G + r"((german|ger|deutsch)[. _-]*(forced|subbed|sub)|(forced|sub)[. _-]*(german|ger|deutsch))" + _E, re.I)
_LOSSLESS = re.compile(_G + r"(dts[-. _]?hd(?:[-. _]?ma)?|truehd|atmos|dts[-. _]?x)" + _E, re.I)
_X264 = re.compile(_G + r"(x264|h[. _]?264|avc)" + _E, re.I)
_1080 = re.compile(_G + r"1080[pi]" + _E, re.I)
_HDR = re.compile(_G + r"(hdr10\+?|hdr|dv|dolby[. _]?vision)" + _E, re.I)
_KINO = re.compile(_G + r"(cam|hdcam|camrip|ts|hdts|telesync|telecine|hdtc|tc|line[. _-]?dubbed|mic[. _-]?dubbed)" + _E, re.I)
_KINO_DEUTSCH = re.compile(_G + r"(ld|md)" + _E, re.I)


def wertung(titel):
    """Release-Name -> {"punkte", "sprache" (nur Sprachpunkte), "bonus", "labels", "deutsch", "dual", "minderwertig"}."""
    text = str(titel or "")
    ohne = _WEBDL.sub("WEBDL", text)  # "WEB-DL" ist keine zweite Tonspur
    forced = bool(_FORCED.search(ohne))
    ton = _FORCED.sub(" ", ohne)  # "German Subbed/Forced" sind Untertitel, keine deutsche Tonspur
    deutsch = bool(_DEUTSCH.search(ton))
    dual = deutsch and bool(_DUAL.search(ton))
    kino = bool(_KINO.search(ohne)) or (deutsch and bool(_KINO_DEUTSCH.search(ohne)))
    labels, sprache, bonus = [], 0, 0
    if dual:
        labels.append("German DL")
        sprache = PUNKTE["German DL"]
    elif deutsch:
        labels.append("German")
        sprache = PUNKTE["German"]
    if forced:
        labels.append("German Forced")
        sprache += PUNKTE["German Forced"]
    if _LOSSLESS.search(ohne):
        labels.append("Lossless")
        bonus += PUNKTE["Lossless"]
    if _X264.search(ohne) and _1080.search(ohne) and not _HDR.search(ohne):
        bonus += PUNKTE["x264"]  # nur Sortierhilfe, keine eigene Anzeige
    if kino:
        labels.append("Kinomitschnitt")
    punkte = sprache + bonus + (PUNKTE["Minderwertig"] if kino else 0)
    return {"punkte": punkte, "sprache": sprache, "bonus": bonus, "labels": labels, "deutsch": deutsch, "dual": dual,
            "minderwertig": kino}


def modus_von(wert):
    wert = str(wert or "aus")
    return wert if wert in MODI else "aus"


def zulassen(w, modus):
    """Darf ein Release mit Wertung w im Modus angeboten werden? (aus: alles; sonst kein Kinomitschnitt, bei "nur" deutsch)"""
    if modus == "aus":
        return True
    if w["minderwertig"]:
        return False
    return not (modus == "nur" and not w["deutsch"])
