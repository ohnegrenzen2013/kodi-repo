"""DHT: Quellen eines Torrents im BitTorrent-Mainline-DHT zaehlen (BEP 5), ohne Tracker und ohne Torrent-Client.

Zu einem Magnet-Link bzw. infoHash fragt H0rSt die Knoten des DHT nach Peers (get_peers), naehert sich dabei
schrittweise den Knoten, die fuer den Hash zustaendig sind, und zaehlt die verschiedenen Peers. Geladen wird
nichts; H0rSt meldet sich nicht als Peer an (kein announce_peer). Herunterladen bleibt Sache des Torrent-Clients
(qBittorrent, Transmission, Deluge nutzen das DHT selbst) oder des Debrid-Dienstes.

Das DHT spricht UDP. Proxy, Tor und I2P koennen das nicht weiterreichen, deshalb fragt H0rSt das DHT nur ab,
wenn kein Netzweg gesetzt ist; bei aktiver Notbremse nur mit laufendem VPN (UDP geht dann durch den Tunnel).

KAD (das Kademlia-Netz von eMule) ist ein anderes Netz: das spricht Ember selbst (siehe ed2k.py).
"""

import os
import random
import re
import select
import socket
import time

from . import ipfilter

BOOTSTRAP = [("router.bittorrent.com", 6881), ("dht.transmissionbt.com", 6881), ("router.utorrent.com", 6881),
             ("dht.libtorrent.org", 25401)]
_HASH = re.compile(r"(?:urn:btih:)?([0-9a-fA-F]{40})")
_HASH32 = re.compile(r"urn:btih:([A-Z2-7]{32})", re.I)
GLEICHZEITIG = 8      # Anfragen je Runde
MAX_ANFRAGEN = 400


class DhtFehler(ValueError):
    pass


# --- Bencode (nur was KRPC braucht) ------------------------------------------------------------
def kodieren(wert):
    if isinstance(wert, int):
        return b"i%de" % wert
    if isinstance(wert, str):
        wert = wert.encode("utf-8")
    if isinstance(wert, bytes):
        return b"%d:%s" % (len(wert), wert)
    if isinstance(wert, list):
        return b"l" + b"".join(kodieren(w) for w in wert) + b"e"
    if isinstance(wert, dict):
        paare = {(k.encode("utf-8") if isinstance(k, str) else k): v for k, v in wert.items()}
        return b"d" + b"".join(kodieren(k) + kodieren(paare[k]) for k in sorted(paare)) + b"e"
    raise DhtFehler("nicht kodierbar: %r" % type(wert))


def dekodieren(daten):
    wert, ende = _lesen(daten, 0)
    if ende != len(daten):
        raise DhtFehler("Restdaten nach Bencode")
    return wert


def _lesen(d, i):
    if i >= len(d):
        raise DhtFehler("Bencode zu kurz")
    z = d[i:i + 1]
    if z == b"i":
        ende = d.index(b"e", i)
        return int(d[i + 1:ende]), ende + 1
    if z == b"l":
        i += 1
        liste = []
        while d[i:i + 1] != b"e":
            w, i = _lesen(d, i)
            liste.append(w)
        return liste, i + 1
    if z == b"d":
        i += 1
        wb = {}
        while d[i:i + 1] != b"e":
            k, i = _lesen(d, i)
            w, i = _lesen(d, i)
            wb[k] = w
        return wb, i + 1
    if z.isdigit():
        trenner = d.index(b":", i)
        laenge = int(d[i:trenner])
        anfang = trenner + 1
        if anfang + laenge > len(d):
            raise DhtFehler("Bencode-Zeichenkette zu kurz")
        return d[anfang:anfang + laenge], anfang + laenge
    raise DhtFehler("ungültiges Bencode")


# --- Hilfen -----------------------------------------------------------------------------------
def infohash(text):
    """infoHash (40 Hex-Zeichen, auch Base32 aus Magnet-Links) -> 20 Bytes."""
    text = str(text or "").strip()
    m = _HASH.search(text)
    if m:
        return bytes.fromhex(m.group(1))
    m = _HASH32.search(text)
    if m:
        import base64
        return base64.b32decode(m.group(1).upper())
    raise DhtFehler("Kein infoHash gefunden (Magnet-Link oder 40 Hex-Zeichen)")


def knoten_lesen(roh):
    """Kompakte Knoten (26 Bytes: id, IPv4, Port)."""
    ergebnis = []
    for i in range(0, len(roh) - len(roh) % 26, 26):
        port = int.from_bytes(roh[i + 24:i + 26], "big")
        ip = socket.inet_ntoa(roh[i + 20:i + 24])
        if port and not ip.startswith(("0.", "127.")):
            ergebnis.append((roh[i:i + 20], (ip, port)))
    return ergebnis


def peers_lesen(werte):
    peers = set()
    for p in werte if isinstance(werte, list) else []:
        if isinstance(p, bytes) and len(p) == 6:
            port = int.from_bytes(p[4:6], "big")
            if port:
                peers.add((socket.inet_ntoa(p[:4]), port))
    return peers


def abstand(a, b):
    return int.from_bytes(bytes(x ^ y for x, y in zip(a, b)), "big")


def erlaubt():
    """'' wenn das DHT abgefragt werden darf, sonst der Grund."""
    from . import sicherheit
    weg = sicherheit.NETZWEG
    if weg.weg is not None:
        return "Das DHT spricht UDP und läuft nicht über Proxy, Tor oder I2P. Mit gesetztem Netzweg fragt H0rSt es nicht ab."
    if weg.notbremse and not weg.vpn_laeuft():
        return "Notbremse: kein VPN aktiv, das DHT wird nicht abgefragt."
    return ""


# --- Abfrage ----------------------------------------------------------------------------------
def peers_zaehlen(text, dauer=8.0, bootstrap=None, sock=None, uhr=time.monotonic):
    """Fragt das DHT nach Peers zum infoHash. Gibt {"peers", "knoten", "anfragen", "sekunden", "beispiele"} zurueck."""
    ziel = infohash(text)
    if sock is None:
        grund = erlaubt()
        if grund:
            raise DhtFehler(grund)
    eigen = os.urandom(20)
    s = sock or socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    if sock is None:
        s.bind(("0.0.0.0", 0))
    s.setblocking(False)
    offen, gefragt, peers, antworten, kandidaten, gesperrt = {}, set(), set(), set(), {}, set()
    nummer = random.randint(0, 0xFFFF)
    start = uhr()

    def fragen(adresse):
        nonlocal nummer
        nummer = (nummer + 1) & 0xFFFF
        tid = nummer.to_bytes(2, "big")
        nachricht = {"t": tid, "y": "q", "q": "get_peers", "a": {"id": eigen, "info_hash": ziel}}
        try:
            s.sendto(kodieren(nachricht), adresse)
            offen[tid] = (adresse, uhr())
            gefragt.add(adresse)
        except OSError:
            gefragt.add(adresse)

    try:
        for host, port in bootstrap or BOOTSTRAP:
            try:
                for info in socket.getaddrinfo(host, port, socket.AF_INET, socket.SOCK_DGRAM):
                    fragen(info[4][:2])
            except OSError:
                continue
        if not offen:
            raise DhtFehler("Kein DHT-Startknoten erreichbar (DNS oder Netz)")
        while uhr() - start < dauer and len(gefragt) < MAX_ANFRAGEN:
            # naechste Runde: die naechstgelegenen noch nicht gefragten Knoten
            frei = GLEICHZEITIG - len(offen)
            if frei > 0 and kandidaten:
                for _kid, adresse in sorted(((k, a) for a, k in kandidaten.items() if a not in gefragt),
                                           key=lambda x: abstand(x[0], ziel))[:frei]:
                    fragen(adresse)
            jetzt = uhr()
            for tid, (_, zeit) in list(offen.items()):
                if jetzt - zeit > 2.0:
                    del offen[tid]
            if not offen and all(a in gefragt for a in kandidaten):
                break
            bereit, _, _ = select.select([s], [], [], 0.25)
            if not bereit:
                continue
            while True:
                try:
                    daten, absender = s.recvfrom(4096)
                except (BlockingIOError, InterruptedError):
                    break
                except OSError:
                    break
                try:
                    antwort = dekodieren(daten)
                except (DhtFehler, ValueError, IndexError):
                    continue
                if not isinstance(antwort, dict) or antwort.get(b"t") not in offen:
                    continue
                del offen[antwort[b"t"]]
                r = antwort.get(b"r")
                if antwort.get(b"y") != b"r" or not isinstance(r, dict):
                    continue
                antworten.add(absender)
                for p in peers_lesen(r.get(b"values")):
                    if ipfilter.gesperrt(p[0]):  # IP-Filter (Sicherheit): gesperrte Peers zaehlen nicht
                        gesperrt.add(p)
                    else:
                        peers.add(p)
                for kid, adresse in knoten_lesen(r.get(b"nodes") or b""):
                    if ipfilter.gesperrt(adresse[0]):
                        gesperrt.add(adresse)
                    else:
                        kandidaten.setdefault(adresse, kid)
    finally:
        if sock is None:
            s.close()
    return {"peers": len(peers), "knoten": len(antworten), "anfragen": len(gefragt),
            "sekunden": round(uhr() - start, 1), "beispiele": ["%s:%d" % p for p in sorted(peers)[:5]],
            "gesperrt": len(gesperrt)}
