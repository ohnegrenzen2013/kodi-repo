"""Server bauen, im Hintergrund laufen lassen und sauber beenden.

Gemeinsam fuer Kommandozeile, Kodi-Dienst und Android-App.
"""

import json
import logging
import os
import re
import shutil
import socket
import threading
import time

from . import __version__, konfig
from . import aktualisierung, ab18, afwall, anbieter, ed2k_listen, ipfilter, kameras, anbindungen, badges, debrid, dienste, einstellungen, ftp, heimspeicher, rustnzb, sicherheit, telegram, vorlagen, youtube
from .anbieter import freigegeben
from .kette import Kette
from .modul import lade_ordner
from .stremio import App, erstelle_server

from .dienst_grund import *
from .dienst_grund import _version

log = logging.getLogger("rezeptserver")


def eigene_adresse():
    """IP-Adresse im Heimnetz (ohne dass Daten verschickt werden)."""
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        s.connect(("10.255.255.255", 1))
        return s.getsockname()[0]
    except OSError:
        return "127.0.0.1"
    finally:
        s.close()


class Verwaltung:
    """Anbieter aus der Oberflaeche verwalten: liest und speichert die Nutzerdaten und laedt danach
    die Kette neu, ohne den Server neu zu starten."""

    def __init__(self, konfig_pfad, alle, holen=None):
        self.konfig_pfad = konfig_pfad
        self.module = alle
        self.holen = holen
        self.app = None
        self._sperre = threading.Lock()

    def daten(self):
        return konfig.lade(self.konfig_pfad)

    def speichern(self, daten):
        with self._sperre:
            konfig.speichere(self.konfig_pfad, daten)
            if self.app is not None:
                self.app.uebernehmen(**kette_bauen(self.module, self.daten(), self.holen))
        log.info("Anbieter gespeichert, Kette neu geladen")

    def abschnitt(self, name, wert):
        """Einen Abschnitt der Nutzerdaten speichern, ohne die Anbieter neu zu laden (Sammlungen, Listen)."""
        with self._sperre:
            daten = konfig.lade(self.konfig_pfad)
            daten[name] = wert
            konfig.speichere(self.konfig_pfad, daten)

    def bearbeiten(self, aenderung):
        """Wie aendern, aber ohne die Anbieter neu zu laden (Einstellungen, Sammlungen). Gibt deren Ergebnis zurueck."""
        with self._sperre:
            daten = konfig.lade(self.konfig_pfad)
            ergebnis = aenderung(daten)
            konfig.speichere(self.konfig_pfad, daten)
        return ergebnis

    def aendern(self, aenderung):
        """aenderung(daten) aendert die Nutzerdaten; danach speichern und neu laden. Gibt deren Ergebnis zurueck."""
        daten = self.daten()
        ergebnis = aenderung(daten)
        self.speichern(daten)
        return ergebnis


def baue(rezepte, konfig_pfad, host="127.0.0.1", port=7000):
    """Gibt (server, kette, adresse) zurueck. Ein Token ist immer Pflicht, auch auf diesem
    Geraet, und wird bei Bedarf erzeugt."""
    daten = konfig.lade(konfig_pfad)
    lokal = host in ("127.0.0.1", "localhost", "::1")
    if not daten.get("token"):
        daten["token"] = konfig.neues_token()
        konfig.speichere(konfig_pfad, daten)
        log.info("Neues Token erzeugt und in %s gespeichert", konfig_pfad)
    token = daten["token"]
    datenordner = os.path.dirname(os.path.abspath(konfig.datenbank_pfad(konfig_pfad)))
    rezepte = aktualisierung.rezepte_ordner(rezepte, datenordner)  # Rezepte aus der GitHub-Aktualisierung
    alle = lade_ordner(rezepte)
    aufbau = kette_bauen(alle, daten)
    kette = aufbau["kette"]
    verwaltung = Verwaltung(konfig_pfad, alle)

    def abschnitt_speichern(name):
        def speichern(neu):
            aktuell = konfig.lade(konfig_pfad)
            aktuell[name] = neu
            konfig.speichere(konfig_pfad, aktuell)
        return speichern

    try:
        app = App(kette, token=token, wunsch_sprachen=daten.get("sprachen"), filter=daten.get("filter"),
                  filter_speichern=abschnitt_speichern("filter"), anbieter_namen=aufbau["anbieter_namen"],
                  addons=aufbau["addons"], usenet_server=aufbau["usenet_server"], verwaltung=verwaltung,
                  debrid=aufbau["debrid"], rustnzb=aufbau["rustnzb"], dienste=aufbau["dienste"],
                  livetv_einstellung=daten.get("livetv"), livetv_speichern=abschnitt_speichern("livetv"),
                  datenordner=os.path.dirname(os.path.abspath(konfig.datenbank_pfad(konfig_pfad))),
                  links=daten.get("links"), links_speichern=abschnitt_speichern("links"),
                  ab18=ab18.Ab18(daten.get(anbieter.AB18) is True, daten.get(ab18.SCHLUESSEL),
                                 abschnitt_speichern(ab18.SCHLUESSEL)),
                  youtube=youtube.Youtube(daten.get(youtube.SCHLUESSEL), abschnitt_speichern(youtube.SCHLUESSEL)),
                  telegram=telegram_aus(daten, abschnitt_speichern(telegram.SCHLUESSEL)),
                  heimspeicher=daten.get(heimspeicher.SCHLUESSEL), oberflaeche_werte=daten.get(einstellungen.SCHLUESSEL),
                  ftp_einstellung=daten.get(ftp.SERVER_SCHLUESSEL), ftp_speichern=abschnitt_speichern(ftp.SERVER_SCHLUESSEL),
                  kameras=daten.get(kameras.SCHLUESSEL),
                  aktualisierung=aktualisierung.Aktualisierung(datenordner, daten.get(aktualisierung.SCHLUESSEL),
                                                               abschnitt_speichern(aktualisierung.SCHLUESSEL)),
                  badges=badges.Badges(daten.get(badges.SCHLUESSEL),
                                       os.path.dirname(os.path.abspath(konfig.datenbank_pfad(konfig_pfad)))))
        verwaltung.app = app
        app.waechter.starten()
        app.beobachtungen.starten()
        app.telegram.starten()
        app.aktualisierung.starten()
        app.snaps.starten()
        # IP-Filter (P2P) baut sich im Hintergrund auf; server.met/nodes.dat-Quellen aus den Nutzerdaten
        app.ipfilter.anwenden(daten.get(ipfilter.SCHLUESSEL), warten=False)
        # afwall (Sicherheit): gespeicherte Netz-Freigaben beim Start erneut setzen, wenn aktiv und root (PC, Pi)
        afwall.beim_start(daten)
        ed2k_listen.anwenden({"server": app.ed2k_suche.serverliste, "kad": app.kadliste}, daten.get(ed2k_listen.SCHLUESSEL))
        from . import dateien as dateien_modul
        dateien_modul.anwenden(app, daten.get(dateien_modul.SCHLUESSEL))
        from . import nutzung as nutzung_modul
        try:  # Grenzen des Servers (Admin-Panel): Listen-Groessen, Uploads
            nutzung_modul.server_grenzen_anwenden(daten.get(nutzung_modul.SERVER_SCHLUESSEL))
        except ValueError as fehler:
            log.warning("Server-Grenzen: %s", fehler)
        # Docker-Compose mit Pi-hole: Anbieter einmalig selbst anlegen (H0RST_PIHOLE_URL/_PASSWORT)
        if os.environ.get("H0RST_PIHOLE_URL", "").strip():
            threading.Thread(target=pihole_einrichten, name="pihole-einrichten", daemon=True,
                             args=(verwaltung, os.environ["H0RST_PIHOLE_URL"].strip(),
                                   os.environ.get("H0RST_PIHOLE_PASSWORT", ""))).start()
        app.ftp_server.heimnetz = not lokal  # FTP nur, wenn H0rSt im Heimnetz freigegeben ist
        app.ftp_server.starten()
        app.badges.im_hintergrund_laden()
        app.epg.bei_bedarf_erneuern()
        server = erstelle_server(app, host, port)
        server.app = app
        server.zweit = None
        # HTTPS im Heimnetz: Kamera und Mikrofon (Videochat, Profilbild) gehen im Browser nur sicher
        https_port = https_port_aus(daten)
        if not lokal and https_port:
            try:
                from . import tls
                server.zweit = erstelle_server(app, host, https_port, tls.kontext(datenordner))
                app.https_port = https_port
                app.https_fingerabdruck = tls.fingerabdruck(datenordner)
            except Exception as fehler:  # HTTPS ist eine Zugabe: ohne startet H0rSt trotzdem
                log.warning("HTTPS auf Port %d nicht moeglich: %s", https_port, fehler)
    except Exception:
        kette.schliessen()
        aufbau["addons"].schliessen()
        raise
    anzeige_host = "127.0.0.1" if lokal else (eigene_adresse() if host in ("0.0.0.0", "") else host)
    if not lokal:  # Medienserver (DLNA): Fernseher und Receiver sehen H0rSt als Quelle
        from . import dlna_server
        aussen_host = re.sub(r"^https?://([^/:]+).*$", r"\1", os.environ.get("H0RST_ADRESSE", "").strip()) or anzeige_host
        name = "H0rSt" + (" – %s" % app.ui.get("profilname") if app.ui.get("profilname") else "")
        app.dlna_vorbereiten("http://%s:%d/%s/dlna/beschreibung.xml" % (aussen_host, port, token), dlna_server.kennung(token), name)
        if app.ui.get("dlna_server", True):
            app.medienserver_setzen(True)
    adresse = "http://%s:%d/%smanifest.json" % (anzeige_host, port, token + "/" if token else "")
    aussen = os.environ.get("H0RST_ADRESSE", "").strip().rstrip("/")  # im Container: Adresse auf dem Host
    if aussen.startswith(("http://", "https://")):
        adresse = "%s/%smanifest.json" % (aussen, token + "/" if token else "")
    return server, kette, adresse


class Dienst:
    """Ein Server im Hintergrund-Faden; starte() startet bei Bedarf neu."""

    def __init__(self, rezepte, konfig_pfad):
        self.rezepte = rezepte
        self.konfig_pfad = konfig_pfad
        self.adresse = None
        self._lauf = None
        self._sperre = threading.Lock()

    def starte(self, host="127.0.0.1", port=7000):
        """Gibt die Addon-Adresse zurueck."""
        with self._sperre:
            self._stoppe()
            try:
                server, kette, adresse = baue(self.rezepte, self.konfig_pfad, host, port)
            except Exception:
                log.exception("Server konnte nicht starten")
                raise
            threading.Thread(target=server.serve_forever, name="rezeptserver", daemon=True).start()
            if getattr(server, "zweit", None) is not None:
                threading.Thread(target=server.zweit.serve_forever, name="rezeptserver-https", daemon=True).start()
            self._lauf = (server, kette)
            self.adresse = adresse
        basis = adresse[:-len("manifest.json")]
        https = getattr(self._lauf[0].app, "https_port", 0)
        if https:
            log.info("Sicher (fuer Kamera und Videochat): %s", re.sub(r"^http://([^/:]+):\d+", r"https://\1:%d" % https, basis))
        server_adresse = "/".join(adresse.split("/")[:3])
        log.info("Rezeptserver %s laeuft. Addon-Adresse fuer Jacktook/Stremio:\n  %s\n"
                 "Durchsuchen im Browser: %s\nLive-TV fuer IPTV-Apps: %stv.m3u\n"
                 "Xtream Codes: Server %s, Benutzer beliebig, Passwort = Token aus der Adresse",
                 __version__, adresse, basis, basis, server_adresse)
        return adresse

    def stoppe(self):
        with self._sperre:
            self._stoppe()

    @property
    def laeuft(self):
        return self._lauf is not None

    def _stoppe(self):
        if self._lauf is None:
            return
        server, kette = self._lauf
        self._lauf = None
        self.adresse = None
        if getattr(getattr(server, "app", None), "nutzung", None) is not None:
            server.app.nutzung.speichern(sofort=True)
        server.shutdown()
        server.server_close()
        if getattr(server, "zweit", None) is not None:
            server.zweit.shutdown()
            server.zweit.server_close()
        kette.schliessen()
        server.app.schliessen()  # nach Neuladen der Anbieter ist es eine neuere Kette
        log.info("beendet")
