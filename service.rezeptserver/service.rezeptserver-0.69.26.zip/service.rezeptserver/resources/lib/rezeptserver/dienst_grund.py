"""Grundbausteine des Server-Lebens: Rezepte uebernehmen, Kette nutzbar machen, Start-Helfer."""

import json
import logging
import os
import shutil
import time

from . import anbindungen, anbieter, debrid, dienste, rustnzb, sicherheit, telegram, vorlagen
from .anbieter import freigegeben
from .kette import Kette

log = logging.getLogger("rezeptserver")


def _version(ordner):
    try:
        with open(os.path.join(ordner, "manifest.json"), encoding="utf-8") as f:
            roh = str(json.load(f).get("version", ""))
        return tuple(int(t) for t in roh.split("."))
    except (OSError, ValueError, AttributeError):
        return ()


def rezepte_uebernehmen(quelle, ziel):
    """Mitgelieferte Rezepte nach ziel kopieren: fehlende und solche mit hoeherer version.

    Eigene Rezepte und gleich alte oder neuere Fassungen in ziel bleiben unangetastet.
    """
    os.makedirs(ziel, exist_ok=True)
    for name in sorted(os.listdir(quelle)):
        von, nach = os.path.join(quelle, name), os.path.join(ziel, name)
        if not os.path.isfile(os.path.join(von, "manifest.json")):
            continue
        if os.path.isdir(nach) and _version(nach) >= _version(von):
            continue
        shutil.rmtree(nach, ignore_errors=True)
        shutil.copytree(von, nach, ignore=shutil.ignore_patterns("__pycache__", "*.pyc"))
        log.info("Rezept %s uebernommen (Version %s)", name, ".".join(map(str, _version(von))))


def nutzbar(module, daten):
    """Nur Rezepte, deren Anbieter keine Anmeldung braucht oder vollstaendige Zugangsdaten hat."""
    einstellungen = daten.get("einstellungen") or {}
    bereit = [m for m in module if not m.fehlende_einstellungen(einstellungen.get(m.konto, {}))]
    fehlen = sorted({m.konto for m in module if m not in bereit})
    if fehlen:
        log.info("Ohne Zugangsdaten ausgelassen: %s", ", ".join(fehlen))
    return bereit


def kette_bauen(alle, daten, holen=None):
    """Kette aus Rezepten und eigenen Anbietern (Indexer, Xtream, vxparser) samt Addons und Usenet-Servern.
    Gibt ein dict fuer App(...) bzw. App.uebernehmen(...) zurueck."""
    sicherheit.anwenden(daten)  # Netzweg und Notbremse gelten ab jetzt fuer alle Abrufe
    eigene = anbindungen.module(daten)
    weitere = {"holen": holen} if holen else {}
    kette = Kette(nutzbar(freigegeben(alle, daten) + eigene, daten), daten.get("einstellungen"),
                  daten.get("zeitgrenzen"), **weitere)
    namen = {a["id"]: a["name"] for a in anbieter.liste(alle, daten)}
    return {"kette": kette, "anbieter_namen": namen, "addons": anbindungen.KombiAddons(anbindungen.stremio_addons(daten, **weitere),
                                              anbindungen.mhub_addons(daten, **weitere)),
            "usenet_server": anbindungen.usenet_server(daten),
            "debrid": debrid.Debrid(debrid.konten(daten), **weitere),
            "rustnzb": rustnzb_client(daten, holen),
            "dienste": dienste.aus_daten(daten, dienste.aus_antwort(holen) if holen else None)}


def rustnzb_client(daten, holen=None):
    """Client fuer den ersten vollstaendigen rustnzb-Anbieter (Adresse und API-Schluessel), sonst None."""
    for anbieter_id, _, werte in anbindungen.eigene(daten, "rustnzb"):
        if werte.get("url", "").strip() and werte.get("api_key", "").strip():
            try:
                return rustnzb.Client(werte, holen=holen)
            except rustnzb.RustnzbFehler as fehler:
                log.warning("rustnzb (%s): %s", anbieter_id, fehler)
    return None


PIHOLE_MERKER = "pihole_automatisch"  # Nutzerdaten: einmal angelegt (auch wenn spaeter geloescht, nicht wieder)


def pihole_einrichten(verwaltung, url, passwort, versuche=40, pause=15.0, warten=None, holen=None):
    """Pi-hole aus demselben Docker-Compose automatisch als Anbieter eintragen.

    Wartet, bis Pi-hole antwortet und das Passwort annimmt (der Container braucht beim ersten Start etwas), legt dann
    einmalig den Anbieter "Pi-hole" an und merkt sich das. Gibt die neue Anbieter-ID zurueck oder None."""
    warten = warten or time.sleep
    daten = verwaltung.daten()
    if daten.get(PIHOLE_MERKER) or any(e.get("typ") == "pihole" for e in (daten.get("anbieter") or {}).values()):
        return None
    werte = {"url": url, "pass": passwort}
    for versuch in range(versuche):
        try:
            dienste.KLASSEN["pihole"]("Pi-hole", werte, holen).zustand()
            break
        except Exception as fehler:  # Container startet noch, Name noch nicht aufloesbar ...
            if versuch == versuche - 1:
                log.info("Pi-hole automatisch einrichten: nicht erreichbar (%s)", fehler)
                return None
            warten(pause)

    def anlegen(d):
        if d.get(PIHOLE_MERKER) or any(e.get("typ") == "pihole" for e in (d.get("anbieter") or {}).values()):
            return None
        d[PIHOLE_MERKER] = True
        return vorlagen.anlegen(d, verwaltung.module, "pihole", werte, "Pi-hole")
    neu = verwaltung.aendern(anlegen)
    if neu:
        log.info("Pi-hole automatisch eingetragen (%s)", url)
    return neu


def https_port_aus(daten):
    """Port fuer HTTPS (Nutzerdaten "https": {"an", "port"}, Umgebung H0RST_HTTPS_PORT); 0 = aus."""
    e = daten.get("https") if isinstance(daten.get("https"), dict) else {}
    if e.get("an") is False or os.environ.get("H0RST_HTTPS", "").lower() in ("0", "aus", "nein"):
        return 0
    try:
        port = int(os.environ.get("H0RST_HTTPS_PORT") or e.get("port") or 7443)
    except ValueError:
        return 7443
    return port if 1024 <= port <= 65535 else 7443


def telegram_aus(daten, speichern):
    """Telegram-Bot aus den Nutzerdaten; kaputte Einstellungen schalten ihn ab statt den Start zu verhindern."""
    try:
        return telegram.Telegram(daten.get(telegram.SCHLUESSEL), speichern)
    except telegram.TelegramFehler as fehler:
        log.warning("Telegram aus: %s", fehler)
        return telegram.Telegram({}, speichern)
