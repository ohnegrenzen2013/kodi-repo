"""Dienste-Zentrale wie nzb360: Download-Clients, Sonarr/Radarr/Lidarr, Seerr, Prowlarr, Tautulli, Bazarr.

Jeder Dienst ist ein eigener Anbieter (Typ wie unten) mit Adresse und Zugang. H0rSt spricht ihn ueber dessen
Web-API an und bereitet alles einheitlich auf:

  Download-Clients (zustand, aktion, nzb/torrent hinzufuegen)
    nzbget        JSON-RPC (v26.3: status, listgroups, history, editqueue, append, rate)
    sabnzbd       /api?mode=queue|history|pause|resume|retry|addfile|config
    rustnzb       ueber rustnzb.Client
    qbittorrent   Web-API v2 (Anmeldung per Cookie, v5 stop/start, aeltere pause/resume)
    transmission  RPC mit X-Transmission-Session-Id
    deluge        Web-JSON-RPC (auth.login, web.update_ui, core.*)
    downloadmaster  ASUS Download Master auf dem AsusWRT-Router (Port 8081): HTTP, FTP, BT/Magnet, NZB und ed2k
                  direkt auf die USB-Platte; Anmeldung wie die Weboberflaeche (check.asp, Cookie AuthByPasswd)
  Medienverwaltung
    sonarr/radarr/lidarr  Kalender, Warteschlange, zuletzt geladen, fehlend, nachschlagen und hinzufuegen;
                  sonarr/radarr zusaetzlich Verlauf, manuelle Suche mit Status und Fehlschlag melden; alle: Speicher (diskspace)
    seerr         Anfragen (Overseerr/Jellyseerr): auflisten, genehmigen, ablehnen
    prowlarr      Suche ueber alle Indexer, "Holen" schickt an Prowlarrs Download-Client
    tautulli      laufende Streams
    bazarr        fehlende Untertitel
  Netzwerk
    pihole        Pi-hole (v6 /api, v5 /admin/api.php): Statistik, Blockieren pausieren und wieder einschalten
"""

from .dienste_grund import *
from .dienste_grund import (_OEFFNER, _als_antwort, _basic, _basis, _bytes, _cookies, _umleitung,
                               _eintrag, _job, _json, _multipart, _prozent, _zeit)
from .dienste_downloads import (_DM_EINHEIT, _dm_bytes, AltMount, DownloadMaster, Deluge, NzbDav, NzbGet,
                                QBittorrent, Rustnzb, Sabnzbd, Transmission)
from .dienste_medien import _AltePihole, Arr, Bazarr, Kodi, Lidarr, Pihole, Prowlarr, Radarr, Seerr, Sonarr, Tautulli

KLASSEN = {"nzbget": NzbGet, "sabnzbd": Sabnzbd, "nzbdav": NzbDav, "altmount": AltMount, "rustnzb": Rustnzb, "qbittorrent": QBittorrent,
           "transmission": Transmission, "deluge": Deluge, "downloadmaster": DownloadMaster, "sonarr": Sonarr, "radarr": Radarr, "lidarr": Lidarr,
           "seerr": Seerr, "prowlarr": Prowlarr, "tautulli": Tautulli, "bazarr": Bazarr, "kodi": Kodi, "pihole": Pihole}


def aus_daten(daten, holen=None):
    """{anbieter_id: Client} aller eingerichteten Dienste (Adresse gesetzt)."""
    ergebnis = {}
    werte_alle = daten.get("einstellungen") or {}
    for anbieter_id, e in sorted((daten.get("anbieter") or {}).items()):
        klasse = KLASSEN.get(e.get("typ"))
        werte = {k: str(w) for k, w in (werte_alle.get(anbieter_id) or {}).items()}
        if not klasse or not werte.get("url", "").strip():
            continue
        try:
            ergebnis[anbieter_id] = klasse(e["name"], werte, holen)
        except DienstFehler:
            continue
    return ergebnis
