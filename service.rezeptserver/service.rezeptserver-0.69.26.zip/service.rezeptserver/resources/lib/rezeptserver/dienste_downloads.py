"""Download-Clients: NZBGet, SABnzbd, rustnzb, qBittorrent, Transmission, Deluge
und ASUS Download Master."""

from .dienste_downloads_grund import *
from .dienste_downloads_grund import _DM_EINHEIT, _als_antwort, _basic, _bytes, _eintrag, _job, _json, _multipart, _zeit
from .dienste_downloads_nzbget import NzbGet
from .dienste_downloads_sabnzbd import AltMount, NzbDav, Sabnzbd
from .dienste_downloads_rustnzb import Rustnzb
from .dienste_downloads_torrent import QBittorrent, Transmission
from .dienste_downloads_downloadmaster import DownloadMaster, _dm_bytes
from .dienste_downloads_deluge import Deluge
