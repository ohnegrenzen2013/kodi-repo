"""Deluge: Torrents hinzufuegen, loeschen und verwalten."""

from .dienste_downloads_grund import (
    Client,
    DienstFehler,
    _cookies,
    _job,
    _umleitung,
    _json,
    _torrent_pruefen,
    base64,
    ist_magnet,
    json,
    re,
)

class Deluge(Client):
    typ = "deluge"
    ENDUNGEN = (r"/json",)
    kann = ("pause_alle", "resume_alle", "pause", "resume", "loeschen", "limit", "torrent", "torrent_datei")

    def __init__(self, name, werte, holen=None):
        super().__init__(name, werte, holen)
        self._cookie = None
        self._nummer = 0

    def _roh(self, methode, *parameter):
        self._nummer += 1
        kopf = {"Content-Type": "application/json"}
        if self._cookie:
            kopf["Cookie"] = self._cookie
        status, header, text = self.http(self.url + "/json", "POST", kopf,
                                         json.dumps({"method": methode, "params": list(parameter), "id": self._nummer}))
        _umleitung(status, header, "Deluge")
        keks = re.search(r"_session_id=([^;,\s]+)", _cookies(header))
        if keks:
            self._cookie = "_session_id=" + keks.group(1)
        d = _json(text, "Deluge")
        if status >= 400 or d.get("error"):
            fehler = d.get("error") or {}
            raise DienstFehler("Deluge: %s" % (fehler.get("message") if isinstance(fehler, dict) else fehler or status))
        return d.get("result")

    def rpc(self, methode, *parameter):
        if not self._cookie:
            if not self._roh("auth.login", self.werte.get("pass", "")):
                raise DienstFehler("Deluge lehnt das Passwort ab")
            if not self._roh("web.connected"):
                hosts = self._roh("web.get_hosts") or []
                if not hosts:
                    raise DienstFehler("Deluge-Weboberfläche ist mit keinem Daemon verbunden")
                self._roh("web.connect", hosts[0][0])
        return self._roh(methode, *parameter)

    def zustand(self):
        felder = ["name", "state", "total_wanted", "total_done", "download_payload_rate", "eta", "label", "message"]
        d = self.rpc("web.update_ui", felder, {}) or {}
        jobs = [_job(h, t.get("name"), {"Downloading": "lädt", "Seeding": "teilt", "Paused": "pausiert",
                                        "Queued": "wartet", "Checking": "prüft", "Error": "Fehler"}.get(t.get("state"), t.get("state")),
                     t.get("total_wanted"), int(t.get("total_wanted") or 0) - int(t.get("total_done") or 0),
                     t.get("download_payload_rate"), t.get("eta") or None, t.get("label"), t.get("state") == "Paused",
                     t.get("message") if t.get("state") == "Error" else "")
                for h, t in (d.get("torrents") or {}).items()]
        statistik = d.get("stats") or {}
        return {"version": self.rpc("daemon.get_version") or "", "tempo": int(statistik.get("download_rate") or 0),
                "pausiert": False, "frei": statistik.get("free_space"),
                "limit": int(statistik.get("max_download") or 0) * 1024 if (statistik.get("max_download") or -1) > 0 else 0,
                "jobs": jobs, "verlauf": []}

    def aktion(self, was, id_=None, wert=None):
        if was in ("pause_alle", "resume_alle"):
            return self.rpc("core.pause_session" if was == "pause_alle" else "core.resume_session")
        if was in ("pause", "resume"):
            return self.rpc("core.pause_torrent" if was == "pause" else "core.resume_torrent", [id_])
        if was == "loeschen":
            return self.rpc("core.remove_torrent", id_, False)
        if was == "limit":
            return self.rpc("core.set_config", {"max_download_speed": (int(wert) // 1024) if wert else -1})
        raise DienstFehler("Deluge kann %s nicht" % was)

    def torrent_hinzufuegen(self, magnet, kategorie=""):
        if not ist_magnet(magnet):  # Adresse einer .torrent-Datei: Deluge laedt sie selbst, add_torrent_magnet nimmt nur Magnets
            return [str(self.rpc("core.add_torrent_url", str(magnet).strip(), {}) or "")]
        return [str(self.rpc("core.add_torrent_magnet", magnet, {}) or "")]

    def torrent_datei_hinzufuegen(self, name, inhalt, kategorie=""):
        # core.add_torrent_file erwartet den Dateiinhalt als Base64-Text, nicht als Bytes
        datei = base64.b64encode(_torrent_pruefen(inhalt)).decode("ascii")
        return [str(self.rpc("core.add_torrent_file", name or "datei.torrent", datei, {}) or "")]


