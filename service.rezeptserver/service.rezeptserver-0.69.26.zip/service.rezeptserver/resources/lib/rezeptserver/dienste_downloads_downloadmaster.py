"""ASUS Download Master: Auftraege, Loeschen und URL-Erkennung."""

from .dienste_downloads_grund import (
    Client,
    DienstFehler,
    _DM_EINHEIT,
    _eintrag,
    _job,
    _multipart,
    base64,
    json,
    re,
    time,
    urlencode,
)

def _dm_bytes(text):
    """"1.25 GB", "700 MB", "512 KB/s" -> Bytes."""
    m = _DM_EINHEIT.search(str(text or ""))
    if not m:
        return 0
    return int(float(m.group(1).replace(",", ".")) * 1024 ** ("KMGT".index(m.group(2).upper()) + 1 if m.group(2) else 0))


class DownloadMaster(Client):
    """ASUS Download Master (AsusWRT, App "Download Master" am USB-Anschluss), Weboberflaeche auf Port 8081.

    Die Schnittstelle ist die der eigenen Weboberflaeche (downloadmaster 3.1.0.114):
      Anmeldung   POST /check.asp  login_username/login_passwd Base64 -> Cookie AuthByPasswd (Pfad /downloadmaster/)
      Liste       GET  /downloadmaster/dm_print_status.cgi?action_mode=All
                  ["id","name","fortschritt 0..1","groesse","status","typ","?","down","up",peers,"?","fertig","ordner"],...
      Hinzufuegen GET  /downloadmaster/dm_apply.cgi?action_mode=DM_ADD&download_type=5&again=no&usb_dm_url=<link>
                  (HTTP, FTP, Magnet, ed2k) -> ACK_SUCESS | ACK_FAIL | ACK_LIMIT | BT_EXIST
                  POST /downloadmaster/dm_uploadbt.cgi  multipart "filename" (.torrent, .nzb)
      Steuern     dm_apply.cgi?action_mode=DM_CTRL&dm_ctrl=start|paused|cancel|clear&task_id=&download_type=<typ>
                  dm_ctrl=start_all|pause_all&download_type=ALL
    Abgelaufene Anmeldung meldet der Router mit HTTP 598; dann meldet sich H0rSt neu an.
    """
    typ = "downloadmaster"
    kann = ("pause_alle", "resume_alle", "pause", "resume", "loeschen", "verlauf_loeschen", "nzb", "torrent", "ed2k", "link")
    STATUS = {"Downloading": "lädt", "Paused": "pausiert", "Finished": "fertig", "Seeding": "teilt", "Hashing": "prüft",
              "notbegin": "wartet", "Error": "Fehler", "Diskfull": "Platte voll", "Timeout": "Zeitüberschreitung",
              "Disconnected": "getrennt", "Stop": "gestoppt", "ConnectFail": "keine Verbindung",
              "AccountFail": "Anmeldung abgelehnt", "SSLFail": "SSL-Fehler", "NotCompleted": "unvollständig"}
    FERTIG = ("Finished", "Seeding")

    def __init__(self, name, werte, holen=None):
        super().__init__(name, werte, holen)
        self._keks = ""

    def _anmelden(self):
        b64 = lambda w: base64.b64encode(str(w or "").encode("utf-8")).decode("ascii")
        formular = urlencode({"flag": "", "login_username": b64(self.werte.get("user")),
                              "login_passwd": b64(self.werte.get("pass")), "directurl": "/downloadmaster/task.asp"})
        status, header, text = self.http(self.url + "/check.asp", "POST",
                                         {"Content-Type": "application/x-www-form-urlencoded"}, formular)
        kekse = []
        if header is not None:
            kekse = header.get_all("Set-Cookie") if hasattr(header, "get_all") else [header.get("Set-Cookie", "")]
        for keks in kekse or []:
            m = re.search(r"AuthByPasswd=([^;]+)", keks or "")
            if m:
                self._keks = "AuthByPasswd=" + m.group(1)
                return
        if status in (200, 302) and "lock" in text.lower():
            raise DienstFehler("Download Master: zu viele Fehlversuche, Anmeldung kurz gesperrt")
        raise DienstFehler("Download Master lehnt Benutzer/Passwort ab (Router-Zugang)")

    def _abruf(self, pfad, methode="GET", kopf=None, daten=None, zeit=20.0):
        for versuch in range(2):
            if not self._keks:
                self._anmelden()
            k = dict(kopf or {}, Cookie=self._keks)
            status, header, text = self.http(self.url + "/downloadmaster/" + pfad, methode, k, daten, zeit)
            if status in (598, 401, 403) or (status == 200 and "Main_Login.asp" in text[:400]):
                self._keks = ""
                if versuch == 0:
                    continue
                raise DienstFehler("Download Master: Anmeldung abgelaufen oder abgelehnt")
            if status >= 400:
                raise DienstFehler("Download Master: HTTP %d" % status)
            return text
        raise DienstFehler("Download Master: keine Antwort")

    def aufgaben(self):
        text = self._abruf("dm_print_status.cgi?action_mode=All&t=%d" % int(time.time() * 1000)).strip()
        if not text:
            return []
        try:
            return [a for a in json.loads("[" + text + "]") if isinstance(a, list) and len(a) >= 6]
        except ValueError:
            raise DienstFehler("Download Master antwortet unerwartet – Adresse (Port 8081) richtig?")

    def zustand(self):
        jobs, verlauf, tempo = [], [], 0
        for a in self.aufgaben():
            a = [str(x) for x in a] + [""] * (13 - len(a))
            try:
                fortschritt = min(1.0, max(0.0, float(a[2] or 0)))
            except ValueError:
                fortschritt = 0.0
            gesamt = _dm_bytes(a[3])
            down = _dm_bytes(a[7])
            if a[4] in self.FERTIG:
                verlauf.append(_eintrag(a[0], a[1], self.STATUS.get(a[4], a[4]), True, gesamt, kategorie=a[5]))
                continue
            tempo += down if a[4] == "Downloading" else 0
            fehler = self.STATUS.get(a[4], "") if a[4] not in ("Downloading", "Paused", "notbegin", "Hashing") else ""
            jobs.append(_job(a[0], a[1], self.STATUS.get(a[4], a[4]), gesamt, int(gesamt * (1 - fortschritt)), down,
                             kategorie=a[5], pausiert=a[4] == "Paused", fehler=fehler))
        return {"version": "", "tempo": tempo, "pausiert": False, "frei": None, "limit": 0, "jobs": jobs, "verlauf": verlauf}

    def pruefen(self):
        z = self.zustand()
        return "ASUS Download Master erreichbar, %d Aufgaben" % (len(z["jobs"]) + len(z["verlauf"]))

    def _steuern(self, dm_ctrl, task_id="", typ="ALL"):
        parameter = {"action_mode": "DM_CTRL", "dm_ctrl": dm_ctrl, "download_type": typ}
        if task_id:
            parameter["task_id"] = task_id
        return self._abruf("dm_apply.cgi?" + urlencode(parameter) + "&t=%d" % int(time.time() * 1000))

    def _typ(self, task_id):
        for a in self.aufgaben():
            if str(a[0]) == str(task_id):
                return str(a[5])
        raise DienstFehler("Aufgabe %s gibt es nicht (mehr)" % task_id)

    def aktion(self, was, id_=None, wert=None):
        if was == "pause_alle":
            return self._steuern("pause_all")
        if was == "resume_alle":
            return self._steuern("start_all")
        if was in ("pause", "resume", "loeschen"):
            return self._steuern({"pause": "paused", "resume": "start", "loeschen": "cancel"}[was], str(id_), self._typ(id_))
        if was == "verlauf_loeschen":  # fertige Aufgaben aus der Liste nehmen (Dateien bleiben)
            for a in self.aufgaben():
                if str(a[4]) in self.FERTIG:
                    self._steuern("clear", str(a[0]), str(a[5]))
            return True
        raise DienstFehler("Download Master kann %s nicht" % was)

    @staticmethod
    def _antwort(text):
        if "BT_EXIST" in text:
            raise DienstFehler("Download Master hat diese Aufgabe schon")
        if "ACK_LIMIT" in text or "HEAVY_FULL" in text or "LIGHT_FULL" in text:
            raise DienstFehler("Download Master: zu viele Aufgaben gleichzeitig")
        if "ACK_SUCESS" not in text:
            raise DienstFehler("Download Master hat die Aufgabe nicht angenommen")
        return True

    def link_hinzufuegen(self, link):
        """HTTP-, FTP-, Magnet- und ed2k-Links (wie das Adressfeld der Weboberflaeche)."""
        link = str(link or "").replace("\n", "").strip()
        if not re.match(r"^(https?|ftp|magnet|ed2k):", link, re.I):
            raise DienstFehler("Download Master nimmt http(s)://, ftp://, magnet: und ed2k://-Links")
        parameter = urlencode({"action_mode": "DM_ADD", "download_type": 5, "again": "no", "usb_dm_url": link})
        return self._antwort(self._abruf("dm_apply.cgi?" + parameter + "&t=%d" % int(time.time() * 1000)))

    def torrent_hinzufuegen(self, magnet, kategorie=""):
        self.link_hinzufuegen(magnet)
        return [""]

    def ed2k_hinzufuegen(self, link):
        return self.link_hinzufuegen(link)

    def _datei(self, dateiname, inhalt, typ):
        koerper, inhaltstyp = _multipart({}, "filename", dateiname, inhalt, typ)
        return self._antwort(self._abruf("dm_uploadbt.cgi", "POST", {"Content-Type": inhaltstyp}, koerper, 60.0))

    def nzb_hinzufuegen(self, name, daten, kategorie=""):
        self._datei(re.sub(r"[^\w.\- ]", "_", name)[:120] + ".nzb", daten, "application/x-nzb")
        return [""]

    def torrent_datei_hinzufuegen(self, name, daten):
        self._datei(re.sub(r"[^\w.\- ]", "_", name)[:120] + ".torrent", daten, "application/x-bittorrent")
        return [""]


