"""Download-Clients: NZBGet, SABnzbd, rustnzb, qBittorrent, Transmission, Deluge
und ASUS Download Master. Grundlage: Importe samt Wiederexport (rezeptserver.dienste_downloads.*)."""


import posixpath

from .dienste_grund import (
    Client,
    DienstFehler,
    _DM_EINHEIT,
    _als_antwort,
    _basic,
    _cookies,
    _umleitung,
    _bytes,
    _eintrag,
    _job,
    _json,
    _multipart,
    _zeit,
    base64,
    json,
    re,
    time,
    urlencode,
    urlsplit,
)


MAX_TORRENT = 5 * 1024 * 1024


def _torrent_pruefen(inhalt):
    """Eine .torrent-Datei ist ein Bencode-Woerterbuch mit "info"; alles andere nicht an den Client schicken."""
    if not isinstance(inhalt, (bytes, bytearray)) or not inhalt:
        raise DienstFehler("Die Torrent-Datei ist leer")
    if len(inhalt) > MAX_TORRENT:
        raise DienstFehler("Die Torrent-Datei ist größer als %d MB" % (MAX_TORRENT // 1048576))
    if not (inhalt.startswith(b"d") and b"4:info" in inhalt):
        raise DienstFehler("Das ist keine gültige .torrent-Datei")
    return bytes(inhalt)


def ist_magnet(adresse):
    return str(adresse or "").strip().lower().startswith("magnet:")
