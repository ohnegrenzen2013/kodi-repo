"""NZBGet: Warteschlange, Verlauf, Entfernen, Wiederholen, Tempolimit und NZB senden."""

from .dienste_downloads_grund import (
    Client,
    DienstFehler,
    _basic,
    _bytes,
    _eintrag,
    _job,
    _json,
    _zeit,
    base64,
    json,
)

class NzbGet(Client):
    typ = "nzbget"
    kann = ("pause_alle", "resume_alle", "pause", "resume", "loeschen", "wiederholen", "verlauf_loeschen", "limit", "nzb")
    STATUS = {"QUEUED": "wartet", "PAUSED": "pausiert", "DOWNLOADING": "lädt", "FETCHING": "holt NZB",
              "PP_QUEUED": "wartet auf Nachbearbeitung", "LOADING_PARS": "lädt PAR2", "VERIFYING_SOURCES": "prüft",
              "REPAIRING": "repariert", "VERIFYING_REPAIRED": "prüft", "RENAMING": "benennt um",
              "UNPACKING": "entpackt", "MOVING": "verschiebt", "EXECUTING_SCRIPT": "Skript", "PP_FINISHED": "fertig"}

    # Verlaufs-Status von NZBGet 26.3 (NzbInfo::MakeTextStatus)
    VERLAUF = {"DELETED/COPY": "Kopie, schon geladen", "DELETED/DUPE": "Duplikat",
               "DELETED/GOOD": "gelöscht, war schon gut", "DELETED/MANUAL": "von Hand gelöscht",
               "FAILURE/BAD": "als fehlerhaft markiert", "FAILURE/HEALTH": "zu viele fehlende Artikel",
               "FAILURE/INTERNAL_ERROR": "interner Fehler", "FAILURE/MOVE": "Verschieben fehlgeschlagen",
               "FAILURE/PAR": "Reparatur fehlgeschlagen", "FAILURE/SCAN": "Prüfung fehlgeschlagen",
               "FAILURE/UNPACK": "Entpacken fehlgeschlagen", "WARNING/DAMAGED": "beschädigt",
               "WARNING/REPAIRABLE": "reparierbar"}
    HAUPT = {"SUCCESS": "fertig", "WARNING": "Warnung", "FAILURE": "fehlgeschlagen", "DELETED": "gelöscht"}

    @classmethod
    def _verlauf_status(cls, status):
        if status.startswith("SUCCESS"):
            return "fertig"
        return cls.VERLAUF.get(status) or cls.HAUPT.get(status.partition("/")[0], status.lower())

    def rpc(self, methode, *parameter):
        status, _, text = self.http(self.url + "/jsonrpc", "POST",
                                    {"Content-Type": "application/json",
                                     "Authorization": _basic(self.werte.get("user"), self.werte.get("pass"))},
                                    json.dumps({"method": methode, "params": list(parameter), "id": 1}))
        if status == 401:
            raise DienstFehler("NZBGet lehnt Benutzer/Passwort ab (ControlUsername/ControlPassword)")
        d = _json(text, "NZBGet")
        if status >= 400 or d.get("error"):
            fehler = d.get("error")
            raise DienstFehler("NZBGet: %s" % ((fehler or {}).get("message") if isinstance(fehler, dict) else fehler
                                               or "HTTP %d" % status))
        return d.get("result")

    def zustand(self):
        s = self.rpc("status")
        jobs = []
        for g in self.rpc("listgroups", 0) or []:
            gesamt, rest = _bytes(g, "FileSize"), _bytes(g, "RemainingSize")
            status = g.get("Status", "")
            # pausiert, sobald alles Verbleibende pausiert ist (Status bleibt sonst DOWNLOADING, bis die
            # letzten Verbindungen fertig sind)
            pausiert_bytes = _bytes(g, "PausedSize")
            pausiert = status == "PAUSED" or (pausiert_bytes > 0 and pausiert_bytes >= _bytes(g, "RemainingSize"))
            jobs.append(_job(g.get("NZBID"), g.get("NZBName"), "pausiert" if pausiert else self.STATUS.get(status, status.lower()),
                             gesamt, rest, kategorie=g.get("Category"), pausiert=pausiert,
                             fehler="Health %.1f %%" % (g["Health"] / 10.0) if int(g.get("Health") or 1000) < 1000 else ""))
        tempo = int(s.get("DownloadRate") or 0)
        for j in jobs:
            if j["status"] == "lädt" and tempo:
                j["tempo"], j["eta"] = tempo, int(j["rest"] / tempo)
        verlauf = []
        for h in (self.rpc("history", False) or [])[:30]:
            status = str(h.get("Status") or "")
            verlauf.append(_eintrag(h.get("NZBID"), h.get("Name"), self._verlauf_status(status),
                                    status.startswith("SUCCESS"), _bytes(h, "FileSize"),
                                    _zeit(h.get("HistoryTime")), h.get("Category"),
                                    "" if status.startswith("SUCCESS") else status))
        return {"version": self.rpc("version"), "tempo": tempo, "pausiert": bool(s.get("DownloadPaused")),
                "frei": int(s.get("FreeDiskSpaceMB") or 0) * 1048576 or None, "limit": int(s.get("DownloadLimit") or 0),
                "jobs": jobs, "verlauf": verlauf}

    def aktion(self, was, id_=None, wert=None):
        befehle = {"pause": "GroupPause", "resume": "GroupResume", "loeschen": "GroupDelete",
                   "wiederholen": "HistoryRedownload", "verlauf_loeschen": "HistoryDelete"}
        if was == "pause_alle":
            return self.rpc("pausedownload")
        if was == "resume_alle":
            return self.rpc("resumedownload")
        if was == "limit":
            return self.rpc("rate", int(wert or 0) // 1024)  # NZBGet erwartet KB/s
        if was in befehle:
            return self.rpc("editqueue", befehle[was], "", [int(id_)])
        raise DienstFehler("NZBGet kann %s nicht" % was)

    def nzb_hinzufuegen(self, name, daten, kategorie=""):
        ergebnis = self.rpc("append", name + ".nzb", base64.b64encode(daten).decode("ascii"),
                            kategorie or self.werte.get("kategorie", ""), 0, False, False, "", 0, "SCORE", [])
        if not ergebnis or int(ergebnis) <= 0:
            raise DienstFehler("NZBGet hat die NZB nicht angenommen")
        return [str(ergebnis)]


