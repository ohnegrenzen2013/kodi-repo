"""rustnzb: Warteschlange, Verlauf und NZB senden."""

from .dienste_downloads_grund import (
    Client,
    _als_antwort,
    _eintrag,
    _job,
)

class Rustnzb(Client):
    typ = "rustnzb"
    kann = ("pause_alle", "resume_alle", "pause", "resume", "loeschen", "wiederholen", "nzb")

    def __init__(self, name, werte, holen=None):
        super().__init__(name, werte, holen)
        from . import rustnzb
        self.client = rustnzb.Client(werte, holen=None if holen is None else _als_antwort(holen))

    def zustand(self):
        s = self.client.status()
        w = self.client.warteschlange()
        jobs = [_job(j["id"], j["name"], j["status_name"], j["gesamt"], j["gesamt"] - j["geladen"], j["geschwindigkeit"],
                     kategorie=j["kategorie"], pausiert=j["status"] == "paused", fehler=j["fehler"]) for j in w["jobs"]]
        verlauf = [_eintrag(e["id"], e["name"], e["status_name"], e["status"] == "completed", e["gesamt"], e["fertig"],
                            e["kategorie"], e["fehler"]) for e in self.client.verlauf()]
        return {"version": s.get("version", ""), "tempo": int(s.get("speed_bps") or 0), "pausiert": bool(s.get("paused")),
                "frei": s.get("disk_space_free"), "limit": int(s.get("speed_limit_bps") or 0), "jobs": jobs,
                "verlauf": verlauf, "mediathek": bool(s.get("webdav_enabled"))}

    def aktion(self, was, id_=None, wert=None):
        was = {"pause_alle": "pause", "resume_alle": "resume"}.get(was, was)
        return self.client.aktion(was, id_)

    def nzb_hinzufuegen(self, name, daten, kategorie=""):
        return self.client.nzb_hinzufuegen(name, daten, kategorie or None)


