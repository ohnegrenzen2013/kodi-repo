"""SABnzbd, NzbDAV und AltMount: Warteschlange, Verlauf und NZB senden."""

from .dienste_downloads_grund import (
    Client,
    DienstFehler,
    _eintrag,
    _job,
    _json,
    _multipart,
    _zeit,
    posixpath,
    re,
    time,
    urlencode,
)

class Sabnzbd(Client):
    typ = "sabnzbd"
    kann = ("pause_alle", "resume_alle", "pause", "resume", "loeschen", "wiederholen", "verlauf_loeschen", "limit", "nzb")
    API_PFAD = "/api"

    def api(self, **parameter):
        parameter.update(output="json", apikey=self.werte.get("api_key", ""))
        status, _, text = self.http(self.url + self.API_PFAD + "?" + urlencode(parameter))
        d = _json(text, "SABnzbd")
        if status >= 400 or (isinstance(d, dict) and d.get("status") is False and d.get("error")):
            raise DienstFehler("SABnzbd: %s" % (d.get("error") if isinstance(d, dict) else "HTTP %d" % status))
        return d

    def zustand(self):
        q = self.api(mode="queue", limit=100).get("queue") or {}
        tempo = int(float(q.get("kbpersec") or 0) * 1024)
        jobs = []
        for s in q.get("slots") or []:
            gesamt = float(s.get("mb") or 0) * 1048576
            rest = float(s.get("mbleft") or 0) * 1048576
            zeit = str(s.get("timeleft") or "")
            eta = None
            if re.match(r"^\d+:\d\d:\d\d$", zeit):
                h, m, sek = (int(x) for x in zeit.split(":"))
                eta = h * 3600 + m * 60 + sek
            jobs.append(_job(s.get("nzo_id"), s.get("filename"), str(s.get("status") or "").lower(), gesamt, rest,
                             tempo if s.get("status") == "Downloading" else 0, eta, s.get("cat"),
                             s.get("status") == "Paused"))
        h = self.api(mode="history", limit=30).get("history") or {}
        verlauf = [_eintrag(e.get("nzo_id"), e.get("name"), str(e.get("status") or "").lower(),
                            e.get("status") == "Completed", e.get("bytes"), _zeit(e.get("completed")), e.get("category"),
                            e.get("fail_message")) for e in h.get("slots") or []]
        frei = q.get("diskspace1")
        return {"version": q.get("version") or self.api(mode="version").get("version"), "tempo": tempo,
                "pausiert": bool(q.get("paused")), "frei": int(float(frei) * 1073741824) if frei else None,
                "limit": int(float(q.get("speedlimit_abs") or 0)), "jobs": jobs, "verlauf": verlauf}

    def aktion(self, was, id_=None, wert=None):
        if was == "pause_alle":
            return self.api(mode="pause")
        if was == "resume_alle":
            return self.api(mode="resume")
        if was == "limit":
            return self.api(mode="config", name="speedlimit", value="%dK" % (int(wert or 0) // 1024) if wert else "0")
        if was in ("pause", "resume", "loeschen"):
            return self.api(mode="queue", name={"loeschen": "delete"}.get(was, was), value=id_)
        if was == "wiederholen":
            return self.api(mode="retry", value=id_)
        if was == "verlauf_loeschen":
            return self.api(mode="history", name="delete", value=id_)
        raise DienstFehler("SABnzbd kann %s nicht" % was)

    def nzb_hinzufuegen(self, name, daten, kategorie=""):
        parameter = {"mode": "addfile", "output": "json", "apikey": self.werte.get("api_key", ""), "nzbname": name}
        if kategorie or self.werte.get("kategorie"):
            parameter["cat"] = kategorie or self.werte.get("kategorie")
        koerper, typ = _multipart({}, "name", name + ".nzb", daten)
        status, _, text = self.http(self.url + self.API_PFAD + "?" + urlencode(parameter), "POST", {"Content-Type": typ}, koerper, 60.0)
        d = _json(text, "SABnzbd")
        if status >= 400 or not d.get("status"):
            raise DienstFehler("SABnzbd hat die NZB nicht angenommen: %s" % (d.get("error") or "HTTP %d" % status))
        return [str(x) for x in d.get("nzo_ids") or []]


class NzbDav(Sabnzbd):
    """NzbDAV (und Abzweigungen wie nzbdavex, infinidysk): NZBs ohne Herunterladen als Dateien per WebDAV.

    SABnzbd-kompatible API (Warteschlange, Verlauf, NZB senden) plus Streaming wie bei AIOStreams: NZB per addurl in
    die Kategorie Movies bzw. TV, warten bis der Verlauf "completed" meldet, dann die groesste Videodatei unter
    <WebDAV>/content/<Kategorie>/<Job> mit Range ueber H0rSt abspielen. Nichts landet auf einer Platte.
    Werte: url, api_key (Settings -> SABnzbd), webdav_user/webdav_pass (Settings -> WebDAV)."""
    typ = "nzbdav"
    kann = ("pause", "resume", "loeschen", "wiederholen", "verlauf_loeschen", "nzb")
    API_PFAD = "/api"
    WEBDAV_PFAD = ""
    INHALT = "/content"
    WARTEN = 80
    VIDEO = (".mkv", ".mp4", ".avi", ".m4v", ".ts", ".mov", ".wmv", ".webm", ".m2ts", ".mpg")

    def _speicher(self):
        return {"id": self.typ, "name": self.name, "art": "webdav", "url": self.url + self.WEBDAV_PFAD,
                "benutzer": self.werte.get("webdav_user", ""), "passwort": self.werte.get("webdav_pass", ""),
                "zertifikat": "pruefen"}

    def _liste(self, pfad):
        from . import heimspeicher
        try:
            return heimspeicher.liste(self._speicher(), pfad)
        except heimspeicher.SpeicherFehler as fehler:
            if "nicht gefunden" in str(fehler):
                return None  # gibt es (noch) nicht
            if "Anmeldung abgelehnt" in str(fehler):
                raise DienstFehler("%s: WebDAV-Benutzer oder -Passwort falsch (Settings → WebDAV)" % self.typ_name)
            raise DienstFehler("%s (WebDAV): %s" % (self.typ_name, fehler))

    def _videodatei(self, pfad, tiefe=0):
        """Groesste Videodatei unter pfad (ohne Samples), bis zu drei Ordner tief."""
        eintraege = self._liste(pfad) or []
        beste = None
        for e in eintraege:
            name = e["name"].lower()
            if e.get("ordner"):
                if tiefe < 3:
                    kandidat = self._videodatei(e["pfad"], tiefe + 1)
                    if kandidat and (not beste or kandidat["groesse"] > beste["groesse"]):
                        beste = kandidat
            elif name.endswith(self.VIDEO) and "sample" not in name and (not beste or e["groesse"] > beste["groesse"]):
                beste = e
        return beste

    def warten(self, nzo_id, zeit=None, uhr=time.monotonic, schlafen=time.sleep):
        ende = uhr() + (self.WARTEN if zeit is None else zeit)
        while uhr() < ende:
            for e in (self.api(mode="history", nzo_ids=nzo_id, limit=20).get("history") or {}).get("slots") or []:
                if str(e.get("nzo_id")) != str(nzo_id):
                    continue
                zustand = str(e.get("status") or "").lower()
                if zustand == "completed":
                    return e
                if zustand == "failed":
                    raise DienstFehler("%s: NZB fehlgeschlagen – %s" % (self.typ_name, e.get("fail_message") or "unbekannt"))
            schlafen(2)
        raise DienstFehler("%s: NZB nach %d s noch nicht bereit" % (self.typ_name, self.WARTEN if zeit is None else zeit))

    def pruefen(self):
        """API (Version, Schluessel) und WebDAV (Zugang, Adresse) zusammen."""
        text = super().pruefen()
        if self._liste("/") is None:
            raise DienstFehler("%s: WebDAV-Adresse nicht gefunden (Settings → WebDAV)" % self.typ_name)
        return text + " · WebDAV erreichbar"

    def fertige(self, kategorie="Movies"):
        """Ordnernamen der Jobs, die schon eingebunden sind (Movies oder TV). Leer, wenn es die Kategorie noch nicht gibt."""
        return [e["name"] for e in (self._liste("%s/%s" % (self.INHALT, kategorie)) or []) if e.get("ordner")]

    def streamen(self, nzb_url, name, kategorie="Movies", wartezeit=None):
        """NZB einbinden (falls noch nicht da) -> (adresse, kopf, dateiname, groesse) der Videodatei.
        wartezeit: wie lange auf das Einbinden gewartet wird (Standard WARTEN, beim Auto-Weiter kuerzer)."""
        from . import heimspeicher
        from .usenet_stream import job_name
        job = job_name(name)
        ordner = "%s/%s/%s" % (self.INHALT, kategorie, job)
        datei = self._videodatei(ordner) if self._liste(ordner) is not None else None
        if not datei:
            antwort = self.api(mode="addurl", name=nzb_url, nzbname=job, cat=kategorie)
            if antwort.get("status") is False or not antwort.get("nzo_ids"):
                raise DienstFehler("%s hat die NZB nicht angenommen: %s" % (self.typ_name, antwort.get("error") or "keine nzo_id"))
            eintrag = self.warten(antwort["nzo_ids"][0], wartezeit)
            speicher = posixpath.basename(str(eintrag.get("storage") or "").rstrip("/")) or str(eintrag.get("name") or job)
            ordner = "%s/%s/%s" % (self.INHALT, eintrag.get("category") or kategorie, speicher)
            datei = self._videodatei(ordner)
        if not datei:
            raise DienstFehler("%s: keine Videodatei in %s" % (self.typ_name, ordner))
        s = self._speicher()
        return heimspeicher.adresse(s, datei["pfad"]), heimspeicher.kopf(s), datei["name"], datei["groesse"]


class AltMount(NzbDav):
    """AltMount: dieselbe Idee wie NzbDAV, API unter /sabnzbd/api, WebDAV unter /webdav, Inhalt unter /complete."""
    typ = "altmount"
    API_PFAD = "/sabnzbd/api"
    WEBDAV_PFAD = "/webdav"
    INHALT = "/complete"


