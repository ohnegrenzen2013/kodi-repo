"""qBittorrent und Transmission: Torrents hinzufuegen, loeschen und verwalten."""

from .dienste_downloads_grund import (
    Client,
    DienstFehler,
    _basic,
    _cookies,
    _umleitung,
    _job,
    _json,
    _multipart,
    _torrent_pruefen,
    base64,
    json,
    re,
    urlencode,
    urlsplit,
)

class QBittorrent(Client):
    typ = "qbittorrent"
    kann = ("pause_alle", "resume_alle", "pause", "resume", "loeschen", "limit", "torrent", "torrent_datei")
    STATUS = {"downloading": "lädt", "stalledDL": "wartet auf Quellen", "metaDL": "holt Metadaten",
              "forcedDL": "lädt (erzwungen)", "queuedDL": "wartet", "pausedDL": "pausiert", "stoppedDL": "pausiert",
              "checkingDL": "prüft", "uploading": "teilt", "stalledUP": "teilt", "queuedUP": "fertig",
              "pausedUP": "fertig", "stoppedUP": "fertig", "forcedUP": "teilt", "checkingUP": "prüft",
              "error": "Fehler", "missingFiles": "Dateien fehlen", "moving": "verschiebt"}

    def __init__(self, name, werte, holen=None):
        super().__init__(name, werte, holen)
        self._cookie = None

    def _anmelden(self):
        status, kopf, text = self.http(self.url + "/api/v2/auth/login", "POST",
                                       {"Content-Type": "application/x-www-form-urlencoded", "Referer": self.url},
                                       urlencode({"username": self.werte.get("user", ""),
                                                  "password": self.werte.get("pass", "")}))
        _umleitung(status, kopf, "qBittorrent")
        # Der Name ist nicht immer "SID" (z. B. QBT_SID_8080 hinter Proxys); Proxys setzen auch eigene Cookies davor
        keks = re.search(r"(?:^|[\s,;])([A-Za-z0-9_]*SID[A-Za-z0-9_]*)=([^;,\s]+)", _cookies(kopf))
        if status >= 400 or text.strip() == "Fails." or not keks:
            raise DienstFehler("qBittorrent lehnt die Anmeldung ab" if status < 500 else "qBittorrent: HTTP %d" % status)
        self._cookie = "%s=%s" % keks.groups()

    def api(self, pfad, daten=None, json_antwort=True, kopf=None):
        for versuch in (1, 2):
            if not self._cookie:
                self._anmelden()
            header = {"Cookie": self._cookie, "Referer": self.url}
            header.update(kopf or {})
            if daten is not None and "Content-Type" not in header:
                header["Content-Type"] = "application/x-www-form-urlencoded"
            status, antwortkopf, text = self.http(self.url + "/api/v2/" + pfad, "POST" if daten is not None else "GET", header,
                                        urlencode(daten) if isinstance(daten, dict) else daten)
            _umleitung(status, antwortkopf, "qBittorrent")
            if status == 403 and versuch == 1:
                self._cookie = None  # Sitzung abgelaufen
                continue
            if status >= 400:
                raise DienstFehler("qBittorrent: HTTP %d bei %s" % (status, pfad.split("?")[0]))
            return _json(text, "qBittorrent") if json_antwort else text

    def zustand(self):
        info = self.api("transfer/info")
        jobs = [_job(t.get("hash"), t.get("name"), self.STATUS.get(t.get("state"), t.get("state")), t.get("size"),
                     t.get("amount_left"), t.get("dlspeed"), t.get("eta") if t.get("eta", 8640000) < 8640000 else None,
                     t.get("category"), str(t.get("state", "")).startswith(("paused", "stopped")))
                for t in self.api("torrents/info?sort=added_on&reverse=true") or []]
        return {"version": self.api("app/version", json_antwort=False), "tempo": int(info.get("dl_info_speed") or 0),
                "pausiert": False, "frei": None, "limit": int(info.get("dl_rate_limit") or 0), "jobs": jobs, "verlauf": []}

    def _pause(self, hashes, an):
        neu, alt = ("torrents/stop", "torrents/pause") if an else ("torrents/start", "torrents/resume")
        try:
            return self.api(neu, {"hashes": hashes}, json_antwort=False)  # qBittorrent 5
        except DienstFehler:
            return self.api(alt, {"hashes": hashes}, json_antwort=False)  # qBittorrent 4

    def aktion(self, was, id_=None, wert=None):
        if was in ("pause_alle", "resume_alle"):
            return self._pause("all", was == "pause_alle")
        if was in ("pause", "resume"):
            return self._pause(id_, was == "pause")
        if was == "loeschen":
            return self.api("torrents/delete", {"hashes": id_, "deleteFiles": "false"}, json_antwort=False)
        if was == "limit":
            return self.api("transfer/setDownloadLimit", {"limit": int(wert or 0)}, json_antwort=False)
        raise DienstFehler("qBittorrent kann %s nicht" % was)

    def torrent_hinzufuegen(self, magnet, kategorie=""):
        felder = {"urls": magnet}
        if kategorie or self.werte.get("kategorie"):
            felder["category"] = kategorie or self.werte.get("kategorie")
        koerper, typ = _multipart(felder, None, "", b"")
        antwort = self.api("torrents/add", koerper, json_antwort=False, kopf={"Content-Type": typ})
        if antwort.strip() == "Fails.":
            raise DienstFehler("qBittorrent hat den Torrent nicht angenommen")
        return []

    def torrent_datei_hinzufuegen(self, name, inhalt, kategorie=""):
        felder = {}
        if kategorie or self.werte.get("kategorie"):
            felder["category"] = kategorie or self.werte.get("kategorie")
        koerper, typ = _multipart(felder, "torrents", (name or "datei.torrent").replace('"', ""), _torrent_pruefen(inhalt),
                                  "application/x-bittorrent")
        antwort = self.api("torrents/add", koerper, json_antwort=False, kopf={"Content-Type": typ})
        if antwort.strip() == "Fails.":
            raise DienstFehler("qBittorrent hat die Torrent-Datei nicht angenommen (schon vorhanden oder ungültig)")
        return []


class Transmission(Client):
    typ = "transmission"
    ENDUNGEN = (r"/transmission/(?:web|rpc)(?:/index\.html)?", r"/transmission")
    kann = ("pause_alle", "resume_alle", "pause", "resume", "loeschen", "limit", "torrent", "torrent_datei")
    STATUS = {0: "pausiert", 1: "wartet auf Prüfung", 2: "prüft", 3: "wartet", 4: "lädt", 5: "wartet aufs Teilen", 6: "teilt"}

    def __init__(self, name, werte, holen=None):
        super().__init__(name, werte, holen)
        self._sitzung = ""
        pfad = urlsplit(self.url).path
        # eigener rpc-url (".../rpc") bleibt, sonst der Standardpfad hinter der Basis
        self.rpc_url = self.url if pfad.endswith("/rpc") else self.url + "/transmission/rpc"

    def rpc(self, methode, **argumente):
        for _ in range(2):
            kopf = {"Content-Type": "application/json", "X-Transmission-Session-Id": self._sitzung}
            if self.werte.get("user") or self.werte.get("pass"):
                kopf["Authorization"] = _basic(self.werte.get("user"), self.werte.get("pass"))
            status, header, text = self.http(self.rpc_url, "POST", kopf,
                                             json.dumps({"method": methode, "arguments": argumente}))
            if status == 409:
                self._sitzung = header.get("X-Transmission-Session-Id", "") if header else ""
                continue
            _umleitung(status, header, "Transmission")
            if status == 401:
                raise DienstFehler("Transmission lehnt Benutzer/Passwort ab")
            d = _json(text, "Transmission")
            if status >= 400 or d.get("result") != "success":
                raise DienstFehler("Transmission: %s" % (d.get("result") or "HTTP %d" % status))
            return d.get("arguments") or {}
        raise DienstFehler("Transmission: keine Sitzung")

    def zustand(self):
        felder = ["id", "name", "status", "totalSize", "leftUntilDone", "rateDownload", "eta", "errorString", "labels"]
        jobs = [_job(t["id"], t.get("name"), self.STATUS.get(t.get("status"), t.get("status")), t.get("totalSize"),
                     t.get("leftUntilDone"), t.get("rateDownload"), t.get("eta") if (t.get("eta") or -1) >= 0 else None,
                     ",".join(t.get("labels") or []), t.get("status") == 0, t.get("errorString"))
                for t in self.rpc("torrent-get", fields=felder).get("torrents") or []]
        sitzung = self.rpc("session-get")
        statistik = self.rpc("session-stats")
        # Was gilt, zeigt der Schalter: ein gespeicherter, aber abgeschalteter Wert ist kein Limit; im Schildkroeten-Modus gilt die alternative Grenze
        if sitzung.get("alt-speed-enabled"):
            limit = int(sitzung.get("alt-speed-down") or 0) * 1024
        else:
            limit = int(sitzung.get("speed-limit-down") or 0) * 1024 if sitzung.get("speed-limit-down-enabled") else 0
        return {"version": sitzung.get("version", ""), "tempo": int(statistik.get("downloadSpeed") or 0),
                "pausiert": False, "frei": sitzung.get("download-dir-free-space"), "limit": limit, "jobs": jobs,
                "verlauf": []}

    def aktion(self, was, id_=None, wert=None):
        if was in ("pause_alle", "resume_alle"):
            return self.rpc("torrent-stop" if was == "pause_alle" else "torrent-start")
        if was in ("pause", "resume"):
            return self.rpc("torrent-stop" if was == "pause" else "torrent-start", ids=[int(id_)])
        if was == "loeschen":
            return self.rpc("torrent-remove", ids=[int(id_)], **{"delete-local-data": False})
        if was == "limit":
            if not int(wert or 0):  # "keine Begrenzung": nur ausschalten, der gespeicherte Wert bleibt fuer spaeter erhalten
                return self.rpc("session-set", **{"speed-limit-down-enabled": False})
            return self.rpc("session-set", **{"speed-limit-down": max(1, int(wert) // 1024), "speed-limit-down-enabled": True})
        raise DienstFehler("Transmission kann %s nicht" % was)

    def torrent_hinzufuegen(self, magnet, kategorie=""):
        a = self.rpc("torrent-add", filename=magnet)
        neu = a.get("torrent-added") or a.get("torrent-duplicate") or {}
        return [str(neu.get("id", ""))]

    def torrent_datei_hinzufuegen(self, name, inhalt, kategorie=""):
        a = self.rpc("torrent-add", metainfo=base64.b64encode(_torrent_pruefen(inhalt)).decode("ascii"))
        neu = a.get("torrent-added") or a.get("torrent-duplicate") or {}
        return [str(neu.get("id", ""))]
