"""Einstellungen der Downloader: Ports, Ordner, Tempo, Warteschlange, Verbindungen, Verschluesselung und Netz –
gelesen und geschrieben ueber die API des jeweiligen Programms (qBittorrent, Transmission, Deluge, NZBGet, SABnzbd).

lesen(client) -> {"gruppen": [{"name", "felder": [{key, titel, art, wert, werte?, einheit?, hinweis?}]}], "hinweis"}
schreiben(client, {key: wert}) prueft gegen das Schema und schickt nur Geaendertes.

Arten: text, zahl (mit min/max), schalter, wahl (werte: [[wert, name]]). "faktor" rechnet die Anzeige (z. B. KB/s) in
die Einheit des Programms um (z. B. Byte/s bei qBittorrent).
"""

import json

from .dienste_grund import DienstFehler

_NETZ, _ORDNER, _TEMPO, _SCHLANGE, _VERB, _SICHER, _NZB = ("Netz & Ports", "Ordner", "Tempo", "Warteschlange", "Verbindungen",
                                                          "Sicherheit & Netzwerke", "Usenet & Nachbearbeitung")


def _f(key, titel, art, gruppe, **mehr):
    return dict(key=key, titel=titel, art=art, gruppe=gruppe, **mehr)


QBITTORRENT = [
    _f("listen_port", "Port für eingehende Verbindungen", "zahl", _NETZ, min=1, max=65535),
    _f("upnp", "Port per UPnP / NAT-PMP öffnen", "schalter", _NETZ),
    _f("random_port", "Bei jedem Start zufälliger Port", "schalter", _NETZ),
    _f("save_path", "Download-Ordner", "text", _ORDNER),
    _f("temp_path_enabled", "Unfertige Dateien in eigenem Ordner", "schalter", _ORDNER),
    _f("temp_path", "Ordner für Unfertiges", "text", _ORDNER),
    _f("dl_limit", "Download-Grenze", "zahl", _TEMPO, min=0, max=10 ** 7, einheit="KB/s (0 = ohne)", faktor=1024),
    _f("up_limit", "Upload-Grenze", "zahl", _TEMPO, min=0, max=10 ** 7, einheit="KB/s (0 = ohne)", faktor=1024),
    _f("queueing_enabled", "Warteschlange verwenden", "schalter", _SCHLANGE),
    _f("max_active_downloads", "Aktive Downloads", "zahl", _SCHLANGE, min=-1, max=1000),
    _f("max_active_uploads", "Aktive Uploads", "zahl", _SCHLANGE, min=-1, max=1000),
    _f("max_active_torrents", "Aktive Torrents insgesamt", "zahl", _SCHLANGE, min=-1, max=1000),
    _f("max_connec", "Verbindungen insgesamt", "zahl", _VERB, min=-1, max=100000),
    _f("max_connec_per_torrent", "Verbindungen je Torrent", "zahl", _VERB, min=-1, max=10000),
    _f("max_uploads", "Upload-Plätze insgesamt", "zahl", _VERB, min=-1, max=10000),
    _f("encryption", "Verschlüsselung", "wahl", _SICHER, werte=[[0, "Bevorzugen"], [1, "Erzwingen"], [2, "Aus"]]),
    _f("anonymous_mode", "Anonymer Modus", "schalter", _SICHER),
    _f("dht", "DHT (ohne Tracker)", "schalter", _SICHER), _f("pex", "Peer-Austausch (PeX)", "schalter", _SICHER),
    _f("lsd", "Peers im Heimnetz finden (LSD)", "schalter", _SICHER),
    _f("ip_filter_enabled", "IP-Filter", "schalter", _SICHER),
    _f("ip_filter_path", "IP-Filter-Datei (z. B. die ipfilter.dat von H0rSt)", "text", _SICHER),
]
TRANSMISSION = [
    _f("peer-port", "Port für eingehende Verbindungen", "zahl", _NETZ, min=1, max=65535),
    _f("port-forwarding-enabled", "Port per UPnP / NAT-PMP öffnen", "schalter", _NETZ),
    _f("peer-port-random-on-start", "Bei jedem Start zufälliger Port", "schalter", _NETZ),
    _f("download-dir", "Download-Ordner", "text", _ORDNER),
    _f("incomplete-dir-enabled", "Unfertige Dateien in eigenem Ordner", "schalter", _ORDNER),
    _f("incomplete-dir", "Ordner für Unfertiges", "text", _ORDNER),
    _f("speed-limit-down-enabled", "Download begrenzen", "schalter", _TEMPO),
    _f("speed-limit-down", "Download-Grenze", "zahl", _TEMPO, min=0, max=10 ** 7, einheit="KB/s"),
    _f("speed-limit-up-enabled", "Upload begrenzen", "schalter", _TEMPO),
    _f("speed-limit-up", "Upload-Grenze", "zahl", _TEMPO, min=0, max=10 ** 7, einheit="KB/s"),
    _f("download-queue-enabled", "Warteschlange verwenden", "schalter", _SCHLANGE),
    _f("download-queue-size", "Aktive Downloads", "zahl", _SCHLANGE, min=0, max=1000),
    _f("peer-limit-global", "Verbindungen insgesamt", "zahl", _VERB, min=0, max=100000),
    _f("peer-limit-per-torrent", "Verbindungen je Torrent", "zahl", _VERB, min=0, max=10000),
    _f("encryption", "Verschlüsselung", "wahl", _SICHER, werte=[["preferred", "Bevorzugen"], ["required", "Erzwingen"], ["tolerated", "Erlauben"]]),
    _f("dht-enabled", "DHT (ohne Tracker)", "schalter", _SICHER), _f("pex-enabled", "Peer-Austausch (PeX)", "schalter", _SICHER),
    _f("lpd-enabled", "Peers im Heimnetz finden (LPD)", "schalter", _SICHER), _f("utp-enabled", "µTP", "schalter", _SICHER),
    _f("blocklist-enabled", "Sperrliste (IP-Filter)", "schalter", _SICHER),
    _f("blocklist-url", "Adresse der Sperrliste (z. B. …/api/ipfilter/ipfilter.dat von H0rSt)", "text", _SICHER),
]
DELUGE = [
    _f("listen_ports.0", "Port von", "zahl", _NETZ, min=1, max=65535), _f("listen_ports.1", "Port bis", "zahl", _NETZ, min=1, max=65535),
    _f("random_port", "Zufälliger Port", "schalter", _NETZ), _f("upnp", "UPnP", "schalter", _NETZ), _f("natpmp", "NAT-PMP", "schalter", _NETZ),
    _f("download_location", "Download-Ordner", "text", _ORDNER),
    _f("max_download_speed", "Download-Grenze", "zahl", _TEMPO, min=-1, max=10 ** 7, einheit="KiB/s (-1 = ohne)"),
    _f("max_upload_speed", "Upload-Grenze", "zahl", _TEMPO, min=-1, max=10 ** 7, einheit="KiB/s (-1 = ohne)"),
    _f("max_active_downloading", "Aktive Downloads", "zahl", _SCHLANGE, min=-1, max=1000),
    _f("max_active_seeding", "Aktives Teilen", "zahl", _SCHLANGE, min=-1, max=1000),
    _f("max_active_limit", "Aktive Torrents insgesamt", "zahl", _SCHLANGE, min=-1, max=1000),
    _f("max_connections_global", "Verbindungen insgesamt", "zahl", _VERB, min=-1, max=100000),
    _f("max_upload_slots_global", "Upload-Plätze", "zahl", _VERB, min=-1, max=10000),
    _f("enc_in_policy", "Verschlüsselung eingehend", "wahl", _SICHER, werte=[[0, "Erzwingen"], [1, "Erlauben"], [2, "Aus"]]),
    _f("enc_out_policy", "Verschlüsselung ausgehend", "wahl", _SICHER, werte=[[0, "Erzwingen"], [1, "Erlauben"], [2, "Aus"]]),
    _f("dht", "DHT", "schalter", _SICHER), _f("lsd", "LSD", "schalter", _SICHER), _f("utpex", "Peer-Austausch", "schalter", _SICHER),
]
_JANEIN = [["yes", "Ja"], ["no", "Nein"]]
NZBGET = [
    _f("ControlPort", "Port der Weboberfläche", "zahl", _NETZ, min=1, max=65535, hinweis="Wirkt nach einem Neustart von NZBGet."),
    _f("MainDir", "Hauptordner", "text", _ORDNER), _f("DestDir", "Ziel für Fertiges", "text", _ORDNER),
    _f("InterDir", "Ordner für Unfertiges", "text", _ORDNER),
    _f("DownloadRate", "Download-Grenze", "zahl", _TEMPO, min=0, max=10 ** 7, einheit="KB/s (0 = ohne)"),
    _f("ArticleCache", "Artikel-Zwischenspeicher", "zahl", _TEMPO, min=0, max=100000, einheit="MB"),
    _f("Server1.Host", "Usenet-Server", "text", _VERB), _f("Server1.Port", "Server-Port", "zahl", _VERB, min=1, max=65535),
    _f("Server1.Connections", "Verbindungen zum Server", "zahl", _VERB, min=1, max=200),
    _f("Server1.Encryption", "Verschlüsselt (SSL)", "wahl", _VERB, werte=_JANEIN),
    _f("ParCheck", "PAR-Prüfung", "wahl", _NZB, werte=[["auto", "Automatisch"], ["always", "Immer"], ["force", "Erzwingen"], ["manual", "Von Hand"]]),
    _f("ParRepair", "Reparieren", "wahl", _NZB, werte=_JANEIN), _f("Unpack", "Entpacken", "wahl", _NZB, werte=_JANEIN),
    _f("UnpackCleanupDisk", "Archive nach dem Entpacken löschen", "wahl", _NZB, werte=_JANEIN),
    _f("DupeCheck", "Duplikate erkennen", "wahl", _NZB, werte=_JANEIN),
    _f("HealthCheck", "Bei zu vielen fehlenden Artikeln", "wahl", _NZB, werte=[["park", "Parken"], ["delete", "Löschen"], ["pause", "Pausieren"], ["none", "Nichts"]]),
]
SABNZBD = [
    _f("misc.port", "Port der Weboberfläche", "zahl", _NETZ, min=1, max=65535, hinweis="Wirkt nach einem Neustart von SABnzbd."),
    _f("misc.download_dir", "Ordner für Unfertiges", "text", _ORDNER), _f("misc.complete_dir", "Ziel für Fertiges", "text", _ORDNER),
    _f("misc.bandwidth_max", "Höchste Leitung (z. B. 50M)", "text", _TEMPO),
    _f("misc.bandwidth_perc", "Davon nutzen", "zahl", _TEMPO, min=0, max=100, einheit="%"),
    _f("misc.cache_limit", "Artikel-Zwischenspeicher (z. B. 1G)", "text", _TEMPO),
    _f("misc.pre_check", "Vorher prüfen, ob alles da ist", "schalter", _NZB), _f("misc.direct_unpack", "Direkt entpacken", "schalter", _NZB),
    _f("misc.enable_all_par", "Alle PAR2 laden", "schalter", _NZB), _f("misc.ignore_samples", "Samples ignorieren", "schalter", _NZB),
]
SCHEMA = {"qbittorrent": QBITTORRENT, "transmission": TRANSMISSION, "deluge": DELUGE, "nzbget": NZBGET, "sabnzbd": SABNZBD}
HINWEISE = {"downloadmaster": "Die Einstellungen des ASUS Download Master stehen im Router-Menü (Download Master → Einstellungen).",
            "rustnzb": "rustnzb stellst du in seiner eigenen Oberfläche ein."}


def _hole(d, key):
    for teil in key.split("."):
        if isinstance(d, list) and teil.isdigit() and int(teil) < len(d):
            d = d[int(teil)]
        elif isinstance(d, dict):
            d = d.get(teil)
        else:
            return None
    return d


def _rohwerte(c):
    """Aktuelle Werte im Format des Programms (flach je key)."""
    typ = c.typ
    if typ == "qbittorrent":
        return c.api("app/preferences")
    if typ == "transmission":
        return c.rpc("session-get")
    if typ == "deluge":
        return c.rpc("core.get_config")
    if typ == "nzbget":
        return {o.get("Name"): o.get("Value") for o in c.rpc("config") or []}
    if typ == "sabnzbd":
        return (c.api(mode="get_config").get("config") or {})
    raise DienstFehler("%s hat hier keine Einstellungen" % c.typ_name)


def _anzeige(feld, roh):
    w = roh.get(feld["key"]) if feld["key"] in roh else _hole(roh, feld["key"])
    if w is None:
        return None
    if feld["art"] == "schalter":
        return w in (True, 1, "1", "yes", "true")
    if feld["art"] == "zahl":
        try:
            w = int(float(w))
        except (TypeError, ValueError):
            return None
        return w // feld["faktor"] if feld.get("faktor") and w > 0 else w
    if feld["art"] == "wahl":
        return w
    return str(w)


def lesen(c):
    if c.typ not in SCHEMA:
        return {"gruppen": [], "hinweis": HINWEISE.get(c.typ, "Für %s gibt es hier keine Einstellungen." % c.typ_name)}
    roh = _rohwerte(c)
    gruppen = {}
    for feld in SCHEMA[c.typ]:
        wert = _anzeige(feld, roh)
        if wert is None:
            continue  # gibt es in dieser Version nicht
        eintrag = {k: v for k, v in feld.items() if k not in ("gruppe", "faktor")}
        eintrag["wert"] = wert
        gruppen.setdefault(feld["gruppe"], []).append(eintrag)
    return {"gruppen": [{"name": n, "felder": f} for n, f in gruppen.items()], "hinweis": ""}


def _pruefen(feld, wert):
    if feld["art"] == "schalter":
        if not isinstance(wert, bool):
            raise DienstFehler("%s: an oder aus" % feld["titel"])
        return wert
    if feld["art"] == "zahl":
        try:
            wert = int(wert)
        except (TypeError, ValueError):
            raise DienstFehler("%s: Zahl erwartet" % feld["titel"])
        if not feld["min"] <= wert <= feld["max"]:
            raise DienstFehler("%s: %d bis %d" % (feld["titel"], feld["min"], feld["max"]))
        return wert * feld["faktor"] if feld.get("faktor") else wert
    if feld["art"] == "wahl":
        erlaubt = {str(w): w for w, _ in feld["werte"]}
        if str(wert) not in erlaubt:
            raise DienstFehler("%s: unbekannter Wert" % feld["titel"])
        return erlaubt[str(wert)]
    wert = str(wert if wert is not None else "").strip()
    if len(wert) > 500 or any(z in wert for z in "\r\n\x00"):
        raise DienstFehler("%s: ungültiger Text" % feld["titel"])
    return wert


def schreiben(c, neu):
    if c.typ not in SCHEMA:
        raise DienstFehler(HINWEISE.get(c.typ, "%s hat hier keine Einstellungen" % c.typ_name))
    if not isinstance(neu, dict) or not neu:
        raise DienstFehler("Änderungen fehlen")
    felder = {f["key"]: f for f in SCHEMA[c.typ]}
    werte = {}
    for key, wert in neu.items():
        if key not in felder:
            raise DienstFehler("Unbekannte Einstellung: %s" % key)
        werte[key] = _pruefen(felder[key], wert)
    typ = c.typ
    if typ == "qbittorrent":
        c.api("app/setPreferences", {"json": json.dumps(werte)}, json_antwort=False)
    elif typ == "transmission":
        c.rpc("session-set", **werte)
    elif typ == "deluge":
        konfig = {}
        for key, wert in werte.items():
            if key.startswith("listen_ports."):
                ports = konfig.get("listen_ports") or list(_rohwerte(c).get("listen_ports") or [6881, 6891])
                ports[int(key[-1])] = wert
                konfig["listen_ports"] = ports
            else:
                konfig[key] = wert
        c.rpc("core.set_config", konfig)
    elif typ == "nzbget":
        alle = c.rpc("config") or []
        for o in alle:
            if o.get("Name") in werte:
                w = werte.pop(o["Name"])
                o["Value"] = ("yes" if w else "no") if isinstance(w, bool) else str(w)
        alle += [{"Name": k, "Value": str(v)} for k, v in werte.items()]
        if not c.rpc("saveconfig", alle):
            raise DienstFehler("NZBGet hat die Einstellungen nicht gespeichert")
        c.rpc("reload")
    elif typ == "sabnzbd":
        for key, wert in werte.items():
            bereich, _, schluessel = key.partition(".")
            c.api(mode="set_config", section=bereich, keyword=schluessel, value=(1 if wert else 0) if isinstance(wert, bool) else wert)
    return lesen(c)
