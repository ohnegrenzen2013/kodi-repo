"""Grundbausteine der Dienste-Zentrale: Konstanten, HTTP-Helfer und die Client-Basis.
Alles hier wird samt Importen wieder exportiert (rezeptserver.dienste.*), damit die
Aufteilung nach aussen unsichtbar bleibt."""


import base64
import json
import re
import secrets
import time
import urllib.error
import urllib.request
from datetime import datetime, timedelta, timezone
from urllib.parse import urlencode, urlsplit

from .netz import _OEFFNER, USER_AGENT, NetzFehler

DOWNLOAD_TYPEN = ("rustnzb", "nzbget", "sabnzbd", "nzbdav", "altmount", "qbittorrent", "transmission", "deluge", "downloadmaster")
NZB_CLIENTS = ("rustnzb", "nzbget", "sabnzbd", "nzbdav", "altmount", "downloadmaster")
USENET_STREAMER = ("nzbdav", "altmount")  # NZBs ohne Herunterladen per WebDAV streamen
TORRENT_CLIENTS = ("qbittorrent", "transmission", "deluge", "downloadmaster")
ED2K_CLIENTS = ("downloadmaster",)
ARR_TYPEN = ("sonarr", "radarr", "lidarr")
ALLE_TYPEN = DOWNLOAD_TYPEN + ARR_TYPEN + ("seerr", "prowlarr", "tautulli", "bazarr", "pihole")
STANDARD_PORTS = {"downloadmaster": 8081, "nzbget": 6789, "sabnzbd": 8080, "nzbdav": 3000, "altmount": 8080, "qbittorrent": 8080, "transmission": 9091, "deluge": 8112,
                  "sonarr": 8989, "radarr": 7878, "lidarr": 8686, "seerr": 5055, "prowlarr": 9696,
                  "tautulli": 8181, "bazarr": 6767, "kodi": 8080, "pihole": 80}
MAX_ANTWORT = 8 * 1024 * 1024


class DienstFehler(Exception):
    pass


def _basis(url, endungen=()):
    """Basisadresse eines Dienstes: ohne Leerraum, Anfuehrungszeichen, Anfrage, Anker und nachgestellte Schraegstriche.
    endungen: Muster (Regex) fuer Pfadenden, die Nutzer gern mit eintragen (z. B. /api/v3), aber nicht zur Basis gehoeren."""
    url = str(url or "").strip().strip("\"'").strip()
    url = url.split("#", 1)[0].split("?", 1)[0].rstrip("/")
    if url and "://" not in url:
        url = "http://" + url
    teile = urlsplit(url)
    if teile.scheme not in ("http", "https") or not teile.hostname:
        raise DienstFehler("Adresse muss http://host:port sein")
    pfad = teile.path
    for _ in range(4):
        for muster in endungen:
            neu = re.sub(r"(?:%s)/*$" % muster, "", pfad)
            if neu != pfad:
                pfad = neu
                break
        else:
            break
    return url[:len(url) - len(teile.path)] + pfad.rstrip("/") if teile.path else url


def _cookies(header):
    """Alle Set-Cookie-Zeilen einer Antwort als ein Text (Reverse-Proxys setzen oft eigene Cookies davor)."""
    if not header:
        return ""
    zeilen = header.get_all("Set-Cookie") if hasattr(header, "get_all") else None
    return "\n".join(zeilen) if zeilen else (header.get("Set-Cookie") or "")


def _umleitung(status, header, dienst, url=""):
    """Weiterleitungen folgt H0rSt nicht; statt "antwortet nicht mit JSON" sagen, wohin der Dienst verweist."""
    if status in (301, 302, 303, 307, 308):
        ziel = (header.get("Location") if header else "") or ""
        basis = ziel.split("/api/", 1)[0].split("/transmission/", 1)[0].split("/json", 1)[0].rstrip("/") if ziel else ""
        raise DienstFehler("%s leitet auf %s weiter. Bitte genau diese Adresse (mit https:// und richtigem Pfad) eintragen"
                           % (dienst, basis or ziel or "eine andere Adresse"))


def http(url, methode="GET", kopf=None, daten=None, zeitgrenze=20.0):
    """(status, header, text); HTTP-Fehler kommen als status zurueck, Weiterleitungen werden nicht verfolgt."""
    header = {"User-Agent": USER_AGENT}
    header.update(kopf or {})
    koerper = daten.encode("utf-8") if isinstance(daten, str) else daten
    try:
        with _OEFFNER.open(urllib.request.Request(url, data=koerper, headers=header, method=methode),
                           timeout=zeitgrenze) as a:
            return a.status, a.headers, a.read(MAX_ANTWORT).decode("utf-8", "replace")
    except urllib.error.HTTPError as fehler:
        try:
            return fehler.code, fehler.headers, fehler.read(64 * 1024).decode("utf-8", "replace")
        finally:
            fehler.close()
    except (urllib.error.URLError, OSError) as fehler:
        raise NetzFehler("%s nicht erreichbar (%s)" % (urlsplit(url).netloc, getattr(fehler, "reason", fehler)))


def _json(text, dienst):
    try:
        return json.loads(text) if text.strip() else {}
    except ValueError:
        raise DienstFehler("%s antwortet nicht mit JSON – Adresse richtig?" % dienst)


def _multipart(felder, datei_feld, dateiname, inhalt, typ="application/x-nzb"):
    grenze = "h0rst" + secrets.token_hex(12)
    teile = []
    for name, wert in felder.items():
        teile.append(('--%s\r\nContent-Disposition: form-data; name="%s"\r\n\r\n%s\r\n'
                      % (grenze, name, wert)).encode("utf-8"))
    if datei_feld:
        teile.append(('--%s\r\nContent-Disposition: form-data; name="%s"; filename="%s"\r\nContent-Type: %s\r\n\r\n'
                      % (grenze, datei_feld, dateiname, typ)).encode("utf-8") + inhalt + b"\r\n")
    teile.append(("--%s--\r\n" % grenze).encode("utf-8"))
    return b"".join(teile), "multipart/form-data; boundary=" + grenze


def _basic(benutzer, passwort):
    return "Basic " + base64.b64encode(("%s:%s" % (benutzer or "", passwort or "")).encode("utf-8")).decode("ascii")


def _prozent(geladen, gesamt):
    return round(100.0 * geladen / gesamt, 1) if gesamt else 0.0


def _job(id_, name, status, gesamt, rest, tempo=0, eta=None, kategorie="", pausiert=False, fehler=""):
    gesamt, rest = int(gesamt or 0), int(rest or 0)
    if eta is None and tempo:
        eta = int(rest / tempo)
    return {"id": str(id_), "name": str(name or ""), "status": str(status or ""), "gesamt": gesamt, "rest": rest,
            "prozent": _prozent(gesamt - rest, gesamt), "tempo": int(tempo or 0),
            "eta": int(eta) if eta not in (None, "") and int(eta) >= 0 else None, "kategorie": str(kategorie or ""),
            "pausiert": bool(pausiert), "fehler": str(fehler or "")}


def _eintrag(id_, name, status, ok, gesamt=0, zeit="", kategorie="", fehler=""):
    return {"id": str(id_), "name": str(name or ""), "status": str(status or ""), "ok": bool(ok),
            "gesamt": int(gesamt or 0), "zeit": str(zeit or "")[:16].replace("T", " "), "kategorie": str(kategorie or ""),
            "fehler": str(fehler or "")}


def _zeit(unix):
    try:
        return time.strftime("%Y-%m-%d %H:%M", time.localtime(int(unix)))
    except (TypeError, ValueError, OverflowError):
        return ""


# --- Download-Clients -----------------------------------------------------------------------------

class Client:
    typ = ""
    kann = ()
    ENDUNGEN = ()  # Pfadenden (Regex), die bei der Adresse abgeschnitten werden, siehe _basis

    def __init__(self, name, werte, holen=None):
        self.name = name
        self.werte = werte
        self.url = _basis(werte.get("url") or "http://127.0.0.1:%d" % STANDARD_PORTS.get(self.typ, 80), self.ENDUNGEN)
        self.http = holen or http

    def pruefen(self):
        z = self.zustand()
        return "%s %s" % (self.typ_name, z.get("version") or "erreichbar")

    @property
    def typ_name(self):
        return {"nzbget": "NZBGet", "sabnzbd": "SABnzbd", "nzbdav": "NzbDAV", "altmount": "AltMount", "rustnzb": "rustnzb", "qbittorrent": "qBittorrent",
                "transmission": "Transmission", "deluge": "Deluge",
                "downloadmaster": "ASUS Download Master"}.get(self.typ, self.typ)


def _bytes(eintrag, feld):
    """NZBGet liefert Groessen als Lo/Hi-Paar (32 Bit) und gerundet in MB."""
    if eintrag.get(feld + "Lo") is not None:
        return int(eintrag.get(feld + "Lo") or 0) + (int(eintrag.get(feld + "Hi") or 0) << 32)
    return int(eintrag.get(feld + "MB") or 0) * 1048576


def aus_antwort(holen):
    """netz.antwort_holen-artige Funktion (status, text) -> http()-artige (status, header, text)."""
    def roh(url, methode="GET", kopf=None, daten=None, zeitgrenze=20.0):
        status, text = holen(url, methode, kopf, daten, zeitgrenze)
        return status, {}, text
    return roh


def _als_antwort(holen):
    """http()-artige Funktion (status, header, text) -> netz.antwort_holen-artige (status, text)."""
    def antwort(url, methode="GET", header=None, daten=None, zeitgrenze=20.0):
        status, _, text = holen(url, methode, header, daten, zeitgrenze)
        return status, text
    return antwort


_DM_EINHEIT = re.compile(r"([\d.,]+)\s*([KMGT]?)i?B", re.I)
