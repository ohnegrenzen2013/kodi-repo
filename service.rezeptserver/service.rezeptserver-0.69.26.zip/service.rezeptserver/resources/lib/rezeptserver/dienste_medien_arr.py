"""Arr-Clients (Sonarr v3, Radarr v3, Lidarr v1): Serien, Filme, Alben, Fehlendes und Kalender."""

from .dienste_medien_grund import (
    Client,
    DienstFehler,
    _json,
    _umleitung,
    _prozent,
    datetime,
    json,
    re,
    timedelta,
    timezone,
    urlencode,
)

from .dienste_medien_verlauf import laufwerk, releases_aufbereiten, verlauf_aufbereiten


class Arr(Client):
    """Gemeinsames fuer Sonarr (v3), Radarr (v3) und Lidarr (v1)."""
    version = "v3"
    ENDUNGEN = (r"/api(?:/v\d+)?", r"/index\.html")

    def api(self, pfad, daten=None, methode=None, zeit=None):
        kopf = {"X-Api-Key": self.werte.get("api_key", ""), "Accept": "application/json"}
        if daten is not None:
            kopf["Content-Type"] = "application/json"
        status, header, text = self.http("%s/api/%s/%s" % (self.url, self.version, pfad),
                                         methode or ("POST" if daten is not None else "GET"), kopf,
                                         json.dumps(daten) if daten is not None else None, **({"zeitgrenze": zeit} if zeit else {}))
        _umleitung(status, header, self.typ_name)
        if status == 401:
            raise DienstFehler("%s lehnt den API-Schlüssel ab" % self.typ_name)
        d = _json(text, self.typ_name)
        if status >= 400:
            fehler = d[0].get("errorMessage") if isinstance(d, list) and d and isinstance(d[0], dict) else \
                (d.get("message") if isinstance(d, dict) else "")
            raise DienstFehler("%s: %s" % (self.typ_name, fehler or "HTTP %d" % status))
        return d

    @property
    def typ_name(self):
        return self.typ.capitalize()

    def pruefen(self):
        s = self.api("system/status")
        return "%s %s" % (self.typ_name, s.get("version", ""))

    @staticmethod
    def _zeitraum(tage):
        jetzt = datetime.now(timezone.utc)
        return {"start": (jetzt - timedelta(days=1)).strftime("%Y-%m-%dT00:00:00Z"),
                "end": (jetzt + timedelta(days=tage)).strftime("%Y-%m-%dT23:59:59Z")}

    def warteschlange(self):
        d = self.api("queue?" + urlencode(dict(pageSize=50, **self._mit())))
        ergebnis = []
        for r in d.get("records") or [] if isinstance(d, dict) else d:
            gesamt, rest = r.get("size") or 0, r.get("sizeleft") or 0
            ergebnis.append({"dienst": self.name, "titel": self._titel(r), "status": r.get("trackedDownloadState") or r.get("status"),
                             "prozent": _prozent(gesamt - rest, gesamt), "rest": str(r.get("timeleft") or ""),
                             "client": r.get("downloadClient") or "", "qualitaet": ((r.get("quality") or {}).get("quality") or {}).get("name", ""),
                             "fehler": "; ".join(m for s in r.get("statusMessages") or [] for m in s.get("messages") or [])})
        return ergebnis

    def zuletzt(self):
        d = self.api("history?" + urlencode(dict(pageSize=20, sortKey="date", sortDirection="descending",
                                                 eventType=self.IMPORTIERT, **self._mit())))
        return [{"dienst": self.name, "titel": self._titel(r), "zeit": str(r.get("date") or "")[:16].replace("T", " "),
                 "qualitaet": ((r.get("quality") or {}).get("quality") or {}).get("name", "")}
                for r in d.get("records") or []]

    def fehlend(self):
        d = self.api("wanted/missing?" + urlencode(dict(pageSize=20, sortKey=self.FEHLEND_SORT,
                                                        sortDirection="descending", monitored="true", **self._mit())))
        return [{"dienst": self.name, "titel": self._titel(r), "zeit": str(r.get(self.FEHLEND_SORT) or "")[:10]}
                for r in d.get("records") or []]

    def als_fehlgeschlagen(self, verlauf_id):
        """Einen Grab als fehlgeschlagen markieren: Arr setzt die Veroeffentlichung auf die Blockliste und sucht eine andere."""
        if not str(verlauf_id or "").isdigit():
            raise DienstFehler("Verlaufseintrag fehlt")
        self.api("history/failed/%d" % int(verlauf_id), methode="POST")
        return "Als fehlgeschlagen markiert. %s sperrt die Veröffentlichung und sucht eine andere." % self.typ_name

    def release_suchen(self, id_, folge=None, staffel=None):
        """Manuelle Suche: alle Veroeffentlichungen der Indexer mit Status (gut, Warnung, abgelehnt, blockiert)."""
        return releases_aufbereiten(self.api("release?" + urlencode(self._release_abfrage(id_, folge, staffel)), zeit=120))

    def release_holen(self, guid, indexer_id):
        if not str(guid or "").strip() or not str(indexer_id if indexer_id is not None else "").isdigit():
            raise DienstFehler("Veröffentlichung oder Indexer fehlt")
        self.api("release", {"guid": str(guid), "indexerId": int(indexer_id)}, zeit=60)
        return "Veröffentlichung geholt, %s übergibt sie an den Downloader" % self.typ_name

    def speicher(self):
        """Laufwerke (diskspace) mit Pfad, freiem und gesamtem Platz."""
        d = self.api("diskspace")
        return [dict(laufwerk(x), dienst=self.name) for x in d if isinstance(x, dict)] if isinstance(d, list) else []

    def profile(self):
        return [{"id": p["id"], "name": p["name"]} for p in self.api("qualityprofile")]

    def ordner(self):
        return [{"pfad": o["path"], "frei": o.get("freeSpace")} for o in self.api("rootfolder")]


class Sonarr(Arr):
    typ = "sonarr"
    IMPORTIERT = 3  # downloadFolderImported
    FEHLEND_SORT = "airDateUtc"

    @staticmethod
    def _mit():
        return {"includeSeries": "true", "includeEpisode": "true"}

    @staticmethod
    def _titel(r):
        serie = (r.get("series") or {}).get("title") or r.get("title") or ""
        folge = r.get("episode") or r
        if folge.get("seasonNumber") is not None and folge.get("episodeNumber") is not None:
            # Kalender/Fehlend: r ist die Folge; Warteschlange/Verlauf: Folge steckt unter "episode"
            return ("%s S%02dE%02d %s" % (serie, folge["seasonNumber"], folge["episodeNumber"],
                                          folge.get("title") or "")).strip()
        return serie

    def verlauf(self, id_, folge=None):
        d = self.api("history/series?" + urlencode({"seriesId": int(id_), "includeEpisode": "true"}))
        return verlauf_aufbereiten(d.get("records") if isinstance(d, dict) else d, folge)

    @staticmethod
    def _release_abfrage(id_, folge, staffel):
        if folge is not None and str(folge).isdigit():
            return {"episodeId": int(folge)}
        if staffel is not None and str(staffel).isdigit():
            return {"seriesId": int(id_), "seasonNumber": int(staffel)}
        raise DienstFehler("Sonarr sucht je Folge oder Staffel – bitte eine wählen")

    def folgen(self, id_):
        liste = self.api("episode?" + urlencode({"seriesId": int(id_)}))
        folgen = [{"id": e["id"], "staffel": e.get("seasonNumber"), "nummer": e.get("episodeNumber"),
                   "label": ("S%02dE%02d %s" % (e.get("seasonNumber") or 0, e.get("episodeNumber") or 0, e.get("title") or "")).strip(),
                   "vorhanden": bool(e.get("hasFile")), "beobachtet": bool(e.get("monitored"))}
                  for e in liste if isinstance(e, dict) and "id" in e] if isinstance(liste, list) else []
        return sorted(folgen, key=lambda f: (f["staffel"] or 0, f["nummer"] or 0))

    def kalender(self, tage=30):
        return [{"dienst": self.name, "art": "Folge", "datum": str(e.get("airDateUtc") or "")[:16],
                 "titel": self._titel(e), "vorhanden": bool(e.get("hasFile")), "beobachtet": bool(e.get("monitored"))}
                for e in self.api("calendar?" + urlencode(dict(self._zeitraum(tage), includeSeries="true")))]

    def status_titel(self, tvdb=None, **_):
        if not tvdb:
            return None
        serien = self.api("series?" + urlencode({"tvdbId": tvdb}))
        s = next((x for x in serien if str(x.get("tvdbId")) == str(tvdb)), None)
        if not s:
            return {"vorhanden": False}
        st = s.get("statistics") or {}
        return {"vorhanden": True, "id": s["id"], "beobachtet": s.get("monitored"),
                "text": "%s von %s Folgen geladen" % (st.get("episodeFileCount", 0), st.get("episodeCount", 0))}

    def hinzufuegen(self, profil, ordner, tvdb=None, **_):
        if not tvdb:
            raise DienstFehler("Sonarr braucht die TVDB-ID der Serie")
        treffer = self.api("series/lookup?" + urlencode({"term": "tvdb:%s" % tvdb}))
        if not treffer:
            raise DienstFehler("Sonarr findet die Serie nicht (tvdb:%s)" % tvdb)
        neu = dict(treffer[0], qualityProfileId=int(profil), rootFolderPath=ordner, monitored=True, seasonFolder=True,
                   addOptions={"monitor": "all", "searchForMissingEpisodes": True})
        try:
            sprachen = self.api("languageprofile")  # nur Sonarr v3
            if sprachen:
                neu["languageProfileId"] = sprachen[0]["id"]
        except DienstFehler:
            pass
        s = self.api("series", neu)
        return "%s in Sonarr angelegt, Suche gestartet" % s.get("title", "Serie")

    def suchen(self, id_):
        self.api("command", {"name": "SeriesSearch", "seriesId": int(id_)})
        return "Sonarr sucht"


class Radarr(Arr):
    typ = "radarr"
    IMPORTIERT = 3
    FEHLEND_SORT = "inCinemas"

    @staticmethod
    def _mit():
        return {"includeMovie": "true"}

    @staticmethod
    def _titel(r):
        film = r.get("movie") or r
        titel = film.get("title") or r.get("sourceTitle") or r.get("title") or ""
        return "%s (%s)" % (titel, film["year"]) if film.get("year") else titel

    def kalender(self, tage=30):
        ergebnis = []
        for f in self.api("calendar?" + urlencode(self._zeitraum(tage))):
            for feld, art in (("inCinemas", "Kino"), ("digitalRelease", "Digital"), ("physicalRelease", "Disc")):
                if f.get(feld):
                    ergebnis.append({"dienst": self.name, "art": art, "datum": str(f[feld])[:16],
                                     "titel": self._titel(f), "vorhanden": bool(f.get("hasFile")),
                                     "beobachtet": bool(f.get("monitored"))})
        start, ende = self._zeitraum(tage)["start"][:10], self._zeitraum(tage)["end"][:10]
        return [e for e in ergebnis if start <= e["datum"][:10] <= ende]

    @staticmethod
    def _release_abfrage(id_, folge, staffel):
        return {"movieId": int(id_)}

    def verlauf(self, id_, folge=None):
        return verlauf_aufbereiten(self.api("history/movie?" + urlencode({"movieId": int(id_)})))

    def _nachschlagen(self, imdb):
        if not re.match(r"^tt\d{1,10}$", str(imdb or "")):
            raise DienstFehler("Radarr braucht die IMDb-ID")
        film = self.api("movie/lookup/imdb?" + urlencode({"imdbId": imdb}))
        if isinstance(film, list):
            film = film[0] if film else None
        if not film or not film.get("tmdbId"):
            raise DienstFehler("Radarr findet den Film nicht (%s)" % imdb)
        return film

    def status_titel(self, imdb=None, **_):
        if not imdb:
            return None
        film = self._nachschlagen(imdb)
        vorhanden = self.api("movie?" + urlencode({"tmdbId": film["tmdbId"]}))
        f = vorhanden[0] if vorhanden else None
        if not f:
            return {"vorhanden": False}
        return {"vorhanden": True, "id": f["id"], "beobachtet": f.get("monitored"),
                "text": "geladen" if f.get("hasFile") else "fehlt noch"}

    def hinzufuegen(self, profil, ordner, imdb=None, **_):
        film = self._nachschlagen(imdb)
        neu = dict(film, qualityProfileId=int(profil), rootFolderPath=ordner, monitored=True,
                   minimumAvailability="released", addOptions={"searchForMovie": True})
        f = self.api("movie", neu)
        return "%s in Radarr angelegt, Suche gestartet" % f.get("title", "Film")

    def suchen(self, id_):
        self.api("command", {"name": "MoviesSearch", "movieIds": [int(id_)]})
        return "Radarr sucht"


class Lidarr(Arr):
    typ = "lidarr"
    version = "v1"
    IMPORTIERT = 3  # trackFileImported
    FEHLEND_SORT = "releaseDate"

    @staticmethod
    def _mit():
        return {"includeArtist": "true", "includeAlbum": "true"}

    @staticmethod
    def _titel(r):
        kuenstler = (r.get("artist") or {}).get("artistName") or ""
        album = (r.get("album") or r).get("title") or ""
        return " – ".join(x for x in (kuenstler, album) if x)

    def kalender(self, tage=30):
        return [{"dienst": self.name, "art": "Album", "datum": str(a.get("releaseDate") or "")[:16],
                 "titel": self._titel(a), "vorhanden": bool((a.get("statistics") or {}).get("percentOfTracks") == 100),
                 "beobachtet": bool(a.get("monitored"))}
                for a in self.api("calendar?" + urlencode(dict(self._zeitraum(tage), includeArtist="true")))]


