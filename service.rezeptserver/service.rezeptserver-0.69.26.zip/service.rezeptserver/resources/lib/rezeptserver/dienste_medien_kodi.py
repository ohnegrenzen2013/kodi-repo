"""Kodi: Titel starten ueber TMDb Helper, Jacktook und Streams auf dem Fernseher."""

from .dienste_medien_grund import (
    Client,
    DienstFehler,
    _basic,
    _json,
    json,
)

class Kodi(Client):
    """Kodi im Netz (Fernsteuerung ueber HTTP, JSON-RPC): Titel und Streams auf dem Fernseher starten."""
    typ = "kodi"

    @property
    def typ_name(self):
        return "Kodi"

    def rpc(self, methode, **parameter):
        kopf = {"Content-Type": "application/json"}
        if self.werte.get("user"):
            kopf["Authorization"] = _basic(self.werte.get("user"), self.werte.get("pass"))
        anfrage = json.dumps({"jsonrpc": "2.0", "id": 1, "method": methode, "params": parameter})
        status, _, text = self.http(self.url + "/jsonrpc", "POST", kopf, anfrage)
        if status == 401:
            raise DienstFehler("Kodi lehnt Benutzer oder Passwort ab")
        if status >= 400:
            raise DienstFehler("Kodi: HTTP %d – Fernsteuerung über HTTP erlaubt?" % status)
        d = _json(text, "Kodi")
        if d.get("error"):
            raise DienstFehler("Kodi: %s" % (d["error"].get("message") or d["error"]))
        return d.get("result")

    def pruefen(self):
        a = self.rpc("Application.GetProperties", properties=["name", "version"]) or {}
        v = a.get("version") or {}
        return "%s %s.%s" % (a.get("name") or "Kodi", v.get("major", "?"), v.get("minor", "?"))

    def addons(self):
        """IDs der installierten Video-Addons (fuer die Player-Auswahl)."""
        d = self.rpc("Addons.GetAddons", type="xbmc.python.pluginsource", enabled=True) or {}
        return {a.get("addonid") for a in d.get("addons") or [] if a.get("addonid")}

    def jetzt(self):
        aktiv = self.rpc("Player.GetActivePlayers") or []
        if not aktiv:
            return {"dienst": self.name, "laeuft": False}
        pid = aktiv[0].get("playerid", 1)
        item = (self.rpc("Player.GetItem", playerid=pid, properties=["title", "showtitle", "season", "episode", "year"])
                or {}).get("item") or {}
        p = self.rpc("Player.GetProperties", playerid=pid, properties=["percentage", "speed", "time", "totaltime"]) or {}
        titel = item.get("title") or item.get("label") or ""
        if item.get("showtitle"):
            titel = "%s S%02dE%02d %s" % (item["showtitle"], int(item.get("season") or 0), int(item.get("episode") or 0), titel)
        return {"dienst": self.name, "laeuft": True, "titel": titel, "prozent": round(float(p.get("percentage") or 0), 1),
                "pausiert": p.get("speed") == 0, "art": aktiv[0].get("type", "")}

    def steuern(self, was):
        aktiv = self.rpc("Player.GetActivePlayers") or []
        if not aktiv:
            raise DienstFehler("Auf Kodi läuft gerade nichts")
        pid = aktiv[0].get("playerid", 1)
        if was == "pause":
            self.rpc("Player.PlayPause", playerid=pid)
        elif was == "stopp":
            self.rpc("Player.Stop", playerid=pid)
        else:
            raise DienstFehler("steuern: pause oder stopp")

    def oeffnen(self, datei):
        """Adresse (http(s)://, plugin://) auf dem Fernseher starten."""
        if not str(datei).lower().startswith(("http://", "https://", "plugin://")):
            raise DienstFehler("Kodi öffnet nur http(s):// oder plugin://")
        self.rpc("Player.Open", item={"file": datei})


