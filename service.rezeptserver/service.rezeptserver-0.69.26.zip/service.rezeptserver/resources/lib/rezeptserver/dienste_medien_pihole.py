"""Pi-hole: Status und Abschalten (auch mit v5-Api-Token)."""

from .dienste_medien_grund import (
    Client,
    DienstFehler,
    _json,
    json,
    re,
)

class Pihole(Client):
    """Pi-hole im Netz: Statistik, Blockieren fuer eine Zeit pausieren oder wieder einschalten.

    Pi-hole v6: POST /api/auth {password} -> sid (Header X-FTL-SID), GET /api/stats/summary, GET/POST /api/dns/blocking
    {blocking, timer}. Pi-hole v5: /admin/api.php?summaryRaw&auth=<API-Token>, ?disable=<sekunden>, ?enable.
    Das Passwort (v6) bzw. der API-Token (v5) steht im Feld Passwort.
    """
    typ = "pihole"
    kann = ("pause", "resume")

    def __init__(self, name, werte, holen=None):
        super().__init__(name, werte, holen)
        self.url = re.sub(r"/admin/?$", "", self.url)
        self._sid = None      # v6-Sitzung ("" = ohne Passwort)
        self._version = None  # 6 oder 5

    @property
    def typ_name(self):
        return "Pi-hole"

    def _v6(self, pfad, methode="GET", daten=None):
        for versuch in range(2):
            if self._sid is None:
                self._anmelden()
            kopf = {"Content-Type": "application/json", "Accept": "application/json"}
            if self._sid:
                kopf["X-FTL-SID"] = self._sid
            status, _, text = self.http(self.url + "/api" + pfad, methode, kopf,
                                        json.dumps(daten) if daten is not None else None)
            if status == 401 and versuch == 0:
                self._sid = None
                continue
            if status == 401:
                raise DienstFehler("Pi-hole lehnt das Passwort ab")
            if status >= 400:
                raise DienstFehler("Pi-hole: HTTP %d" % status)
            return _json(text, "Pi-hole")
        raise DienstFehler("Pi-hole: keine Sitzung")

    def _anmelden(self):
        status, _, text = self.http(self.url + "/api/auth", "POST", {"Content-Type": "application/json"},
                                    json.dumps({"password": self.werte.get("pass", "")}))
        if status == 404:
            self._version = 5
            raise _AltePihole()
        sitzung = (_json(text, "Pi-hole").get("session") or {}) if status < 500 else {}
        if status == 401 or not sitzung.get("valid"):
            raise DienstFehler("Pi-hole lehnt das Passwort ab (App-Passwort oder Weboberflächen-Passwort)")
        self._version = 6
        self._sid = sitzung.get("sid") or ""

    def _v5(self, abfrage):
        status, _, text = self.http(self.url + "/admin/api.php?" + abfrage + "&auth=" + self.werte.get("pass", ""))
        if status >= 400:
            raise DienstFehler("Pi-hole: HTTP %d" % status)
        d = _json(text, "Pi-hole")
        if isinstance(d, list) or not d:
            raise DienstFehler("Pi-hole lehnt den API-Token ab")
        return d

    def zustand(self):
        try:
            if self._version != 5:
                s = self._v6("/stats/summary")
                b = self._v6("/dns/blocking")
                q = s.get("queries") or {}
                return {"version": "v6", "aktiv": b.get("blocking") == "enabled", "timer": b.get("timer"),
                        "anfragen": int(q.get("total") or 0), "blockiert": int(q.get("blocked") or 0),
                        "prozent": round(float(q.get("percent_blocked") or 0), 1),
                        "domains": int((s.get("gravity") or {}).get("domains_being_blocked") or 0),
                        "clients": int((s.get("clients") or {}).get("active") or 0)}
        except _AltePihole:
            pass
        d = self._v5("summaryRaw")
        return {"version": "v5", "aktiv": d.get("status") == "enabled", "timer": None,
                "anfragen": int(d.get("dns_queries_today") or 0), "blockiert": int(d.get("ads_blocked_today") or 0),
                "prozent": round(float(d.get("ads_percentage_today") or 0), 1),
                "domains": int(d.get("domains_being_blocked") or 0), "clients": int(d.get("unique_clients") or 0)}

    def pruefen(self):
        z = self.zustand()
        return "Pi-hole %s, Blockieren %s, %s Domains auf der Liste" % (z["version"], "an" if z["aktiv"] else "pausiert", z["domains"])

    def aktion(self, was, id_=None, wert=None):
        """pause (wert = Sekunden, 0 = bis zum Einschalten) oder resume."""
        if was not in ("pause", "resume"):
            raise DienstFehler("Pi-hole kann %s nicht" % was)
        sekunden = max(0, min(86400, int(wert or 0)))
        if self._version is None:
            self.zustand()
        if self._version == 6:
            daten = {"blocking": was == "resume", "timer": sekunden or None}
            return self._v6("/dns/blocking", "POST", daten)
        return self._v5("enable" if was == "resume" else "disable=%d" % sekunden)


class _AltePihole(Exception):
    """Pi-hole v5: keine /api/auth."""


