"""Prowlarr: Suche ueber alle Indexer und Holen an den Download-Client."""

from .dienste_medien_grund import (
    Client,
    DienstFehler,
    _json,
    datetime,
    json,
    re,
    time,
    timezone,
    urlencode,
)

def _nur_web(url):
    """Adresse eines Indexers nur, wenn sie http(s) ist (die Seite macht daraus einen Link)."""
    url = str(url or "").strip()
    return url if re.match(r"^https?://", url, re.I) else ""


class Prowlarr(Client):
    typ = "prowlarr"

    def api(self, pfad, daten=None, methode=None):
        status, _, text = self.http(self.url + "/api/v1/" + pfad, methode or ("POST" if daten is not None else "GET"),
                                    {"X-Api-Key": self.werte.get("api_key", ""), "Content-Type": "application/json"},
                                    json.dumps(daten) if daten is not None else None, 60.0)
        if status == 401:
            raise DienstFehler("Prowlarr lehnt den API-Schlüssel ab")
        d = _json(text, "Prowlarr")
        if status >= 400:
            raise DienstFehler("Prowlarr: %s" % (d.get("message") if isinstance(d, dict) else "HTTP %d" % status))
        return d

    @property
    def typ_name(self):
        return "Prowlarr"

    def pruefen(self):
        return "Prowlarr %s" % self.api("system/status").get("version", "")

    def suche(self, text, art="search"):
        jetzt = time.time()
        ergebnis = []
        for r in self.api("search?" + urlencode({"query": text, "type": art, "limit": 100})) or []:
            datum = str(r.get("publishDate") or "")
            try:
                alter = int((jetzt - datetime.strptime(datum[:19], "%Y-%m-%dT%H:%M:%S").replace(
                    tzinfo=timezone.utc).timestamp()) // 86400)
            except ValueError:
                alter = r.get("age")
            ergebnis.append({"dienst": self.name, "guid": r.get("guid"), "indexer_id": r.get("indexerId"),
                             "indexer": r.get("indexer"), "titel": r.get("title"), "groesse": int(r.get("size") or 0),
                             "alter": alter, "grabs": r.get("grabs"), "seeder": r.get("seeders"),
                             "art": r.get("protocol"), "info": _nur_web(r.get("infoUrl"))})
        return ergebnis

    def holen(self, guid, indexer_id):
        self.api("search", {"guid": guid, "indexerId": int(indexer_id)})
        return "an Prowlarrs Download-Client geschickt"


