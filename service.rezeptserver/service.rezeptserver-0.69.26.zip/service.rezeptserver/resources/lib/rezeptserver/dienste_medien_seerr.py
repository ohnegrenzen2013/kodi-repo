"""Seerr (Overseerr/Jellyseerr): Anfragen genehmigen und ablehnen."""

from .dienste_medien_grund import (
    Client,
    DienstFehler,
    NetzFehler,
    _json,
    json,
    urlencode,
)

class Seerr(Client):
    typ = "seerr"
    STATUS = {1: "wartet auf Freigabe", 2: "genehmigt", 3: "abgelehnt", 4: "fehlgeschlagen", 5: "erledigt"}
    # Medienstatus in Seerr: 1 unbekannt, 2 angefragt, 3 in Arbeit, 4 teilweise da, 5 verfuegbar
    MEDIUM_STATUS = {2: "angefragt", 3: "wird geholt", 4: "teilweise verfügbar", 5: "verfügbar"}

    def __init__(self, name, werte, holen=None):
        super().__init__(name, werte, holen)
        self._titel = {}

    def api(self, pfad, daten=None):
        status, _, text = self.http(self.url + "/api/v1/" + pfad, "POST" if daten is not None else "GET",
                                    {"X-Api-Key": self.werte.get("api_key", ""), "Content-Type": "application/json"},
                                    json.dumps(daten) if daten is not None else None)
        if status in (401, 403):
            raise DienstFehler("Seerr lehnt den API-Schlüssel ab")
        d = _json(text, "Seerr")
        if status >= 400:
            raise DienstFehler("Seerr: %s" % (d.get("message") if isinstance(d, dict) else "HTTP %d" % status))
        return d

    @property
    def typ_name(self):
        return "Seerr"

    def pruefen(self):
        return "Seerr %s" % self.api("status").get("version", "")

    def _medium(self, art, tmdb):
        schluessel = (art, tmdb)
        if schluessel not in self._titel:
            try:
                d = self.api("%s/%s" % ("tv" if art == "tv" else "movie", tmdb))
                datum = str(d.get("releaseDate") or d.get("firstAirDate") or "")[:4]
                self._titel[schluessel] = {"titel": d.get("title") or d.get("name") or str(tmdb), "jahr": datum,
                                           "poster": "https://image.tmdb.org/t/p/w185" + d["posterPath"]
                                           if d.get("posterPath") else ""}
            except (DienstFehler, NetzFehler):
                self._titel[schluessel] = {"titel": "TMDb %s" % tmdb, "jahr": "", "poster": ""}
        return self._titel[schluessel]

    def anfragen(self, filter_="pending"):
        d = self.api("request?" + urlencode({"take": 30, "skip": 0, "filter": filter_, "sort": "added"}))
        ergebnis = []
        for r in d.get("results") or []:
            medium = r.get("media") or {}
            ergebnis.append(dict(self._medium(medium.get("mediaType") or r.get("type"), medium.get("tmdbId")),
                                 id=r.get("id"), dienst=self.name, art="Serie" if r.get("type") == "tv" else "Film",
                                 status=self.STATUS.get(r.get("status"), r.get("status")), offen=r.get("status") == 1,
                                 von=(r.get("requestedBy") or {}).get("displayName") or "",
                                 datum=str(r.get("createdAt") or "")[:10]))
        return ergebnis

    def entscheiden(self, id_, genehmigen):
        self.api("request/%d/%s" % (int(id_), "approve" if genehmigen else "decline"), {})
        return "genehmigt" if genehmigen else "abgelehnt"



    def suchen(self, text):
        """Titelsuche in Seerr (TMDb): Filme und Serien mit Stand (verfuegbar, angefragt ...)."""
        text = " ".join(str(text or "").split())[:120]
        if len(text) < 2:
            return []
        d = self.api("search?" + urlencode({"query": text, "page": 1, "language": "de"}))
        ergebnis = []
        for r in d.get("results") or []:
            art = r.get("mediaType")
            if art not in ("movie", "tv") or not r.get("id"):
                continue
            datum = str(r.get("releaseDate") or r.get("firstAirDate") or "")[:4]
            stand = (r.get("mediaInfo") or {}).get("status")
            ergebnis.append({"dienst": self.name, "tmdb": r["id"], "art": art, "titel": r.get("title") or r.get("name") or "",
                             "jahr": datum, "poster": "https://image.tmdb.org/t/p/w185" + r["posterPath"] if r.get("posterPath") else "",
                             "stand": self.MEDIUM_STATUS.get(stand, ""), "anfragbar": stand not in (2, 3, 4, 5)})
        return ergebnis[:20]

    def anfrage_stellen(self, art, tmdb, staffeln=None):
        """Eine Anfrage stellen (Film oder Serie; Serie: alle Staffeln oder die genannten). Nur auf ausdruecklichen Klick."""
        if art not in ("movie", "tv"):
            raise DienstFehler("Art muss movie oder tv sein")
        if not str(tmdb or "").isdigit():
            raise DienstFehler("TMDb-Nummer fehlt")
        koerper = {"mediaType": art, "mediaId": int(tmdb)}
        if art == "tv":
            if staffeln in (None, "", "all"):
                koerper["seasons"] = "all"
            else:
                if not isinstance(staffeln, list) or not all(isinstance(n, int) and 0 <= n < 1000 for n in staffeln) or not staffeln:
                    raise DienstFehler("Staffeln müssen eine Liste von Zahlen sein")
                koerper["seasons"] = staffeln
        self.api("request", koerper)
        return "Anfrage gestellt"
