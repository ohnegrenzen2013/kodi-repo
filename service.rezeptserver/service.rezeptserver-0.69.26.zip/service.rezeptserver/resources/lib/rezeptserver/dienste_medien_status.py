"""Tautulli und Bazarr: laufende Plex-Streams und fehlende Untertitel."""

from .dienste_medien_grund import (
    Client,
    DienstFehler,
    _json,
    urlencode,
)

class Tautulli(Client):
    typ = "tautulli"

    def api(self, befehl, **parameter):
        status, _, text = self.http(self.url + "/api/v2?" + urlencode(dict(parameter, apikey=self.werte.get("api_key", ""),
                                                                          cmd=befehl)))
        d = _json(text, "Tautulli").get("response") or {}
        if status >= 400 or d.get("result") != "success":
            raise DienstFehler("Tautulli: %s" % (d.get("message") or "HTTP %d" % status))
        return d.get("data")

    @property
    def typ_name(self):
        return "Tautulli"

    def pruefen(self):
        return "Tautulli %s" % (self.api("get_tautulli_info") or {}).get("tautulli_version", "")

    def aktivitaet(self):
        d = self.api("get_activity") or {}
        return {"dienst": self.name, "anzahl": int(d.get("stream_count") or 0),
                "bandbreite": int(d.get("total_bandwidth") or 0),
                "streams": [{"wer": s.get("friendly_name") or s.get("user"), "titel": s.get("full_title"),
                             "prozent": int(s.get("progress_percent") or 0), "zustand": s.get("state"),
                             "player": s.get("player"), "qualitaet": s.get("quality_profile"),
                             "transcode": s.get("transcode_decision")} for s in d.get("sessions") or []]}


class Bazarr(Client):
    typ = "bazarr"

    def api(self, pfad):
        status, _, text = self.http(self.url + "/api/" + pfad, kopf={"X-API-KEY": self.werte.get("api_key", "")})
        if status == 401:
            raise DienstFehler("Bazarr lehnt den API-Schlüssel ab")
        if status >= 400:
            raise DienstFehler("Bazarr: HTTP %d" % status)
        return _json(text, "Bazarr")

    @property
    def typ_name(self):
        return "Bazarr"

    def pruefen(self):
        return "Bazarr %s" % ((self.api("system/status").get("data") or {}).get("bazarr_version", ""))

    def fehlend(self):
        b = self.api("badges")
        return {"dienst": self.name, "folgen": b.get("episodes", 0), "filme": b.get("movies", 0),
                "provider": b.get("providers", 0)}


