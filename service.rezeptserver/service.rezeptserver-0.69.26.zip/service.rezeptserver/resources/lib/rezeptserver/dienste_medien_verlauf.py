"""Sonarr/Radarr: Verlauf eines Titels (Grabs, Importe, Loeschungen, Fehler nach Tag), manuelle Suche mit Status
und Festplattenspeicher mit Verzeichnisfilter. Reine Aufbereitung der Arr-Antworten, ohne Netz."""

import re
from datetime import datetime, timezone

# eventType der Arr-Verlaeufe -> (Art, Beschriftung)
EREIGNISSE = {
    "grabbed": ("grab", "Geholt"),
    "downloadfolderimported": ("import", "Importiert"),
    "moviefolderimported": ("import", "Importiert"),
    "seriesfolderimported": ("import", "Importiert"),
    "downloadfailed": ("fehler", "Download fehlgeschlagen"),
    "importfailed": ("fehler", "Import fehlgeschlagen"),
    "moviefiledeleted": ("loeschung", "Datei gelöscht"),
    "episodefiledeleted": ("loeschung", "Datei gelöscht"),
    "moviefilerenamed": ("umbenannt", "Umbenannt"),
    "episodefilerenamed": ("umbenannt", "Umbenannt"),
    "downloadignored": ("ignoriert", "Ignoriert"),
}
MAX_VERLAUF = 500


def _zeit(iso):
    """(lokaler Tag JJJJ-MM-TT, Uhrzeit HH:MM) einer ISO-Zeit in der Zeitzone des Servers; ("", "") wenn unlesbar."""
    try:
        t = datetime.fromisoformat(str(iso).replace("Z", "+00:00"))
    except ValueError:
        return "", ""
    if t.tzinfo is None:
        t = t.replace(tzinfo=timezone.utc)
    t = t.astimezone()
    return t.strftime("%Y-%m-%d"), t.strftime("%H:%M")


def _stempel(iso):
    """Zeitpunkt als Sekunden (UTC) zum Sortieren; 0 bei Unsinn. Zeichenketten zu vergleichen waere bei gemischten Formaten falsch."""
    try:
        t = datetime.fromisoformat(str(iso).replace("Z", "+00:00"))
    except ValueError:
        return 0.0
    return (t if t.tzinfo else t.replace(tzinfo=timezone.utc)).timestamp()


def _qualitaet(r):
    return ((r.get("quality") or {}).get("quality") or {}).get("name", "")


def folge_name(folge):
    if not isinstance(folge, dict) or folge.get("seasonNumber") is None or folge.get("episodeNumber") is None:
        return ""
    return ("S%02dE%02d %s" % (folge["seasonNumber"], folge["episodeNumber"], folge.get("title") or "")).strip()


def verlauf_eintrag(r):
    typ = str(r.get("eventType") or "")
    art, text = EREIGNISSE.get(typ.lower()) or (("fehler", typ) if "fail" in typ.lower() else ("sonst", typ or "Ereignis"))
    daten = r.get("data") if isinstance(r.get("data"), dict) else {}
    tag, uhr = _zeit(r.get("date"))
    return {"id": r.get("id"), "art": art, "text": text, "titel": str(r.get("sourceTitle") or ""), "zeit": str(r.get("date") or ""),
            "tag": tag, "uhr": uhr, "qualitaet": _qualitaet(r), "indexer": str(daten.get("indexer") or ""),
            "client": str(daten.get("downloadClientName") or daten.get("downloadClient") or ""),
            "grund": str(daten.get("message") or daten.get("reason") or ""),
            "folge": folge_name(r.get("episode")), "folge_id": r.get("episodeId"),
            "fehlschlag_moeglich": art == "grab"}


def verlauf_aufbereiten(records, folge=None):
    """Neueste zuerst, nach lokalem Tag gruppiert: {tage: [{tag, eintraege}], folgen: [{id, label}], anzahl}."""
    eintraege = [verlauf_eintrag(r) for r in (records if isinstance(records, list) else []) if isinstance(r, dict)]
    folgen = {}
    for e in eintraege:
        if e["folge"] and e["folge_id"] is not None:
            folgen[e["folge_id"]] = e["folge"]
    if folge is not None:
        eintraege = [e for e in eintraege if str(e["folge_id"]) == str(folge)]
    eintraege.sort(key=lambda e: _stempel(e["zeit"]), reverse=True)
    eintraege = eintraege[:MAX_VERLAUF]
    tage = []
    for e in eintraege:
        if not tage or tage[-1]["tag"] != e["tag"]:
            tage.append({"tag": e["tag"], "eintraege": []})
        tage[-1]["eintraege"].append(e)
    return {"tage": tage, "anzahl": len(eintraege),
            "folgen": [{"id": i, "label": n} for i, n in sorted(folgen.items(), key=lambda x: x[1])]}


# --- Manuelle Suche -----------------------------------------------------------------------------------------------

_SPERRE = re.compile(r"black ?list|block ?list|sperrliste|gesperrt", re.I)
STATUS_REIHE = {"gut": 0, "warnung": 1, "abgelehnt": 2, "blockiert": 3}
MAX_RELEASES = 100


def _gruende(r):
    gruende = []
    for g in r.get("rejections") or []:
        text = g.get("reason") if isinstance(g, dict) else g
        if text:
            gruende.append(str(text))
    return gruende


def release_status(r):
    """gut (freigegeben) | warnung (nur vorlaeufig abgelehnt) | abgelehnt | blockiert (steht auf der Blockliste)."""
    gruende = _gruende(r)
    if any(_SPERRE.search(g) for g in gruende):
        return "blockiert"
    if r.get("approved") or not (r.get("rejected") or gruende):
        return "gut"
    if r.get("temporarilyRejected"):
        return "warnung"
    return "abgelehnt"


def release_eintrag(r):
    status = release_status(r)
    return {"guid": str(r.get("guid") or ""), "indexer_id": r.get("indexerId"), "titel": str(r.get("title") or ""),
            "indexer": str(r.get("indexer") or ""), "qualitaet": _qualitaet(r), "groesse": int(r.get("size") or 0),
            "alter_tage": int(r.get("age") or 0), "seeders": r.get("seeders"), "protokoll": str(r.get("protocol") or ""),
            "punkte": r.get("customFormatScore"), "status": status, "gruende": _gruende(r),
            "erlaubt": r.get("downloadAllowed", True) is not False}


def releases_aufbereiten(roh):
    liste = [release_eintrag(r) for r in (roh if isinstance(roh, list) else []) if isinstance(r, dict) and r.get("guid")]
    liste.sort(key=lambda e: STATUS_REIHE[e["status"]])  # stabil: innerhalb eines Status bleibt Arrs Reihenfolge
    return liste[:MAX_RELEASES]


# --- Festplattenspeicher ------------------------------------------------------------------------------------------

def _pfad(p):
    return str(p or "").strip().replace("\\", "/").rstrip("/").lower() or "/"


def muster_pruefen(text):
    """Eine Zeile je Muster; leere Zeilen und #-Kommentare entfallen."""
    return [z.strip()[:300] for z in str(text or "").splitlines() if z.strip() and not z.strip().startswith("#")][:50]


def wildcard_passt(muster, pfad):
    """* steht fuer beliebig viel (auch Unterordner und /), ? fuer genau ein Zeichen; sonst woertlich, ohne Gross-/Kleinschreibung.
    Zwei-Zeiger-Verfahren statt Regex: auch absichtlich verschachtelte Muster (*a*a*a*b) rechnen nie ewig."""
    m, p = _pfad(muster), _pfad(pfad)
    i = j = 0
    stern, rest = -1, 0
    while j < len(p):
        if i < len(m) and m[i] != "*" and (m[i] == "?" or m[i] == p[j]):
            i += 1
            j += 1
        elif i < len(m) and m[i] == "*":
            stern, rest = i, j
            i += 1
        elif stern >= 0:
            i, rest = stern + 1, rest + 1
            j = rest
        else:
            return False
    while i < len(m) and m[i] == "*":
        i += 1
    return i == len(m)


def speicher_filtern(laufwerke, muster):
    """Laufwerke ohne die, deren Pfad zu einem Muster passt; doppelte Pfade (mehrere Arrs) nur einmal."""
    muster = muster_pruefen("\n".join(muster) if isinstance(muster, (list, tuple)) else muster)
    gesehen, ergebnis = set(), []
    for d in laufwerke:
        schluessel = _pfad(d.get("pfad"))
        if schluessel in gesehen or any(wildcard_passt(m, d.get("pfad")) for m in muster):
            continue
        gesehen.add(schluessel)
        ergebnis.append(d)
    return ergebnis


def laufwerk(d):
    frei, gesamt = int(d.get("freeSpace") or 0), int(d.get("totalSpace") or 0)
    return {"pfad": str(d.get("path") or ""), "name": str(d.get("label") or ""), "frei": frei, "gesamt": gesamt,
            "belegt_prozent": round(100.0 * (gesamt - frei) / gesamt, 1) if gesamt else None}
