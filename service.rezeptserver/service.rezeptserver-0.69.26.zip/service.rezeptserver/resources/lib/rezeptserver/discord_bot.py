"""Discord-Bildbot: Zufallsbilder aus dem Ab-18-Bereich an einen Discord-Webhook senden.

Vorbild ist VictorMoises/NSFW (Discord-Bot mit Zufallsbildern je Kategorie). H0rSt
betreibt keinen Gateway-Bot und kopiert keinen fremden Code: Der Versand laeuft ueber
einen Discord-Webhook, die Bilder bleiben bei den Ab-18-Seiten. Ohne Freigabe ab 18,
ohne ausdrueckliche Bestaetigung und ohne eingeschalteten Schalter passiert nichts.
"""

import json
import random
import re
from urllib.parse import urlsplit

from .netz import antwort_holen, oeffentlich_antwort_holen

SCHLUESSEL = "discord"
WEBHOOK = re.compile(r"^https://(?:(?:ptb|canary)\.)?discord(?:app)?\.com/api/webhooks/\d{10,}/[A-Za-z0-9_-]{20,}$")
MAX_ANZAHL = 10
KATEGORIEN = [
    {"id": "4k", "name": "4K", "suche": "4k"},
    {"id": "amateur", "name": "Amateur", "suche": "amateur"},
    {"id": "asian", "name": "Asian", "suche": "asian"},
    {"id": "ass", "name": "Ass", "suche": "ass"},
    {"id": "bbw", "name": "BBW", "suche": "bbw"},
    {"id": "boobs", "name": "Boobs", "suche": "boobs"},
    {"id": "cosplay", "name": "Cosplay", "suche": "cosplay"},
    {"id": "dick", "name": "Dick", "suche": "dick"},
    {"id": "fuck", "name": "Fuck", "suche": "fuck"},
    {"id": "gif", "name": "GIF", "suche": "gif"},
    {"id": "hentai", "name": "Hentai", "suche": "hentai"},
    {"id": "milf", "name": "MILF", "suche": "milf"},
    {"id": "pornhub", "name": "Pornhub", "suche": "pornhub"},
    {"id": "public", "name": "Public", "suche": "public"},
    {"id": "pussy", "name": "Pussy", "suche": "pussy"},
    {"id": "snapchat", "name": "Snapchat", "suche": "snapchat"},
    {"id": "uniform", "name": "Uniform", "suche": "uniform"},
]
_KATEGORIE = {k["id"]: k for k in KATEGORIEN}


class DiscordFehler(ValueError):
    pass


def _text(wert, laenge):
    return " ".join(str(wert or "").split())[:laenge]


def _zahl(wert, standard, klein, gross):
    try:
        return max(klein, min(gross, int(wert)))
    except (TypeError, ValueError, OverflowError):
        return standard


def pruefe(roh):
    roh = roh if isinstance(roh, dict) else {}
    kategorie = str(roh.get("discord_kategorie") or "4k").strip().lower()
    if kategorie not in _KATEGORIE:
        kategorie = "4k"
    return {"discord_an": roh.get("discord_an") is True,
            "discord_webhook": str(roh.get("discord_webhook") or "").strip()[:500],
            "discord_prefix": _text(roh.get("discord_prefix"), 60) or "nsfw ",
            "discord_kategorie": kategorie,
            "discord_anzahl": str(_zahl(roh.get("discord_anzahl"), 1, 1, MAX_ANZAHL)),
            "discord_text": _text(roh.get("discord_text"), 300),
            "discord_nsfw_bestaetigt": roh.get("discord_nsfw_bestaetigt") is True}


def zustand(werte):
    w = pruefe(werte)
    return {"an": w["discord_an"], "webhook": w["discord_webhook"],
            "webhook_gesetzt": bool(w["discord_webhook"]),
            "webhook_ok": bool(WEBHOOK.match(w["discord_webhook"])),
            "prefix": w["discord_prefix"], "kategorie": w["discord_kategorie"],
            "anzahl": w["discord_anzahl"], "text": w["discord_text"],
            "bestaetigt": w["discord_nsfw_bestaetigt"], "kategorien": KATEGORIEN,
            "hinweis": "Der Webhook muss in einem Kanal mit Altersfreigabe liegen. "
                       "H0rSt sendet nur Titel, Link und Vorschaubild; die Dateien bleiben bei den Seiten."}


def _webhook(werte):
    url = str(werte.get("discord_webhook") or "").strip()
    if not WEBHOOK.match(url):
        raise DiscordFehler("Discord-Webhook-Adresse fehlt oder ist ungueltig")
    return url


def _treffer(ergebnis):
    videos = []
    for eintrag in (ergebnis or {}).get("ergebnisse") or []:
        for video in eintrag.get("videos") or []:
            if isinstance(video, dict) and str(video.get("url") or "").startswith(("http://", "https://")):
                videos.append(video)
    return videos


def senden(werte, kategorie=None, anzahl=None, text=None, suche=None, holen=None):
    w = pruefe(werte)
    if not w["discord_an"]:
        raise DiscordFehler("Der Discord-Bildbot ist ausgeschaltet")
    if not w["discord_nsfw_bestaetigt"]:
        raise DiscordFehler("Erst bestaetigen: nur in Kanaelen mit Altersfreigabe")
    url = _webhook(w)
    k = _KATEGORIE.get(str(kategorie or w["discord_kategorie"]).strip().lower())
    if k is None:
        raise DiscordFehler("Unbekannte Kategorie")
    if not callable(suche):
        raise DiscordFehler("Ab-18-Suche nicht verfuegbar")
    menge = _zahl(anzahl if anzahl is not None else w["discord_anzahl"], 1, 1, MAX_ANZAHL)
    videos = _treffer(suche(k["suche"]))
    if not videos:
        raise DiscordFehler("Keine Videos gefunden (%s)" % k["name"])
    zufall = random.SystemRandom()
    auswahl = zufall.sample(videos, min(menge, len(videos)))
    zusatz = _text(text if text is not None else w["discord_text"], 300)
    inhalt = (w["discord_prefix"].rstrip() + " " + k["name"] + ((" · " + zusatz) if zusatz else ""))[:2000]
    einbettungen = []
    for video in auswahl:
        bild = str(video.get("bild") or "")
        e = {"title": _text(video.get("titel") or k["name"], 200),
             "footer": {"text": "H0rSt · 18+ · " + str(video.get("seite_name") or "")}}
        if bild.startswith(("http://", "https://")):
            e["image"] = {"url": bild}
        einbettungen.append(e)
    koerper = json.dumps({"content": inhalt, "embeds": einbettungen, "allowed_mentions": {"parse": []}},
                         ensure_ascii=False).encode("utf-8")
    holen = holen or oeffentlich_antwort_holen(antwort_holen)
    try:
        status, antwort = holen(url, "POST", {"Content-Type": "application/json", "User-Agent": "H0rSt-Discord"},
                                koerper, zeitgrenze=20)
    except Exception as fehler:  # noqa: BLE001 – Webhook-Fehler bleiben eine Meldung
        raise DiscordFehler("Discord nicht erreichbar: %s" % fehler)
    if status not in (200, 204):
        raise DiscordFehler("Discord-Webhook: HTTP %s %s" % (status, str(antwort or "")[:200]))
    return {"gesendet": len(einbettungen), "kategorie": k["id"], "namen": [e["title"] for e in einbettungen]}


def webhook_pruefen(werte, holen=None):
    url = _webhook(pruefe(werte))
    holen = holen or oeffentlich_antwort_holen(antwort_holen)
    try:
        status, antwort = holen(url, "GET", {"User-Agent": "H0rSt-Discord"}, None, zeitgrenze=15)
    except Exception as fehler:  # noqa: BLE001
        raise DiscordFehler("Discord nicht erreichbar: %s" % fehler)
    if status != 200:
        raise DiscordFehler("Webhook antwortet nicht (HTTP %s)" % status)
    try:
        d = json.loads(antwort)
    except (TypeError, ValueError):
        d = {}
    return {"ok": True, "name": str((d or {}).get("name") or "Webhook"),
            "kanal": str((d or {}).get("channel_id") or "")}


def kategorie_liste():
    return [{"id": k["id"], "name": k["name"]} for k in KATEGORIEN]


def webhook_host(url):
    try:
        return urlsplit(str(url or "")).hostname or ""
    except ValueError:
        return ""
