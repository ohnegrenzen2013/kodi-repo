"""H0rSt als DLNA-/UPnP-Medienserver: Fernseher, Receiver (Dreambox), Kodi und VLC sehen H0rSt als Quelle.

Die Gegenrichtung zu fernseher.py (dort schickt H0rSt aktiv): Hier blaettert das Geraet selbst durch H0rSt –
"Medien" bzw. "Quellen" in der App des Fernsehers, DLNA-Browser der Dreambox, VLC "Universal Plug'n'Play".

  Ankuendigen   SSDP (UDP 239.255.255.250:1900): Antworten auf M-SEARCH, alle 10 Minuten NOTIFY alive,
                beim Stoppen byebye
  Beschreibung  /dlna/beschreibung.xml (MediaServer:1), /dlna/cd.xml und /dlna/cm.xml (Dienstbeschreibungen)
  Steuerung     POST /dlna/cd: Browse (Kinder und Metadaten), GetSystemUpdateID, Such-/Sortierfaehigkeiten
                POST /dlna/cm: GetProtocolInfo, GetCurrentConnectionIDs
  Inhalt        0/radio  Radio-Favoriten (radio.py)
                0/tv     Live-TV: alle Sender aus tv.m3u (kostenlose Sender, eigene Listen, Receiver-Favoriten)
                0/heim   Eigene Speicher (heimspeicher.py: AiCloud, Nextcloud, Synology, WebDAV, FTP, offene
                         Verzeichnisse) mit Unterordnern; nur Ordner, Videos, Musik und Bilder. Dateien laufen ueber
                         /dlna/datei/<speicher>?pfad=… durch H0rSt (Zugangsdaten bleiben hier, Range zum Springen)

Laeuft nur, wenn H0rSt im Heimnetz freigegeben ist (mit Token: alle Adressen tragen es im Pfad) und unter
Einstellungen -> Wiedergabe "Medienserver (DLNA)" an ist. In Docker braucht SSDP network_mode: host.
"""

from .dlna_server_grund import *
from .dlna_server_grund import _LOGO, __version__
from .dlna_server_ssdp import Ankuendiger, antworten, kennung, melden, typen
from .dlna_server_beschreibungen import CD_SCPD, CM_SCPD, beschreibung, _scpd
from .dlna_server_inhalt import browse, didl, heim_kinder, kinder, m3u_eintraege, _container, _eltern, _heim_id, _heim_speicher, _heim_teile, _item, _tv_mime
from .dlna_server_soap import soap_antwort, soap_fehler
