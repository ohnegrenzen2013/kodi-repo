"""Beschreibungen: Geraete- und Dienstbeschreibungen (cd.xml, cm.xml)."""

from .dlna_server_grund import (
    CD,
    CM,
    GERAET,
    __version__,
    escape,
)

def beschreibung(uuid, name):
    return ('<?xml version="1.0" encoding="utf-8"?>\n<root xmlns="urn:schemas-upnp-org:device-1-0" '
            'xmlns:dlna="urn:schemas-dlna-org:device-1-0"><specVersion><major>1</major><minor>0</minor></specVersion>'
            '<device><deviceType>%s</deviceType><friendlyName>%s</friendlyName><manufacturer>m0dulh0st</manufacturer>'
            '<manufacturerURL>https://github.com/CR0C0d0C</manufacturerURL><modelName>H0rSt</modelName>'
            '<modelNumber>%s</modelNumber><UDN>uuid:%s</UDN><dlna:X_DLNADOC>DMS-1.50</dlna:X_DLNADOC>'
            '<iconList><icon><mimetype>image/svg+xml</mimetype><width>120</width><height>120</height><depth>24</depth>'
            '<url>../logo.svg</url></icon></iconList><serviceList>'
            '<service><serviceType>%s</serviceType><serviceId>urn:upnp-org:serviceId:ContentDirectory</serviceId>'
            '<SCPDURL>cd.xml</SCPDURL><controlURL>cd</controlURL><eventSubURL>cd-ereignis</eventSubURL></service>'
            '<service><serviceType>%s</serviceType><serviceId>urn:upnp-org:serviceId:ConnectionManager</serviceId>'
            '<SCPDURL>cm.xml</SCPDURL><controlURL>cm</controlURL><eventSubURL>cm-ereignis</eventSubURL></service>'
            '</serviceList></device></root>' % (GERAET, escape(name), __version__, uuid, CD, CM))


def _scpd(aktionen, variablen):
    teile = []
    for name, argumente in aktionen:
        args = "".join("<argument><name>%s</name><direction>%s</direction><relatedStateVariable>%s</relatedStateVariable></argument>"
                       % a for a in argumente)
        teile.append("<action><name>%s</name><argumentList>%s</argumentList></action>" % (name, args))
    vars_ = "".join('<stateVariable sendEvents="%s"><name>%s</name><dataType>%s</dataType></stateVariable>' % v for v in variablen)
    return ('<?xml version="1.0" encoding="utf-8"?>\n<scpd xmlns="urn:schemas-upnp-org:service-1-0"><specVersion><major>1</major>'
            '<minor>0</minor></specVersion><actionList>%s</actionList><serviceStateTable>%s</serviceStateTable></scpd>'
            % ("".join(teile), vars_))


CD_SCPD = _scpd([
    ("Browse", [("ObjectID", "in", "A_ARG_TYPE_ObjectID"), ("BrowseFlag", "in", "A_ARG_TYPE_BrowseFlag"),
                ("Filter", "in", "A_ARG_TYPE_Filter"), ("StartingIndex", "in", "A_ARG_TYPE_Index"),
                ("RequestedCount", "in", "A_ARG_TYPE_Count"), ("SortCriteria", "in", "A_ARG_TYPE_SortCriteria"),
                ("Result", "out", "A_ARG_TYPE_Result"), ("NumberReturned", "out", "A_ARG_TYPE_Count"),
                ("TotalMatches", "out", "A_ARG_TYPE_Count"), ("UpdateID", "out", "A_ARG_TYPE_UpdateID")]),
    ("GetSystemUpdateID", [("Id", "out", "SystemUpdateID")]),
    ("GetSearchCapabilities", [("SearchCaps", "out", "SearchCapabilities")]),
    ("GetSortCapabilities", [("SortCaps", "out", "SortCapabilities")])],
    [("no", "A_ARG_TYPE_ObjectID", "string"), ("no", "A_ARG_TYPE_BrowseFlag", "string"), ("no", "A_ARG_TYPE_Filter", "string"),
     ("no", "A_ARG_TYPE_Index", "ui4"), ("no", "A_ARG_TYPE_Count", "ui4"), ("no", "A_ARG_TYPE_SortCriteria", "string"),
     ("no", "A_ARG_TYPE_Result", "string"), ("no", "A_ARG_TYPE_UpdateID", "ui4"), ("yes", "SystemUpdateID", "ui4"),
     ("no", "SearchCapabilities", "string"), ("no", "SortCapabilities", "string")])


CM_SCPD = _scpd([
    ("GetProtocolInfo", [("Source", "out", "SourceProtocolInfo"), ("Sink", "out", "SinkProtocolInfo")]),
    ("GetCurrentConnectionIDs", [("ConnectionIDs", "out", "CurrentConnectionIDs")])],
    [("yes", "SourceProtocolInfo", "string"), ("yes", "SinkProtocolInfo", "string"), ("yes", "CurrentConnectionIDs", "string")])


