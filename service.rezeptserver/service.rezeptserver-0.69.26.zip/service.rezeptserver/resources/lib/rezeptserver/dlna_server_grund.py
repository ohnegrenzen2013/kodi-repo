"""Grundlage von dlna_server: Importe, Logger, Adressen, Typen und Ordner.
Alles hier wird samt Importen wieder exportiert (rezeptserver.dlna_server.*)."""


import logging
import mimetypes
import random
import re
import socket
import struct
import threading
import time
import uuid as uuid_modul
from xml.sax.saxutils import escape

from . import __version__, radio

log = logging.getLogger("rezeptserver")

GRUPPE = ("239.255.255.250", 1900)
GERAET = "urn:schemas-upnp-org:device:MediaServer:1"
CD = "urn:schemas-upnp-org:service:ContentDirectory:1"
CM = "urn:schemas-upnp-org:service:ConnectionManager:1"
ALIVE_ABSTAND = 600
SERVER_KOPF = "Linux/1.0 UPnP/1.0 H0rSt/%s" % __version__
ORDNER = [("radio", "Radio-Favoriten"), ("tv", "Live-TV"), ("heim", "Eigene Speicher")]
# Inhaltstypen, wie Fernseher sie erwarten (unabhaengig davon, was die Python-Version kennt)
DLNA_TYPEN = {".mkv": "video/x-matroska", ".mp4": "video/mp4", ".m4v": "video/mp4", ".avi": "video/x-msvideo",
              ".ts": "video/mp2t", ".m2ts": "video/mp2t", ".mov": "video/quicktime", ".webm": "video/webm", ".mpg": "video/mpeg",
              ".mpeg": "video/mpeg", ".wmv": "video/x-ms-wmv", ".mp3": "audio/mpeg", ".flac": "audio/flac", ".m4a": "audio/mp4",
              ".aac": "audio/aac", ".ogg": "audio/ogg", ".opus": "audio/ogg", ".wav": "audio/wav", ".wma": "audio/x-ms-wma",
              ".mp2": "audio/mpeg", ".m4b": "audio/mp4", ".oga": "audio/ogg", ".weba": "audio/webm", ".mka": "audio/x-matroska",
              ".aif": "audio/aiff", ".aiff": "audio/aiff", ".ac3": "audio/ac3", ".eac3": "audio/eac3", ".dts": "audio/vnd.dts",
              ".ape": "audio/x-ape", ".wv": "audio/x-wavpack", ".amr": "audio/amr",
              ".jpg": "image/jpeg", ".jpeg": "image/jpeg", ".png": "image/png", ".gif": "image/gif", ".webp": "image/webp"}
MEDIEN = {"video": "object.item.videoItem", "audio": "object.item.audioItem.musicTrack", "bild": "object.item.imageItem.photo"}
_LOGO = re.compile(r'tvg-logo="([^"]*)"')
