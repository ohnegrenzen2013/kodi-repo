"""Inhalt: M3U, Eintraege, Ordner und Browse ueber Radio, Live-TV und eigene Speicher."""

from .dlna_server_grund import (
    DLNA_TYPEN,
    MEDIEN,
    ORDNER,
    _LOGO,
    escape,
    mimetypes,
    radio,
)

def m3u_eintraege(text):
    """[(name, logo, url)] aus einer M3U-Liste."""
    eintraege, aktuell = [], None
    for zeile in str(text or "").splitlines():
        zeile = zeile.strip()
        if zeile.startswith("#EXTINF"):
            # Name hinter dem ersten Komma ausserhalb von Anfuehrungszeichen (Attribute duerfen Kommas enthalten)
            in_text, trenner = False, len(zeile)
            for n, z in enumerate(zeile):
                if z == '"':
                    in_text = not in_text
                elif z == "," and not in_text:
                    trenner = n
                    break
            logo = _LOGO.search(zeile[:trenner])
            aktuell = (zeile[trenner + 1:].strip(), logo.group(1) if logo else "")
        elif zeile and not zeile.startswith("#") and aktuell:
            eintraege.append((aktuell[0], aktuell[1], zeile))
            aktuell = None
    return eintraege


def _tv_mime(url):
    pfad = url.split("?", 1)[0].lower()
    if pfad.endswith(".m3u8") or "/api/hls/" in pfad:
        return "application/x-mpegURL"
    if pfad.endswith(".mp4"):
        return "video/mp4"
    return "video/mp2t"


def _item(oid, eltern, titel, url, mime, klasse, bild=""):
    return ('<item id="%s" parentID="%s" restricted="1"><dc:title>%s</dc:title><upnp:class>%s</upnp:class>%s'
            '<res protocolInfo="http-get:*:%s:DLNA.ORG_OP=00;DLNA.ORG_FLAGS=01700000000000000000000000000000">%s</res></item>'
            % (escape(oid), escape(eltern), escape(titel), klasse,
               "<upnp:albumArtURI>%s</upnp:albumArtURI>" % escape(bild) if bild else "", mime, escape(url)))


def _container(oid, eltern, titel, anzahl=None):
    zahl = ' childCount="%d"' % anzahl if anzahl is not None else ""  # bei Speichern unbekannt, ohne Liste zu laden
    return ('<container id="%s" parentID="%s" restricted="1" searchable="0"%s><dc:title>%s</dc:title>'
            '<upnp:class>object.container.storageFolder</upnp:class></container>' % (escape(oid), escape(eltern), zahl, escape(titel)))


def _heim_id(art, sid, pfad):
    return "%s:%s:%s" % (art, sid, pfad)


def _heim_teile(oid):
    """"h:<speicher>:<pfad>" (Ordner) bzw. "f:…" (Datei) -> (art, speicher, pfad); None bei fremden IDs."""
    teile = oid.split(":", 2)
    if len(teile) != 3 or teile[0] not in ("h", "f") or not teile[1] or not teile[2].startswith("/"):
        return None
    return teile[0], teile[1], teile[2]


def _eltern(sid, pfad):
    oben = pfad.rstrip("/").rsplit("/", 1)[0] or "/"
    return "heim" if pfad.rstrip("/") in ("", "/") else _heim_id("h", sid, oben)


def heim_kinder(sid, pfad, heim):
    """Eintraege eines Speicher-Ordners: Unterordner und Mediendateien."""
    teile = []
    for e in heim["liste"](sid, pfad):
        if e.get("ordner"):
            teile.append(_container(_heim_id("h", sid, e["pfad"]), _heim_id("h", sid, pfad), e["name"]))
        elif e.get("art") in MEDIEN:
            endung = ("." + e["name"].rsplit(".", 1)[-1].lower()) if "." in e["name"] else ""
            mime = DLNA_TYPEN.get(endung) or e.get("typ") or mimetypes.guess_type(e["name"])[0] or \
                {"video": "video/mp4", "audio": "audio/mpeg"}.get(e["art"], "image/jpeg")
            teile.append(_item(_heim_id("f", sid, e["pfad"]), _heim_id("h", sid, pfad), e["name"], heim["url"](sid, e["pfad"]),
                               mime.split(";")[0].strip(), MEDIEN[e["art"]]))
    return teile


def didl(teile):
    return ('<DIDL-Lite xmlns="urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/" xmlns:dc="http://purl.org/dc/elements/1.1/" '
            'xmlns:upnp="urn:schemas-upnp-org:metadata-1-0/upnp/">%s</DIDL-Lite>' % "".join(teile))


def kinder(ordner, quellen):
    """Eintraege eines Ordners: ["<item …>", …]; quellen = {"radio": [sender], "tv": [(name, logo, url)]}."""
    if ordner == "radio":
        return [_item("radio/%d" % n, "radio", s["name"], s["url"], radio.mime(s), "object.item.audioItem.audioBroadcast", s.get("bild", ""))
                for n, s in enumerate(quellen.get("radio") or [])]
    if ordner == "tv":
        return [_item("tv/%d" % n, "tv", name, url, _tv_mime(url), "object.item.videoItem.videoBroadcast", logo)
                for n, (name, logo, url) in enumerate(quellen.get("tv") or [])]
    return []


def _heim_speicher(quellen):
    heim = quellen.get("heim") or {}
    return [_container(_heim_id("h", s["id"], "/"), "heim", s["name"]) for s in heim.get("speicher") or []]


def browse(werte, quellen, name="H0rSt"):
    """(Result-DIDL, NumberReturned, TotalMatches) fuer Browse. quellen["heim"] = {"speicher": [{id, name}],
    "liste": f(speicher, pfad) -> Eintraege, "url": f(speicher, pfad) -> Adresse}."""
    oid = werte.get("ObjectID") or "0"
    flag = werte.get("BrowseFlag") or "BrowseDirectChildren"
    try:
        start = max(0, int(werte.get("StartingIndex") or 0))
        anzahl = max(0, int(werte.get("RequestedCount") or 0))
    except ValueError:
        raise ValueError("StartingIndex/RequestedCount als Zahl")
    heim = _heim_teile(oid)
    if heim:
        art, sid, pfad = heim
        if all(s["id"] != sid for s in (quellen.get("heim") or {}).get("speicher") or []):
            raise KeyError(oid)
        if flag == "BrowseMetadata":
            if art == "h":
                speicher = next(s for s in quellen["heim"]["speicher"] if s["id"] == sid)
                titel = speicher["name"] if pfad.rstrip("/") in ("", "/") else pfad.rstrip("/").rsplit("/", 1)[-1]
                return didl([_container(oid, _eltern(sid, pfad), titel)]), 1, 1
            oben = pfad.rsplit("/", 1)[0] or "/"
            treffer = [t for t in heim_kinder(sid, oben, quellen["heim"]) if 'id="%s"' % escape(oid) in t]
            if not treffer:
                raise KeyError(oid)
            return didl(treffer), 1, 1
        if art != "h":
            raise KeyError(oid)
        alle = heim_kinder(sid, pfad, quellen["heim"])
        auswahl = alle[start:start + anzahl] if anzahl else alle[start:]
        return didl(auswahl), len(auswahl), len(alle)
    if flag == "BrowseMetadata":
        if oid == "0":
            teil = ('<container id="0" parentID="-1" restricted="1" searchable="0" childCount="%d"><dc:title>%s</dc:title>'
                    '<upnp:class>object.container.storageFolder</upnp:class></container>' % (len(ORDNER), escape(name)))
        elif oid == "heim":
            teil = _container(oid, "0", dict(ORDNER)[oid], len(_heim_speicher(quellen)))
        elif oid in dict(ORDNER):
            teil = _container(oid, "0", dict(ORDNER)[oid], len(kinder(oid, quellen)))
        else:
            ordner, _, nr = oid.partition("/")
            alle = kinder(ordner, quellen)
            if not nr.isdigit() or int(nr) >= len(alle):
                raise KeyError(oid)
            teil = alle[int(nr)]
        return didl([teil]), 1, 1
    if oid == "0":
        alle = [_container(o, "0", t, len(_heim_speicher(quellen) if o == "heim" else kinder(o, quellen))) for o, t in ORDNER]
    elif oid == "heim":
        alle = _heim_speicher(quellen)
    elif oid in dict(ORDNER):
        alle = kinder(oid, quellen)
    else:
        raise KeyError(oid)
    auswahl = alle[start:start + anzahl] if anzahl else alle[start:]
    return didl(auswahl), len(auswahl), len(alle)


