"""SOAP-Antworten: Erfolg und Fehler als UPnP-Envelope."""

from .dlna_server_grund import (
    escape,
)

def soap_antwort(dienst, aktion, werte):
    teile = "".join("<%s>%s</%s>" % (k, escape(str(v)), k) for k, v in werte)
    return ('<?xml version="1.0" encoding="utf-8"?>\n<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" '
            's:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"><s:Body><u:%sResponse xmlns:u="%s">%s</u:%sResponse>'
            '</s:Body></s:Envelope>' % (aktion, dienst, teile, aktion))


def soap_fehler(code, text):
    return ('<?xml version="1.0" encoding="utf-8"?>\n<s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" '
            's:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"><s:Body><s:Fault><faultcode>s:Client</faultcode>'
            '<faultstring>UPnPError</faultstring><detail><UPnPError xmlns="urn:schemas-upnp-org:control-1-0">'
            '<errorCode>%d</errorCode><errorDescription>%s</errorDescription></UPnPError></detail></s:Fault></s:Body>'
            '</s:Envelope>' % (code, escape(text)))


