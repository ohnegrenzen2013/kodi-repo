"""Ankuendigen: SSDP antworten (M-SEARCH) und melden (NOTIFY) sowie der Ankuendiger-Faden."""

from .dlna_server_grund import (
    ALIVE_ABSTAND,
    CD,
    CM,
    GERAET,
    GRUPPE,
    SERVER_KOPF,
    log,
    random,
    socket,
    struct,
    threading,
    time,
    uuid_modul,
)

def kennung(token):
    """Stabile UUID je H0rSt (aus dem Token), damit Fernseher die Quelle wiedererkennen."""
    return str(uuid_modul.uuid5(uuid_modul.NAMESPACE_URL, "h0rst-dlna:" + str(token or "")))


def typen(uuid):
    """(ST/NT, USN) fuer alles, was angekuendigt wird."""
    u = "uuid:" + uuid
    return [("upnp:rootdevice", u + "::upnp:rootdevice"), (u, u), (GERAET, u + "::" + GERAET), (CD, u + "::" + CD), (CM, u + "::" + CM)]


def antworten(daten, uuid, ort):
    """Antworten auf ein M-SEARCH-Paket (leer, wenn es nicht passt)."""
    text = daten.decode("utf-8", "replace")
    if not text.startswith("M-SEARCH") or "ssdp:discover" not in text.lower():
        return []
    st = next((z.split(":", 1)[1].strip() for z in text.split("\r\n") if z.lower().startswith("st:")), "")
    passend = [t for t in typen(uuid) if st in ("ssdp:all", t[0])]
    return [("HTTP/1.1 200 OK\r\nCACHE-CONTROL: max-age=1800\r\nDATE: %s\r\nEXT:\r\nLOCATION: %s\r\nSERVER: %s\r\n"
             "ST: %s\r\nUSN: %s\r\n\r\n" % (time.strftime("%a, %d %b %Y %H:%M:%S GMT", time.gmtime()), ort, SERVER_KOPF, t, usn)).encode("ascii")
            for t, usn in passend]


def melden(uuid, ort, art="ssdp:alive"):
    """NOTIFY-Pakete (alive oder byebye)."""
    pakete = []
    for nt, usn in typen(uuid):
        kopf = "NOTIFY * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nNT: %s\r\nNTS: %s\r\nUSN: %s\r\n" % (nt, art, usn)
        if art == "ssdp:alive":
            kopf += "CACHE-CONTROL: max-age=1800\r\nLOCATION: %s\r\nSERVER: %s\r\n" % (ort, SERVER_KOPF)
        pakete.append((kopf + "\r\n").encode("ascii"))
    return pakete


class Ankuendiger:
    """SSDP im Hintergrund: beantwortet Suchen und meldet sich regelmaessig."""

    def __init__(self, uuid, ort, sock=None):
        self.uuid, self.ort = uuid, ort
        self._sock = sock
        self._halt = threading.Event()
        self._faden = None

    def _oeffnen(self):
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM, socket.IPPROTO_UDP)
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        if hasattr(socket, "SO_REUSEPORT"):
            try:
                s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEPORT, 1)
            except OSError:
                pass
        s.bind(("", GRUPPE[1]))
        s.setsockopt(socket.IPPROTO_IP, socket.IP_ADD_MEMBERSHIP, struct.pack("4s4s", socket.inet_aton(GRUPPE[0]), socket.inet_aton("0.0.0.0")))
        s.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 2)
        return s

    def starten(self):
        if self._sock is None:
            self._sock = self._oeffnen()  # OSError (Port belegt, kein Multicast): der Aufrufer meldet es
        self._sock.settimeout(1.0)
        self._halt.clear()
        self._faden = threading.Thread(target=self._schleife, name="dlna-ssdp", daemon=True)
        self._faden.start()

    def stoppen(self):
        self._halt.set()
        try:
            for p in melden(self.uuid, self.ort, "ssdp:byebye"):
                self._sock.sendto(p, GRUPPE)
        except OSError:
            pass
        if self._faden:
            self._faden.join(3)
        try:
            self._sock.close()
        except OSError:
            pass

    def _schleife(self):
        naechste = 0.0
        while not self._halt.is_set():
            if time.monotonic() >= naechste:
                try:
                    pakete = melden(self.uuid, self.ort)
                except Exception as fehler:
                    log.warning("SSDP-Meldung uebersprungen: %s", fehler)
                    pakete = []
                for p in pakete:
                    try:
                        self._sock.sendto(p, GRUPPE)
                    except OSError:
                        pass
                naechste = time.monotonic() + ALIVE_ABSTAND
            try:
                daten, absender = self._sock.recvfrom(4096)
            except socket.timeout:
                continue
            except OSError:
                if self._halt.is_set():
                    break
                time.sleep(1)
                continue
            try:
                antworten_liste = antworten(daten, self.uuid, self.ort)
            except Exception as fehler:
                log.warning("SSDP-Antwort uebersprungen: %s", fehler)
                antworten_liste = []
            for antwort in antworten_liste:
                time.sleep(random.uniform(0, 0.2))  # nicht alle Geraete gleichzeitig (MX)
                try:
                    self._sock.sendto(antwort, absender)
                except OSError:
                    pass


