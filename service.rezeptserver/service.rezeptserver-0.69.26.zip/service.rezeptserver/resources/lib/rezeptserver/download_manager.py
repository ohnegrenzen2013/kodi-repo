"""Nativer Downloader: direkte HTTP(S)-Adressen in eine Warteschlange legen und offline abspielen.

Drei Downloads laufen gleichzeitig, jeder in einem eigenen Faden und mit Fortschritt. Die Dateien liegen unter
`<Datenordner>/downloads`; die Oberflaeche kann sie ueber `/api/downloads/datei` abspielen. Fuer Streams mit
Zugangsdaten koennen Kopfzeilen mitgegeben werden. Private Adressen sind gesperrt (SSRF-Schutz).
"""

import os
import re
import secrets
import threading
import time
import urllib.error
import urllib.request
from urllib.parse import urljoin

from . import netz

MAX_JOBS = 50
MAX_DATEI = 20 * 1024 * 1024 * 1024
STUECK = 256 * 1024


class DownloadFehler(ValueError):
    pass


class DownloadManager:
    def __init__(self, datenordner, oeffnen=None, pruefen=None, gleichzeitig=3):
        self.ordner = os.path.join(datenordner or ".", "downloads")
        self.oeffnen = oeffnen or netz.oeffentlich_oeffnen
        self.pruefen = pruefen or netz.gepruefte_ips
        self.gleichzeitig = max(1, min(6, int(gleichzeitig or 3)))
        self.jobs = {}
        self._sperre = threading.Lock()
        self._frei = threading.Semaphore(self.gleichzeitig)

    def _name(self, name, url):
        name = re.sub(r"[^\w.()\[\] -]+", "_", str(name or "")).strip(" .")[:160]
        if not name:
            name = str(url).rstrip("/").rsplit("/", 1)[-1].split("?", 1)[0][:120] or "download"
        return name

    def start(self, url, name="", header=None):
        url = str(url or "").strip()
        if not url.lower().startswith(("http://", "https://")):
            raise DownloadFehler("Nur http:// und https://")
        self.pruefen(url)
        os.makedirs(self.ordner, exist_ok=True)
        ziel = os.path.join(self.ordner, self._name(name, url))
        nummer = 0
        while os.path.exists(ziel):
            nummer += 1
            basis, endung = os.path.splitext(self._name(name, url))
            ziel = os.path.join(self.ordner, "%s-%d%s" % (basis, nummer, endung))
        job = {"id": secrets.token_hex(8), "url": url, "name": os.path.basename(ziel), "pfad": ziel,
               "status": "wartet", "fortschritt": 0, "groesse": 0, "geladen": 0, "fehler": "", "abbrechen": False,
               "zeit": int(time.time())}
        with self._sperre:
            if len(self.jobs) >= MAX_JOBS:
                raise DownloadFehler("Zu viele Downloads in der Warteschlange")
            self.jobs[job["id"]] = job
        threading.Thread(target=self._lauf, args=(job, dict(header or {})), name="download-" + job["id"],
                         daemon=True).start()
        return dict(job)

    def _oeffnen(self, url, header):
        aktuell = url
        for _ in range(5):
            anfrage = urllib.request.Request(aktuell, headers={"User-Agent": "Rezeptserver/" + __import__(
                "rezeptserver").__version__, **header})
            try:
                return self.oeffnen(anfrage, timeout=30)
            except urllib.error.HTTPError as fehler:
                ziel = fehler.headers.get("Location") if fehler.headers else None
                fehler.close()
                if fehler.code in (301, 302, 303, 307, 308) and ziel:
                    aktuell = urljoin(aktuell, ziel)
                    self.pruefen(aktuell)
                    continue
                raise
        raise DownloadFehler("Zu viele Weiterleitungen")

    def _lauf(self, job, header):
        with self._frei:
            if job["abbrechen"]:
                job["status"] = "abgebrochen"
                return
            job["status"] = "läuft"
            try:
                with self._oeffnen(job["url"], header) as antwort:
                    laenge = antwort.headers.get("Content-Length") if hasattr(antwort, "headers") else None
                    job["groesse"] = int(laenge) if laenge and str(laenge).isdigit() else 0
                    with open(job["pfad"], "wb") as f:
                        while not job["abbrechen"]:
                            stueck = antwort.read(STUECK)
                            if not stueck:
                                break
                            f.write(stueck)
                            job["geladen"] += len(stueck)
                            if job["geladen"] > MAX_DATEI:
                                raise DownloadFehler("Datei größer als 20 GB")
                            job["fortschritt"] = round(job["geladen"] * 100.0 / job["groesse"]) if job["groesse"] else 0
                job["status"] = "abgebrochen" if job["abbrechen"] else "fertig"
                if job["abbrechen"]:
                    self._loeschen(job)
            except Exception as fehler:  # noqa: BLE001 – ein Download darf den Server nicht reissen
                job["status"] = "fehler"
                job["fehler"] = str(fehler)[:300]
                self._loeschen(job)

    @staticmethod
    def _loeschen(job):
        try:
            if os.path.exists(job["pfad"]):
                os.remove(job["pfad"])
        except OSError:
            pass

    def liste(self):
        with self._sperre:
            return [dict(j) for j in sorted(self.jobs.values(), key=lambda x: x["zeit"], reverse=True)]

    def stoppen(self, job_id):
        with self._sperre:
            job = self.jobs.get(job_id)
        if not job:
            raise DownloadFehler("Unbekannter Download")
        job["abbrechen"] = True
        return {"ok": True}

    def entfernen(self, job_id):
        with self._sperre:
            job = self.jobs.pop(job_id, None)
        if not job:
            raise DownloadFehler("Unbekannter Download")
        job["abbrechen"] = True
        self._loeschen(job)
        return {"ok": True}

    def datei(self, job_id):
        with self._sperre:
            job = self.jobs.get(job_id)
        if not job or job["status"] != "fertig" or not os.path.isfile(job["pfad"]):
            raise DownloadFehler("Datei nicht fertig")
        return job["pfad"], job["name"]
