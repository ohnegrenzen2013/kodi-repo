"""Bereich "Easynews": die Suche des Easynews-Members-Bereichs als eigener Tab, mit den gespeicherten Zugangsdaten.

Dieselben Zugangsdaten wie die Rezepte easynews-finder/-aufloeser (Nutzerdaten einstellungen.easynews: user, pass).
Gesucht wird ueber die Global-Search-API (members.easynews.com/2.0/search/solr-search/advanced), die auch die
Weboberflaeche nutzt: Art (Video, Audio, Bilder, Dokumente, Archive, alles), Sortierung (Relevanz, Groesse, neu),
Mindestaufloesung, Seiten. Abgespielt und geladen wird ueber H0rSt (Basic-Auth als Header, nur an easynews.com),
Vorschaubilder ebenso; das Passwort erreicht den Browser nie. Erwachsenen-Gruppen fallen ohne Ab-18-Freigabe weg.
"""

import base64
import json
import re
import time
from datetime import datetime
import urllib.error
import urllib.request
from urllib.parse import quote, urlencode, urlsplit

from .netz import USER_AGENT

KONTO = "easynews"
SUCHE = "https://members.easynews.com/2.0/search/solr-search/advanced"
MITGLIEDER = "https://members.easynews.com/3.0/"
ARTEN = {"VIDEO": "Videos", "AUDIO": "Musik", "IMAGE": "Bilder", "DOCUMENT": "Dokumente", "ARCHIVE": "Archive", "": "Alles"}
SORTIERUNGEN = {"relevanz": ("relevance", "dsize", "dtime"), "groesse": ("dsize", "relevance", "dtime"),
                "neu": ("dtime", "relevance", "dsize")}
AUFLOESUNGEN = {"": 0, "720p": 720, "1080p": 1080, "2160p": 2160}
PRO_SEITE = 50
_AB18 = re.compile(r"(?i)erotic|xxx|porn|pron|masturbat|bestial|incest|hentai|shemale|transsex|(?:^|\.)sex")
_HOEHE = re.compile(r"(?i)(2160|1080|720|576|480)p")
_GRUPPE = re.compile(r"^[A-Za-z0-9._+*-]{2,100}$")
GRUPPEN_SORT = {"anzahl": "meiste Treffer", "groesse": "größte Datenmenge", "name": "Name A–Z", "neu": "zuletzt aktiv"}
_HASH = re.compile(r"^[0-9A-Za-z]{10,64}$")


class EasynewsFehler(ValueError):
    pass


def zugang(daten):
    werte = (daten.get("einstellungen") or {}).get(KONTO) or {}
    return str(werte.get("user") or "").strip(), str(werte.get("pass") or "")


def kopf(benutzer, passwort):
    return {"Authorization": "Basic " + base64.b64encode(("%s:%s" % (benutzer, passwort)).encode("utf-8")).decode("ascii"),
            "User-Agent": USER_AGENT}


def _abruf(url, k, holen=None):
    if holen:
        return holen(url, k)
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers=k), timeout=30) as a:
            return a.read(16 * 1024 * 1024).decode("utf-8", "replace")
    except urllib.error.HTTPError as fehler:
        fehler.close()
        if fehler.code == 401:
            raise EasynewsFehler("Easynews lehnt Benutzer oder Passwort ab")
        raise EasynewsFehler("Easynews: HTTP %d" % fehler.code)
    except (urllib.error.URLError, OSError) as fehler:
        raise EasynewsFehler("Easynews nicht erreichbar: %s" % getattr(fehler, "reason", fehler))


def _bytes(eintrag):
    roh = eintrag.get("rawSize")
    if isinstance(roh, (int, float)) or str(roh or "").isdigit():
        return int(roh)
    m = re.match(r"\s*([\d.,]+)\s*([KMGT]?)B", str(eintrag.get("4") or ""), re.I)
    if not m:
        return 0
    return int(float(m.group(1).replace(",", ".")) * 1024 ** ("KMGT".index(m.group(2).upper()) + 1 if m.group(2) else 0))


def _hoehe(eintrag, name):
    voll = str(eintrag.get("fullres") or "")
    m = re.search(r"\d+\s*x\s*(\d+)", voll)
    if m:
        return int(m.group(1))
    m = _HOEHE.search(name)
    return int(m.group(1)) if m else 0


_DATUM = ("%d-%m-%Y %H:%M:%S", "%d-%m-%Y", "%Y-%m-%d %H:%M:%S", "%Y-%m-%d", "%m/%d/%Y %H:%M:%S", "%m/%d/%Y", "%d.%m.%Y %H:%M:%S", "%d.%m.%Y")
ALTER_STUFEN = {"": 0, "1": 1, "7": 7, "30": 30, "90": 90, "365": 365}


def _alter_tage(datum, jetzt=None):
    """Alter eines Treffers in Tagen aus dem Datumstext der Antwort; None, wenn das Format unbekannt ist."""
    text = str(datum or "").strip()
    for fmt in _DATUM:
        try:
            wann = datetime.strptime(text, fmt)
        except ValueError:
            continue
        return max(0.0, ((jetzt if jetzt is not None else time.time()) - wann.timestamp()) / 86400)
    return None


def _mb(wert, name):
    wert = str(wert or "").strip()
    if not wert:
        return 0
    if not wert.isdigit() or int(wert) > 10_000_000:
        raise EasynewsFehler("%s muss eine Zahl in MB sein" % name)
    return int(wert) * 1024 * 1024


def suchen(benutzer, passwort, text, art="VIDEO", sortierung="relevanz", aufloesung="", seite=1, ab18=False, holen=None,
           min_mb="", max_mb="", alter="", jetzt=None, gruppe=""):
    """Treffer [{hash, name, ext, groesse, dauer, gruppe, hoehe, codec, datum, art, stream}] und Seitenzahl.
    min_mb/max_mb/alter (Tage) filtern die gelieferte Seite zusaetzlich (Vorbild: die Felder Groesse und Alter der Basis-Suche).
    gruppe: Newsgroup-Filter (Parameter "ns" der Global-Search, wie in der Suchmaske und in Open-Source-Addons); dann darf der Text leer sein."""
    if not benutzer or not passwort:
        raise EasynewsFehler("Erst die Easynews-Zugangsdaten eintragen")
    text = " ".join(str(text or "").split())[:200]
    gruppe = str(gruppe or "").strip()
    if gruppe and not _GRUPPE.match(gruppe):
        raise EasynewsFehler("Gruppenname ungültig (Buchstaben, Ziffern, Punkt, Minus, Pluszeichen)")
    if len(text) < 2 and not gruppe:
        raise EasynewsFehler("Suchbegriff zu kurz")
    if art not in ARTEN or sortierung not in SORTIERUNGEN or aufloesung not in AUFLOESUNGEN:
        raise EasynewsFehler("Unbekannte Auswahl")
    seite = max(1, min(100, int(seite or 1)))
    kleinste, groesste = _mb(min_mb, "Mindestgröße"), _mb(max_mb, "Höchstgröße")
    alter = str(alter or "")
    if alter not in ALTER_STUFEN:
        raise EasynewsFehler("Unbekannte Auswahl")
    s1, s2, s3 = SORTIERUNGEN[sortierung]
    parameter = [("gps", text), ("st", "adv"), ("sb", "1"), ("spamf", "1"), ("u", "1"), ("gx", "1"),
                 ("pno", str(seite)), ("sS", "3"), ("s1", s1), ("s1d", "-"), ("s2", s2), ("s2d", "-"),
                 ("s3", s3), ("s3d", "-"), ("pby", str(PRO_SEITE))]
    if art:
        parameter.append(("fty[]", art))
    if gruppe:
        parameter.append(("ns", gruppe))
    roh = _abruf(SUCHE + "?" + urlencode(parameter), kopf(benutzer, passwort), holen)
    try:
        d = json.loads(roh)
    except ValueError:
        raise EasynewsFehler("Easynews antwortet unerwartet (kein JSON)")
    down = str(d.get("downURL") or "")
    host = re.sub(r"^(?:https?:)?//", "", down).strip("/")
    farm, port = str(d.get("dlFarm") or ""), str(d.get("dlPort") or "")
    mindest = AUFLOESUNGEN[aufloesung]
    treffer = []
    for e in d.get("data") or []:
        if not isinstance(e, dict):
            continue
        h, name, ext = str(e.get("0") or ""), str(e.get("10") or ""), str(e.get("11") or "")
        gruppe = str(e.get("9") or "")
        if not _HASH.match(h) or not name or e.get("virus") or e.get("passwd"):
            continue
        if not ab18 and (_AB18.search(gruppe) or _AB18.search(name)):
            continue
        hoehe = _hoehe(e, name)
        if mindest and hoehe < mindest:
            continue
        gr = _bytes(e)
        if (kleinste and gr < kleinste) or (groesste and gr > groesste):
            continue
        if ALTER_STUFEN[alter]:
            tage = _alter_tage(e.get("5"), jetzt)
            if tage is not None and tage > ALTER_STUFEN[alter]:
                continue
        stream = "https://%s/%s/%s/%s%s/%s%s" % (host, quote(farm, safe=""), quote(port, safe=""), quote(h, safe=""),
                                                 quote(ext, safe=""), quote(name, safe=""), quote(ext, safe="")) \
            if host and farm and port else ""
        treffer.append({"hash": h, "name": name, "ext": ext, "groesse": _bytes(e), "groesse_text": str(e.get("4") or ""),
                        "dauer": str(e.get("14") or ""), "gruppe": gruppe, "hoehe": hoehe,
                        "codec": str(e.get("12") or ""), "datum": str(e.get("5") or ""), "art": str(e.get("type") or art),
                        "stream": stream, "bild": _bild(d, h)})
    seiten = int(d.get("numPages") or d.get("pages") or 0) or (seite + 1 if len(d.get("data") or []) >= PRO_SEITE else seite)
    return {"treffer": treffer, "seite": seite, "seiten": seiten, "gesamt": int(d.get("results") or len(treffer))}


def _bild(d, h):
    """Vorschaubild (Easynews: <thumbURL><erste 3 Zeichen>/pr-<hash>.jpg), "" wenn die Antwort keinen Bildserver nennt."""
    basis = str(d.get("thumbURL") or "")
    if not basis:
        return ""
    if basis.startswith("//"):
        basis = "https:" + basis
    return "%s%s/pr-%s.jpg" % (basis if basis.endswith("/") else basis + "/", h[:3], h)


def erlaubt(url):
    """Nur Adressen bei easynews.com bekommen die Zugangsdaten."""
    host = (urlsplit(str(url or "")).hostname or "").lower()
    return urlsplit(str(url or "")).scheme == "https" and (host == "easynews.com" or host.endswith(".easynews.com"))


def gruppen_uebersicht(treffer, sortierung="anzahl"):
    """Treffer -> Newsgroups [{name, anzahl, groesse, neuestes}] (sortiert). Ohne Netz, nur Rechnung."""
    if sortierung not in GRUPPEN_SORT:
        raise EasynewsFehler("Unbekannte Sortierung")
    gruppen = {}
    for t in treffer:
        for name in [g for g in re.split(r"[\s,]+", str(t.get("gruppe") or "")) if g] or ["(ohne Gruppe)"]:
            g = gruppen.setdefault(name, {"name": name, "anzahl": 0, "groesse": 0, "neuestes": "", "_tage": None})
            g["anzahl"] += 1
            g["groesse"] += int(t.get("groesse") or 0)
            tage = _alter_tage(t.get("datum"))
            if tage is not None and (g["_tage"] is None or tage < g["_tage"]):
                g["_tage"], g["neuestes"] = tage, str(t.get("datum") or "")
    liste = list(gruppen.values())
    if sortierung == "name":
        liste.sort(key=lambda g: g["name"].lower())
    elif sortierung == "groesse":
        liste.sort(key=lambda g: (-g["groesse"], g["name"].lower()))
    elif sortierung == "neu":
        liste.sort(key=lambda g: (g["_tage"] is None, g["_tage"] or 0, g["name"].lower()))
    else:
        liste.sort(key=lambda g: (-g["anzahl"], g["name"].lower()))
    for g in liste:
        g.pop("_tage")
    return liste


def gruppen_suchen(benutzer, passwort, text, sortierung="anzahl", gruppe="", seiten=3, ab18=False, holen=None):
    """Gruppen durchsuchen: Treffer zu einem Suchwort (bis zu `seiten` Seiten a 50) nach Newsgroup zusammenfassen, oder
    mit gruppe=<Name> die Dateien dieser einen Gruppe. Dieselbe Global-Search-API wie suchen(); nur ein Konto, nichts anderes."""
    treffer, letzte = [], 1
    for seite in range(1, max(1, min(int(seiten), 3)) + 1):
        r = suchen(benutzer, passwort, text, art="", sortierung="neu" if sortierung == "neu" else "relevanz", seite=seite,
                   ab18=ab18, holen=holen, gruppe=gruppe)
        treffer.extend(r["treffer"])
        letzte = r["seiten"]
        if seite >= r["seiten"]:
            break
    return {"gruppen": gruppen_uebersicht(treffer, sortierung), "treffer": treffer if gruppe else [], "gesehen": len(treffer), "seiten": letzte}
