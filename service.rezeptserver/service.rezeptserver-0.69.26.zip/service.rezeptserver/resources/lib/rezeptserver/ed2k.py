"""eD2K/KAD-Links fuer Ember (Ember-P2P, eMule-kompatibel): sammeln, pruefen, an Ember uebergeben.

Ember (https://github.com/untaimed18/Ember-P2P) ist ein Desktop-Programm ohne Fernsteuerung, oeffnet aber
ed2k://-Links und .emulecollection-Dateien vom Betriebssystem, auch wenn es schon laeuft (mit Rueckfrage).
H0rSt sammelt solche Links (z. B. am Handy), zeigt Name, Groesse, Hash und Badges und gibt sie am PC per
Klick oder als .emulecollection an Ember weiter. Dazu: die aktuelle Ember-Version mit Download-Links.

Linkformate: ed2k://|file|<name>|<groesse>|<md4-hash>|[h=<aich>|][p=<teil-hashes>|][s=<quelle>|]/
             ed2k://|server|<ip>|<port>|/   ed2k://|serverlist|<adresse>|/
Nutzerdaten "ed2k": {"links": [{"name", "groesse", "hash", "aich", "link", "zeit"}]}
"""

import json
import re
import threading
import time
import urllib.request
from urllib.parse import quote, unquote

from .netz import USER_AGENT

SCHLUESSEL = "ed2k"
MAX_LINKS = 1000
RELEASES = "https://api.github.com/repos/untaimed18/Ember-P2P/releases/latest"
_DATEI = re.compile(r"ed2k://\|file\|([^|]+)\|(\d+)\|([0-9a-fA-F]{32})\|(.*?)/", re.I)
_SERVER = re.compile(r"ed2k://\|server\|([^|]+)\|(\d+)\|/", re.I)


class Ed2kFehler(ValueError):
    pass


def link_bauen(name, groesse, md4, aich=""):
    teile = ["ed2k://|file|%s|%d|%s|" % (quote(name, safe=" ()[]-_.,!'&+@#"), groesse, md4.upper())]
    if aich:
        teile.append("h=%s|" % aich)
    return "".join(teile) + "/"


def links_lesen(text):
    """Alle Datei-Links aus Text (auch .emulecollection im Textformat, auch zerlegte Zeilen)."""
    text = str(text or "").replace("\r", "")
    gefunden, gesehen = [], set()
    for m in _DATEI.finditer(text):
        name = unquote(m.group(1)).strip()
        groesse, md4 = int(m.group(2)), m.group(3).upper()
        if not name or groesse <= 0 or md4 in gesehen:
            continue
        aich = ""
        for zusatz in m.group(4).split("|"):
            if zusatz.lower().startswith("h=") and re.match(r"^[A-Z2-7]{32}$", zusatz[2:].upper()):
                aich = zusatz[2:].upper()
        gesehen.add(md4)
        gefunden.append({"name": name[:300], "groesse": groesse, "hash": md4, "aich": aich,
                         "link": link_bauen(name, groesse, md4, aich)})
    return gefunden


def server_lesen(text):
    return [{"adresse": m.group(1), "port": int(m.group(2))} for m in _SERVER.finditer(str(text or ""))]


def pruefe(roh):
    e = {"links": []}
    links = (roh or {}).get("links") if isinstance(roh, dict) else []
    for l in links if isinstance(links, list) else []:
        if isinstance(l, dict) and re.match(r"^[0-9A-F]{32}$", str(l.get("hash", ""))):
            e["links"].append({"name": str(l.get("name", ""))[:300], "groesse": int(l.get("groesse") or 0),
                               "hash": l["hash"], "aich": str(l.get("aich") or ""), "link": str(l.get("link", ""))[:2000],
                               "zeit": int(l.get("zeit") or 0)})
    if len(e["links"]) > MAX_LINKS:
        raise Ed2kFehler("Höchstens %d Links" % MAX_LINKS)
    return e


def sammlung(links):
    """.emulecollection im Textformat (eine Zeile je Link), wie eMule und Ember sie lesen."""
    return "\r\n".join(l["link"] for l in links) + "\r\n"


class Ember:
    """Neueste Ember-Version (GitHub), 6 Stunden zwischengespeichert."""

    def __init__(self, holen=None):
        self.holen = holen
        self._stand = (0, None)
        self._sperre = threading.Lock()

    def version(self):
        with self._sperre:
            zeit, daten = self._stand
        if daten and time.time() - zeit < 6 * 3600:
            return daten
        try:
            if self.holen:
                roh = self.holen(RELEASES)
            else:
                anfrage = urllib.request.Request(RELEASES, headers={"User-Agent": USER_AGENT, "Accept": "application/vnd.github+json"})
                with urllib.request.urlopen(anfrage, timeout=15) as a:
                    roh = a.read(512 * 1024).decode("utf-8")
            r = json.loads(roh)
            dateien = []
            for a in r.get("assets") or []:
                name = a.get("name", "")
                if name.endswith((".sig", ".json")):
                    continue
                art = "Windows" if name.endswith((".exe", ".msi")) else "Linux" if name.endswith((".deb", ".AppImage", ".rpm")) \
                    else "macOS" if name.endswith((".dmg", ".app.tar.gz")) else "Sonstige"
                dateien.append({"name": name, "art": art, "url": a.get("browser_download_url", ""), "groesse": a.get("size", 0)})
            daten = {"version": r.get("tag_name", ""), "datum": str(r.get("published_at", ""))[:10],
                     "seite": r.get("html_url", "https://github.com/untaimed18/Ember-P2P/releases"), "dateien": dateien, "fehler": ""}
        except Exception as fehler:
            daten = {"version": "", "datum": "", "seite": "https://github.com/untaimed18/Ember-P2P/releases", "dateien": [],
                     "fehler": str(fehler)[:200]}
        with self._sperre:
            self._stand = (time.time(), daten)
        return daten
