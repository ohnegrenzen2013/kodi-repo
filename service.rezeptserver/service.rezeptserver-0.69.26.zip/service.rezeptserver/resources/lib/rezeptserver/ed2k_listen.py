"""Server- und Kad-Listen fuer eD2K: server.met und nodes.dat hochladen, aus Quellen aktualisieren, weitergeben.

  * server.met (eD2K-Server): H0rSt sucht darueber (ed2k_suche.py). Quellen: emule-security.org und eigene
    Adressen; alle 3 Tage neu, auf Knopfdruck sofort.
  * nodes.dat (Kad-Knoten): Startpunkte fuer das serverlose Kad-Netz von eMule/Ember. H0rSt spricht Kad nicht
    selbst, haelt die Liste aber aktuell und gibt sie weiter.
  * Hochgeladene Listen (Datei aus eMule, aMule, Ember oder aus dem Netz) bleiben als "eigene" Eintraege stehen,
    Aktualisierungen ersetzen nur den geladenen Teil. Beide Teile zusammen ergeben die Liste.
  * Weitergeben: GET /api/ed2k/server.met und /api/ed2k/nodes.dat – in eMule/Ember unter "Aktualisieren von
    URL" eintragen, dann holen sie die Listen von H0rSt.
  * Der IP-Filter (Sicherheit) sortiert gesperrte Server und Knoten aus.

Nutzerdaten "ed2k_listen": {"server": {"standard": bool, "quellen": [urls]}, "kad": {...}}
"""

import json
import logging
import os
import socket
import struct
import threading
import time
import urllib.request

from . import ipfilter
from .netz import USER_AGENT

log = logging.getLogger("rezeptserver")

SCHLUESSEL = "ed2k_listen"
ERNEUERN = 3 * 24 * 3600
MAX_DATEI = 4 * 1024 * 1024
MAX_EINTRAEGE = 5000
MAX_QUELLEN = 10
ARTEN = ("server", "kad")


class ListenFehler(ValueError):
    pass


# --- nodes.dat --------------------------------------------------------------------------------
def nodes_lesen(d):
    """nodes.dat (Version 0, 1, 2 und 3/Bootstrap) -> [{id, adresse, udp, tcp, version, geprueft}]."""
    if len(d) < 8:
        raise ListenFehler("Keine nodes.dat")
    anzahl, i, version = struct.unpack_from("<I", d, 0)[0], 4, 0
    if anzahl == 0:
        version = struct.unpack_from("<I", d, 4)[0]
        i = 8
        if version == 3:  # Bootstrap-Liste: dahinter die Ausgabe
            i = 12
        if version not in (1, 2, 3) or len(d) < i + 4:
            raise ListenFehler("Unbekannte nodes.dat-Version %d" % version)
        anzahl = struct.unpack_from("<I", d, i)[0]
        i += 4
    groesse = 34 if version == 2 else 25
    if anzahl == 0 or anzahl > 100000 or len(d) < i + groesse:
        raise ListenFehler("Keine Knoten in der nodes.dat")
    knoten, gesehen = [], set()
    for _ in range(min(anzahl, MAX_EINTRAEGE)):
        if i + groesse > len(d):
            break
        ip, udp, tcp, art = struct.unpack_from("<IHHB", d, i + 16)
        adresse = socket.inet_ntoa(struct.pack(">I", ip))  # Kad speichert die Adresse in Rechner-Reihenfolge
        if ip and udp and (version > 0 or art < 4) and (adresse, udp) not in gesehen:
            gesehen.add((adresse, udp))
            knoten.append({"id": d[i:i + 16].hex().upper(), "adresse": adresse, "udp": udp, "tcp": tcp,
                           "version": art if version else 0, "geprueft": bool(version == 2 and d[i + 33])})
        i += groesse
    if not knoten:
        raise ListenFehler("Keine Knoten in der nodes.dat")
    return knoten


def nodes_bauen(knoten):
    """Knoten -> nodes.dat Version 2 (wie eMule 0.50+ sie schreibt)."""
    teile = [struct.pack("<III", 0, 2, len(knoten))]
    for k in knoten:
        ip = struct.unpack(">I", socket.inet_aton(k["adresse"]))[0]
        teile.append(bytes.fromhex(k["id"]) + struct.pack("<IHHB", ip, k["udp"], k.get("tcp") or k["udp"], k.get("version") or 0)
                     + b"\x00" * 8 + (b"\x01" if k.get("geprueft") else b"\x00"))
    return b"".join(teile)


# --- server.met -------------------------------------------------------------------------------
def servermet_bauen(server):
    """Server -> server.met (Kopf 0x0E, Name als Tag 0x01, Nutzer und Dateien wie eMule als "users"/"files")."""
    teile = [struct.pack("<BI", 0x0E, len(server))]
    for s in server:
        name = str(s.get("name") or s["adresse"]).encode("utf-8")[:200]
        tags = [struct.pack("<BHBH", 0x02, 1, 0x01, len(name)) + name]
        for schluessel, feld in ((b"users", "nutzer"), (b"files", "dateien")):
            if s.get(feld):
                tags.append(struct.pack("<BH", 0x03, len(schluessel)) + schluessel + struct.pack("<I", int(s[feld]) & 0xFFFFFFFF))
        teile.append(socket.inet_aton(s["adresse"]) + struct.pack("<HI", s["port"], len(tags)) + b"".join(tags))
    return b"".join(teile)


def _servermet_lesen(roh):
    from .ed2k_suche import SucheFehler, servermet_lesen
    try:
        return [s for s in servermet_lesen(roh) if s["port"]]
    except (SucheFehler, struct.error, IndexError, ValueError) as fehler:
        raise ListenFehler("Keine gültige server.met (%s)" % fehler)


# --- Listen -----------------------------------------------------------------------------------
class Liste:
    """Geladener Teil (aus Quellen, erneuert) plus eigener Teil (hochgeladen); gesperrte Adressen fallen weg."""
    ART = ""
    NAME = ""
    STANDARD_QUELLEN = []
    DATEI = ""
    FELD = "eintraege"

    def __init__(self, ordner, holen=None, uhr=time.time):
        self.ordner = ordner or "."
        self.pfad = os.path.join(self.ordner, self.DATEI)
        self.pfad_eigen = self.pfad.replace(".json", "_eigen.json")
        self.holen = holen
        self.uhr = uhr
        self.einstellung = {"standard": True, "quellen": []}
        self._sperre = threading.Lock()

    # Unterklassen: lesen(roh) -> Eintraege, bauen(eintraege) -> bytes, schluessel(eintrag)
    def lesen(self, roh):
        raise NotImplementedError

    def bauen(self, eintraege):
        raise NotImplementedError

    @staticmethod
    def schluessel(e):
        return e["adresse"], e.get("port") or e.get("udp")

    def ersatz(self):
        return []

    def quellen(self):
        return (list(self.STANDARD_QUELLEN) if self.einstellung["standard"] else []) + self.einstellung["quellen"]

    def _json(self, pfad):
        try:
            with open(pfad, encoding="utf-8") as f:
                d = json.load(f)
            return d if isinstance(d, dict) else {}
        except (OSError, ValueError):
            return {}

    def _schreiben(self, pfad, d):
        try:
            os.makedirs(self.ordner, exist_ok=True)
            with open(pfad + ".neu", "w", encoding="utf-8") as f:
                json.dump(d, f)
            os.replace(pfad + ".neu", pfad)
        except OSError as fehler:
            log.info("%s speichern: %s", self.NAME, fehler)

    def _geladen(self):
        d = self._json(self.pfad)
        return d, d.get(self.FELD) or []

    def _laden(self, url):
        if self.holen:
            return self.holen(url)
        anfrage = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
        with urllib.request.urlopen(anfrage, timeout=20) as a:
            return a.read(MAX_DATEI)

    def aktualisieren(self):
        """Die erste Quelle, die eine gueltige Liste liefert, ersetzt den geladenen Teil."""
        fehler = []
        for url in self.quellen():
            try:
                neu = self.lesen(self._laden(url))
                self._schreiben(self.pfad, {"zeit": int(self.uhr()), "quelle": url, self.FELD: neu[:MAX_EINTRAEGE]})
                return self.stand()
            except Exception as f:  # Netz oder Format: naechste Quelle
                log.info("%s %s: %s", self.NAME, url, f)
                fehler.append("%s: %s" % (url.split("/")[2] if "//" in url else url, str(f)[:120]))
        d, alt = self._geladen()
        self._schreiben(self.pfad, dict(d, versuch=int(self.uhr()), fehler=" · ".join(fehler) or "keine Quelle eingestellt"))
        if not self.quellen():
            return self.stand()
        raise ListenFehler("Keine Quelle hat eine gültige Liste geliefert: " + " · ".join(fehler))

    def eintraege(self, erneuern=False):
        """Eigene zuerst, dann geladene; ohne Doppelte und ohne vom IP-Filter gesperrte."""
        with self._sperre:
            d, geladen = self._geladen()
            faellig = self.uhr() - d.get("zeit", 0) > ERNEUERN and self.uhr() - d.get("versuch", 0) > 3600
            if erneuern or (faellig and self.quellen()):
                try:
                    self.aktualisieren()
                except ListenFehler:
                    pass
                d, geladen = self._geladen()
        eigene = self._json(self.pfad_eigen).get(self.FELD) or []
        alle, gesehen = [], set()
        for e in eigene + (geladen or (self.ersatz() if not eigene else [])):
            k = self.schluessel(e)
            if k not in gesehen and not ipfilter.gesperrt(e["adresse"]):
                gesehen.add(k)
                alle.append(e)
        return alle

    def hochladen(self, roh, ersetzen=True):
        """Datei als eigene Liste uebernehmen (ersetzen oder dazunehmen)."""
        if not roh:
            raise ListenFehler("Leere Datei")
        neu = self.lesen(bytes(roh[:MAX_DATEI]))
        with self._sperre:
            alt = [] if ersetzen else self._json(self.pfad_eigen).get(self.FELD) or []
            schon = {self.schluessel(e) for e in neu}
            liste = (neu + [e for e in alt if self.schluessel(e) not in schon])[:MAX_EINTRAEGE]
            self._schreiben(self.pfad_eigen, {"zeit": int(self.uhr()), self.FELD: liste})
        return dict(self.stand(), neu=len(neu))

    def eigene_leeren(self):
        try:
            os.remove(self.pfad_eigen)
        except OSError:
            pass
        return self.stand()

    def datei(self):
        return self.bauen(self.eintraege())

    def stand(self):
        d, geladen = self._geladen()
        eigene = self._json(self.pfad_eigen).get(self.FELD) or []
        roh = len({self.schluessel(e) for e in eigene + geladen})
        return {"art": self.ART, "name": self.NAME, "geladen": len(geladen), "eigene": len(eigene),
                "gesperrt": sum(1 for e in eigene + geladen if ipfilter.gesperrt(e["adresse"])), "gesamt": roh,
                "zeit": d.get("zeit", 0), "quelle": d.get("quelle", ""), "fehler": d.get("fehler", "") if d.get("versuch", 0) >= d.get("zeit", 0) else "",
                "standard": self.einstellung["standard"], "standard_quellen": list(self.STANDARD_QUELLEN),
                "quellen": list(self.einstellung["quellen"])}


class Serverliste(Liste):
    ART = "server"
    NAME = "server.met"
    STANDARD_QUELLEN = ["http://upd.emule-security.org/server.met"]
    DATEI = "ed2k_server.json"
    FELD = "server"

    def lesen(self, roh):
        return _servermet_lesen(roh)

    def bauen(self, eintraege):
        return servermet_bauen(eintraege)

    def ersatz(self):
        from .ed2k_suche import ERSATZ
        return list(ERSATZ)

    def server(self, erneuern=False):
        """Wie bisher (ed2k_suche): die Server zum Suchen."""
        return self.eintraege(erneuern)


class Kadliste(Liste):
    ART = "kad"
    NAME = "nodes.dat"
    STANDARD_QUELLEN = ["http://upd.emule-security.org/nodes.dat"]
    DATEI = "ed2k_kad.json"
    FELD = "knoten"

    def lesen(self, roh):
        return nodes_lesen(roh)

    def bauen(self, eintraege):
        return nodes_bauen(eintraege)


# --- Einstellungen ----------------------------------------------------------------------------
def _url(url):
    url = str(url or "").strip()
    if not url.startswith(("http://", "https://")) or len(url) < 12:
        raise ListenFehler("Adresse mit http(s)://")
    return url[:1000]


def pruefe(roh):
    roh = roh if isinstance(roh, dict) else {}
    e = {}
    for art in ARTEN:
        x = roh.get(art) if isinstance(roh.get(art), dict) else {}
        quellen = []
        for url in (x.get("quellen") or [])[:MAX_QUELLEN]:
            try:
                url = _url(url)
            except ListenFehler:
                continue
            if url not in quellen:
                quellen.append(url)
        e[art] = {"standard": x.get("standard") is not False, "quellen": quellen}
    return e


def anwenden(listen, einstellung):
    """{art: Liste} auf die gespeicherten Einstellungen setzen."""
    e = pruefe(einstellung)
    for art, liste in listen.items():
        liste.einstellung = e[art]
    return e


def aendern(daten, wunsch):
    """{art, quelle_dazu: url} | {art, quelle_weg: url} | {art, standard: bool} -> neue Einstellung."""
    if not isinstance(wunsch, dict) or wunsch.get("art") not in ARTEN:
        raise ListenFehler("art: server oder kad")
    e = pruefe(daten.get(SCHLUESSEL))
    x = e[wunsch["art"]]
    if "quelle_dazu" in wunsch:
        url = _url(wunsch["quelle_dazu"])
        if url in x["quellen"] or url in (Serverliste.STANDARD_QUELLEN + Kadliste.STANDARD_QUELLEN):
            raise ListenFehler("Diese Quelle ist schon eingetragen")
        if len(x["quellen"]) >= MAX_QUELLEN:
            raise ListenFehler("Höchstens %d eigene Quellen" % MAX_QUELLEN)
        x["quellen"].append(url)
    if "quelle_weg" in wunsch:
        x["quellen"] = [u for u in x["quellen"] if u != wunsch["quelle_weg"]]
    if "standard" in wunsch:
        x["standard"] = wunsch["standard"] is True
    daten[SCHLUESSEL] = e
    return e
