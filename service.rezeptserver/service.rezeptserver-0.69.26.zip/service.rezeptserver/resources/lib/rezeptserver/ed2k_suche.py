"""ed2k-Suche: Dateien im eD2K-Netz finden, wie eMule es ueber einen Server tut, und als ed2k-Links an Ember geben.

H0rSt meldet sich bei einem eD2K-Server an (TCP, eMule-Protokoll: OP_LOGINREQUEST), schickt die Suchanfrage
(OP_SEARCHREQUEST) und liest die Treffer (OP_SEARCHRESULT): Name, Groesse, MD4-Hash, Quellen, vollstaendige
Quellen, Laenge, Bitrate und Codec. Daraus werden ed2k://|file|...-Links. Geladen wird nichts und nichts
freigegeben (H0rSt bietet keine Dateien an, keine Verbindung zu anderen Nutzern); das Laden macht Ember.

Die Serverliste kommt aus einer server.met (wie bei eMule: aus Quellen erneuert oder hochgeladen, siehe
ed2k_listen.py), zwischengespeichert neben den Nutzerdaten, oder aus eigenen ed2k://|server|...-Links. Faellt ein Server aus, nimmt H0rSt den naechsten. Die Verbindung ist TCP und
laeuft deshalb auch ueber den Netzweg aus "Sicherheit" (Proxy/Tor), sofern der Server das zulaesst.

KAD (die serverlose Suche von eMule) spricht Ember selbst; H0rSt nutzt die Server-Suche, weil sie mit einer
einzigen Verbindung auskommt.
"""

import logging
import os
import socket
import struct
import time
import zlib

from . import ed2k_listen, ipfilter
from .ed2k import link_bauen

log = logging.getLogger("rezeptserver")

# falls keine server.met erreichbar ist: bekannte langlebige Server
ERSATZ = [{"name": "eMule Security", "adresse": "45.82.80.155", "port": 5687},
          {"name": "GrupoTS Server", "adresse": "46.105.126.71", "port": 4661}]
TYPEN = {"": "Alle", "Video": "Video", "Audio": "Audio", "Pro": "Programme", "Doc": "Dokumente",
         "Image": "Bilder", "Arc": "Archive", "Iso": "CD/DVD-Abbilder"}
MAX_TREFFER = 300
OP_EDONKEY, OP_GEPACKT = 0xE3, 0xD4
OP_LOGIN, OP_SERVERMESSAGE, OP_IDCHANGE, OP_SUCHE, OP_SUCHERGEBNIS = 0x01, 0x38, 0x40, 0x16, 0x33
# Tag-Kennungen
FT_NAME, FT_GROESSE, FT_TYP, FT_QUELLEN, FT_GROESSE_HI, FT_KOMPLETT = 0x01, 0x02, 0x03, 0x15, 0x3A, 0x30
FT_LAENGE, FT_BITRATE, FT_CODEC = 0xD3, 0xD4, 0xD5


class SucheFehler(ValueError):
    pass


# --- Tags lesen und schreiben ----------------------------------------------------------------
def tag_lesen(d, i):
    """Ein Tag (alte und neue Form) -> ((kennung, wert), naechste Position)."""
    typ = d[i]
    i += 1
    if typ & 0x80:  # neue Form: 1 Byte Kennung, kein Laengenfeld
        typ &= 0x7F
        kennung = d[i]
        i += 1
    else:
        laenge = struct.unpack_from("<H", d, i)[0]
        i += 2
        name = d[i:i + laenge]
        i += laenge
        kennung = name[0] if laenge == 1 else name.decode("latin-1")
    if typ == 0x02:      # Zeichenkette
        laenge = struct.unpack_from("<H", d, i)[0]
        wert = d[i + 2:i + 2 + laenge].decode("utf-8", "replace")
        i += 2 + laenge
    elif 0x11 <= typ <= 0x20:  # kurze Zeichenkette, Laenge im Typ
        laenge = typ - 0x10
        wert = d[i:i + laenge].decode("utf-8", "replace")
        i += laenge
    elif typ == 0x03:
        wert = struct.unpack_from("<I", d, i)[0]
        i += 4
    elif typ == 0x08:
        wert = struct.unpack_from("<H", d, i)[0]
        i += 2
    elif typ == 0x09:
        wert = d[i]
        i += 1
    elif typ == 0x0B:
        wert = struct.unpack_from("<Q", d, i)[0]
        i += 8
    elif typ == 0x04:
        wert = struct.unpack_from("<f", d, i)[0]
        i += 4
    elif typ == 0x01:
        wert = d[i:i + 16]
        i += 16
    elif typ == 0x05:
        wert = bool(d[i])
        i += 1
    elif typ == 0x07:
        laenge = struct.unpack_from("<I", d, i)[0]
        wert = d[i + 4:i + 4 + laenge]
        i += 4 + laenge
    elif typ == 0x06:
        bits = struct.unpack_from("<H", d, i)[0]
        i += 2 + (bits + 7) // 8
        wert = None
    else:
        raise SucheFehler("Unbekannter Tag-Typ 0x%02x" % typ)
    return (kennung, wert), i


def tags_lesen(d, i):
    anzahl = struct.unpack_from("<I", d, i)[0]
    i += 4
    tags = {}
    for _ in range(min(anzahl, 200)):
        (k, w), i = tag_lesen(d, i)
        tags[k] = w
    return tags, i


def _tag(kennung, wert):
    if isinstance(wert, str):
        roh = wert.encode("utf-8")
        return struct.pack("<BHB", 0x02, 1, kennung) + struct.pack("<H", len(roh)) + roh
    return struct.pack("<BHBI", 0x03, 1, kennung, wert)


def paket(opcode, nutzlast):
    return struct.pack("<BIB", OP_EDONKEY, len(nutzlast) + 1, opcode) + nutzlast


# --- Serverliste ------------------------------------------------------------------------------
def servermet_lesen(d):
    if not d or d[0] not in (0x0E, 0xE0):
        raise SucheFehler("Keine server.met")
    anzahl = struct.unpack_from("<I", d, 1)[0]
    i, server = 5, []
    for _ in range(min(anzahl, 2000)):
        ip = socket.inet_ntoa(d[i:i + 4])
        port = struct.unpack_from("<H", d, i + 4)[0]
        tags, i = tags_lesen(d, i + 6)
        name = tags.get(0x01) or tags.get("name") or ip
        nutzer = tags.get("users") or 0
        dateien = tags.get("files") or 0
        server.append({"name": str(name)[:80], "adresse": ip, "port": port,
                       "nutzer": int(nutzer) if isinstance(nutzer, int) else 0,
                       "dateien": int(dateien) if isinstance(dateien, int) else 0})
    server.sort(key=lambda s: -s["nutzer"])
    return server


# Serverliste: server.met aus Quellen, hochgeladen oder eigene (ed2k_listen.py), ohne vom IP-Filter gesperrte
Serverliste = ed2k_listen.Serverliste


# --- Verbindung -------------------------------------------------------------------------------
def _empfangen(s, puffer):
    """Ein Paket -> (opcode, nutzlast); entpackt 0xD4."""
    while len(puffer) < 5:
        teil = s.recv(65536)
        if not teil:
            raise SucheFehler("Server hat die Verbindung beendet")
        puffer.extend(teil)
    proto, laenge = struct.unpack_from("<BI", puffer, 0)
    if proto not in (OP_EDONKEY, OP_GEPACKT) or laenge < 1 or laenge > 16 * 1024 * 1024:
        raise SucheFehler("Unerwartete Antwort des Servers")
    while len(puffer) < 5 + laenge:
        teil = s.recv(65536)
        if not teil:
            raise SucheFehler("Server hat die Verbindung beendet")
        puffer.extend(teil)
    opcode, nutzlast = puffer[5], bytes(puffer[6:5 + laenge])
    del puffer[:5 + laenge]
    if proto == OP_GEPACKT:
        nutzlast = zlib.decompress(nutzlast)
    return opcode, nutzlast


def _anmelden_nutzlast():
    kennung = bytearray(os.urandom(16))
    kennung[5], kennung[14] = 14, 111  # so markiert eMule seine Nutzerkennung
    # Name, eD2K-Version 0x3C, Faehigkeiten (Kompression, neue Tags, Unicode, grosse Dateien) und eMule-Version
    # 0.70b: viele Server lehnen Clients ohne eMule-Version als "too old" ab
    tags = [_tag(0x01, "H0rSt"), _tag(0x11, 0x3C), _tag(0x20, 0x01 | 0x08 | 0x10 | 0x100),
            _tag(0xFB, (70 << 10) | (1 << 7))]
    return bytes(kennung) + struct.pack("<IHI", 0, 4662, len(tags)) + b"".join(tags)


def _suche_nutzlast(text, typ=""):
    roh = text.encode("utf-8")
    begriff = struct.pack("<BH", 0x01, len(roh)) + roh
    if not typ:
        return begriff
    wert = typ.encode("ascii")
    return b"\x00\x00" + begriff + struct.pack("<BH", 0x02, len(wert)) + wert + struct.pack("<HB", 1, FT_TYP)


def ergebnisse_lesen(d):
    anzahl = struct.unpack_from("<I", d, 0)[0]
    i, treffer = 4, []
    for _ in range(min(anzahl, MAX_TREFFER)):
        md4 = d[i:i + 16].hex().upper()
        tags, i = tags_lesen(d, i + 22)  # Hash, Client-ID (4), Port (2)
        name = str(tags.get(FT_NAME) or "")
        groesse = int(tags.get(FT_GROESSE) or 0) + (int(tags.get(FT_GROESSE_HI) or 0) << 32)
        if not name or groesse <= 0:
            continue
        laenge = tags.get(FT_LAENGE)
        treffer.append({"name": name[:300], "groesse": groesse, "hash": md4,
                        "quellen": int(tags.get(FT_QUELLEN) or 0), "komplett": int(tags.get(FT_KOMPLETT) or 0),
                        "typ": str(tags.get(FT_TYP) or ""), "laenge": int(laenge) if isinstance(laenge, int) else 0,
                        "bitrate": int(tags.get(FT_BITRATE) or 0) if isinstance(tags.get(FT_BITRATE), int) else 0,
                        "codec": str(tags.get(FT_CODEC) or ""), "link": link_bauen(name, groesse, md4)})
    return treffer


def suchen_bei(server, text, typ="", zeit=12.0, verbinden=socket.create_connection):
    """Anmelden, suchen, Treffer lesen. Gibt (treffer, meldung) zurueck."""
    ende = time.monotonic() + zeit
    s = verbinden((server["adresse"], server["port"]), timeout=min(8.0, zeit))
    meldung = ""
    try:
        s.sendall(paket(OP_LOGIN, _anmelden_nutzlast()))
        puffer = bytearray()
        angemeldet = False
        while time.monotonic() < ende:
            s.settimeout(max(0.5, ende - time.monotonic()))
            opcode, d = _empfangen(s, puffer)
            if opcode == OP_SERVERMESSAGE and len(d) >= 2:
                laenge = struct.unpack_from("<H", d, 0)[0]
                meldung = d[2:2 + laenge].decode("utf-8", "replace").strip()[:300]
            elif opcode == OP_IDCHANGE and not angemeldet:
                angemeldet = True
                s.sendall(paket(OP_SUCHE, _suche_nutzlast(text, typ)))
            elif opcode == OP_SUCHERGEBNIS and angemeldet:
                return ergebnisse_lesen(d), meldung
        raise SucheFehler("Keine Antwort in %d s" % zeit if angemeldet else "Anmeldung nicht bestätigt")
    finally:
        s.close()


class Ed2kSuche:
    def __init__(self, ordner, holen=None, verbinden=None):
        self.serverliste = Serverliste(ordner, holen)
        self.verbinden = verbinden
        self.letzter = None  # zuletzt erfolgreicher Server zuerst

    def suchen(self, text, typ="", eigene=None, versuche=4):
        text = " ".join(str(text or "").split())[:120]
        if len(text) < 3:
            raise SucheFehler("Suchbegriff zu kurz (mindestens 3 Zeichen)")
        if typ not in TYPEN:
            raise SucheFehler("Unbekannter Typ")
        liste = [s for s in eigene or [] if not ipfilter.gesperrt(s["adresse"])] + self.serverliste.server()
        if self.letzter:
            liste.sort(key=lambda x: (x["adresse"], x["port"]) != (self.letzter["adresse"], self.letzter["port"]))
        fehler = []
        for server in liste[:versuche]:
            try:
                weitere = {"verbinden": self.verbinden} if self.verbinden else {}
                treffer, meldung = suchen_bei(server, text, typ, **weitere)
                self.letzter = server
                treffer.sort(key=lambda t: (-t["komplett"], -t["quellen"]))
                return {"treffer": treffer, "server": server.get("name") or server["adresse"], "meldung": meldung}
            except (SucheFehler, OSError, struct.error, zlib.error, IndexError, ValueError) as f:
                fehler.append("%s: %s" % (server.get("name") or server["adresse"], str(f)[:120]))
        raise SucheFehler("Kein eD2K-Server hat geantwortet. " + " · ".join(fehler))
