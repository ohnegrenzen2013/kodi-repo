"""eD2K-Netz: aMule (Docker), Rucio und die Kad-Knoten in einem Zustand.

Vorbilder: ngosang/docker-amule (aMule 3.2 mit amuleapi auf Port 4711), ogarcia/rucio
(dezentrale Dateifreigabe mit Kad2-Bruecke, Webpanel 3003) und weskerty/aMuleD.bin
(aMuTorrent fuer Termux). H0rSt startet nichts selbst. Es prueft die lokalen Dienste,
baut die Docker-Befehle zum Nachlesen und zeigt die Kad-Liste aus `ed2k_listen.py`.

Ports: aMule 4711 (Web/API), 4712 (EC), 4662/TCP, 4665/UDP, 4672/UDP;
Rucio 3003 (Panel/API), 4321/TCP, 4662/TCP, 4672/UDP.
"""

import ipaddress
import json
import urllib.request
from urllib.parse import urlsplit

from .netz import USER_AGENT

NAME = "eD2K & Kad"
AMULE_REPO = "https://github.com/ngosang/docker-amule"
AMULE_IMAGE = "ghcr.io/ngosang/amule:latest"
AMULE_WEB = "http://127.0.0.1:4711"
RUCIO_REPO = "https://github.com/ogarcia/rucio"
RUCIO_WEB = "http://127.0.0.1:3003"
AMULED_REPO = "https://github.com/weskerty/aMuleD.bin"
LIZENZEN = {"amule": "GPL-2.0", "rucio": "GPL-3.0-or-later", "amuled": "AGPL-3.0"}
PORTS = {"web": 4711, "ec": 4712, "ed2k": 4662, "udp": 4665, "kad": 4672}


def _lokal(host):
    host = str(host or "").lower()
    if host == "localhost" or host.endswith(".local"):
        return True
    try:
        ip = ipaddress.ip_address(host)
    except ValueError:
        return False
    return ip.is_loopback or ip.is_private or ip.is_link_local


def _url(wert, standard):
    wert = str(wert or "").strip()
    if not wert:
        return standard
    try:
        teile = urlsplit(wert)
    except ValueError:
        return standard
    if teile.scheme not in ("http", "https") or not teile.hostname or not _lokal(teile.hostname):
        return standard
    return wert.rstrip("/")[:300]


def _port(wert, standard):
    try:
        port = int(str(wert).strip())
    except (TypeError, ValueError):
        return standard
    return port if 1 <= port <= 65535 else standard


def _holen(url, kopf=None, daten=None, zeitgrenze=1.5):
    """(status, inhalt) einer lokalen JSON-Adresse; (0, b"") wenn sie nicht antwortet."""
    header = {"User-Agent": USER_AGENT, "Accept": "application/json"}
    header.update(kopf or {})
    try:
        anfrage = urllib.request.Request(url, data=daten, headers=header)
        with urllib.request.urlopen(anfrage, timeout=zeitgrenze) as antwort:
            return int(getattr(antwort, "status", 0) or antwort.getcode() or 0), antwort.read(256 * 1024)
    except Exception:  # nicht erreichbar, kein HTTP, Zeitueberschreitung …
        return 0, b""


def _offen(url, zeitgrenze=0.6):
    import socket
    teile = urlsplit(url)
    try:
        port = teile.port or (443 if teile.scheme == "https" else 80)
        with socket.create_connection((teile.hostname, port), zeitgrenze):
            return True
    except (OSError, ValueError):
        return False


def _json(inhalt):
    try:
        d = json.loads((inhalt or b"").decode("utf-8"))
        return d if isinstance(d, dict) else {}
    except (ValueError, UnicodeDecodeError):
        return {}


def amule_zustand(werte=None, holen=None, offen=None, pruefen=False):
    """aMule-Web-API und Ports pruefen. Ohne pruefen=True wird nichts geklopft."""
    werte = werte if isinstance(werte, dict) else {}
    web = _url(werte.get("amule_web"), AMULE_WEB)
    ec = _port(werte.get("amule_ec"), PORTS["ec"])
    erreichbar, api, meldung, version = False, False, "", ""
    if pruefen:
        status, inhalt = (holen or _holen)(web + "/api/v1/status")
        daten = _json(inhalt)
        api = status in (200, 401, 403)
        erreichbar = api or (offen or _offen)(web)
        version = str(daten.get("version") or daten.get("data", {}).get("version") or "")[:40]
        if api and status == 200:
            meldung = "amuleapi antwortet" + (": " + version if version else ".")
        elif api:
            meldung = "amuleapi ist erreichbar, verlangt aber die Anmeldung (WEBUI_PWD)."
        elif erreichbar:
            meldung = "Der Port ist offen, aber /api/v1/status antwortet nicht wie erwartet."
        else:
            meldung = "aMule antwortet nicht. Laeuft der Container und ist Port %d erreichbar?" % PORTS["web"]
    else:
        meldung = "Nicht geprueft – aMule wird erst auf Knopfdruck abgefragt."
    return {"name": "aMule", "repo": AMULE_REPO, "lizenz": LIZENZEN["amule"], "web": web, "ec": ec,
            "erreichbar": erreichbar, "api": api, "version": version, "meldung": meldung,
            "ports": dict(PORTS), "start": docker_befehl(werte)}


def rucio_zustand(werte=None, holen=None, offen=None, pruefen=False):
    """Rucio-Panel und Status-API (/api/v1/status) pruefen."""
    werte = werte if isinstance(werte, dict) else {}
    web = _url(werte.get("rucio_web"), RUCIO_WEB)
    erreichbar, meldung, daten = False, "", {}
    if pruefen:
        status, inhalt = (holen or _holen)(web + "/api/v1/status")
        daten = _json(inhalt)
        erreichbar = status == 200 and bool(daten)
        if erreichbar:
            meldung = "Rucio ist erreichbar" + (": " + str(daten.get("version") or "")[:40] if daten.get("version") else "")
        else:
            status2, _ = (holen or _holen)(web + "/health")
            erreichbar = status2 == 200 or (offen or _offen)(web)
            meldung = ("Rucio ist erreichbar, die Status-API antwortet aber nicht." if erreichbar
                       else "Rucio antwortet nicht. Laeuft der Container und ist Port 3003 erreichbar?")
    else:
        meldung = "Nicht geprueft – Rucio wird erst auf Knopfdruck abgefragt."
    return {"name": "Rucio", "repo": RUCIO_REPO, "lizenz": LIZENZEN["rucio"], "web": web,
            "erreichbar": erreichbar, "peers": int(daten.get("connected_peers") or 0),
            "downloads": int(daten.get("active_downloads") or 0), "uploads": int(daten.get("active_uploads") or 0),
            "version": str(daten.get("version") or "")[:40], "meldung": meldung}


def docker_befehl(werte=None):
    """Docker-Befehl fuer aMule zum Nachlesen. Passwoerter stehen nur als Platzhalter darin."""
    werte = werte if isinstance(werte, dict) else {}
    ordner = str(werte.get("amule_ordner") or "/pfad/zu/.aMule")[:200]
    downloads = str(werte.get("amule_downloads") or "/pfad/zu/Downloads")[:200]
    return ("docker run -d --name amule -p 4711:4711 -p 4712:4712 -p 4662:4662 "
            "-p 4665:4665/udp -p 4672:4672/udp -e PUID=1000 -e PGID=1000 -e TZ=Europe/Berlin "
            "-e WEBUI_PWD=<passwort> -e GUI_PWD=<ec-passwort> "
            "-v \"%s\":/home/amule/.aMule -v \"%s\":/downloads --restart unless-stopped %s"
            % (ordner, downloads, AMULE_IMAGE))


def zustand(werte=None, kad=None, holen=None, offen=None, pruefen=False):
    """Alles fuer den eD2K-Bereich: aMule, Rucio, Kad-Liste und die Quellstaende."""
    werte = werte if isinstance(werte, dict) else {}
    kad = kad if isinstance(kad, dict) else {}
    return {"name": NAME, "an": werte.get("ed2knetz_an") is not False,
            "amule": amule_zustand(werte, holen=holen, offen=offen, pruefen=pruefen),
            "rucio": rucio_zustand(werte, holen=holen, offen=offen, pruefen=pruefen),
            "kad": kad, "amuled": {"name": "aMuTorrent (aMuleD.bin)", "repo": AMULED_REPO,
                                   "lizenz": LIZENZEN["amuled"],
                                   "hinweis": "Termux-Paket fuer Android mit Transmission und aMule im Watch-Ordner."},
            "hinweis": "H0rSt startet keine P2P-Programme. aMule und Rucio laufen als eigene Container, "
                       "Ember als eigenes Programm; H0rSt prueft nur, ordnet Kad-Knoten ein und reicht Links weiter."}
