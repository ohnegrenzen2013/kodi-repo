"""Eigene Quelle fuer Filme und Serien: eine Webseite per Adresse eintragen, H0rSt liest sie aus.

Nach dem Vorbild von ab18/seiten/eigene.py ("Eigene Seiten"), aber mit einem wichtigen Unterschied: H0rSt
spielt hier keinen gescrapten Videolink direkt ab. Stattdessen werden die gefundenen Titel gegen Cinemeta
abgeglichen (entdecken.Entdecken.aufloesen) und nur eindeutige Treffer als normale Karten gezeigt - die dann
ganz normal ueber die Detailseite und die vorhandene Multi-Provider-Suche laufen, wie jede andere Karte aus
Kataloge (xREL, MDBList-Listen, Streaming-Anbieter).

Ablauf: Listenseite abrufen -> Links mit Vorschaubild und Titel finden (ohne eigenes Muster: die groesste
Gruppe nach dem ersten Pfadsegment, das filtert Logos/Banner) -> Titel saeubern (entdecken.titel_bereinigen)
-> gegen Cinemeta abgleichen -> nur Treffer bis entdecken.MAX_STUFE zaehlen.

Gespeichert unter den Nutzerdaten "kataloge": {"quellen": [{"name", "url", "muster", "typ", "aktiv"}]} -
"kataloge", weil es derselbe Bereich wie Feeds/Listen ist (kataloge.py). "aktiv" (Standard an, Muster Ab18s
einstellungen["seiten"]-Checkbox-Zustand) entscheidet, ob eine Quelle an EigeneQuellen.suche() (gleichzeitige
Suche ueber alle aktiven eigenen Quellen, Muster Ab18._parallel()/suche()) teilnimmt.

Nur HTML-Listenseiten (keine JSON-APIs wie bei Ab 18). Private/interne Adressen sind immer gesperrt, ohne
Ausnahme (anders als bei Fremd-Addons gibt es hier keinen bekannten Anwendungsfall fuers Heimnetz).
Bot-Schranken (Cloudflare u. a.) werden nicht umgangen; solche Seiten melden einen Fehler.
"""

import html
import logging
import re
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import parse_qsl, quote, urlencode, urljoin, urlsplit, urlunsplit

from . import entdecken as entdecken_modul
from . import js_sandbox
from . import netz
from .netz import urllib_holen

log = logging.getLogger("rezeptserver")

SCHLUESSEL = "kataloge"
UNTER = "quellen"
MAX_QUELLEN = 12
MAX_KANDIDATEN = 24
MAX_SUCHTREFFER_JE_QUELLE = 12
ZEIT = 1800
TYPEN = ("auto", "movie", "series")
_MUSTER_LAENGE = 300
_LOKALER_HOST = re.compile(
    r"^(localhost|127\.\d{1,3}\.\d{1,3}\.\d{1,3}|10\.\d{1,3}\.\d{1,3}\.\d{1,3}|192\.168\.\d{1,3}\.\d{1,3}|"
    r"172\.(1[6-9]|2\d|3[01])\.\d{1,3}\.\d{1,3}|0\.0\.0\.0|\[?::1\]?)$", re.I)

# wie ab18/seiten/eigene.py - generische HTML-Muster, hier ohne Video-spezifischen Teil kopiert (Ab 18 bleibt unberuehrt)
_LINK = re.compile(r"<a\s([^>]*?)href\s*=\s*[\"']([^\"'#]+)[\"']([^>]*)>(.*?)</a>", re.I | re.S)
_BILD = re.compile(r"<img\s[^>]*?(?:data-src|data-original|data-thumb|data-lazy-src|data-mediumthumb|src)\s*=\s*[\"']([^\"']+\.(?:jpe?g|png|webp|gif)[^\"']*)[\"']", re.I)
_ATTR = re.compile(r"(?:title|alt|aria-label)\s*=\s*[\"']([^\"']{3,300})[\"']", re.I)
_SEITEN_PARAM = ("page", "p", "seite", "pg", "pagenum", "page_num", "start_page")


class KatalogFehler(ValueError):
    pass


def _ssrf_pruefen_host(url):
    host = urlsplit(url).hostname or ""
    if _LOKALER_HOST.match(host) or host.endswith(".local"):
        raise KatalogFehler("Private/interne Adressen sind nicht erlaubt")


def kandidaten_lesen(seite_html, basis, muster=None, suchtext=""):
    """Listenseite -> [{"roh", "titel", "jahr", "typ_hinweis", "bild", "link"}], hoechstens MAX_KANDIDATEN.
    Ohne eigenes Muster: Links nach dem ersten Pfadsegment gruppieren, nur die groesste Gruppe behalten.
    suchtext (optional): einfacher Teilstring-Filter auf den gesaeuberten Titel, nur eine Eingrenzung
    der schon gelesenen Kandidaten. Wird NACH der Gruppierung angewandt, sonst wuerde ein enger Suchbegriff
    die Erkennung der groessten (echten) Link-Gruppe verfaelschen. Eine erkannte Suchadresse der Seite
    (seiten_suche.py) steht getrennt in "suche" und wird von _eine_suchen() benutzt.

Optionales JS-Plugin statt der generischen Heuristik (NuvioMobile-Plan NV5b, braucht js_sandbox.py/
quickjs-rs - ohne installierte Sandbox liefert eine Quelle mit "js"-Feld einen klaren Fehler, keinen
Absturz): das Plugin definiert eine Funktion kandidaten(html, basisUrl) und liefert per JSON.stringify()
eine Liste [{"titel", "link"[, "bild"]}] - dieselbe Rolle wie kandidaten_lesen()s generische Gruppierung,
nur fuer Seiten, die die generische Heuristik nicht gut erkennt. Bewusst KEIN Netzzugriff aus dem Plugin
heraus (siehe js_sandbox.py): H0rSt hat die Seite schon selbst (SSRF-geprueft) abgerufen, das Plugin
bekommt nur ihren HTML-Text zur Auswertung. Ist "js" gesetzt, ersetzt es die generische Erkennung
vollstaendig - "muster" (das nur die generische Erkennung einschraenkt) bleibt dann ungenutzt."""
    host = (urlsplit(basis).hostname or "").lower().replace("www.", "")
    roh_muster = re.compile(muster, re.I) if muster else None
    treffer = []
    for m in _LINK.finditer(seite_html or ""):
        attribute, innen = m.group(1) + " " + m.group(3), m.group(4)
        bild = _BILD.search(innen)
        if not bild:
            continue
        ziel = urljoin(basis, html.unescape(m.group(2)).strip())
        zhost = (urlsplit(ziel).hostname or "").lower().replace("www.", "")
        if not ziel.startswith(("http://", "https://")) or (zhost != host and not zhost.endswith("." + host)):
            continue
        pfad, query = urlsplit(ziel).path, urlsplit(ziel).query
        if roh_muster and not roh_muster.search(pfad + ("?" + query if query else "")):
            continue
        titel_roh = _ATTR.search(attribute) or _ATTR.search(innen)
        titel_roh = html.unescape(titel_roh.group(1)).strip() if titel_roh else \
            " ".join(html.unescape(re.sub(r"<[^>]+>", " ", innen)).split())[:200]
        if not titel_roh:
            continue
        segment = pfad.strip("/").split("/", 1)[0] or "/"
        treffer.append((segment, ziel, titel_roh, urljoin(basis, html.unescape(bild.group(1)))))
    if not roh_muster and treffer:
        groessen = {}
        for segment, *_rest in treffer:
            groessen[segment] = groessen.get(segment, 0) + 1
        beste = max(groessen, key=groessen.get)
        treffer = [t for t in treffer if t[0] == beste]
    return _kandidaten_fertigstellen([(titel_roh, bild, ziel) for _segment, ziel, titel_roh, bild in treffer], suchtext)


def _kandidaten_fertigstellen(treffer, suchtext=""):
    """treffer: [(titel_roh, bild, link), ...], schon pfad-/host-geprueft. Saeubert den Titel (entdecken.
    titel_bereinigen), dedupliziert nach (titel, jahr), wendet den optionalen suchtext-Filter an, kappt bei
    MAX_KANDIDATEN. Gemeinsamer Abschluss fuer kandidaten_lesen() (generische Heuristik) und
    kandidaten_aus_js() (eigenes JS-Plugin, NV5b)."""
    suchtext = suchtext.strip().lower()
    gesehen, ergebnis = set(), []
    for titel_roh, bild, ziel in treffer:
        titel, jahr, typ_hinweis = entdecken_modul.titel_bereinigen(titel_roh)
        if not titel or (titel, jahr) in gesehen:
            continue
        if suchtext and suchtext not in titel.lower():
            continue
        gesehen.add((titel, jahr))
        ergebnis.append({"roh": titel_roh, "titel": titel, "jahr": jahr, "typ_hinweis": typ_hinweis,
                         "bild": bild, "link": ziel})
        if len(ergebnis) >= MAX_KANDIDATEN:
            break
    return ergebnis


def kandidaten_aus_js(seite_html, basis, js_code, suchtext=""):
    """Wie kandidaten_lesen(), aber die Erkennung kommt aus einem admin-eigenen JS-Plugin (NuvioMobile-
    Plan NV5b) statt aus der generischen Gruppierung - fuer Seiten, die die generische Heuristik nicht
    gut erkennt. Das Plugin definiert eine Funktion kandidaten(html, basisUrl) und liefert per
    JSON.stringify() eine Liste [{"titel", "link"[, "bild"]}] zurueck (js_sandbox.py: kein Netzzugriff
    aus dem Plugin heraus, nur Auswertung der schon abgerufenen Seite). Wirft KatalogFehler, wenn die
    Sandbox fehlt, das Plugin selbst einen Fehler wirft oder kein gueltiges Ergebnis liefert."""
    try:
        roh = js_sandbox.ausfuehren(js_code, "kandidaten", [seite_html, basis])
    except js_sandbox.JsSandboxFehler as fehler:
        raise KatalogFehler("JS-Plugin: %s" % fehler)
    if not isinstance(roh, list):
        raise KatalogFehler("JS-Plugin: kandidaten() muss eine Liste liefern")
    host = (urlsplit(basis).hostname or "").lower().replace("www.", "")
    treffer = []
    for eintrag in roh:
        if not isinstance(eintrag, dict):
            continue
        titel_roh = str(eintrag.get("titel") or "").strip()[:200]
        link_roh = str(eintrag.get("link") or "").strip()
        if not titel_roh or not link_roh:
            continue
        ziel = urljoin(basis, link_roh)
        zhost = (urlsplit(ziel).hostname or "").lower().replace("www.", "")
        if not ziel.startswith(("http://", "https://")) or (zhost != host and not zhost.endswith("." + host)):
            continue
        bild_roh = str(eintrag.get("bild") or "").strip()
        treffer.append((titel_roh, urljoin(basis, bild_roh) if bild_roh else "", ziel))
        if len(treffer) >= MAX_KANDIDATEN * 2:  # grobe Vorab-Deckelung, bevor Saeubern/Dedup laeuft
            break
    return _kandidaten_fertigstellen(treffer, suchtext)


# --- Seitenzahl erkennen (wie ab18/seiten/eigene.py) -------------------------------------------------------

def _seiten_vorlage(url):
    """{seite} in eine Adresse setzen, die schon eine Seitenzahl hat (?page=1, /2/, /page/3)."""
    t = urlsplit(url)
    teile = parse_qsl(t.query, keep_blank_values=True)
    for i, (k, v) in enumerate(teile):
        if k.lower() in _SEITEN_PARAM and v.isdigit():
            teile[i] = (k, "SEITE")
            return urlunsplit(t._replace(query=urlencode(teile))).replace("SEITE", "{seite}")
    m = re.search(r"(/(?:page/)?)(\d{1,4})(/?)$", t.path)
    if m and t.path.count("/") > 1:
        return urlunsplit(t._replace(path=t.path[:m.start(2)] + "{seite}" + t.path[m.end(2):]))
    return ""


def _naechste_seite(text, basis):
    """Adresse der zweiten Seite: rel=next, ein Link "2" oder "Next/Weiter/›/»"."""
    m = re.search(r"<(?:link|a)\s[^>]*rel\s*=\s*[\"']next[\"'][^>]*>", text or "", re.I)
    if m:
        h = re.search(r"href\s*=\s*[\"']([^\"']+)", m.group(0), re.I)
        if h:
            return urljoin(basis, html.unescape(h.group(1)))
    for m in _LINK.finditer(text or ""):
        innen = " ".join(re.sub(r"<[^>]+>", " ", m.group(4)).split()).lower()
        if innen in ("2", "next", "weiter", "nächste", "›", "»", "next page", "next »", "→"):
            return urljoin(basis, html.unescape(m.group(2)))
    return ""


def _vorlage_aus_zwei(erste, zweite):
    """Aus Seite 1 und Seite 2 die Vorlage mit {seite} machen."""
    if not zweite:
        return _seiten_vorlage(erste)
    v = _seiten_vorlage(zweite)
    if v:
        return v
    stellen = [m.start() for m in re.finditer(r"(?<!\d)2(?!\d)", zweite)]
    return zweite[:stellen[-1]] + "{seite}" + zweite[stellen[-1] + 1:] if stellen else ""


def _name(text, url):
    for muster in (r"<meta\s[^>]*property\s*=\s*[\"']og:site_name[\"'][^>]*content\s*=\s*[\"']([^\"']+)",
                   r"<meta\s[^>]*content\s*=\s*[\"']([^\"']+)[\"'][^>]*property\s*=\s*[\"']og:site_name",
                   r"<title[^>]*>([^<]{2,120})</title>"):
        m = re.search(muster, text or "", re.I)
        if m:
            name = re.split(r"\s+[-|–:•]\s+", html.unescape(m.group(1)).strip())
            return (min(name, key=len) if len(name) > 1 else name[0])[:40]
    return (urlsplit(url).hostname or "Quelle").replace("www.", "").split(".")[0].capitalize()


# --- Speichern und Validieren --------------------------------------------------------------------------

def quellen(daten):
    eigene = ((daten or {}).get(SCHLUESSEL) or {}).get(UNTER) or []
    # "aktiv"/"js" nachtragen: vor diesen Feldern gespeicherte Eintraege gelten als an bzw. ohne Plugin
    return [dict(q, aktiv=bool(q.get("aktiv", True)), js=str(q.get("js") or ""))
            for q in eigene if isinstance(q, dict) and q.get("url")]


def _eintrag_pruefen(roh):
    roh = roh if isinstance(roh, dict) else {}
    url = str(roh.get("url") or "").strip()[:500]
    if not re.match(r"^https?://[^\s/]+", url):
        raise KatalogFehler("Adresse mit http(s):// eingeben")
    if url.count("{seite}") > 1:
        raise KatalogFehler("{seite} darf höchstens einmal vorkommen")
    _ssrf_pruefen_host(url)
    suche = str(roh.get("suche") or "").strip()[:800]
    if suche:
        if not re.match(r"^https?://[^\s]+$", suche, re.I) or "{titel}" not in suche:
            raise KatalogFehler("Suchadresse mit http(s):// und {titel}")
        if suche.count("{titel}") > 1:
            raise KatalogFehler("{titel} darf in der Suchadresse höchstens einmal vorkommen")
        _ssrf_pruefen_host(suche)
    muster = str(roh.get("muster") or "").strip()[:_MUSTER_LAENGE]
    if muster:
        try:
            re.compile(muster)
        except re.error as fehler:
            raise KatalogFehler("Muster ungültig: %s" % fehler)
    typ = roh.get("typ") if roh.get("typ") in TYPEN else "auto"
    name = " ".join(str(roh.get("name") or "").split())[:60] or (urlsplit(url).hostname or "Quelle")
    aktiv = bool(roh.get("aktiv", True))  # Standard an; fehlt das Feld (z. B. aeltere Eintraege), gilt "an"
    js = str(roh.get("js") or "").strip()[:js_sandbox.MAX_CODE]  # optionales JS-Plugin (NV5b), kein Syntax-Check hier
    return {"name": name, "url": url, "suche": suche, "muster": muster, "typ": typ, "aktiv": aktiv, "js": js}


def aendern(e, wunsch):
    """{quelle_dazu: {name, url, muster?, typ?, aktiv?}} | {quelle_weg: url} - aufgerufen aus kataloge.aendern()."""
    liste = [q for q in (e.get(UNTER) or []) if isinstance(q, dict)]
    if isinstance(wunsch.get("quelle_dazu"), dict):
        neu = _eintrag_pruefen(wunsch["quelle_dazu"])
        vorhandene_urls = {q.get("url") for q in liste}
        if neu["url"] not in vorhandene_urls and len(liste) >= MAX_QUELLEN:
            raise KatalogFehler("Höchstens %d eigene Quellen" % MAX_QUELLEN)
        liste = [q for q in liste if q.get("url") != neu["url"]] + [neu]
    if "quelle_weg" in wunsch:
        liste = [q for q in liste if q.get("url") != wunsch["quelle_weg"]]
    e[UNTER] = liste
    return liste


def _kandidaten_fuer(eintrag, seite_html, ziel, suchtext=""):
    """Kandidaten einer eingetragenen Quelle lesen: ueber das JS-Plugin (eintrag["js"], NV5b), falls gesetzt,
    sonst ueber die generische Heuristik (kandidaten_lesen(), mit eintrag["muster"]). Gemeinsame Stelle fuer
    katalog() und _eine_suchen(), damit beide Aufrufer dieselbe Entscheidung treffen."""
    if eintrag.get("js"):
        return kandidaten_aus_js(seite_html, ziel, eintrag["js"], suchtext)
    return kandidaten_lesen(seite_html, ziel, eintrag.get("muster") or None, suchtext)


# --- Netz: erkennen (Vorschau, nichts wird gespeichert) und katalog (nur eingetragene Quellen) --------------

class EigeneQuellen:
    def __init__(self, holen=urllib_holen, entdecken=None, uhr=time.time):
        self.holen = holen
        self.entdecken = entdecken
        self.uhr = uhr
        self._speicher = {}
        self._sperre = threading.Lock()
        self._pool = ThreadPoolExecutor(max_workers=4, thread_name_prefix="eigenequelle")

    def _holen(self, url):
        _ssrf_pruefen_host(url)
        host = urlsplit(url).hostname or ""
        abrufer = netz.Abrufer([".".join(host.split(".")[-2:])], holen=netz.oeffentlich_holen(self.holen), zeitgrenze=15.0)
        return abrufer.abruf(url)

    def _aufloesen(self, kandidaten, typ):
        if not self.entdecken or not kandidaten:
            return [], [{"titel": k["titel"], "jahr": k["jahr"]} for k in kandidaten]
        auftraege = [(k, self._pool.submit(self.entdecken.aufloesen, k["titel"], k["jahr"],
                                           typ if typ != "auto" else (k["typ_hinweis"] or "")))
                    for k in kandidaten]
        treffer, verworfen, gesehen = [], [], set()
        for k, z in auftraege:
            try:
                r = z.result(timeout=15)
            except Exception as fehler:
                log.warning("Eigene Quelle: Titelabgleich fehlgeschlagen (%s): %s", k["titel"], fehler)
                r = None
            if r and r["id"] not in gesehen:
                gesehen.add(r["id"])
                treffer.append(dict(r, quelle="eigen"))
            elif not r:
                verworfen.append({"titel": k["titel"], "jahr": k["jahr"]})
        return treffer, verworfen

    def erkennen(self, url):
        """Adresse -> Vorschau {name, url, muster, typ, kandidaten, treffer, probe, verworfen, hinweise}.
        Speichert nichts."""
        url = str(url or "").strip()
        if not url.lower().startswith(("http://", "https://")):
            raise KatalogFehler("Adresse mit http(s):// eingeben")
        _ssrf_pruefen_host(url)
        try:
            text = self._holen(url)
        except netz.NetzFehler as fehler:
            raise KatalogFehler(str(fehler))
        kandidaten = kandidaten_lesen(text, url)
        hinweise = []
        if not kandidaten:
            hinweise.append("Auf dieser Seite fand H0rSt keine Film-/Serienlinks mit Vorschaubild – eine "
                            "Listenseite (z. B. „Neueste“) nehmen oder unten ein Muster angeben.")
        start = _vorlage_aus_zwei(url, _naechste_seite(text, url))
        if start and start.replace("{seite}", "1") != url and not _seiten_vorlage(url):
            hinweise.append("Seitenzahl erkannt: „%s“." % start)
        treffer, verworfen = self._aufloesen(kandidaten, "auto")
        if kandidaten:
            hinweise.append("%d von %d Titeln eindeutig erkannt." % (len(treffer), len(kandidaten)))
        return {"name": _name(text, url), "url": start or url, "muster": "", "typ": "auto",
                "kandidaten": len(kandidaten), "treffer": len(treffer), "probe": treffer[:8],
                "verworfen": verworfen[:10], "hinweise": hinweise}

    def katalog(self, url, daten, seite=1, suchtext=""):
        """Nur fuer eingetragene Quellen (wie Kataloge.feed): eine Seite als Karten, 30 Min. zwischengespeichert.
        suchtext (optional): grenzt die gelesenen Kandidaten dieser einen Quelle ein (siehe kandidaten_lesen())."""
        eintrag = next((q for q in quellen(daten) if q["url"] == url), None)
        if not eintrag:
            raise KatalogFehler("Diese Quelle erst eintragen")
        try:
            seite = max(1, int(seite or 1))
        except (TypeError, ValueError):
            seite = 1
        suchtext = str(suchtext or "").strip()[:200]
        schluessel = (url, seite, suchtext)
        with self._sperre:
            alt = self._speicher.get(schluessel)
            if alt and self.uhr() - alt[0] < ZEIT:
                return alt[1]
        if seite > 1 and "{seite}" not in url:
            raise KatalogFehler("Diese Quelle hat keine Seitenzahl")
        ziel = url.replace("{seite}", str(seite)) if "{seite}" in url else url
        try:
            text = self._holen(ziel)
        except netz.NetzFehler as fehler:
            raise KatalogFehler(str(fehler))
        kandidaten = _kandidaten_fuer(eintrag, text, ziel, suchtext)
        treffer, verworfen = self._aufloesen(kandidaten, eintrag.get("typ") or "auto")
        ergebnis = {"titel": treffer, "mehr": "{seite}" in url and bool(kandidaten), "weiter": seite + 1,
                    "name": eintrag["name"], "quelle": "Eigene Quelle · %s" % (urlsplit(url).hostname or ""),
                    "verworfen": len(verworfen)}
        with self._sperre:
            if len(self._speicher) > 200:
                self._speicher.clear()
            self._speicher[schluessel] = (self.uhr(), ergebnis)
        return ergebnis

    def _eine_suchen(self, eintrag, text):
        """Eine Quelle durchsuchen (erste Seite, mit suchtext eingegrenzt). Wirft nicht - Fehler laufen
        ueber suche()s eigenes Try/Except, damit eine kaputte Quelle die anderen nicht aufhaelt."""
        if eintrag.get("suche"):
            url = eintrag["suche"].replace("{titel}", quote(text))
            seite_html = self._holen(url)
            kandidaten = _kandidaten_fuer(eintrag, seite_html, url, "")
        else:
            url = eintrag["url"].replace("{seite}", "1") if "{seite}" in eintrag["url"] else eintrag["url"]
            seite_html = self._holen(url)
            kandidaten = _kandidaten_fuer(eintrag, seite_html, url, text)
        treffer, _verworfen = self._aufloesen(kandidaten, eintrag.get("typ") or "auto")
        return treffer[:MAX_SUCHTREFFER_JE_QUELLE]

    def suche(self, text, daten):
        """Gleichzeitige Suche ueber alle aktiven eigenen Quellen (Muster Ab18._parallel()/suche()): jede
        Quelle isoliert, eine kaputte/langsame Quelle haelt die anderen nicht auf."""
        text = " ".join(str(text or "").split())[:200]
        if not text:
            raise KatalogFehler("Suchbegriff fehlt")
        aktive = [q for q in quellen(daten) if q.get("aktiv", True)]
        if not aktive:
            return {"suche": text, "ergebnisse": []}

        def eine(eintrag):
            try:
                return {"url": eintrag["url"], "name": eintrag["name"], "fehler": "",
                        "titel": self._eine_suchen(eintrag, text)}
            except Exception as fehler:  # eine Quelle darf die anderen nicht aufhalten
                return {"url": eintrag["url"], "name": eintrag["name"], "fehler": str(fehler)[:300], "titel": []}

        with ThreadPoolExecutor(max_workers=min(8, len(aktive))) as pool:
            ergebnisse = list(pool.map(eine, aktive))
        return {"suche": text, "ergebnisse": ergebnisse}
