"""Einstellungen wie in ARVIO: Kategorien links, Zeilen mit Titel, Erklaerung und Wert rechts.

Das Schema hier ist die einzige Quelle: Die Oberflaeche baut die Seite daraus, der Server prueft damit.
Die Werte gelten fuer alle Geraete (Nutzerdaten), nur "Breit/Poster" und "Gesehene ausblenden" darf ein
Geraet zusaetzlich fuer sich umschalten.

Kategorien nach ARVIO: Sprachen, Wiedergabe & Steuerung, Darstellung, Telegram (Kommunikation), Anbieter & Addons
(der Anbieter-Bereich steht direkt hier), Verweise auf TV, Heimserver, Sicherheit, dazu Aktualisierung,
Datenschutz & Daten und Ueber.

Nutzerdaten: "oberflaeche": {schluessel: wert}; Sprachen bleiben wie bisher unter "sprachen": {"audio", "untertitel"}.
"""

from .einstellungen_grund import *
from .einstellungen_grund import _ZEILEN
from .einstellungen_navigation import eigene_tabs_pruefe, nav_liste, navigation_pruefe
from .einstellungen_werte import aendern, pruefe, standard, werte, _wert
from .einstellungen_ausschluss import ausschluss
