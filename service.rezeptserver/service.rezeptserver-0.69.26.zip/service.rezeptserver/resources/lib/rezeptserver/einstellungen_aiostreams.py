"""Einstellungen: eigene AIOStreams-Instanz fuer Stremio, ARVIO und Nuvio."""

AIOSTREAMS_KATEGORIE = {
    "id": "aiostreams", "name": "AIOStreams", "symbol": "🎬",
    "gruppe": "Verbindungen & Geräte", "eigen": True,
    "beschreibung": "Eine eigene AIOStreams-Instanz bündelt Stremio-Addons, Debrid und Usenet zu einem Addon. "
                    "H0rSt prüft die manifest.json, zeigt die Einrichtung und übernimmt sie als Stremio-Addon – "
                    "für Stremio, ARVIO, Nuvio Mobile und Nuvio TV.",
    "zeilen": [
        {"key": "aiostreams_an", "typ": "schalter", "titel": "AIOStreams anbieten",
         "standard": True,
         "hinweis": "Zeigt den AIOStreams-Helfer. Aus = keine Prüfung, Übernahme oder Installationsbefehle."},
        {"key": "aiostreams_basis", "typ": "text", "titel": "Basis-Adresse",
         "standard": "", "platzhalter": "https://aio.example.com",
         "hinweis": "Adresse der eigenen Instanz ohne /stremio/configure. Wird für Konfigurationsseite, Dashboard "
                    "und die Befehlsliste verwendet."},
        {"key": "aiostreams_manifest", "typ": "text", "titel": "Manifest-Adresse",
         "standard": "", "platzhalter": "https://aio.example.com/stremio/<uuid>/<passwort>/manifest.json",
         "hinweis": "Aus AIOStreams → Save & Install kopieren. Die Adresse enthält den verschlüsselten "
                    "Konfigurationstoken – wie ein Passwort behandeln. stremio:// geht auch."},
        {"key": "aiostreams_heimnetz", "typ": "schalter", "titel": "Auch im Heimnetz erlauben",
         "standard": False,
         "hinweis": "Erlaubt private/interne Adressen (192.168.x.x, 10.x.x.x, localhost), wenn AIOStreams auf "
                    "einem Rechner im eigenen Netz läuft. Ohne den Schalter sind solche Adressen gesperrt."},
    ],
}
