"""Ausschluss: kompilierte Regex fuer "Releases ausschliessen"."""

from .einstellungen_grund import (
    re,
)

def ausschluss(werte_):
    """Kompilierte Regex fuer "Releases ausschliessen" oder None."""
    muster = (werte_ or {}).get("ausschliessen") or ""
    try:
        return re.compile(muster, re.I) if muster else None
    except re.error:
        return None


