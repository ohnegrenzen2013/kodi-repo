"""Einstellungen fuer die lokale Bild-Datensatz-Pflege.

Vorbild: alex000kim/nsfw_data_scraper (MIT). Uebernommen wird nur der lokale
Ablauf – Kategorien als Ordner, kaputte Bilder aussortieren, Duplikate
erkennen, Testmenge abtrennen, train/test schreiben. Die Scraper- und
Download-Skripte des Vorbilds bleiben draussen; H0rSt laedt keine fremden
Bilder. Die Klassen sind frei einstellbar und standardmaessig neutral.
"""

BILDDATENSATZ_KATEGORIE = {
    "id": "bilddatensatz", "name": "Bild-Datensatz", "symbol": "🗂", "gruppe": "KI, Automatisierung & Backup", "eigen": True,
    "beschreibung": "Lokale Bilder pruefen, entdoppeln und als train/test fuer einen Bildfilter aufteilen – "
                    "nach dem lokalen Ablauf von NSFW Data Scraper. Kein Download, keine Url-Listen; nur eigene "
                    "oder lizenzierte Dateien.",
    "zeilen": [
        {"key": "bildds_an", "typ": "schalter", "titel": "Bild-Datensatz-Werkzeug anbinden", "standard": False,
         "hinweis": "Schaltet die Knoepfe unter dieser Seite frei. Ohne Schalter liest und schreibt H0rSt keine "
                    "Bildordner."},
        {"key": "bildds_quelle", "typ": "text", "titel": "Quellordner", "standard": "",
         "platzhalter": "/pfad/zu/bildern", "hinweis": "Darin liegen je Klasse Unterordner, z. B. neutral/ und drawings/. "
                                                       "H0rSt liest nur, was dort schon liegt."},
        {"key": "bildds_ziel", "typ": "text", "titel": "Zielordner", "standard": "",
         "platzhalter": "/pfad/zu/datensatz", "hinweis": "Dort entstehen train/ und test/ (Namen unten aenderbar). "
                                                         "Quelle und Ziel duerfen nicht ineinander liegen."},
        {"key": "bildds_klassen", "typ": "text", "titel": "Klassen", "standard": "neutral, drawings",
         "platzhalter": "neutral, drawings", "hinweis": "Ordnernamen unter Quelle und Ziel, mit Komma getrennt. Das "
                                                        "Vorbild nennt zusaetzlich sexy, porn und hentai; trage sie nur "
                                                        "fuer eigenes, lizenziertes Material ein."},
        {"key": "bildds_rekursiv", "typ": "schalter", "titel": "Unterordner mitlesen", "standard": True,
         "hinweis": "Auch Bilder in Unterordnern der Klassenordner einsammeln."},
        {"key": "bildds_versteckte", "typ": "schalter", "titel": "Versteckte Dateien mitlesen", "standard": False,
         "hinweis": "Dateien und Ordner, die mit einem Punkt beginnen."},
        {"key": "bildds_formate", "typ": "text", "titel": "Bildformate", "standard": "jpg, jpeg, png, webp",
         "platzhalter": "jpg, jpeg, png, webp, bmp", "hinweis": "Nur diese Endungen werden geprueft; die Datei muss "
                                                                 "auch einen passenden Bildkopf haben."},
        {"key": "bildds_min_kb", "typ": "text", "titel": "Kleinste Datei (KB)", "standard": "1", "platzhalter": "1",
         "hinweis": "0 erlaubt alles. Sehr kleine Dateien sind oft kaputt."},
        {"key": "bildds_max_mb", "typ": "text", "titel": "Groesste Datei (MB)", "standard": "50", "platzhalter": "50",
         "hinweis": "1 bis 2048 MB. Groessere Bilder werden uebersprungen."},
        {"key": "bildds_max_dateien", "typ": "text", "titel": "Hoechstens Dateien je Lauf", "standard": "20000",
         "platzhalter": "20000", "hinweis": "Schuetzt vor versehentlich riesigen Ordnern; 1 bis 200000."},
        {"key": "bildds_max_klasse", "typ": "text", "titel": "Hoechstens Bilder je Klasse", "standard": "0",
         "platzhalter": "0 = alle", "hinweis": "0 nimmt alle gefundenen Bilder einer Klasse."},
        {"key": "bildds_test_anzahl", "typ": "text", "titel": "Testbilder je Klasse", "standard": "1000",
         "platzhalter": "1000", "hinweis": "Wie im Vorbild: so viele Bilder wandern je Klasse nach test/, der Rest "
                                           "nach train/. 0 legt keine Testmenge an."},
        {"key": "bildds_aufteilen", "typ": "schalter", "titel": "Train/Test aufteilen", "standard": True,
         "hinweis": "Aus: alle Bilder landen in train/. Dann bleibt test/ leer."},
        {"key": "bildds_modus", "typ": "wahl", "titel": "Uebertragen", "standard": "kopieren",
         "werte": [["kopieren", "Kopieren (Originale bleiben)"], ["verschieben", "Verschieben (Quelle leeren)"]],
         "hinweis": "Verschieben loescht die Quelldatei erst, nachdem die Kopie geschrieben wurde."},
        {"key": "bildds_duplikate", "typ": "schalter", "titel": "Duplikate aussortieren", "standard": True,
         "hinweis": "Vergleicht den SHA-256-Inhalt aller gefundenen Bilder. Gleiche Bilder zaehlen nur einmal, "
                    "auch ueber Klassen hinweg."},
        {"key": "bildds_seed", "typ": "text", "titel": "Zufalls-Seed", "standard": "42", "platzhalter": "42",
         "hinweis": "Gleicher Seed, gleiche Auswahl – wichtig fuer vergleichbare Laeufe."},
        {"key": "bildds_probe", "typ": "schalter", "titel": "Nur Vorschau (nichts schreiben)", "standard": True,
         "hinweis": "Ab Werk an: H0rSt zaehlt und prueft nur. Erst ausschalten, wenn der Bericht passt."},
        {"key": "bildds_bericht", "typ": "text", "titel": "Berichtsdatei", "standard": "bericht.json",
         "platzhalter": "bericht.json", "hinweis": "Wird im Zielordner abgelegt, mit Zaehlern, Seed und Fehlern."},
        {"key": "bildds_train", "typ": "text", "titel": "Name der Trainingsmenge", "standard": "train",
         "platzhalter": "train", "hinweis": "Ordner unter dem Ziel."},
        {"key": "bildds_test", "typ": "text", "titel": "Name der Testmenge", "standard": "test",
         "platzhalter": "test", "hinweis": "Ordner unter dem Ziel."},
        {"key": "bildds_umbenennen", "typ": "schalter", "titel": "Bilder fortlaufend umbenennen", "standard": False,
         "hinweis": "000001.jpg, 000002.jpg … mit optionalem Praefix. Aus: Originalname bleibt, Kollisionen "
                    "bekommen -1, -2."},
        {"key": "bildds_prefix", "typ": "text", "titel": "Praefix beim Umbenennen", "standard": "",
         "platzhalter": "bild_", "hinweis": "Nur wenn umbenannt wird."},
    ],
}
