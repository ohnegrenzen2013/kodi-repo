"""Einstellungen fuer den Discord-Bildbot (Webhook, Kategorie, Menge und Freigabe)."""

from .discord_bot import KATEGORIEN

DISCORD_KATEGORIE = {
    "id": "discord", "name": "Discord-Bildbot", "symbol": "🤖", "gruppe": "Verbindungen & Geräte",
    "beschreibung": "Schickt Zufallsbilder aus dem Ab-18-Bereich an einen Discord-Webhook. Vorbild ist der Bot "
                    "VictorMoises/NSFW; H0rSt nutzt keinen Gateway-Bot und kopiert keinen fremden Code. "
                    "Nur fuer Kanaele mit Altersfreigabe, standardmaessig aus.",
    "zeilen": [
        {"key": "discord_an", "typ": "schalter", "titel": "Discord-Bildbot anbinden", "standard": False,
         "hinweis": "Ohne Schalter bleibt der Versand aus; die uebrigen Werte werden nur gespeichert."},
        {"key": "discord_webhook", "typ": "passwort", "titel": "Discord-Webhook-Adresse", "standard": "",
         "platzhalter": "https://discord.com/api/webhooks/…/…",
         "hinweis": "Kanal → Integrationen → Webhooks. Die Adresse ist ein Geheimnis und bleibt auf dem Server."},
        {"key": "discord_nsfw_bestaetigt", "typ": "schalter", "titel": "Nur in Kanaelen mit Altersfreigabe (18+)",
         "standard": False,
         "hinweis": "Muss eingeschaltet sein, sonst sendet H0rSt nichts. Der Kanal muss bei Discord als NSFW markiert sein."},
        {"key": "discord_prefix", "typ": "text", "titel": "Befehlswort im Beitrag", "standard": "nsfw ",
         "hinweis": "Steht vor dem Kategorienamen im Beitrag, wie beim Vorbild „nsfw “."},
        {"key": "discord_kategorie", "typ": "wahl", "titel": "Standard-Kategorie", "standard": "4k",
         "werte": [[k["id"], k["name"]] for k in KATEGORIEN]},
        {"key": "discord_anzahl", "typ": "wahl", "titel": "Bilder je Sendung", "standard": "1",
         "werte": [["1", "1"], ["2", "2"], ["3", "3"], ["5", "5"], ["10", "10"]]},
        {"key": "discord_text", "typ": "text", "titel": "Zusatztext zum Beitrag", "standard": "",
         "platzhalter": "optional"},
    ],
}
