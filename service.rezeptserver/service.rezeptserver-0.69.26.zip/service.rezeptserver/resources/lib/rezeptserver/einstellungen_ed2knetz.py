"""Einstellungen: eD2K-Netz (aMule, Rucio und Kad)."""

ED2KNETZ_KATEGORIE = {
    "id": "ed2knetz", "name": "eD2K & Kad", "symbol": "🐴",
    "gruppe": "Verbindungen & Geräte", "eigen": True,
    "beschreibung": "aMule und Rucio als eigene Container, dazu die Kad-Knotenliste. H0rSt prüft nur und "
                    "rechnet die Kad-Kennungen; gestartet wird nichts.",
    "zeilen": [
        {"key": "ed2knetz_an", "typ": "schalter", "titel": "eD2K-Netz anzeigen",
         "standard": True,
         "hinweis": "Zeigt im Ember-Bereich aMule, Rucio, aMuTorrent und die Kad-Tabelle mit den nächsten Knoten."},
        {"key": "amule_web", "typ": "text", "titel": "aMule Web/API",
         "standard": "http://127.0.0.1:4711", "platzhalter": "http://192.168.1.20:4711",
         "hinweis": "amuleapi aus ngosang/docker-amule. H0rSt fragt /api/v1/status ab; Anmeldedaten werden nicht gespeichert."},
        {"key": "rucio_web", "typ": "text", "titel": "Rucio-Panel",
         "standard": "http://127.0.0.1:3003", "platzhalter": "http://192.168.1.20:3003",
         "hinweis": "Webpanel und API von ogarcia/rucio; H0rSt liest /api/v1/status."},
        {"key": "kad_id", "typ": "text", "titel": "Eigene Kad-Kennung",
         "standard": "", "platzhalter": "leer = feste H0rSt-Kennung",
         "hinweis": "Optional 32 Hex-Zeichen. Nur für die Anzeige der k-Buckets und der nächsten Knoten; "
                    "H0rSt tritt dem Kad-Netz nicht bei."},
    ],
}
