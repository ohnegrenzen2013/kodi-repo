"""Einstellungen fuer Ember-P2P: Anbindung ein- und ausschalten.

Ember-P2P (untaimed18/Ember-P2P, GPL-3.0) ist die eMule-kompatible P2P-App mit
eD2K, KAD und eigenem Ember-Netz. H0rSt bringt sie im Reiter "Ember" bereits
vollstaendig unter (ed2k-Links, eD2K-Suche, Start/Stopp, Fortschritt,
Einstellungen, server.met/nodes.dat/ipfilter.dat). Dieser Schalter blendet den
Reiter aus und sperrt die Steuerungs-API, wenn Ember nicht genutzt werden soll.
"""

EMBERP2P_KATEGORIE = {
    "id": "emberp2p", "name": "Ember-P2P", "symbol": "🔥", "gruppe": "Verbindungen & Geräte", "eigen": True,
    "beschreibung": "Ember-P2P (GPL-3.0) ist die eMule-kompatible P2P-App mit eD2K, KAD und eigenem Ember-Netz. "
                    "H0rSt sammelt ed2k-Links, sucht im eD2K-Netz und steuert Ember auf demselben Rechner. "
                    "Hier schaltest du den Reiter und die Steuerung ein oder aus.",
    "verweis": "ember",
    "text": "Der Reiter Ember enthält die eD2K-Suche, die Link-Sammlung, Start/Stopp, den Fortschritt, die "
            "Ember-Einstellungen und die Uebergabe von server.met, nodes.dat und ipfilter.dat.",
    "zeilen": [
        {"key": "emberp2p_an", "typ": "schalter", "titel": "Ember-P2P anzeigen", "standard": True,
         "hinweis": "Aus: der Reiter Ember wird ausgeblendet und die Steuerungs-API /api/ember/steuerung "
                    "antwortet nicht mehr. Gespeicherte Links und Embers eigene Dateien bleiben unberuehrt."},
    ],
}
