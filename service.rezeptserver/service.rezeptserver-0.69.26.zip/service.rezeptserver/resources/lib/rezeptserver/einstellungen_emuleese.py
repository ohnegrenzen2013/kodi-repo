"""Einstellungen fuer eMule eSE LiveTV: Dashboard, Status-API und RTMP-Eingang.

eMule eSE (diad87/eMule-eSE-LiveTV, GPL-2.0) ist ein eMule-0.70b-Zweig fuer
dezentrales Live-Streaming ueber eD2K und Kad. Das portable Windows-x64-Paket
startet ein lokales Dashboard auf 127.0.0.1:8080/live und eine Status-API auf
127.0.0.1:4711. H0rSt startet eSE nicht selbst; es merkt sich die Adressen,
prueft die Erreichbarkeit und oeffnet das Dashboard als Portal-Reiter.
"""

EMULEESE_KATEGORIE = {
    "id": "emuleese", "name": "eSE LiveTV", "symbol": "🐴", "gruppe": "Verbindungen & Geräte", "eigen": True,
    "beschreibung": "eMule eSE (GPL-2.0) sendet Live-TV ueber eD2K und Kad. Hier schaltest du die Anbindung "
                    "ein, traegst Dashboard, Status-API und RTMP-Port ein und oeffnest das Dashboard im Portal. "
                    "H0rSt startet eSE nicht und laedt keine fremden Streams.",
    "zeilen": [
        {"key": "emuleese_an", "typ": "schalter", "titel": "eSE LiveTV anbinden", "standard": False,
         "hinweis": "Zeigt den eSE-Block in den Einstellungen, prueft das Dashboard und bietet den Portal-Reiter an. "
                    "Ohne Schalter bleibt alles wie bisher; H0rSt oeffnet dann auch keinen eSE-Reiter."},
        {"key": "emuleese_dashboard", "typ": "text", "titel": "Dashboard-Adresse", "standard": "http://127.0.0.1:8080/live",
         "platzhalter": "http://127.0.0.1:8080/live",
         "hinweis": "Standard im eSE-Paket: http://127.0.0.1:8080/live. Laeuft eSE auf einem anderen Rechner im "
                    "Heimnetz, hier dessen Adresse eintragen."},
        {"key": "emuleese_api", "typ": "text", "titel": "Status-API", "standard": "http://127.0.0.1:4711",
         "platzhalter": "http://127.0.0.1:4711",
         "hinweis": "Die native eSE-Status-API. H0rSt klopft nur den Port ab, weil die API ein lokales Token "
                    "verlangt; Zugangsdaten werden nicht gespeichert."},
        {"key": "emuleese_rtmp", "typ": "text", "titel": "RTMP-Eingang", "standard": "1935",
         "platzhalter": "1935",
         "hinweis": "Port fuer OBS und andere RTMP-Quellen. Nur noetig, wenn OBS auf einem anderen Rechner laeuft; "
                    "H0rSt oeffnet den Port nicht."},
    ],
}
