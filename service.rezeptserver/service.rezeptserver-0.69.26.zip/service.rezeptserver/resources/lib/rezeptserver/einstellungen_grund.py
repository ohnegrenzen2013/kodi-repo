"""Einstellungen der Oberflaeche: Kategorien, Navigation, eigene Tabs und Wertepruefung.
Grundlage: Konstante, Fehlerklasse und Importe (rezeptserver.einstellungen.*)."""


import re

from .einstellungen_kategorien import KATEGORIEN, SPRACHEN

SCHLUESSEL = "oberflaeche"

# Navigation: Reihenfolge und Sichtbarkeit aller Tabs und Gruppenueberschriften (g:...), frei einstellbar
NAV = [("start", "Start"), ("apps", "Apps (nur App)"), ("g:sehen", "Überschrift „Sehen“"), ("filme", "Filme"),
       ("serien", "Serien"), ("nuvio", "Nuvio"), ("livetv", "Live-TV"), ("youtube", "YouTube"), ("radio", "Radio"), ("kodiaddons", "Kodi"), ("gamehub", "GameHub"), ("brause", "Brause"), ("lesehalle", "Lesehalle (nur App)"), ("portal", '("_• )—* Portal'), ("ab18", "Ab 18"),
       ("g:party", "Überschrift „Party“"), ("gemeinsam", "Gemeinsam schauen"), ("daumenkino", "Daumenkino"), ("localdream", "LocalDream"), ("videowerkstatt", "Videowerkstatt"), ("karaoke", "Karaoke"),
       ("g:laden", "Überschrift „Finden & Laden“"), ("dateisuche", "Dateisuche"), ("easynews", "Easynews"), ("usenet", "Usenet-Stream"),
       ("dienste", "Herunterladen"), ("xdcc", "XDCC"), ("ember", "Ember"), ("g:zuhause", "Überschrift „Zuhause“"),
       ("heim", "Heim"), ("kameras", "Kameras"), ("videochat", "Videochat"), ("licht", "Smart Home"), ("webhosting", "Webhosting"), ("vx", "vxparser"), ("g:einrichten", "Überschrift „Einrichten“"),
       ("einstellungen", "Einstellungen"), ("sicherheit", "Sicherheit"), ("tresor", "Tresor")]
NAV_PFLICHT = ("einstellungen",)
# Eigene Tabs: eine App auf dem Geraet starten (Android), eine Weboberflaeche einbetten oder ein Kodi-Addon (plugin://…) zeigen
EIGENE_STANDARD = [
    {"id": "horus", "name": "Horus", "art": "app", "ziel": "com.scariflabs.horus", "symbol": "𓂀",
     "laden": "https://f-droid.org/packages/com.scariflabs.horus/",
     "text": "Alpine-Linux-Arbeitsplatz für Coding-Agenten (Claude Code, Codex, OpenCode) auf dem Handy."},
]
EIGENE_VORLAGEN = EIGENE_STANDARD + [
    {"id": "homeassistant", "name": "Home Assistant", "art": "web", "ziel": "http://homeassistant.local:8123", "symbol": "🏠",
     "text": "Smart Home"},
    {"id": "jellyfin", "name": "Jellyfin", "art": "web", "ziel": "http://jellyfin.local:8096", "symbol": "🎞", "text": "Mediathek"},
    # Emby (emby.media): Weboberflaeche des eigenen Servers (Port 8096) oder die Emby-App auf dem Geraet
    {"id": "emby", "name": "Emby", "art": "web", "ziel": "http://emby.local:8096/web/index.html", "symbol": "🟢", "text": "Mediathek (Emby-Server)"},
    {"id": "embyapp", "name": "Emby-App", "art": "app", "ziel": "com.mb.android", "symbol": "🟢",
     "laden": "https://play.google.com/store/apps/details?id=com.mb.android", "text": "Emby für Android"},
]
MAX_EIGENE = 40  # bleibt immer sichtbar, sonst kaeme man nicht mehr zurueck
AKZENTE = {"gruen": ("#00d588", "#00160d"), "blau": ("#3d9bff", "#00122b"), "violett": ("#a77bff", "#14002e"),
           "pink": ("#ff5fa8", "#2b0016"), "rot": ("#ff5a5a", "#2b0000"), "orange": ("#ff9d3d", "#2b1300"),
           "gelb": ("#ffd23d", "#2b2200")}
_ZEILEN = {z["key"]: z for k in KATEGORIEN for z in k.get("zeilen", [])}
MAX_TEXT = 300


class EinstellungsFehler(ValueError):
    pass
