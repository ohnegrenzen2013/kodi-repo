"""Heim-Styles, Super-Heim-Brett und Tastatur-Schemata (Einstellungen → Darstellung und → Bedienung & Tasten).

  * Heim-Style: klassisch, warm, elegant, futuristisch, Super Heim, die zweiundzwanzig [ "Name" @ H0rSt ] (ARVIO, Stremio, Nuvio,
    StreamCloud, ROGplay, Vyxel Apps, Jellyfin, Winlator, MT Manager, Web Video Caster, Netflix, MX Player, Goon, Open Generative AI,
    Opera GX, NOVA, GNUnet, MagicWX, Shizuku, Ember-P2P, eSE LiveTV, OmniSearch) oder Kodi-Skin (Zeile "stil" in Darstellung);
    beim Kodi-Skin sagt "kodiskin" {id, schema, hintergrund}, welcher Skin (kodi_addons/skins.py).
  * Brett (nur Super Heim): bis zu 9 Fenster auf einem 3×3-Brett, je {id, bereich, kat, x, y, w, h, farbe}.
    Jeder Bereich steht hoechstens einmal darauf; ein leeres Fenster (bereich "") fragt, was hinein soll.
  * Tasten: Aktion -> Tasten (bis zu 3). Schemata Fernbedienung, Tastatur und Zahlen sind fest, "eigenes" frei
    belegbar. Tasten heissen wie KeyboardEvent.key, mit Ctrl+/Alt+/Shift+ davor, z. B. "Alt+1", "ColorF0Red".

Nutzerdaten unter "oberflaeche": "brett": [...], "tasten": {aktion: [tasten]} (nur fuer das eigene Schema).
"""

import re

from .einstellungen_grund import EinstellungsFehler

FARBEN = ("", "rot", "gruen", "gelb", "blau")
MAX_FENSTER = 9
# die Bereiche der Oberflaeche (Element-ids), die ein Fenster aufnehmen kann
BEREICHE = ("start", "apps", "suche", "livetv", "youtube", "radio", "kodiaddons", "gamehub", "brause", "lesehalle", "portal", "ab18", "gemeinsam", "daumenkino", "localdream", "karaoke", "dateisuche", "easynews", "usenet",
            "dienste", "xdcc", "ember", "nuvio", "heim", "kameras", "videochat", "licht", "webhosting", "vx", "eigentab",
            "einstellungen", "sicherheit")
# Aktion: (Name, Gruppe)
AKTIONEN = {
    "suche": ("Optionen-Suche öffnen", "Allgemein"), "sprechen": ("H0rSt hört zu (Sprachbefehl)", "Allgemein"),
    "start": ("Zum Start", "Allgemein"), "filme": ("Filme", "Allgemein"), "serien": ("Serien", "Allgemein"),
    "stil": ("Heim-Style wechseln", "Allgemein"),
    "rot": ("Rotes Fenster", "Super Heim"), "gruen": ("Grünes Fenster", "Super Heim"),
    "gelb": ("Gelbes Fenster", "Super Heim"), "blau": ("Blaues Fenster", "Super Heim"),
    "farbe": ("Farbe des aktiven Fensters wechseln", "Super Heim"), "naechstes": ("Nächstes Fenster", "Super Heim"),
    "links": ("Fenster links andocken", "Super Heim"), "rechts": ("Fenster rechts andocken", "Super Heim"),
    "oben": ("Fenster oben andocken", "Super Heim"), "unten": ("Fenster unten andocken", "Super Heim"),
    "voll": ("Fenster ganz groß", "Super Heim"), "breite": ("Schmal / breit umschalten", "Super Heim"),
    "hoehe": ("Flach / hoch umschalten", "Super Heim"), "teilen": ("Fenster teilen (✂)", "Super Heim"),
    "neu": ("Neues Fenster", "Super Heim"), "schliessen": ("Fenster schließen", "Super Heim"),
}
for _n in range(1, 10):
    AKTIONEN["fenster%d" % _n] = ("Fenster %d" % _n, "Super Heim")
_FARBTASTEN = {"rot": ["ColorF0Red"], "gruen": ["ColorF1Green"], "gelb": ["ColorF2Yellow"], "blau": ["ColorF3Blue"]}
SCHEMATA = {
    "fernbedienung": dict({"suche": ["BrowserSearch", "/", "Ctrl+K"], "sprechen": ["MediaRecord", "F2"], "start": ["Home", "BrowserHome"],
                           "naechstes": ["ChannelUp", "MediaTrackNext"], "farbe": ["Info", "ContextMenu"],
                           "teilen": ["ChannelDown"]}, **_FARBTASTEN),
    "tastatur": dict({"suche": ["Ctrl+K", "/"], "sprechen": ["Alt+M"], "start": ["Alt+H"], "filme": ["Alt+F"],
                      "serien": ["Alt+S"], "stil": ["Alt+T"], "naechstes": ["Alt+Tab", "Alt+N"], "farbe": ["Alt+C"],
                      "links": ["Alt+ArrowLeft"], "rechts": ["Alt+ArrowRight"], "oben": ["Alt+ArrowUp"], "unten": ["Alt+ArrowDown"],
                      "voll": ["Alt+Enter"], "breite": ["Alt+B"], "hoehe": ["Alt+V"], "teilen": ["Alt+X"], "neu": ["Alt+Plus", "Alt++"],
                      "schliessen": ["Alt+W"], "rot": ["Alt+R"], "gruen": ["Alt+G"], "gelb": ["Alt+Y"], "blau": ["Alt+U"]},
                     **{"fenster%d" % n: ["Alt+%d" % n] for n in range(1, 10)}),
    "zahlen": dict({"suche": ["0", "BrowserSearch", "Ctrl+K"], "sprechen": ["*"], "start": ["#"]},
                   **{"fenster%d" % n: [str(n)] for n in range(1, 10)}, **_FARBTASTEN),
}
SCHEMA_NAMEN = [["fernbedienung", "Fernbedienung (Farbtasten)"], ["zahlen", "Zahlentasten"], ["tastatur", "Tastatur (Alt + …)"],
                ["eigenes", "Eigenes Schema"]]
_TASTE = re.compile(r"^(?:(?:Ctrl|Alt|Shift|Meta)\+){0,3}[^\s]{1,24}$")


def brett_pruefe(roh):
    """Fenster pruefen: Lage im 3×3-Brett, bekannte Bereiche (je hoechstens einmal), Farben."""
    if not isinstance(roh, list):
        raise EinstellungsFehler("Brett: Liste von Fenstern erwartet")
    fenster, bereiche, ids = [], set(), set()
    for f in roh[:MAX_FENSTER]:
        if not isinstance(f, dict):
            continue
        try:
            x, y, w, h = (int(f.get(k, 1)) for k in ("x", "y", "w", "h"))
        except (TypeError, ValueError):
            continue
        if not (1 <= x <= 3 and 1 <= y <= 3 and 1 <= w <= 4 - x and 1 <= h <= 4 - y):
            continue
        bereich = str(f.get("bereich") or "")
        if bereich and (bereich not in BEREICHE or bereich in bereiche):
            bereich = ""
        fid = re.sub(r"[^a-z0-9]", "", str(f.get("id") or "").lower())[:12] or "f%d" % len(fenster)
        while fid in ids:
            fid += "x"
        if bereich:
            bereiche.add(bereich)
        ids.add(fid)
        farbe = f.get("farbe") if f.get("farbe") in FARBEN else ""
        fenster.append({"id": fid, "bereich": bereich, "kat": re.sub(r"[^A-Za-z0-9_-]", "", str(f.get("kat") or ""))[:40],
                        "x": x, "y": y, "w": w, "h": h, "farbe": farbe})
    return fenster


def kodiskin_pruefe(roh):
    """Heim-Style "Kodi-Skin": {id: skin.…, schema: Name des Farbschemas, hintergrund: Bildadresse aus dem Skin oder leer,
    texturen: Rahmen und Fokus aus den Texturen des Skins}."""
    if not isinstance(roh, dict):
        raise EinstellungsFehler("Kodi-Skin: Objekt erwartet")
    sid = str(roh.get("id") or "")
    if sid and not re.match(r"^skin\.[\w.\-]{1,100}$", sid):
        raise EinstellungsFehler("Kodi-Skin: ungültige ID")
    hintergrund = str(roh.get("hintergrund") or "")[:400]
    if hintergrund and not hintergrund.startswith("api/kodiaddons/datei?pfad="):
        hintergrund = ""
    return {"id": sid, "schema": re.sub(r"[\x00-\x1f/\\]", "", str(roh.get("schema") or ""))[:60], "hintergrund": hintergrund,
            "texturen": roh.get("texturen") is not False}


def tasten_pruefe(roh):
    """Eigenes Schema: {aktion: [taste, ...]} mit bekannten Aktionen, hoechstens 3 Tasten je Aktion."""
    if not isinstance(roh, dict):
        raise EinstellungsFehler("Tasten: {Aktion: [Tasten]} erwartet")
    e = {}
    for aktion, tasten in roh.items():
        if aktion not in AKTIONEN:
            continue
        tasten = [tasten] if isinstance(tasten, str) else tasten if isinstance(tasten, list) else []
        gut = []
        for t in tasten:
            t = str(t or "").strip()[:40]
            if t and _TASTE.match(t) and t not in gut:
                gut.append(t)
        if gut:
            e[aktion] = gut[:3]
    return e
