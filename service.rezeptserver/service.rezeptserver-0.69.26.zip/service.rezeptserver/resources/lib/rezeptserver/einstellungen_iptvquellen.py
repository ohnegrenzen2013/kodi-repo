"""Einstellungen: IPTV-Quellen und Dispatcharr."""

IPTVQUELLEN_KATEGORIE = {
    "id": "iptvquellen", "name": "IPTV-Quellen", "symbol": "📡",
    "gruppe": "Verbindungen & Geräte", "eigen": True,
    "beschreibung": "Freie Senderlisten, Dispatcharr und die Listenprüfung. Übernommene Listen landen unter "
                    "Live-TV → Eigene Listen und können dort jederzeit entfernt werden.",
    "zeilen": [
        {"key": "iptvquellen_an", "typ": "schalter", "titel": "IPTV-Quellen anbieten",
         "standard": True,
         "hinweis": "Zeigt freie, täglich geprüfte Senderlisten (BUG TV, Michaz, IPTV-org) und die Dispatcharr-"
                    "Anbindung im Live-TV-Bereich. Aus = nur die eingebauten Sender."},
        {"key": "dispatcharr_url", "typ": "text", "titel": "Dispatcharr-Adresse",
         "standard": "http://127.0.0.1:9191", "platzhalter": "http://192.168.1.20:9191",
         "hinweis": "Adresse der Dispatcharr-Installation. H0rSt übernimmt deren M3U- und EPG-Ausgabe "
                    "(/output/m3u und /output/epg) als eigene Liste."},
        {"key": "dispatcharr_key", "typ": "passwort", "titel": "Dispatcharr-API-Schlüssel",
         "standard": "", "platzhalter": "optional – für Kanäle und geschützte Ausgaben",
         "hinweis": "Wird als X-API-Key gesendet. Leer lassen, wenn die Ausgabe ohne Schlüssel erreichbar ist."},
    ],
}
