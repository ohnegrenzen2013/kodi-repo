"""Einstellungen: IPVPN-Overlay."""

IPVPN_KATEGORIE = {
    "id": "ipvpn", "name": "IPVPN", "symbol": "🛡",
    "gruppe": "Verbindungen & Geräte", "eigen": True,
    "beschreibung": "Dezentrales Overlay über IPFS-DHT und WireGuard (my-network/ipvpn). H0rSt startet ipvpnd "
                    "nicht; es prüft die Schnittstellen und baut die Einrichtung als Befehlsliste.",
    "zeilen": [
        {"key": "ipvpn_an", "typ": "schalter", "titel": "IPVPN anzeigen",
         "standard": False,
         "hinweis": "Zeigt das Overlay im Sicherheitsbereich. Aus = keine Prüfung der Schnittstellen."},
        {"key": "ipvpn_netz", "typ": "text", "titel": "Netz-Kennung",
         "standard": "", "platzhalter": "mein-netz",
         "hinweis": "3–64 Zeichen. Alle Geräte mit derselben Kennung und demselben Passwort bilden ein Netz."},
        {"key": "ipvpn_knoten", "typ": "text", "titel": "Feste Peers",
         "standard": "", "platzhalter": "namen: 10.197.202.2, 10.197.203.7",
         "hinweis": "Optional, je Zeile „name IP“. Die eigentliche Peer-Suche macht der IPFS-DHT."},
        {"key": "ipvpn_passwort", "typ": "passwort", "titel": "Netz-Passwort",
         "standard": "", "platzhalter": "mindestens 8 Zeichen",
         "hinweis": "Wird nur für die Befehlsliste verwendet und nie zurückgegeben. H0rSt legt keine Datei an."},
    ],
}
