"""Einstellungen fuer KeepADB 1.11.0 (m00sfett, AGPL-3.0-or-later).

KeepADB schaltet Androids „Wireless debugging“ und holt es nach Netzwechsel oder
Neustart zurueck. Die Zeilen unten bilden die Regeln des Vorbilds ab: Wachdienst,
Netzregel mit vertrauten Zugangspunkten, Sperrliste, Kraft-Modus mit Ablauf und der
Webhook fuer den geprueften Endpunkt. H0rSt schreibt die Systemeinstellung nicht
selbst; es bewertet Netze, maskiert Adressen und baut die Befehle.
"""

KEEPADB_KATEGORIE = {
    "id": "keepadb", "name": "KeepADB", "symbol": "📡", "gruppe": "System & Pflege", "eigen": True,
    "beschreibung": "KeepADB 1.11.0 (m00sfett, AGPL-3.0-or-later) haelt Androids Wireless Debugging wach: "
                    "Wachdienst nach Netzregel, vertraute Zugangspunkte, Sperrliste, Kraft-Modus mit Ablauf, "
                    "Webhook fuer den Endpunkt und Masken fuer Adressen. H0rSt schaltet die Systemeinstellung "
                    "nicht selbst, sondern bewertet Netze und baut die Befehle.",
    "zeilen": [
        {"key": "ka_an", "typ": "schalter", "titel": "KeepADB anbieten", "standard": False,
         "hinweis": "Schaltet den Kasten unter „System & Pflege“ und die API frei. Ohne diesen Schalter bewertet "
                    "H0rSt kein Netz, baut keinen Befehl und sendet keine Meldung."},
        {"key": "ka_paket", "typ": "text", "titel": "Paketname", "standard": "de.hohnepeople.keepadb",
         "platzhalter": "de.hohnepeople.keepadb",
         "hinweis": "Paket der KeepADB-App (F-Droid oder GitHub-Freigabe). Vor dem Installieren die Signatur "
                    "pruefen; H0rSt liefert keine APK mit."},
        {"key": "ka_wach_an", "typ": "schalter", "titel": "Wachdienst (Keep-Alive)", "standard": False,
         "hinweis": "Wie beim Vorbild ab Werk aus: H0rSt darf Wireless Debugging nur dann zurueckholen, wenn "
                    "dieser Schalter an ist und die Netzregel das Netz erlaubt."},
        {"key": "ka_netz_regel", "typ": "wahl", "titel": "Netzregel", "standard": "vertraut",
         "werte": [["vertraut", "Nur vertraute Zugangspunkte"], ["alle", "Alle WLAN-Netze"]],
         "hinweis": "„Nur vertraute Zugangspunkte“ ist die sichere Vorgabe des Vorbilds: automatisch "
                    "eingeschaltet wird nur in eingetragenen Netzen, bei unlesbarer Kennung wird gewartet."},
        {"key": "ka_vertraut", "typ": "textfeld", "titel": "Vertraute Zugangspunkte (BSSID)", "standard": "",
         "platzhalter": "aa:bb:cc:dd:ee:01",
         "hinweis": "Eine Kennung je Zeile (oder mit Komma getrennt). Verglichen wird die BSSID, also die "
                    "Geräteadresse des Zugangspunkts – nicht der Netzname."},
        {"key": "ka_namen", "typ": "textfeld", "titel": "Vertraute Netznamen (SSID)", "standard": "",
         "platzhalter": "MeinWlan",
         "hinweis": "Nur mit „Auch nach Netzname vertrauen“. Ein Name ist leicht faelschbar; die BSSID bleibt "
                    "deshalb der Weg der Wahl."},
        {"key": "ka_namen_trauen", "typ": "schalter", "titel": "Auch nach Netzname vertrauen", "standard": False,
         "hinweis": "Wie beim Vorbild eine Bequemlichkeit: ein Netz mit passendem Namen gilt dann als vertraut."},
        {"key": "ka_blockliste", "typ": "textfeld", "titel": "Sperrliste (BSSID oder Netzname)", "standard": "",
         "platzhalter": "GastWlan",
         "hinweis": "In diesen Netzen greift der Wachdienst nie – nur der Kraft-Modus setzt sich darüber."},
        {"key": "ka_unbekannt_aus", "typ": "schalter", "titel": "In fremden Netzen ausschalten", "standard": False,
         "hinweis": "Verschärfung nach Vorbild (ab Werk aus): schon eingeschaltetes Wireless Debugging wird in "
                    "einem nicht vertrauten Netz beendet. Ohne den Schalter meldet H0rSt nur."},
        {"key": "ka_kraft_an", "typ": "schalter", "titel": "Kraft-Modus", "standard": False,
         "hinweis": "Zeitweise in jedem Netz erlaubt, auch in gesperrten und in Netzen mit unlesbarer Kennung. "
                    "Endet von selbst, wenn die Frist abgelaufen ist."},
        {"key": "ka_kraft_dauer", "typ": "wahl", "titel": "Kraft-Modus gilt", "standard": "1h",
         "wenn": "ka_kraft_an",
         "werte": [["1h", "1 Stunde"], ["24h", "24 Stunden"], ["7d", "7 Tage"], ["30d", "30 Tage"],
                   ["unbegrenzt", "Unbegrenzt"]],
         "hinweis": "Die Frist laeuft ab dem Zeitpunkt, an dem der Kraft-Modus eingeschaltet wurde; „Unbegrenzt“ "
                    "kennt kein Ende und will bedacht sein."},
        {"key": "ka_schalten", "typ": "schalter", "titel": "Schaltbefehle erlauben", "standard": True,
         "hinweis": "Gibt settings put/get global adb_wifi_enabled, pm grant und adb connect frei. Die Befehle "
                    "entstehen nur als Text und werden von dir ausgefuehrt."},
        {"key": "ka_paaren", "typ": "schalter", "titel": "Kopplungsbefehl erlauben", "standard": False,
         "hinweis": "Gibt adb pair frei. Standard aus: der Kopplungscode oeffnet den Weg zum Geraet und gehoert "
                    "in keine gespeicherte Liste."},
        {"key": "ka_webhook_an", "typ": "schalter", "titel": "Endpunkt per Webhook melden", "standard": False,
         "hinweis": "Meldet den geprueften Wireless-Debugging-Endpunkt als JSON an die Adresse unten. Ohne "
                    "diesen Schalter geht nichts hinaus."},
        {"key": "ka_webhook_url", "typ": "text", "titel": "Webhook-Adresse", "standard": "",
         "platzhalter": "https://…/keepadb",
         "hinweis": "https wird empfohlen; http verschluesselt weder Adresse noch Inhalt und gehoert hoechstens "
                    "in ein eigenes Netz. Gesendet wird nur der Endpunkt – kein Netzname, kein Kopplungscode."},
        {"key": "ka_privat_app", "typ": "schalter", "titel": "Adressen in der App verstecken", "standard": False,
         "hinweis": "Wie beim Vorbild teilweise maskiert: eine IPv4-Adresse behaelt ihre erste Zahl und der Port "
                    "bleibt sichtbar (192.*.*.*:41234), Netzname, BSSID und Host werden ersetzt."},
        {"key": "ka_privat_meldung", "typ": "schalter", "titel": "Adressen in Meldungen verstecken",
         "standard": False,
         "hinweis": "Meldungen nennen dann gar keine Adresse und keinen Port – sinnvoll, damit nichts auf dem "
                    "Sperrbildschirm landet."},
        {"key": "ka_privat_widget", "typ": "schalter", "titel": "Adressen im Widget verstecken", "standard": False,
         "hinweis": "Zeigt nur den Zustand, ohne Port und Adresse."},
        {"key": "ka_farbe_an", "typ": "schalter", "titel": "KeepADB-Farbe fuer den Style verwenden",
         "standard": False,
         "hinweis": "Nur wenn der Heim-Style [ „KeepADB“ @ H0rSt ] aktiv ist: Akzentfarbe aus der Auswahl unten "
                    "statt des festen Rots."},
        {"key": "ka_farbe", "typ": "wahl", "titel": "KeepADB-Farbe", "standard": "rot",
         "werte": [["rot", "Rot #D01822 (Primär)"], ["banner", "Bannerrot #B11218"],
                   ["gelb", "Titelgelb #FFD21F"]],
         "hinweis": "Die Palette stammt aus KeepADBs colors.xml: Rot #D01822, Bannerrot #B11218 und "
                    "Titelgelb #FFD21F auf dem Grund #080604."},
    ],
}
