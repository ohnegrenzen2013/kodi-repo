"""Einstellungen: LBRY/Odysee."""

LBRY_KATEGORIE = {
    "id": "lbry", "name": "LBRY/Odysee", "symbol": "▶",
    "gruppe": "Verbindungen & Geräte", "eigen": True,
    "beschreibung": "Suche und Wiedergabe über LBRY. Ohne lokalen Daemon fragt H0rSt die öffentliche "
                    "Odysee-Brücke; ein lokaler lbrynet liefert die Wiedergabe-Adressen direkt.",
    "zeilen": [
        {"key": "lbry_an", "typ": "schalter", "titel": "LBRY/Odysee anbieten",
         "standard": True,
         "hinweis": "Zeigt die LBRY-Suche in der Dateisuche und holt auf Klick eine Wiedergabe-Adresse."},
        {"key": "lbry_daemon", "typ": "text", "titel": "Eigener LBRY-Daemon",
         "standard": "", "platzhalter": "http://127.0.0.1:5279",
         "hinweis": "Leer = öffentliche Odysee-Brücke. Mit Daemon laufen Suche und get über deinen lbrynet "
                    "(JSON-RPC, Port 5279 im Heimnetz)."},
    ],
}
