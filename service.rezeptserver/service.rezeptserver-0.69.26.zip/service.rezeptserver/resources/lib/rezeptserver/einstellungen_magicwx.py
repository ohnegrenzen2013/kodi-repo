"""Einstellungen fuer MagicWX: App, Bildserver, Chat und alle Bildparameter.

MagicWX (Pangu-Immortal/MagicWX, MIT) bringt lokale Chat-Modelle (RWKV/ONNX,
MediaPipe/LiteRT) und SD-1.5-Bilder ueber denselben LocalDream-Bildserver wie
Local Dream. H0rSt uebernimmt die Palette als Style und bietet hier alle
Parameter, die MagicWX in seinem Advanced-Dialog kennt. Der Block unter
"Parameterblock" laesst sich in MagicWX ueber "Erweitert -> Import" einlesen;
umgekehrt kann H0rSt einen Block aus der Zwischenablage uebernehmen.
"""

MAGICWX_KATEGORIE = {
    "id": "magicwx", "name": "MagicWX", "symbol": "🪄", "gruppe": "KI, Automatisierung & Backup", "eigen": True,
    "beschreibung": "Offline-Chat und Bilder mit MagicWX (MIT): RWKV/ONNX/MediaPipe fuer Text, SD 1.5 ueber den "
                    "LocalDream-Bildserver fuer Bilder. Hier schaltest du die Anbindung und stellst alle Parameter "
                    "ein; der Block laesst sich in MagicWX importieren.",
    "zeilen": [
        {"key": "magicwx_an", "typ": "schalter", "titel": "MagicWX anbinden", "standard": False,
         "hinweis": "Zeigt MagicWX im LocalDream-Bereich, uebernimmt die Werte unten ins Formular und nimmt die "
                    "Zusatzparameter in jeden Bildauftrag auf. Ohne Schalter bleibt alles wie bisher."},
        {"key": "magicwx_uebernehmen", "typ": "schalter", "titel": "Werte ins LocalDream-Formular uebernehmen", "standard": True,
         "hinweis": "Beim Oeffnen von LocalDream Prompt, Groesse, Schritte, CFG, Seed und Sampler aus diesen "
                    "Einstellungen setzen. Einmal je Sitzung, damit eigene Aenderungen nicht ueberschrieben werden."},
        {"key": "magicwx_app", "typ": "text", "titel": "Paketname der App", "standard": "com.qihao.open.rwkv",
         "platzhalter": "com.qihao.open.rwkv", "hinweis": "Fuer „MagicWX oeffnen“. Die offizielle App heisst "
                                                          "com.qihao.open.rwkv; eigene Builds koennen anders heissen."},
        {"key": "magicwx_server", "typ": "text", "titel": "Bildserver-Adresse", "standard": "http://127.0.0.1:18081",
         "platzhalter": "http://127.0.0.1:18081", "hinweis": "MagicWX startet seinen nativen Bildserver auf Port "
                                                             "18081 (LocalDream-Protokoll). Der Knopf unten traegt ihn als Server ein."},
        {"key": "magicwx_chat", "typ": "schalter", "titel": "Lokalen Chat ermoeglichen", "standard": True,
         "hinweis": "MagicWX chatten lassen (Text). H0rSt zeigt die Modellwahl als Merkzettel; die App selbst "
                    "laedt und laedt das Modell."},
        {"key": "magicwx_bild", "typ": "schalter", "titel": "Bilder ermoeglichen", "standard": True,
         "hinweis": "SD-1.5-Bilder ueber den MagicWX-Bildserver. Aus: H0rSt sendet keine MagicWX-Bildauftraege."},
        {"key": "magicwx_chat_modell", "typ": "wahl", "titel": "Chat-Modell", "standard": "rwkv-7",
         "werte": [["builtin", "MagicWX built-in experience (ohne Download)"],
                   ["rwkv-7", "RWKV-7 World 0.4B (ONNX)"], ["qwen3", "Qwen3 0.6B (ONNX)"],
                   ["qwen25", "Qwen2.5 0.5B (ONNX)"], ["smollm", "SmolLM2 360M (ONNX)"],
                   ["tinyllama", "TinyLlama 1.1B Chat (LiteRT)"]],
         "hinweis": "Nur Modelle, die MagicWX auf dem Testgeraet bestanden hat. Weitere Kandidaten bleiben in "
                    "der App absichtlich verborgen, bis sie denselben Test bestehen."},
        {"key": "magicwx_chat_runtime", "typ": "wahl", "titel": "Chat-Laufzeit", "standard": "onnx",
         "werte": [["builtin", "BUILTIN_TEXT"], ["onnx", "ONNX Runtime"], ["litert", "MediaPipe / LiteRT-LM"]],
         "hinweis": "MagicWX waehlt die Laufzeit passend zum Modell; der Eintrag dient als Merkzettel fuer "
                    "eigene Builds und die Fehlersuche."},
        {"key": "magicwx_chat_tokens", "typ": "wahl", "titel": "Hoechstens Token", "standard": "256",
         "werte": [["128", "128"], ["256", "256"], ["512", "512"], ["1024", "1024"]],
         "hinweis": "Antwortlaenge im Chat. MagicWX nutzt standardmaessig 256 Token, Temperatur 1,0 und Top-p 0,1."},
        {"key": "magicwx_chat_temperatur", "typ": "wahl", "titel": "Temperatur", "standard": "1.0",
         "werte": [["0.2", "0,2 (sehr ruhig)"], ["0.5", "0,5"], ["0.7", "0,7"], ["1.0", "1,0 (Standard)"], ["1.2", "1,2 (lebhaft)"]],
         "hinweis": "Merkzettel fuer den Chat; MagicWX speichert seine eigenen Werte in der App."},
        {"key": "magicwx_chat_top_p", "typ": "wahl", "titel": "Top-p", "standard": "0.1",
         "werte": [["0.1", "0,1 (Standard)"], ["0.5", "0,5"], ["0.9", "0,9"], ["1.0", "1,0"]],
         "hinweis": "Merkzettel fuer den Chat; MagicWX speichert seine eigenen Werte in der App."},
        {"key": "magicwx_vision", "typ": "schalter", "titel": "Bildverstehen (VLM) einplanen", "standard": False,
         "hinweis": "SmolVLM/Qwen3-VL stehen bei MagicWX noch auf der Roadmap. Der Schalter dokumentiert die "
                    "Absicht und blendet spaeter passende Hinweise ein, er lädt kein Modell."},
        {"key": "magicwx_asr", "typ": "schalter", "titel": "Spracheingabe (Whisper) einplanen", "standard": False,
         "hinweis": "Whisper/Vosk/sherpa-onnx sind bei MagicWX noch nicht angeschlossen. Kein Download, keine "
                    "Aufnahme durch H0rSt."},
        {"key": "magicwx_tts", "typ": "schalter", "titel": "Sprachausgabe (Kokoro/Piper) einplanen", "standard": False,
         "hinweis": "TTS ist bei MagicWX Roadmap. H0rSt spricht weiterhin ueber die vorhandenen Wege."},
        {"key": "magicwx_vad", "typ": "schalter", "titel": "Sprachaktivitaet (Silero VAD) einplanen", "standard": False,
         "hinweis": "VAD ist bei MagicWX Roadmap; der Schalter laedt nichts."},
        {"key": "magicwx_tools", "typ": "schalter", "titel": "Werkzeuge/Funktionsaufrufe einplanen", "standard": False,
         "hinweis": "MagicWX nennt Tool Calling als Ziel. H0rSts eigene MCP-Werkzeuge bleiben davon unberuehrt."},
        {"key": "magicwx_rag", "typ": "schalter", "titel": "Dokumenten-Wissensbasis einplanen", "standard": False,
         "hinweis": "PDF/RAG ist bei MagicWX Roadmap; H0rSt indexiert hier nichts."},
        {"key": "magicwx_downloads", "typ": "schalter", "titel": "Modell-Downloads erlauben", "standard": True,
         "hinweis": "MagicWX laedt Modelle selbst in seiner App. Aus: kein automatischer Downloadhinweis."},
        {"key": "magicwx_hintergrund_downloads", "typ": "schalter", "titel": "Downloads im Hintergrund", "standard": True,
         "hinweis": "MagicWX nutzt dafuer einen Vordergrunddienst; der Schalter ist ein Merkzettel fuer die App."},
        {"key": "magicwx_hf_spiegel", "typ": "schalter", "titel": "Hugging-Face-Spiegel als Rueckfall", "standard": True,
         "hinweis": "MagicWX probiert bei blockierter Hugging-Face-Adresse hf-mirror und danach das GitHub-Release. "
                    "Der Schalter dokumentiert den Rueckfall; H0rSt laedt keine Modelle."},
        {"key": "magicwx_verlauf", "typ": "schalter", "titel": "Bildverlauf in MagicWX behalten", "standard": True,
         "hinweis": "MagicWX speichert Ergebnisse in Room. H0rSt zeigt seine eigenen Galeriebilder unabhaengig davon."},
        {"key": "magicwx_statistik", "typ": "schalter", "titel": "Anonyme Statistik in MagicWX", "standard": False,
         "hinweis": "MagicWX selbst sendet nur nach ausdruecklicher Zustimmung anonyme Statistiken. H0rSt sendet keine."},
        {"key": "magicwx_prompt", "typ": "text", "titel": "Standard-Prompt", "standard": "masterpiece, best quality, a cat on a windowsill, warm light,",
         "platzhalter": "masterpiece, best quality, …", "hinweis": "Wird beim Uebernehmen ins LocalDream-Formular gesetzt und steht im Parameterblock."},
        {"key": "magicwx_negativ", "typ": "text", "titel": "Standard-Negativ", "standard": "worst quality, low quality, blurry, watermark, signature, text,",
         "platzhalter": "worst quality, low quality, …", "hinweis": "Negativ-Prompt fuer alle MagicWX-Bildauftraege."},
        {"key": "magicwx_modus", "typ": "wahl", "titel": "Bildmodus", "standard": "txt2img",
         "werte": [["txt2img", "Text zu Bild"], ["img2img", "Bild zu Bild"], ["inpaint", "Teilweise neu malen"]],
         "hinweis": "Bei Bild zu Bild und Teilweise neu malen waehlst du im LocalDream-Formular ein Ausgangsbild "
                    "und bei Teilweise neu malen zusaetzlich eine Maske."},
        {"key": "magicwx_schritte", "typ": "text", "titel": "Schritte", "standard": "20", "platzhalter": "20",
         "hinweis": "1 bis 150. MagicWX-Standard: 20."},
        {"key": "magicwx_cfg", "typ": "text", "titel": "CFG", "standard": "7", "platzhalter": "7",
         "hinweis": "1 bis 30. MagicWX-Standard: 7."},
        {"key": "magicwx_seed", "typ": "text", "titel": "Seed", "standard": "-1", "platzhalter": "-1",
         "hinweis": "-1 wuerfelt; eine Zahl macht das Bild reproduzierbar."},
        {"key": "magicwx_breite", "typ": "text", "titel": "Breite", "standard": "512", "platzhalter": "512",
         "hinweis": "8er-Schritte, 64 bis 2048. MagicWX-Standard: 512."},
        {"key": "magicwx_hoehe", "typ": "text", "titel": "Hoehe", "standard": "512", "platzhalter": "512",
         "hinweis": "8er-Schritte, 64 bis 2048. MagicWX-Standard: 512."},
        {"key": "magicwx_sampler", "typ": "wahl", "titel": "Sampler", "standard": "dpm",
         "werte": [["dpm", "DPM++ 2M"], ["dpm_karras", "DPM++ 2M Karras"], ["dpm_sde", "DPM++ 2M SDE"],
                   ["dpm_sde_karras", "DPM++ 2M SDE Karras"], ["euler_a", "Euler a"], ["euler", "Euler"],
                   ["lcm", "LCM (schnelle Modelle)"]],
         "hinweis": "Dieselben IDs wie im MagicWX- und LocalDream-Protokoll."},
        {"key": "magicwx_aspect", "typ": "wahl", "titel": "Seitenverhaeltnis (SDXL/Anima)", "standard": "1:1",
         "werte": [["1:1", "1:1"], ["3:4", "3:4 (Hochformat)"], ["4:3", "4:3 (Querformat)"],
                   ["9:16", "9:16"], ["16:9", "16:9"]],
         "hinweis": "Wird als aspect_ratio an den Bildserver gegeben; SD 1.5 ignoriert es."},
        {"key": "magicwx_denoise", "typ": "text", "titel": "Staerke (Bild zu Bild)", "standard": "0.6", "platzhalter": "0.6",
         "hinweis": "0,05 bis 1. MagicWX-Standard: 0,6."},
        {"key": "magicwx_batch", "typ": "text", "titel": "Bilder je Auftrag", "standard": "1", "platzhalter": "1",
         "hinweis": "1 bis 10. H0rSt zaehlt die Bilder in seiner Galerie; MagicWX zeigt seinen eigenen Verlauf."},
        {"key": "magicwx_vorschau", "typ": "schalter", "titel": "Zwischenbilder zeigen", "standard": True,
         "hinweis": "Der LocalDream-Server sendet dann Zwischenbilder (JPEG)."},
        {"key": "magicwx_stride", "typ": "text", "titel": "Zwischenbild alle … Schritte", "standard": "2", "platzhalter": "2",
         "hinweis": "1 bis 20. Kleiner heisst fluessiger, aber mehr Last."},
        {"key": "magicwx_format", "typ": "wahl", "titel": "Ausgabeformat", "standard": "png",
         "werte": [["png", "PNG (verlustfrei)"], ["jpeg", "JPEG"], ["raw", "Roh (RGB)"]],
         "hinweis": "H0rSt legt Galeriebilder als PNG ab; das Format betrifft die Antwort des Bildservers."},
        {"key": "magicwx_ultrafix_steps", "typ": "text", "titel": "UltraFix: Schritte", "standard": "10", "platzhalter": "10",
         "hinweis": "Reparatur grosser Bilder in Kacheln. MagicWX-Standard: 10."},
        {"key": "magicwx_ultrafix_denoise", "typ": "text", "titel": "UltraFix: Entrauschschritte", "standard": "4", "platzhalter": "4",
         "hinweis": "1 bis Schritte. MagicWX-Standard: 4."},
        {"key": "magicwx_ultrafix_qualitaet", "typ": "schalter", "titel": "UltraFix: Qualitaets-Prompt", "standard": True,
         "hinweis": "Ersetzt den Prompt beim Reparieren durch „masterpiece, best quality, 4k resolution“."},
        {"key": "magicwx_lowram", "typ": "schalter", "titel": "SDXL/Anima: wenig Arbeitsspeicher", "standard": False,
         "hinweis": "Wird beim Start des MagicWX-Bildservers gesetzt, nicht je Auftrag. H0rSt merkt die Wahl fuer "
                    "den Parameterblock."},
        {"key": "magicwx_seqdit", "typ": "schalter", "titel": "Anima: DiT nacheinander laden", "standard": False,
         "hinweis": "Ebenfalls ein Startparameter des MagicWX-Bildservers; fuer Geraete mit 12 GB."},
        {"key": "magicwx_patch", "typ": "text", "titel": "Pfad zum Aufloesungs-Patch", "standard": "", "platzhalter": "/pfad/zum/patch.bin",
         "hinweis": "Nur fuer den SD-1.5-NPU-Server bei Groessen ausser 512. Leer lassen, wenn unbekannt."},
    ],
}
