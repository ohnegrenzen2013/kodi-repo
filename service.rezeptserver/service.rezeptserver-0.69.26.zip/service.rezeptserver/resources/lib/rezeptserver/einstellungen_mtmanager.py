"""Einstellungen fuer MT Manager 2.26.11 und den lokalen APK-MCP-Dienst.

Der MCP-Dienst laeuft in MT Manager (Werkzeuge -> APK MCP) auf Port 8787 und
spricht Streamable HTTP unter /mcp. H0rSt verbindet sich als MCP-Client. Die
MT-internen Schalter (Home, Port, Workspaces, Signatur, Installation) kann nur
MT selbst setzen; H0rSt merkt sie sich als Prüf- und Einrichtungshilfe und
zeigt sie beim Verbinden an.
"""

MTMANAGER_KATEGORIE = {
    "id": "mtmanager", "name": "MT Manager", "symbol": "📦", "gruppe": "KI, Automatisierung & Backup", "eigen": True,
    "beschreibung": "MT Manager 2.26.11 als MCP-Server anbinden: Datei-, ZIP- und APK-Werkzeuge fuer die KI. "
                    "Der MCP-Dienst wird in MT gestartet (Werkzeuge -> APK MCP); H0rSt verbindet sich nur.",
    "zeilen": [
        {"key": "mt_an", "typ": "schalter", "titel": "MT-Manager-Anbindung anbieten", "standard": False,
         "hinweis": "Schaltet den Kasten unter „KI & Werkzeuge“ frei. Der MCP-Dienst selbst laeuft in MT Manager "
                    "und muss dort gestartet werden."},
        {"key": "mt_url", "typ": "text", "titel": "MCP-Adresse", "standard": "http://127.0.0.1:8787/mcp",
         "platzhalter": "http://127.0.0.1:8787/mcp",
         "hinweis": "MT zeigt die Adresse unter APK MCP an: lokal http://127.0.0.1:8787/mcp, im Heimnetz die "
                    "LAN-Adresse des Handys. H0rSt uebernimmt sie als MCP-Server."},
        {"key": "mt_home", "typ": "text", "titel": "MT-Home-Ordner", "standard": "/storage/emulated/0/MT2/mcp",
         "platzhalter": "/storage/emulated/0/MT2/mcp",
         "hinweis": "Arbeitsordner des MCP-Dienstes (MT: Einstellungen -> Allgemein -> Home). Nur eigene Dateien "
                    "und nur mit den in MT erlaubten Rechten bearbeiten."},
        {"key": "mt_port", "typ": "text", "titel": "Port", "standard": "8787", "platzhalter": "8787",
         "hinweis": "Standard 8787. Muss zur Adresse oben passen; in MT nur bei Konflikt aendern."},
        {"key": "mt_workspaces", "typ": "text", "titel": "APK-Arbeitsstaende behalten", "standard": "5",
         "platzhalter": "5", "hinweis": "MT haelt so viele zuletzt geoeffnete APK-Arbeitsstaende warm. Mehr kostet "
                                        "Speicher; die MT-Einstellung bleibt massgeblich."},
        {"key": "mt_floating", "typ": "schalter", "titel": "Schwebekugel gegen Einschlafen", "standard": True,
         "hinweis": "MTs Schwebekugel haelt den MCP-Dienst im Hintergrund am Leben. Ohne sie brechen Verbindungen "
                    "ab, sobald Android MT anhaelt – in MT einschalten und die Rechte bestaetigen."},
        {"key": "mt_auth", "typ": "schalter", "titel": "Bearer-Token verlangt", "standard": False,
         "hinweis": "In MT kann die MCP-Authentifizierung an sein. Dann hier den Token eintragen (Feld unter "
                    "„KI & Werkzeuge“); der Token wird wie der MCP-Schluessel gespeichert, nicht in dieser Liste."},
        {"key": "mt_dateizugriff", "typ": "wahl", "titel": "Dateizugriff in MT", "standard": "read_write",
         "werte": [["read_write", "Lesen und schreiben"], ["read_only", "Nur lesen"], ["home", "Nur Home-Ordner"]],
         "hinweis": "MTs eigene Regel (MCP-Dateizugriff). H0rSt kann sie nicht aendern, zeigt sie aber vor dem "
                    "Aufruf an. Fuer APK-Aenderungen braucht die KI Schreibrecht."},
        {"key": "mt_signieren", "typ": "schalter", "titel": "Neue APK signieren", "standard": True,
         "hinweis": "Beim Bauen einer geaenderten APK mit dem in MT gewaehlten Schluessel signieren."},
        {"key": "mt_signaturschluessel", "typ": "text", "titel": "Signaturschluessel (Merkzettel)", "standard": "",
         "platzhalter": "Name in MT", "hinweis": "Der Schluessel liegt in MT (APK MCP -> Einstellungen -> APK). "
                                                   "H0rSt merkt sich nur den Namen."},
        {"key": "mt_installationspruefung", "typ": "schalter", "titel": "Signatur und Versionscode pruefen", "standard": True,
         "hinweis": "Vor der Installation vergleichen; bei abweichender Signatur fragt MT nach."},
        {"key": "mt_installation", "typ": "wahl", "titel": "Installationsweg", "standard": "system",
         "werte": [["system", "System-Installer"], ["shizuku", "Shizuku"], ["root", "Root"], ["dhizuku", "Dhizuku"]],
         "hinweis": "MTs Installationsreihenfolge ist Shizuku > Dhizuku > Root > System. Ohne Root/Shizuku zeigt "
                    "Android die uebliche Bestaetigung."},
        {"key": "mt_zip", "typ": "schalter", "titel": "ZIP-Werkzeuge erlauben", "standard": True,
         "hinweis": "Archiv lesen, aendern und entpacken (MT 2.26.10+). H0rSt ruft sie nur auf, wenn die KI danach fragt."},
        {"key": "mt_transfer", "typ": "schalter", "titel": "Datei-Transfer erlauben", "standard": True,
         "hinweis": "Hoch- und Herunterladen ueber den MCP-Dienst (MT 2.26.11+). Nur zwischen Geraeten, die sich "
                    "gegenseitig erreichen."},
        {"key": "mt_installieren", "typ": "schalter", "titel": "APK-Installation durch die KI erlauben", "standard": True,
         "hinweis": "Erlaubt den Installationsaufruf aus der Werkzeugliste (MT 2.26.11+). MT fragt je nach "
                    "Einstellung selbst nach."},
        {"key": "mt_farbe_an", "typ": "schalter", "titel": "MT-Farbe fuer den Style verwenden", "standard": False,
         "hinweis": "Nur wenn der Heim-Style [ „MT Manager“ @ H0rSt ] aktiv ist: Akzentfarbe aus der Auswahl unten "
                    "statt des festen Azurblaus."},
        {"key": "mt_farbe", "typ": "wahl", "titel": "MT-Farbe", "standard": "blau",
         "werte": [["blau", "Azurblau #5B85FA (Original)"], ["gold", "VIP-Gold #ECB82B"],
                   ["violett", "Violett #9C6BFF"], ["gruen", "Gruen #4CAF50"]],
         "hinweis": "MT 2.26.11 erlaubt Theme-Farbe, Nachtmodus und Monet-Farben. H0rSt bildet die Auswahl auf "
                    "seinen Akzent ab; der Rest des Styles bleibt wie bei der Aufnahme."},
        {"key": "mt_apk_url", "typ": "text", "titel": "APK-Seite", "standard": "https://pan.mt2.cn/apk/26110366",
         "platzhalter": "https://pan.mt2.cn/apk/26110366",
         "hinweis": "Nur ein Link zum Oeffnen/Herunterladen; H0rSt installiert die APK nicht automatisch. "
                    "Vor dem Installieren Paketname und Signatur pruefen."},
    ],
}
