"""Navigation: Uebersichten, eigene Tabs und Reihenfolge pruefen und einsortieren."""

from .einstellungen_grund import (
    EinstellungsFehler,
    MAX_EIGENE,
    NAV,
    NAV_PFLICHT,
    re,
)

def eigene_tabs_pruefe(roh):
    if not isinstance(roh, list) or len(roh) > MAX_EIGENE:
        raise EinstellungsFehler("Eigene Tabs: Liste mit höchstens %d Einträgen" % MAX_EIGENE)
    ergebnis, ids = [], set()
    for t in roh:
        if not isinstance(t, dict):
            raise EinstellungsFehler("Eigener Tab muss ein Objekt sein")
        if t.get("art") == "app" and t.get("ziel") == "io.github.xororz.localdream" and t.get("id") == "localdream":
            continue  # frueher ab Werk als App-Reiter; jetzt der eingebaute Reiter "LocalDream" (startet die App auch)
        name = " ".join(str(t.get("name") or "").split())[:30]
        art = t.get("art") if t.get("art") in ("app", "web", "link", "kodi") else "web"
        ziel = str(t.get("ziel") or "").strip()[:500]
        if not name or not ziel:
            raise EinstellungsFehler("Eigener Tab braucht Name und Ziel")
        if art in ("web", "link") and not re.match(r"^https?://", ziel, re.I):
            raise EinstellungsFehler("%s: Webadresse mit http(s)://" % name)
        if art == "app" and not re.match(r"^[A-Za-z][\w]*(\.[A-Za-z][\w]*)+$", ziel):
            raise EinstellungsFehler("%s: App als Paketname, z. B. com.beispiel.app" % name)
        if art == "kodi" and not re.match(r"^plugin://[A-Za-z0-9_][\w.\-]{0,119}(/\S*)?$", ziel):
            raise EinstellungsFehler("%s: Kodi-Addon als plugin://<id>/" % name)
        laden = str(t.get("laden") or "").strip()[:500]
        if laden and not re.match(r"^https?://", laden, re.I):
            laden = ""
        tid = re.sub(r"[^a-z0-9]", "", str(t.get("id") or name).lower())[:20] or "tab"
        while tid in ids:
            tid += "x"
        ids.add(tid)
        ergebnis.append({"id": tid, "name": name, "art": art, "ziel": ziel, "symbol": str(t.get("symbol") or "")[:4],
                         "laden": laden, "text": " ".join(str(t.get("text") or "").split())[:200],
                         "menue": t.get("menue") is True})
    return ergebnis


def nav_liste(eigene):
    """Alle Navigationseintraege: eingebaute und eigene Tabs (eigen:<id>); Kodi-Addons hinter "Kodi", die uebrigen hinter vxparser."""
    liste = list(NAV)
    for art, hinter in (("kodi", "kodiaddons"), ("", "vx")):
        stelle = next(n + 1 for n, (i, _) in enumerate(liste) if i == hinter)
        for t in eigene or []:
            if (t.get("art") == "kodi") == bool(art):
                liste.insert(stelle, ("eigen:" + t["id"], t["name"]))
                stelle += 1
    return liste


def navigation_pruefe(roh, eigene=None):
    """[{id, an}] in gewuenschter Reihenfolge; unbekannte fallen weg, neue Tabs kommen an ihre Standardstelle."""
    if not isinstance(roh, list):
        raise EinstellungsFehler("navigation muss eine Liste sein")
    bekannt = [i for i, _ in nav_liste(eigene)]
    liste, gesehen = [], set()
    for e in roh:
        i = e.get("id") if isinstance(e, dict) else None
        if i in bekannt and i not in gesehen:
            gesehen.add(i)
            liste.append({"id": i, "an": True if i in NAV_PFLICHT else e.get("an") is not False})
    for pos, i in enumerate(bekannt):  # fehlende (z. B. neue Tabs nach einer Aktualisierung) einsortieren
        if i not in gesehen:
            vorher = bekannt[pos - 1] if pos else None
            stelle = next((n + 1 for n, x in enumerate(liste) if x["id"] == vorher), 0 if vorher is None else len(liste))
            liste.insert(stelle, {"id": i, "an": True})
            gesehen.add(i)
    return liste


