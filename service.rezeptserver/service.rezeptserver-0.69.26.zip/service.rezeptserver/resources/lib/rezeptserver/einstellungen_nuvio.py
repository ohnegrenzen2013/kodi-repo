"""Einstellungen fuer Nuvio Mobile (Modulschalter und eigene Server-Adresse)."""

from .nuvio_mobil import AN, ADRESSE

NUVIO_KATEGORIE = {
    "id": "nuvio", "name": "Nuvio Mobile", "symbol": "🎬", "gruppe": "Verbindungen & Geräte",
    "beschreibung": "Nuvio Mobile (NuvioMedia/NuvioMobile, GPL-3.0) ist der Client, H0rSt die Quelle. "
                    "Die App haengt H0rSt als Stremio-Addon ein und nutzt zusaetzlich die H0rSt-APIs fuer "
                    "Suche, Streams, Untertitel, Downloads, Fortschritt und Tracker. Kein fremder Code "
                    "laeuft im Server; die App wird bei GitHub geladen.",
    "zeilen": [
        {"key": AN, "typ": "schalter", "titel": "Nuvio-Modul andocken", "standard": True,
         "hinweis": "Ohne Schalter bleibt der Reiter unsichtbar und /api/nuvio meldet an=false. "
                    "Die uebrigen Werte bleiben gespeichert."},
        {"key": ADRESSE, "typ": "text", "titel": "Eigene Server-Adresse", "standard": "",
         "platzhalter": "https://h0rst.example/",
         "hinweis": "Leer = die Adresse der Anfrage wird benutzt (samt Token). Fuer unterwegs eine feste "
                    "HTTPS-Adresse eintragen, damit die Addon- und API-Adressen in der App stimmen."},
    ],
}
