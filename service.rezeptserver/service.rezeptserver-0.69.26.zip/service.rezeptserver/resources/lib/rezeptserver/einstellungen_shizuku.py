"""Einstellungen fuer Shizuku 13.6.0-R4 (Fork yangFenTuoZi) und rish-Befehle.

Shizuku startet einen Dienst per ADB oder Root und gibt normalen Apps einen
Binder auf System-APIs. Die Schalter unten bilden die Einstellungen der
Shizuku-App ab (Start, ADB-Root, TCP/IP-Port, Nachtmodus, Systemfarbe). H0rSt
kann sie nicht in Shizuku setzen; es merkt sie sich als Pruef- und
Einrichtungshilfe und baut daraus rish-Befehle fuer seine eigenen Werkzeuge.
Die APK wird nicht mitgeliefert.
"""

SHIZUKU_KATEGORIE = {
    "id": "shizuku", "name": "Shizuku", "symbol": "🪄", "gruppe": "System & Pflege", "eigen": True,
    "beschreibung": "Shizuku 13.6.0-R4 (Fork yangFenTuoZi, Apache-2.0) als Rechtebruecke fuer ADB und Root: "
                    "Start, Wireless Debugging, TCP/IP-Port, Nachtmodus und rish-Befehle fuer pm, settings und appops. "
                    "H0rSt setzt die Shizuku-Schalter nicht selbst; sie gelten in Shizuku und werden hier nur gemerkt.",
    "zeilen": [
        {"key": "sh_an", "typ": "schalter", "titel": "Shizuku-Anbindung anbieten", "standard": False,
         "hinweis": "Schaltet den Kasten unter „System & Pflege“ frei. Shizuku und der gestartete Dienst bleiben "
                    "eigenstaendig; H0rSt liefert keine APK mit und startet keinen fremden Dienst."},
        {"key": "sh_paket", "typ": "text", "titel": "Paketname", "standard": "moe.shizuku.privileged.api",
         "platzhalter": "moe.shizuku.privileged.api",
         "hinweis": "Paket der Shizuku-App. Offizielle Fassung und Fork tragen denselben Namen; vor dem "
                    "Installieren Signatur pruefen."},
        {"key": "sh_modus", "typ": "wahl", "titel": "Startweg", "standard": "auto",
         "werte": [["auto", "Automatisch (Root, sonst ADB)"], ["root", "Root"], ["adb", "ADB/Computer"]],
         "hinweis": "Wie Shizuku gestartet wurde. Bei „ADB“ muss der Dienst nach jedem Neustart erneut gestartet "
                    "werden; Root-Geraete starten selbst."},
        {"key": "sh_start_on_boot", "typ": "schalter", "titel": "Start beim Booten (Root)", "standard": True,
         "hinweis": "Shizukus Schalter „Start on boot (root)“. H0rSt merkt ihn sich, setzt ihn aber nicht."},
        {"key": "sh_start_on_boot_wireless", "typ": "schalter", "titel": "Start beim Booten (Wireless ADB)",
         "standard": False,
         "hinweis": "Fork-Funktion fuer Geraete ohne Root. Braucht die Berechtigung WRITE_SECURE_SETTINGS und "
                    "schaltet Wireless Debugging beim Start ein."},
        {"key": "sh_adb_root", "typ": "schalter", "titel": "ADB-Root (userdebug)", "standard": False,
         "hinweis": "Shizukus „ADB root (rooted debugging)“ fuer userdebug-ROMs; nur dort verfuegbar. Auf "
                    "normalen ROMs ohne Wirkung."},
        {"key": "sh_tcpip_port", "typ": "text", "titel": "TCP/IP-Port", "standard": "", "platzhalter": "leer = aus",
         "hinweis": "Port, auf den adbd nach dem Start ueber Wireless Debugging hoert (1–65535). Leer lassen "
                    "schaltet die Aenderung ab; Shizuku prueft den Wert selbst."},
        {"key": "sh_sprache", "typ": "text", "titel": "Sprache", "standard": "SYSTEM", "platzhalter": "SYSTEM",
         "hinweis": "Shizukus Sprachkuerzel (z. B. de, en) oder SYSTEM fuer die Geraetesprache."},
        {"key": "sh_nachtmodus", "typ": "wahl", "titel": "Nachtmodus", "standard": "system",
         "werte": [["system", "System folgen"], ["dunkel", "Immer dunkel"], ["hell", "Immer hell"]],
         "hinweis": "Shizukus „Dark theme“: aus, an oder System folgen. Der Style unten nimmt die Dunkelansicht auf."},
        {"key": "sh_schwarz", "typ": "schalter", "titel": "Reines Schwarz im Nachtmodus", "standard": False,
         "hinweis": "Shizukus „Black night theme“: schwarze statt dunkelgraue Flaechen."},
        {"key": "sh_systemfarbe", "typ": "schalter", "titel": "Systemfarbe verwenden", "standard": True,
         "hinweis": "Shizukus „Use system theme color“ (Android 12+): Material You faerbt die App mit dem "
                    "Hintergrundbild. Ohne Systemfarbe gilt das Indigo des Originals."},
        {"key": "sh_rish", "typ": "text", "titel": "rish-Aufruf", "standard": "rish", "platzhalter": "rish",
         "hinweis": "Name oder Pfad des rish-Skripts aus Shizuku (Terminal-Export). H0rSt baut damit Befehle, "
                    "fuehrt sie aber nicht selbst aus."},
        {"key": "sh_zufallsordner", "typ": "schalter", "titel": "Zufaelliger Ablageordner (Fork)", "standard": True,
         "hinweis": "Der Fork legt den Dienst unter einem zufaelligen Namen in /data/local/tmp ab, damit andere "
                    "Apps ihn nicht erraten. Shizuku-Einstellung, nur gemerkt."},
        {"key": "sh_starter_entfernen", "typ": "schalter", "titel": "shizuku_starter aufraeumen (Fork)",
         "standard": True,
         "hinweis": "Der Fork loescht shizuku_starter nach dem Start. Nur gemerkt; H0rSt loescht keine fremden "
                    "Dateien."},
        {"key": "sh_installieren", "typ": "schalter", "titel": "APK-Installation erlauben", "standard": True,
         "hinweis": "Gibt den rish-Befehl „pm install -r …“ frei. Der Befehl wird nur gebaut und kopiert, nie "
                    "automatisch ausgefuehrt."},
        {"key": "sh_deinstallieren", "typ": "schalter", "titel": "Deinstallation erlauben", "standard": False,
         "hinweis": "Gibt „pm uninstall …“ frei. Standard aus, weil dabei Daten verloren gehen."},
        {"key": "sh_rechte", "typ": "schalter", "titel": "Berechtigungen setzen erlauben", "standard": True,
         "hinweis": "Gibt „pm grant“ und „pm revoke“ frei, etwa fuer WRITE_SECURE_SETTINGS."},
        {"key": "sh_einstellungen", "typ": "schalter", "titel": "Systemeinstellungen und App-Ops erlauben",
         "standard": False,
         "hinweis": "Gibt „settings put“ und „cmd appops set“ frei. Standard aus, weil sich damit Geraete- "
                    "verhalten aendern laesst."},
        {"key": "sh_gefaehrlich", "typ": "schalter", "titel": "Eingriffe erlauben (deaktivieren, Daten loeschen)",
         "standard": False,
         "hinweis": "Gibt „pm disable-user“, „pm enable“ und „pm clear“ frei. Standard aus; „pm clear“ entfernt "
                    "alle Daten der gewaehlten App."},
        {"key": "sh_farbe_an", "typ": "schalter", "titel": "Shizuku-Farbe fuer den Style verwenden",
         "standard": False,
         "hinweis": "Nur wenn der Heim-Style [ „Shizuku“ @ H0rSt ] aktiv ist: Akzentfarbe aus der Auswahl unten "
                    "statt des festen Periwinkels."},
        {"key": "sh_farbe", "typ": "wahl", "titel": "Shizuku-Farbe", "standard": "original",
         "werte": [["original", "Periwinkel #B1B8DF (Dunkelansicht)"], ["indigo", "Indigo #3F51B5 (Hellansicht)"],
                   ["flieder", "Flieder #D0BCFF (Material 3)"]],
         "hinweis": "Shizukus appColorPrimary: #B1B8DF im Dunkeln, #3F51B5 im Hellen; #D0BCFF ist die "
                    "Material-3-Vorgabe. H0rSt bildet die Auswahl auf seinen Akzent ab."},
        {"key": "sh_apk_url", "typ": "text", "titel": "APK-Seite", "standard": "https://github.com/yangFenTuoZi/Shizuku/releases/latest",
         "platzhalter": "https://github.com/yangFenTuoZi/Shizuku/releases/latest",
         "hinweis": "Nur ein Link zum Oeffnen oder Herunterladen; H0rSt installiert die APK nicht automatisch. "
                    "Offizielle Anleitung: shizuku.rikka.app."},
    ],
}
