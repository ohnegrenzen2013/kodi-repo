"""Einstellungen fuer die Videowerkstatt (ComfyUI)."""

VIDEOWERKSTATT_KATEGORIE = {
    "id": "videowerkstatt", "name": "Videowerkstatt", "symbol": "🎬",
    "gruppe": "KI, Automatisierung & Backup",
    "beschreibung": "Kurze Videoclips aus Text in ComfyUI: Bildfolge samplen und als animiertes WebP oder MP4 "
                    "speichern. Der Workflow orientiert sich am AnimateDiff-Aufbau aus OmniRoute (MIT); Modelle, "
                    "Motion-Module und der Ausgabeknoten bleiben in ComfyUI.",
    "zeilen": [
        {"key": "vw_an", "typ": "schalter", "titel": "Videowerkstatt anbinden", "standard": False,
         "hinweis": "Ohne Schalter nimmt H0rSt keine Videoauftraege an. ComfyUI muss mit --listen laufen."},
        {"key": "vw_url", "typ": "text", "titel": "ComfyUI-Adresse", "standard": "http://127.0.0.1:8188",
         "platzhalter": "http://127.0.0.1:8188",
         "hinweis": "Im Heimnetz z. B. http://192.168.1.20:8188. H0rSt ruft /prompt, /history und /view auf."},
        {"key": "vw_modell", "typ": "text", "titel": "Checkpoint", "standard": "",
         "platzhalter": "v1-5-pruned-emaonly.safetensors",
         "hinweis": "Dateiname aus ComfyUI/models/checkpoints. In der Videowerkstatt listet „ComfyUI-Modelle“ "
                    "die vorhandenen Namen auf."},
        {"key": "vw_breite", "typ": "zahl", "titel": "Breite", "standard": "832",
         "hinweis": "Wird auf ein Vielfaches von 8 gerundet; 832×480 ist quer, 480×832 hoch."},
        {"key": "vw_hoehe", "typ": "zahl", "titel": "Hoehe", "standard": "480"},
        {"key": "vw_frames", "typ": "zahl", "titel": "Bilder je Clip", "standard": "16",
         "hinweis": "1–64. AnimateDiff-Modelle sind meist auf 16 Bilder trainiert."},
        {"key": "vw_fps", "typ": "zahl", "titel": "Bilder pro Sekunde", "standard": "8",
         "hinweis": "8 fps bei 16 Bildern ergibt rund zwei Sekunden."},
        {"key": "vw_schritte", "typ": "zahl", "titel": "Schritte", "standard": "20"},
        {"key": "vw_cfg", "typ": "zahl", "titel": "CFG", "standard": "7"},
        {"key": "vw_sampler", "typ": "wahl", "titel": "Sampler", "standard": "euler",
         "werte": [["euler", "Euler"], ["euler_ancestral", "Euler ancestral"], ["dpmpp_2m", "DPM++ 2M"],
                   ["dpmpp_2m_sde", "DPM++ 2M SDE"], ["dpmpp_sde", "DPM++ SDE"], ["lcm", "LCM"]]},
        {"key": "vw_scheduler", "typ": "wahl", "titel": "Scheduler", "standard": "normal",
         "werte": [["normal", "Normal"], ["karras", "Karras"], ["exponential", "Exponential"],
                   ["sgm_uniform", "SGM Uniform"], ["simple", "Simple"], ["beta", "Beta"]]},
        {"key": "vw_seed", "typ": "text", "titel": "Seed", "standard": "-1",
         "hinweis": "-1 = zufaellig; sonst eine Zahl von 0 bis 4294967295."},
        {"key": "vw_anzahl", "typ": "wahl", "titel": "Clips je Auftrag", "standard": "1",
         "werte": [["1", "1"], ["2", "2"], ["4", "4"]]},
        {"key": "vw_format", "typ": "wahl", "titel": "Ausgabeformat", "standard": "webp",
         "werte": [["webp", "Animiertes WebP"], ["mp4", "MP4 (VideoHelperSuite)"]],
         "hinweis": "MP4 braucht den Knoten VHS_VideoCombine aus der VideoHelperSuite; sonst WebP waehlen."},
        {"key": "vw_negativ", "typ": "text", "titel": "Negativ-Prompt",
         "standard": "worst quality, low quality, blurry, watermark, text"},
    ],
}
