"""Werte: Standard, Pruefen, Lesen und Aendern der Einstellungen."""

import time

from .einstellungen_grund import (
    EIGENE_STANDARD,
    EinstellungsFehler,
    MAX_TEXT,
    SCHLUESSEL,
    SPRACHEN,
    _ZEILEN,
    re,
)

from .einstellungen_navigation import eigene_tabs_pruefe, navigation_pruefe
from .einstellungen_heim import SCHEMATA, brett_pruefe, kodiskin_pruefe, tasten_pruefe

# Werte mit eigener Pruefung (JSON statt Text/Wahl): Super-Heim-Brett und eigenes Tastenschema
_JSON = {"brett": brett_pruefe, "tasten": tasten_pruefe, "kodiskin": kodiskin_pruefe}

def standard():
    e = {k: z["standard"] for k, z in _ZEILEN.items() if not z.get("abschnitt")}
    e["eigene_tabs"] = [dict(t) for t in EIGENE_STANDARD]
    e["navigation"] = navigation_pruefe([], e["eigene_tabs"])
    e["brett"] = []
    e["kodiskin"] = {"id": "", "schema": "", "hintergrund": "", "texturen": True}
    e["tasten"] = {k: list(v) for k, v in SCHEMATA["tastatur"].items()}  # Vorlage fuers eigene Schema
    return e


def _wert(zeile, wert):
    typ = zeile["typ"]
    if typ == "schalter":
        if not isinstance(wert, bool):
            raise EinstellungsFehler("%s: an oder aus" % zeile["titel"])
        return wert
    if typ in ("wahl", "farbe"):
        wert = str(wert)
        if wert not in [w for w, _ in zeile["werte"]]:
            raise EinstellungsFehler("%s: unbekannter Wert %s" % (zeile["titel"], wert))
        return wert
    wert = " ".join(str(wert or "").split())[:MAX_TEXT]
    if zeile["key"] == "hintergrund_url" and wert and not re.match(r"^https?://", wert, re.I):
        raise EinstellungsFehler("Hintergrundbild: Adresse mit http(s)://")
    if zeile["key"] == "ausschliessen" and wert:
        try:
            re.compile(wert, re.I)
        except re.error as fehler:
            raise EinstellungsFehler("Regex ungültig: %s" % fehler)
    if zeile.get("abschnitt") == SPRACHEN and wert and not re.match(r"^[A-Za-z]{2,3}(\s*[,\s/+]\s*[A-Za-z]{2,3})*$", wert):
        raise EinstellungsFehler("%s: Sprachcodes wie „de, en“" % zeile["titel"])
    return wert


def pruefe(roh):
    """Gespeicherte Werte: unbekannte und kaputte Eintraege fallen auf den Standard zurueck."""
    e = standard()
    roh = roh if isinstance(roh, dict) else {}
    if "eigene_tabs" in roh:
        try:
            e["eigene_tabs"] = eigene_tabs_pruefe(roh["eigene_tabs"])
        except EinstellungsFehler:
            pass
    e["navigation"] = navigation_pruefe([], e["eigene_tabs"])
    for k, w in roh.items():
        if k == "eigene_tabs":
            continue
        if k == "navigation":
            try:
                e[k] = navigation_pruefe(w, e["eigene_tabs"])
            except EinstellungsFehler:
                pass
        elif k in _JSON:
            try:
                e[k] = _JSON[k](w)
            except EinstellungsFehler:
                pass
        elif k in e:
            try:
                e[k] = _wert(_ZEILEN[k], w)
            except EinstellungsFehler:
                pass
    return e


def werte(daten):
    """Alle Werte fuer die Oberflaeche, Sprachen aus ihrem Abschnitt."""
    e = pruefe(daten.get(SCHLUESSEL))
    sprachen = daten.get(SPRACHEN) or {}
    for k, z in _ZEILEN.items():
        if z.get("abschnitt") == SPRACHEN:
            w = sprachen.get(k) or ""
            e[k] = ", ".join(w) if isinstance(w, list) else str(w)
    return e


def aendern(daten, neu, uhr=time.time):
    """Uebernimmt {schluessel: wert} in die Nutzerdaten (prueft jeden Wert). Gibt die neuen Werte zurueck."""
    if not isinstance(neu, dict) or not neu:
        raise EinstellungsFehler("JSON-Objekt mit Einstellungen erwartet")
    e = pruefe(daten.get(SCHLUESSEL))
    sprachen = dict(daten.get(SPRACHEN) or {})
    if "eigene_tabs" in neu:
        e["eigene_tabs"] = eigene_tabs_pruefe(neu["eigene_tabs"])
        e["navigation"] = navigation_pruefe(e["navigation"], e["eigene_tabs"])
    for k, w in neu.items():
        if k == "eigene_tabs":
            continue
        if k == "navigation":
            e[k] = navigation_pruefe(w, e["eigene_tabs"])
            continue
        if k in _JSON:
            e[k] = _JSON[k](w)
            continue
        zeile = _ZEILEN.get(k)
        if not zeile:
            raise EinstellungsFehler("Unbekannte Einstellung: %s" % k)
        w = _wert(zeile, w)
        if zeile.get("abschnitt") == SPRACHEN:
            if w:
                sprachen[k] = w
            else:
                sprachen.pop(k, None)
        else:
            e[k] = w
    daten[SCHLUESSEL] = e
    daten["oberflaeche_geaendert"] = int(uhr())
    if sprachen:
        daten[SPRACHEN] = sprachen
    else:
        daten.pop(SPRACHEN, None)
    return werte(daten)


