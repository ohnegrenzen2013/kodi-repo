"""Ember-Steuerung: Ember (eMule/KAD, Rust + Tauri) hat keine Fernsteuerung – laeuft es auf demselben Rechner wie
H0rSt (PC, Pi, Docker-Projekt EM-B3R), liest und steuert H0rSt es ueber seine Dateien.

  * Datenordner: EMBER_DATA_DIR, sonst wie Ember selbst (Linux ~/.local/share/p2p bzw. ~/.local/share/ember/p2p,
    Windows %APPDATA%\\ember\\p2p\\data, macOS ~/Library/Application Support/com.ember.p2p) oder fest eingestellt.
  * Laeuft Ember? Am TCP-Port aus config.json (Standard 4662) und an den Prozessen (Linux /proc, Windows tasklist).
  * Fortschritt: Tabelle "transfers" in ember.db (SQLite, nur lesend) – Name, Status, Fortschritt, Tempo, Groesse.
  * Einstellungen: config.json (Ports, Ordner, Limits, UPnP, Verschleierung, IP-Filter …). Geaendert wird nur bei
    gestopptem Ember, sonst schreibt Ember beim Beenden seine Fassung zurueck. Vorher legt H0rSt eine Kopie an.
  * Starten/Stoppen: das eingestellte Programm (oder gefunden) starten; Stoppen beendet den Prozess sauber (SIGTERM).
  * Listen uebergeben: server.met, nodes.dat und ipfilter.dat von H0rSt in den Ember-Ordner schreiben.

Nutzerdaten "ember_steuerung": {"ordner": "", "programm": ""}.
"""

import json
import os
import shutil
import signal
import socket
import sqlite3
import subprocess
import sys
import time

SCHLUESSEL = "ember_steuerung"
STANDARD_TCP, STANDARD_UDP = 4662, 4672
# Einstellungen, die H0rSt zeigt und aendern darf: key -> (Titel, Art, Grenzen)
FELDER = {
    "nickname": ("Name im Netz", "text", None),
    "download_folder": ("Download-Ordner", "text", None),
    "tcp_port": ("TCP-Port", "zahl", (1, 65535)),
    "udp_port": ("UDP-Port (KAD)", "zahl", (1, 65535)),
    "max_download_speed": ("Download-Grenze (KB/s, 0 = ohne)", "zahl", (0, 10 ** 7)),
    "max_upload_speed": ("Upload-Grenze (KB/s, 0 = ohne)", "zahl", (0, 10 ** 7)),
    "max_concurrent_downloads": ("Downloads gleichzeitig", "zahl", (0, 1000)),
    "max_concurrent_uploads": ("Upload-Plätze (0 = automatisch)", "zahl", (0, 1000)),
    "max_connections": ("Verbindungen höchstens", "zahl", (0, 100000)),
    "upnp_enabled": ("Ports per UPnP öffnen", "schalter", None),
    "obfuscation_enabled": ("Verschleierung (Protokoll-Obfuscation)", "schalter", None),
    "ip_filter_enabled": ("IP-Filter", "schalter", None),
    "filter_incoming_connections": ("IP-Filter auch für eingehende Verbindungen", "schalter", None),
    "auto_connect_server": ("Automatisch mit eD2K-Server verbinden", "schalter", None),
    "add_downloads_paused": ("Neue Downloads pausiert anlegen", "schalter", None),
    "remove_finished_downloads": ("Fertige Downloads aus der Liste nehmen", "schalter", None),
}


class EmberFehler(ValueError):
    pass


def kandidaten(home=None, umgebung=None):
    """Moegliche Datenordner, wie Ember sie bestimmt."""
    umgebung = os.environ if umgebung is None else umgebung
    home = home or os.path.expanduser("~")
    liste = []
    if (umgebung.get("EMBER_DATA_DIR") or "").strip():
        liste.append(umgebung["EMBER_DATA_DIR"].strip())
    xdg = umgebung.get("XDG_DATA_HOME") or os.path.join(home, ".local", "share")
    liste += [os.path.join(xdg, "p2p"), os.path.join(xdg, "ember", "p2p")]
    if umgebung.get("APPDATA"):
        liste += [os.path.join(umgebung["APPDATA"], "ember", "p2p", "data"), os.path.join(umgebung["APPDATA"], "ember", "p2p")]
    liste.append(os.path.join(home, "Library", "Application Support", "com.ember.p2p"))
    return liste


def programm_kandidaten(home=None, umgebung=None):
    umgebung = os.environ if umgebung is None else umgebung
    home = home or os.path.expanduser("~")
    liste = [shutil.which("ember") or "", shutil.which("Ember") or "", "/usr/bin/ember", "/usr/local/bin/ember", "/opt/Ember/ember",
             os.path.join(home, "Applications", "Ember.AppImage"), "/Applications/Ember.app/Contents/MacOS/Ember"]
    if umgebung.get("LOCALAPPDATA"):
        liste.append(os.path.join(umgebung["LOCALAPPDATA"], "Programs", "Ember", "Ember.exe"))
    return [p for p in liste if p]


class EmberSteuerung:
    def __init__(self, einstellung=None, uhr=time.time, home=None, umgebung=None, starten=None, prozesse=None, offen=None):
        self.einstellung = dict(einstellung or {})
        self.uhr = uhr
        self.home, self.umgebung = home, umgebung
        self._starten = starten or self._prozess_starten
        self._prozesse = prozesse or self._prozess_liste
        self._offen = offen or _port_offen

    # --- Orte ----------------------------------------------------------------------------------------
    def ordner(self):
        eigen = (self.einstellung.get("ordner") or "").strip()
        for o in ([eigen] if eigen else []) + kandidaten(self.home, self.umgebung):
            if os.path.isfile(os.path.join(o, "config.json")) or os.path.isfile(os.path.join(o, "ember.db")):
                return o
        return eigen

    def programm(self):
        eigen = pruefe(self.einstellung)["programm"]
        if eigen:
            return eigen
        return next((p for p in programm_kandidaten(self.home, self.umgebung) if os.path.isfile(p)), "")

    def konfig(self):
        o = self.ordner()
        try:
            with open(os.path.join(o, "config.json"), encoding="utf-8") as f:
                d = json.load(f)
            return d if isinstance(d, dict) else {}
        except (OSError, ValueError):
            return {}

    # --- Zustand -------------------------------------------------------------------------------------
    @staticmethod
    def _prozess_liste():
        """[(pid, name)] laufender Ember-Prozesse."""
        funde = []
        if os.path.isdir("/proc"):
            for pid in os.listdir("/proc"):
                if not pid.isdigit():
                    continue
                try:
                    with open("/proc/%s/comm" % pid, encoding="utf-8", errors="replace") as f:
                        name = f.read().strip()
                except OSError:
                    continue
                if name.lower() in ("ember", "ember-p2p", "ember.appimage"):
                    funde.append((int(pid), name))
        elif sys.platform.startswith("win"):
            try:
                aus = subprocess.run(["tasklist", "/FI", "IMAGENAME eq Ember.exe", "/FO", "CSV", "/NH"], capture_output=True, text=True, timeout=10).stdout
                for zeile in aus.splitlines():
                    teile = [t.strip('"') for t in zeile.split('","')]
                    if len(teile) > 1 and teile[1].isdigit():
                        funde.append((int(teile[1]), teile[0]))
            except (OSError, subprocess.SubprocessError):
                pass
        return funde

    def zustand(self):
        o, k = self.ordner(), self.konfig()
        tcp, udp = int(k.get("tcp_port") or STANDARD_TCP), int(k.get("udp_port") or STANDARD_UDP)
        prozesse = self._prozesse()
        laeuft = bool(prozesse) or self._offen(tcp)
        return {"ordner": o, "gefunden": bool(o and (k or os.path.isfile(os.path.join(o, "ember.db")))), "programm": self.programm(),
                "laeuft": laeuft, "prozesse": [p for p, _ in prozesse], "ports": {"tcp": tcp, "udp": udp, "tcp_offen": self._offen(tcp)},
                "einstellungen": {key: {"titel": f[0], "art": f[1], "wert": k.get(key)} for key, f in FELDER.items() if key in k},
                "transfers": self.transfers(), "kandidaten": kandidaten(self.home, self.umgebung),
                "listen": {"server": k.get("server_list_path") or "", "nodes": k.get("nodes_dat_path") or ""}}

    def transfers(self):
        db = os.path.join(self.ordner() or "", "ember.db")
        if not os.path.isfile(db):
            return []
        try:
            verbindung = sqlite3.connect("file:%s?mode=ro" % db.replace("?", "%3F"), uri=True, timeout=2)
            try:
                zeilen = verbindung.execute(
                    "SELECT file_name, direction, status, progress, speed, total_size, transferred, started_at FROM transfers "
                    "ORDER BY CASE status WHEN 'active' THEN 0 WHEN 'queued' THEN 1 WHEN 'paused' THEN 2 ELSE 3 END, started_at DESC LIMIT 300").fetchall()
            finally:
                verbindung.close()
        except sqlite3.Error:
            return []
        return [{"name": z[0], "richtung": z[1], "status": z[2], "fortschritt": round(float(z[3] or 0) * (100 if float(z[3] or 0) <= 1 else 1), 1),
                 "tempo": int(z[4] or 0), "groesse": int(z[5] or 0), "fertig": int(z[6] or 0), "beginn": int(z[7] or 0)} for z in zeilen]

    # --- Aendern -------------------------------------------------------------------------------------
    def einstellen(self, neu):
        if not isinstance(neu, dict) or not neu:
            raise EmberFehler("Änderungen fehlen")
        if self.zustand()["laeuft"]:
            raise EmberFehler("Ember läuft – erst stoppen, sonst schreibt Ember beim Beenden seine Einstellungen zurück")
        o = self.ordner()
        pfad = os.path.join(o or "", "config.json")
        if not os.path.isfile(pfad):
            raise EmberFehler("Keine config.json von Ember gefunden – Ember einmal starten oder den Ordner einstellen")
        k = self.konfig()
        for key, wert in neu.items():
            if key not in FELDER:
                raise EmberFehler("Unbekannte Einstellung: %s" % key)
            _, art, grenzen = FELDER[key]
            if art == "schalter":
                if not isinstance(wert, bool):
                    raise EmberFehler("%s: an oder aus" % FELDER[key][0])
            elif art == "zahl":
                try:
                    wert = int(wert)
                except (TypeError, ValueError):
                    raise EmberFehler("%s: Zahl erwartet" % FELDER[key][0])
                if not grenzen[0] <= wert <= grenzen[1]:
                    raise EmberFehler("%s: %d–%d" % (FELDER[key][0], grenzen[0], grenzen[1]))
            else:
                wert = " ".join(str(wert or "").split())[:500]
                if not wert:
                    raise EmberFehler("%s darf nicht leer sein" % FELDER[key][0])
            k[key] = wert
        shutil.copy2(pfad, pfad + ".h0rst-%s.bak" % time.strftime("%Y%m%d%H%M%S", time.localtime(self.uhr())))
        with open(pfad + ".neu", "w", encoding="utf-8") as f:
            json.dump(k, f, indent=2, ensure_ascii=False)
        os.replace(pfad + ".neu", pfad)
        return self.zustand()

    def listen_geben(self, dateien):
        """{name: bytes} (server.met, nodes.dat, ipfilter.dat) in den Ember-Ordner – fuer den naechsten Start."""
        o = self.ordner()
        if not o or not (os.path.isfile(os.path.join(o, "config.json")) or os.path.isfile(os.path.join(o, "ember.db"))):
            raise EmberFehler("Ember-Ordner nicht gefunden (dort liegen config.json und ember.db)")
        k, geschrieben = self.konfig(), []
        for name, daten in dateien.items():
            if name not in ("server.met", "nodes.dat", "ipfilter.dat") or not daten:
                continue
            ziel = k.get("server_list_path") if name == "server.met" else k.get("nodes_dat_path") if name == "nodes.dat" else ""
            ziel = ziel if ziel and os.path.isabs(ziel) and os.path.isdir(os.path.dirname(ziel)) else os.path.join(o, name)
            with open(ziel + ".neu", "wb") as f:
                f.write(daten)
            os.replace(ziel + ".neu", ziel)
            geschrieben.append(ziel)
        return geschrieben

    # --- Starten / Stoppen ------------------------------------------------------------------------
    @staticmethod
    def _prozess_starten(programm):
        art = {"start_new_session": True} if os.name == "posix" else {"creationflags": 0x00000008}  # DETACHED_PROCESS
        subprocess.Popen([programm], stdin=subprocess.DEVNULL, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, close_fds=True, **art)

    def starten(self):
        if self.zustand()["laeuft"]:
            return self.zustand()
        p = self.programm()
        if not p or not os.path.isfile(p):
            raise EmberFehler("Ember-Programm nicht gefunden – unter „Programm“ den Pfad eintragen (z. B. /opt/Ember/ember)")
        if os.name == "posix" and not (os.environ.get("DISPLAY") or os.environ.get("WAYLAND_DISPLAY")) and sys.platform != "darwin":
            raise EmberFehler("Kein Bildschirm (DISPLAY) – Ember ist eine Desktop-App. Auf einem Server das Docker-Projekt EM-B3R nehmen.")
        try:
            self._starten(p)
        except OSError as fehler:
            raise EmberFehler("Ember startet nicht: %s" % fehler)
        return self.zustand()

    def stoppen(self):
        prozesse = self._prozesse()
        if not prozesse:
            raise EmberFehler("Kein Ember-Prozess auf diesem Rechner gefunden")
        for pid, _ in prozesse:
            try:
                if sys.platform.startswith("win"):
                    subprocess.run(["taskkill", "/PID", str(pid)], capture_output=True, timeout=10)
                else:
                    os.kill(pid, signal.SIGTERM)  # Ember speichert beim Beenden
            except (OSError, subprocess.SubprocessError):
                pass
        return self.zustand()


def _port_offen(port, host="127.0.0.1"):
    s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    s.settimeout(0.4)
    try:
        return s.connect_ex((host, int(port))) == 0
    except (OSError, ValueError):
        return False
    finally:
        s.close()


def pruefe(roh, streng=False):
    """Einstellungen pruefen. Als Programm geht nur eine Datei, deren Name "ember" enthaelt – ueber die Oberflaeche soll
    sich kein beliebiges Programm starten lassen."""
    roh = roh if isinstance(roh, dict) else {}
    e = {"ordner": str(roh.get("ordner") or "").strip()[:500], "programm": str(roh.get("programm") or "").strip()[:500]}
    if e["programm"] and "ember" not in os.path.basename(e["programm"]).lower():
        if streng:
            raise EmberFehler("Als Programm geht nur Ember selbst (der Dateiname muss „ember“ enthalten)")
        e["programm"] = ""
    return e
