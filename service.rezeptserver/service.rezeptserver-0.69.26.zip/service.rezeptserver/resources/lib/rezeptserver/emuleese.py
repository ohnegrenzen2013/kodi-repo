"""eMule eSE LiveTV: Adressen, Statuspruefung und Zustand fuer die Oberflaeche.

eSE (diad87/eMule-eSE-LiveTV, GPL-2.0) ist ein eMule-0.70b-Zweig, der Live-HLS
ueber eD2K und Kad verteilt. Das Dashboard laeuft standardmaessig auf
127.0.0.1:8080/live, die native Status-API auf 127.0.0.1:4711, RTMP auf 1935.
H0rSt uebernimmt keine fremde Software; es prueft nur, ob das Dashboard
antwortet, und reicht die Adresse an das Portal weiter.
"""

import ipaddress
import re
import socket
import urllib.request
from urllib.parse import urlsplit

NAME = "eMule eSE LiveTV"
REPO = "https://github.com/diad87/eMule-eSE-LiveTV"
STAND = "eSE 9.1.0"
LIZENZ = "GPL-2.0"
DASHBOARD = "http://127.0.0.1:8080/live"
API = "http://127.0.0.1:4711"
RTMP = 1935
_TITEL = re.compile(r"<title[^>]*>([^<]{1,200})</title>", re.I)


def _lokal(host):
    host = str(host or "").lower()
    if host == "localhost" or host.endswith(".local"):
        return True
    try:
        ip = ipaddress.ip_address(host)
    except ValueError:
        return False
    return ip.is_loopback or ip.is_private or ip.is_link_local


def _url(wert, standard):
    """Private/oeffentliche http(s)-Adresse im Heimnetz uebernehmen; sonst Standard."""
    wert = str(wert or "").strip()
    if not wert:
        return standard
    try:
        teile = urlsplit(wert)
    except ValueError:
        return standard
    if teile.scheme not in ("http", "https") or not teile.hostname or not _lokal(teile.hostname):
        return standard
    return wert[:300]


def _port(wert, standard):
    try:
        port = int(str(wert).strip())
    except (TypeError, ValueError):
        return standard
    return port if 1 <= port <= 65535 else standard


def _holen(url, zeitgrenze=1.5):
    """(status, inhalt) der Dashboard-Seite; (0, b"") wenn sie nicht antwortet."""
    try:
        anfrage = urllib.request.Request(url, headers={"User-Agent": "H0rSt-eSE/1.0"})
        with urllib.request.urlopen(anfrage, timeout=zeitgrenze) as antwort:
            return int(getattr(antwort, "status", 0) or antwort.getcode() or 0), antwort.read(8192)
    except Exception:  # nicht erreichbar, kein HTTP, Zeitueberschreitung …
        return 0, b""


def _offen(url, zeitgrenze=0.6):
    """Antwortet der TCP-Port der Adresse? (ohne Anmeldung, ohne Inhalt)"""
    teile = urlsplit(url)
    try:
        port = teile.port or (443 if teile.scheme == "https" else 80)
        with socket.create_connection((teile.hostname, port), zeitgrenze):
            return True
    except (OSError, ValueError):
        return False


def zustand(werte=None, holen=None, offen=None, pruefen=True):
    """Was die Oberflaeche ueber eSE wissen muss. Ohne Schalter wird nicht geklopft."""
    werte = werte if isinstance(werte, dict) else {}
    an = werte.get("emuleese_an") is True
    dashboard = _url(werte.get("emuleese_dashboard"), DASHBOARD)
    api = _url(werte.get("emuleese_api"), API)
    rtmp = _port(werte.get("emuleese_rtmp"), RTMP)
    erreichbar, api_offen, titel = False, False, ""
    meldung = "Ausgeschaltet – eSE wird nicht geprueft." if not an else ""
    if an and pruefen:
        status, inhalt = (holen or _holen)(dashboard)
        text = (inhalt or b"").decode("utf-8", "replace")
        treffer = _TITEL.search(text)
        titel = " ".join(treffer.group(1).split()) if treffer else ""
        erreichbar = status == 200 and bool(inhalt)
        api_offen = (offen or _offen)(api)
        if erreichbar:
            meldung = "Dashboard erreichbar" + (": " + titel if titel else ".")
            if not api_offen:
                meldung += " Die Status-API antwortet nicht – laeuft die native eSE-API?"
        else:
            meldung = ("Dashboard antwortet nicht. Laeuft eMule eSE auf diesem Rechner und ist das Dashboard "
                       "unter " + dashboard + " erreichbar?")
    return {"name": NAME, "repo": REPO, "stand": STAND, "lizenz": LIZENZ,
            "an": an, "dashboard": dashboard, "api": api, "rtmp": rtmp,
            "erreichbar": erreichbar, "api_offen": api_offen, "titel": titel, "meldung": meldung}
