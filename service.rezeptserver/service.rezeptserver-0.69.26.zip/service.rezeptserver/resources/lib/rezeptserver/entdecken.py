"""Titelsuche und Entdecken wie in ARVIO: Metadaten von Cinemeta (Stremio, ohne API-Schluessel).

  - Titelsuche ueber Filme und Serien, Treffer nach ARVIOs Rangfolge (exakter Titel vor Teiltreffer,
    Akzente, Satzzeichen und Artikel zaehlen nicht), Reihenfolge der Quelle bleibt innerhalb einer Stufe.
  - Entdecken: Kataloge "Beliebt" (top), "Top bewertet" (imdbRating) und "Neu" (year), mit Genre und Jahr.
  - Smart-Suche: nur ausdrueckliche Wuensche wie "beste Horrorfilme", "neue Serien", "top 10 filme"
    (Titel wie "Best in Show" bleiben eine normale Suche).
  - Details eines Titels samt Folgen einer Serie.

Alle Abrufe laufen ueber den Abrufer der App (nur strem.io) und werden 30 Minuten zwischengespeichert.
"""

import json
import logging
import re
import threading
import time
import unicodedata
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import quote

from .netz import NetzFehler
from .entdecken_titel import *  # noqa: F403


log = logging.getLogger("rezeptserver")

CINEMETA = "https://v3-cinemeta.strem.io"
ZWISCHENSPEICHER = 1800
MAX_SPEICHER = 300
TYPEN = ("movie", "series")
SORTIERUNGEN = {"top": "Beliebt", "imdbRating": "Top bewertet", "year": "Neu"}
# Mindest-Bewertung als Filter (Vorbild ARVIO); "bewertung" in karte() kommt als String von Cinemeta
BEWERTUNGEN = ("6", "7", "8", "9")
# aufloesen(): nur Treffer bis zu dieser stufe() zaehlen (0 exakt ... 2 "titel ..."), alles schwaechere wird verworfen
MAX_STUFE = 2
NUR_SERIEN = ("Reality-TV", "Talk-Show", "Game-Show")

_AKZENTE = re.compile(r"[̀-ͯ]+")
_ZEICHEN = re.compile(r"[^\w]+", re.UNICODE)
_ARTIKEL = re.compile(r"^(the|an|a|der|die|das|ein|eine|le|la|les|el|il) ")


def normalisiere(text):
    text = unicodedata.normalize("NFD", str(text or ""))
    text = _AKZENTE.sub("", text).lower().replace("&", " and ").replace("'", "").replace("’", "")
    text = text.replace("ß", "ss")
    return " ".join(_ZEICHEN.sub(" ", text).replace("_", " ").split())


def stufe(anfrage, titel):
    """Rangstufe wie ARVIOs rankSearchResults: 0 = exakt ... 7 = kein Titeltreffer."""
    q, t = normalisiere(anfrage), normalisiere(titel)
    woerter = q.split()
    if t == q:
        return 0
    if _ARTIKEL.sub("", t) == _ARTIKEL.sub("", q):
        return 1
    if t.startswith(q + " "):
        return 2
    if (" %s " % q) in (" %s " % t):
        return 3
    if woerter and all(w in t.split() for w in woerter):
        return 4
    if t.startswith(q):
        return 5
    if q in t:
        return 6
    return 7


def ranking(anfrage, karten):
    """Doppelte raus (Typ + ID), dann stabil nach Stufe sortieren."""
    gesehen, eindeutig = set(), []
    for k in karten:
        schluessel = (k["typ"], k["id"])
        if schluessel not in gesehen:
            gesehen.add(schluessel)
            eindeutig.append(k)
    return sorted(eindeutig, key=lambda k: stufe(anfrage, k["titel"]))




# --- Cinemeta -------------------------------------------------------------------------------

def karte(meta, typ=None):
    """Cinemeta-Meta -> Karte fuer die Oberflaeche (nur, was die Seite braucht)."""
    typ = meta.get("type") or typ or "movie"
    beschreibung = str(meta.get("description") or "")
    return {
        "id": str(meta.get("id") or meta.get("imdb_id") or ""), "typ": "series" if typ == "series" else "movie",
        "titel": str(meta.get("name") or ""), "jahr": str(meta.get("releaseInfo") or meta.get("year") or ""),
        "bewertung": str(meta.get("imdbRating") or ""), "poster": str(meta.get("poster") or ""),
        "hintergrund": str(meta.get("background") or ""), "logo": str(meta.get("logo") or ""),
        "genres": [g for g in (meta.get("genres") or meta.get("genre") or []) if isinstance(g, str)][:4],
        "beschreibung": beschreibung[:400] + ("…" if len(beschreibung) > 400 else ""),
        "laufzeit": str(meta.get("runtime") or ""),
    }


def _bewertung(karte):
    """karte()["bewertung"] als float, 0 bei leer/kaputt (nie werfen)."""
    try:
        return float(karte.get("bewertung") or 0)
    except (TypeError, ValueError):
        return 0


def trailer_von(meta):
    """YouTube-Kennung des ersten Trailers (Cinemeta: trailers[].source oder trailerStreams[].ytId) oder ''."""
    for t in (meta.get("trailerStreams") or []) + (meta.get("trailers") or []):
        if isinstance(t, dict):
            kennung = str(t.get("ytId") or t.get("source") or "")
            if re.match(r"^[\w-]{11}$", kennung):
                return kennung
    return ""


class Entdecken:
    def __init__(self, abrufer, addons=lambda: None):
        self.abrufer = abrufer
        self.addons = addons  # liefert die aktuellen Stremio-Addons der App (oder None)
        self._speicher = {}
        self._sperre = threading.Lock()
        self._pool = ThreadPoolExecutor(max_workers=4, thread_name_prefix="entdecken")

    def leeren(self):
        """Zwischenspeicher verwerfen ("Neu laden" in der Oberflaeche): die naechsten Abrufe holen frisch."""
        with self._sperre:
            self._speicher.clear()

    def _json(self, pfad):
        with self._sperre:
            alt = self._speicher.get(pfad)
            if alt and time.time() - alt[0] < ZWISCHENSPEICHER:
                return alt[1]
        try:
            daten = json.loads(self.abrufer.abruf(CINEMETA + pfad))
        except ValueError:
            raise NetzFehler("Cinemeta liefert kein JSON")
        with self._sperre:
            if len(self._speicher) >= MAX_SPEICHER:
                self._speicher.clear()
            self._speicher[pfad] = (time.time(), daten)
        return daten

    def _katalog(self, typ, katalog, extra=None):
        pfad = "/catalog/%s/%s%s.json" % (typ, katalog, "/" + "&".join(
            "%s=%s" % (k, quote(str(v), safe="")) for k, v in extra.items()) if extra else "")
        metas = self._json(pfad).get("metas") or []
        return [karte(m, typ) for m in metas if isinstance(m, dict) and m.get("id")]

    def katalog(self, typ, sortierung="top", genre="", jahr="", skip=0, bewertung=""):
        """Eine Seite eines Katalogs. Mit Jahr (oder "Neu") der Jahreskatalog, das Genre filtert dann hier.
        bewertung (Mindest-Bewertung, Vorbild ARVIO) filtert ebenfalls hier, unabhaengig vom Katalog."""
        if typ not in TYPEN:
            raise ValueError("Typ muss movie oder series sein")
        if sortierung not in SORTIERUNGEN:
            raise ValueError("unbekannte Sortierung")
        if genre and genre not in GENRES:
            raise ValueError("unbekanntes Genre")
        jahr = str(jahr or "").strip()
        if jahr and not re.match(r"^(18|19|20|21)\d\d$", jahr):
            raise ValueError("ungueltiges Jahr")
        bewertung = str(bewertung or "").strip()
        if bewertung and bewertung not in BEWERTUNGEN:
            raise ValueError("ungueltige Bewertung")
        extra = {}
        if jahr or sortierung == "year":
            extra["genre"] = jahr or time.strftime("%Y")
            katalog = "year"
        else:
            katalog = sortierung
            if genre:
                extra["genre"] = genre
        if skip:
            extra["skip"] = int(skip)
        karten = self._katalog(typ, katalog, extra)
        roh = len(karten)
        if genre and katalog == "year":
            karten = [k for k in karten if genre in k["genres"]]
        if bewertung:
            schwelle = float(bewertung)
            karten = [k for k in karten if _bewertung(k) >= schwelle]
        return {"titel": karten, "mehr": roh >= 20, "weiter": int(skip or 0) + roh}

    def suche(self, text):
        """Filme, Serien und Treffer aus den Suchkatalogen der Stremio-Addons, nach Rang sortiert."""
        text = " ".join(str(text or "").split())[:120]
        if not text:
            return {"filme": [], "serien": [], "addons": []}
        auftraege = {typ: self._pool.submit(self._katalog, typ, "top", {"search": text}) for typ in TYPEN}
        addons = self.addons()
        fremd = self._pool.submit(addons.katalog_suche, text) if addons and addons.addons else None
        ergebnis = {}
        for typ, auftrag in auftraege.items():
            try:
                ergebnis[typ] = ranking(text, auftrag.result(timeout=15))
            except Exception as fehler:
                log.warning("Cinemeta-Suche (%s): %s", typ, fehler)
                ergebnis[typ] = None
        if ergebnis["movie"] is None and ergebnis["series"] is None:
            raise NetzFehler("Titelsuche nicht erreichbar")
        fremd_karten = []
        if fremd is not None:
            try:
                bekannt = {k["id"] for liste in ergebnis.values() for k in liste or []}
                for addon, meta in fremd.result(timeout=12):
                    k = karte(meta)
                    if k["id"] and k["titel"] and k["id"] not in bekannt:
                        bekannt.add(k["id"])
                        fremd_karten.append(dict(k, quelle=addon["name"]))
            except Exception as fehler:
                log.warning("Addon-Suche: %s", fehler)
        return {"filme": ergebnis["movie"] or [], "serien": ergebnis["series"] or [],
                "addons": ranking(text, fremd_karten)}

    def aufloesen(self, titel, jahr="", typ=""):
        """Einen Titel (z. B. von einer gescrapten Seite) gegen Cinemeta abgleichen -> karte mit
        zusaetzlich "sicher" (bool) oder None, wenn kein Treffer bis MAX_STUFE da ist. Mit jahr zaehlen nur
        Kandidaten mit demselben oder einem direkt angrenzenden Jahr (Kinostart/Erstausstrahlung-Toleranz)."""
        titel = " ".join(str(titel or "").split())[:120]
        if not titel:
            return None
        typen = [typ] if typ in TYPEN else list(TYPEN)
        kandidaten = []
        for t in typen:
            try:
                kandidaten.extend(self._katalog(t, "top", {"search": titel}))
            except Exception as fehler:
                log.warning("Cinemeta-Abgleich (%s): %s", t, fehler)
        sortiert = [k for k in ranking(titel, kandidaten) if stufe(titel, k["titel"]) <= MAX_STUFE]
        if not sortiert:
            return None
        if jahr:
            try:
                jahr_i = int(jahr)
            except (TypeError, ValueError):
                jahr_i = None
            if jahr_i is not None:
                passend = [k for k in sortiert if k["jahr"][:4].isdigit() and abs(int(k["jahr"][:4]) - jahr_i) <= 1]
                if passend:
                    sortiert = passend
        beste_stufe = stufe(titel, sortiert[0]["titel"])
        auf_bester_stufe = [k for k in sortiert if stufe(titel, k["titel"]) == beste_stufe]
        ergebnis = dict(sortiert[0])
        ergebnis["sicher"] = len({k["id"] for k in auf_bester_stufe}) == 1
        return ergebnis

    def smart_suche(self, deutung):
        karten = []
        for typ in deutung["typen"]:
            karten.extend(self.katalog(typ, deutung["sortierung"], deutung["genre"] or "")["titel"])
        if deutung["anzahl"]:
            karten = karten[:deutung["anzahl"]]
        return karten

    def details(self, typ, sid):
        if typ not in TYPEN or not re.match(r"^tt\d{1,10}$", sid):
            raise ValueError("Details gibt es nur zu IMDb-IDs (tt...)")
        meta = self._json("/meta/%s/%s.json" % (typ, sid)).get("meta") or {}
        if not meta:
            raise NetzFehler("Titel nicht gefunden")
        ergebnis = karte(meta, typ)
        ergebnis.update(besetzung=[str(c) for c in (meta.get("cast") or [])[:6]],
                        tvdb=str(meta.get("tvdb_id") or ""),
                        tmdb=str(meta.get("moviedb_id") or ""),
                        regie=[str(c) for c in (meta.get("director") or [])[:3]],
                        beschreibung=str(meta.get("description") or ""), trailer=trailer_von(meta))
        folgen = []
        for v in meta.get("videos") or []:
            if isinstance(v, dict) and v.get("season") and (v.get("episode") or v.get("number")):
                folgen.append({"id": str(v.get("id") or ""), "staffel": int(v["season"]),
                               "folge": int(v.get("episode") or v.get("number")),
                               "titel": str(v.get("name") or v.get("title") or ""),
                               "bild": str(v.get("thumbnail") or ""),
                               "datum": str(v.get("released") or v.get("firstAired") or "")[:10],
                               "beschreibung": str(v.get("overview") or ""),
                               "laufzeit": str(v.get("runtime") or "")})
        folgen.sort(key=lambda f: (f["staffel"], f["folge"]))
        ergebnis["folgen"] = folgen
        return ergebnis

    def genres(self):
        return {typ: [{"id": g, "name": n} for g, n in GENRES.items() if typ == "series" or g not in NUR_SERIEN]
                for typ in TYPEN}

    def schliessen(self):
        self._pool.shutdown(wait=False)
