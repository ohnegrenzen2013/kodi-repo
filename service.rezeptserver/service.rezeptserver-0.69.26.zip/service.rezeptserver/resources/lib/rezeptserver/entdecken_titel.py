"""Entdecken, Titelhilfen: gescrapte Titel saeubern und ausdrueckliche Wuensche erkennen.

titel_bereinigen() macht aus einem Seitentitel Titel, Jahr und Serienhinweis, smart() erkennt Wuensche
wie "beste Horrorfilme". Kataloge, Suche und Details stehen in entdecken.py.
"""

import re
import time

# Cinemeta-Genre -> deutscher Name
GENRES = {"Action": "Action", "Adventure": "Abenteuer", "Animation": "Animation", "Biography": "Biografie",
          "Comedy": "Komödie", "Crime": "Krimi", "Documentary": "Dokumentation", "Drama": "Drama",
          "Family": "Familie", "Fantasy": "Fantasy", "History": "Historie", "Horror": "Horror",
          "Mystery": "Mystery", "Romance": "Liebe", "Sci-Fi": "Sci-Fi", "Sport": "Sport", "Thriller": "Thriller",
          "War": "Krieg", "Western": "Western", "Reality-TV": "Reality-TV", "Talk-Show": "Talkshow",
          "Game-Show": "Spielshow"}


# --- Titel von gescrapten Seiten saeubern (fuer Entdecken.aufloesen, eigene_quelle.py) --------------------------

_JAHR = re.compile(r"[\(\[]?((?:18|19|20)\d{2})[\)\]]?")
_FUELLWORT = re.compile(
    r"\b(stream(?:en|ing)?|deutsch|german|online|anschauen|kostenlos|ganzer\s+film|komplett(?:er)?|"
    r"hd|4k|2160p?|1080p?|720p?|480p?|kinox(?:\.to)?|movie4k)\b", re.IGNORECASE)
_SERIE_HINWEIS = re.compile(r"\b(staffel\s*\d+|season\s*\d+|s\d{1,2}e\d{1,3})\b", re.IGNORECASE)
_TRENNER = re.compile(r"\s*[-|–]\s*")


def titel_bereinigen(roh):
    """Rohtitel einer gescrapten Seite (z. B. "Dune: Part Two (2024) Stream Deutsch HD") -> (titel, jahr,
    typ_hinweis). typ_hinweis ist "series" bei einem Staffel-/Folgen-Hinweis im Text, sonst ""."""
    text = " ".join(str(roh or "").split())
    typ_hinweis = "series" if _SERIE_HINWEIS.search(text) else ""
    text = _SERIE_HINWEIS.sub(" ", text)
    heutiges_jahr = int(time.strftime("%Y"))
    jahr = ""

    def _jahr_ersetzen(treffer):
        nonlocal jahr
        j = int(treffer.group(1))
        if not jahr and 1900 <= j <= heutiges_jahr + 1:
            jahr = treffer.group(1)
            return " "
        return treffer.group(0)

    text = _JAHR.sub(_jahr_ersetzen, text)
    text = _FUELLWORT.sub(" ", text)
    # am ersten Trenner abschneiden, wenn danach (nach dem Saeubern) kaum noch etwas steht
    teile = _TRENNER.split(text, maxsplit=1)
    if len(teile) == 2 and len(teile[0].strip()) >= 2 and len(teile[1].strip()) <= 2:
        text = teile[0]
    return " ".join(text.split())[:120], jahr, typ_hinweis


# --- Smart-Suche ----------------------------------------------------------------------------

_GENRE_WOERTER = [
    ("science fiction", "Sci-Fi"), ("science-fiction", "Sci-Fi"), ("scifi", "Sci-Fi"), ("sci-fi", "Sci-Fi"),
    ("dokumentationen", "Documentary"), ("dokumentation", "Documentary"), ("dokus", "Documentary"),
    ("doku", "Documentary"), ("documentary", "Documentary"),
    ("komödien", "Comedy"), ("komoedien", "Comedy"), ("komödie", "Comedy"), ("comedy", "Comedy"),
    ("abenteuer", "Adventure"), ("adventure", "Adventure"), ("action", "Action"), ("animation", "Animation"),
    ("zeichentrick", "Animation"), ("biografien", "Biography"), ("biografie", "Biography"), ("biography", "Biography"),
    ("krimi", "Crime"), ("crime", "Crime"), ("drama", "Drama"), ("dramen", "Drama"), ("familien", "Family"),
    ("familie", "Family"), ("family", "Family"), ("fantasy", "Fantasy"), ("historien", "History"),
    ("history", "History"), ("horror", "Horror"), ("mystery", "Mystery"), ("liebes", "Romance"),
    ("romantische", "Romance"), ("romance", "Romance"), ("sport", "Sport"), ("thriller", "Thriller"),
    ("kriegs", "War"), ("krieg", "War"), ("war", "War"), ("western", "Western"), ("anime", "Animation"),
]
_QUALIFIER = (r"top(?:\s+\d{1,3})?(?:\s+rated)?|beste[nrs]?|besten|beliebteste[nrs]?|beliebte[nrs]?|"
              r"neueste[nrs]?|neue[nrs]?|aktuelle[nrs]?|trending|best|popular|new|latest")
_GENRE_MUSTER = "|".join(re.escape(w) for w, _ in sorted(_GENRE_WOERTER, key=lambda p: -len(p[0])))
_TYP_MUSTER = r"filme|film|serien|serie|movies?|films?|shows?|tv shows?|series|animes?"
_SMART = re.compile(r"^(?P<qual>%s)\s+(?:(?P<genre>%s)[\s-]*)?(?P<typ>%s)$" % (_QUALIFIER, _GENRE_MUSTER, _TYP_MUSTER),
                    re.IGNORECASE)


def smart(text, jahr=None):
    """Ausdruecklicher Entdecken-Wunsch -> {deutung, typen, sortierung, genre, anzahl}, sonst None."""
    text = " ".join(str(text or "").lower().split())
    treffer = _SMART.match(text)
    if not treffer:
        return None
    qual, typ_wort = treffer.group("qual"), treffer.group("typ")
    genre = dict(_GENRE_WOERTER).get(treffer.group("genre") or "")
    anime = typ_wort.startswith("anime") or treffer.group("genre") == "anime"
    if anime:
        genre = "Animation"
    if typ_wort.startswith(("serie", "show", "tv")) or typ_wort == "series" or anime:
        typen = ["series"]
    else:
        typen = ["movie"]
    anzahl = re.search(r"top\s+(\d{1,3})", qual)
    if qual.startswith(("beste", "best", "top")):
        sortierung = "imdbRating"
    elif qual.startswith(("neue", "aktuelle", "new", "latest")):
        sortierung = "year"
    else:
        sortierung = "top"
    teile = []
    if anzahl:
        teile.append("Top %s" % anzahl.group(1))
    else:
        teile.append({"imdbRating": "Beste", "year": "Neue", "top": "Beliebte"}[sortierung])
    if genre:
        teile.append("Anime" if anime else GENRES.get(genre, genre))
    teile.append("Serien" if typen == ["series"] and not anime else ("" if anime else "Filme"))
    return {"deutung": " ".join(t for t in teile if t), "typen": typen, "sortierung": sortierung, "genre": genre,
            "anzahl": int(anzahl.group(1)) if anzahl else None, "jahr": jahr}
