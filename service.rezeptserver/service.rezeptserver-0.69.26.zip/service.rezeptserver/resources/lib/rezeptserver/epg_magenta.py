"""EPG-Grabber Magenta TV: Programmdaten der Sender als XMLTV, ohne fremde XMLTV-Quelle.

Nutzt den oeffentlichen Gast-Zugang der Magenta-TV-Webseite (kein Konto noetig), wie der
EPG-Grabber in vxparser (sunsettrack4). Geholt werden nur die Sender aus livetv.SENDER; die
XMLTV-Kennungen sind deren tvg-id, die Sendungen passen also zur eigenen /tv.m3u.

Ablauf: Login (Gast) -> Authenticate -> AllChannel (Sender-IDs pruefen) -> PlayBillList je Sender.
"""

import gzip
import http.client
import json
import logging
import re
import time
from xml.sax.saxutils import escape, quoteattr

log = logging.getLogger("rezeptserver")

NAME = "Magenta TV"
TAGE = 3
VERSUCHE = 4
HOST = "api.prod.sngtv.magentatv.de"
PFAD = "/EPG/JSON/"
USER_AGENT = "Mozilla/5.0 (X11; Linux x86_64; rv:140.0) Gecko/20100101 Firefox/140.0"
MAX_BYTES = 20 * 1024 * 1024

# sender-id aus livetv.SENDER -> (contentId bei Magenta, Name bei Magenta); DW Deutsch fuehrt Magenta nicht
SENDER = {
    "daserste": ("373", "Das Erste"), "zdf": ("408", "ZDF"), "3sat": ("392", "3sat"), "arte": ("394", "ARTE"),
    "phoenix": ("371", "phoenix"), "kika": ("387", "KiKA"), "zdfneo": ("391", "ZDFneo"),
    "zdfinfo": ("378", "ZDFinfo"), "tagesschau24": ("400", "tagesschau24"), "one": ("402", "ONE"),
    "ardalpha": ("479", "ARD-alpha"), "br": ("407", "BR Fernsehen Süd"), "hr": ("386", "hr-fernsehen"),
    "mdr": ("370", "MDR-Fernsehen Sachsen"), "ndr": ("377", "NDR Fernsehen Niedersachsen"),
    "rbb": ("384", "rbb fernsehen Berlin"), "sr": ("379", "SR Fernsehen"), "swr": ("398", "SWR Fernsehen BW"),
    "wdr": ("397", "WDR Fernsehen Köln"),
}

_LOGIN = {"userId": "Guest", "mac": "00:00:00:00:00:00"}
_AUTHENTICATE = {"terminalid": "00:00:00:00:00:00", "mac": "00:00:00:00:00:00", "terminaltype": "WEBTV",
                 "utcEnable": "1", "timezone": "UTC", "userType": "3", "terminalvendor": "Unknown",
                 "preSharedKeyID": "PC01P00002", "cnonce": "5c6ff0b9e4e5efb1498e7eaa8f54d9fb"}
_ALLE_SENDER = {"properties": [{"name": "logicalChannel", "include": "/channellist/logicalChannel/contentId,"
                                "/channellist/logicalChannel/name"}],
                "metaDataVer": "Channel/1.1", "channelNamespace": "2",
                "filterlist": [{"key": "IsHide", "value": "-1"}], "returnSatChannel": "0"}
_FELDER = '[{"name":"playbill","include":"id,channelid,name,subName,starttime,endtime,introduce,genres,' \
          'producedate,pictures,subNum,seasonNum"}]'
_ZEIT = re.compile(r"^(\d{4})-(\d\d)-(\d\d) (\d\d):(\d\d):(\d\d)(?: UTC([+-])(\d\d):?(\d\d))?")


class Sitzung:
    """POST mit JSON und Cookies ueber eine einzige, offen gehaltene HTTPS-Verbindung.

    Magenta verteilt neue Verbindungen auf mehrere Server, die die Gast-Sitzung nicht teilen. Mit einer
    neuen Verbindung je Anfrage (urllib) liefen deshalb die meisten Abrufe in "session expired"."""

    def __init__(self, host=HOST):
        self.host = host
        self.kopf = {"User-Agent": USER_AGENT, "Content-Type": "application/json", "Accept": "application/json"}
        self.kekse = {}
        self._verbindung = None

    def cookie(self, name):
        return self.kekse.get(name)

    def schliessen(self):
        if self._verbindung is not None:
            self._verbindung.close()
            self._verbindung = None

    def post(self, pfad, daten):
        koerper = json.dumps(daten).encode("utf-8")
        kopf = dict(self.kopf)
        if self.kekse:
            kopf["Cookie"] = "; ".join("%s=%s" % k for k in self.kekse.items())
        for versuch in (1, 2):  # eine eingeschlafene Verbindung einmal neu aufbauen
            if self._verbindung is None:
                self._verbindung = http.client.HTTPSConnection(self.host, timeout=60)
            try:
                self._verbindung.request("POST", PFAD + pfad, koerper, kopf)
                antwort = self._verbindung.getresponse()
                roh = antwort.read(MAX_BYTES + 1)
                break
            except (http.client.HTTPException, OSError):
                self.schliessen()
                if versuch == 2:
                    raise
        if len(roh) > MAX_BYTES:
            self.schliessen()
            raise OSError("Antwort groesser als %d MB" % (MAX_BYTES >> 20))
        for wert in antwort.headers.get_all("Set-Cookie") or []:
            name, _, rest = wert.partition("=")
            self.kekse[name.strip()] = rest.split(";", 1)[0].strip()
        if antwort.status != 200:
            raise OSError("HTTP %d bei %s" % (antwort.status, pfad.split("?", 1)[0]))
        return json.loads(roh.decode("utf-8"))


def _anmelden(sitzung):
    sitzung.kopf.pop("X_CSRFToken", None)  # mit altem Token schlaegt die neue Anmeldung still fehl
    sitzung.post("Login?&T=PC_firefox_75", _LOGIN)
    antwort = sitzung.post("Authenticate?SID=firstup&T=PC_firefox_75", _AUTHENTICATE)
    if str(antwort.get("retcode", "0")) != "0":
        raise OSError("Magenta-Anmeldung abgelehnt (retcode %s)" % antwort.get("retcode"))
    token = sitzung.cookie("CSRFSESSION")
    if not token:
        raise OSError("Magenta-Anmeldung ohne CSRF-Token")
    sitzung.kopf["X_CSRFToken"] = token


def _abfrage(sitzung, pfad, daten, versuche=VERSUCHE):
    """POST; laeuft die Gast-Sitzung ab (retcode -2, kommt bei Magenta immer wieder vor), neu anmelden."""
    for versuch in range(versuche):
        antwort = sitzung.post(pfad, daten)
        if str(antwort.get("retcode", "0")) != "-2":
            return antwort
        if versuch + 1 < versuche:
            _anmelden(sitzung)
    raise OSError("Magenta-Sitzung laeuft immer wieder ab")


def _name(text):
    return re.sub(r"[^a-z0-9]", "", str(text).lower().replace("ü", "u").replace("ö", "o").replace("ä", "a"))


def sender_ids(liste):
    """contentId je sender-id aus der Magenta-Senderliste: erst die bekannte ID, sonst ueber den Namen."""
    ids = {str(k.get("contentId")) for k in liste}
    namen = {_name(k.get("name")): str(k.get("contentId")) for k in liste}
    ergebnis = {}
    for sid, (cid, name) in SENDER.items():
        if cid in ids:
            ergebnis[sid] = cid
        elif _name(name) in namen:
            ergebnis[sid] = namen[_name(name)]
    return ergebnis


def xmltv_zeit(text):
    """'2026-10-10 22:25:00 UTC+00:00' -> '20261010222500 +0000', None wenn unverstaendlich."""
    t = _ZEIT.match(str(text or ""))
    if not t:
        return None
    j, mo, d, h, mi, s, vz, oh, om = t.groups()
    return "%s%s%s%s%s%s %s%s%s" % (j, mo, d, h, mi, s, vz or "+", oh or "00", om or "00")


def _bild(sendung):
    for bild in sendung.get("pictures") or []:
        if isinstance(bild, dict) and bild.get("href"):
            return bild["href"]
    return (sendung.get("picture") or {}).get("poster")


def programm_xml(sendung, kanal):
    start, ende = xmltv_zeit(sendung.get("starttime")), xmltv_zeit(sendung.get("endtime"))
    if not start or not ende or not sendung.get("name"):
        return None
    zeilen = ['<programme start="%s" stop="%s" channel=%s>' % (start, ende, quoteattr(kanal)),
              '<title lang="de">%s</title>' % escape(str(sendung["name"]))]
    if sendung.get("subName"):
        zeilen.append('<sub-title lang="de">%s</sub-title>' % escape(str(sendung["subName"])))
    if sendung.get("introduce"):
        zeilen.append('<desc lang="de">%s</desc>' % escape(str(sendung["introduce"])))
    jahr = str(sendung.get("producedate") or "")[:4]
    if jahr.isdigit():
        zeilen.append("<date>%s</date>" % jahr)
    for genre in str(sendung.get("genres") or "").split(","):
        if genre.strip():
            zeilen.append('<category lang="de">%s</category>' % escape(genre.strip()))
    bild = _bild(sendung)
    if bild:
        zeilen.append("<icon src=%s/>" % quoteattr(str(bild)))
    staffel, folge = str(sendung.get("seasonNum") or ""), str(sendung.get("subNum") or "")
    if folge.isdigit():
        zeilen.append('<episode-num system="onscreen">%s</episode-num>'
                      % (("S%s E%s" % (staffel, folge)) if staffel.isdigit() else "E" + folge))
    zeilen.append("</programme>")
    return "".join(zeilen)


def schreibe(pfad, sender, sitzung=None, tage=TAGE, jetzt=None):
    """Holt die EPG der Sender und schreibt sie gepackt als XMLTV nach pfad.

    sender: [(sender-id, Name, tvg-id)]. Gibt die Zahl der Sendungen zurueck; ein einzelner Sender
    darf scheitern, liefert kein Sender etwas, gibt es einen Fehler (die alte Datei bleibt dann)."""
    eigene = sitzung is None
    sitzung = sitzung or Sitzung()
    try:
        return _schreibe(pfad, sender, sitzung, tage, jetzt)
    finally:
        if eigene:
            sitzung.schliessen()


def _schreibe(pfad, sender, sitzung, tage, jetzt):
    _anmelden(sitzung)
    ids = sender_ids(_abfrage(sitzung, "AllChannel?SID=first&T=PC_firefox_75", _ALLE_SENDER).get("channellist") or [])
    jetzt = time.time() if jetzt is None else jetzt
    beginn = time.strftime("%Y%m%d000000", time.gmtime(jetzt))
    ende = time.strftime("%Y%m%d235959", time.gmtime(jetzt + (tage - 1) * 86400))
    kanaele, programme, fehler = [], [], []
    for sid, name, tvg_id in sender:
        cid = ids.get(sid)
        if not cid:
            continue
        try:
            antwort = _abfrage(sitzung, "PlayBillList?userContentFilter=241221015&sessionArea=1&SID=ottall&T=PC_firefox_75",
                               {"channelid": cid, "type": "2", "offset": "0", "count": "-1", "isFillProgram": "1",
                                "properties": _FELDER, "begintime": beginn, "endtime": ende})
        except (OSError, ValueError) as f:
            fehler.append("%s: %s" % (name, f))
            continue
        if "playbilllist" not in antwort:
            fehler.append("%s: %s" % (name, antwort.get("desc") or "keine Sendungsliste"))
            continue
        neu = [p for p in (programm_xml(s, tvg_id) for s in antwort.get("playbilllist") or []
                           if isinstance(s, dict) and s.get("type", "PROGRAM") == "PROGRAM") if p]
        if neu:
            kanaele.append('<channel id=%s><display-name lang="de">%s</display-name></channel>'
                           % (quoteattr(tvg_id), escape(name)))
            programme.extend(neu)
    if fehler:
        log.warning("%s-EPG: %d Sender ohne Daten (%s)", NAME, len(fehler), "; ".join(fehler[:3]))
    if not programme:
        raise OSError("%s lieferte keine Sendungen" % NAME)
    with gzip.open(pfad, "wt", encoding="utf-8") as f:
        f.write('<?xml version="1.0" encoding="UTF-8"?>\n<tv generator-info-name="m0dulh0st (%s)">\n' % NAME)
        for zeile in kanaele + programme:
            f.write(zeile + "\n")
        f.write("</tv>\n")
    return len(programme)
