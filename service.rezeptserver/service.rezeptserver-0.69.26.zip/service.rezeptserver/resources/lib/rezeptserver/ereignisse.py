"""Meldestelle: Module melden Ereignisse (Ausfall, Download fertig ...), Empfaenger wie Telegram hoeren mit.

  ereignisse.melden("waechter", "Eweka gestört: …", ok=False)
  ereignisse.anmelden(funktion)   # funktion(art, text, ok)

Arten: "waechter" (Verfuegbarkeit), "download" (XDCC, YouTube), "update" (Aktualisierung aus GitHub). Ein Empfaenger darf den Melder nie aufhalten.
"""

import logging
import threading

log = logging.getLogger("rezeptserver")
_empfaenger = []
_sperre = threading.Lock()


def anmelden(funktion):
    with _sperre:
        if funktion not in _empfaenger:
            _empfaenger.append(funktion)


def abmelden(funktion):
    with _sperre:
        if funktion in _empfaenger:
            _empfaenger.remove(funktion)


def melden(art, text, ok=True):
    with _sperre:
        liste = list(_empfaenger)
    for funktion in liste:
        try:
            funktion(art, text, ok)
        except Exception as fehler:
            log.warning("Meldung an %s: %s", getattr(funktion, "__name__", funktion), fehler)
