"""Fernseher & Geraete: alles, worauf H0rSt etwas schicken kann (wie Castify) – hinter einer Schnittstelle.

  cast     Google Cast: Chromecast, Google TV, Nest/Google-Home-Lautsprecher (cast.py)
  dlna     DLNA/UPnP-Renderer: Smart-TVs (Samsung, LG, Sony, Philips, Panasonic …), AV-Receiver, Kodi, VLC
           Finden per SSDP, abspielen ueber AVTransport (SetAVTransportURI, Play …), Lautstaerke ueber RenderingControl
  roku     Roku (ECP, Port 8060): abspielen ueber den Kanal "Play on Roku" (15985), Tasten fuer Pause/Lautstaerke
  enigma2  Receiver mit Enigma2 und OpenWebif: Dreambox (One 4K …), Vu+, Gigablue, OpenATV/OpenPLi
           Abspielen als Dienst 4097 (URL), Fernbedienung, Lautstaerke; dazu TV- und Radio-Favoriten als Live-TV-Listen

Jedes Geraet: {"id", "art", "name", "ip", "port", "modell", …}. abspielen() und steuern() liefern den Stand
einheitlich: {"app", "zustand" (PLAYING|PAUSED|BUFFERING|IDLE), "titel", "lautstaerke", "stumm"}.
Gespeichert (Nutzerdaten "cast_geraete"): von Hand eingetragene Geraete; "cast_standard": id des Standard-Geraets.
"""

from .fernseher_grund import *
from .fernseher_grund import _IP
from .fernseher_finden import dlna_beschreibung, medienart, roku_info, ssdp_antworten, suchen, _holen, _text, _xml
from .fernseher_dlna import didl, _DLNA_ZUSTAND, _dlna_stand, _soap
from .fernseher_roku import _roku, _roku_stand
from .fernseher_enigma2 import e2_dienst, enigma2_bouquets, enigma2_info, _e2, _e2_kopf, _e2_stand, _e2_url
from .fernseher_wiedergabe import abspielen, oeffentlich, pruefe_eintrag, steuern
