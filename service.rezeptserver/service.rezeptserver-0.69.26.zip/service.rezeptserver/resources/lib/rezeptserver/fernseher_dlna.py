"""DLNA/UPnP: SOAP-Aufrufe (AVTransport, RenderingControl), DIDL-Metadaten und der Stand."""

from .fernseher_grund import (
    GeraetFehler,
    cast,
    escape,
)

from .fernseher_finden import _holen, _text, _xml, medienart

def _soap(g, dienst, aktion, werte, holen=_holen):
    if dienst not in (g.get("steuer") or {}):
        raise GeraetFehler("Das kann dieses Gerät nicht")
    typ = "urn:schemas-upnp-org:service:%s:1" % ("AVTransport" if dienst == "avt" else "RenderingControl")
    teile = "".join("<%s>%s</%s>" % (k, escape(str(v)), k) for k, v in werte)
    koerper = ('<?xml version="1.0" encoding="utf-8"?><s:Envelope xmlns:s="http://schemas.xmlsoap.org/soap/envelope/" '
               's:encodingStyle="http://schemas.xmlsoap.org/soap/encoding/"><s:Body><u:%s xmlns:u="%s">%s</u:%s>'
               '</s:Body></s:Envelope>' % (aktion, typ, teile, aktion)).encode("utf-8")
    status, roh = holen(g["steuer"][dienst], "POST", {"Content-Type": 'text/xml; charset="utf-8"',
                                                      "SOAPACTION": '"%s#%s"' % (typ, aktion)}, koerper, 8)
    if status != 200:
        fehler = _text(_xml(roh), "errorDescription") if roh.strip().startswith(b"<") else ""
        raise GeraetFehler("%s: %s" % (aktion, fehler or "HTTP %d" % status))
    return _xml(roh)


def didl(url, titel, bild="", mime=None):
    art = medienart(url, mime)
    mime = mime or (cast.inhaltstyp(url) if art == "video" else "audio/mpeg")
    klasse = "object.item.videoItem" if art == "video" else "object.item.audioItem.musicTrack"
    return ('<DIDL-Lite xmlns="urn:schemas-upnp-org:metadata-1-0/DIDL-Lite/" xmlns:dc="http://purl.org/dc/elements/1.1/" '
            'xmlns:upnp="urn:schemas-upnp-org:metadata-1-0/upnp/"><item id="0" parentID="-1" restricted="1">'
            '<dc:title>%s</dc:title><upnp:class>%s</upnp:class>%s<res protocolInfo="http-get:*:%s:*">%s</res></item>'
            '</DIDL-Lite>' % (escape(titel or "H0rSt"), klasse,
                              "<upnp:albumArtURI>%s</upnp:albumArtURI>" % escape(bild) if bild else "", mime, escape(url)))


_DLNA_ZUSTAND = {"PLAYING": "PLAYING", "PAUSED_PLAYBACK": "PAUSED", "TRANSITIONING": "BUFFERING", "STOPPED": "IDLE",
                 "NO_MEDIA_PRESENT": "IDLE"}


def _dlna_stand(g, holen):
    zustand = _text(_soap(g, "avt", "GetTransportInfo", [("InstanceID", 0)], holen), "CurrentTransportState")
    titel = ""
    try:
        meta = _text(_soap(g, "avt", "GetPositionInfo", [("InstanceID", 0)], holen), "TrackMetaData")
        if meta.startswith("<"):
            titel = _text(_xml(meta.encode("utf-8")), "title")
    except GeraetFehler:
        pass
    lautst, stumm = 0, False
    if "rc" in g.get("steuer", {}):
        try:
            lautst = int(_text(_soap(g, "rc", "GetVolume", [("InstanceID", 0), ("Channel", "Master")], holen), "CurrentVolume") or 0)
            stumm = _text(_soap(g, "rc", "GetMute", [("InstanceID", 0), ("Channel", "Master")], holen), "CurrentMute") in ("1", "true")
        except (GeraetFehler, ValueError):
            pass
    return {"app": "DLNA", "zustand": _DLNA_ZUSTAND.get(zustand, zustand), "titel": titel, "lautstaerke": lautst, "stumm": stumm}


