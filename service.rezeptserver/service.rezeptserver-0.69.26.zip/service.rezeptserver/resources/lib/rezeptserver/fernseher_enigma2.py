"""Enigma2 (OpenWebif): Aufrufe, Geraeteinfo, Dienstreferenzen, Stand und Bouquets."""

from .fernseher_grund import (
    GeraetFehler,
    base64,
    quote,
    re,
    urlencode,
)

from .fernseher_finden import _holen

def _e2_url(g, pfad):
    return "http://%s%s%s" % (g["ip"], "" if int(g.get("port") or 80) == 80 else ":%d" % int(g["port"]), pfad)


def _e2_kopf(g):
    if not g.get("benutzer"):
        return {}
    return {"Authorization": "Basic " + base64.b64encode(("%s:%s" % (g["benutzer"], g.get("passwort", ""))).encode("utf-8")).decode("ascii")}


def _e2(g, pfad, holen):
    import json
    status, roh = holen(_e2_url(g, pfad), kopf=_e2_kopf(g), zeit=8)
    if status == 401:
        raise GeraetFehler("Receiver: Benutzer oder Passwort falsch")
    if status != 200:
        raise GeraetFehler("Receiver: HTTP %d" % status)
    try:
        return json.loads(roh) if roh.strip() else {}
    except ValueError:
        return {}


def enigma2_info(ip, port=80, benutzer="", passwort="", holen=_holen):
    import json
    g = {"id": "enigma2:" + ip, "art": "enigma2", "name": ip, "ip": ip, "port": int(port or 80), "modell": "",
         "benutzer": benutzer, "passwort": passwort}
    status, roh = holen(_e2_url(g, "/api/about"), kopf=_e2_kopf(g), zeit=5)
    if status == 401:
        raise GeraetFehler("Receiver verlangt Benutzer und Passwort (OpenWebif)")
    if status != 200:
        raise GeraetFehler("Kein OpenWebif gefunden (HTTP %d) – läuft es auf dem Receiver?" % status)
    try:
        info = (json.loads(roh) or {}).get("info") or {}
    except ValueError:
        raise GeraetFehler("Kein OpenWebif gefunden")
    marke = str(info.get("brand") or "").strip()
    modell = str(info.get("model") or info.get("boxtype") or "").strip()
    g["name"] = " ".join(x for x in (marke, modell) if x) or ip
    g["modell"] = " · ".join(x for x in (info.get("imagedistro"), info.get("imagever")) if x)
    return g


def e2_dienst(url, titel=""):
    """Dienstreferenz fuer eine Adresse: 4097 = Medienwiedergabe (GStreamer/exteplayer3) des Receivers."""
    name = re.sub(r"[:\n]", " ", titel or "H0rSt")
    return "4097:0:1:0:0:0:0:0:0:0:%s:%s" % (quote(url, safe=""), name)


def _e2_stand(g, holen):
    vol = _e2(g, "/api/vol", holen)
    jetzt = _e2(g, "/api/getcurrent", holen)
    info, sendung = jetzt.get("info") or {}, jetzt.get("now") or {}
    name = str(info.get("name") or "")
    return {"app": name, "zustand": "PLAYING" if name else "IDLE", "titel": str(sendung.get("title") or ""),
            "lautstaerke": int(vol.get("current") or 0), "stumm": bool(vol.get("ismute"))}


def enigma2_bouquets(g, art="tv", holen=_holen):
    """[{"name", "url"}]: Favoriten-Listen (Bouquets) des Receivers als M3U-Adressen fuer Live-TV."""
    if art not in ("tv", "radio"):
        raise GeraetFehler("tv oder radio")
    listen = []
    for eintrag in _e2(g, "/api/bouquets?" + urlencode({"stype": art}), holen).get("bouquets") or []:
        if not isinstance(eintrag, (list, tuple)) or len(eintrag) < 2:
            continue
        ref, name = str(eintrag[0]), str(eintrag[1])
        zugang = ""
        if g.get("benutzer"):
            zugang = "%s:%s@" % (quote(g["benutzer"], safe=""), quote(g.get("passwort", ""), safe=""))
        port = "" if int(g.get("port") or 80) == 80 else ":%d" % int(g["port"])
        listen.append({"name": ("%s – %s" % (g["name"], name))[:60],
                       "url": "http://%s%s%s/web/services.m3u?%s" % (zugang, g["ip"], port, urlencode({"bRef": ref, "bName": name}))})
    return listen


