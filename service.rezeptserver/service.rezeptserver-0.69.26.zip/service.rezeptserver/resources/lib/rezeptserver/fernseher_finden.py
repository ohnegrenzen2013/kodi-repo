"""Geraete finden: Google Cast, DLNA/SSDP und Roku ueber deren Schnittstellen."""

from .fernseher_grund import (
    ET,
    GeraetFehler,
    RENDERER,
    ROKU_ST,
    SSDP,
    USER_AGENT,
    cast,
    socket,
    threading,
    time,
    urljoin,
    urllib,
    urlsplit,
)

def _holen(url, methode="GET", kopf=None, koerper=None, zeit=8):
    """(status, bytes); HTTP-Fehler kommen als Status zurueck, Netzfehler als GeraetFehler."""
    anfrage = urllib.request.Request(url, data=koerper, method=methode, headers=dict({"User-Agent": USER_AGENT}, **(kopf or {})))
    try:
        with urllib.request.urlopen(anfrage, timeout=zeit) as a:
            return a.status, a.read(2 * 1024 * 1024)
    except urllib.error.HTTPError as fehler:
        try:
            return fehler.code, fehler.read(64 * 1024)
        finally:
            fehler.close()
    except (urllib.error.URLError, OSError) as fehler:
        raise GeraetFehler("Gerät nicht erreichbar: %s" % getattr(fehler, "reason", fehler))


def medienart(url, mime=None):
    """video oder audio (fuer Metadaten und Roku); ein bekannter Inhaltstyp (Radio: audio/mpeg …) geht vor."""
    if mime:
        return "audio" if mime.startswith("audio/") else "video"
    pfad = url.split("?", 1)[0].lower()
    return "audio" if pfad.endswith((".mp3", ".aac", ".m4a", ".flac", ".ogg", ".opus", ".wav")) else "video"


def ssdp_antworten(dauer=2.5, sock=None, uhr=time.monotonic):
    """M-SEARCH nach Renderern und Roku: [{"ort", "st", "usn", "ip"}]."""
    s = sock or socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    gefunden = {}
    try:
        if sock is None:
            s.setsockopt(socket.IPPROTO_IP, socket.IP_MULTICAST_TTL, 2)
            s.bind(("0.0.0.0", 0))
        s.settimeout(0.3)
        for st in (RENDERER, ROKU_ST):
            s.sendto(("M-SEARCH * HTTP/1.1\r\nHOST: 239.255.255.250:1900\r\nMAN: \"ssdp:discover\"\r\nMX: 2\r\n"
                      "ST: %s\r\n\r\n" % st).encode("ascii"), SSDP)
        ende = uhr() + dauer
        while uhr() < ende:
            try:
                daten, absender = s.recvfrom(4096)
            except socket.timeout:
                continue
            except OSError:
                break
            kopf = {}
            for zeile in daten.decode("utf-8", "replace").split("\r\n")[1:]:
                k, _, v = zeile.partition(":")
                if k.strip():
                    kopf[k.strip().lower()] = v.strip()
            if kopf.get("location"):
                gefunden[kopf["location"]] = {"ort": kopf["location"], "st": kopf.get("st", ""), "usn": kopf.get("usn", ""),
                                              "ip": absender[0]}
    finally:
        if sock is None:
            s.close()
    return list(gefunden.values())


def _xml(roh):
    try:
        return ET.fromstring(roh)
    except ET.ParseError:
        raise GeraetFehler("Antwort ist kein gültiges XML")


def _text(knoten, name):
    """Erstes Unterelement mit diesem Namen (Namensraum egal)."""
    for k in knoten.iter():
        if k.tag.rsplit("}", 1)[-1] == name:
            return (k.text or "").strip()
    return ""


def dlna_beschreibung(ort, holen=_holen):
    """Geraetebeschreibung eines Renderers -> Geraet mit AVTransport- und RenderingControl-Adresse."""
    status, roh = holen(ort, zeit=4)
    if status != 200:
        raise GeraetFehler("Beschreibung: HTTP %d" % status)
    wurzel = _xml(roh)
    basis = _text(wurzel, "URLBase") or ort
    steuer = {}
    for dienst in wurzel.iter():
        if dienst.tag.rsplit("}", 1)[-1] != "service":
            continue
        typ, adresse = _text(dienst, "serviceType"), _text(dienst, "controlURL")
        if "AVTransport" in typ:
            steuer["avt"] = urljoin(basis, adresse)
        elif "RenderingControl" in typ:
            steuer["rc"] = urljoin(basis, adresse)
    if "avt" not in steuer:
        raise GeraetFehler("Kein AVTransport – das Gerät spielt nichts ab")
    teile = urlsplit(ort)
    modell = " ".join(x for x in (_text(wurzel, "manufacturer"), _text(wurzel, "modelName")) if x)
    return {"id": "dlna:" + (_text(wurzel, "UDN").replace("uuid:", "") or teile.hostname), "art": "dlna",
            "name": _text(wurzel, "friendlyName") or teile.hostname, "ip": teile.hostname, "port": teile.port or 80,
            "modell": modell, "ort": ort, "steuer": steuer}


def roku_info(ip, holen=_holen):
    status, roh = holen("http://%s:8060/query/device-info" % ip, zeit=4)
    if status != 200:
        raise GeraetFehler("Roku antwortet nicht (HTTP %d)" % status)
    w = _xml(roh)
    return {"id": "roku:" + ip, "art": "roku", "name": _text(w, "user-device-name") or _text(w, "friendly-device-name") or "Roku",
            "ip": ip, "port": 8060, "modell": _text(w, "model-name")}


def suchen(dauer=2.5, holen=_holen, ssdp=ssdp_antworten, cast_suchen=cast.suchen):
    """Alle Geraete im Heimnetz: Google Cast und SSDP (DLNA-Renderer, Roku) gleichzeitig."""
    ergebnis, sperre = [], threading.Lock()

    def gc():
        try:
            gefunden = cast_suchen(dauer)
        except OSError:
            return
        with sperre:
            ergebnis.extend(dict(g, id="cast:" + g["ip"], art="cast") for g in gefunden)

    faden = threading.Thread(target=gc, daemon=True)
    faden.start()
    try:
        antworten = ssdp(dauer)
    except OSError:
        antworten = []
    for a in antworten:
        try:
            if a["st"] == ROKU_ST or "roku" in a["usn"].lower():
                g = roku_info(urlsplit(a["ort"]).hostname or a["ip"], holen)
            else:
                g = dlna_beschreibung(a["ort"], holen)
        except (GeraetFehler, KeyError):
            continue
        with sperre:
            if all(x["id"] != g["id"] for x in ergebnis):
                ergebnis.append(g)
    faden.join(dauer + 2)
    return sorted(ergebnis, key=lambda g: (g["art"] != "cast", g["name"].lower()))


