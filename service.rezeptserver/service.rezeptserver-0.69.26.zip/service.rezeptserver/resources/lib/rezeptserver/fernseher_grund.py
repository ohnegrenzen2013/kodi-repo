"""Grundlage von Fernseher: Importe, Geraetearten, Fehler und die Suchadressen.
Alles hier wird samt Importen wieder exportiert (rezeptserver.fernseher.*)."""


import base64
import re
import socket
import threading
import time
import urllib.error
import urllib.request
import xml.etree.ElementTree as ET
from urllib.parse import quote, urlencode, urljoin, urlsplit
from xml.sax.saxutils import escape

from . import cast
from .netz import USER_AGENT

ARTEN = {"cast": "Chromecast / Google TV", "dlna": "Smart-TV (DLNA)", "roku": "Roku", "enigma2": "Receiver (Enigma2)"}
SSDP = ("239.255.255.250", 1900)
RENDERER = "urn:schemas-upnp-org:device:MediaRenderer:1"
ROKU_ST = "roku:ecp"
PLAY_ON_ROKU = "15985"
_IP = re.compile(r"^\d{1,3}(\.\d{1,3}){3}$")


class GeraetFehler(ValueError):
    pass
