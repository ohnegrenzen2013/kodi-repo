"""Roku (ECP): Anfragen und der Wiedergabe-Stand."""

from .fernseher_grund import (
    GeraetFehler,
)

from .fernseher_finden import _text, _xml

def _roku(g, pfad, holen, methode="POST"):
    status, roh = holen("http://%s:%d%s" % (g["ip"], g.get("port") or 8060, pfad), methode, None, b"" if methode == "POST" else None, 8)
    if status not in (200, 202, 204):
        raise GeraetFehler("Roku: HTTP %d" % status)
    return roh


def _roku_stand(g, holen):
    w = _xml(_roku(g, "/query/media-player", holen, "GET"))
    zustand = {"play": "PLAYING", "pause": "PAUSED", "buffer": "BUFFERING"}.get(w.get("state", ""), "IDLE")
    app = ""
    try:
        app = _text(_xml(_roku(g, "/query/active-app", holen, "GET")), "app")
    except GeraetFehler:
        pass
    return {"app": app, "zustand": zustand, "titel": "", "lautstaerke": None, "stumm": False}


