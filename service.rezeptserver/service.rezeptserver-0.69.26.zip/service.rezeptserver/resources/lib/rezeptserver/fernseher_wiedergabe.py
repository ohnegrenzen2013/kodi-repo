"""Einheitlich abspielen und steuern sowie Geraete pruefen und kuerzen."""

from .fernseher_grund import (
    GeraetFehler,
    PLAY_ON_ROKU,
    _IP,
    cast,
    urlencode,
    urlsplit,
)

from .fernseher_dlna import _dlna_stand, _soap, didl

from .fernseher_enigma2 import _e2, _e2_stand, e2_dienst

from .fernseher_finden import _holen, medienart

from .fernseher_roku import _roku, _roku_stand

def abspielen(g, url, titel="", bild="", live=False, holen=_holen, cast_oeffnen=None, mime=None):
    """mime: Inhaltstyp, wenn bekannt (Radio-Sender ohne Dateiendung: audio/mpeg, audio/aac …)."""
    art = g.get("art", "cast")
    if art == "cast":
        return cast.abspielen(g["ip"], url, titel, bild, live, g.get("port", 8009), cast_oeffnen, mime)
    if art == "dlna":
        try:
            _soap(g, "avt", "Stop", [("InstanceID", 0)], holen)  # manche Fernseher nehmen sonst keine neue Adresse
        except GeraetFehler:
            pass
        _soap(g, "avt", "SetAVTransportURI", [("InstanceID", 0), ("CurrentURI", url), ("CurrentURIMetaData", didl(url, titel, bild, mime))], holen)
        _soap(g, "avt", "Play", [("InstanceID", 0), ("Speed", 1)], holen)
        return {"zustand": "PLAYING", "titel": titel}
    if art == "roku":
        teile = urlsplit(url).path.lower()
        format_ = "hls" if ".m3u8" in teile or "/api/hls/" in teile else "mkv" if teile.endswith(".mkv") else "mp4"
        werte = {"t": "a" if medienart(url, mime) == "audio" else "v", "u": url, "videoName": titel or "H0rSt", "videoFormat": format_}
        if bild:
            werte["k"] = bild
        _roku(g, "/input/%s?%s" % (PLAY_ON_ROKU, urlencode(werte)), holen)
        return {"zustand": "PLAYING", "titel": titel}
    if art == "enigma2":
        _e2(g, "/api/zap?" + urlencode({"sRef": e2_dienst(url, titel)}), holen)
        return {"zustand": "PLAYING", "titel": titel}
    raise GeraetFehler("Unbekannte Geräteart")


def steuern(g, was, wert=None, holen=_holen, cast_oeffnen=None):
    """was: pause, weiter, stopp, lautstaerke (0-100), lauter, leiser, stumm, stand."""
    art = g.get("art", "cast")
    if art == "cast":
        if was in ("lauter", "leiser"):
            stand = cast.steuern(g["ip"], "stand", port=g.get("port", 8009), oeffnen=cast_oeffnen)
            was, wert = "lautstaerke", max(0, min(100, stand["lautstaerke"] + (10 if was == "lauter" else -10)))
        return cast.steuern(g["ip"], was, wert, g.get("port", 8009), cast_oeffnen)
    if was not in ("pause", "weiter", "stopp", "lautstaerke", "lauter", "leiser", "stumm", "stand"):
        raise GeraetFehler("Unbekannter Befehl")
    if art == "dlna":
        if was in ("pause", "weiter", "stopp"):
            _soap(g, "avt", {"pause": "Pause", "weiter": "Play", "stopp": "Stop"}[was],
                  [("InstanceID", 0)] + ([("Speed", 1)] if was == "weiter" else []), holen)
        elif was in ("lautstaerke", "lauter", "leiser"):
            if was != "lautstaerke":
                jetzt = _dlna_stand(g, holen)["lautstaerke"] or 0
                wert = jetzt + (5 if was == "lauter" else -5)
            _soap(g, "rc", "SetVolume", [("InstanceID", 0), ("Channel", "Master"), ("DesiredVolume", max(0, min(100, int(wert))))], holen)
        elif was == "stumm":
            _soap(g, "rc", "SetMute", [("InstanceID", 0), ("Channel", "Master"), ("DesiredMute", 1 if wert else 0)], holen)
        return _dlna_stand(g, holen)
    if art == "roku":
        taste = {"pause": "Play", "weiter": "Play", "stopp": "Back", "lauter": "VolumeUp", "leiser": "VolumeDown",
                 "stumm": "VolumeMute"}.get(was)
        if was == "lautstaerke":
            raise GeraetFehler("Roku kennt nur lauter und leiser")
        if taste:
            _roku(g, "/keypress/" + taste, holen)
        return _roku_stand(g, holen)
    if art == "enigma2":
        if was in ("pause", "weiter"):
            _e2(g, "/api/remotecontrol?command=164", holen)  # KEY_PLAYPAUSE
        elif was == "stopp":
            _e2(g, "/api/remotecontrol?command=128", holen)  # KEY_STOP
        elif was == "lautstaerke":
            _e2(g, "/api/vol?set=set%d" % max(0, min(100, int(wert))), holen)
        elif was in ("lauter", "leiser"):
            _e2(g, "/api/vol?set=" + ("up" if was == "lauter" else "down"), holen)
        elif was == "stumm":
            _e2(g, "/api/vol?set=mute", holen)
        return _e2_stand(g, holen)
    raise GeraetFehler("Unbekannte Geräteart")


def pruefe_eintrag(roh):
    """Von Hand eingetragenes Geraet: {"art", "ip", "name", "port", "benutzer", "passwort"}."""
    if not isinstance(roh, dict):
        raise GeraetFehler("Gerät als Objekt")
    art = roh.get("art") or "cast"
    if art not in ("cast", "roku", "enigma2"):
        raise GeraetFehler("Von Hand gehen Chromecast, Roku und Enigma2 – DLNA-Fernseher findet die Suche")
    ip = str(roh.get("ip") or "").strip()
    if not _IP.match(ip):
        raise GeraetFehler("IP-Adresse wie 192.168.178.50")
    port = int(roh.get("port") or {"cast": 8009, "roku": 8060, "enigma2": 80}[art])
    eintrag = {"id": "%s:%s" % (art, ip), "art": art, "ip": ip, "port": port,
               "name": " ".join(str(roh.get("name") or "").split())[:40] or ip}
    if art == "enigma2":
        eintrag["benutzer"] = str(roh.get("benutzer") or "")[:60]
        eintrag["passwort"] = str(roh.get("passwort") or "")[:100]
    return eintrag


def oeffentlich(g):
    """Fuer die Oberflaeche: ohne Passwort und interne Steueradressen."""
    return {k: v for k, v in dict(g, passwort_gesetzt=bool(g.get("passwort"))).items() if k not in ("passwort", "steuer", "ort")}


