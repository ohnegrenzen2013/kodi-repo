"""Mit dem Handy steuern: Das Handy koppelt sich per Code (oder QR-Code) mit H0rSt auf dem Fernseher und wird zu
Touchpad, Tastatur und Fernbedienung – fuer die H0rSt-Oberflaeche und die Brause.

H0rSt reicht die Eingaben nur weiter: alles liegt im Speicher, nichts auf der Platte. Der Fernseher holt sie ab und
wartet dabei, bis etwas kommt (lange Anfrage, hoechstens WARTEN Sekunden), so bleibt die Verzoegerung klein.

  POST /api/fernsteuerung {aktion: "neu", tv?}                Fernseher: Kennung (tv) und Code (10 Minuten gueltig)
  GET  /api/fernsteuerung?tv=…&nach=N                         Fernseher: Eingaben nach Nummer N (wartet bis zu WARTEN s)
  POST /api/fernsteuerung {aktion: "koppeln", code, name?}    Handy: Kennung (handy)
  POST /api/fernsteuerung {aktion: "senden", handy, eingaben}  Handy: Eingaben an den Fernseher
  GET  /api/fernsteuerung?handy=…                             Handy: noch verbunden, Fernseher erreichbar?
  POST /api/fernsteuerung {aktion: "trennen", tv | handy}
  GET  /api/fernsteuerung/qr.svg?text=…                       QR-Code (SVG), z. B. mit der Kopplungsadresse

Eingaben: {art: bewegen, dx, dy} | {art: klick} | {art: scrollen, dx?, dy} | {art: taste, taste: hoch|runter|links|
rechts|ok|zurueck|home} | {art: text, text} | {art: loeschen} | {art: eingabe} (Enter).
"""

import re
import secrets
import threading
import time

from . import qrcodegen

CODE_ZEICHEN = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"  # ohne 0/O und 1/I: am Fernseher gut lesbar
CODE_LAENGE = 6
CODE_GUELTIG = 600          # Sekunden, in denen ein Handy mit dem Code koppeln kann
RUHE = 12 * 3600            # danach vergisst H0rSt einen Fernseher ohne Lebenszeichen
TV_DA = 30                  # so lange gilt ein Fernseher nach seiner letzten Abfrage als erreichbar
WARTEN = 20                 # laengste Wartezeit einer Abfrage des Fernsehers
MAX_TV, MAX_HANDYS, MAX_PUFFER, MAX_JE_SENDUNG = 50, 4, 400, 100
MAX_FEHLVERSUCHE, FEHLER_FENSTER = 20, 300  # falsche Codes: hoechstens 20 in 5 Minuten (alle zusammen)
TASTEN = ("hoch", "runter", "links", "rechts", "ok", "zurueck", "home")
_KENNUNG = re.compile(r"^[A-Za-z0-9_-]{16,64}$")


class FernFehler(ValueError):
    pass


def _zahl(wert, grenze):
    """Zahl aus dem Handy, auf +-grenze begrenzt; 0 bei Unsinn."""
    try:
        z = float(wert)
    except (TypeError, ValueError):
        return 0.0
    return max(-grenze, min(grenze, z)) if z == z else 0.0  # z == z: nicht NaN


def eingabe_pruefen(roh):
    """Eine Eingabe des Handys pruefen und auf das Noetige kuerzen; None bei Unsinn."""
    if not isinstance(roh, dict):
        return None
    art = roh.get("art")
    if art == "bewegen":
        return {"art": art, "dx": round(_zahl(roh.get("dx"), 2000), 1), "dy": round(_zahl(roh.get("dy"), 2000), 1)}
    if art == "scrollen":
        return {"art": art, "dx": round(_zahl(roh.get("dx"), 5000), 1), "dy": round(_zahl(roh.get("dy"), 5000), 1)}
    if art == "taste":
        return {"art": art, "taste": roh["taste"]} if roh.get("taste") in TASTEN else None
    if art == "text":
        text = str(roh.get("text") or "")[:500]
        return {"art": art, "text": text} if text else None
    if art in ("klick", "loeschen", "eingabe"):
        return {"art": art}
    return None


def qr_svg(text, rand=2):
    """QR-Code als SVG (schwarz auf weiss, mit Ruhezone), fuer Text bis 600 Zeichen."""
    text = str(text or "")
    if not text or len(text) > 600:
        raise FernFehler("Text fuer den QR-Code: 1 bis 600 Zeichen")
    code = qrcodegen.QrCode.encode_text(text, qrcodegen.QrCode.Ecc.MEDIUM)
    groesse = code.get_size()
    wege = " ".join("M%d,%dh1v1h-1z" % (x + rand, y + rand)
                    for y in range(groesse) for x in range(groesse) if code.get_module(x, y))
    seite = groesse + 2 * rand
    # eigene Groesse (8 px je Modul): ohne sie hat das Bild keine natuerliche Breite (naturalWidth 0)
    return ('<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" viewBox="0 0 %d %d" shape-rendering="crispEdges">'
            '<rect width="100%%" height="100%%" fill="#fff"/><path d="%s" fill="#000"/></svg>'
            % (seite * 8, seite * 8, seite, seite, wege))


class Fernsteuerung:
    """Kopplungen Fernseher <-> Handys und die Eingaben dazwischen (im Speicher)."""

    def __init__(self, uhr=time.time):
        self._uhr = uhr
        self._bedingung = threading.Condition()
        self._tvs = {}       # tv -> {"code", "code_bis", "handys": {handy: {"name", "zeit"}}, "eingaben": [(nr, e)], "nr", "zeit"}
        self._handys = {}    # handy -> tv
        self._fehler = []    # Zeitpunkte falscher Codes

    def _aufraeumen(self, jetzt):
        for tv in [t for t, x in self._tvs.items() if jetzt - x["zeit"] > RUHE]:
            self._weg(tv)

    def _weg(self, tv):
        for handy in self._tvs.pop(tv, {}).get("handys", {}):
            self._handys.pop(handy, None)

    def _neuer_code(self):
        belegt = {x.get("code") for x in self._tvs.values()}  # der gerade angelegte hat noch keinen
        while True:
            code = "".join(secrets.choice(CODE_ZEICHEN) for _ in range(CODE_LAENGE))
            if code not in belegt:
                return code

    def neu(self, tv=None):
        """Fernseher anmelden (oder seinen Code erneuern): {"tv", "code", "gueltig"} (Sekunden)."""
        with self._bedingung:
            jetzt = self._uhr()
            self._aufraeumen(jetzt)
            x = self._tvs.get(tv) if tv else None
            if x is None:
                if len(self._tvs) >= MAX_TV:
                    raise FernFehler("Zu viele Fernseher gleichzeitig, bitte spaeter nochmal")
                tv = secrets.token_urlsafe(24)
                x = self._tvs[tv] = {"handys": {}, "eingaben": [], "nr": 0}
            x.update(code=self._neuer_code(), code_bis=jetzt + CODE_GUELTIG, zeit=jetzt)
            return {"tv": tv, "code": x["code"], "gueltig": CODE_GUELTIG}

    def koppeln(self, code, name=""):
        """Handy mit dem Code des Fernsehers verbinden: {"handy"}."""
        code = re.sub(r"[^A-Z0-9]", "", str(code or "").upper())
        with self._bedingung:
            jetzt = self._uhr()
            self._aufraeumen(jetzt)
            self._fehler = [t for t in self._fehler if jetzt - t < FEHLER_FENSTER]
            if len(self._fehler) >= MAX_FEHLVERSUCHE:
                raise FernFehler("Zu viele falsche Codes – bitte ein paar Minuten warten")
            tv = next((t for t, x in self._tvs.items() if x["code"] == code and x["code_bis"] > jetzt), None)
            if not tv:
                self._fehler.append(jetzt)
                raise FernFehler("Code unbekannt oder abgelaufen – am Fernseher steht ein neuer")
            x = self._tvs[tv]
            if len(x["handys"]) >= MAX_HANDYS:
                raise FernFehler("Schon %d Handys verbunden" % MAX_HANDYS)
            handy = secrets.token_urlsafe(24)
            x["handys"][handy] = {"name": " ".join(str(name or "Handy").split())[:40] or "Handy", "zeit": jetzt}
            self._handys[handy] = tv
            self._bedingung.notify_all()  # der Fernseher zeigt gleich, wer verbunden ist
            return {"handy": handy}

    def _tv_von(self, handy):
        tv = self._handys.get(handy) if isinstance(handy, str) and _KENNUNG.match(handy) else None
        if not tv or tv not in self._tvs:
            raise FernFehler("Nicht (mehr) verbunden – bitte neu koppeln")
        return tv

    def senden(self, handy, eingaben):
        """Eingaben des Handys an den Fernseher: {"tv_da"} (ob der Fernseher gerade abholt)."""
        if not isinstance(eingaben, list) or len(eingaben) > MAX_JE_SENDUNG:
            raise FernFehler("Eingaben als Liste (hoechstens %d)" % MAX_JE_SENDUNG)
        gut = [e for e in (eingabe_pruefen(x) for x in eingaben) if e]
        with self._bedingung:
            jetzt = self._uhr()
            tv = self._tv_von(handy)
            x = self._tvs[tv]
            x["handys"][handy]["zeit"] = jetzt
            for e in gut:
                x["nr"] += 1
                x["eingaben"].append((x["nr"], e))
            del x["eingaben"][:-MAX_PUFFER]
            if gut:
                self._bedingung.notify_all()
            return {"tv_da": jetzt - x["zeit"] < TV_DA}

    def abholen(self, tv, nach=0, warten=WARTEN):
        """Fernseher: Eingaben nach Nummer `nach`; wartet hoechstens `warten` s, bis etwas kommt.
        {"eingaben", "nr", "handys": [Namen], "code", "code_gueltig"}."""
        if not isinstance(tv, str) or not _KENNUNG.match(tv):
            raise FernFehler("Unbekannter Fernseher")
        try:
            nach = int(nach or 0)
        except (TypeError, ValueError):
            nach = 0
        with self._bedingung:
            if tv not in self._tvs:
                raise FernFehler("Unbekannter Fernseher – bitte neu starten")
            ende = self._uhr() + max(0.0, min(float(warten), WARTEN))
            handys_vorher = len(self._tvs[tv]["handys"])
            while True:
                x = self._tvs.get(tv)
                if x is None:
                    raise FernFehler("Getrennt")
                jetzt = self._uhr()
                x["zeit"] = jetzt
                neu = [e for nr, e in x["eingaben"] if nr > nach]
                rest = ende - jetzt
                if neu or rest <= 0 or len(x["handys"]) != handys_vorher:
                    return {"eingaben": neu, "nr": x["nr"], "handys": [h["name"] for h in x["handys"].values()],
                            "code": x["code"], "code_gueltig": max(0, int(x["code_bis"] - jetzt))}
                self._bedingung.wait(rest)

    def stand(self, handy):
        """Handy: verbunden und ob der Fernseher gerade abholt."""
        with self._bedingung:
            tv = self._tv_von(handy)
            return {"verbunden": True, "tv_da": self._uhr() - self._tvs[tv]["zeit"] < TV_DA}

    def trennen(self, tv=None, handy=None):
        with self._bedingung:
            if tv and tv in self._tvs:
                self._weg(tv)
            elif handy and handy in self._handys:
                x = self._tvs.get(self._handys.pop(handy))
                if x:
                    x["handys"].pop(handy, None)
            self._bedingung.notify_all()
            return {"getrennt": True}
