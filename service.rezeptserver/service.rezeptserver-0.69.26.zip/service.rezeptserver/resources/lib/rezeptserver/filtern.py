"""Filter und Sortierung fuer Suchergebnisse und Streams.

Ein gespeicherter Filter (Nutzerdaten, Abschnitt "filter") gilt fuer alle Anbieter
und fuer jede Ausgabe: die Oberflaeche "Durchsuchen" und die Stremio-JSON-Antworten
(Kataloge und Streams).

Felder der Treffer, die hier ausgewertet werden (alle optional):
  jahr, datum (Unix-Zeit oder "JJJJ-MM-TT..."), genre (Text oder Liste), audio,
  aufloesung, groesse/groesse_mb, poster, _anbieter (setzt die Kette).
"""

import re
import time

from . import sprachen

SORTIERUNGEN = {"relevanz": "Relevanz", "neueste": "Neueste zuerst", "aelteste": "Älteste zuerst",
                "titel": "Titel A–Z", "groesse": "Größte zuerst"}
QUALITAETEN = ("4K", "HD", "SD")
MAX_GENRES = 30
STANDARD = {"anbieter": [], "sprache": [], "genre": [], "qualitaet": [], "jahr_von": None, "jahr_bis": None,
            "sortierung": "relevanz", "ohne_angabe": False}
_LISTEN = ("anbieter", "sprache", "genre", "qualitaet")
_JAHR = re.compile(r"(?<!\d)(19\d\d|20\d\d)(?!\d)")
_EINHEITEN = {"kb": 1 << 10, "mb": 1 << 20, "gb": 1 << 30, "tb": 1 << 40}


class FilterFehler(ValueError):
    pass


def pruefe(roh):
    """Gibt einen vollstaendigen, bereinigten Filter zurueck oder wirft FilterFehler."""
    if roh is None:
        roh = {}
    if not isinstance(roh, dict):
        raise FilterFehler("filter muss ein JSON-Objekt sein")
    unbekannt = set(roh) - set(STANDARD)
    if unbekannt:
        raise FilterFehler("Unbekannte Filter: %s" % ", ".join(sorted(unbekannt)))
    f = dict(STANDARD)
    for name in _LISTEN:
        wert = roh.get(name) or []
        if isinstance(wert, str):
            wert = [wert]
        if not isinstance(wert, list) or not all(isinstance(w, str) for w in wert):
            raise FilterFehler("%s muss eine Liste von Texten sein" % name)
        f[name] = [w.strip() for w in wert if w.strip()]
    f["sprache"] = [_sprachcode(s) for s in f["sprache"]]
    for q in f["qualitaet"]:
        if q not in QUALITAETEN:
            raise FilterFehler("Unbekannte Qualitaet %r (erlaubt: %s)" % (q, ", ".join(QUALITAETEN)))
    for name in ("jahr_von", "jahr_bis"):
        wert = roh.get(name)
        if wert in (None, ""):
            continue
        try:
            f[name] = int(wert)
        except (TypeError, ValueError):
            raise FilterFehler("%s muss eine Jahreszahl sein" % name)
    sortierung = roh.get("sortierung") or "relevanz"
    if sortierung not in SORTIERUNGEN:
        raise FilterFehler("Unbekannte Sortierung %r (erlaubt: %s)" % (sortierung, ", ".join(SORTIERUNGEN)))
    f["sortierung"] = sortierung
    f["ohne_angabe"] = bool(roh.get("ohne_angabe"))
    return f


def _sprachcode(text):
    """'de', 'ger', 'German' -> 'de'."""
    code = sprachen.normalisiere(text)
    if len(code) in (2, 3):
        return code
    erkannt = sprachen.erkenne(text)
    return erkannt[0] if erkannt else text.lower()


def aktiv(f):
    """True, wenn mindestens ein Filter (nicht nur die Sortierung) gesetzt ist."""
    return any(f.get(n) for n in _LISTEN) or f.get("jahr_von") is not None or f.get("jahr_bis") is not None


# --- Merkmale eines Treffers ------------------------------------------------

def zeitpunkt(treffer):
    """Unix-Zeit fuer die Sortierung nach Datum, sonst None."""
    datum = treffer.get("datum")
    if isinstance(datum, (int, float)) and not isinstance(datum, bool):
        return float(datum)
    if isinstance(datum, str):
        text = datum.strip()
        if text.isdigit():
            return float(text)
        teile = re.match(r"(\d{4})(?:-(\d\d)(?:-(\d\d))?)?", text)
        if teile:
            jahr, monat, tag = int(teile.group(1)), int(teile.group(2) or 1), int(teile.group(3) or 1)
            try:
                return float(time.mktime((jahr, monat, tag, 12, 0, 0, 0, 0, -1)))
            except (OverflowError, ValueError):
                return None
    jahr = jahr_von(treffer)
    return float(time.mktime((jahr, 1, 1, 12, 0, 0, 0, 0, -1))) if jahr else None


def jahr_von(treffer):
    """Erscheinungsjahr: Feld jahr, sonst eine Jahreszahl im Titel, sonst das Datum (z. B. Sendetermin)."""
    gefunden = None if treffer.get("jahr") else _JAHR.search(str(treffer.get("titel", "")))
    if gefunden:
        return int(gefunden.group(1))
    for wert in (treffer.get("jahr"), treffer.get("datum")):
        if isinstance(wert, (int, float)) and not isinstance(wert, bool):
            wert = int(wert)
            if 1800 <= wert <= 2200:
                return wert
            if wert > 100000:  # Unix-Zeit
                return time.gmtime(wert).tm_year
        if isinstance(wert, str):
            gefunden = _JAHR.search(wert)
            if gefunden:
                return int(gefunden.group(1))
    return None


def genres_von(treffer):
    roh = treffer.get("genre")
    if isinstance(roh, str):
        roh = re.split(r"[;,/|]", roh)
    if not isinstance(roh, list):
        return []
    gesehen, liste = set(), []
    for g in roh:
        g = str(g).strip()
        if g and g.casefold() not in gesehen:
            gesehen.add(g.casefold())
            liste.append(g)
    return liste


def qualitaet(text):
    text = str(text or "").lower()
    if not text.strip():
        return None
    if re.search(r"2160|4k|uhd", text):
        return "4K"
    if re.search(r"1080|720|\bhd\b", text):
        return "HD"
    return "SD"


def groesse_bytes(treffer):
    mb = treffer.get("groesse_mb")
    if mb not in (None, ""):
        try:
            return float(mb) * (1 << 20)
        except (TypeError, ValueError):
            pass
    roh = treffer.get("groesse")
    if isinstance(roh, (int, float)) and not isinstance(roh, bool):
        return float(roh)
    gefunden = re.match(r"\s*([\d.,]+)\s*([kmgt]b)?", str(roh or ""), re.I)
    if not gefunden:
        return None
    try:
        zahl = float(gefunden.group(1).replace(",", "."))
    except ValueError:
        return None
    return zahl * _EINHEITEN.get((gefunden.group(2) or "").lower(), 1)


# --- Anwenden ----------------------------------------------------------------

def _passt_liste(werte, gewuenscht, ohne_angabe, mehrsprachig=False):
    if not gewuenscht:
        return True
    if not werte:
        return ohne_angabe
    if mehrsprachig and "mul" in werte:
        return True
    gewuenscht = {g.casefold() for g in gewuenscht}
    return any(str(w).casefold() in gewuenscht for w in werte)


def passt_treffer(treffer, f):
    ohne = f["ohne_angabe"]
    if f["anbieter"] and treffer.get("_anbieter") not in f["anbieter"]:
        return False
    if not _passt_liste(sprachen.audio_von(treffer), f["sprache"], ohne, mehrsprachig=True):
        return False
    if not _passt_liste(genres_von(treffer), f["genre"], ohne):
        return False
    if f["jahr_von"] is not None or f["jahr_bis"] is not None:
        jahr = jahr_von(treffer)
        if jahr is None:
            if not ohne:
                return False
        elif (f["jahr_von"] is not None and jahr < f["jahr_von"]) or \
                (f["jahr_bis"] is not None and jahr > f["jahr_bis"]):
            return False
    # Qualitaet nur, wenn der Treffer sie schon kennt; sonst entscheiden die Streams
    q = qualitaet(treffer.get("aufloesung"))
    if f["qualitaet"] and q and q not in f["qualitaet"]:
        return False
    return True


def sortiere(liste, f):
    art = f["sortierung"]
    if art == "relevanz":
        return list(liste)
    if art == "titel":
        return sorted(liste, key=lambda t: str(t.get("titel", "")).casefold())
    if art == "groesse":
        return sorted(liste, key=lambda t: -(groesse_bytes(t) or -1))
    # neueste/aelteste: Eintraege ohne Datum immer ans Ende
    rueckwaerts = art == "neueste"
    mit = [t for t in liste if zeitpunkt(t) is not None]
    ohne = [t for t in liste if zeitpunkt(t) is None]
    return sorted(mit, key=zeitpunkt, reverse=rueckwaerts) + ohne


def treffer_anwenden(liste, f):
    return sortiere([t for t in liste if passt_treffer(t, f)], f)


def streams_anwenden(paare, f):
    """Qualitaetsfilter fuer (treffer, stream)-Paare; Streams ohne Angabe nur mit ohne_angabe."""
    if not f["qualitaet"]:
        return list(paare)
    ergebnis = []
    for treffer, stream in paare:
        q = qualitaet(stream.get("aufloesung") or treffer.get("aufloesung"))
        if (q is None and f["ohne_angabe"]) or q in f["qualitaet"]:
            ergebnis.append((treffer, stream))
    return ergebnis


def facetten(liste):
    """Was in den (ungefilterten) Treffern vorkommt, mit Anzahl; fuer die Auswahl in der Oberflaeche."""
    zaehler = {"anbieter": {}, "sprache": {}, "genre": {}, "qualitaet": {}}
    jahre = []
    for t in liste:
        werte = {"anbieter": [t.get("_anbieter")] if t.get("_anbieter") else [],
                 "sprache": sprachen.audio_von(t), "genre": genres_von(t),
                 "qualitaet": [qualitaet(t.get("aufloesung"))] if t.get("aufloesung") else []}
        for name, liste_werte in werte.items():
            for w in liste_werte:
                # gleiche Werte in anderer Schreibweise zusammenzaehlen, erste Schreibweise gewinnt
                schreibweise = next((k for k in zaehler[name] if str(k).casefold() == str(w).casefold()), w)
                zaehler[name][schreibweise] = zaehler[name].get(schreibweise, 0) + 1
        jahr = jahr_von(t)
        if jahr:
            jahre.append(jahr)
    zaehler["jahre"] = [min(jahre), max(jahre)] if jahre else []
    # freie Schlagwoerter (z. B. archive.org) koennen hunderte sein: nur die haeufigsten zeigen
    haeufigste = sorted(zaehler["genre"].items(), key=lambda p: -p[1])[:MAX_GENRES]
    zaehler["genre"] = dict(haeufigste)
    return zaehler
