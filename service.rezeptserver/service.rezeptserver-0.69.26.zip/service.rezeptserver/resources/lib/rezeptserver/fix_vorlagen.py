"""Fix-Vorlagen: eingebaute und eigene Prompt-Vorlagen fuer KI-Vorschlaege. Nach dem Muster der Anbieter-
Vorlagen (vorlagen_bauen.py, eingebaut, fest im Code) und der eigenen Anbieter (anbieter.py, Nutzerdaten
mit eigener Pruefung/CRUD): eingebaute Vorlagen sind nicht editierbar, eigene sind es.

Parameter einer Vorlage ("werte") folgen derselben Feld-Form wie anbieter.FELDER
({key, label, typ: text|passwort|zahl|schalter, optional, mehrzeilig}) und rendern deshalb ueber das
schon vorhandene generische feldEingabe()/felderZeigen()/felderLesen() in seite_js/ - keine neue
Oberflaechen-Logik je Vorlage.

Nutzerdaten "fix_vorlagen_eigene": {id: {"name", "kategorie", "prompt", "werte": [...], "hinweis",
"mcp_erlaubt"}}

"mcp_erlaubt" (bool, Vorgabe False): darf diese Vorlage beim Erzeugen eines Vorschlags Werkzeuge des
eingetragenen MCP-Servers aufrufen (Phase 2 Schritt 2, siehe vorschlaege.ki_vorschlagen()). Werkzeug-
Aufrufe laufen ohne eigene Freigabe-Schranke - nur das Dateien-Ergebnis geht durch die Warteschlange.
"""

import re

KATEGORIEN = {"qualitaet": "Code-Qualität", "sicherheit": "Sicherheit", "sonstige": "Sonstige"}
_FELD_TYPEN = {"text", "passwort", "zahl", "schalter"}
_ID = re.compile(r"^[a-z0-9][a-z0-9-]{0,39}$")
_FELD_KEY = re.compile(r"^[a-z][a-z0-9_]{0,30}$")


class VorlageFehler(ValueError):
    pass


def _v(vid, name, kategorie, prompt, werte=None, hinweis="", mcp_erlaubt=False):
    return {"id": vid, "name": name, "kategorie": kategorie, "prompt": prompt, "werte": werte or [],
            "hinweis": hinweis, "mcp_erlaubt": mcp_erlaubt}


# Bewusst nur zwei echte Vorlagen zum Start - mehr folgt in eigenen, spaeteren Commits, wenn ein echter
# Anwendungsfall dafuer da ist (kein spekulativer Katalog).
VORLAGEN = [
    _v("ruff-fix", "Ruff-Warnung beheben", "qualitaet",
       "Behebe in {datei} genau diese ruff-Warnung minimal, ohne das Verhalten sonst zu aendern:\n\n"
       "{warnung}\n\nGib nur JSON zurueck: "
       '{{"dateien": {{"<pfad>": "<vollstaendiger neuer Dateiinhalt>"}}, "begruendung": "..."}}',
       werte=[{"key": "datei", "label": "Datei (Pfad im Repo)", "typ": "text"},
              {"key": "warnung", "label": "Ruff-Warnung (Text)", "typ": "text", "mehrzeilig": True}],
       hinweis="Für eine einzelne, schon bekannte ruff-Meldung."),
    _v("sicherheit-muster", "Bekanntes Sicherheitsmuster entschärfen", "sicherheit",
       "In H0rSt wurde folgendes Sicherheitsmuster gemeldet: {muster}\n\nPrüfe {datei} darauf und behebe es "
       "minimal. Gib nur JSON zurueck: "
       '{{"dateien": {{"<pfad>": "<vollstaendiger neuer Dateiinhalt>"}}, "begruendung": "..."}}',
       werte=[{"key": "datei", "label": "Datei (Pfad im Repo)", "typ": "text"},
              {"key": "muster", "label": "Sicherheitsmuster/Fund", "typ": "text", "mehrzeilig": True}],
       hinweis="Für einen konkret benannten Fund (z. B. aus einem Review)."),
]
NACH_ID = {v["id"]: v for v in VORLAGEN}


def pruefe_eigene(eigene):
    """Prueft den Abschnitt "fix_vorlagen_eigene" der Nutzerdaten, wirft VorlageFehler."""
    if not isinstance(eigene, dict):
        raise VorlageFehler("fix_vorlagen_eigene muss die Form {id: {...}} haben")
    for vid, eintrag in eigene.items():
        if not _ID.match(vid):
            raise VorlageFehler("Vorlagen-ID nur a-z, 0-9 und Bindestrich: %r" % vid)
        if not isinstance(eintrag, dict) or not str(eintrag.get("name", "")).strip():
            raise VorlageFehler("Vorlage %s braucht einen Namen" % vid)
        if eintrag.get("kategorie") not in KATEGORIEN:
            raise VorlageFehler("Vorlage %s: unbekannte Kategorie %r (erlaubt: %s)"
                                 % (vid, eintrag.get("kategorie"), ", ".join(KATEGORIEN)))
        if not str(eintrag.get("prompt", "")).strip():
            raise VorlageFehler("Vorlage %s braucht einen Prompt" % vid)
        werte = eintrag.get("werte", [])
        if not isinstance(werte, list) or not all(
                isinstance(w, dict) and _FELD_KEY.match(str(w.get("key", ""))) and w.get("typ") in _FELD_TYPEN
                for w in werte):
            raise VorlageFehler("Vorlage %s: werte müssen eine Liste von Feldern {key, label, typ} sein" % vid)
        if "mcp_erlaubt" in eintrag and not isinstance(eintrag["mcp_erlaubt"], bool):
            raise VorlageFehler("Vorlage %s: mcp_erlaubt muss ein bool sein" % vid)
        unbekannt = set(eintrag) - {"name", "kategorie", "prompt", "werte", "hinweis", "mcp_erlaubt"}
        if unbekannt:
            raise VorlageFehler("Vorlage %s: unbekannte Angaben %s" % (vid, ", ".join(sorted(unbekannt))))


def hinzufuegen(daten, name, kategorie, prompt, werte=None, hinweis="", vid=None, mcp_erlaubt=False):
    """Legt eine eigene Vorlage in daten an (daten danach speichern). Gibt die id zurueck."""
    eigene = daten.setdefault("fix_vorlagen_eigene", {})
    vid = vid or re.sub(r"[^a-z0-9]+", "-", str(name).lower()).strip("-")[:40] or "eigen"
    if vid in NACH_ID or vid in eigene:
        raise VorlageFehler("Vorlage %s gibt es schon" % vid)
    eintrag = {"name": str(name).strip(), "kategorie": kategorie, "prompt": prompt, "werte": werte or [],
               "hinweis": hinweis, "mcp_erlaubt": bool(mcp_erlaubt)}
    pruefe_eigene({vid: eintrag})
    eigene[vid] = eintrag
    return vid


def entfernen(daten, vid):
    """Entfernt eine eigene Vorlage. Eingebaute lassen sich nicht entfernen."""
    eigene = daten.get("fix_vorlagen_eigene") or {}
    if vid not in eigene:
        raise VorlageFehler("Eigene Vorlage %s nicht gefunden" % vid)
    del eigene[vid]


def alle(daten):
    """Eingebaute + eigene Vorlagen zusammen, fuer die Oberflaeche."""
    eigene = daten.get("fix_vorlagen_eigene") or {}
    return VORLAGEN + [dict(v, id=vid, eigen=True) for vid, v in eigene.items()]


def finde(daten, vid):
    if vid in NACH_ID:
        return NACH_ID[vid]
    eigene = daten.get("fix_vorlagen_eigene") or {}
    if vid in eigene:
        return dict(eigene[vid], id=vid, eigen=True)
    raise VorlageFehler("Vorlage %s nicht gefunden" % vid)
