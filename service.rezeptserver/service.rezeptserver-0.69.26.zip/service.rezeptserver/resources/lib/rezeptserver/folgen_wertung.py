"""IMDb-Bewertung einzelner Folgen, nur wenn eine Quelle sie wirklich liefert.

ARVIO zeigt seit 2.2 Folgen-IMDb-Werte (web/lib/tmdb.ts getSeasonEpisodeRatings,
web/lib/imdbRatings.ts). Cinemeta hat pro Folge oft eine andere Zahl im Feld rating
(bei Breaking Bad S01E01 z. B. 7.7, IMDb ist 9.1) und keine Folgen-IMDb-Nummer.
Die Nummer kommt bei Trakt in einem Aufruf je Staffel (ids.imdb), sonst — nur mit
eigenem TMDb-Schluessel — von der Folgen-Schnittstelle. Die Zahl selbst kommt von
Agregarr (https://api.agregarr.org/api/ratings), derselben keylosen Quelle wie ARVIO.
Ohne Treffer bleibt das Feld leer; TMDb-vote_average wird nicht als IMDb ausgegeben.
"""

import json
import logging
import re
import threading
import time
from urllib.parse import urlencode

from . import trakt
from .netz import NetzFehler

log = logging.getLogger("rezeptserver")

AGREGARR = "https://api.agregarr.org/api/ratings"
MERKEN = 7 * 86400
MAX_FOLGEN = 40
MAX_TMDB = 12  # je Staffel; ARVIO fragt jede Folge einzeln, hier gedeckelt
_IMDB = re.compile(r"^tt\d{1,10}$")
_sperre = threading.Lock()
_ids = {}          # imdb-folge -> (zeit, "9.1" oder "")
_staffeln = {}     # (herkunft, kennung, staffel) -> (zeit, {nummer: imdb})


def _zahl(wert):
    try:
        zahl = float(wert)
    except (TypeError, ValueError):
        return ""
    if not 0 < zahl <= 10:
        return ""
    return "%.1f" % zahl


def _merken_staffel(schluessel, zuordnung, uhr):
    with _sperre:
        if len(_staffeln) > 200:
            _staffeln.clear()
        _staffeln[schluessel] = (uhr, zuordnung)


def _staffel_aus_speicher(schluessel, uhr):
    with _sperre:
        alt = _staffeln.get(schluessel)
    if alt and uhr - alt[0] < MERKEN:
        return alt[1]
    return None


def _agregarr(holen, kennungen, uhr):
    """{imdb: "9.1"} fuer die noch nicht gespeicherten Kennungen. Fehlschlag speichert nichts."""
    jetzt = {}
    fehlen = []
    with _sperre:
        for kid in kennungen:
            alt = _ids.get(kid)
            if alt and uhr - alt[0] < MERKEN:
                if alt[1]:
                    jetzt[kid] = alt[1]
            else:
                fehlen.append(kid)
    if not fehlen:
        return jetzt
    url = AGREGARR + "?" + urlencode([("id", kid) for kid in fehlen])
    try:
        status, text = holen(url, "GET", {"Accept": "application/json"}, None, 12)
    except TypeError:
        status, text = holen(url, "GET", {"Accept": "application/json"}, None)
    except NetzFehler as fehler:
        log.info("Folgen-IMDb nicht geladen: %s", fehler)
        return jetzt
    if status >= 400:
        return jetzt
    try:
        zeilen = json.loads(text) if text else []
    except ValueError:
        return jetzt
    if not isinstance(zeilen, list):
        return jetzt
    gesehen = set()
    with _sperre:
        if len(_ids) > 4000:
            _ids.clear()
        for zeile in zeilen:
            if not isinstance(zeile, dict):
                continue
            kid = str(zeile.get("imdbId") or "").strip().lower()
            if not _IMDB.match(kid):
                continue
            gesehen.add(kid)
            wert = _zahl(zeile.get("rating"))
            _ids[kid] = (uhr, wert)
            if wert:
                jetzt[kid] = wert
        for kid in fehlen:
            if kid not in gesehen:
                _ids[kid] = (uhr, "")
    return jetzt


def _trakt_staffel(holen, client_id, imdb, staffel, uhr):
    schluessel = ("trakt", imdb, staffel)
    alt = _staffel_aus_speicher(schluessel, uhr)
    if alt is not None:
        return alt
    kopf = {"Accept": "application/json", "trakt-api-version": "2", "trakt-api-key": client_id}
    try:
        try:
            status, text = holen(trakt.API + "/shows/%s/seasons/%s" % (imdb, staffel), "GET", kopf, None, 12)
        except TypeError:
            status, text = holen(trakt.API + "/shows/%s/seasons/%s" % (imdb, staffel), "GET", kopf, None)
    except NetzFehler as fehler:
        log.info("Trakt-Staffel nicht geladen: %s", fehler)
        return {}
    if status >= 400:
        return {}
    try:
        zeilen = json.loads(text) if text else []
    except ValueError:
        return {}
    zuordnung = {}
    if isinstance(zeilen, list):
        for folge in zeilen:
            if not isinstance(folge, dict):
                continue
            nummer = folge.get("number")
            kid = str(((folge.get("ids") or {}).get("imdb")) or "").strip().lower()
            if isinstance(nummer, int) and nummer > 0 and _IMDB.match(kid):
                zuordnung[nummer] = kid
    _merken_staffel(schluessel, zuordnung, uhr)
    return zuordnung


def _tmdb_staffel(tmdb, api_key, tmdb_id, staffel, nummern, uhr):
    schluessel = ("tmdb", str(tmdb_id), staffel)
    alt = _staffel_aus_speicher(schluessel, uhr)
    if alt is not None:
        return {n: alt[n] for n in nummern if n in alt} if nummern else alt
    from .tmdb import TmdbFehler
    ziel = [n for n in nummern if isinstance(n, int) and n > 0][:MAX_TMDB]

    def eine(nummer):
        try:
            daten = tmdb._holen("/tv/%s/season/%s/episode/%s" % (tmdb_id, staffel, nummer), api_key,
                                append_to_response="external_ids")
        except (TmdbFehler, NetzFehler, TypeError, ValueError):
            return nummer, ""
        kid = str(((daten or {}).get("external_ids") or {}).get("imdb_id") or "").strip().lower()
        return nummer, kid if _IMDB.match(kid) else ""

    pool = getattr(tmdb, "_pool", None)
    paare = list(pool.map(eine, ziel)) if pool is not None else [eine(n) for n in ziel]
    zuordnung = {nummer: kid for nummer, kid in paare if kid}
    if zuordnung:
        _merken_staffel(schluessel, zuordnung, uhr)
    return zuordnung


def _nummern(text):
    roh = []
    for teil in str(text or "").split(","):
        teil = teil.strip()
        if teil.isdigit():
            zahl = int(teil)
            if 0 < zahl < 10000 and zahl not in roh:
                roh.append(zahl)
        if len(roh) >= MAX_FOLGEN:
            break
    return roh


def folgen_imdb(holen, imdb, staffel, folgen="", trakt_client_id="", tmdb=None, tmdb_key="", tmdb_id="", uhr=None):
    """{Folgennummer als Text: "9.1"}. Leer ohne Zugangsdaten oder ohne Treffer, wirft nicht."""
    uhr = time.time if uhr is None else uhr
    jetzt = uhr()
    imdb = str(imdb or "").strip().lower()
    try:
        staffel = int(staffel)
    except (TypeError, ValueError):
        return {}
    if staffel < 0 or staffel > 200 or not _IMDB.match(imdb):
        return {}
    nummern = _nummern(folgen)
    zuordnung = {}
    if trakt_client_id:
        zuordnung = _trakt_staffel(holen, trakt_client_id, imdb, staffel, jetzt)
        if nummern:
            zuordnung = {n: zuordnung[n] for n in nummern if n in zuordnung}
    elif tmdb is not None and tmdb_key and str(tmdb_id).isdigit() and nummern:
        zuordnung = _tmdb_staffel(tmdb, tmdb_key, str(int(tmdb_id)), staffel, nummern, jetzt)
    else:
        return {}
    if not zuordnung:
        return {}
    bewertet = _agregarr(holen, sorted(set(zuordnung.values())), jetzt)
    return {str(nummer): bewertet[kid] for nummer, kid in sorted(zuordnung.items()) if bewertet.get(kid)}


def fuer_anfrage(holen, werte, trakt_client_id="", tmdb=None, tmdb_key=""):
    werte = werte or {}
    return {"bewertungen": folgen_imdb(
        holen, werte.get("imdb", ""), werte.get("staffel", ""), werte.get("folgen", ""),
        trakt_client_id=trakt_client_id, tmdb=tmdb, tmdb_key=tmdb_key, tmdb_id=werte.get("tmdb", ""))}


def fuer_app(app, werte):
    daten = app.verwaltung.daten() if getattr(app, "verwaltung", None) else {}
    t = daten.get("trakt") if isinstance(daten.get("trakt"), dict) else {}
    client_id = str((t.get("app") or {}).get("client_id") or "")
    from . import tmdb as tmdb_modul
    schluessel = tmdb_modul.schluessel(daten)
    holen = app.trakt.holen if getattr(app, "trakt", None) is not None else None
    if holen is None:
        from .netz import antwort_holen
        holen = antwort_holen
    return fuer_anfrage(holen, werte, trakt_client_id=client_id, tmdb=getattr(app, "tmdb", None), tmdb_key=schluessel)


def speicher_leeren():
    with _sperre:
        _ids.clear()
        _staffeln.clear()
