"""Kostenlose Sender (FAST): Samsung TV Plus und Pluto TV, legal und ohne Anmeldung.

Senderdaten, Logos, Gruppen und Programm (XMLTV) kommen aus Matt Huismans oeffentlichem i.mjh.nz (dieselbe
Quelle wie die SlyGuy-Addons fuer Kodi). Sender mit Kopierschutz (license_url) laesst H0rSt weg.

Abspielen:
  * Samsung TV Plus: https://jmp2.uk/stvp-<id> (leitet auf den HLS-Stream weiter).
  * Pluto TV: die oeffentliche Stitcher-Adresse der Pluto-Web-App (ohne Konto, Geraete-ID zufaellig).
Beide Adressen sind fest und laufen damit in jeder IPTV-App, auch ueber Xtream.
Die Sender bringen ihre Werbung im Stream selbst mit (sie finanzieren sich so); H0rSt fuegt keine hinzu.

Nutzerdaten livetv.frei: ["samsung-de", "pluto-de", ...]
"""

import gzip
import json
import logging
import urllib.request
import uuid

from .netz import USER_AGENT

log = logging.getLogger("rezeptserver")

QUELLEN = {
    "samsung": {"name": "Samsung TV Plus", "daten": "https://i.mjh.nz/SamsungTVPlus/.channels.json.gz",
                "epg": "https://i.mjh.nz/SamsungTVPlus/%s.xml.gz", "regionen": ("de", "at", "ch")},
    "pluto": {"name": "Pluto TV", "daten": "https://i.mjh.nz/PlutoTV/.channels.json.gz",
              "epg": "https://i.mjh.nz/PlutoTV/%s.xml.gz", "regionen": ("de",)},
}
REGIONEN = {"de": "Deutschland", "at": "Österreich", "ch": "Schweiz"}
MAX_DATEN = 8 * 1024 * 1024


class FreiFehler(ValueError):
    pass


def auswahl():
    """Alle waehlbaren Listen: [{"id": "samsung-de", "name": "Samsung TV Plus · Deutschland"}]."""
    return [{"id": "%s-%s" % (q, r), "name": "%s · %s" % (v["name"], REGIONEN[r])}
            for q, v in QUELLEN.items() for r in v["regionen"]]


def pruefe(roh):
    roh = roh or []
    if not isinstance(roh, list):
        raise FreiFehler("livetv.frei muss eine Liste sein")
    erlaubt = [a["id"] for a in auswahl()]
    falsch = [x for x in roh if x not in erlaubt]
    if falsch:
        raise FreiFehler("Unbekannte kostenlose Liste: %s" % ", ".join(map(str, falsch)))
    return [x for x in erlaubt if x in roh]


def _zerlegen(liste_id):
    quelle, _, region = liste_id.partition("-")
    if quelle not in QUELLEN or region not in QUELLEN[quelle]["regionen"]:
        raise FreiFehler("Unbekannte Liste: %s" % liste_id)
    return quelle, region


def epg_quellen(gewaehlt):
    return [QUELLEN[q]["epg"] % r for q, r in (_zerlegen(x) for x in gewaehlt)]


def _holen_standard(url):
    anfrage = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(anfrage, timeout=30) as antwort:
        return antwort.read(MAX_DATEN + 1)


PLUTO = ("https://service-stitcher.clusters.pluto.tv/v1/stitch/embed/hls/channel/%s/master.m3u8?deviceId=%s"
         "&deviceModel=web&deviceType=web&deviceMake=chrome&sid=%s&appName=web&appVersion=9.9.0"
         "&serverSideAds=true&deviceDNT=0&deviceVersion=126")


def sender(liste_id, holen=None):
    """Eintraege einer Liste fuer M3U/Xtream: [{"name", "url", "attribute", "optionen"}]."""
    quelle, region = _zerlegen(liste_id)
    try:
        roh = (holen or _holen_standard)(QUELLEN[quelle]["daten"])
        if len(roh) > MAX_DATEN:
            raise FreiFehler("Senderdaten zu groß")
        if roh[:2] == b"\x1f\x8b":
            roh = gzip.decompress(roh)
        daten = json.loads(roh.decode("utf-8"))
    except FreiFehler:
        raise
    except Exception as fehler:
        raise FreiFehler("%s: Senderdaten nicht ladbar: %s" % (QUELLEN[quelle]["name"], fehler))
    kanaele = ((daten.get("regions") or {}).get(region) or {}).get("channels") or {}
    geraet, sitzung = str(uuid.uuid4()), str(uuid.uuid4())
    ua = (daten.get("headers") or {}).get("user-agent")
    eintraege = []
    for kid, k in sorted(kanaele.items(), key=lambda e: (e[1].get("chno") or 0, str(e[1].get("name", "")))):
        if k.get("license_url"):
            continue  # Kopierschutz (DRM): in normalen Playern nicht abspielbar
        if quelle == "samsung":
            url = "https://jmp2.uk/" + str(daten.get("slug") or "stvp-{id}").replace("{id}", kid)
        else:
            url = PLUTO % (kid, geraet, sitzung)
        eintraege.append({"name": str(k.get("name") or kid), "url": url,
                          "optionen": ["#EXTVLCOPT:http-user-agent=%s" % ua] if ua and quelle == "samsung" else [],
                          "attribute": {"tvg-id": kid, "tvg-name": str(k.get("name") or kid),
                                        "tvg-logo": str(k.get("logo") or ""), "tvg-chno": str(k.get("chno") or ""),
                                        "group-title": "%s · %s" % (QUELLEN[quelle]["name"], k.get("group") or "Sonstige")}})
    if not eintraege:
        raise FreiFehler("%s: keine Sender für %s" % (QUELLEN[quelle]["name"], REGIONEN[region]))
    return eintraege
