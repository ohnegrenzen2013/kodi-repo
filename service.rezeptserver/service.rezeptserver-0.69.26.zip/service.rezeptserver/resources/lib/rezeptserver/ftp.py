"""FTP: Client und kleiner Server.

Client: FTP- und FTPS-Speicher im Bereich Heim (wie WebDAV): Ordner listen (MLSD, sonst LIST), Dateien ueber
H0rSt abspielen, mit Range zum Springen (REST). Auch Treffer aus der FTP-Suche (Napalm FTP Indexer) laufen
darueber. Benutzer und Passwort bleiben auf dem Server.

Server: gibt die Download-Ordner von H0rSt (XDCC, YouTube) und auf Wunsch einen eigenen Ordner per FTP frei,
damit Kodi, VLC, ein Fernseher oder ein Dateimanager sie im Heimnetz holen kann. Nur mit Benutzer und
Passwort, standardmaessig nur lesen; Hochladen nur in den eigenen Ordner, wenn eingeschaltet. Passiver Modus.
Nutzerdaten "ftp_server": {"an", "port", "benutzer", "passwort", "ordner", "schreiben"}
Im Container (Docker): H0RST_FTP_PASSIV="30000-30009" legt die Passiv-Ports fest (im Compose gleich weitergereicht),
H0RST_FTP_ADRESSE die IP des Hosts, die den Clients fuer den Passiv-Modus genannt wird.
"""

from .ftp_grund import *
from .ftp_grund import _LIST
from .ftp_client import auflisten, datei_url, senden, teile, verbinden, _list_zeile
from .ftp_server import FtpServer, passiv_bereich, passiv_lauscher, server_pruefe, _Server, _Sitzung
