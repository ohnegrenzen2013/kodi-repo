"""FTP-Client: verbinden, Ordner auflisten, Dateien abspielen (mit Range/REST)."""

from .ftp_grund import (
    FtpFehler,
    _LIST,
    ftplib,
    log,
    posixpath,
    quote,
    re,
    ssl,
    time,
    unquote,
    urlsplit,
)

def teile(url):
    """ftp[s]://benutzer:passwort@host:port/pfad -> dict."""
    t = urlsplit(str(url or "").strip())
    if t.scheme not in ("ftp", "ftps") or not t.hostname:
        raise FtpFehler("Adresse muss mit ftp:// oder ftps:// beginnen")
    try:
        port = t.port or 21  # t.port wirft ValueError bei einem Port ausserhalb 0-65535
    except ValueError:
        raise FtpFehler("Ungültiger Port in der Adresse")
    return {"tls": t.scheme == "ftps", "host": t.hostname, "port": port,
            "benutzer": unquote(t.username or ""), "passwort": unquote(t.password or ""),
            "pfad": unquote(t.path or "/") or "/"}


def verbinden(url, benutzer="", passwort="", eigenes=False, zeit=20):
    z = teile(url)
    benutzer = benutzer or z["benutzer"] or "anonymous"
    passwort = passwort or z["passwort"] or ("h0rst@" if benutzer == "anonymous" else "")
    try:
        if z["tls"]:
            kontext = ssl.create_default_context()
            if eigenes:
                kontext.check_hostname, kontext.verify_mode = False, ssl.CERT_NONE
            f = ftplib.FTP_TLS(context=kontext, timeout=zeit)
        else:
            f = ftplib.FTP(timeout=zeit)
        f.encoding = "utf-8"
        try:
            f.connect(z["host"], z["port"])
            f.login(benutzer, passwort)
            if z["tls"]:
                f.prot_p()
            f.set_pasv(True)
        except BaseException:
            f.close()
            raise
    except ftplib.error_perm as fehler:
        raise FtpFehler("Anmeldung abgelehnt: %s" % str(fehler)[:200])
    except (ftplib.Error, OSError, EOFError) as fehler:
        raise FtpFehler("FTP nicht erreichbar: %s" % str(fehler)[:200])
    return f, z["pfad"]


def _list_zeile(zeile):
    m = _LIST.match(zeile)
    if not m:
        return None
    name = m.group(4)
    if m.group(1) == "l":
        name = name.split(" -> ", 1)[0]
    return name, m.group(1) == "d", int(m.group(2))


def auflisten(speicher, pfad="/"):
    from .heimspeicher import art_von, pfad_sauber
    pfad = pfad_sauber(pfad)
    f, basis = verbinden(speicher["url"], speicher.get("benutzer", ""), speicher.get("passwort", ""),
                         speicher.get("zertifikat") == "eigenes")
    ziel = posixpath.join(basis, pfad.lstrip("/")) or "/"
    eintraege = []
    try:
        try:
            for name, fakten in f.mlsd(ziel, facts=["type", "size", "modify"]):
                if name in (".", "..") or fakten.get("type") in ("cdir", "pdir"):
                    continue
                ordner = fakten.get("type") == "dir"
                zeit = 0
                if fakten.get("modify"):
                    try:
                        zeit = int(time.mktime(time.strptime(fakten["modify"][:14], "%Y%m%d%H%M%S")))
                    except ValueError:
                        pass
                eintraege.append((name, ordner, int(fakten.get("size") or 0), zeit))
        except ftplib.error_perm:
            zeilen = []
            f.retrlines("LIST " + ziel, zeilen.append)
            for z in zeilen:
                teil = _list_zeile(z)
                if teil and teil[0] not in (".", ".."):
                    eintraege.append(teil + (0,))
    except (ftplib.Error, OSError, EOFError) as fehler:
        raise FtpFehler("Ordner nicht lesbar: %s" % str(fehler)[:200])
    finally:
        try:
            f.quit()
        except Exception:
            f.close()
    ergebnis = [{"name": n, "pfad": pfad_sauber(posixpath.join(pfad, n)), "ordner": o, "groesse": g, "zeit": z,
                 "typ": "", "art": "ordner" if o else art_von(n)} for n, o, g, z in eintraege]
    ergebnis.sort(key=lambda e: (not e["ordner"], e["name"].lower()))
    return ergebnis


def datei_url(speicher, pfad):
    """Interne Adresse einer Datei (mit Zugangsdaten, bleibt auf dem Server)."""
    from .heimspeicher import pfad_sauber
    z = teile(speicher["url"])
    anmeldung = ""
    if speicher.get("benutzer"):
        anmeldung = "%s:%s@" % (quote(speicher["benutzer"], safe=""), quote(speicher.get("passwort", ""), safe=""))
    voll = posixpath.join(z["pfad"], pfad_sauber(pfad).lstrip("/"))
    return "%s://%s%s:%d%s" % ("ftps" if z["tls"] else "ftp", anmeldung, z["host"], z["port"], quote(voll))


def senden(handler, url, eigenes=False):
    """Datei per HTTP ausliefern, Range ueber REST."""
    import mimetypes
    try:
        f, pfad = verbinden(url, eigenes=eigenes)
    except FtpFehler as fehler:
        log.warning("FTP: %s", fehler)
        handler.send_error(502)
        return
    geantwortet = False
    try:
        f.voidcmd("TYPE I")
        try:
            groesse = f.size(pfad)
        except ftplib.Error:
            groesse = None
        anfang, ende = 0, (groesse - 1) if groesse else None
        bereich = re.match(r"bytes=(\d+)-(\d*)$", handler.headers.get("Range") or "")
        if bereich and groesse:
            anfang = int(bereich.group(1))
            if bereich.group(2):
                ende = min(int(bereich.group(2)), groesse - 1)
            if anfang > ende:
                handler.send_response(416)
                handler.send_header("Content-Range", "bytes */%d" % groesse)
                handler.end_headers()
                return
        geantwortet = True  # ab hier keinen send_error() mehr - die Antwort hat schon begonnen
        handler.send_response(206 if bereich and groesse else 200)
        typ = mimetypes.guess_type(pfad)[0] or ("video/x-matroska" if pfad.lower().endswith(".mkv") else "application/octet-stream")
        handler.send_header("Content-Type", typ)
        if groesse:
            handler.send_header("Accept-Ranges", "bytes")
            handler.send_header("Content-Length", str(ende - anfang + 1))
            if bereich:
                handler.send_header("Content-Range", "bytes %d-%d/%d" % (anfang, ende, groesse))
        handler.send_header("Cache-Control", "no-store")
        handler.end_headers()
        if handler.command == "HEAD":
            return
        rest = (ende - anfang + 1) if groesse else None
        verbindung = f.transfercmd("RETR " + pfad, rest=anfang or None)
        try:
            while rest is None or rest > 0:
                block = verbindung.recv(min(rest or 262144, 262144))
                if not block:
                    break
                handler.wfile.write(block)
                if rest is not None:
                    rest -= len(block)
        except (BrokenPipeError, ConnectionResetError):
            pass
        finally:
            verbindung.close()
    except (ftplib.Error, OSError, EOFError) as fehler:
        log.warning("FTP-Wiedergabe: %s", fehler)
        if not geantwortet:
            try:
                handler.send_error(502)
            except OSError:
                pass  # Verbindung schon weg
    finally:
        f.close()


