"""Grundlage von FTP: Importe, Logger, Fehler und die Serverkonstanten.
Alles hier wird samt Importen wieder exportiert (rezeptserver.ftp.*)."""


import ftplib
import logging
import os
import posixpath
import re
import secrets
import shutil
import socket
import socketserver
import ssl
import threading
import time
from urllib.parse import quote, unquote, urlsplit

log = logging.getLogger("rezeptserver")


class FtpFehler(ValueError):
    pass


_LIST = re.compile(r"^([\-dl])\S{9}\s+\d+\s+\S+\s+\S+\s+(\d+)\s+(\w{3}\s+\d{1,2}\s+[\d:]{4,5})\s+(.+)$")


# --- Server -----------------------------------------------------------------------------------
SERVER_SCHLUESSEL = "ftp_server"
SERVER_STANDARD = {"an": False, "port": 2121, "benutzer": "h0rst", "passwort": "", "ordner": "", "schreiben": False}
