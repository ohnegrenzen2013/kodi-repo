"""FTP-Server: Freigaben, Sitzung, Passiv-Ports und die Serververwaltung."""

from .ftp_grund import (
    FtpFehler,
    SERVER_STANDARD,
    log,
    os,
    posixpath,
    re,
    secrets,
    shutil,
    socket,
    socketserver,
    threading,
    time,
)

def server_pruefe(roh):
    e = dict(SERVER_STANDARD)
    if isinstance(roh, dict):
        e.update({k: roh[k] for k in SERVER_STANDARD if k in roh})
    e["an"], e["schreiben"] = e["an"] is True, e["schreiben"] is True
    try:
        e["port"] = int(e["port"])
    except (TypeError, ValueError):
        raise FtpFehler("Port muss eine Zahl sein")
    if not 1024 <= e["port"] <= 65535:
        raise FtpFehler("Port zwischen 1024 und 65535")
    e["benutzer"] = re.sub(r"[^\w.\-]", "", str(e["benutzer"] or ""))[:40] or "h0rst"
    e["passwort"] = str(e["passwort"] or "")[:200]
    e["ordner"] = str(e["ordner"] or "").strip()[:500]
    if e["an"] and len(e["passwort"]) < 6:
        raise FtpFehler("Für den FTP-Server ein Passwort mit mindestens 6 Zeichen setzen")
    if e["ordner"] and not os.path.isdir(e["ordner"]):
        raise FtpFehler("Ordner gibt es nicht: %s" % e["ordner"])
    return e


def passiv_bereich():
    """(von, bis) aus H0RST_FTP_PASSIV ("30000-30009") oder None (beliebiger freier Port)."""
    m = re.match(r"^\s*(\d{4,5})\s*-\s*(\d{4,5})\s*$", os.environ.get("H0RST_FTP_PASSIV", ""))
    if not m or not 1024 <= int(m.group(1)) <= int(m.group(2)) <= 65535:
        return None
    return int(m.group(1)), int(m.group(2))


def passiv_lauscher(ip):
    bereich = passiv_bereich()
    ports = list(range(bereich[0], bereich[1] + 1)) if bereich else [0]
    for port in ports:
        lauscher = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        try:
            lauscher.bind((ip if not bereich else "0.0.0.0", port))
            lauscher.listen(1)
            return lauscher
        except OSError:
            lauscher.close()
    raise FtpFehler("Kein Passiv-Port frei (H0RST_FTP_PASSIV)")


class _Sitzung(socketserver.StreamRequestHandler):
    """Eine FTP-Sitzung: virtuelles Dateisystem aus den freigegebenen Ordnern (/xdcc, /youtube, /eigener)."""

    timeout = 600

    def antworten(self, text):
        self.wfile.write((text + "\r\n").encode("utf-8"))

    def setup(self):
        super().setup()
        self.angemeldet, self.benutzer, self.cwd, self.pasv, self.rest = False, "", "/", None, 0
        self.fehlversuche = 0

    # virtuelle Pfade
    def _echt(self, pfad):
        wurzeln = self.server.wurzeln()
        voll = posixpath.normpath(posixpath.join(self.cwd, pfad or ""))
        if voll in ("/", "."):
            return None, "/"
        teile_ = voll.strip("/").split("/", 1)
        if teile_[0] not in wurzeln:
            raise FtpFehler("Gibt es nicht")
        wurzel = os.path.realpath(wurzeln[teile_[0]])
        echt = os.path.realpath(os.path.join(wurzel, *(teile_[1].split("/") if len(teile_) > 1 else [])))
        if echt != wurzel and not echt.startswith(wurzel + os.sep):
            raise FtpFehler("Außerhalb der Freigabe")
        return (teile_[0], echt), voll

    def _daten(self):
        if self.pasv is None:
            raise FtpFehler("Erst PASV oder EPSV")
        lauscher, self.pasv = self.pasv, None
        lauscher.settimeout(30)
        try:
            verbindung, _ = lauscher.accept()
        finally:
            lauscher.close()
        return verbindung

    def _liste(self, pfad, nur_namen=False, mlsd=False):
        ziel, voll = self._echt(pfad)
        eintraege = []
        if ziel is None:
            for name, ordner in self.server.wurzeln().items():
                eintraege.append((name, True, 0, os.path.getmtime(ordner) if os.path.isdir(ordner) else 0))
        else:
            if not os.path.isdir(ziel[1]):
                raise FtpFehler("Kein Ordner")
            for name in sorted(os.listdir(ziel[1])):
                p = os.path.join(ziel[1], name)
                try:
                    st = os.stat(p)
                except OSError:
                    continue
                eintraege.append((name, os.path.isdir(p), st.st_size, st.st_mtime))
        zeilen = []
        for name, ordner, groesse, zeit in eintraege:
            if nur_namen:
                zeilen.append(name)
            elif mlsd:
                zeilen.append("type=%s;size=%d;modify=%s; %s" % ("dir" if ordner else "file", groesse,
                                                                 time.strftime("%Y%m%d%H%M%S", time.gmtime(zeit)), name))
            else:
                zeilen.append("%s 1 h0rst h0rst %13d %s %s" % ("drwxr-xr-x" if ordner else "-rw-r--r--", groesse,
                                                              time.strftime("%b %d %H:%M", time.localtime(zeit)), name))
        return zeilen

    def handle(self):
        self.antworten("220 H0rSt FTP bereit")
        while True:
            try:
                zeile = self.rfile.readline(4096)
            except (OSError, socket.timeout):
                return
            if not zeile:
                return
            zeile = zeile.decode("utf-8", "replace").rstrip("\r\n")
            befehl, _, arg = zeile.partition(" ")
            befehl = befehl.upper()
            try:
                if self.befehl(befehl, arg) is False:
                    return
            except FtpFehler as fehler:
                self.antworten("550 %s" % fehler)
            except (OSError, ValueError) as fehler:
                self.antworten("451 %s" % str(fehler)[:100])

    def befehl(self, befehl, arg):
        e = self.server.einstellung
        if befehl == "USER":
            self.benutzer, self.angemeldet = arg, False
            return self.antworten("331 Passwort bitte")
        if befehl == "PASS":
            if secrets.compare_digest(self.benutzer.encode("utf-8"), e["benutzer"].encode("utf-8")) and secrets.compare_digest(arg.encode("utf-8"), e["passwort"].encode("utf-8")):
                self.angemeldet = True
                return self.antworten("230 Angemeldet")
            self.fehlversuche += 1
            time.sleep(1)
            self.antworten("530 Anmeldung abgelehnt")
            return False if self.fehlversuche >= 3 else None
        if befehl == "QUIT":
            self.antworten("221 Tschüss")
            return False
        if befehl in ("FEAT",):
            self.wfile.write(b"211-Features:\r\n UTF8\r\n MLSD\r\n SIZE\r\n MDTM\r\n REST STREAM\r\n EPSV\r\n PASV\r\n211 Ende\r\n")
            return None
        if befehl == "OPTS":
            return self.antworten("200 OK")
        if befehl == "SYST":
            return self.antworten("215 UNIX Type: L8")
        if befehl == "NOOP":
            return self.antworten("200 OK")
        if not self.angemeldet:
            return self.antworten("530 Bitte anmelden")
        if befehl in ("PWD", "XPWD"):
            return self.antworten('257 "%s"' % self.cwd.replace('"', '""'))
        if befehl in ("CWD", "XCWD", "CDUP"):
            ziel, voll = self._echt(".." if befehl == "CDUP" else arg)
            if ziel is not None and not os.path.isdir(ziel[1]):
                raise FtpFehler("Kein Ordner")
            self.cwd = voll
            return self.antworten("250 OK")
        if befehl == "TYPE":
            return self.antworten("200 Typ gesetzt")
        if befehl in ("PASV", "EPSV"):
            if self.pasv is not None:
                self.pasv.close()
            lauscher = passiv_lauscher(self.connection.getsockname()[0])
            self.pasv = lauscher
            port = lauscher.getsockname()[1]
            if befehl == "EPSV":
                return self.antworten("229 Passiv (|||%d|)" % port)
            ip = (os.environ.get("H0RST_FTP_ADRESSE") or self.connection.getsockname()[0]).replace(".", ",")
            return self.antworten("227 Passiv (%s,%d,%d)" % (ip, port >> 8, port & 255))
        if befehl == "REST":
            self.rest = max(0, int(arg or 0))
            return self.antworten("350 Weiter ab %d" % self.rest)
        if befehl in ("LIST", "NLST", "MLSD"):
            pfad = "" if arg.startswith("-") else arg
            zeilen = self._liste(pfad, befehl == "NLST", befehl == "MLSD")
            self.antworten("150 Liste kommt")
            verbindung = self._daten()
            with verbindung:
                verbindung.sendall(("\r\n".join(zeilen) + ("\r\n" if zeilen else "")).encode("utf-8"))
            return self.antworten("226 Fertig")
        if befehl in ("SIZE", "MDTM"):
            ziel, _ = self._echt(arg)
            if ziel is None or not os.path.isfile(ziel[1]):
                raise FtpFehler("Keine Datei")
            if befehl == "SIZE":
                return self.antworten("213 %d" % os.path.getsize(ziel[1]))
            return self.antworten("213 " + time.strftime("%Y%m%d%H%M%S", time.gmtime(os.path.getmtime(ziel[1]))))
        if befehl == "RETR":
            ziel, _ = self._echt(arg)
            if ziel is None or not os.path.isfile(ziel[1]):
                raise FtpFehler("Keine Datei")
            ab, self.rest = self.rest, 0
            self.antworten("150 Datei kommt")
            verbindung = self._daten()
            with verbindung, open(ziel[1], "rb") as datei:
                datei.seek(ab)
                try:
                    shutil.copyfileobj(datei, verbindung.makefile("wb"), 262144)
                except (BrokenPipeError, ConnectionResetError):
                    return self.antworten("426 Abgebrochen")
            return self.antworten("226 Fertig")
        if befehl in ("STOR", "MKD", "DELE"):
            ziel, _ = self._echt(arg)
            if not e["schreiben"] or ziel is None or ziel[0] != "eigener":
                raise FtpFehler("Nur lesen (Schreiben nur im eigenen Ordner, wenn eingeschaltet)")
            if befehl == "MKD":
                os.makedirs(ziel[1], exist_ok=True)
                return self.antworten("257 Angelegt")
            if befehl == "DELE":
                os.remove(ziel[1])
                return self.antworten("250 Gelöscht")
            self.antworten("150 Bereit")
            verbindung = self._daten()
            with verbindung, open(ziel[1], "wb") as datei:
                shutil.copyfileobj(verbindung.makefile("rb"), datei, 262144)
            return self.antworten("226 Gespeichert")
        return self.antworten("502 Nicht unterstützt")


class _Server(socketserver.ThreadingTCPServer):
    daemon_threads = True
    allow_reuse_address = True


class FtpServer:
    def __init__(self, einstellung=None, ordner=None, speichern=None):
        self.einstellung = self._sicher(einstellung or {})
        self.ordner = dict(ordner or {})  # {"xdcc": pfad, "youtube": pfad}
        self._speichern = speichern
        self._server = None
        self.fehler = ""
        self.heimnetz = True  # False: H0rSt laeuft nur fuer dieses Geraet, dann auch kein FTP

    @staticmethod
    def _sicher(einstellung):
        try:
            return server_pruefe(einstellung)
        except FtpFehler:
            return server_pruefe(dict(einstellung, an=False, ordner=""))

    def wurzeln(self):
        w = {n: p for n, p in self.ordner.items() if p and os.path.isdir(p)}
        if self.einstellung["ordner"]:
            w["eigener"] = self.einstellung["ordner"]
        return w

    @property
    def laeuft(self):
        return self._server is not None

    def starten(self):
        if self._server or not self.einstellung["an"]:
            return
        if not self.heimnetz:
            self.fehler = "H0rSt läuft nur für dieses Gerät. Für FTP H0rSt im Heimnetz freigeben (--host 0.0.0.0)."
            return
        try:
            server = _Server(("0.0.0.0", self.einstellung["port"]), _Sitzung)
        except OSError as fehler:
            self.fehler = "Port %d belegt oder nicht erlaubt: %s" % (self.einstellung["port"], fehler)
            log.warning("FTP-Server: %s", self.fehler)
            return
        server.einstellung = self.einstellung
        server.wurzeln = self.wurzeln
        self._server, self.fehler = server, ""
        threading.Thread(target=server.serve_forever, name="ftp-server", daemon=True).start()
        log.info("FTP-Server läuft auf Port %d", self.einstellung["port"])

    def stoppen(self):
        if self._server:
            self._server.shutdown()
            self._server.server_close()
            self._server = None

    def einstellen(self, neu):
        e = dict(self.einstellung)
        for k, w in (neu or {}).items():
            if k not in SERVER_STANDARD:
                raise FtpFehler("Unbekannte Einstellung: %s" % k)
            if k == "passwort" and not str(w or ""):
                continue  # leer = bleibt
            e[k] = w
        e = server_pruefe(e)
        self.stoppen()
        self.einstellung = e
        if self._speichern:
            self._speichern(dict(e))
        self.starten()
        return self.zustand()

    def zustand(self, adresse=""):
        e = self.einstellung
        return {"an": e["an"], "port": e["port"], "benutzer": e["benutzer"], "passwort_gesetzt": bool(e["passwort"]),
                "ordner": e["ordner"], "schreiben": e["schreiben"], "laeuft": self.laeuft, "fehler": self.fehler,
                "freigaben": sorted(self.wurzeln()),
                "adresse": "ftp://%s:%s/" % (os.environ.get("H0RST_FTP_ADRESSE") or adresse or "IP-DES-SERVERS",
                                            os.environ.get("H0RST_FTP_PORT_AUSSEN") or e["port"])}


