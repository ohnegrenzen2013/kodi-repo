"""Google Drive: Sicherungen jeder Art und Drive als Speicherort.

  * Anmelden per Geraete-Code wie bei Trakt (google.com/device). Dafuer braucht H0rSt einen eigenen OAuth-Client in der
    Google Cloud Console (Typ "Fernseher und Geraete mit begrenzter Eingabe", Drive-API eingeschaltet); dessen Client ID
    und Secret traegt der Admin ein. Berechtigung nur "drive.file": H0rSt sieht ausschliesslich, was es selbst angelegt
    hat – alles liegt im Ordner "H0rSt" in deinem Drive.
  * Sicherungen: jede automatische oder Hand-Sicherung der Nutzerdaten (h0rst-sicherung-*.json) auf Wunsch sofort nach
    H0rSt/Sicherungen; dort bleiben die neuesten N. Zurueckholen legt sie neben die lokalen Sicherungen, von dort geht
    das Wiederherstellen wie gewohnt.
  * Ordner und Dateien: aus dem Dateibrowser (Downloads, Fotos, Ablage, USB …) einzeln sichern oder Orte taeglich
    spiegeln (nur Neues und Geaendertes, nach Name und Groesse) nach H0rSt/<Ort>/….
  * Speicherort: Drive erscheint unter Heim → Speicher wie AiCloud oder Nextcloud (ansehen, abspielen mit Springen,
    herunterladen); die Wurzel ist der Ordner "H0rSt".

Nutzerdaten "gdrive": {"app": {client_id, client_secret}, "konto": {access_token, refresh_token, ablauf, email},
                       "auto": bool, "behalten": n, "spiegeln": [ort-id], "zuletzt", "fehler", "ordner": {pfad: id}}
"""

import json
import mimetypes
import os
import threading
import time
from urllib.parse import quote, urlencode

from .gdrive_grund import *
from .gdrive_grund import _json, _q, _teile
from .gdrive_konto import KontoMixin


class GDrive(KontoMixin):
    def __init__(self, verwaltung, anfrage=None, uhr=None):
        self._verwaltung = verwaltung  # Funktion: Verwaltung der Nutzerdaten (oder None)
        self.anfrage = anfrage or roh_anfrage
        self.uhr = uhr or time.time
        self._geraet = None
        self._sperre = threading.Lock()
        self._ordner_cache = {}
        self.auftrag = None            # {art, fertig, gesamt, uebersprungen, fehler, ende}

    # --- Drive-API ---------------------------------------------------------------------------------------------------
    def _roh(self, methode, url, kopf=None, daten=None):
        for erneuern in (False, True):
            k = dict(kopf or {}, Authorization="Bearer " + self._token(erneuern))
            status, antwort_kopf, inhalt = self.anfrage(methode, url, k, daten)
            if status != 401:
                return status, antwort_kopf, inhalt
        raise DriveFehler("Google lehnt die Anmeldung ab – neu verbinden")

    def _api(self, methode, url, inhalt=None):
        daten = json.dumps(inhalt).encode("utf-8") if inhalt is not None else None
        status, _, antwort = self._roh(methode, url, {"Content-Type": "application/json"} if daten is not None else None, daten)
        if status >= 400:
            fehler = _json(antwort).get("error") or {}
            meldung = fehler.get("message") if isinstance(fehler, dict) else ""
            raise DriveFehler("Google Drive: " + (meldung or "HTTP %d" % status))
        return _json(antwort)

    def liste(self, ordner_id):
        dateien, seite = [], ""
        while True:
            abfrage = {"q": "'%s' in parents and trashed=false" % _q(ordner_id), "pageSize": "1000",
                       "fields": "nextPageToken,files(id,name,mimeType,size,modifiedTime)", "orderBy": "folder,name"}
            if seite:
                abfrage["pageToken"] = seite
            d = self._api("GET", DRIVE + "/files?" + urlencode(abfrage))
            dateien.extend(d.get("files") or [])
            seite = d.get("nextPageToken") or ""
            if not seite or len(dateien) >= MAX_DATEIEN:
                return dateien

    def _kind(self, eltern, name, ordner=None):
        abfrage = "name='%s' and '%s' in parents and trashed=false" % (_q(name), _q(eltern))
        if ordner is not None:
            abfrage += " and mimeType%s'%s'" % ("=" if ordner else "!=", ORDNER_TYP)
        d = self._api("GET", DRIVE + "/files?" + urlencode({"q": abfrage, "fields": "files(id,name,mimeType,size,modifiedTime)", "pageSize": "10"}))
        return (d.get("files") or [None])[0]

    def ordner(self, teile, anlegen=True):
        """Id des Ordners H0rSt/<teile…>; legt fehlende an (oder None, wenn anlegen=False)."""
        pfad, eltern = "", "root"
        for name in [WURZEL] + list(teile):
            pfad += "/" + name
            if pfad in self._ordner_cache:
                eltern = self._ordner_cache[pfad]
                continue
            gefunden = self._kind(eltern, name, ordner=True)
            if not gefunden:
                if not anlegen:
                    return None
                gefunden = self._api("POST", DRIVE + "/files?fields=id", {"name": name, "mimeType": ORDNER_TYP, "parents": [eltern]})
            eltern = self._ordner_cache[pfad] = gefunden["id"]
        return eltern

    def hochladen(self, lokal, name, eltern, ersetzen=None):
        """Datei in Stuecken hochladen (fortsetzbares Hochladen). ersetzen = Id einer vorhandenen Datei (neue Fassung)."""
        groesse = os.path.getsize(lokal)
        art = mimetypes.guess_type(name)[0] or "application/octet-stream"
        meta = json.dumps({"name": name} if ersetzen else {"name": name, "parents": [eltern]}).encode("utf-8")
        url = "%s/files%s?uploadType=resumable&fields=id" % (UPLOAD, "/" + quote(ersetzen) if ersetzen else "")
        status, kopf, inhalt = self._roh("PATCH" if ersetzen else "POST", url, {
            "Content-Type": "application/json; charset=UTF-8", "X-Upload-Content-Type": art, "X-Upload-Content-Length": str(groesse)}, meta)
        ziel = kopf.get("location")
        if status >= 400 or not ziel:
            raise DriveFehler("Hochladen nicht möglich (HTTP %d)" % status)
        with open(lokal, "rb") as f:
            start = 0
            while True:
                stueck = f.read(STUECK)
                ende = start + len(stueck)
                bereich = "bytes %d-%d/%d" % (start, ende - 1, groesse) if stueck else "bytes */%d" % groesse
                status, _, inhalt = self.anfrage("PUT", ziel, {"Content-Length": str(len(stueck)), "Content-Range": bereich}, stueck)
                if status in (200, 201):
                    return _json(inhalt).get("id", "")
                if status != 308:
                    raise DriveFehler("Hochladen abgebrochen (HTTP %d) bei %s" % (status, name))
                start = ende
                if not stueck:
                    raise DriveFehler("Hochladen unvollständig: %s" % name)

    def herunterladen(self, datei_id):
        status, _, inhalt = self._roh("GET", "%s/files/%s?alt=media" % (DRIVE, quote(datei_id)))
        if status >= 400:
            raise DriveFehler("Herunterladen nicht möglich (HTTP %d)" % status)
        return inhalt

    def loeschen(self, datei_id):
        status, _, _ = self._roh("DELETE", "%s/files/%s" % (DRIVE, quote(datei_id)))
        if status >= 400 and status != 404:
            raise DriveFehler("Löschen nicht möglich (HTTP %d)" % status)

    # --- Sicherungen der Nutzerdaten ---------------------------------------------------------------------------------
    def sicherung_hochladen(self, lokal):
        ordner = self.ordner([SICHERUNGEN])
        datei_id = self.hochladen(lokal, os.path.basename(lokal), ordner)
        behalten = int(self._g().get("behalten") or 10)
        alle = sorted((f for f in self.liste(ordner) if f.get("name", "").startswith("h0rst-sicherung-")), key=lambda f: f["name"], reverse=True)
        for alt in alle[behalten:]:
            self.loeschen(alt["id"])
        self._setzen(zuletzt=self.uhr(), fehler="")
        return datei_id

    def sicherungen(self):
        ordner = self.ordner([SICHERUNGEN], anlegen=False)
        if not ordner:
            return []
        return sorted(({"id": f["id"], "name": f["name"], "groesse": int(f.get("size") or 0), "zeit": f.get("modifiedTime", "")}
                       for f in self.liste(ordner) if f.get("name", "").startswith("h0rst-sicherung-")), key=lambda f: f["name"], reverse=True)

    def nach_sicherung(self, lokal):
        """Ruft die Aktualisierung nach jeder lokalen Sicherung auf: im Hintergrund nach Drive, wenn eingeschaltet."""
        g = self._g()
        if not (g.get("konto") or {}).get("refresh_token") or not g.get("auto", True):
            return

        def los():
            try:
                self.sicherung_hochladen(lokal)
                log.info("Sicherung nach Google Drive: %s", os.path.basename(lokal))
            except DriveFehler as fehler:
                self._setzen(fehler=str(fehler))
                log.warning("Sicherung nach Google Drive: %s", fehler)
        threading.Thread(target=los, name="gdrive-sicherung", daemon=True).start()

    # --- Ordner und Dateien sichern ----------------------------------------------------------------------------------
    def sichern(self, lokal, ziel_teile, ausschluss=()):
        """Datei oder ganzen Ordner nach H0rSt/<ziel_teile…>; vorhandene Dateien gleicher Groesse bleiben, geaenderte
        bekommen eine neue Fassung. ausschluss: Unterordnernamen, die an jeder Tiefe uebersprungen werden.
        Verknuepfungen (Symlinks) werden nie hochgeladen. Gibt {fertig, uebersprungen, gesamt} zurueck."""
        if not os.path.exists(lokal):
            raise DriveFehler("Gibt es nicht: %s" % lokal)
        zaehler = {"fertig": 0, "uebersprungen": 0, "gesamt": 0}
        if os.path.islink(lokal):
            return zaehler
        if os.path.isfile(lokal):
            self._datei_sichern(lokal, self.ordner(ziel_teile), {}, zaehler)
            return zaehler
        for wurzel, ordner, dateien in os.walk(lokal):
            ordner[:] = sorted(o for o in ordner if not o.startswith(".") and o not in ausschluss
                                and not os.path.islink(os.path.join(wurzel, o)))
            rel = os.path.relpath(wurzel, lokal)
            ziel = self.ordner(list(ziel_teile) + ([] if rel == "." else _teile(rel)))
            dateien = sorted(n for n in dateien if not os.path.islink(os.path.join(wurzel, n)))
            vorhanden = {f["name"]: f for f in self.liste(ziel) if f.get("mimeType") != ORDNER_TYP} if dateien else {}
            for name in dateien:
                if zaehler["gesamt"] >= MAX_DATEIEN:
                    return zaehler
                self._datei_sichern(os.path.join(wurzel, name), ziel, vorhanden, zaehler)
        return zaehler

    def _datei_sichern(self, pfad, ziel, vorhanden, zaehler):
        name = os.path.basename(pfad)
        zaehler["gesamt"] += 1
        if self.auftrag is not None:
            self.auftrag.update(gesamt=zaehler["gesamt"], datei=name)
        alt = vorhanden.get(name)
        if alt and int(alt.get("size") or -1) == os.path.getsize(pfad):
            zaehler["uebersprungen"] += 1
            return
        self.hochladen(pfad, name, ziel, ersetzen=alt["id"] if alt else None)
        zaehler["fertig"] += 1
        if self.auftrag is not None:
            self.auftrag["fertig"] = zaehler["fertig"]

    def im_hintergrund(self, art, arbeit):
        """Ein Auftrag zur Zeit (Sichern, Spiegeln); Fortschritt steht in self.auftrag."""
        with self._sperre:
            if self.auftrag and not self.auftrag.get("ende"):
                raise DriveFehler("Ein Auftrag läuft schon")
            self.auftrag = {"art": art, "fertig": 0, "gesamt": 0, "uebersprungen": 0, "fehler": "", "ende": 0}

        def los():
            try:
                ergebnis = arbeit()
                self.auftrag.update(ergebnis or {})
                self._setzen(zuletzt=self.uhr(), fehler="")
            except Exception as fehler:  # noqa: BLE001 - ein Hintergrund-Auftrag darf nie unsichtbar
                # abstuerzen: ohne dieses Netz wuerde self.auftrag["ende"] trotzdem gesetzt (siehe
                # finally) und die Oberflaeche zeigt "fertig" fuer einen in Wahrheit gescheiterten Lauf.
                self.auftrag["fehler"] = str(fehler) or type(fehler).__name__
                self._setzen(fehler=self.auftrag["fehler"])
                log.warning("Google Drive (%s): %s", art, fehler)
            finally:
                self.auftrag["ende"] = self.uhr()
        threading.Thread(target=los, name="gdrive-" + art, daemon=True).start()
        return self.auftrag

    def spiegeln_faellig(self):
        g = self._g()
        return bool((g.get("konto") or {}).get("refresh_token") and g.get("spiegeln")) and \
            self.uhr() - float(g.get("gespiegelt") or 0) > SPIEGEL_ABSTAND and not (self.auftrag and not self.auftrag.get("ende"))

    def spiegeln(self, orte):
        """orte: [(id, name, lokaler pfad)] der gewaehlten Orte; alles nach H0rSt/<name>/."""
        zaehler = {"fertig": 0, "uebersprungen": 0, "gesamt": 0}
        for _, name, pfad in orte:
            if os.path.isdir(pfad):
                for k, v in self.sichern(pfad, [name]).items():
                    zaehler[k] += v
        self._setzen(gespiegelt=self.uhr())
        return zaehler

    # --- Drive als Speicherort (heimspeicher, Art "gdrive") ----------------------------------------------------------
    def finden(self, pfad):
        """Datei oder Ordner unter H0rSt/<pfad> -> Drive-Eintrag (None, wenn es ihn nicht gibt)."""
        teile = _teile(pfad)
        if not teile:
            wurzel = self.ordner([], anlegen=False)
            return {"id": wurzel, "mimeType": ORDNER_TYP, "name": WURZEL} if wurzel else None
        eltern = self.ordner(teile[:-1], anlegen=False)
        return self._kind(eltern, teile[-1]) if eltern else None

    def speicher_liste(self, pfad="/"):
        from .heimspeicher import art_von
        eintrag = self.finden(pfad)
        if eintrag is None:
            if not _teile(pfad):
                return []  # noch nichts gesichert
            raise DriveFehler("Ordner gibt es nicht")
        if eintrag.get("mimeType") != ORDNER_TYP:
            raise DriveFehler("Das ist kein Ordner")
        basis = "/" + "/".join(_teile(pfad))
        ergebnis = []
        for f in self.liste(eintrag["id"]):
            ordner = f.get("mimeType") == ORDNER_TYP
            zeit = 0
            try:
                zeit = int(time.mktime(time.strptime(f.get("modifiedTime", "")[:19], "%Y-%m-%dT%H:%M:%S")))
            except ValueError:
                pass
            ergebnis.append({"name": f["name"], "pfad": (basis.rstrip("/") + "/" + f["name"]), "ordner": ordner,
                             "groesse": int(f.get("size") or 0), "zeit": zeit, "typ": f.get("mimeType", ""),
                             "art": "ordner" if ordner else art_von(f["name"])})
        ergebnis.sort(key=lambda e: (not e["ordner"], e["name"].lower()))
        return ergebnis

    def download_adresse(self, pfad):
        eintrag = self.finden(pfad)
        if not eintrag or eintrag.get("mimeType") == ORDNER_TYP:
            raise DriveFehler("Datei gibt es nicht")
        return "%s/files/%s?alt=media" % (DRIVE, quote(eintrag["id"]))
