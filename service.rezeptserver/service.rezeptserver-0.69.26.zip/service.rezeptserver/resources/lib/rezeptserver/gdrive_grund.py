"""Google Drive: Konstanten, Fehler und gemeinsame Helfer."""

import json
import logging
import urllib.error
import urllib.request

from .netz import USER_AGENT

log = logging.getLogger("rezeptserver")

OAUTH = "https://oauth2.googleapis.com"
DRIVE = "https://www.googleapis.com/drive/v3"
UPLOAD = "https://www.googleapis.com/upload/drive/v3"
SCOPE = "https://www.googleapis.com/auth/drive.file"
ORDNER_TYP = "application/vnd.google-apps.folder"
SCHLUESSEL = "gdrive"
WURZEL = "H0rSt"
SICHERUNGEN = "Sicherungen"
STUECK = 8 * 1024 * 1024          # Hochladen in Stuecken (Vielfaches von 256 KiB, wie Google es verlangt)
SPIEGEL_ABSTAND = 24 * 3600
MAX_DATEIEN = 5000                # je Auftrag
AKTIV = None                      # die laufende Instanz (fuer heimspeicher: Drive als Speicherort)


class DriveFehler(ValueError):
    pass


def roh_anfrage(methode, url, kopf=None, daten=None, zeitgrenze=60):
    """(status, kopfzeilen klein geschrieben, inhalt als bytes) – auch bei HTTP-Fehlern."""
    k = {"User-Agent": USER_AGENT}
    k.update(kopf or {})
    anfrage = urllib.request.Request(url, data=daten, headers=k, method=methode)
    try:
        with urllib.request.urlopen(anfrage, timeout=zeitgrenze) as a:
            return a.status, {n.lower(): v for n, v in a.headers.items()}, a.read()
    except urllib.error.HTTPError as fehler:
        try:
            return fehler.code, {n.lower(): v for n, v in (fehler.headers or {}).items()}, fehler.read(64 * 1024)
        finally:
            fehler.close()
    except (urllib.error.URLError, OSError) as fehler:
        raise DriveFehler("Google nicht erreichbar: %s" % getattr(fehler, "reason", fehler))


def _json(inhalt):
    try:
        return json.loads(inhalt.decode("utf-8")) if inhalt else {}
    except (UnicodeDecodeError, ValueError):
        return {}


def _q(text):
    """Text fuer eine Drive-Suchabfrage (q=…): Apostroph und Backslash maskieren."""
    return str(text).replace("\\", "\\\\").replace("'", "\\'")


def _teile(pfad):
    teile = [t for t in str(pfad or "").replace("\\", "/").split("/") if t not in ("", ".")]
    if ".." in teile:
        raise DriveFehler("Ungültiger Pfad")
    return teile



