"""Google Drive: Nutzerdaten, Geraete-Code und Anmeldung."""

from urllib.parse import urlencode

from .gdrive_grund import DRIVE, OAUTH, SCHLUESSEL, SCOPE, DriveFehler, _json, log


class KontoMixin:
    """Nutzerdaten, Geraete-Code und Anmeldung."""

    # --- Nutzerdaten -------------------------------------------------------------------------------------------------
    @staticmethod
    def _abschnitt(daten):
        g = daten.get(SCHLUESSEL) if isinstance(daten.get(SCHLUESSEL), dict) else {}
        daten[SCHLUESSEL] = g
        return g

    def _v(self):
        v = self._verwaltung()
        if v is None:
            raise DriveFehler("Nutzerdaten nicht verfügbar")
        return v

    def _g(self):
        d = self._v().daten()
        return d.get(SCHLUESSEL) if isinstance(d.get(SCHLUESSEL), dict) else {}

    def _setzen(self, **werte):
        def tun(d):
            g = self._abschnitt(d)
            for k, v in werte.items():
                if v is None:
                    g.pop(k, None)
                else:
                    g[k] = v
        self._v().bearbeiten(tun)

    def stand(self, daten):
        g = daten.get(SCHLUESSEL) if isinstance(daten.get(SCHLUESSEL), dict) else {}
        app, konto = g.get("app") or {}, g.get("konto") or {}
        ergebnis = {"eingerichtet": bool(app.get("client_id") and app.get("client_secret")), "client_id": str(app.get("client_id") or ""),
                    "verbunden": bool(konto.get("refresh_token")), "email": konto.get("email", ""), "auto": bool(g.get("auto", True)),
                    "behalten": int(g.get("behalten") or 10), "spiegeln": list(g.get("spiegeln") or []),
                    "zuletzt": g.get("zuletzt", 0), "fehler": g.get("fehler", ""), "auftrag": self.auftrag}
        if self._geraet and self._geraet["bis"] > self.uhr():
            ergebnis["geraet"] = {k: self._geraet[k] for k in ("code", "url", "bis", "intervall")}
        return ergebnis

    @staticmethod
    def app_setzen(daten, wunsch):
        g = KontoMixin._abschnitt(daten)
        cid, geheim = str(wunsch.get("client_id") or "").strip(), str(wunsch.get("client_secret") or "").strip()
        if not cid:
            g.pop("app", None)
            return {"eingerichtet": False}
        if len(cid) > 300 or len(geheim) > 300:
            raise DriveFehler("Client ID oder Secret zu lang")
        app = dict(g.get("app") or {}, client_id=cid)
        if geheim:
            app["client_secret"] = geheim
        if not app.get("client_secret"):
            raise DriveFehler("Client Secret fehlt")
        g["app"] = app
        return {"eingerichtet": True}

    @staticmethod
    def einstellungen_setzen(daten, wunsch):
        g = KontoMixin._abschnitt(daten)
        if "auto" in wunsch:
            g["auto"] = bool(wunsch["auto"])
        if "behalten" in wunsch:
            try:
                g["behalten"] = max(1, min(100, int(wunsch["behalten"])))
            except (TypeError, ValueError):
                raise DriveFehler("behalten: Zahl von 1 bis 100")
        if "spiegeln" in wunsch:
            orte = wunsch["spiegeln"] if isinstance(wunsch["spiegeln"], list) else []
            g["spiegeln"] = [str(o)[:40] for o in orte if str(o).strip()][:20]
        return {k: g.get(k) for k in ("auto", "behalten", "spiegeln")}

    def _app(self):
        app = self._g().get("app") or {}
        if not app.get("client_id") or not app.get("client_secret"):
            raise DriveFehler("Google Drive ist noch nicht eingerichtet: Client ID und Secret eintragen")
        return app

    # --- Anmelden per Geraete-Code -----------------------------------------------------------------------------------
    def _formular(self, pfad, felder):
        status, _, inhalt = self.anfrage("POST", OAUTH + pfad, {"Content-Type": "application/x-www-form-urlencoded"},
                                         urlencode(felder).encode("ascii"))
        return status, _json(inhalt)

    def verbinden_start(self):
        app = self._app()
        status, d = self._formular("/device/code", {"client_id": app["client_id"], "scope": SCOPE})
        if status != 200 or not d.get("device_code"):
            raise DriveFehler("Google gibt keinen Code (%s) – stimmt die Client ID, Typ „Fernseher und Geräte mit begrenzter Eingabe“?"
                              % (d.get("error_description") or d.get("error") or "HTTP %d" % status))
        self._geraet = {"geraet": d["device_code"], "code": str(d.get("user_code") or ""), "intervall": int(d.get("interval") or 5),
                        "url": str(d.get("verification_url") or d.get("verification_uri") or "https://www.google.com/device"),
                        "bis": self.uhr() + int(d.get("expires_in") or 1800)}
        return {k: self._geraet[k] for k in ("code", "url", "bis", "intervall")}

    def verbinden_pruefen(self):
        g = self._geraet
        if not g or g["bis"] <= self.uhr():
            self._geraet = None
            return {"fertig": False, "warten": False, "fehler": "Der Code ist abgelaufen – neu verbinden"}
        app = self._app()
        status, d = self._formular("/token", {"client_id": app["client_id"], "client_secret": app["client_secret"],
                                              "device_code": g["geraet"], "grant_type": "urn:ietf:params:oauth:grant-type:device_code"})
        if d.get("error") in ("authorization_pending", "slow_down"):
            return {"fertig": False, "warten": True}
        if status != 200 or not d.get("access_token"):
            self._geraet = None
            return {"fertig": False, "warten": False,
                    "fehler": "abgelehnt" if d.get("error") == "access_denied" else (d.get("error_description") or "Google antwortet mit HTTP %d" % status)}
        self._geraet = None
        konto = {"access_token": d["access_token"], "refresh_token": str(d.get("refresh_token") or ""),
                 "ablauf": self.uhr() + int(d.get("expires_in") or 3600)}
        self._setzen(konto=konto, fehler="", ordner=None)
        self._ordner_cache.clear()
        email = ""
        try:
            email = str((self._api("GET", DRIVE + "/about?fields=user(emailAddress)").get("user") or {}).get("emailAddress") or "")
        except DriveFehler:
            pass
        if email:
            self._setzen(konto=dict(konto, email=email))
        return {"fertig": True, "warten": False, "email": email}

    def trennen(self):
        konto = self._g().get("konto") or {}
        if konto.get("refresh_token"):
            try:
                self.anfrage("POST", OAUTH + "/revoke?" + urlencode({"token": konto["refresh_token"]}),
                             {"Content-Type": "application/x-www-form-urlencoded"}, b"")
            except DriveFehler as fehler:
                log.info("Google Drive: Abmelden ohne Rueckmeldung: %s", fehler)
        self._geraet = None
        self._ordner_cache.clear()
        self._setzen(konto=None, ordner=None)
        return {"verbunden": False}

    def _token(self, erneuern=False):
        g = self._g()
        konto = g.get("konto") or {}
        if not konto.get("refresh_token"):
            raise DriveFehler("Google Drive ist nicht verbunden")
        if not erneuern and konto.get("access_token") and float(konto.get("ablauf") or 0) > self.uhr() + 60:
            return konto["access_token"]
        app = self._app()
        status, d = self._formular("/token", {"client_id": app["client_id"], "client_secret": app["client_secret"],
                                              "refresh_token": konto["refresh_token"], "grant_type": "refresh_token"})
        if status != 200 or not d.get("access_token"):
            self._setzen(fehler="Anmeldung abgelaufen – neu verbinden")
            raise DriveFehler("Anmeldung bei Google abgelaufen – neu verbinden")
        self._setzen(konto=dict(konto, access_token=d["access_token"], ablauf=self.uhr() + int(d.get("expires_in") or 3600)))
        return d["access_token"]

    def kopf(self):
        return {"Authorization": "Bearer " + self._token()}
