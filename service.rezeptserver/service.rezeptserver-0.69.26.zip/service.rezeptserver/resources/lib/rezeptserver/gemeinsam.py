"""Gemeinsam schauen (wie StreamWatch): Filme und Serien im selben Takt sehen – daheim oder unterwegs, jeder auf seinem Geraet.

Ein Raum hat einen kurzen Code. Wer H0rSt erreicht und den Code (oder den Einladungslink) hat, kommt hinein – im offenen
Raum sofort, sonst laesst der Gastgeber zu. Der Raum kennt das Medium (Adresse eines Streams aus H0rSt, Titel, Bild) und
den gemeinsamen Stand der Wiedergabe: laeuft/pausiert, an welcher Stelle, seit wann (Serverzeit). Jedes Geraet rechnet
daraus die Stelle von jetzt aus und zieht seinen Player nach; Abspielen, Pause und Springen meldet es dem Raum.
Wer steuern darf, stellt der Gastgeber ein (alle oder nur er). Dazu ein Chat und schnelle Reaktionen (😂 ❤️ 😱 …).
Jedes Geraet meldet beim Abfragen seine Stelle und ob es puffert – so sehen alle, wer hinterherhaengt.

Bestellen fuer die Watch-Party ("Drehteller" wie im China-Restaurant): Wer dran ist, waehlt seine Gerichte, dann dreht
sich der Teller zum Naechsten. Der Kassenbon rechnet je Person zusammen (Gerichte, Anteil an der Lieferung, eigenes
Trinkgeld) und zeigt, wer fuer wen zahlt – selbst, uebernommen oder als Geschenk. Bestellt wird dann in Lieferando,
Uber Eats & Co. (deren Apps haben keine offene Schnittstelle zum Bestellen); Bezahlen untereinander macht H0rSt nicht.
Gutscheine sammelt der Raum selbst: wer einen Code findet, traegt ihn ein – die Top 10 (Daumen, Kopien, frisch) sieht
jeder Raum, gespeichert ueber Neustarts hinweg (gutscheine.json), nach 30 Tagen fallen sie weg.

Alles uebrige im Speicher, nach 12 Stunden Ruhe ist ein Raum weg. Geraete erkennen sich an einer zufaelligen Kennung (sid);
die anderen sehen davon nur eine oeffentliche Kennung (kennung.py) – sonst koennte jeder im Raum als Gastgeber auftreten.
"""

import os
import random
import threading
import time

from .gemeinsam_bestellung import BestellungMixin
from .gemeinsam_grund import *
from .gemeinsam_grund import _ADRESSE, _BILD, _CODE, _GUTSCHEIN, _SID, _name, _text, _zahl
from .gemeinsam_gutscheine import GutscheinMixin
from .gemeinsam_raum import RaumMixin


class Gemeinsam(RaumMixin, BestellungMixin, GutscheinMixin):
    def __init__(self, uhr=time.time, zufall=None, datenordner=None):
        self.uhr = uhr
        self.zufall = zufall or random.Random()
        self._raeume = {}
        self._sperre = threading.Lock()
        self._gutschein_datei = os.path.join(datenordner, "gutscheine.json") if datenordner else None
        self._gutscheine = self._gutscheine_laden()

    # --- Hilfen -----------------------------------------------------------------------------------
