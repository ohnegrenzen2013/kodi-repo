"""Gemeinsam schauen: Bestellen, Drehteller und Kassenbon."""

from . import kennung
from .gemeinsam_grund import (DIENSTE, GemeinsamFehler, MAX_POSTEN, ONLINE, _text, cent)


class BestellungMixin:
    """Bestellen, Drehteller und Kassenbon."""

    # --- Bestellen: Drehteller und Kassenbon ----------------------------------------------------------
    @staticmethod
    def _in_reihe(r, sid):
        b = r.get("bestellung")
        if b and sid not in b["reihe"]:
            b["reihe"].append(sid)

    def _bestellung(self, r):
        if not r.get("bestellung"):
            raise GemeinsamFehler("Noch keine Bestellrunde – erst starten")
        return r["bestellung"]

    def _bestellung_neu(self, r, sid, w):
        m = self._mitglied(r, sid)
        if r.get("bestellung") and r["bestellung"]["posten"] and r["bestellung"]["status"] != "bestellt":
            raise GemeinsamFehler("Es läuft schon eine Bestellrunde")
        dienst = w.get("dienst") if w.get("dienst") in DIENSTE else "lieferando"
        reihe = [sid] + [k for k in sorted(r["mitglieder"], key=lambda k: r["mitglieder"][k]["seit"]) if k != sid]
        r["bestellung"] = {"dienst": dienst, "laden": _text(w.get("laden"), 60), "status": "offen", "bestellt_von": "",
                           "drehteller": w.get("drehteller") is not False, "reihe": reihe, "dran": 0, "runde": 1,
                           "posten": [], "lieferung": 0, "trinkgeld": {}, "zahler": {}, "start": m["name"]}
        self._system(r, "%s startet eine Bestellrunde bei %s%s – der Teller dreht sich" % (
            m["name"], DIENSTE[dienst][0], (" („%s“)" % r["bestellung"]["laden"]) if r["bestellung"]["laden"] else ""))

    def _offen_pruefen(self, b):
        if b["status"] == "bestellt":
            raise GemeinsamFehler("Schon bestellt – für Nachschlag eine neue Runde starten")

    def _posten(self, r, sid, w):
        m = self._mitglied(r, sid)
        b = self._bestellung(r)
        self._offen_pruefen(b)
        if b["drehteller"] and b["reihe"] and b["reihe"][b["dran"]] != sid:
            raise GemeinsamFehler("Der Teller steht gerade bei %s" % r["mitglieder"].get(b["reihe"][b["dran"]], {}).get("name", "jemand anderem"))
        was = _text(w.get("was"), 80)
        if not was:
            raise GemeinsamFehler("Was möchtest du?")
        try:
            menge = int(w.get("menge") or 1)
        except (TypeError, ValueError):
            menge = 1
        if not 1 <= menge <= 20:
            raise GemeinsamFehler("Menge 1 bis 20")
        if len(b["posten"]) >= MAX_POSTEN:
            raise GemeinsamFehler("Die Bestellung ist voll")
        r["zaehler"] += 1
        b["posten"].append({"nr": r["zaehler"], "sid": sid, "name": m["name"], "was": was, "preis": cent(w.get("preis")),
                            "menge": menge, "notiz": _text(w.get("notiz"), 80)})

    def _posten_weg(self, r, sid, w):
        b = self._bestellung(r)
        self._offen_pruefen(b)
        p = next((x for x in b["posten"] if x["nr"] == w.get("nr")), None)
        if not p:
            raise GemeinsamFehler("Diesen Posten gibt es nicht mehr")
        if p["sid"] != sid and sid != r["gastgeber"]:
            raise GemeinsamFehler("Nur eigene Posten entfernen")
        b["posten"].remove(p)

    def _drehen(self, r, sid, w):
        """Weiter zum Naechsten – wer dran ist, der Gastgeber oder (ist der Dranne nicht da) jeder."""
        self._mitglied(r, sid)
        b = self._bestellung(r)
        if not b["reihe"]:
            return
        dran = b["reihe"][b["dran"]]
        weg = dran not in r["mitglieder"] or self.uhr() - r["mitglieder"][dran]["zuletzt"] > ONLINE
        if sid not in (dran, r["gastgeber"]) and not weg:
            raise GemeinsamFehler("Weiterdrehen darf %s (oder der Gastgeber)" % r["mitglieder"][dran]["name"])
        b["dran"] = (b["dran"] + 1) % len(b["reihe"])
        if b["dran"] == 0:
            b["runde"] += 1

    def _drehteller(self, r, sid, w):
        self._nur_gastgeber(r, sid)
        self._bestellung(r)["drehteller"] = w.get("an") is not False

    def _lieferung(self, r, sid, w):
        self._mitglied(r, sid)
        b = self._bestellung(r)
        self._offen_pruefen(b)
        b["lieferung"] = cent(w.get("betrag"))

    def _trinkgeld(self, r, sid, w):
        self._mitglied(r, sid)
        self._bestellung(r)["trinkgeld"][sid] = cent(w.get("betrag"))  # auch nach dem Bestellen: Trinkgeld kommt oft danach

    def _zahlen(self, r, sid, w):
        """Wer zahlt fuer wen: ich uebernehme fuer jemanden (auch als Geschenk) – oder jemand zahlt wieder selbst."""
        m = self._mitglied(r, sid)
        b = self._bestellung(r)
        fuer = kennung.finden(w.get("fuer"), set(r["mitglieder"]) | {p["sid"] for p in b["posten"]} | set(b["zahler"]) | set(b["trinkgeld"]))
        if not fuer:
            raise GemeinsamFehler("Diese Person ist nicht in der Runde")
        if w.get("selbst"):
            if sid not in (fuer, b["zahler"].get(fuer, {}).get("von")):
                raise GemeinsamFehler("Zurücknehmen kann nur, wer übernommen hat – oder die Person selbst")
            b["zahler"].pop(fuer, None)
            return
        if fuer == sid:
            b["zahler"].pop(sid, None)
            return
        b["zahler"][fuer] = {"von": sid, "name": m["name"], "geschenk": w.get("geschenk") is True}  # Name bleibt, auch wenn sie geht

    def _bestellt(self, r, sid, w):
        m = self._mitglied(r, sid)
        b = self._bestellung(r)
        if not b["posten"]:
            raise GemeinsamFehler("Noch nichts ausgesucht")
        b["status"], b["bestellt_von"] = "bestellt", m["name"]
        self._system(r, "%s hat bei %s bestellt – guten Hunger! 🍜" % (m["name"], DIENSTE[b["dienst"]][0]))

    def _bestellung_ende(self, r, sid, w):
        self._mitglied(r, sid)
        if sid != r["gastgeber"] and r.get("bestellung") and r["bestellung"]["status"] != "bestellt":
            raise GemeinsamFehler("Eine offene Runde beendet der Gastgeber")
        r["bestellung"] = None

    @staticmethod
    def _zahler_von(b, sid):
        """Wer am Ende fuer sid zahlt: Ketten aufloesen (A zahlt fuer B, B fuer C -> A zahlt fuer C); im Kreis zahlt jeder selbst."""
        z, geschenk, gesehen = sid, False, {sid}
        while z in b["zahler"]:
            weiter = b["zahler"][z]
            geschenk = geschenk or weiter.get("geschenk", False)
            z = weiter["von"]
            if z in gesehen:
                return {"von": sid, "geschenk": False}
            gesehen.add(z)
        return {"von": z, "geschenk": geschenk}

    def kassenbon(self, r):
        """Je Person: Gerichte, Anteil Lieferung (gleich verteilt auf alle mit Posten), Trinkgeld, Summe und wer zahlt."""
        b = r["bestellung"]
        namen = {k: m["name"] for k, m in r["mitglieder"].items()}
        for p in b["posten"]:
            namen.setdefault(p["sid"], p["name"])
        for z in b["zahler"].values():
            namen.setdefault(z["von"], z.get("name", "?"))
        leute = [k for k in b["reihe"] if any(p["sid"] == k for p in b["posten"])]
        leute += [p["sid"] for p in b["posten"] if p["sid"] not in leute]
        leute = list(dict.fromkeys(leute))
        anteil, rest = divmod(b["lieferung"], len(leute)) if leute else (0, 0)
        personen = []
        for i, k in enumerate(leute):
            posten = [p for p in b["posten"] if p["sid"] == k]
            summe = sum(p["preis"] * p["menge"] for p in posten)
            liefer = anteil + (1 if i < rest else 0)
            trink = b["trinkgeld"].get(k, 0)
            zahler = self._zahler_von(b, k)
            personen.append({"sid": k, "name": namen.get(k, "?"), "posten": posten, "summe": summe, "lieferung": liefer, "trinkgeld": trink,
                             "gesamt": summe + liefer + trink, "zahlt": zahler["von"], "zahlt_name": namen.get(zahler["von"], "?"),
                             "geschenk": zahler["geschenk"] and zahler["von"] != k})
        for k, t in b["trinkgeld"].items():  # Trinkgeld ohne eigene Posten (z. B. wer nur mitschaut und spendiert)
            if t and k not in leute:
                zahler = self._zahler_von(b, k)
                personen.append({"sid": k, "name": namen.get(k, "?"), "posten": [], "summe": 0, "lieferung": 0, "trinkgeld": t, "gesamt": t,
                                 "zahlt": zahler["von"], "zahlt_name": namen.get(zahler["von"], "?"), "geschenk": False})
        zahler = {}
        for p in personen:
            z = zahler.setdefault(p["zahlt"], {"sid": p["zahlt"], "name": p["zahlt_name"], "betrag": 0, "fuer": []})
            z["betrag"] += p["gesamt"]
            if p["zahlt"] != p["sid"]:
                z["fuer"].append({"name": p["name"], "betrag": p["gesamt"], "geschenk": p["geschenk"]})
        gesamt = sum(p["gesamt"] for p in personen)
        return {"personen": personen, "zahler": sorted(zahler.values(), key=lambda z: -z["betrag"]), "gesamt": gesamt,
                "essen": sum(p["summe"] for p in personen), "lieferung": b["lieferung"], "trinkgeld": sum(b["trinkgeld"].values())}

    def _bestell_ansicht(self, r, sid):
        b = r.get("bestellung")
        if not b:
            return None
        dran = b["reihe"][b["dran"]] if b["reihe"] else ""
        return {"dienst": b["dienst"], "dienst_name": DIENSTE[b["dienst"]][0], "dienst_url": DIENSTE[b["dienst"]][1], "laden": b["laden"],
                "status": b["status"], "bestellt_von": b["bestellt_von"], "drehteller": b["drehteller"], "runde": b["runde"],
                "reihe": [{"sid": k, "name": r["mitglieder"][k]["name"]} for k in b["reihe"] if k in r["mitglieder"]],
                "dran": dran, "dran_name": r["mitglieder"].get(dran, {}).get("name", ""),
                "ich_dran": not b["drehteller"] or dran == sid, "bon": self.kassenbon(r), "start": b["start"]}
