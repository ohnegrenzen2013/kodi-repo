"""Gemeinsam schauen: Konstanten, Fehler und gemeinsame Helfer."""

import re


MAX_RAEUME = 40
MAX_MITGLIEDER = 16
MAX_CHAT = 120
MAX_REAKTIONEN = 30
RUHE = 12 * 3600
ONLINE = 20  # so lange nach der letzten Abfrage gilt ein Geraet als da
REAKTIONEN = ("😂", "❤️", "😱", "👏", "🍿", "😢", "🔥", "👀")
ZUSTAENDE = ("spielt", "pause", "puffert", "laedt", "fertig", "")
_SID = re.compile(r"^[A-Za-z0-9_-]{8,40}$")
_CODE = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
# Adressen, die ein Raum abspielt: ein Pfad auf diesem H0rSt (Streams, Debrid, Usenet, Wiedergabe) oder http(s)
_ADRESSE = re.compile(r"^(?:https?://[^\s]+|/[^\s]*|api/[^\s]*)$", re.I)
_BILD = re.compile(r"^https?://[^\s]+$", re.I)
# Bestellen
DIENSTE = {"lieferando": ("Lieferando", "https://www.lieferando.de/"), "ubereats": ("Uber Eats", "https://www.ubereats.com/de"),
           "wolt": ("Wolt", "https://wolt.com/de/deu"), "andere": ("Anderer Lieferdienst", "")}
MAX_POSTEN = 200
MAX_BETRAG = 100000  # Cent je Posten, Lieferung und Trinkgeld (1.000 €)
GUTSCHEIN_TAGE = 30
MAX_GUTSCHEINE = 300
MAX_STIMMEN = 500  # gemerkte Geraete je Gutschein (Daumen, Kopien)
_GUTSCHEIN = re.compile(r"^[A-Za-z0-9][A-Za-z0-9_-]{2,39}$")


class GemeinsamFehler(ValueError):
    pass


def cent(wert):
    """Betrag in Cent aus "8,50", "8.5", 8.5 oder "1.234,50" (Euro); leer = 0."""
    if isinstance(wert, bool):
        raise GemeinsamFehler("Betrag erwartet")
    text = str(wert if wert is not None else "").strip().replace("€", "").replace(" ", "")
    if not text:
        return 0
    if re.match(r"^\d{1,3}(\.\d{3})+,\d{1,2}$", text):  # 1.234,50
        text = text.replace(".", "")
    text = text.replace(",", ".")
    if not re.match(r"^\d{1,6}(\.\d{1,2})?$", text):
        raise GemeinsamFehler("Betrag wie 8,50 eingeben")
    betrag = round(float(text) * 100)
    if betrag > MAX_BETRAG:
        raise GemeinsamFehler("Höchstens 1.000 €")
    return betrag


def _text(roh, laenge):
    return " ".join(str(roh or "").split())[:laenge]


def _name(roh, standard="Gast"):
    return _text(roh, 24) or standard


def _zahl(wert, standard=0.0):
    try:
        z = float(wert)
    except (TypeError, ValueError):
        return standard
    return z if z == z and abs(z) != float("inf") else standard  # NaN und unendlich
