"""Gemeinsam schauen: gesammelte Gutscheine."""

import json
import os

from . import kennung
from .gemeinsam_grund import (DIENSTE, GUTSCHEIN_TAGE, GemeinsamFehler, MAX_GUTSCHEINE, MAX_STIMMEN,
                              _GUTSCHEIN, _text)


class GutscheinMixin:
    """Gesammelte Gutscheine."""

    # --- Gutscheine: von den Raeumen gesammelt, Top 10 fuer alle -------------------------------------
    def _gutscheine_laden(self):
        if not self._gutschein_datei:
            return []
        try:
            with open(self._gutschein_datei, encoding="utf-8") as f:
                liste = json.load(f)
            return [g for g in liste if isinstance(g, dict) and _GUTSCHEIN.match(str(g.get("code") or ""))] if isinstance(liste, list) else []
        except (OSError, ValueError):
            return []

    def _gutscheine_speichern(self):
        if not self._gutschein_datei:
            return
        try:
            tmp = self._gutschein_datei + ".neu"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(self._gutscheine, f, ensure_ascii=False, indent=1)
            os.replace(tmp, self._gutschein_datei)
        except OSError:
            pass

    def _gutscheine_aufraeumen(self, jetzt):
        grenze = jetzt - GUTSCHEIN_TAGE * 86400
        self._gutscheine = [g for g in self._gutscheine if g.get("zuletzt", 0) >= grenze][-MAX_GUTSCHEINE:]

    def _top_gutscheine(self, jetzt, sid=""):
        """Top 10: Daumen und Kopien zaehlen (je Geraet einmal), frische (die letzten 2 Tage) bekommen Vorsprung."""
        def wert(g):
            frisch = max(0.0, 2.0 - (jetzt - g.get("neu", 0)) / 86400)
            return g.get("gut", 0) * 2 + g.get("kopiert", 0) + frisch * 3
        top = sorted((g for g in self._gutscheine if jetzt - g.get("zuletzt", 0) < GUTSCHEIN_TAGE * 86400), key=lambda g: (-wert(g), -g.get("neu", 0)))[:10]
        ich = kennung.dauerhaft(sid)
        return [dict({k: g.get(k) for k in ("nr", "code", "text", "dienst", "von", "neu", "gut", "kopiert")},
                     ich_gut=ich in g.get("gut_von", []), ich_eigen=ich == g.get("eigen")) for g in top]

    @staticmethod
    def _einmal(g, feld, sid):
        """Zaehlt feld (gut/kopiert) fuer dieses Geraet nur einmal und nie fuer den eigenen Code – sonst klickt sich einer
        seinen Code an die Spitze."""
        wer, liste = kennung.dauerhaft(sid), g.setdefault(feld + "_von", [])
        if wer in liste or wer == g.get("eigen"):
            return
        liste.append(wer)
        del liste[:-MAX_STIMMEN]
        g[feld] = g.get(feld, 0) + 1

    def _gutschein(self, r, sid, w):
        m = self._mitglied(r, sid)
        code = str(w.get("code") or "").strip()
        if not _GUTSCHEIN.match(code):
            raise GemeinsamFehler("Gutschein-Code: 3 bis 40 Zeichen, Buchstaben, Ziffern, - und _")
        dienst = w.get("dienst") if w.get("dienst") in DIENSTE else "andere"
        jetzt = self.uhr()
        self._gutscheine_aufraeumen(jetzt)
        alt = next((g for g in self._gutscheine if g["code"].upper() == code.upper() and g["dienst"] == dienst), None)
        if alt:  # schon bekannt: gilt als frisch bestaetigt (ein Daumen je Geraet)
            alt["zuletzt"] = jetzt
            self._einmal(alt, "gut", sid)
        else:  # wer ihn eintraegt ("eigen"), kann ihn nicht selbst hochdaumen
            nr = max([g.get("nr", 0) for g in self._gutscheine] + [0]) + 1
            self._gutscheine.append({"nr": nr, "code": code, "text": _text(w.get("text"), 120), "dienst": dienst, "von": m["name"],
                                     "neu": jetzt, "zuletzt": jetzt, "gut": 0, "kopiert": 0, "eigen": kennung.dauerhaft(sid)})
        self._gutscheine_speichern()

    def _gutschein_zaehlen(self, w, feld, sid):
        jetzt = self.uhr()
        g = next((x for x in self._gutscheine if x.get("nr") == w.get("nr") and jetzt - x.get("zuletzt", 0) < GUTSCHEIN_TAGE * 86400), None)
        if not g:
            raise GemeinsamFehler("Diesen Gutschein gibt es nicht mehr")
        self._einmal(g, feld, sid)
        g["zuletzt"] = jetzt
        self._gutscheine_speichern()

    def _gutschein_gut(self, r, sid, w):
        self._mitglied(r, sid)
        self._gutschein_zaehlen(w, "gut", sid)

    def _gutschein_kopiert(self, r, sid, w):
        self._mitglied(r, sid)
        self._gutschein_zaehlen(w, "kopiert", sid)
