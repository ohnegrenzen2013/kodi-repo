"""Gemeinsam schauen: Raum, Ansicht und Aktionen."""

from . import kennung
from .gemeinsam_grund import (GemeinsamFehler, MAX_CHAT, MAX_MITGLIEDER, MAX_RAEUME, MAX_REAKTIONEN, ONLINE,
                              REAKTIONEN, RUHE, ZUSTAENDE, _ADRESSE, _BILD, _CODE, _SID, _name, _text, _zahl)


class RaumMixin:
    """Raum, Ansicht und Aktionen."""

    def _aufraeumen(self):
        jetzt = self.uhr()
        for code in [c for c, r in self._raeume.items() if jetzt - r["zeit"] > RUHE]:
            del self._raeume[code]

    def _raum(self, code):
        r = self._raeume.get(str(code or "").strip().upper())
        if not r:
            raise GemeinsamFehler("Raum nicht gefunden – Code prüfen")
        return r

    @staticmethod
    def _sid(sid):
        if not _SID.match(str(sid or "")):
            raise GemeinsamFehler("Geräte-Kennung fehlt")
        return sid

    def _mitglied(self, r, sid):
        m = r["mitglieder"].get(sid)
        if not m:
            raise GemeinsamFehler("Du bist (noch) nicht in diesem Raum")
        return m

    def _darf_steuern(self, r, sid):
        return sid in r["mitglieder"] and (r["alle_steuern"] or sid == r["gastgeber"])

    def stelle(self, r, jetzt=None):
        """Stelle der gemeinsamen Wiedergabe in Sekunden, von jetzt aus gerechnet."""
        w = r["wiedergabe"]
        jetzt = self.uhr() if jetzt is None else jetzt
        return max(0.0, w["position"] + (jetzt - w["zeit"] if w["laeuft"] else 0.0))

    @staticmethod
    def _sids(r):
        """Alle Geraete-Kennungen, die in der Ansicht eines Raums vorkommen koennen."""
        sids = set(r["mitglieder"]) | set(r["wartend"]) | {r["gastgeber"]} | {c["sid"] for c in r["chat"]}
        b = r.get("bestellung")
        if b:
            sids |= set(b["reihe"]) | {p["sid"] for p in b["posten"]} | set(b["zahler"]) | {z["von"] for z in b["zahler"].values()}
            sids |= set(b["trinkgeld"])
        return sids

    def ansicht(self, r, sid=""):
        """Was ein Geraet sieht; Wartende sieht nur der Gastgeber. Wer (noch) nicht drin ist – etwa vor der Tuer eines
        geschlossenen Raums –, sieht nur den Raum selbst, nicht Film, Chat, Leute oder Bestellung."""
        jetzt = self.uhr()
        gastgeber = sid == r["gastgeber"]
        kopf = {"code": r["code"], "name": r["name"], "offen": r["offen"], "gruppe": r["gruppe"], "alle_steuern": r["alle_steuern"],
                "gastgeber": r["mitglieder"][r["gastgeber"]]["name"] if r["gastgeber"] in r["mitglieder"] else "",
                "ich": {"sid": kennung.oeffentlich(sid), "gastgeber": gastgeber, "drin": sid in r["mitglieder"], "wartet": sid in r["wartend"],
                        "steuern": self._darf_steuern(r, sid)},
                "stand": r["stand"], "jetzt": jetzt}
        if sid not in r["mitglieder"]:
            return dict(kopf, mitglieder=[], wartend=[], medium=None, chat=[], reaktionen=[], bestellung=None, gutscheine=[],
                        wiedergabe={"laeuft": False, "position": 0.0, "zeit": jetzt, "von": "", "stelle": 0.0})
        mitglieder = []
        for k, m in sorted(r["mitglieder"].items(), key=lambda kv: (kv[0] != r["gastgeber"], kv[1]["seit"])):
            mitglieder.append({"sid": k, "name": m["name"], "gastgeber": k == r["gastgeber"], "online": jetzt - m["zuletzt"] < ONLINE,
                               "position": round(m["position"], 1), "zustand": m["zustand"]})
        return kennung.verbergen(dict(
            kopf, mitglieder=mitglieder, wartend=[{"sid": k, "name": w["name"]} for k, w in r["wartend"].items()] if gastgeber else [],
            medium=r["medium"], wiedergabe=dict(r["wiedergabe"], stelle=round(self.stelle(r, jetzt), 2)),
            chat=r["chat"][-50:], reaktionen=[x for x in r["reaktionen"] if jetzt - x["zeit"] < 10],
            bestellung=self._bestell_ansicht(r, sid), gutscheine=self._top_gutscheine(jetzt, sid)), self._sids(r))

    def _geaendert(self, r):
        r["zeit"] = self.uhr()
        r["stand"] += 1

    # --- Aktionen ---------------------------------------------------------------------------------
    def lesen(self, code, sid="", position=None, zustand=None):
        """Stand eines Raums; ein Mitglied meldet dabei seine Stelle und ob es puffert (aendert den Stand nicht)."""
        with self._sperre:
            r = self._raum(code)
            m = r["mitglieder"].get(sid)
            if m:
                m["zuletzt"] = self.uhr()
                if position is not None:
                    m["position"] = max(0.0, _zahl(position, m["position"]))
                if zustand is not None and zustand in ZUSTAENDE:
                    m["zustand"] = zustand
            return self.ansicht(r, sid)

    def aktion(self, w):
        if not isinstance(w, dict):
            raise GemeinsamFehler("JSON-Objekt erwartet")
        a = w.get("aktion")
        sid = self._sid(w.get("sid"))
        with self._sperre:
            self._aufraeumen()
            if a == "neu":
                return self._neu(w, sid)
            r = self._raum(w.get("raum"))
            tun = {"beitreten": self._beitreten, "zulassen": self._zulassen, "offen": self._offen, "verlassen": self._verlassen,
                   "medium": self._medium, "steuern": self._steuern, "alle_steuern": self._alle_steuern, "chat": self._chat,
                   "reaktion": self._reaktion, "bestellung_neu": self._bestellung_neu, "posten": self._posten,
                   "posten_weg": self._posten_weg, "drehen": self._drehen, "drehteller": self._drehteller,
                   "lieferung": self._lieferung, "trinkgeld": self._trinkgeld, "zahlen": self._zahlen,
                   "bestellt": self._bestellt, "bestellung_ende": self._bestellung_ende,
                   "gutschein": self._gutschein, "gutschein_gut": self._gutschein_gut, "gutschein_kopiert": self._gutschein_kopiert}.get(a)
            if not tun:
                raise GemeinsamFehler("Unbekannte Aktion")
            tun(r, sid, w)
            self._geaendert(r)
            return self.ansicht(r, sid) if r["code"] in self._raeume else {"code": r["code"], "ich": {"sid": sid, "drin": False}}

    def _neu(self, w, sid):
        if len(self._raeume) >= MAX_RAEUME:
            raise GemeinsamFehler("Gerade zu viele Räume – später noch einmal")
        code = "".join(self.zufall.choice(_CODE) for _ in range(5))
        while code in self._raeume:
            code = "".join(self.zufall.choice(_CODE) for _ in range(5))
        gruppe = _text(w.get("gruppe"), 20)
        if gruppe and w.get("_gruppen") is not None and gruppe not in w["_gruppen"]:
            raise GemeinsamFehler("Einen Raum nur für eine Gruppe eröffnet, wer selbst darin ist")
        r = {"code": code, "name": _text(w.get("name"), 40) or "Filmabend", "offen": w.get("offen") is not False, "gruppe": gruppe,
             "alle_steuern": w.get("alle_steuern") is not False, "gastgeber": sid, "mitglieder": {}, "wartend": {},
             "medium": None, "wiedergabe": {"laeuft": False, "position": 0.0, "zeit": self.uhr(), "von": ""},
             "chat": [], "reaktionen": [], "bestellung": None, "zaehler": 0, "zeit": self.uhr(), "stand": 0}
        r["mitglieder"][sid] = self._neues_mitglied(w.get("name_ich"))
        self._raeume[code] = r
        if w.get("medium"):
            self._medium(r, sid, w)
        return self.ansicht(r, sid)

    def _neues_mitglied(self, name):
        return {"name": _name(name), "seit": self.uhr(), "zuletzt": self.uhr(), "position": 0.0, "zustand": ""}

    def _beitreten(self, r, sid, w):
        if sid in r["mitglieder"]:
            r["mitglieder"][sid]["name"] = _name(w.get("name_ich"), r["mitglieder"][sid]["name"])
            return
        if r["gruppe"] and w.get("_gruppen") is not None and r["gruppe"] not in w["_gruppen"]:
            raise GemeinsamFehler("Dieser Raum ist nur für die Gruppe „%s“" % r["gruppe"])
        if len(r["mitglieder"]) >= MAX_MITGLIEDER:
            raise GemeinsamFehler("Der Raum ist voll")
        if r["offen"]:
            r["mitglieder"][sid] = self._neues_mitglied(w.get("name_ich"))
            self._system(r, "%s ist dabei" % r["mitglieder"][sid]["name"])
            self._in_reihe(r, sid)
        else:
            r["wartend"][sid] = {"name": _name(w.get("name_ich"))}

    def _nur_gastgeber(self, r, sid):
        if sid != r["gastgeber"]:
            raise GemeinsamFehler("Das darf nur der Gastgeber")

    def _zulassen(self, r, sid, w):
        self._nur_gastgeber(r, sid)
        wen = kennung.finden(w.get("wen"), list(r["wartend"]))
        wer = r["wartend"].pop(wen, None)
        if wer and w.get("ja") is not False and len(r["mitglieder"]) < MAX_MITGLIEDER:
            r["mitglieder"][wen] = self._neues_mitglied(wer["name"])
            self._system(r, "%s ist dabei" % wer["name"])
            self._in_reihe(r, wen)

    def _offen(self, r, sid, w):
        self._nur_gastgeber(r, sid)
        r["offen"] = w.get("offen") is not False

    def _alle_steuern(self, r, sid, w):
        self._nur_gastgeber(r, sid)
        r["alle_steuern"] = w.get("alle") is not False

    def _verlassen(self, r, sid, w):
        r["wartend"].pop(sid, None)
        m = r["mitglieder"].pop(sid, None)
        if not m:
            return
        self._system(r, "%s ist gegangen" % m["name"])
        b = r.get("bestellung")
        if b and sid in b["reihe"]:  # vom Drehteller nehmen; war er dran, ist der Naechste dran
            i = b["reihe"].index(sid)
            b["reihe"].remove(sid)
            if b["reihe"] and (i < b["dran"] or b["dran"] >= len(b["reihe"])):
                b["dran"] = (b["dran"] - (1 if i < b["dran"] else 0)) % len(b["reihe"])
        if not r["mitglieder"]:
            del self._raeume[r["code"]]
        elif sid == r["gastgeber"]:  # der am laengsten Dabeie uebernimmt
            r["gastgeber"] = min(r["mitglieder"], key=lambda k: r["mitglieder"][k]["seit"])
            self._system(r, "%s ist jetzt Gastgeber" % r["mitglieder"][r["gastgeber"]]["name"])

    def _medium(self, r, sid, w):
        if not self._darf_steuern(r, sid):
            raise GemeinsamFehler("Den Film wählt in diesem Raum der Gastgeber")
        m = w.get("medium")
        if not isinstance(m, dict):
            raise GemeinsamFehler("Medium als Objekt erwartet")
        url = str(m.get("url") or "").strip()
        if len(url) > 2000 or not _ADRESSE.match(url):
            raise GemeinsamFehler("Diese Adresse kann der Raum nicht abspielen")
        bild = str(m.get("bild") or "").strip()
        meta = m.get("meta") if isinstance(m.get("meta"), dict) else {}
        r["medium"] = {"url": url, "titel": _text(m.get("titel"), 120) or "Video", "bild": bild if _BILD.match(bild) and len(bild) < 1000 else "",
                       "hls": bool(m.get("hls")) or ".m3u8" in url.lower() or "/api/hls/" in url or url.startswith("api/hls/"),
                       "meta": {k: _text(meta.get(k), 200) for k in ("id", "typ", "titel", "poster", "hintergrund", "logo")
                                if meta.get(k) and (k in ("id", "typ", "titel") or _BILD.match(str(meta[k])))}}
        start = max(0.0, _zahl(m.get("start"), 0.0))
        r["wiedergabe"] = {"laeuft": False, "position": start, "zeit": self.uhr(), "von": r["mitglieder"][sid]["name"]}
        for x in r["mitglieder"].values():
            x["position"], x["zustand"] = start, "laedt"
        self._system(r, "%s hat „%s“ gewählt" % (r["mitglieder"][sid]["name"], r["medium"]["titel"]))

    def _steuern(self, r, sid, w):
        if not self._darf_steuern(r, sid):
            raise GemeinsamFehler("Steuern darf in diesem Raum nur der Gastgeber")
        if not r["medium"]:
            raise GemeinsamFehler("Noch kein Film gewählt")
        laeuft = r["wiedergabe"]["laeuft"] if w.get("laeuft") is None else w.get("laeuft") is True
        position = self.stelle(r) if w.get("position") is None else max(0.0, _zahl(w.get("position"), self.stelle(r)))
        r["wiedergabe"] = {"laeuft": laeuft, "position": position, "zeit": self.uhr(), "von": r["mitglieder"][sid]["name"]}

    def _chat(self, r, sid, w):
        m = self._mitglied(r, sid)
        text = _text(w.get("text"), 500)
        if not text:
            raise GemeinsamFehler("Leere Nachricht")
        r["zaehler"] += 1
        r["chat"].append({"nr": r["zaehler"], "von": m["name"], "sid": sid, "text": text, "zeit": self.uhr(),
                          "stelle": round(self.stelle(r), 1) if r["medium"] else None})
        del r["chat"][:-MAX_CHAT]

    def _reaktion(self, r, sid, w):
        m = self._mitglied(r, sid)
        if w.get("zeichen") not in REAKTIONEN:
            raise GemeinsamFehler("Unbekannte Reaktion")
        r["zaehler"] += 1
        r["reaktionen"].append({"nr": r["zaehler"], "von": m["name"], "zeichen": w["zeichen"], "zeit": self.uhr()})
        del r["reaktionen"][:-MAX_REAKTIONEN]

    def _system(self, r, text):
        r["zaehler"] += 1
        r["chat"].append({"nr": r["zaehler"], "von": "", "sid": "", "text": text, "zeit": self.uhr(), "stelle": None})
        del r["chat"][:-MAX_CHAT]
