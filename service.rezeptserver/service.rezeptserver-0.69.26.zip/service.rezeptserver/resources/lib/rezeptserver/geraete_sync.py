"""geraete_sync.py: echter Merge zwischen zwei unabhaengigen H0rSt-Installationen (NuvioMobile-Plan NV6).

Anders als "ein Server, viele Clients" (das kann H0rSt schon immer) geht es hier um zwei VOLLSTAENDIGE,
unabhaengige Installationen mit je eigener nutzerdaten.db - z. B. ein PC-Server zu Hause und die Android-
App mit ihrem eigenen eingebetteten Server unterwegs. zusammenfuehren() nimmt eine fremde Momentaufnahme
(gleiche Form wie die eigenen Nutzerdaten, z. B. aus konfig.exportiere()/einlesen() oder direkt von einer
anderen Installation) und fuehrt sie in die lokalen Nutzerdaten ein. Mutiert daten, wirft nur bei
offensichtlich falscher Form (kein dict) - einzelne kaputte Eintraege fallen weg, statt den ganzen Merge
abzubrechen.

geraet_id() vergibt beim ersten Aufruf eine stabile, zufaellige Kennung je Installation - nur um einen
Merge mit der eigenen, versehentlich zurueckgespielten Momentaufnahme zu erkennen (NV6c: z. B. die eigene
letzte Drive-Sicherung erneut herunterladen).

Prinzip je Datenbereich (die vier, fuer die NV6a einen "geaendert"-Zeitstempel ergaenzt hat - siehe dort,
warum gerade diese vier):
  - Profile (profile.py, daten["profile"]["liste"]): gleiche id auf beiden Seiten -> der Eintrag mit dem
    neueren Zeitstempel ("geaendert", sonst "erstellt") gewinnt vollstaendig; nur auf einer Seite vorhanden
    -> wird uebernommen (bis MAX_PROFILE). Nicht zusammengefuehrt: Gruppen, Einladungen, Beitrittsanfragen,
    Sitzungen (profile.py) - Sitzungen sind Anmelde-Tokens, die gehoeren nie auf ein anderes Geraet, und fuer
    den Rest waere eine echte Zusammenfuehrung ein eigener, hier nicht begonnener Umfang.
  - Merkliste/Verlauf/Weiterschauen (sehen.py, je Profil-Id): gleicher Titel (typ, id) auf beiden Seiten ->
    neuerer Zeitstempel gewinnt; sonst Vereinigung. Ergebnis nach Zeitstempel absteigend sortiert - genau
    die Reihenfolge, die die Listen schon heute haben (neuester Eintrag zuerst).
  - Eigene Anbieter (anbieter.py, daten["anbieter"]): gleiche Id -> neuerer "geaendert" gewinnt, inklusive
    der dazugehoerigen Zugangsdaten unter daten["einstellungen"][id]; sonst Vereinigung. Mitgelieferte
    Anbieter (kein eigener Eintrag in daten["anbieter"]) sind nie betroffen.
  - Einstellungen (einstellungen_werte.py, daten["oberflaeche"] + daten["sprachen"]): EIN gemeinsamer
    Zeitstempel ("oberflaeche_geaendert") fuer den ganzen Block - der neuere gewinnt vollstaendig, kein
    Feld-fuer-Feld-Merge (waere eine groessere Strukturaenderung, siehe WISSEN.md NV6a).

Nur fremde Eintraege werden vor der Uebernahme geprueft/bereinigt (sehen.karte()/weiter_eintrag(),
anbieter.pruefe_eigene(), einstellungen_werte.pruefe()) - lokale Daten gelten als bereits gueltig und
werden nicht noch einmal validiert, damit ein Validierungsfehler beim Mergen nie echte lokale Daten
verwirft.

Bewusst nicht zusammengefuehrt (eigener, hier nicht begonnener Umfang je Bereich): Filter, Live-TV-Listen,
Badges, Downloads-Warteschlangen und alles andere in den Nutzerdaten ausserhalb der vier genannten Bereiche.
Namensgleiche, aber unabhaengig auf beiden Seiten angelegte Profile werden NICHT anhand des Namens
zusammengefuehrt (nur anhand der Id) - zwei "Admin"-Profile mit unterschiedlicher Id bleiben zwei Profile.
"""

import re
import secrets

from . import anbieter, profile, sehen
from .einstellungen_grund import SCHLUESSEL as OBERFLAECHE_SCHLUESSEL, SPRACHEN
from .einstellungen_werte import pruefe as einstellungen_pruefen

GERAET_SCHLUESSEL = "geraet_id"
_GERAET_RE = re.compile(r"^[a-f0-9]{16}$")


class GeraeteSyncFehler(ValueError):
    pass


def geraet_id(daten):
    """Stabile, zufaellige Kennung dieser Installation; wird beim ersten Aufruf erzeugt und gespeichert."""
    gid = daten.get(GERAET_SCHLUESSEL)
    if not isinstance(gid, str) or not _GERAET_RE.match(gid):
        gid = secrets.token_hex(8)
        daten[GERAET_SCHLUESSEL] = gid
    return gid


def _zeit(eintrag, *felder):
    if not isinstance(eintrag, dict):
        return 0
    for feld in felder:
        w = eintrag.get(feld)
        if isinstance(w, (int, float)) and not isinstance(w, bool):
            return w
    return 0


def _liste_mergen(lokal, fremd, schluessel, zeitfelder, pruefen, deckel, neu_oben=False):
    """Listen-Form (Profile, Merkliste/Verlauf/Weiterschauen): schluessel(eintrag) bestimmt die Identitaet,
    bei Konflikt gewinnt der neuere Zeitstempel. Gibt (neue_liste, geaenderte_schluessel) zurueck."""
    index, ergebnis = {}, []
    for e in lokal or []:
        if isinstance(e, dict):
            index[schluessel(e)] = len(ergebnis)
            ergebnis.append(e)
    geaendert = []
    for roh in fremd or []:
        eintrag = pruefen(roh)
        if eintrag is None:
            continue
        k = schluessel(eintrag)
        i = index.get(k)
        if i is None:
            if len(ergebnis) < deckel:
                index[k] = len(ergebnis)
                ergebnis.append(eintrag)
                geaendert.append(k)
        elif _zeit(eintrag, *zeitfelder) > _zeit(ergebnis[i], *zeitfelder):
            ergebnis[i] = eintrag
            geaendert.append(k)
    if neu_oben:
        ergebnis.sort(key=lambda e: _zeit(e, *zeitfelder), reverse=True)
    return ergebnis[:deckel], geaendert


def _dict_mergen(lokal, fremd, zeitfelder, pruefen):
    """{id: eintrag}-Form (eigene Anbieter): neuer Zeitstempel gewinnt den ganzen Eintrag."""
    ergebnis = dict(lokal or {})
    geaendert = []
    for eid, roh in (fremd or {}).items():
        eintrag = pruefen(eid, roh)
        if eintrag is None:
            continue
        bisher = ergebnis.get(eid)
        if bisher is None or _zeit(eintrag, *zeitfelder) > _zeit(bisher, *zeitfelder):
            ergebnis[eid] = eintrag
            geaendert.append(eid)
    return ergebnis, geaendert


def _profil_pruefen(roh):
    if not isinstance(roh, dict):
        return None
    pid, name = roh.get("id"), roh.get("name")
    if not isinstance(pid, str) or not pid or not isinstance(name, str) or not name.strip():
        return None
    return roh


def _profile_mergen(daten, fremd):
    lokal = profile.daten_von(daten)
    fremd_profile = fremd.get(profile.SCHLUESSEL) if isinstance(fremd.get(profile.SCHLUESSEL), dict) else {}
    neue_liste, geaendert = _liste_mergen(lokal["liste"], fremd_profile.get("liste"), lambda e: e.get("id"),
                                          ("geaendert", "erstellt"), _profil_pruefen, profile.MAX_PROFILE)
    lokal["liste"] = neue_liste
    daten[profile.SCHLUESSEL] = lokal
    return len(geaendert)


def _karte_pruefen(roh):
    try:
        return sehen.karte(roh)
    except sehen.SehenFehler:
        return None


def _weiter_pruefen(roh):
    try:
        return sehen.weiter_eintrag(roh)
    except sehen.SehenFehler:
        return None


def _sehen_schluessel(e):
    return (e.get("typ"), e.get("id"))


def _sehen_eine_liste(lokal, fremd, art):
    if art == "weiterschauen":
        return _liste_mergen(lokal, fremd, _sehen_schluessel, ("zeit",), _weiter_pruefen,
                              sehen.MAX_WEITERSCHAUEN, neu_oben=True)
    deckel = sehen.MAX_MERKLISTE if art == "merkliste" else sehen.MAX_VERLAUF
    return _liste_mergen(lokal, fremd, _sehen_schluessel, ("geaendert",), _karte_pruefen, deckel, neu_oben=True)


def _sehen_mergen(daten, fremd):
    alle = daten.get(sehen.SCHLUESSEL) if isinstance(daten.get(sehen.SCHLUESSEL), dict) else {}
    fremd_alle = fremd.get(sehen.SCHLUESSEL) if isinstance(fremd.get(sehen.SCHLUESSEL), dict) else {}
    geaendert = 0
    for profil_id in set(alle) | set(fremd_alle):
        lokal_eigen = alle.get(profil_id) if isinstance(alle.get(profil_id), dict) else {}
        fremd_eigen = fremd_alle.get(profil_id) if isinstance(fremd_alle.get(profil_id), dict) else {}
        neu = {}
        for art in ("merkliste", "verlauf", "weiterschauen"):
            liste, aenderungen = _sehen_eine_liste(lokal_eigen.get(art) or [], fremd_eigen.get(art) or [], art)
            neu[art] = liste
            geaendert += len(aenderungen)
        alle[profil_id] = neu
    daten[sehen.SCHLUESSEL] = alle
    return geaendert


def _anbieter_pruefen(eid, roh):
    if not isinstance(roh, dict):
        return None
    try:
        anbieter.pruefe_eigene({eid: roh})
    except anbieter.AnbieterFehler:
        return None
    return roh


def _anbieter_mergen(daten, fremd):
    lokal = daten.get("anbieter") if isinstance(daten.get("anbieter"), dict) else {}
    fremd_anbieter = fremd.get("anbieter") if isinstance(fremd.get("anbieter"), dict) else {}
    neu, geaendert = _dict_mergen(lokal, fremd_anbieter, ("geaendert",), _anbieter_pruefen)
    daten["anbieter"] = neu
    lokal_zugang = daten.get("einstellungen") if isinstance(daten.get("einstellungen"), dict) else {}
    fremd_zugang = fremd.get("einstellungen") if isinstance(fremd.get("einstellungen"), dict) else {}
    for eid in geaendert:
        werte = fremd_zugang.get(eid)
        if isinstance(werte, dict):
            lokal_zugang[eid] = {str(k)[:60]: str(v)[:2000] for k, v in werte.items() if isinstance(k, str)}
    daten["einstellungen"] = lokal_zugang
    return len(geaendert)


def _einstellungen_mergen(daten, fremd):
    lokal_zeit, fremd_zeit = _zeit(daten, "oberflaeche_geaendert"), _zeit(fremd, "oberflaeche_geaendert")
    if fremd_zeit <= lokal_zeit:
        return 0
    daten[OBERFLAECHE_SCHLUESSEL] = einstellungen_pruefen(fremd.get(OBERFLAECHE_SCHLUESSEL))
    if isinstance(fremd.get(SPRACHEN), dict):
        daten[SPRACHEN] = {k: list(v) if isinstance(v, list) else v for k, v in fremd[SPRACHEN].items()}
    else:
        daten.pop(SPRACHEN, None)
    daten["oberflaeche_geaendert"] = fremd_zeit
    return 1


def zusammenfuehren(daten, fremd):
    """Fuehrt eine fremde Momentaufnahme in daten ein. Mutiert daten, wirft nur bei offensichtlich falscher
    Form. Gibt einen Bericht {bereich: Anzahl geaenderter/uebernommener Eintraege} zurueck."""
    if not isinstance(fremd, dict):
        raise GeraeteSyncFehler("Momentaufnahme muss ein JSON-Objekt sein")
    eigene_id = geraet_id(daten)
    if fremd.get(GERAET_SCHLUESSEL) == eigene_id:
        return {"profile": 0, "sehen": 0, "anbieter": 0, "einstellungen": 0, "selbe_geraete_kennung": True}
    return {
        "profile": _profile_mergen(daten, fremd),
        "sehen": _sehen_mergen(daten, fremd),
        "anbieter": _anbieter_mergen(daten, fremd),
        "einstellungen": _einstellungen_mergen(daten, fremd),
    }
