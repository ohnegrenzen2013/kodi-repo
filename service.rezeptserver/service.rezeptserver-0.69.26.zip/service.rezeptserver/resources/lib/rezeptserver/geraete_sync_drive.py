"""GeraeteAbgleich: Transport fuer geraete_sync.py ueber Google Drive (NuvioMobile-Plan NV6c).

Jede teilnehmende Installation legt im eigenen Drive-Ordner "Geraete-Abgleich" (siehe geraete_sync_grund.py,
getrennt von "Sicherungen"/"Komplettbackup") genau eine, laufend ueberschriebene Momentaufnahme ab
(h0rst-geraet-<eigene geraet_id>.json - gleiche Form wie konfig.sicherung(), kein Passwort, da der Ordner
ohnehin nur ueber das eigene Google-Konto erreichbar ist). Ein Lauf (jetzt_starten()/_lauf()) laedt alle
ANDEREN Momentaufnahmen aus diesem Ordner herunter, fuehrt sie der Reihe nach ueber
geraete_sync.zusammenfuehren() ein (ein kaputter/unlesbarer Download haelt die anderen nicht auf) und laedt
danach die eigene, jetzt moeglicherweise durch den Merge veraenderte Momentaufnahme neu hoch (ersetzen,
nie eine zweite Datei anlegen - sonst wuechse der Ordner mit jedem Lauf).

Muster wie KomplettBackup/GDrive.spiegeln_faellig(): ein Lauf zur Zeit, eigenes Intervall, eigene
Einstellungen unter daten["geraete_abgleich"] - unabhaengig vom bestehenden Spiegeln/Sichern (laeuft in
einem eigenen Drive-Ordner, kann parallel dazu laufen)."""

from .geraete_sync import GERAET_SCHLUESSEL, GeraeteSyncFehler, geraet_id, zusammenfuehren
from .geraete_sync_grund import (
    DRIVE_ORDNER,
    INTERVALL_STANDARD,
    INTERVALL_WAHL,
    GeraeteAbgleichFehler,
    SCHLUESSEL,
    log,
    os,
    tempfile,
    threading,
    time,
)
from .gdrive import DriveFehler, ORDNER_TYP
from .konfig import DatenFehler, aus_sicherung, exportiere

_FELDER = ("profile", "sehen", "anbieter", "einstellungen")


class GeraeteAbgleich:
    def __init__(self, verwaltung, gdrive=None, uhr=None):
        self._verwaltung = verwaltung
        self.gdrive = gdrive
        self.uhr = uhr or time.time
        self._sperre = threading.Lock()
        self.auftrag = None  # {gefunden, profile, sehen, anbieter, einstellungen, fehler, ende}

    @staticmethod
    def _abschnitt(daten):
        k = daten.get(SCHLUESSEL) if isinstance(daten.get(SCHLUESSEL), dict) else {}
        daten[SCHLUESSEL] = k
        return k

    def _v(self):
        v = self._verwaltung()
        if v is None:
            raise GeraeteAbgleichFehler("Nutzerdaten nicht verfügbar")
        return v

    def _k(self):
        d = self._v().daten()
        return d.get(SCHLUESSEL) if isinstance(d.get(SCHLUESSEL), dict) else {}

    def _setzen(self, **werte):
        def tun(d):
            k = self._abschnitt(d)
            for name, wert in werte.items():
                if wert is None:
                    k.pop(name, None)
                else:
                    k[name] = wert
        self._v().bearbeiten(tun)

    def stand(self, daten):
        k = daten.get(SCHLUESSEL) if isinstance(daten.get(SCHLUESSEL), dict) else {}
        return {"an": bool(k.get("an")), "intervall_stunden": int(k.get("intervall_stunden") or INTERVALL_STANDARD),
                "zuletzt": k.get("zuletzt", 0), "fehler": k.get("fehler", ""), "auftrag": self.auftrag,
                "geraet_id": str(daten.get(GERAET_SCHLUESSEL) or "")}

    @staticmethod
    def einstellungen_setzen(daten, wunsch):
        k = GeraeteAbgleich._abschnitt(daten)
        if "an" in wunsch:
            k["an"] = bool(wunsch["an"])
        if "intervall_stunden" in wunsch:
            try:
                stunden = int(wunsch["intervall_stunden"])
            except (TypeError, ValueError):
                stunden = -1
            if stunden not in INTERVALL_WAHL:
                raise GeraeteAbgleichFehler("Intervall: " + "/".join(str(s) for s in INTERVALL_WAHL))
            k["intervall_stunden"] = stunden
        return {name: k.get(name) for name in ("an", "intervall_stunden")}

    def faellig(self):
        k = self._k()
        return bool(k.get("an")) and bool(self.gdrive) and \
            self.uhr() - float(k.get("zuletzt") or 0) > int(k.get("intervall_stunden") or INTERVALL_STANDARD) * 3600 and \
            not (self.auftrag and not self.auftrag.get("ende"))

    def jetzt_starten(self):
        if not self.gdrive:
            raise GeraeteAbgleichFehler("Google Drive ist nicht eingerichtet")
        with self._sperre:
            if self.auftrag and not self.auftrag.get("ende"):
                raise GeraeteAbgleichFehler("Ein Abgleich läuft schon")
            self.auftrag = dict(dict.fromkeys(("gefunden",) + _FELDER, 0), fehler="", ende=0)

        def los():
            try:
                self._lauf()
                self._setzen(zuletzt=self.uhr(), fehler="")
            except (GeraeteAbgleichFehler, GeraeteSyncFehler, DriveFehler) as fehler:
                self.auftrag["fehler"] = str(fehler)
                self._setzen(fehler=str(fehler))
                log.warning("Geraete-Abgleich: %s", fehler)
            finally:
                self.auftrag["ende"] = self.uhr()
        threading.Thread(target=los, name="geraete-abgleich", daemon=True).start()
        return self.auftrag

    def _lauf(self):
        eigene_id = self._v().bearbeiten(geraet_id)
        eigener_name = "h0rst-geraet-%s.json" % eigene_id
        ordner = self.gdrive.ordner([DRIVE_ORDNER])
        eigene_datei = None
        for datei in self.gdrive.liste(ordner):
            if datei.get("mimeType") == ORDNER_TYP:
                continue
            if datei.get("name") == eigener_name:
                eigene_datei = datei
                continue
            self.auftrag["gefunden"] += 1
            try:
                roh = self.gdrive.herunterladen(datei["id"]).decode("utf-8")
                fremd = aus_sicherung(roh)
            except (DriveFehler, DatenFehler, UnicodeDecodeError) as fehler:
                log.warning("Geraete-Abgleich: %s nicht lesbar (%s)", datei.get("name"), fehler)
                continue
            try:
                bericht = self._v().bearbeiten(lambda d, fremd=fremd: zusammenfuehren(d, fremd))
            except GeraeteSyncFehler as fehler:
                log.warning("Geraete-Abgleich: %s (%s)", datei.get("name"), fehler)
                continue
            for feld in _FELDER:
                self.auftrag[feld] += bericht.get(feld, 0)
        fd, tmp_pfad = tempfile.mkstemp(suffix=".json", prefix="h0rst-geraet-")
        os.close(fd)
        try:
            exportiere(self._v().konfig_pfad, tmp_pfad)
            self.gdrive.hochladen(tmp_pfad, eigener_name, ordner, ersetzen=eigene_datei["id"] if eigene_datei else None)
        finally:
            os.remove(tmp_pfad)
