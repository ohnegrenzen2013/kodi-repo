"""Grundlage des Geraete-Abgleichs ueber Google Drive (NuvioMobile-Plan NV6c): Importe, Logger,
Konstanten und der Fehler. Alles hier wird samt Importen wieder exportiert (rezeptserver.geraete_sync_drive)."""

import logging
import os
import tempfile
import threading
import time

log = logging.getLogger("rezeptserver")

SCHLUESSEL = "geraete_abgleich"
# Eigener Drive-Ordner, getrennt von "Sicherungen" (Notfall-Sicherung/-Wiederherstellung einer einzelnen
# Datei, von Hand ausgeloest) und "Komplettbackup" (ganze Ordner, einseitig server -> Drive). Hier legt
# JEDE teilnehmende Installation ihre eigene, laufend ueberschriebene Momentaufnahme ab; jede andere liest
# alle fremden Momentaufnahmen und fuehrt sie zusammen (siehe geraete_sync.py).
DRIVE_ORDNER = "Geraete-Abgleich"
INTERVALL_STANDARD = 6
INTERVALL_WAHL = (1, 6, 24)


class GeraeteAbgleichFehler(ValueError):
    pass
