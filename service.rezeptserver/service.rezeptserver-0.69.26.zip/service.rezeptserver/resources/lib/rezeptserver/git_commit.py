"""Git-Commit, absichtlich ohne Push: diese Automatisierung darf Dateien versionieren, aber niemals
selbst veroeffentlichen. Push auf main ist eine Veroeffentlichung (APK-/Docker-/Kodi-Repo-Build) und bleibt
ein manueller, von einem Menschen ausdruecklich bestaetigter Schritt - deshalb gibt es hier bewusst keine
push()-Funktion und wird nie eine geben.

Git ist nicht auf jedem H0rSt-Ziel vorhanden (Android-App, Kodi-Direktbetrieb, Termux) - verfuegbar() prueft
das vorab, committen() schlaegt dort kontrolliert fehl statt abzustuerzen.
"""

import shutil
import subprocess


class GitFehler(ValueError):
    pass


def verfuegbar(wurzel):
    """True nur wenn das Programm "git" installiert ist UND wurzel/.git existiert."""
    if not shutil.which("git"):
        return False
    try:
        ergebnis = subprocess.run(["git", "rev-parse", "--is-inside-work-tree"], cwd=wurzel,
                                   capture_output=True, text=True, timeout=10)
        return ergebnis.returncode == 0 and ergebnis.stdout.strip() == "true"
    except (OSError, subprocess.TimeoutExpired):
        return False


def _git(befehl, wurzel, zeitlimit=30):
    try:
        ergebnis = subprocess.run(["git"] + befehl, cwd=wurzel, capture_output=True, text=True, timeout=zeitlimit)
    except (OSError, subprocess.TimeoutExpired) as fehler:
        raise GitFehler(str(fehler)) from fehler
    if ergebnis.returncode != 0:
        raise GitFehler((ergebnis.stderr or ergebnis.stdout or "git-Befehl fehlgeschlagen").strip()[:2000])
    return ergebnis.stdout


def committen(dateien, nachricht, wurzel):
    """git add <genau diese Dateien> + git commit -m <nachricht>, nie "git add -A"/".". Wirft GitFehler bei
    jedem Problem (kein Repo, nichts zu committen, ein Hook schlaegt fehl). Gibt {"ok": True, "sha": str}."""
    if not verfuegbar(wurzel):
        raise GitFehler("Kein Git-Repository auf diesem Geraet - automatisches Anwenden braucht einen "
                         "lokalen Checkout (PC, Raspberry Pi, Docker).")
    if not dateien:
        raise GitFehler("Keine Dateien zum Committen")
    _git(["add", "--"] + list(dateien), wurzel)
    _git(["commit", "-m", nachricht], wurzel)
    sha = _git(["rev-parse", "HEAD"], wurzel).strip()
    return {"ok": True, "sha": sha}
