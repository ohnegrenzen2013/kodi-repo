"""GNUnet-Werkzeuge: Netzwerk-Stack, Anwendungen und Werkzeuge an einer Stelle.

Die Liste sammelt geprüfte Links zu GNUnet selbst, den mitgelieferten Anwendungen
(GNU Name System, Filesharing, Conversation, re:claimID), aufbauenden Projekten
(GNU Taler, secushare, Messenger) und den Werkzeugen für Betrieb und Android.
H0rSt startet GNUnet nicht selbst und lädt keine fremde Software nach; die Liste
erklärt nur, wofür jedes Projekt gut ist und wo die aktuelle Quelle liegt.
"""

STAND = "2026-11-06"
GRUPPEN = [
    ("kern", "GNUnet selbst"),
    ("anwendungen", "Anwendungen aus GNUnet"),
    ("aufbau", "Auf GNUnet aufbauend"),
    ("android", "Android & Messenger"),
    ("werkzeuge", "Werkzeuge & Betrieb"),
    ("nicht", "Geprüft, aber nicht als Werkzeug"),
]

TOOLS = [
    # --- GNUnet selbst ---
    {"id": "gnunet", "name": "GNUnet", "gruppe": "kern", "art": "Netzwerk-Stack", "status": "ok",
     "url": "https://www.gnunet.org/en/index.html", "lizenz": "AGPL-3.0-or-later",
     "text": "Freier Netzwerk-Stack für sichere, verteilte und datensparsame Anwendungen: Adressierung, "
             "verschlüsselte Kanäle, Namensauflösung und Peer-Austausch ohne zentrale Stelle. H0rSt startet "
             "GNUnet nicht selbst, sondern sammelt die Werkzeuge an einer Stelle."},
    {"id": "install", "name": "GNUnet installieren", "gruppe": "kern", "art": "Anleitung", "status": "ok",
     "url": "https://www.gnunet.org/en/install.html", "lizenz": "",
     "text": "Pakete für Debian, Alpine, Arch, Fedora, NixOS, Homebrew und Guix sowie der Weg über den "
             "Quellcode – mit den nötigen Abhängigkeiten und Startbefehlen."},
    {"id": "handbuch", "name": "GNUnet-Handbuch", "gruppe": "kern", "art": "Dokumentation", "status": "ok",
     "url": "https://docs.gnunet.org/handbook/gnunet.html", "lizenz": "",
     "text": "Handbuch und API-Dokumentation: Einrichtung, Konfiguration, Betrieb und die Dienste "
             "(namestore, fs, cadet, conversation, vpn, dht, messenger)."},
    {"id": "quelle", "name": "GNUnet-Quellcode", "gruppe": "kern", "art": "Quellcode", "status": "ok",
     "url": "https://git.gnunet.org/gnunet/gnunet/", "lizenz": "AGPL-3.0-or-later",
     "text": "Offizielles Git-Repository des Kerns in C. Patches und Fehler gehen über den GNUnet-Bugtracker, "
             "nicht über fremde Mirrors."},

    # --- Anwendungen aus GNUnet ---
    {"id": "gns", "name": "GNU Name System (GNS)", "gruppe": "anwendungen", "art": "Namenssystem", "status": "ok",
     "url": "https://www.gnunet.org/en/gns.html", "lizenz": "AGPL-3.0-or-later",
     "text": "Dezentraler Ersatz für DNS: Namensauflösung als gerichteter Graph, kryptografisch signierte "
             "Einträge und private Abfragen. Die Spezifikation steht in LSD0001."},
    {"id": "gns-spec", "name": "GNU Name System (LSD0001)", "gruppe": "anwendungen", "art": "Spezifikation", "status": "ok",
     "url": "https://lsd.gnunet.org/lsd0001", "lizenz": "siehe Dokument",
     "text": "Die technische Spezifikation des GNU Name System: Aufbau, Records, Zonen und die "
             "kryptografischen Garantien der Auflösung."},
    {"id": "reclaim", "name": "re:claimID", "gruppe": "anwendungen", "art": "Identität", "status": "ok",
     "url": "https://www.gnunet.org/en/reclaim/index.html", "lizenz": "AGPL-3.0-or-later",
     "text": "Selbstbestimmte Identität auf GNS: Attribute für Websites freigeben, ohne sie einem zentralen "
             "Anbieter zu überlassen (OpenID Connect)."},
    {"id": "filesharing", "name": "GNUnet Filesharing (Alpha)", "gruppe": "anwendungen", "art": "Dateien teilen", "status": "prüfen",
     "url": "https://docs.gnunet.org/handbook/users/fs.html", "lizenz": "AGPL-3.0-or-later",
     "text": "Zensurresistentes, anonymes Teilen von Dateien; der Herausgeber entscheidet zwischen Tempo und "
             "Anonymität. Laut Projekt Alpha – Stand und Verhalten vor dem Einsatz prüfen."},
    {"id": "conversation", "name": "GNUnet Conversation (Pre-Alpha)", "gruppe": "anwendungen", "art": "Sprache", "status": "prüfen",
     "url": "https://docs.gnunet.org/handbook/users/conversation.html", "lizenz": "AGPL-3.0-or-later",
     "text": "Verschlüsselte Sprachkommunikation über GNUnet, dezentral geroutet. Laut Projekt Pre-Alpha – "
             "nur zum Ausprobieren, nicht als belastbarer Notruf- oder Alltagsweg."},

    # --- Auf GNUnet aufbauend ---
    {"id": "taler", "name": "GNU Taler", "gruppe": "aufbau", "art": "Bezahlen", "status": "ok",
     "url": "https://taler.net/", "lizenz": "GPL-3.0-or-later",
     "text": "Datenschutzfreundliches elektronisches Bezahlen: Zahlungen werden in Millisekunden bestätigt, "
             "ohne Kreditkartendaten an den Händler zu geben. Laut GNUnet Alpha."},
    {"id": "secushare", "name": "secushare", "gruppe": "aufbau", "art": "Soziales Netz", "status": "prüfen",
     "url": "https://secushare.org/", "lizenz": "siehe Projekt",
     "text": "Dezentrales soziales Netzwerk auf GNUnet mit PSYC und Ende-zu-Ende-Verschlüsselung. "
             "Projektstand und Betrieb vor dem Einsatz prüfen."},
    {"id": "messenger-gtk", "name": "Messenger-GTK", "gruppe": "aufbau", "art": "Messenger", "status": "ok",
     "url": "https://git.gnunet.org/gnunet/messenger-gtk/", "lizenz": "AGPL-3.0",
     "text": "GTK-Oberfläche für den GNUnet-Messenger: Direkt- und Gruppenchats, Sprachnachrichten, Dateien, "
             "Video-/Sprachanrufe und Bildschirmfreigabe, Ende-zu-Ende-verschlüsselt."},
    {"id": "messenger-cli", "name": "messenger-cli", "gruppe": "aufbau", "art": "Messenger", "status": "ok",
     "url": "https://git.gnunet.org/gnunet/messenger-cli/", "lizenz": "siehe Projekt",
     "text": "Terminal-Oberfläche für denselben Messenger-Dienst; vollständig kompatibel mit Messenger-GTK."},
    {"id": "libgnunetchat", "name": "libgnunetchat", "gruppe": "aufbau", "art": "Bibliothek", "status": "ok",
     "url": "https://git.gnunet.org/gnunet/libgnunetchat/", "lizenz": "siehe Projekt",
     "text": "C-Bibliothek für Chat-Funktionen auf dem GNUnet-Messenger; Grundlage für Messenger-GTK, "
             "messenger-cli und die Android-App."},

    # --- Android & Messenger ---
    {"id": "gnunet-android", "name": "GNUnet für Android", "gruppe": "android", "art": "Android-App", "status": "prüfen",
     "url": "https://git.gnunet.org/gnunet/gnunet-android/", "lizenz": "siehe Projekt",
     "text": "Android-Port des GNUnet-Kerns als Quellcode. Kein Eintrag in F-Droid oder im Play Store belegt; "
             "vor dem Bauen Stand und Anleitung im Repository prüfen."},
    {"id": "messenger-android", "name": "GNUnet Messenger für Android", "gruppe": "android", "art": "Android-App", "status": "prüfen",
     "url": "https://git.gnunet.org/gnunet/messenger-android/", "lizenz": "siehe Projekt",
     "text": "Android-Oberfläche für den GNUnet-Messenger, aktiv gepflegt. Bau- und Bezugsweg vor dem Einsatz "
             "prüfen; H0rSt installiert die App nicht selbst."},

    # --- Werkzeuge & Betrieb ---
    {"id": "gnunet-gtk", "name": "gnunet-gtk", "gruppe": "werkzeuge", "art": "Oberfläche", "status": "prüfen",
     "url": "https://docs.gnunet.org/handbook/guis/index.html", "lizenz": "siehe Projekt",
     "text": "GTK-Oberflächen für GNUnet (z. B. gnunet-fs-gtk und gnunet-setup). Im Handbuch beschrieben; "
             "das Paket gehört je nach Distribution dazu oder wird getrennt installiert."},
    {"id": "gnunet-fuse", "name": "GNUnet FUSE", "gruppe": "werkzeuge", "art": "Dateisystem", "status": "ok",
     "url": "https://git.gnunet.org/gnunet/gnunet-fuse/", "lizenz": "siehe Projekt",
     "text": "Hängt freigegebene GNUnet-Dateien als Verzeichnis ein, damit andere Programme sie wie normale "
             "Dateien lesen können."},
    {"id": "ascension", "name": "Ascension", "gruppe": "werkzeuge", "art": "Migration", "status": "ok",
     "url": "https://git.gnunet.org/gnunet/ascension/", "lizenz": "siehe Projekt",
     "text": "Wandelt bestehende DNS-Zonen in das GNU Name System um und übernimmt die Einträge."},
    {"id": "gns-registrar", "name": "GNS-Registrar", "gruppe": "werkzeuge", "art": "Registrar", "status": "prüfen",
     "url": "https://git.gnunet.org/gnunet/gnunet-gns-registrar/", "lizenz": "siehe Projekt",
     "text": "Registrar für GNS-Namen; Stand, Betriebsmodell und Sicherheitsupdates vor dem Einsatz prüfen."},

    # --- Geprüft, aber nicht als Werkzeug ---
    {"id": "alte-messenger-links", "name": "Alte Messenger-Links auf gnunet.org", "gruppe": "nicht", "art": "Veralteter Link", "status": "fremd",
     "url": "https://www.gnunet.org/en/applications.html", "lizenz": "–",
     "text": "Die Anwendungsseite verlinkt Messenger-GTK und messenger-cli noch auf git.gnunet.org/messenger-*.git; "
             "diese Pfade antworten mit 404. Die aktuellen Repositories liegen unter git.gnunet.org/gnunet/… und "
             "stehen oben."},
]


def zustand():
    return {"stand": STAND, "gruppen": [{"id": i, "name": n} for i, n in GRUPPEN],
            "tools": [dict(t) for t in TOOLS],
            "hinweis": "GNUnet ist ein eigener Netzwerk-Stack, kein Zusatz zu Tor oder I2P. H0rSt startet weder "
                       "GNUnet noch einen Messenger und lädt keine fremde Software nach; die Liste öffnet nur "
                       "geprüfte Quellen. Alpha- und Pre-Alpha-Anwendungen sind als solche markiert."}
