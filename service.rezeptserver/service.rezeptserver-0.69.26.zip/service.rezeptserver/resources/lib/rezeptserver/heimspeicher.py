"""Heimspeicher: Dateien auf ASUS AiCloud und anderen WebDAV-Speichern ansehen, abspielen und an Kodi geben.

ASUS AiCloud 2.0 ("Cloud Disk") gibt die USB-Platte am ASUS-Router per HTTPS frei: Standard-Port 443, im
Heimnetz z. B. https://router.asus.com oder https://192.168.50.1, unterwegs https://<name>.asuscomm.com (DDNS).
Angemeldet wird mit Benutzer und Passwort des Routers. Der Dienst dahinter spricht WebDAV: PROPFIND listet einen
Ordner, GET mit Range liefert eine Datei. Genauso funktionieren Nextcloud (remote.php/dav/files/<benutzer>/),
die WebDAV-Freigabe einer Synology (Port 5006) und andere WebDAV-Server.

H0rSt ruft die Speicher selbst ab; Benutzer und Passwort bleiben auf dem Server und erreichen den Browser nie.
Abgespielt wird ueber H0rSt (/api/wiedergabe/..., mit Range zum Springen), auch im App-Player und in Kodi.
Router haben meist ein selbst signiertes Zertifikat, deshalb gibt es je Speicher "zertifikat":
"pruefen" (Standard) oder "eigenes" (selbst signiertes Zertifikat annehmen; nur fuer das Heimnetz gedacht).

Nutzerdaten, Abschnitt "heimspeicher":
  [{"id", "name", "art": "aicloud"|"nextcloud"|"synology"|"webdav"|"ftp"|"verzeichnis"|"gdrive", "url", "benutzer", "passwort",
    "zertifikat"}]  (gdrive: das verbundene Konto aus gdrive.py, Adresse fest)
"""

import base64
import posixpath
import re
import secrets
import ssl
import urllib.error
import urllib.request
import xml.etree.ElementTree as ET
from email.utils import parsedate_to_datetime
from urllib.parse import quote, unquote, urlsplit

from .netz import USER_AGENT

SCHLUESSEL = "heimspeicher"
MAX_SPEICHER = 20
MAX_EINTRAEGE = 2000
ARTEN = {
    "aicloud": {"name": "ASUS AiCloud", "url": "https://router.asus.com", "zertifikat": "eigenes",
                "hinweis": "AiCloud 2.0 → Cloud Disk am Router einschalten. Anmeldung mit Benutzer und Passwort des "
                           "Routers, Port 443 (sonst :Port an die Adresse). Unterwegs https://NAME.asuscomm.com."},
    "nextcloud": {"name": "Nextcloud", "url": "https://cloud.example.org/remote.php/dav/files/BENUTZER/",
                  "zertifikat": "pruefen", "hinweis": "Am besten ein App-Passwort (Einstellungen → Sicherheit)."},
    "synology": {"name": "Synology (WebDAV)", "url": "https://diskstation:5006", "zertifikat": "eigenes",
                 "hinweis": "Paket „WebDAV Server“ installieren und HTTPS (Port 5006) einschalten."},
    "webdav": {"name": "WebDAV", "url": "https://", "zertifikat": "pruefen", "hinweis": "Jeder WebDAV-Server."},
    "ftp": {"name": "FTP", "url": "ftp://", "zertifikat": "pruefen",
            "hinweis": "FTP oder FTPS (ftps://). Ohne Benutzer anonym. Auch die FRITZ!NAS: ftp://fritz.box"},
    "gdrive": {"name": "Google Drive", "url": "https://www.googleapis.com/drive/v3", "zertifikat": "pruefen",
               "hinweis": "Erst unter Einstellungen → Trakt, MDBList & Google Drive verbinden. Zeigt den Ordner „H0rSt“ in "
                          "deinem Drive (Sicherungen und gesicherte Ordner)."},
    "verzeichnis": {"name": "Offenes Verzeichnis", "url": "https://", "zertifikat": "pruefen",
                    "hinweis": "Webseite mit Dateiliste (Apache, nginx, „Index of /“). Nur lesen."},
}
VIDEO = (".mkv", ".mp4", ".m4v", ".avi", ".mov", ".webm", ".ts", ".m2ts", ".mpg", ".mpeg", ".wmv", ".flv", ".3gp")
AUDIO = (".mp3", ".flac", ".m4a", ".aac", ".ogg", ".opus", ".wav")
BILD = (".jpg", ".jpeg", ".png", ".gif", ".webp")
_ABFRAGE = (b'<?xml version="1.0" encoding="utf-8"?><d:propfind xmlns:d="DAV:"><d:prop><d:displayname/>'
            b'<d:resourcetype/><d:getcontentlength/><d:getlastmodified/><d:getcontenttype/></d:prop></d:propfind>')


class SpeicherFehler(ValueError):
    pass


class _NichtFolgen(urllib.request.HTTPRedirectHandler):
    # Zugangsdaten nie an eine Weiterleitung geben; die Adresse soll der Nutzer richtig eintragen
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


def ssl_kontext(eigenes):
    if not eigenes:
        return ssl.create_default_context()
    kontext = ssl.create_default_context()
    kontext.check_hostname = False
    kontext.verify_mode = ssl.CERT_NONE
    return kontext


def oeffner(eigenes):
    return urllib.request.build_opener(_NichtFolgen, urllib.request.HTTPSHandler(context=ssl_kontext(eigenes)))


def pruefe(roh, alt=None):
    """Prueft die Liste; leere Passwoerter behalten den alten Wert (Oberflaeche zeigt nur "gesetzt")."""
    roh = roh or []
    if not isinstance(roh, list) or len(roh) > MAX_SPEICHER:
        raise SpeicherFehler("heimspeicher muss eine Liste mit höchstens %d Einträgen sein" % MAX_SPEICHER)
    alte = {s.get("id"): s for s in alt or [] if isinstance(s, dict)}
    ergebnis, ids = [], set()
    for s in roh:
        if not isinstance(s, dict):
            raise SpeicherFehler("Jeder Speicher ist ein Objekt")
        art = s.get("art") if s.get("art") in ARTEN else "webdav"
        sid = re.sub(r"[^a-z0-9]", "", str(s.get("id") or "").lower())[:16] or secrets.token_hex(4)
        while sid in ids:
            sid = secrets.token_hex(4)
        ids.add(sid)
        url = ARTEN["gdrive"]["url"] if art == "gdrive" else str(s.get("url") or "").strip()
        teile = urlsplit(url)
        schemata = ("ftp", "ftps") if art == "ftp" else ("http", "https")
        if teile.scheme not in schemata or not teile.hostname:
            raise SpeicherFehler("Adresse muss mit %s beginnen und einen Host haben" % " oder ".join(x + "://" for x in schemata))
        if "DEINNAME" in url or "BENUTZER" in url or teile.hostname.endswith("example.org"):
            raise SpeicherFehler("Platzhalter in der Adresse ersetzen (DEINNAME, BENUTZER …)")
        passwort = str(s.get("passwort") or "")
        if not passwort and sid in alte:
            passwort = alte[sid].get("passwort", "")
        ergebnis.append({"id": sid, "name": " ".join(str(s.get("name") or ARTEN[art]["name"]).split())[:60],
                         "art": art, "url": url.rstrip("/"), "benutzer": str(s.get("benutzer") or "")[:200],
                         "passwort": passwort[:500],
                         "zertifikat": "eigenes" if s.get("zertifikat", ARTEN[art]["zertifikat"]) == "eigenes" else "pruefen"})
    return ergebnis


def oeffentlich(speicher):
    """Fuer die Oberflaeche: ohne Passwort."""
    return [dict({k: v for k, v in s.items() if k != "passwort"}, passwort_gesetzt=bool(s.get("passwort")))
            for s in speicher]


def pfad_sauber(pfad):
    """Ordnerpfad relativ zur Speicher-Adresse; kein Ausbruch nach oben."""
    pfad = "/" + str(pfad or "").replace("\\", "/").lstrip("/")
    sauber = posixpath.normpath(pfad)
    if ".." in sauber.split("/"):
        raise SpeicherFehler("Ungültiger Pfad")
    return "/" if sauber in ("/", ".") else sauber


def _drive():
    from . import gdrive
    if gdrive.AKTIV is None:
        raise SpeicherFehler("Google Drive ist nicht verfügbar")
    return gdrive


def adresse(speicher, pfad):
    if speicher.get("art") == "gdrive":
        gdrive = _drive()
        try:
            return gdrive.AKTIV.download_adresse(pfad_sauber(pfad))
        except gdrive.DriveFehler as fehler:
            raise SpeicherFehler(str(fehler))
    return speicher["url"] + quote(pfad_sauber(pfad), safe="/")


def kopf(speicher):
    k = {"User-Agent": USER_AGENT}
    if speicher.get("art") == "gdrive":
        gdrive = _drive()
        try:
            k.update(gdrive.AKTIV.kopf())
        except gdrive.DriveFehler as fehler:
            raise SpeicherFehler(str(fehler))
        return k
    if speicher.get("benutzer") or speicher.get("passwort"):
        paar = ("%s:%s" % (speicher.get("benutzer", ""), speicher.get("passwort", ""))).encode("utf-8")
        k["Authorization"] = "Basic " + base64.b64encode(paar).decode("ascii")
    return k


def art_von(name):
    n = name.lower()
    return "video" if n.endswith(VIDEO) else "audio" if n.endswith(AUDIO) else "bild" if n.endswith(BILD) else "datei"


def _anfrage(speicher, pfad, holen=None):
    """PROPFIND Depth 1 -> (status, xml-text)."""
    url = adresse(speicher, pfad)
    if not url.endswith("/"):
        url += "/"
    k = dict(kopf(speicher), Depth="1")
    k["Content-Type"] = "application/xml; charset=utf-8"
    if holen:
        return holen(url, k, speicher.get("zertifikat") == "eigenes")
    anfrage = urllib.request.Request(url, data=_ABFRAGE, headers=k, method="PROPFIND")
    try:
        with oeffner(speicher.get("zertifikat") == "eigenes").open(anfrage, timeout=20) as a:
            return a.status, a.read(8 * 1024 * 1024).decode("utf-8", "replace")
    except urllib.error.HTTPError as fehler:
        ziel = fehler.headers.get("Location", "") if fehler.headers else ""
        fehler.close()
        return fehler.code, ziel
    except ssl.SSLCertVerificationError:
        raise SpeicherFehler("Zertifikat nicht vertrauenswürdig (selbst signiert?). Für Router im Heimnetz "
                             "„Eigenes Zertifikat annehmen“ wählen.")
    except (urllib.error.URLError, OSError) as fehler:
        grund = getattr(fehler, "reason", fehler)
        if isinstance(grund, ssl.SSLCertVerificationError):
            raise SpeicherFehler("Zertifikat nicht vertrauenswürdig (selbst signiert?). Für Router im Heimnetz "
                                 "„Eigenes Zertifikat annehmen“ wählen.")
        raise SpeicherFehler("Nicht erreichbar: %s" % str(grund)[:200])


def auflisten(speicher, pfad="/", holen=None):
    """Inhalt eines Ordners: Ordner zuerst, dann Dateien nach Name."""
    pfad = pfad_sauber(pfad)
    status, text = _anfrage(speicher, pfad, holen)
    if status in (301, 302, 303, 307, 308):
        raise SpeicherFehler("Der Speicher leitet weiter%s. Bitte die Zieladresse eintragen." % (" nach " + text if text else ""))
    if status == 401:
        hinweis = " Nach mehreren Fehlversuchen sperrt AiCloud das Konto: AiCloud 2.0 → Einstellungen → Entsperren." \
            if speicher.get("art") == "aicloud" else ""
        raise SpeicherFehler("Anmeldung abgelehnt: Benutzer oder Passwort falsch." + hinweis)
    if status == 403:
        raise SpeicherFehler("Zugriff verweigert (403)")
    if status == 404:
        raise SpeicherFehler("Ordner nicht gefunden")
    if status in (405, 501):
        raise SpeicherFehler("Kein WebDAV an dieser Adresse (%d). Bei AiCloud: Cloud Disk eingeschaltet, Port richtig?" % status)
    if status != 207:
        raise SpeicherFehler("Unerwartete Antwort: HTTP %d" % status)
    return eintraege_lesen(text, urlsplit(speicher["url"]).path, pfad)


def _zeit(text):
    try:
        return int(parsedate_to_datetime(text).timestamp()) if text else 0
    except (TypeError, ValueError, IndexError):
        return 0


def eintraege_lesen(text, basis, pfad):
    """WebDAV-Multistatus -> [{name, pfad, ordner, groesse, zeit, typ, art}] ohne den Ordner selbst."""
    try:
        wurzel = ET.fromstring(text.encode("utf-8") if isinstance(text, str) else text)
    except ET.ParseError:
        raise SpeicherFehler("Antwort ist kein WebDAV-XML")
    basis = "/" + unquote(basis or "").strip("/")
    basis = "" if basis == "/" else basis
    eigen = (basis + (pfad if pfad != "/" else "")).rstrip("/") or "/"
    eintraege = []
    for antwort in wurzel.iter("{DAV:}response"):
        href = antwort.findtext("{DAV:}href") or ""
        voll = unquote(urlsplit(href).path or href)
        if voll.rstrip("/") == eigen.rstrip("/"):
            continue  # der Ordner selbst
        props = {}
        for propstat in antwort.iter("{DAV:}propstat"):
            if "200" not in (propstat.findtext("{DAV:}status") or "200"):
                continue
            for prop in propstat.iter("{DAV:}prop"):
                props.update({kind.tag: kind for kind in prop})
        typ = props.get("{DAV:}resourcetype")
        ordner = typ is not None and typ.find("{DAV:}collection") is not None
        name = posixpath.basename(voll.rstrip("/")) or (props["{DAV:}displayname"].text if "{DAV:}displayname" in props else "")
        if not name:
            continue
        relativ = voll[len(basis):] if basis and voll.startswith(basis) else voll
        laenge = props.get("{DAV:}getcontentlength")
        geaendert = props.get("{DAV:}getlastmodified")
        inhalt = props.get("{DAV:}getcontenttype")
        eintraege.append({"name": name, "pfad": pfad_sauber(relativ), "ordner": ordner,
                          "groesse": int(laenge.text) if laenge is not None and (laenge.text or "").isdigit() else 0,
                          "zeit": _zeit(geaendert.text if geaendert is not None else ""),
                          "typ": (inhalt.text or "") if inhalt is not None else "",
                          "art": "ordner" if ordner else art_von(name)})
        if len(eintraege) >= MAX_EINTRAEGE:
            break
    eintraege.sort(key=lambda e: (not e["ordner"], e["name"].lower()))
    return eintraege


def liste(speicher, pfad="/", holen=None):
    """Ordner eines Speichers, egal welcher Art (WebDAV, FTP, offenes Verzeichnis, Google Drive)."""
    if speicher.get("art") == "gdrive":
        gdrive = _drive()
        try:
            return gdrive.AKTIV.speicher_liste(pfad_sauber(pfad))
        except gdrive.DriveFehler as fehler:
            raise SpeicherFehler(str(fehler))
    if speicher.get("art") == "ftp":
        from . import ftp
        try:
            return ftp.auflisten(speicher, pfad)
        except ftp.FtpFehler as fehler:
            raise SpeicherFehler(str(fehler))
    if speicher.get("art") == "verzeichnis":
        from . import crawler
        return crawler.verzeichnis(speicher, pfad, holen)
    return auflisten(speicher, pfad, holen)


def pruefen(speicher, holen=None):
    """Verbindungstest: Wurzel listen. Gibt (ok, meldung) zurueck."""
    try:
        eintraege = liste(speicher, "/", holen)
    except SpeicherFehler as fehler:
        return False, str(fehler)
    return True, "Verbunden, %d Einträge im obersten Ordner" % len(eintraege)
