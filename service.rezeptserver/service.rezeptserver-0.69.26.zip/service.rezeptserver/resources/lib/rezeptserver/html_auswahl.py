"""HTML lesen und mit einfachen CSS-Selektoren durchsuchen (nur Standardbibliothek).

Selektoren: tag  .klasse  #id  [attr]  [attr=wert]  [attr^=wert]  [attr$=wert]  [attr*=wert]
kombinierbar (a.titel[href]) und mit Leerzeichen (Nachfahre) oder > (direktes Kind).
"""

import re
from html.parser import HTMLParser

LEERE_TAGS = {"area", "base", "br", "col", "embed", "hr", "img", "input", "link", "meta",
              "source", "track", "wbr"}
_TEIL = re.compile(r"""
    (?P<tag>[a-zA-Z][a-zA-Z0-9\-]*|\*)
  | \#(?P<id>[\w\-]+)
  | \.(?P<klasse>[\w\-]+)
  | \[\s*(?P<attr>[\w\-:]+)\s*(?:(?P<op>[\^$*]?=)\s*(?P<wert>"[^"]*"|'[^']*'|[^\]\s]+))?\s*\]
""", re.VERBOSE)


class AuswahlFehler(ValueError):
    pass


class Knoten:
    __slots__ = ("tag", "attrs", "kinder", "eltern", "texte")

    def __init__(self, tag, attrs=None, eltern=None):
        self.tag = tag
        self.attrs = dict(attrs or {})
        self.kinder = []
        self.eltern = eltern
        self.texte = []

    def text(self):
        teile = []

        def sammle(knoten):
            for stueck in knoten.texte:
                if isinstance(stueck, Knoten):
                    sammle(stueck)
                else:
                    teile.append(stueck)

        sammle(self)
        return re.sub(r"\s+", " ", "".join(teile)).strip()

    def nachfahren(self):
        for kind in self.kinder:
            yield kind
            yield from kind.nachfahren()


class _Leser(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.wurzel = Knoten("#dokument")
        self.offen = [self.wurzel]

    def handle_starttag(self, tag, attrs):
        eltern = self.offen[-1]
        knoten = Knoten(tag, {k: (v or "") for k, v in attrs}, eltern)
        eltern.kinder.append(knoten)
        eltern.texte.append(knoten)
        if tag not in LEERE_TAGS:
            self.offen.append(knoten)

    def handle_startendtag(self, tag, attrs):
        self.handle_starttag(tag, attrs)
        if tag not in LEERE_TAGS:
            self.offen.pop()

    def handle_endtag(self, tag):
        # nicht geschlossene Tags dazwischen werden mitgeschlossen
        for i in range(len(self.offen) - 1, 0, -1):
            if self.offen[i].tag == tag:
                del self.offen[i:]
                return

    def handle_data(self, data):
        self.offen[-1].texte.append(data)


def lese(text):
    leser = _Leser()
    leser.feed(text or "")
    leser.close()
    return leser.wurzel


def _zerlege_einfach(teil):
    bedingungen = []
    pos = 0
    while pos < len(teil):
        treffer = _TEIL.match(teil, pos)
        if not treffer or treffer.end() == pos:
            raise AuswahlFehler("Selektor nicht verstanden: %s" % teil)
        g = treffer.groupdict()
        if g["tag"]:
            if g["tag"] != "*":
                bedingungen.append(("tag", g["tag"].lower()))
        elif g["id"]:
            bedingungen.append(("id", g["id"]))
        elif g["klasse"]:
            bedingungen.append(("klasse", g["klasse"]))
        else:
            wert = g["wert"]
            if wert and wert[0] in "'\"":
                wert = wert[1:-1]
            bedingungen.append(("attr", g["attr"].lower(), g["op"], wert))
        pos = treffer.end()
    return bedingungen


def zerlege(selektor):
    """Liste von (verbindung, bedingungen); verbindung ist ' ' oder '>'."""
    if not isinstance(selektor, str) or not selektor.strip():
        raise AuswahlFehler("Leerer Selektor")
    stuecke = re.sub(r"\s*>\s*", " > ", selektor.strip()).split()
    kette = []
    verbindung = " "
    for stueck in stuecke:
        if stueck == ">":
            verbindung = ">"
            continue
        kette.append((verbindung, _zerlege_einfach(stueck)))
        verbindung = " "
    return kette


def _passt(knoten, bedingungen):
    for b in bedingungen:
        if b[0] == "tag" and knoten.tag != b[1]:
            return False
        if b[0] == "id" and knoten.attrs.get("id") != b[1]:
            return False
        if b[0] == "klasse" and b[1] not in knoten.attrs.get("class", "").split():
            return False
        if b[0] == "attr":
            _, name, op, wert = b
            if name not in knoten.attrs:
                return False
            ist = knoten.attrs[name]
            if op == "=" and ist != wert:
                return False
            if op == "^=" and not ist.startswith(wert):
                return False
            if op == "$=" and not ist.endswith(wert):
                return False
            if op == "*=" and wert not in ist:
                return False
    return True


def _pruefe(knoten, kette, grenze):
    # kette[-1] passt bereits auf knoten; die Verbindung von kette[-1] bestimmt den Weg nach oben
    if len(kette) == 1:
        return True
    verbindung = kette[-1][0]
    vorne = kette[:-1]
    eltern = knoten.eltern
    while eltern is not None and eltern is not grenze:
        if _passt(eltern, vorne[-1][1]) and _pruefe(eltern, vorne, grenze):
            return True
        if verbindung == ">":
            return False
        eltern = eltern.eltern
    return False


def waehle(wurzel, selektor):
    kette = zerlege(selektor)
    return [k for k in wurzel.nachfahren() if _passt(k, kette[-1][1]) and _pruefe(k, kette, wurzel)]


def wert(knoten, angabe):
    """angabe: 'selektor', 'selektor@attr', '@attr' oder '' (Text des Knotens selbst)."""
    selektor, _, attr = (angabe or "").partition("@")
    ziel = knoten
    if selektor.strip():
        gefunden = waehle(knoten, selektor)
        if not gefunden:
            return None
        ziel = gefunden[0]
    if attr:
        return ziel.attrs.get(attr.lower())
    return ziel.text()
