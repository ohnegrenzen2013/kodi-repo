"""Licht: Philips Hue ueber die Bridge im Heimnetz (lokale API, ohne Cloud).

  * Bridge finden: discovery.meethue.com (fragt Philips nach Bridges im selben Anschluss) oder IP von Hand.
  * Koppeln: Knopf auf der Bridge druecken, dann "Koppeln" – die Bridge gibt H0rSt einen eigenen Benutzer.
  * Raeume (Gruppen) und Lampen: an/aus, Helligkeit, Farbtemperatur, Szenen; alles aus.
Nutzerdaten "hue": {"bridge": "192.168.178.30", "benutzer": "..."}
"""

import json
import re
import urllib.error
import urllib.request

from .netz import USER_AGENT

SCHLUESSEL = "hue"
SUCHE = "https://discovery.meethue.com/"
_IP = re.compile(r"^[\w.-]{1,100}(:\d{1,5})?$")


class HueFehler(ValueError):
    pass


def pruefe(roh):
    e = {"bridge": "", "benutzer": ""}
    if isinstance(roh, dict):
        e["bridge"] = str(roh.get("bridge") or "").strip()[:100]
        e["benutzer"] = re.sub(r"[^\w-]", "", str(roh.get("benutzer") or ""))[:80]
    if e["bridge"] and not _IP.match(e["bridge"]):
        raise HueFehler("Bridge-Adresse ungültig")
    return e


def _http(url, methode="GET", daten=None, holen=None, zeit=8):
    if holen:
        return holen(url, methode, daten)
    koerper = json.dumps(daten).encode("utf-8") if daten is not None else None
    anfrage = urllib.request.Request(url, data=koerper, method=methode,
                                     headers={"User-Agent": USER_AGENT, "Content-Type": "application/json"})
    try:
        with urllib.request.urlopen(anfrage, timeout=zeit) as a:
            return json.loads(a.read(4 * 1024 * 1024).decode("utf-8", "replace") or "null")
    except urllib.error.HTTPError as fehler:
        fehler.close()
        raise HueFehler("Hue-Bridge: HTTP %d" % fehler.code)
    except (urllib.error.URLError, OSError, ValueError) as fehler:
        raise HueFehler("Hue-Bridge nicht erreichbar: %s" % getattr(fehler, "reason", fehler))


def suchen(holen=None):
    """Bridges im selben Anschluss: [{"id", "ip"}]."""
    antwort = _http(SUCHE, holen=holen, zeit=10)
    return [{"id": str(b.get("id", "")), "ip": str(b.get("internalipaddress", ""))}
            for b in antwort if isinstance(b, dict) and b.get("internalipaddress")] if isinstance(antwort, list) else []


def _fehler(antwort):
    if isinstance(antwort, list) and antwort and isinstance(antwort[0], dict) and "error" in antwort[0]:
        f = antwort[0]["error"]
        if f.get("type") == 1:
            raise HueFehler("Bridge kennt H0rSt nicht mehr – neu koppeln")
        raise HueFehler("Hue: %s" % f.get("description", "Fehler"))
    return antwort


def koppeln(bridge, holen=None):
    """Nach Knopfdruck auf der Bridge: neuer Benutzer fuer H0rSt."""
    antwort = _http("http://%s/api" % bridge, "POST", {"devicetype": "h0rst#server"}, holen)
    if isinstance(antwort, list) and antwort and isinstance(antwort[0], dict):
        if "success" in antwort[0]:
            return antwort[0]["success"]["username"]
        if antwort[0].get("error", {}).get("type") == 101:
            raise HueFehler("Erst den runden Knopf auf der Hue-Bridge drücken, dann innerhalb von 30 Sekunden „Koppeln“")
    _fehler(antwort)
    raise HueFehler("Bridge antwortet unerwartet")


class Hue:
    def __init__(self, einstellung, holen=None):
        self.e = pruefe(einstellung)
        self.holen = holen

    @property
    def bereit(self):
        return bool(self.e["bridge"] and self.e["benutzer"])

    def _api(self, pfad, methode="GET", daten=None):
        if not self.bereit:
            raise HueFehler("Erst eine Hue-Bridge koppeln")
        return _fehler(_http("http://%s/api/%s%s" % (self.e["bridge"], self.e["benutzer"], pfad), methode, daten, self.holen))

    def zustand(self):
        lampen = self._api("/lights") or {}
        gruppen = self._api("/groups") or {}
        szenen = self._api("/scenes") or {}
        raeume = []
        for gid, g in sorted(gruppen.items(), key=lambda x: str(x[1].get("name", ""))):
            if g.get("type") not in ("Room", "Zone", "Entertainment") and not g.get("lights"):
                continue
            raeume.append({"id": gid, "name": g.get("name", gid), "art": g.get("type", ""),
                           "an": bool((g.get("state") or {}).get("any_on")), "alle_an": bool((g.get("state") or {}).get("all_on")),
                           "hell": int((g.get("action") or {}).get("bri") or 0), "lampen": list(g.get("lights") or []),
                           "szenen": [{"id": sid, "name": sz.get("name", sid)} for sid, sz in szenen.items()
                                      if sz.get("group") == gid]})
        return {"raeume": raeume, "lampen": [
            {"id": lid, "name": l.get("name", lid), "an": bool((l.get("state") or {}).get("on")),
             "hell": int((l.get("state") or {}).get("bri") or 0), "erreichbar": (l.get("state") or {}).get("reachable", True),
             "farbtemp": "ct" in (l.get("state") or {}), "farbe": "xy" in (l.get("state") or {}), "typ": l.get("type", "")}
            for lid, l in sorted(lampen.items(), key=lambda x: str(x[1].get("name", "")))]}

    def schalten(self, art, kennung, an=None, hell=None, farbtemp=None, szene=None):
        """art "raum" oder "lampe"; hell 1-254, farbtemp 153 (kalt) bis 500 (warm), szene: Szenen-ID (nur Raum)."""
        if art not in ("raum", "lampe") or not re.match(r"^[\w-]{1,40}$", str(kennung)):
            raise HueFehler("Unbekanntes Licht")
        daten = {}
        if an is not None:
            daten["on"] = bool(an)
        if hell is not None:
            daten["bri"] = max(1, min(254, int(hell)))
            daten.setdefault("on", True)
        if farbtemp is not None:
            daten["ct"] = max(153, min(500, int(farbtemp)))
        if szene:
            if art != "raum":
                raise HueFehler("Szenen gibt es nur für Räume")
            daten = {"scene": str(szene)}
        if not daten:
            raise HueFehler("Nichts zu tun")
        pfad = "/groups/%s/action" % kennung if art == "raum" else "/lights/%s/state" % kennung
        return self._api(pfad, "PUT", daten)

    def alle(self, an):
        """Gruppe 0 = alle Lampen."""
        return self._api("/groups/0/action", "PUT", {"on": bool(an)})
