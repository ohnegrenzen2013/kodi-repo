"""IP-Filter (Bereich "Sicherheit"): Sperrlisten wie bei eMule und qBittorrent, auswaehlbar.

Ausgewaehlte Listen (Katalog unten, eigene Adressen, hochgeladene Dateien) werden geladen, zu sortierten
IPv4-Bereichen zusammengefuehrt und taeglich erneuert. Gesperrt wird dort, wo H0rSt mit fremden Rechnern im
P2P-Netz spricht: eD2K-Server, Kad-Knoten (nodes.dat) und DHT-Knoten und -Peers. Auf Wunsch auch Zugriffe von
aussen auf H0rSt selbst. Normale Verbindungen (Indexer, Hoster, Addons) prueft der Filter nicht – manche Listen
sperren ganze Rechenzentren (z. B. Cloudflare-Bereiche), das wuerde dort mehr kaputt machen als schuetzen.
Das Heimnetz (private Adressen, localhost) wird nie gesperrt.

Formate (erkannt am Inhalt, auch .gz und .zip):
  * eMule ipfilter.dat:  000.000.000.000 - 000.255.255.255 , 000 , Beschreibung   (Stufe >= 128 = erlaubt)
  * P2P/PeerGuardian:    Beschreibung:1.2.3.0-1.2.3.255
  * CIDR/netset:         1.2.3.0/24 ; Kommentar   (FireHOL, Spamhaus DROP, einzelne Adressen)

Die zusammengefuehrte Liste gibt es als ipfilter.dat (GET /api/ipfilter/ipfilter.dat) fuer eMule, Ember oder
qBittorrent. Einstellungen in den Nutzerdaten unter "ipfilter": {"listen": [ids], "eigene": [{name, url}],
"eingehend": bool}; geladene Listen liegen im Datenordner unter ipfilter/.
"""

from .ipfilter_grund import *
from .ipfilter_grund import _BEREICH, _CIDR, _DAT, _FIREHOL, _IBL, _P2P, _id_eigen, _url
from .ipfilter_bereiche import entpacken, lesen, zusammenfuehren, _heimnetz, _ip, _zahl


class Filter:
    """Unveraenderliche Sperrliste mit schneller Abfrage (bisect)."""

    def __init__(self, bereiche=()):
        self.anf, self.end = zusammenfuehren(bereiche)

    def __len__(self):
        return len(self.anf)

    def adressen(self):
        return sum(b - a + 1 for a, b in zip(self.anf, self.end))

    def gesperrt(self, ip):
        ip = str(ip or "").strip("[]")
        if ip.startswith("::ffff:"):
            ip = ip[7:]
        if not self.anf or ":" in ip or _heimnetz(ip):
            return False
        try:
            z = _zahl(ip.encode("ascii"))
        except (ValueError, UnicodeEncodeError):
            return False
        i = bisect.bisect_right(self.anf, z) - 1
        return i >= 0 and z <= self.end[i]

    def als_dat(self):
        """eMule-Format, fuer eMule, Ember und qBittorrent."""
        return "".join("%s - %s , 000 , H0rSt\n" % (_ip(a), _ip(b)) for a, b in zip(self.anf, self.end)).encode("ascii")


AKTIV = Filter()


EINGEHEND = False


def gesperrt(ip):
    """Fuer P2P (eD2K, Kad, DHT): True, wenn die Adresse auf einer gewaehlten Sperrliste steht."""
    return AKTIV.gesperrt(ip)


def eingehend_gesperrt(ip):
    """Fuer Zugriffe auf H0rSt: nur, wenn "auch von aussen pruefen" an ist."""
    return EINGEHEND and AKTIV.gesperrt(ip)


class Verwaltung:
    """Laedt, speichert und erneuert die gewaehlten Listen; setzt den aktiven Filter."""

    def __init__(self, datenordner, holen=None, uhr=time.time):
        self.ordner = os.path.join(datenordner or ".", ORDNER)
        self.holen = holen
        self.uhr = uhr
        self._sperre = threading.RLock()
        self._laeuft = False
        self.hintergrund = True  # False: Laden und Bauen sofort (Tests)
        self.einstellung = dict(STANDARD)

    # Dateien: <id>.bin (Bereiche als Zahlenpaare), meta.json ({id: {zeit, anzahl, fehler, quelle}})
    def _meta(self):
        try:
            with open(os.path.join(self.ordner, "meta.json"), encoding="utf-8") as f:
                d = json.load(f)
            return d if isinstance(d, dict) else {}
        except (OSError, ValueError):
            return {}

    def _meta_setzen(self, lid, werte):
        meta = self._meta()
        meta[lid] = dict(meta.get(lid) or {}, **werte)
        os.makedirs(self.ordner, exist_ok=True)
        with open(os.path.join(self.ordner, "meta.json.neu"), "w", encoding="utf-8") as f:
            json.dump(meta, f)
        os.replace(os.path.join(self.ordner, "meta.json.neu"), os.path.join(self.ordner, "meta.json"))

    def _speichern(self, lid, bereiche):
        anf, end = zusammenfuehren(bereiche)
        paare = array.array("I")
        for a, b in zip(anf, end):
            paare.extend((a, b))
        os.makedirs(self.ordner, exist_ok=True)
        pfad = os.path.join(self.ordner, lid + ".bin")
        with open(pfad + ".neu", "wb") as f:
            f.write(json.dumps({"itemsize": paare.itemsize}).encode("ascii") + b"\n")
            f.write(paare.tobytes())
        os.replace(pfad + ".neu", pfad)
        return len(anf)

    def _bereiche(self, lid):
        try:
            with open(os.path.join(self.ordner, lid + ".bin"), "rb") as f:
                kopf = json.loads(f.readline())
                roh = f.read()
        except (OSError, ValueError):
            return []
        paare = array.array("I")
        if kopf.get("itemsize") != paare.itemsize:  # anderer Rechner (32/64 Bit): neu laden lassen
            return []
        paare.frombytes(roh[:len(roh) - len(roh) % (2 * paare.itemsize)])
        return list(zip(paare[0::2], paare[1::2]))

    def quellen(self):
        """[(id, name, url)] aller gewaehlten Listen; hochgeladene Datei zuletzt (ohne Adresse)."""
        e = self.einstellung
        q = [(lid, KATALOG[lid][0], KATALOG[lid][1]) for lid in e["listen"]]
        q += [(_id_eigen(x["url"]), x["name"], x["url"]) for x in e["eigene"]]
        if os.path.isfile(os.path.join(self.ordner, "hochgeladen.bin")):
            q.append(("hochgeladen", "Hochgeladene Liste", ""))
        return q

    def anwenden(self, einstellung, warten=True):
        """Einstellungen uebernehmen, Filter aus den gespeicherten Listen bauen, Veraltetes im Hintergrund holen.
        warten=False (Start von H0rSt): auch das Bauen laeuft im Hintergrund, bis dahin gilt der alte Filter."""
        global EINGEHEND
        self.einstellung = pruefe(einstellung)
        EINGEHEND = self.einstellung["eingehend"]
        if not warten and self.hintergrund:
            threading.Thread(target=self._bauen, args=(True,), name="ipfilter-bauen", daemon=True).start()
            return AKTIV
        return self._bauen()

    def _bauen(self, nachladen=True):
        global AKTIV
        with self._sperre:  # nacheinander, damit kein aelterer Stand einen neueren ueberschreibt
            bereiche = []
            for lid, _, _ in self.quellen():
                bereiche += self._bereiche(lid)
            AKTIV = Filter(bereiche)
        if nachladen and self._veraltet():
            self.im_hintergrund()
        return AKTIV

    def _faellig(self, m):
        """Aelter als einen Tag und kein Fehlversuch in der letzten Stunde."""
        return self.uhr() - m.get("zeit", 0) > ERNEUERN and self.uhr() - m.get("versuch", 0) > 3600

    def _veraltet(self):
        meta = self._meta()
        return any(url and self._faellig(meta.get(lid) or {}) for lid, _, url in self.quellen())

    def _laden(self, url):
        if self.holen:
            return self.holen(url)
        anfrage = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
        with urllib.request.urlopen(anfrage, timeout=60) as a:
            roh = a.read(MAX_DATEI + 1)
        if len(roh) > MAX_DATEI:
            raise FilterFehler("Liste zu groß")
        return roh

    def aktualisieren(self, alle=True):
        """Gewaehlte Listen laden (alle oder nur veraltete); Fehler bleiben je Liste stehen. Gibt den Stand zurueck."""
        with self._sperre:
            meta = self._meta()
            for lid, name, url in self.quellen():
                if not url or (not alle and not self._faellig(meta.get(lid) or {})):
                    continue
                try:
                    anzahl = self._speichern(lid, lesen(self._laden(url)))
                    self._meta_setzen(lid, {"zeit": int(self.uhr()), "anzahl": anzahl, "fehler": ""})
                except Exception as fehler:  # Netz, Format, Platte: die alte Fassung bleibt
                    log.info("IP-Filter %s: %s", name, fehler)
                    self._meta_setzen(lid, {"fehler": str(fehler)[:200], "versuch": int(self.uhr())})
            self._bauen(nachladen=False)
        return self.stand()

    def im_hintergrund(self, alle=False):
        if not self.hintergrund:
            self.aktualisieren(alle=alle)
            return
        if self._laeuft:
            return
        self._laeuft = True

        def lauf():
            try:
                self.aktualisieren(alle=alle)
            finally:
                self._laeuft = False
        threading.Thread(target=lauf, name="ipfilter", daemon=True).start()

    def hochladen(self, roh):
        """Eigene Liste (Datei) als "Hochgeladene Liste" – bleibt, bis sie ersetzt oder entfernt wird."""
        with self._sperre:
            anzahl = self._speichern("hochgeladen", lesen(roh))
            self._meta_setzen("hochgeladen", {"zeit": int(self.uhr()), "anzahl": anzahl, "fehler": ""})
        self.anwenden(self.einstellung)
        return self.stand()

    def hochgeladen_entfernen(self):
        try:
            os.remove(os.path.join(self.ordner, "hochgeladen.bin"))
        except OSError:
            pass
        self.anwenden(self.einstellung)
        return self.stand()

    def stand(self):
        meta = self._meta()
        listen = []
        for lid, name, url in self.quellen():
            m = meta.get(lid) or {}
            listen.append({"id": lid, "name": name, "url": url, "anzahl": m.get("anzahl", 0),
                           "zeit": m.get("zeit", 0), "fehler": m.get("fehler", "")})
        return {"einstellung": self.einstellung, "listen": listen, "bereiche": len(AKTIV), "adressen": AKTIV.adressen(),
                "laedt": self._laeuft,
                "katalog": [{"id": k, "name": v[0], "url": v[1], "text": v[2]} for k, v in KATALOG.items()]}

    def aendern(self, daten, wunsch):
        """Aenderung an den Nutzerdaten (unter "ipfilter"): {listen: [ids]} | {eigene_dazu: {name, url}} |
        {eigene_weg: url} | {eingehend: bool}. Gibt die neue Einstellung zurueck."""
        if not isinstance(wunsch, dict):
            raise FilterFehler("JSON-Objekt erwartet")
        e = pruefe(daten.get(SCHLUESSEL))
        if "listen" in wunsch:
            if not isinstance(wunsch["listen"], list) or any(x not in KATALOG for x in wunsch["listen"]):
                raise FilterFehler("Unbekannte Liste")
            e["listen"] = [x for x in KATALOG if x in wunsch["listen"]]
        if "eigene_dazu" in wunsch:
            x = wunsch["eigene_dazu"] if isinstance(wunsch["eigene_dazu"], dict) else {}
            url = _url(x.get("url"))
            if len(e["eigene"]) >= MAX_EIGENE:
                raise FilterFehler("Höchstens %d eigene Listen" % MAX_EIGENE)
            e["eigene"] = [y for y in e["eigene"] if y["url"] != url] + [{"name": x.get("name") or "", "url": url}]
        if "eigene_weg" in wunsch:
            e["eigene"] = [y for y in e["eigene"] if y["url"] != str(wunsch["eigene_weg"])]
        if "eingehend" in wunsch:
            e["eingehend"] = wunsch["eingehend"] is True
        e = pruefe(e)
        daten[SCHLUESSEL] = e
        return e
