"""IP-Filter: Sperrlisten-Bereiche: IPv4 in Zahlen, entpacken/lesen (eMule, P2P, CIDR; gz/zip) und zusammenfuehren."""

from .archiv import GZIP_FEHLER, ZIP_FEHLER
from .ipfilter_grund import (
    FilterFehler,
    MAX_DATEI,
    _BEREICH,
    _CIDR,
    _DAT,
    _P2P,
    array,
    gzip,
    io,
    ipaddress,
    zipfile,
)

def _zahl(ip):
    """IPv4 als Zahl; fuehrende Nullen (001.002.003.004) wie bei eMule erlaubt."""
    teile = ip.split(b".")
    werte = [int(t) for t in teile]
    if len(werte) != 4 or any(w > 255 for w in werte):
        raise ValueError(ip)
    return (werte[0] << 24) | (werte[1] << 16) | (werte[2] << 8) | werte[3]


def _ip(zahl):
    return "%d.%d.%d.%d" % (zahl >> 24, (zahl >> 16) & 255, (zahl >> 8) & 255, zahl & 255)


def entpacken(roh):
    """gzip und zip (erste Liste im Archiv) auspacken, sonst unveraendert."""
    if roh[:2] == b"\x1f\x8b":
        try:
            with gzip.GzipFile(fileobj=io.BytesIO(roh)) as g:
                roh = g.read(MAX_DATEI + 1)
        except GZIP_FEHLER as fehler:  # BadGzipFile ist ein OSError
            raise FilterFehler("Kaputtes gzip: %s" % fehler)
    elif roh[:4] == b"PK\x03\x04":
        try:
            with zipfile.ZipFile(io.BytesIO(roh)) as z:
                namen = [n for n in z.namelist() if not n.endswith("/")]
                name = next((n for n in namen if n.lower().endswith((".dat", ".p2p", ".txt", ".netset"))), namen[0] if namen else None)
                if not name:
                    raise FilterFehler("Leeres ZIP")
                with z.open(name) as f:
                    roh = f.read(MAX_DATEI + 1)
        except FilterFehler:
            raise
        except ZIP_FEHLER as fehler:
            raise FilterFehler("Kaputtes ZIP: %s" % fehler)
    if len(roh) > MAX_DATEI:
        raise FilterFehler("Liste zu groß")
    return roh


def lesen(roh):
    """Bytes einer Liste (beliebiges Format) -> [(anfang, ende)] als Zahlen, unsortiert."""
    roh = entpacken(roh)
    bereiche = []
    for zeile in roh.splitlines():
        if not zeile.strip() or zeile.lstrip()[:1] in (b"#", b";", b"/"):
            continue
        try:
            m = _DAT.match(zeile)
            if m:
                if int(m.group(3)) >= 128:  # eMule: Stufe ab 128 ist erlaubt
                    continue
                a, b = _zahl(m.group(1)), _zahl(m.group(2))
            else:
                m = _P2P.search(zeile) or _BEREICH.match(zeile)
                if m:
                    a, b = _zahl(m.group(1)), _zahl(m.group(2))
                else:
                    m = _CIDR.match(zeile)
                    if not m:
                        continue
                    a = _zahl(m.group(1))
                    laenge = int(m.group(2)) if m.group(2) else 32
                    if laenge > 32:
                        continue
                    maske = (0xFFFFFFFF << (32 - laenge)) & 0xFFFFFFFF
                    a &= maske
                    b = a | (~maske & 0xFFFFFFFF)
        except ValueError:
            continue
        if a <= b:
            bereiche.append((a, b))
    if not bereiche:
        raise FilterFehler("Keine IP-Bereiche erkannt (ipfilter.dat, P2P oder CIDR)")
    return bereiche


def zusammenfuehren(bereiche):
    """Sortieren und Ueberlappendes/Angrenzendes verbinden -> (anfaenge, enden) als array("I")."""
    anf, end = array.array("I"), array.array("I")
    for a, b in sorted(bereiche):
        if end and a <= end[-1] + 1:
            if b > end[-1]:
                end[-1] = b
        else:
            anf.append(a)
            end.append(b)
    return anf, end


def _heimnetz(ip):
    try:
        x = ipaddress.ip_address(ip)
    except ValueError:
        return True  # kein IPv4/IPv6 (Name): hier nicht zu entscheiden
    return x.is_private or x.is_loopback or x.is_link_local or x.is_unspecified


