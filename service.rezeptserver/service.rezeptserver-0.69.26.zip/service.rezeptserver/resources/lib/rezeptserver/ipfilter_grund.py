"""IP-Filter: Grundlage: Importe, Konstanten (KATALOG, STANDARD ...), FilterFehler und die Einstellungs-Helfer _url, pruefe, _id_eigen."""


import array
import bisect
import gzip
import io
import ipaddress
import json
import logging
import os
import re
import threading
import time
import urllib.request
import zipfile

from .netz import USER_AGENT

log = logging.getLogger("rezeptserver")

SCHLUESSEL = "ipfilter"
ORDNER = "ipfilter"
ERNEUERN = 24 * 3600
MAX_DATEI = 48 * 1024 * 1024  # entpackt
MAX_EIGENE = 10
_IBL = "https://list.iblocklist.com/?list=%s&fileformat=p2p&archiveformat=gz"
_FIREHOL = "https://raw.githubusercontent.com/firehol/blocklist-ipsets/master/%s.netset"
# id: (Name, Adresse, Beschreibung)
KATALOG = {
    "emule": ("eMule Security (guarding.p2p)", "http://upd.emule-security.org/ipfilter.zip",
              "Die Liste von eMule: Anti-P2P-Firmen, Spione, Fake-Server, Bots. Täglich erneuert, rund 3 MB."),
    "level1": ("Level 1 (iBlocklist/Bluetack)", _IBL % "ydxerpxkpcfqjaybcssw",
               "Der Klassiker aus qBittorrent und PeerBlock: Anti-P2P, Überwacher, Bots. Rund 3,5 MB."),
    "werbung": ("Werbung & Tracker (iBlocklist)", _IBL % "dgxtneitpuvgqqcpfulq",
                "Werbe- und Tracking-Server, klein."),
    "davidmoore": ("ipfilter (DavidMoore, gesammelt)", "https://github.com/DavidMoore/ipfilter/releases/download/lists/ipfilter.dat.gz",
                   "Täglich zusammengeführt aus mehreren Listen, bereit für qBittorrent. Rund 2,5 MB."),
    "firehol1": ("FireHOL Level 1", _FIREHOL % "firehol_level1",
                 "Angreifer, Botnetze, gekaperte Netze – wenig Fehlalarme. Klein."),
    "firehol2": ("FireHOL Level 2", _FIREHOL % "firehol_level2",
                 "Aktuelle Angriffe der letzten 48 Stunden, ergänzt Level 1."),
    "spamhaus": ("Spamhaus DROP", "https://www.spamhaus.org/drop/drop.txt",
                 "Gekaperte und kriminelle Netze, sehr klein, keine Fehlalarme."),
}
STANDARD = {"listen": [], "eigene": [], "eingehend": False}

_DAT = re.compile(rb"^\s*(\d{1,3}(?:\.\d{1,3}){3})\s*-\s*(\d{1,3}(?:\.\d{1,3}){3})\s*,\s*(\d+)")
_P2P = re.compile(rb":\s*(\d{1,3}(?:\.\d{1,3}){3})\s*-\s*(\d{1,3}(?:\.\d{1,3}){3})\s*$")
_CIDR = re.compile(rb"^\s*(\d{1,3}(?:\.\d{1,3}){3})(?:/(\d{1,2}))?\s*(?:[;#].*)?$")
_BEREICH = re.compile(rb"^\s*(\d{1,3}(?:\.\d{1,3}){3})\s*-\s*(\d{1,3}(?:\.\d{1,3}){3})\s*(?:[;#].*)?$")


class FilterFehler(ValueError):
    pass


# --- Einstellungen ----------------------------------------------------------------------------
def _url(url):
    url = str(url or "").strip()
    if not re.match(r"^https?://[^\s/]+", url):
        raise FilterFehler("Adresse mit http(s)://")
    return url[:1000]


def pruefe(roh):
    roh = roh if isinstance(roh, dict) else {}
    e = {"listen": [x for x in KATALOG if x in (roh.get("listen") or [])], "eigene": [], "eingehend": roh.get("eingehend") is True}
    for x in (roh.get("eigene") or [])[:MAX_EIGENE]:
        try:
            url = _url((x or {}).get("url"))
        except (FilterFehler, AttributeError):
            continue
        if all(y["url"] != url for y in e["eigene"]):
            e["eigene"].append({"name": " ".join(str(x.get("name") or "").split())[:60] or url.split("/")[2], "url": url})
    return e


def _id_eigen(url):
    import hashlib
    return "eigen-" + hashlib.sha1(url.encode("utf-8")).hexdigest()[:10]
