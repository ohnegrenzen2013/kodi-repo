"""Mitschnitt (Catch-up) nur, wenn die Playlist ihn selbst ausweist.

Vorbild ist ARVIOs Xtream-Timeshift (web/lib/iptv.ts, buildXtreamCatchupUrl): eine laufende
Sendung ist kein Mitschnitt, und ohne Archiv-Angabe des Anbieters wird keine Adresse erfunden.
Zusaetzlich, wenn die M3U eine catchup-source-Vorlage mit Platzhaltern mitliefert, wird die
benutzt — die ist genauer als die geratene Timeshift-Adresse. H0rSt selbst speichert keine
Sendungen; die offiziellen Sender bleiben ohne Archiv (tv_archive 0).
"""

import re
import time
from urllib.parse import quote, unquote, urljoin

_TAGE_SCHLUESSEL = ("catchup-days", "timeshift", "tvg-rec")
_AUS = {"", "0", "false", "none", "off", "no"}
_XTREAM = re.compile(
    r"^(?P<basis>https?://[^/?#]+)/live/(?P<user>[^/]+)/(?P<pw>[^/]+)/(?P<sid>\d{1,10})"
    r"(?:\.[A-Za-z0-9]{1,8})?(?:\?[^#]*)?$")
_TOKEN = re.compile(r"\$\{([a-z]+)\}|\{([a-z]+)\}")
_MAX_TAGE = 14


def _an(text):
    return str(text or "").strip().lower() not in _AUS


def tage_von(attribute):
    """Archiv-Tage aus den M3U-Attributen, 0 wenn der Anbieter keins nennt. Hoechstens 14."""
    attr = attribute or {}
    for schluessel in _TAGE_SCHLUESSEL:
        roh = str(attr.get(schluessel) or "").strip()
        if roh.isdigit() and int(roh) > 0:
            return min(int(roh), _MAX_TAGE)
    if _an(attr.get("catchup")) or _an(attr.get("catchup-source")):
        return 1
    return 0


def _werte(beginn, ende, jetzt):
    return {"utc": int(beginn), "start": int(beginn), "timestamp": int(beginn),
            "utcend": int(ende), "end": int(ende),
            "duration": int(round(ende - beginn)), "offset": int(max(0, jetzt - beginn))}


def _vorlage(vorlage, url, werte):
    def einsetzen(treffer):
        name = treffer.group(1) or treffer.group(2)
        return str(werte[name]) if name in werte else treffer.group(0)
    if not _TOKEN.search(vorlage):
        return None
    neu = _TOKEN.sub(einsetzen, vorlage)
    if _TOKEN.search(neu):
        return None
    if not neu.lower().startswith(("http://", "https://")):
        neu = urljoin(url, neu)
    return neu if neu.lower().startswith(("http://", "https://")) else None


def _xtream(url, beginn, ende):
    treffer = _XTREAM.match(str(url or "").strip())
    if not treffer:
        return None
    minuten = max(1, int(round((ende - beginn) / 60.0)))
    if minuten > 12 * 60:
        return None
    stempel = time.strftime("%Y-%m-%d:%H-%M", time.localtime(beginn))
    user = quote(unquote(treffer.group("user")), safe="")
    pw = quote(unquote(treffer.group("pw")), safe="")
    return "%s/timeshift/%s/%s/%d/%s/%s.m3u8" % (treffer.group("basis"), user, pw, minuten, stempel, treffer.group("sid"))


def mitschnitt_url(attribute, url, beginn, ende, jetzt=None):
    """Adresse einer beendeten Sendung, oder None. jetzt/beginn/ende sind Unix-Sekunden."""
    try:
        beginn, ende = float(beginn), float(ende)
    except (TypeError, ValueError):
        return None
    tage = tage_von(attribute)
    if tage <= 0 or not (ende > beginn):
        return None
    jetzt = time.time() if jetzt is None else float(jetzt)
    # nur beendete Sendungen im ausgewiesenen Fenster (ARVIO: end <= now und nicht aelter als die Tage)
    if ende > jetzt or beginn < jetzt - tage * 86400:
        return None
    werte = _werte(beginn, ende, jetzt)
    vorlage = str((attribute or {}).get("catchup-source") or "").strip()
    if vorlage:
        # Der Anbieter hat eine Vorlage genannt. Eine geratene Timeshift-Adresse waere eine andere Quelle.
        return _vorlage(vorlage, url, werte)
    return _xtream(url, beginn, ende)
