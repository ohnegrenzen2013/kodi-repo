"""IPTV-Quellen: freie Senderlisten, Dispatcharr und eine schonende M3U-Diagnose.

Vorbilder: Zaman-Topu/Ip-tv-Collection (taeglich gepruegte M3U- und EPG-Dateien, MIT),
Dispatcharr/Dispatcharr (IPTV-Verwaltung mit /output/m3u und /output/epg, AGPL-3.0),
davidchiu66/IPTV_Ultimate_Player_Codex (M3U/M3U8/TXT/JSON-Diagnose, GPL-3.0) und
namandhakad712/iptv-stream (schlichter Web-Player, MIT).

H0rSt laedt keine fremden Sender in die eigene Oberflaeche, sondern zeigt die Quellen,
prueft eine Liste auf Kopfdaten, Doppel und kaputte Zeilen und uebernimmt eine Liste
erst nach einem Klick in die eigenen Live-TV-Listen. Zugangsdaten bleiben lokal.
"""

import json
import re
import urllib.request
from urllib.parse import urlsplit

from .netz import USER_AGENT

NAME = "IPTV-Quellen"
DISPATCHARR = "http://127.0.0.1:9191"
LIZENZEN = {"bug": "MIT", "michaz": "keine Lizenzdatei", "dispatcharr": "AGPL-3.0",
            "player": "GPL-3.0-or-later", "stream": "MIT"}
MAX_LISTE = 8 * 1024 * 1024
_ATTR = re.compile(r"""([\w-]+)\s*=\s*(?:"([^"]*)"|'([^']*)'|([^\s,]+))""")
_EPG = re.compile(r"""(?:url-tvg|x-tvg-url|tvg-url)\s*=\s*["']?([^"'\s>]+)""", re.I)

FREIE_LISTEN = [
    {"id": "bug-tv", "name": "BUG TV (Zaman-Topu)", "an": True,
     "url": "https://raw.githubusercontent.com/Zaman-Topu/Ip-tv-Collection/main/FINAL_IPTV_ACTIVE.m3u",
     "epg": "https://raw.githubusercontent.com/Zaman-Topu/Ip-tv-Collection/main/FINAL_EPG_COMPLETE.xml.gz",
     "repo": "https://github.com/Zaman-Topu/Ip-tv-Collection", "lizenz": LIZENZEN["bug"],
     "hinweis": "Taeglich neu gepruefte Sender aus vielen freien Listen; Schwerpunkt Suedasien, dazu internationale Sender."},
    {"id": "michaz-tv", "name": "Michaz TV", "an": True,
     "url": "https://michaz1988.github.io/tv.m3u",
     "epg": "https://github.com/michaz1988/michaz1988.github.io/releases/download/EPG/guide.xml.gz",
     "repo": "https://github.com/michaz1988/michaz1988.github.io", "lizenz": LIZENZEN["michaz"],
     "hinweis": "Senderliste und taeglich erneuerte EPG aus dem Michaz-Kodi-Repository."},
    {"id": "iptv-org-de", "name": "IPTV-org Deutschland", "an": True,
     "url": "https://iptv-org.github.io/iptv/countries/de.m3u", "epg": "",
     "repo": "https://github.com/iptv-org/iptv", "lizenz": "MIT",
     "hinweis": "Oeffentlich-rechtliche und frei empfangbare deutsche Sender aus dem iptv-org-Verzeichnis."},
]

WERKZEUGE = [
    {"name": "Dispatcharr", "repo": "https://github.com/Dispatcharr/Dispatcharr", "lizenz": LIZENZEN["dispatcharr"],
     "text": "IPTV-Verwaltung mit M3U- und XMLTV-Ausgabe, Xtream- und HDHomeRun-Schnittstelle. H0rSt uebernimmt "
             "die fertige Ausgabe als eigene Liste."},
    {"name": "IPTV Ultimate Player", "repo": "https://github.com/davidchiu66/IPTV_Ultimate_Player_Codex",
     "lizenz": LIZENZEN["player"],
     "text": "Windows-Player fuer M3U-, M3U8-, TXT-, JSON- und CFG-Listen mit EPG und Diagnoseprotokoll; "
             "seine Formate und die Diagnoseideen stecken in der Listenpruefung."},
    {"name": "StreamOS (iptv-stream)", "repo": "https://github.com/namandhakad712/iptv-stream",
     "lizenz": LIZENZEN["stream"],
     "text": "Schlanker Web-Player (React/PWA), der eine M3U-Adresse direkt im Browser abspielt."},
]

FORMATE = ["M3U", "M3U8", "HLS", "XMLTV"]


def _url(wert, standard=""):
    wert = str(wert or "").strip()
    if not wert:
        return standard
    try:
        teile = urlsplit(wert)
    except ValueError:
        return standard
    if teile.scheme not in ("http", "https") or not teile.hostname:
        return standard
    return wert[:1000]


def _holen(url, kopf=None, zeitgrenze=8.0):
    header = {"User-Agent": USER_AGENT}
    header.update(kopf or {})
    try:
        anfrage = urllib.request.Request(url, headers=header)
        with urllib.request.urlopen(anfrage, timeout=zeitgrenze) as antwort:
            return int(getattr(antwort, "status", 0) or antwort.getcode() or 0), antwort.read(MAX_LISTE)
    except Exception:
        return 0, b""


def dispatcharr_url(werte=None):
    werte = werte if isinstance(werte, dict) else {}
    return _url(werte.get("dispatcharr_url"), DISPATCHARR).rstrip("/")


def m3u_pruefen(text):
    """M3U/M3U8 schonend auswerten: Sender, Gruppen, EPG-Kopf, Doppel und kaputte Zeilen.

    Es wird nichts abgespielt und keine Adresse geladen; die Funktion arbeitet nur auf dem Text.
    """
    text = str(text or "").replace("\r", "")
    zeilen = text.splitlines()
    epg = ""
    treffer = _EPG.search(text[:4000])
    if treffer:
        epg = treffer.group(1).strip()
    eintraege, gruppen, tvg_ids, adressen = [], set(), set(), set()
    doppelt, kaputt, ohne_namen, letzte = 0, 0, 0, None
    for roh in zeilen:
        zeile = roh.strip()
        if not zeile:
            continue
        if zeile.upper().startswith("#EXTINF"):
            attr = {}
            for m in _ATTR.finditer(zeile.split(",", 1)[0]):
                attr[m.group(1).lower()] = (m.group(2) if m.group(2) is not None
                                             else m.group(3) if m.group(3) is not None else m.group(4) or "")
            name = zeile.rsplit(",", 1)[-1].strip() if "," in zeile else ""
            gruppe = attr.get("group-title") or attr.get("tvg-group") or "Ohne Gruppe"
            gruppen.add(gruppe[:80])
            if attr.get("tvg-id"):
                tvg_ids.add(attr["tvg-id"][:200])
            letzte = {"name": name[:200], "gruppe": gruppe[:80], "tvg_id": attr.get("tvg-id", "")[:200],
                      "logo": attr.get("tvg-logo", "")[:500]}
            if not name:
                ohne_namen += 1
            continue
        if zeile.startswith("#"):
            if zeile.upper().startswith("#EXTGRP:") and letzte:
                gruppe = zeile.split(":", 1)[1].strip()[:80]
                letzte["gruppe"] = gruppe or letzte["gruppe"]
                gruppen.add(letzte["gruppe"])
            continue
        if letzte is None:
            kaputt += 1
            continue
        if not re.match(r"(?i)^(https?|rtmp|rtsp|udp|rtp)://", zeile):
            kaputt += 1
            letzte = None
            continue
        if zeile in adressen:
            doppelt += 1
        adressen.add(zeile)
        eintraege.append(dict(letzte, url=zeile[:2000]))
        letzte = None
    return {"format": "M3U" if text.lstrip().upper().startswith("#EXTM3U") else "unbekannt",
            "sender": len(eintraege), "gruppen": sorted(gruppen)[:60], "gruppen_anzahl": len(gruppen),
            "tvg_ids": len(tvg_ids), "doppelt": doppelt, "kaputt": kaputt, "ohne_namen": ohne_namen,
            "epg": epg, "beispiele": eintraege[:12],
            "warnung": ("" if eintraege else "Keine Sender in der Liste gefunden.")}


def liste_pruefen(url, holen=None):
    """Eine M3U-Adresse holen und auswerten (hoechstens MAX_LISTE Bytes)."""
    url = _url(url)
    if not url:
        raise ValueError("Adresse mit http:// oder https://")
    status, inhalt = (holen or _holen)(url)
    if status != 200 or not inhalt:
        raise ValueError("Liste nicht erreichbar (HTTP %d)" % status)
    if len(inhalt) > MAX_LISTE:
        raise ValueError("Liste ist groesser als 8 MB")
    text = inhalt.decode("utf-8-sig", "replace")
    daten = m3u_pruefen(text)
    daten["url"] = url
    return daten


def dispatcharr_zustand(werte=None, holen=None, pruefen=False):
    """Dispatcharr pruefen: Version, Kanalzahl und die fertigen Ausgabe-Adressen."""
    werte = werte if isinstance(werte, dict) else {}
    basis = dispatcharr_url(werte)
    schluessel = str(werte.get("dispatcharr_key") or "").strip()[:500]
    erreichbar, meldung, version, kanaele = False, "", "", 0
    if not werte.get("iptvquellen_an"):
        meldung = "Ausgeschaltet – Dispatcharr wird nicht geprueft."
    elif not pruefen:
        meldung = "Nicht geprueft – Dispatcharr wird erst auf Knopfdruck abgefragt."
    else:
        status, inhalt = (holen or _holen)(basis + "/api/core/version/")
        if status == 200 and inhalt:
            try:
                daten = json.loads(inhalt.decode("utf-8", "replace"))
                version = str((daten or {}).get("version") or "")[:40]
            except (ValueError, UnicodeDecodeError):
                version = ""
            kopf = {"X-API-Key": schluessel} if schluessel else {}
            status2, inhalt2 = (holen or _holen)(basis + "/api/channels/channels/", kopf)
            if status2 == 200 and inhalt2:
                try:
                    roh = json.loads(inhalt2.decode("utf-8", "replace"))
                    kanaele = int(roh.get("count") or 0) if isinstance(roh, dict) else len(roh or [])
                except (ValueError, UnicodeDecodeError, TypeError):
                    kanaele = 0
            erreichbar = True
            meldung = "Dispatcharr erreichbar" + (": " + version if version else "") + \
                      (" – %d Kanaele." % kanaele if kanaele else ".")
            if not schluessel:
                meldung += " Fuer Kanaele und geschuetzte Ausgaben einen API-Schluessel eintragen."
        elif status in (301, 302, 401, 403):
            erreichbar = True
            meldung = "Dispatcharr ist erreichbar, die API verlangt aber eine Anmeldung."
        else:
            meldung = "Dispatcharr antwortet nicht. Laeuft der Container und ist %s erreichbar?" % basis
    return {"name": "Dispatcharr", "repo": "https://github.com/Dispatcharr/Dispatcharr",
            "lizenz": LIZENZEN["dispatcharr"], "web": basis, "erreichbar": erreichbar,
            "version": version, "kanaele": kanaele, "meldung": meldung,
            "m3u": basis + "/output/m3u", "epg": basis + "/output/epg",
            "key_gesetzt": bool(schluessel)}


def zustand(werte=None, holen=None, pruefen=False):
    werte = werte if isinstance(werte, dict) else {}
    return {"name": NAME, "an": werte.get("iptvquellen_an") is not False,
            "quellen": FREIE_LISTEN, "werkzeuge": WERKZEUGE, "formate": FORMATE,
            "dispatcharr": dispatcharr_zustand(werte, holen=holen, pruefen=pruefen),
            "hinweis": "Eine fremde Liste erst pruefen, dann uebernehmen. H0rSt spielt nur Adressen ab, "
                       "deren Rechte beim jeweiligen Anbieter liegen."}


def listen_eintrag(name, url):
    """Eintrag fuer Live-TV (livetv.pruefe) aus Name und Adresse bauen."""
    name = " ".join(str(name or "").split())[:80]
    url = _url(url)
    if not name or not url:
        raise ValueError("Name und Adresse mit http:// oder https:// noetig")
    return {"name": name, "url": url, "an": True}
