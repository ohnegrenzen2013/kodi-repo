"""IPVPN: dezentrales Overlay-Netz aus IPFS-DHT und WireGuard.

Vorbild: my-network/ipvpn (Go, WIP). Ein ipvpn-Knoten findet die anderen ueber den
IPFS-DHT, baut bei Bedarf einen WireGuard-Tunnel und legt zwei Schnittstellen an:
`ipvpn_direct` (direkt, UDP-Hole-Punching) und `ipvpn_tunnel` (Fallback). Alle Knoten
mit derselben Netz-Kennung und demselben Passwort bilden ein Netz; Beispieladressen
sind 10.197.202.1 und 10.197.203.1.

H0rSt startet ipvpnd nicht und braucht keine Root-Rechte. Es prueft, ob die
Schnittstellen vorhanden sind, baut die Befehle zum Einrichten und merkt sich die
Netz-Kennung. Das Passwort wird nie zurueckgegeben.
"""

import ipaddress
import os
import re

NAME = "IPVPN"
REPO = "https://github.com/my-network/ipvpn"
LIZENZ = "GPL-3.0"
NETZ_DATEI = "network_id.txt"
PASSWORT_DATEI = "password_new.txt"
SCHNITTSTELLEN = ("ipvpn_direct", "ipvpn_tunnel")
BEISPIEL_ADRESSEN = ("10.197.202.1", "10.197.203.1")
_NAME = re.compile(r"^[A-Za-z0-9._-]{3,64}$")
_ZEILE = re.compile(r"^\s*([0-9A-Za-z_.-]{1,32})\s+(\d{1,3}(?:\.\d{1,3}){3})\s*$")


class IpvpnFehler(ValueError):
    pass


def netz_pruefen(text):
    text = str(text or "").strip()
    if not _NAME.match(text):
        raise IpvpnFehler("Netz-Kennung: 3–64 Zeichen aus Buchstaben, Ziffern, Punkt, _ und -")
    return text


def passwort_pruefen(text):
    text = str(text or "")
    if len(text) < 8:
        raise IpvpnFehler("Passwort mit mindestens 8 Zeichen")
    return text


def knoten(text):
    """Zeilen "name 10.197.202.2" -> Peers; ungueltige Zeilen werden uebergangen."""
    ergebnis = []
    for zeile in str(text or "").splitlines():
        m = _ZEILE.match(zeile)
        if not m:
            continue
        try:
            ip = str(ipaddress.ip_address(m.group(2)))
        except ValueError:
            continue
        if ip not in [e["adresse"] for e in ergebnis]:
            ergebnis.append({"name": m.group(1)[:32], "adresse": ip})
    return ergebnis[:64]


def schnittstellen_lesen(pfad="/proc/net/dev"):
    try:
        with open(pfad, encoding="utf-8") as f:
            zeilen = f.readlines()
    except OSError:
        return []
    namen = []
    for zeile in zeilen:
        if ":" in zeile:
            name = zeile.split(":", 1)[0].strip()
            if name:
                namen.append(name)
    return namen


def befehle(werte=None):
    """Einrichtung als Befehlsliste; das Passwort bleibt ein Platzhalter."""
    werte = werte if isinstance(werte, dict) else {}
    try:
        netz = netz_pruefen(werte.get("ipvpn_netz"))
    except IpvpnFehler:
        netz = "<netz-kennung>"
    return [
        {"titel": "ipvpnd installieren", "befehl": "go install github.com/my-network/ipvpn/cmd/ipvpnd@latest"},
        {"titel": "Rechte fuer WireGuard", "befehl": "sudo setcap cap_net_raw,cap_net_admin+ep $(go env GOPATH)/bin/ipvpnd"},
        {"titel": "Ordner und Netzkennung", "befehl": "mkdir -p ~/.ipvpn && printf '%%s\\n' '%s' > ~/.ipvpn/%s" % (netz, NETZ_DATEI)},
        {"titel": "Passwort setzen", "befehl": "printf '%%s\\n' '<passwort>' > ~/.ipvpn/%s" % PASSWORT_DATEI},
        {"titel": "ipvpnd starten", "befehl": "$(go env GOPATH)/bin/ipvpnd"},
        {"titel": "Schnittstellen pruefen", "befehl": "ip a show dev ipvpn_direct; ip a show dev ipvpn_tunnel"},
        {"titel": "Beispieladressen pingen", "befehl": "ping -c 5 10.197.202.1; ping -c 5 10.197.203.1"},
    ]


def zustand(werte=None, vorhanden=None, pruefen=False):
    """Netz-Kennung, Peers und Schnittstellen; ohne pruefen=True wird /proc/net/dev nicht gelesen."""
    werte = werte if isinstance(werte, dict) else {}
    an = werte.get("ipvpn_an") is True
    netz, fehler = "", ""
    try:
        netz = netz_pruefen(werte.get("ipvpn_netz"))
    except IpvpnFehler as problem:
        fehler = str(problem)
    peers = knoten(werte.get("ipvpn_knoten"))
    namen = list(vorhanden or []) if vorhanden is not None else (schnittstellen_lesen() if pruefen else [])
    da = [n for n in SCHNITTSTELLEN if n in namen]
    if not an:
        meldung = "Ausgeschaltet – IPVPN wird nicht geprueft."
    elif not pruefen:
        meldung = "Nicht geprueft – Schnittstellen werden erst auf Knopfdruck gelesen."
    elif len(da) == len(SCHNITTSTELLEN):
        meldung = "Beide IPVPN-Schnittstellen sind vorhanden."
    elif da:
        meldung = "Nur %s vorhanden – der Tunnel ist noch nicht vollstaendig." % ", ".join(da)
    else:
        meldung = "Keine IPVPN-Schnittstelle gefunden. Laeuft ipvpnd auf diesem Rechner?"
    return {"name": NAME, "repo": REPO, "lizenz": LIZENZ, "an": an, "netz": netz, "fehler": fehler,
            "peers": peers, "schnittstellen": da, "erwartet": list(BEISPIEL_ADRESSEN),
            "passwort_gesetzt": bool(str(werte.get("ipvpn_passwort") or "")),
            "meldung": meldung, "befehle": befehle(werte)}


def dateien(ordner=None):
    """Wo ipvpn seine zwei Dateien erwartet (nur Anzeige, es wird nichts angelegt)."""
    ordner = ordner or os.path.join("~", ".ipvpn")
    return {"ordner": ordner, "netz": os.path.join(ordner, NETZ_DATEI),
            "passwort": os.path.join(ordner, PASSWORT_DATEI)}
