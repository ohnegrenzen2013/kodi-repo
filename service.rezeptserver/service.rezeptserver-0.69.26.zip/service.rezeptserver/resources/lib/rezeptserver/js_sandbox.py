"""js_sandbox.py: echte, isolierte JavaScript-Ausfuehrung fuer fremden Code (NuvioMobile-Plan NV5).

Nuvios Plugin-System fuehrt fremden, aus dem Netz geladenen JS-Code aus (Funktionssignatur
`getStreams(tmdbId, mediaType, season, episode)`). H0rSt hatte dafuer bisher keine sichere native
Sandbox. ausfuehren() schliesst genau diese Luecke, ueber quickjs-rs: QuickJS-ng wird zu WebAssembly
kompiliert und per wasmtime ausgefuehrt, das fremde JS sieht nie einen Host-Zeiger und kann weder
Python- noch Betriebssystem-Speicher erreichen.

Optional wie yt-dlp (siehe ab18/resolver.py::have_resolver() - gleiches Muster): `pip install
quickjs-rs`, selbst erkannt und nie vorausgesetzt. quickjs-rs selbst verlangt Python >= 3.11 - eine
aeltere Installation kann das Paket gar nicht erst installieren, eine eigene Versionspruefung hier ist
daher nicht noetig. Laeuft NICHT in der Kodi-Addon-Laufzeit (die kann grundsaetzlich nie zur Laufzeit
pip-installieren) und nur eingeschraenkt auf Android (wasmtime liefert zwar eigene Android-Wheels,
dokumentiert Android aber selbst nur als "supported but less well tested, not tested on CI").

Bewusst OHNE Netzzugriff aus dem Sandbox-Code heraus: Das Plugin bekommt nur JSON-faehige Argumente
und muss selbst `JSON.stringify()` auf seinen Rueckgabewert anwenden - das haelt die Host-Python-Grenze
strikt auf "JSON herein, JSON heraus" und vermeidet jede Unsicherheit ueber automatisches Marshalling
komplexer JS-Objekte. quickjs-rs nennt in der eigenen Sicherheits-Doku wasmtime/Cranelift als
verbleibendes Rest-Risiko und empfiehlt bei feindlichem Code zusaetzliche Prozess-/Container-Isolation;
ein Netzzugriff aus der Sandbox heraus waere ein weiterer, hier bewusst nicht eroeffneter Angriffsvektor
– ein Plugin bekommt nur das, was H0rSt ihm (bereits SSRF-geprueft) selbst beschafft hat.

quickjs-rs 0.2.6 ist PyPI-Status "Alpha", ~6 Monate alt und nennt sich selbst "experimental" - die
Oberflaeche muss das deutlich zeigen (siehe oberflaeche_js_sandbox.py/Einstellungen).

ausfuehren_mit_fetch() (NV5-To-Do, Fetch-Bridge fuer den vollen Nuvio-kompatiblen getStreams()-Plugin)
durchbricht diesen No-Network-Grundsatz bewusst fuer EINEN, separaten Pfad - ausfuehren() selbst bleibt
unveraendert netzlos, nur der neue Pfad bekommt einen echten Host-Callback (quickjs-rs Context.register(),
empirisch bestaetigt synchron/blockierend, WISSEN.md 0.68.141). Sicherheits-/Zeitgrenzen-Verantwortung
(SSRF-Pruefung, Aufruf-Deckel, Socket-Zeitgrenze) liegt vollstaendig beim Aufrufer (nuvio_plugin.py), nicht
hier - dieses Modul bleibt protokoll-/sicherheits-agnostisch bzgl. HTTP. WICHTIG, ebenfalls empirisch
bestaetigt: quickjs-rs' Context(timeout=...) unterbricht einen haengenden Host-Callback NICHT (nur reine
JS-Dauerschleifen) - der Aufrufer darf sich dafuer also nicht auf das Zeitlimit hier verlassen."""

import json

ZEITLIMIT_STANDARD = 5.0           # Sekunden; quickjs-rs' eigener Standard (Context(timeout=5.0))
ZEITLIMIT_FETCH_STANDARD = 60.0    # grosszuegiger: echte Netz-Rundlaeufe brauchen mehr Zeit als reine
                                    # Berechnung - der eigentliche Schutz vor einem haengenden Callback
                                    # liegt beim Aufrufer (Socket-Zeitgrenze + Aufruf-Deckel), nicht hier
SPEICHERLIMIT_STANDARD = 64 * 1024 * 1024  # Bytes; quickjs-rs' eigener Standard (Runtime(memory_limit=...))
MAX_CODE = 200_000                 # Zeichen - ein Plugin ist ein kleines Skript, kein Megabyte-Bundle
MAX_ERGEBNIS = 2_000_000           # Zeichen JSON-Text zurueck


class JsSandboxFehler(ValueError):
    pass


def _quickjs():
    try:
        import quickjs_rs
    except Exception:
        return None
    return quickjs_rs


def verfuegbar():
    """Ob die Sandbox auf dieser Installation ueberhaupt nutzbar ist (pip install quickjs-rs)."""
    return _quickjs() is not None


def version():
    modul = _quickjs()
    return str(getattr(modul, "__version__", "") or "") if modul else ""


def _ausfuehren(code, funktion, argumente, zeitlimit, speicherlimit, registrieren=None):
    """Gemeinsamer Kern von ausfuehren()/ausfuehren_mit_fetch() - registrieren(ctx), falls gesetzt, laeuft
    nach dem Aufbau des Context und vor dem eval() (Host-Funktionen eintragen)."""
    quickjs_rs = _quickjs()
    if quickjs_rs is None:
        raise JsSandboxFehler("JS-Sandbox nicht verfügbar (pip install quickjs-rs, braucht Python 3.11+)")
    if not isinstance(code, str) or not code.strip():
        raise JsSandboxFehler("Kein JS-Code")
    if len(code) > MAX_CODE:
        raise JsSandboxFehler("JS-Code zu groß")
    if not isinstance(funktion, str) or not funktion.strip():
        raise JsSandboxFehler("Kein Funktionsname")
    try:
        aufruf_argumente = ", ".join(json.dumps(a) for a in argumente)
    except (TypeError, ValueError) as fehler:
        raise JsSandboxFehler("Argumente nicht JSON-fähig: %s" % fehler)
    quelle = "%s\n;JSON.stringify(%s(%s))" % (code, funktion, aufruf_argumente)
    try:
        with quickjs_rs.Runtime(memory_limit=speicherlimit) as rt:
            with rt.new_context(timeout=zeitlimit) as ctx:
                if registrieren:
                    registrieren(ctx)
                ergebnis = ctx.eval(quelle)
    except quickjs_rs.QuickJSError as fehler:
        raise JsSandboxFehler(str(fehler))
    if ergebnis is None:
        return None
    if not isinstance(ergebnis, str):
        raise JsSandboxFehler("%s lieferte kein JSON (muss JSON.stringify() aufrufen)" % funktion)
    if len(ergebnis) > MAX_ERGEBNIS:
        raise JsSandboxFehler("Ergebnis zu groß")
    try:
        return json.loads(ergebnis)
    except ValueError as fehler:
        raise JsSandboxFehler("Ergebnis ist kein gültiges JSON: %s" % fehler)


def ausfuehren(code, funktion, argumente=(), zeitlimit=ZEITLIMIT_STANDARD, speicherlimit=SPEICHERLIMIT_STANDARD):
    """Fuehrt code (definiert funktion als globale JS-Funktion) in einer isolierten quickjs-rs-Sandbox
    aus und ruft funktion(*argumente) auf. argumente sind JSON-faehige Python-Werte; funktion muss sein
    Ergebnis selbst mit JSON.stringify() zurueckgeben (sonst JsSandboxFehler). Wirft JsSandboxFehler bei
    jedem Problem (Sandbox nicht verfuegbar, zu grosser Code, Zeit-/Speicherlimit, JS-Fehler, kaputtes
    JSON) - nie eine andere Exception nach aussen. Gibt None zurueck, wenn funktion nichts liefert."""
    return _ausfuehren(code, funktion, argumente, zeitlimit, speicherlimit)


def ausfuehren_mit_fetch(code, funktion, argumente, fetch_sync, zeitlimit=ZEITLIMIT_FETCH_STANDARD,
                         speicherlimit=SPEICHERLIMIT_STANDARD):
    """Wie ausfuehren(), aber das JS bekommt eine synchrone Host-Funktion `fetchSync(argument)` zur
    Verfuegung gestellt (quickjs-rs Context.register() - ein echter synchroner Host-Callback, der
    ctx.eval() blockiert, bis fetch_sync() zurueckkehrt; empirisch bestaetigt, WISSEN.md 0.68.141).
    fetch_sync(argument: dict) -> dict wird vom AUFRUFER uebergeben und bleibt die einzige Stelle mit
    Netzzugriff - dieses Modul selbst stellt nie eine Verbindung her. argumente/Rueckgabewert von
    fetch_sync duerfen echte, verschachtelte dict/list/str/int/bool/None sein - quickjs-rs marshallt das
    automatisch in beide Richtungen (anders als funktion()s eigener JSON.stringify()-Rueckgabewert,
    dessen Vertrag unveraendert bleibt).

    fetch_sync() SOLLTE selbst eine Socket-Zeitgrenze durchsetzen (z. B. ueber netz.Abrufer) - das
    Context-Timeout (zeitlimit) unterbricht einen haengenden Host-Callback NICHT, nur reine JS-
    Dauerschleifen (empirisch bestaetigt). fetch_sync() sollte fuer erwartbare Fehler (SSRF gesperrt,
    Aufruf-Deckel erreicht, Netzfehler) ein Fehler-Dict zurueckgeben statt zu werfen, damit das Plugin
    selbst reagieren kann - eine vom JS-Code selbst gefangene Python-Exception kommt dort naemlich nur
    als nicht unterscheidbarer "HostError: Host function failed" an, die urspruengliche Meldung geht
    verloren. Als Schutznetz, falls fetch_sync() trotzdem wirft (und das JS den Fehler NICHT selbst
    faengt - die rohe Exception wuerde sonst unveraendert bis hier durchschlagen, empirisch bestaetigt):
    diese Funktion faengt jede Exception aus fetch_sync() ab und gibt dem JS stattdessen
    {"fehler": "..."} zurueck - ausfuehren_mit_fetch() wirft also wie ausfuehren() nie etwas ausser
    JsSandboxFehler nach aussen."""
    def _fetch_sicher(argument):
        try:
            return fetch_sync(argument)
        except Exception as fehler:
            return {"fehler": str(fehler)[:300]}
    return _ausfuehren(code, funktion, argumente, zeitlimit, speicherlimit,
                       registrieren=lambda ctx: ctx.register("fetchSync", _fetch_sicher))
