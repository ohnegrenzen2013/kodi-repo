"""Kleine JSONPath-Teilmenge fuer Rezepte.

Unterstuetzt: $  .feld  ['feld']  [3]  [-1]  [*]  .*  [?(@.feld)]  [?(@.feld=='wert')]  [?(@.feld!='wert')]
"""

import re

_NAME = re.compile(r"[A-Za-z0-9_\-]+")
_FILTER = re.compile(r"^@\.([A-Za-z0-9_\-.]+)\s*(?:(==|!=)\s*(.+))?$")


class PfadFehler(ValueError):
    pass


def _literal(text):
    text = text.strip()
    if len(text) >= 2 and text[0] == text[-1] and text[0] in "'\"":
        return text[1:-1]
    try:
        return float(text) if "." in text else int(text)
    except ValueError:
        raise PfadFehler("Unbekannter Wert im Filter: %s" % text)


def zerlege(pfad):
    if not isinstance(pfad, str) or not pfad.startswith("$"):
        raise PfadFehler("Pfad muss mit $ beginnen: %r" % (pfad,))
    teile = []
    i = 1
    while i < len(pfad):
        zeichen = pfad[i]
        if zeichen == ".":
            if pfad[i + 1:i + 2] == "*":
                teile.append(("alle",))
                i += 2
                continue
            treffer = _NAME.match(pfad, i + 1)
            if not treffer:
                raise PfadFehler("Feldname erwartet bei Stelle %d: %s" % (i + 1, pfad))
            teile.append(("feld", treffer.group(0)))
            i = treffer.end()
        elif zeichen == "[":
            if pfad.startswith("[?(", i):
                ende = pfad.find(")]", i)
                if ende < 0:
                    raise PfadFehler("Filter nicht geschlossen: %s" % pfad)
                teile.append(_filter(pfad[i + 3:ende]))
                i = ende + 2
                continue
            ende = pfad.find("]", i)
            if ende < 0:
                raise PfadFehler("Klammer nicht geschlossen: %s" % pfad)
            inhalt = pfad[i + 1:ende].strip()
            if inhalt == "*":
                teile.append(("alle",))
            elif re.fullmatch(r"-?\d+", inhalt):
                teile.append(("index", int(inhalt)))
            elif len(inhalt) >= 2 and inhalt[0] == inhalt[-1] and inhalt[0] in "'\"":
                teile.append(("feld", inhalt[1:-1]))
            else:
                raise PfadFehler("Unbekannter Ausdruck [%s] in %s" % (inhalt, pfad))
            i = ende + 1
        else:
            raise PfadFehler("Unerwartetes Zeichen %r in %s" % (zeichen, pfad))
    return teile


def _filter(ausdruck):
    treffer = _FILTER.match(ausdruck.strip())
    if not treffer:
        raise PfadFehler("Filter nicht verstanden: %s" % ausdruck)
    feld, op, wert = treffer.groups()
    return ("filter", feld.split("."), op, _literal(wert) if op else None)


def _feldwert(knoten, kette):
    for name in kette:
        if not isinstance(knoten, dict) or name not in knoten:
            return None, False
        knoten = knoten[name]
    return knoten, True


def finde(pfad, daten):
    """Gibt eine Liste aller Treffer zurueck (leer, wenn nichts passt)."""
    aktuell = [daten]
    for teil in zerlege(pfad):
        neu = []
        for knoten in aktuell:
            art = teil[0]
            if art == "feld":
                if isinstance(knoten, dict) and teil[1] in knoten:
                    neu.append(knoten[teil[1]])
            elif art == "alle":
                if isinstance(knoten, list):
                    neu.extend(knoten)
                elif isinstance(knoten, dict):
                    neu.extend(knoten.values())
            elif art == "index":
                if isinstance(knoten, list) and -len(knoten) <= teil[1] < len(knoten):
                    neu.append(knoten[teil[1]])
            elif art == "filter":
                _, kette, op, wert = teil
                for element in knoten if isinstance(knoten, list) else []:
                    vorhanden_wert, vorhanden = _feldwert(element, kette)
                    if op is None:
                        passt = vorhanden and vorhanden_wert not in (None, "", False)
                    elif op == "==":
                        passt = vorhanden and vorhanden_wert == wert
                    else:
                        passt = not vorhanden or vorhanden_wert != wert
                    if passt:
                        neu.append(element)
        aktuell = neu
    return aktuell
