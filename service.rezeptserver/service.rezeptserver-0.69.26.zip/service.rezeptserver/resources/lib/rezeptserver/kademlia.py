"""Kademlia-Grundlagen fuer eD2K/Kad: Kennungen, XOR-Abstand und k-Buckets.

Die eD2K-Kad-Knoten aus `ed2k_listen.py` (nodes.dat) sind Startpunkte. H0rSt spricht Kad
weiterhin nicht selbst; dieses Modul rechnet nur den Abstand aus, ordnet die Knoten in
k-Buckets ein und zeigt, welche Knoten einem Ziel am naechsten liegen. Vorbilder:
DavidKeller/kademlia (C++11, MIT) und "The Kademlia Protocol Succinctly".

Nutzerdaten: keine. Die eigene Kennung kommt aus den Einstellungen (`kad_id`, optional).
"""

import hashlib
import os
import re

from . import ed2k_listen

K = 20
ID_BITS = 128
HEX = set("0123456789ABCDEF")
_ID = re.compile(r"^[0-9A-F]{32}$")


class KadFehler(ValueError):
    pass


def id_pruefen(text):
    """Kad-Kennung (128 Bit) als 32 Hex-Zeichen; Doppelpunkte und Leerraum werden entfernt."""
    text = re.sub(r"[\s:]", "", str(text or "")).upper()
    if not _ID.match(text):
        raise KadFehler("Kad-Kennung muss aus 32 Hex-Zeichen bestehen")
    return text


def zufalls_id():
    return os.urandom(16).hex().upper()


def abstand(a, b):
    """XOR-Abstand zweier Kad-Kennungen als ganze Zahl."""
    return int(id_pruefen(a), 16) ^ int(id_pruefen(b), 16)


def gemeinsame_bits(a, b):
    """Anzahl fuehrender gleicher Bits (0 … 128)."""
    rest = abstand(a, b)
    return ID_BITS - rest.bit_length()


def eigene_id(werte=None):
    """Eigene Kad-Kennung: aus den Einstellungen oder fest aus dem Projektnamen abgeleitet."""
    werte = werte if isinstance(werte, dict) else {}
    roh = str(werte.get("kad_id") or "").strip()
    if roh:
        try:
            return id_pruefen(roh)
        except KadFehler:
            pass
    return hashlib.sha1(b"h0rst-kad-standard").hexdigest()[:32].upper()


def knoten_pruefen(roh):
    """Einen Kad-Knoten pruefen und auf die Felder der Oberflaeche bringen."""
    if not isinstance(roh, dict):
        raise KadFehler("Knoten muss ein JSON-Objekt sein")
    kid = id_pruefen(roh.get("id"))
    adresse = str(roh.get("adresse") or "").strip()
    if not adresse:
        raise KadFehler("Knoten ohne Adresse")
    udp = int(roh.get("udp") or 0)
    tcp = int(roh.get("tcp") or 0)
    if not 1 <= udp <= 65535 and not 1 <= tcp <= 65535:
        raise KadFehler("Knoten ohne gueltigen Port")
    return {"id": kid, "adresse": adresse[:100], "udp": udp if 1 <= udp <= 65535 else 0,
            "tcp": tcp if 1 <= tcp <= 65535 else 0, "version": int(roh.get("version") or 0)}


class Tabelle:
    """Routing-Tabelle mit einem k-Bucket je gemeinsamer Bit-Laenge."""

    def __init__(self, ich):
        self.ich = id_pruefen(ich)
        self.buckets = [[] for _ in range(ID_BITS)]

    def _fach(self, kid):
        return min(gemeinsame_bits(self.ich, kid), ID_BITS - 1)

    def einfuegen(self, roh):
        k = knoten_pruefen(roh)
        if k["id"] == self.ich:
            return False
        fach = self._fach(k["id"])
        for vorhanden in self.buckets[fach]:
            if vorhanden["id"] == k["id"]:
                vorhanden.update(k)
                return False
        if len(self.buckets[fach]) >= K:
            return False
        self.buckets[fach].append(k)
        return True

    def naechste(self, ziel, anzahl=K):
        ziel = id_pruefen(ziel)
        alle = [k for bucket in self.buckets for k in bucket]
        return sorted(alle, key=lambda k: abstand(k["id"], ziel))[:max(1, int(anzahl))]

    def alle(self):
        return [k for bucket in self.buckets for k in bucket]

    def zustand(self, ziel=None):
        ziel = id_pruefen(ziel or self.ich)
        buckets = [(i, len(b)) for i, b in enumerate(self.buckets) if b]
        return {"id": self.ich, "knoten": len(self.alle()), "buckets": buckets,
                "naechste": self.naechste(ziel), "ziel": ziel}


def tabelle_bauen(knoten, ich=None):
    """Knoten aus nodes.dat in eine Tabelle uebernehmen; doppelte Kennungen zaehlen einmal."""
    tabelle = Tabelle(ich or eigene_id())
    for roh in knoten or []:
        try:
            tabelle.einfuegen(roh)
        except (KadFehler, TypeError, ValueError):
            continue
    return tabelle


def kad_liste(ordner=None, holen=None):
    """Die aktuelle nodes.dat-Liste aus ed2k_listen (ohne Netz, solange nichts geladen ist)."""
    if not ordner:
        return []
    liste = ed2k_listen.Kadliste(ordner, holen=holen)
    return liste.eintraege()


def zustand(werte=None, knoten=None, tabelle=None, holen=None, ordner=None):
    """Was die Oberflaeche ueber Kad wissen muss: Kennung, Knoten, Buckets, naechste Knoten."""
    werte = werte if isinstance(werte, dict) else {}
    ich = eigene_id(werte)
    if tabelle is None:
        if knoten is None:
            knoten = kad_liste(ordner, holen=holen)
        tabelle = tabelle_bauen(knoten, ich)
    ziel = str(werte.get("kad_ziel") or "").strip()
    try:
        ziel = id_pruefen(ziel) if ziel else ich
    except KadFehler:
        ziel = ich
    daten = tabelle.zustand(ziel)
    daten.update({"name": "eD2K & Kad", "k": K, "frei": max(0, K - len(tabelle.buckets[0]))})
    return daten


def knoten_text(text, ich=None):
    """Zeilen "ip:port" oder "id ip:port" -> Knotenliste (Startpunkte von Hand)."""
    ergebnis = []
    for zeile in str(text or "").replace(",", "\n").splitlines():
        teile = zeile.strip().replace("udp://", "").replace("tcp://", "").split()
        if not teile:
            continue
        if len(teile) >= 2 and _ID.match(teile[0].upper().replace(":", "")):
            kid, adresse = teile[0], teile[1]
        else:
            adresse = teile[-1]
            kid = hashlib.sha1(adresse.encode("utf-8")).hexdigest()[:32].upper()
        host, _, port = adresse.rpartition(":")
        if not host or not port.isdigit():
            continue
        try:
            ergebnis.append(knoten_pruefen({"id": kid, "adresse": host, "udp": int(port)}))
        except KadFehler:
            continue
    return ergebnis
