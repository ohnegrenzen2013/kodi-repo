"""Kameras: IP-Webcams im Heimnetz live ansehen, Snaps machen und im Abstand aufnehmen (Ueberwachung).

Arten je Kamera:
  mjpeg     Motion-JPEG-Strom (z. B. http://cam/video.mjpg, IP Webcam auf Android: http://handy:8080/video)
  snapshot  Einzelbild-Adresse (z. B. http://cam/snapshot.jpg, IP Webcam: /shot.jpg); live = Bild alle 1-2 s
  hls       HLS-Strom (.m3u8), laeuft ueber den HLS-Weg von H0rSt
  rtsp      rtsp://... – Browser koennen das nicht; Link fuer VLC/Kodi/externen Player
Zugangsdaten (Basic oder Digest) bleiben auf dem Server; der Browser sieht nur H0rSt-Adressen.
Snaps: <Datenordner>/kameras/<id>/<JJJJMMTT-HHMMSS>.jpg; Ueberwachung macht alle n Minuten einen Snap und behaelt
die letzten m. Nutzerdaten "kameras": [{"id", "name", "art", "url", "benutzer", "passwort", "intervall", "behalten"}]
"""

import logging
import os
import re
import secrets
import threading
import time
import urllib.error
import urllib.request
from urllib.parse import urlsplit

from .netz import USER_AGENT

log = logging.getLogger("rezeptserver")

SCHLUESSEL = "kameras"
ARTEN = {"mjpeg": "MJPEG-Strom", "snapshot": "Einzelbild-Adresse", "hls": "HLS (.m3u8)", "rtsp": "RTSP (nur externer Player)"}
INTERVALLE = (0, 1, 5, 15, 60)
MAX_KAMERAS = 16
MAX_BILD = 8 * 1024 * 1024
ORDNER = "kameras"
_SNAP = re.compile(r"^\d{8}-\d{6}(?:-\d+)?\.jpg$")
VORSCHLAEGE = [
    {"name": "IP Webcam (Android-App)", "art": "mjpeg", "url": "http://HANDY-IP:8080/video"},
    {"name": "IP Webcam – Einzelbild", "art": "snapshot", "url": "http://HANDY-IP:8080/shot.jpg"},
    {"name": "Reolink – Einzelbild", "art": "snapshot", "url": "http://KAMERA-IP/cgi-bin/api.cgi?cmd=Snap&channel=0"},
    {"name": "Hikvision – Einzelbild", "art": "snapshot", "url": "http://KAMERA-IP/ISAPI/Streaming/channels/101/picture"},
    {"name": "RTSP-Kamera", "art": "rtsp", "url": "rtsp://KAMERA-IP:554/stream1"},
]


class KameraFehler(ValueError):
    pass


def pruefe(roh, alt=None):
    roh = roh or []
    if not isinstance(roh, list) or len(roh) > MAX_KAMERAS:
        raise KameraFehler("kameras: Liste mit höchstens %d Kameras" % MAX_KAMERAS)
    alte = {k.get("id"): k for k in alt or [] if isinstance(k, dict)}
    ergebnis, ids = [], set()
    for k in roh:
        if not isinstance(k, dict):
            raise KameraFehler("Jede Kamera ist ein Objekt")
        art = k.get("art") if k.get("art") in ARTEN else "mjpeg"
        url = str(k.get("url") or "").strip()
        schema = urlsplit(url).scheme
        if art == "rtsp" and schema not in ("rtsp", "rtsps"):
            raise KameraFehler("RTSP-Adresse muss mit rtsp:// beginnen")
        if art != "rtsp" and schema not in ("http", "https"):
            raise KameraFehler("Adresse muss mit http:// oder https:// beginnen")
        if not urlsplit(url).hostname or re.search(r"HANDY-IP|KAMERA-IP", url):
            raise KameraFehler("Platzhalter in der Adresse ersetzen (HANDY-IP, KAMERA-IP)")
        kid = re.sub(r"[^a-z0-9]", "", str(k.get("id") or "").lower())[:16] or secrets.token_hex(4)
        while kid in ids:
            kid = secrets.token_hex(4)
        ids.add(kid)
        passwort = str(k.get("passwort") or "") or alte.get(kid, {}).get("passwort", "")
        try:
            intervall = int(k.get("intervall") or 0)
            behalten = max(1, min(1000, int(k.get("behalten") or 50)))
        except (TypeError, ValueError):
            raise KameraFehler("Intervall und Anzahl müssen Zahlen sein")
        ergebnis.append({"id": kid, "name": " ".join(str(k.get("name") or "Kamera").split())[:60], "art": art, "url": url,
                         "benutzer": str(k.get("benutzer") or "")[:100], "passwort": passwort[:200],
                         "intervall": intervall if intervall in INTERVALLE else 0, "behalten": behalten})
    return ergebnis


def oeffentlich(kameras):
    return [dict({k: v for k, v in c.items() if k != "passwort"}, passwort_gesetzt=bool(c.get("passwort"))) for c in kameras]


def oeffner(kamera):
    """urllib-Oeffner mit Basic- und Digest-Anmeldung (IP-Kameras nutzen oft Digest)."""
    handler = []
    if kamera.get("benutzer") or kamera.get("passwort"):
        verwaltung = urllib.request.HTTPPasswordMgrWithDefaultRealm()
        verwaltung.add_password(None, kamera["url"], kamera.get("benutzer", ""), kamera.get("passwort", ""))
        handler += [urllib.request.HTTPBasicAuthHandler(verwaltung), urllib.request.HTTPDigestAuthHandler(verwaltung)]
    return urllib.request.build_opener(*handler)


def oeffnen(kamera, zeit=15):
    try:
        return oeffner(kamera).open(urllib.request.Request(kamera["url"], headers={"User-Agent": USER_AGENT}), timeout=zeit)
    except urllib.error.HTTPError as fehler:
        fehler.close()
        raise KameraFehler("Kamera antwortet mit HTTP %d%s" % (fehler.code, " (Zugangsdaten?)" if fehler.code == 401 else ""))
    except (urllib.error.URLError, OSError) as fehler:
        raise KameraFehler("Kamera nicht erreichbar: %s" % getattr(fehler, "reason", fehler))


def jpeg_aus_strom(antwort, grenze=MAX_BILD):
    """Erstes vollstaendiges JPEG aus einem MJPEG-Strom (SOI ... EOI)."""
    puffer = bytearray()
    while len(puffer) < grenze:
        teil = antwort.read(16384)
        if not teil:
            break
        puffer.extend(teil)
        anfang = puffer.find(b"\xff\xd8")
        if anfang >= 0:
            ende = puffer.find(b"\xff\xd9", anfang + 2)
            if ende >= 0:
                return bytes(puffer[anfang:ende + 2])
    raise KameraFehler("Kein Bild im Strom gefunden")


def bild(kamera):
    """Ein aktuelles JPEG der Kamera (Einzelbild-Adresse oder erstes Bild aus dem MJPEG-Strom)."""
    if kamera["art"] not in ("mjpeg", "snapshot"):
        raise KameraFehler("Für %s gibt es kein Einzelbild" % ARTEN[kamera["art"]])
    with oeffnen(kamera) as antwort:
        if kamera["art"] == "mjpeg" and "multipart" in (antwort.headers.get("Content-Type") or ""):
            return jpeg_aus_strom(antwort)
        daten = antwort.read(MAX_BILD + 1)
    if len(daten) > MAX_BILD or not daten.startswith(b"\xff\xd8"):
        raise KameraFehler("Die Adresse liefert kein JPEG-Bild")
    return daten


class Snaps:
    """Snaps je Kamera speichern, auflisten, loeschen; Ueberwachung im Hintergrund."""

    def __init__(self, datenordner, kameras_holen, uhr=time.time):
        self.ordner = os.path.join(datenordner or ".", ORDNER)
        self.kameras_holen = kameras_holen  # -> aktuelle Liste der Kameras
        self.uhr = uhr
        self._halt = threading.Event()
        self._faden = None
        self._zuletzt = {}
        self.fehler = {}

    def _ordner(self, kid):
        if not re.match(r"^[a-z0-9]{1,16}$", str(kid or "")):
            raise KameraFehler("Ungültige Kamera")
        return os.path.join(self.ordner, kid)

    def speichern(self, kamera, daten=None):
        daten = daten or bild(kamera)
        ziel = self._ordner(kamera["id"])
        os.makedirs(ziel, exist_ok=True)
        name = time.strftime("%Y%m%d-%H%M%S", time.localtime(self.uhr())) + ".jpg"
        n = 1
        while os.path.exists(os.path.join(ziel, name)):
            name = time.strftime("%Y%m%d-%H%M%S", time.localtime(self.uhr())) + "-%d.jpg" % n
            n += 1
        with open(os.path.join(ziel, name), "wb") as f:
            f.write(daten)
        self._aufraeumen(kamera)
        return name

    def liste(self, kid):
        ziel = self._ordner(kid)
        if not os.path.isdir(ziel):
            return []
        namen = sorted((n for n in os.listdir(ziel) if _SNAP.match(n)), reverse=True)
        return [{"name": n, "groesse": os.path.getsize(os.path.join(ziel, n)),
                 "zeit": "%s.%s.%s %s:%s:%s" % (n[6:8], n[4:6], n[0:4], n[9:11], n[11:13], n[13:15])} for n in namen]

    def pfad(self, kid, name):
        if not _SNAP.match(str(name or "")):
            raise KameraFehler("Ungültiger Snap")
        pfad = os.path.join(self._ordner(kid), name)
        if not os.path.isfile(pfad):
            raise KameraFehler("Snap gibt es nicht")
        return pfad

    def loeschen(self, kid, name=None):
        if name:
            os.remove(self.pfad(kid, name))
            return
        for s in self.liste(kid):
            os.remove(os.path.join(self._ordner(kid), s["name"]))

    def _aufraeumen(self, kamera):
        for s in self.liste(kamera["id"])[kamera.get("behalten", 50):]:
            try:
                os.remove(os.path.join(self._ordner(kamera["id"]), s["name"]))
            except OSError:
                pass

    # Ueberwachung: alle "intervall" Minuten ein Snap
    def starten(self):
        if self._faden and self._faden.is_alive():
            return
        self._halt.clear()
        self._faden = threading.Thread(target=self._schleife, name="kameras", daemon=True)
        self._faden.start()

    def stoppen(self):
        self._halt.set()

    def runde(self):
        jetzt = self.uhr()
        for k in self.kameras_holen():
            if not k.get("intervall") or k["art"] not in ("mjpeg", "snapshot"):
                continue
            if jetzt - self._zuletzt.get(k["id"], 0) < k["intervall"] * 60 - 5:
                continue
            self._zuletzt[k["id"]] = jetzt
            try:
                self.speichern(k)
                self.fehler.pop(k["id"], None)
            except (KameraFehler, OSError) as fehler:
                if k["id"] not in self.fehler:
                    from . import ereignisse
                    ereignisse.melden("waechter", "Kamera %s: %s" % (k["name"], fehler), False)
                self.fehler[k["id"]] = str(fehler)

    def _schleife(self):
        while not self._halt.wait(30):
            try:
                self.runde()
            except Exception:
                log.exception("Kameras: Ueberwachung")
