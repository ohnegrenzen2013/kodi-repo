"""Kataloge zur Auswahl (Sehen und Ab 18): Streaming-Anbieter, Reality, Shows, Konzerte und xREL.

  * Streaming-Anbieter: was gerade bei Netflix, Prime Video, Disney+, Apple TV+, HBO Max, Paramount+ oder Crunchyroll
    in Deutschland laeuft – aus dem freien Stremio-Addon "Streaming Catalogs" (ohne Konto, Land DE).
  * Reality, Shows, Konzerte: Reality-TV, Talk- und Spielshows aus Cinemeta (Serien), Konzertfilme und Musik ueber
    die Cinemeta-Suche.
  * xREL: die neuesten Scene-Releases je Kategorie (Filme, Serien, XXX fuer Ab 18) ueber die xREL-API v2, mit
    IMDb-Kennung, damit Filme und Serien direkt als Karten erscheinen. Dazu jeder RSS- oder Atom-Feed (ab Werk der
    Release-Feed von xREL), den man selbst eintraegt.

  * Listen von MDBList und Trakt (Idee aus ARVIO): oeffentliche Listen per Adresse eintragen oder suchen; sie erscheinen
    als Katalog. MDBList braucht einen kostenlosen API-Schluessel (mdblist.com/preferences), Trakt die Client ID der
    Trakt-App (trakt.py).
  * Durchstoeberbare Kataloge eigener Stremio-Addons (anbindungen_stremio.py) und eigene Quellen fuer Filme/Serien
    (eigene_quelle.py: eine Webseite per Adresse eintragen, Titel werden gegen Cinemeta abgeglichen).
  * TMDb-Reihen (nur mit eingetragenem Schluessel, tmdb.py): "Top 10 heute" (echte Tagesrangliste), ein
    Jahrzehnt (Discover mit Datumsbereich) oder ein Franchise (Collection-Suche) - rein optional, ohne
    Schluessel bleiben diese Reihen einfach aus.

Alles wird 30 Minuten zwischengespeichert. Eigene Feeds, Listen und Quellen liegen in den Nutzerdaten unter
"kataloge": {"feeds": [...], "listen": [{name, url}], "quellen": [{name, url, muster, typ, aktiv}], "mdblist_key": "..."}.
"""

import base64
import json
import logging
import threading
import time
from datetime import date, timedelta
from urllib.parse import quote

from . import eigene_quelle, tmdb
from .entdecken import karte
from .kataloge_aendern import aendern
from .kataloge_feeds import _EINTRAG, _feld, feed_lesen
from .kataloge_grund import *
from .kataloge_grund import (_MDBLIST, _TRAKT, _mdblist_karte, _mdblist_key, _trakt_id, _trakt_karte,
                             _trakt_kopf)
from .kataloge_anbieter import KatalogeAnbieterMixin
from .kataloge_listen import KatalogeListenMixin

log = logging.getLogger("rezeptserver")


class Kataloge(KatalogeListenMixin, KatalogeAnbieterMixin):
    def __init__(self, abrufer, uhr=time.time, addons=lambda: None, tmdb_klient=lambda: None):
        self.abrufer = abrufer  # .abruf(url) -> Text (geht ueber den Netzweg)
        self.uhr = uhr
        self.addons = addons  # liefert die aktuellen Fremd-Addons der App (oder None)
        self.tmdb_klient = tmdb_klient  # liefert den tmdb.Tmdb-Klienten der App (oder None, falls nicht verdrahtet)
        self._speicher = {}
        self._sperre = threading.Lock()

    def _holen(self, url, kopf=None, heimnetz_erlaubt=False):
        with self._sperre:
            alt = self._speicher.get(url)
            if alt and self.uhr() - alt[0] < ZEIT:
                return alt[1]
        # heimnetz_erlaubt nur bei Bedarf mitgeben: der Abrufer in den Tests kennt nur abruf(url[, kopf])
        zusatz = {"heimnetz_erlaubt": True} if heimnetz_erlaubt else {}
        text = self.abrufer.abruf(url, kopf, **zusatz) if kopf else self.abrufer.abruf(url, **zusatz)
        with self._sperre:
            if len(self._speicher) > 200:
                self._speicher.clear()
            self._speicher[url] = (self.uhr(), text)
        return text

    def _json(self, url, kopf=None):
        try:
            return json.loads(self._holen(url, kopf))
        except ValueError:
            raise KatalogFehler("Keine gültige Antwort von %s" % url.split("/")[2])

    def uebersicht(self, daten=None):
        return {"streaming": [{"id": k, "name": n} for k, n in STREAMING], "dienste": dienste(daten),
                "themen": [{"id": k, "name": v[0], "typ": v[1]} for k, v in THEMEN.items()],
                "xrel": [{"id": k, "name": "xREL: neu (%s)" % v[2]} for k, v in XREL_ARTEN.items()],
                "feeds": feeds(daten), "listen": listen(daten), "addons": self._addon_liste(),
                "quellen": eigene_quelle.quellen(daten),
                "mdblist": bool(_mdblist_key(daten)), "trakt": bool(_trakt_id(daten)), "tmdb": tmdb.konfiguriert(daten),
                "tmdb_franchises": tmdb.FRANCHISES, "anbieter": self.anbieter_liste(daten)}

    def _addon_liste(self):
        addons = self.addons()
        if not addons:
            return []
        try:
            return addons.katalog_liste()
        except Exception as fehler:  # die Uebersicht darf daran nicht scheitern
            log.warning("Addon-Kataloge nicht lesbar: %s", fehler)
            return []

    def addon_liste(self):
        """Durchstoeberbare Addon-Kataloge (oeffentlich fuer Sammlungen)."""
        return self._addon_liste()

    # --- Streaming-Anbieter -----------------------------------------------------------------------
    def streaming(self, anbieter, typ):
        if anbieter not in dict(STREAMING):
            raise KatalogFehler("Unbekannter Anbieter")
        if typ not in ("movie", "series"):
            raise KatalogFehler("Typ movie oder series")
        konfig = base64.b64encode((",".join(k for k, _ in STREAMING) + "::" + LAND).encode()).decode()
        metas = self._json("%s/%s/catalog/%s/%s.json" % (STREAMING_ADDON, quote(konfig, safe=""), typ, anbieter)).get("metas") or []
        titel = []
        for m in metas:
            if isinstance(m, dict) and (m.get("imdb_id") or m.get("id")):
                m = dict(m, id=m.get("imdb_id") or m.get("id"))
                k = karte(m, typ)
                if not k["poster"] and k["id"].startswith("tt"):
                    k["poster"] = POSTER % k["id"]
                titel.append(k)
        return {"titel": titel, "mehr": False, "name": dict(STREAMING)[anbieter]}

    # --- TMDb-Reihen (optional, nur mit eingetragenem Schluessel - tmdb.py) ------------------------
    def _tmdb(self, daten):
        schluessel = tmdb.schluessel(daten)
        if not schluessel:
            raise KatalogFehler("Für diese Reihe erst den TMDb-Schlüssel eintragen (Einstellungen → Konten)")
        klient = self.tmdb_klient()
        if not klient:
            raise KatalogFehler("TMDb ist auf diesem Server nicht eingerichtet")
        return klient, schluessel

    def tmdb_trending(self, typ, daten=None):
        """Top 10 heute (/trending/movie|tv/day) - echte Tagesrangliste, kein erfundenes Ranking."""
        if typ not in ("movie", "series"):
            raise KatalogFehler("Typ movie oder series")
        klient, schluessel = self._tmdb(daten)
        try:
            titel = klient.trending(typ, schluessel)
        except tmdb.TmdbFehler as fehler:
            raise KatalogFehler(str(fehler))
        return {"titel": titel[:10], "mehr": False, "name": "Top 10 heute"}

    def jahrzehnt(self, typ, dekade, skip=0, daten=None):
        if typ not in ("movie", "series"):
            raise KatalogFehler("Typ movie oder series")
        try:
            start = int(dekade)
        except (TypeError, ValueError):
            raise KatalogFehler("Jahrzehnt ungültig")
        klient, schluessel = self._tmdb(daten)
        try:
            skip = max(0, int(skip or 0))
        except (TypeError, ValueError):
            skip = 0
        feld = "primary_release_date" if typ == "movie" else "first_air_date"
        try:
            titel = klient.discover(typ, schluessel, sort_by="popularity.desc", page=skip // 20 + 1,
                                    **{feld + ".gte": "%d-01-01" % start, feld + ".lte": "%d-12-31" % (start + 9)})
        except tmdb.TmdbFehler as fehler:
            raise KatalogFehler(str(fehler))
        # TMDb-Seiten haben 20 Treffer; discover() filtert danach noch auf eine gueltige IMDb-Zuordnung -
        # "mehr" ist deshalb eine Naeherung (fast volle Seite), kein exakter Seitenzaehler von TMDb selbst.
        return {"titel": titel, "mehr": len(titel) >= 15, "weiter": skip + 20, "name": "%ser" % start}

    def demnaechst(self, typ, daten=None):
        """Netflix-Vorbild "Demnaechst verfuegbar": TMDb-Discover auf die naechsten 60 Tage begrenzt,
        aufsteigend nach Erscheinungsdatum sortiert - echte kommende Termine, nichts erfunden."""
        if typ not in ("movie", "series"):
            raise KatalogFehler("Typ movie oder series")
        klient, schluessel = self._tmdb(daten)
        feld = "primary_release_date" if typ == "movie" else "first_air_date"
        heute, bis = date.today(), date.today() + timedelta(days=60)
        try:
            titel = klient.discover(typ, schluessel, sort_by=feld + ".asc",
                                    **{feld + ".gte": heute.isoformat(), feld + ".lte": bis.isoformat()})
        except tmdb.TmdbFehler as fehler:
            raise KatalogFehler(str(fehler))
        return {"titel": titel, "mehr": False, "name": "Demnächst verfügbar"}

    def tmdb_franchise(self, name, daten=None):
        klient, schluessel = self._tmdb(daten)
        try:
            gefunden = klient.collection_suche(name, schluessel)
            if not gefunden:
                raise KatalogFehler("Kein Franchise mit diesem Namen gefunden")
            titel = klient.collection(gefunden["id"], schluessel)
        except tmdb.TmdbFehler as fehler:
            raise KatalogFehler(str(fehler))
        return {"titel": titel, "mehr": False, "name": str(gefunden.get("name") or name)}

    def tmdb_zusatz(self, tmdb_id, typ, daten=None):
        """Budget/FSK/Streaming-Anbieter zu einem schon bekannten Titel (entdecken.details()s "tmdb"-Feld)."""
        if typ not in ("movie", "series"):
            raise KatalogFehler("Typ movie oder series")
        if not str(tmdb_id or "").strip():
            raise KatalogFehler("Keine TMDb-Id")
        klient, schluessel = self._tmdb(daten)
        try:
            return klient.film_zusatz(tmdb_id, typ, schluessel)
        except tmdb.TmdbFehler as fehler:
            raise KatalogFehler(str(fehler))

    # --- Fremde Stremio-Addons (durchstoeberbare Kataloge, nicht nur ihre Suchkataloge) ------------
    def addon(self, addon_id, typ, katalog, genre="", skip=0):
        addons = self.addons()
        if not addons:
            raise KatalogFehler("Kein Addon eingetragen")
        try:
            skip = max(0, int(skip or 0))
        except (TypeError, ValueError):
            skip = 0
        schluessel = ("addon", addon_id, typ, katalog, genre, skip)
        with self._sperre:
            alt = self._speicher.get(schluessel)
            if alt and self.uhr() - alt[0] < ZEIT:
                return alt[1]
        try:
            metas = addons.katalog_holen(addon_id, typ, katalog, genre, skip)
        except (ValueError, KeyError) as fehler:
            raise KatalogFehler(str(fehler))
        eintrag = next((a for a in addons.katalog_liste() if a["addon"] == addon_id
                        and a["typ"] == typ and a["katalog"] == katalog), None)
        name = "%s: %s" % (eintrag["addon_name"], eintrag["name"]) if eintrag else addon_id
        titel = []
        for m in metas:
            k = karte(m, typ)
            if not k["poster"] and k["id"].startswith("tt"):
                k["poster"] = POSTER % k["id"]
            titel.append(k)
        ergebnis = {"titel": titel, "mehr": bool(eintrag and eintrag["blaettern"] and len(metas) >= 20),
                    "weiter": skip + len(metas), "name": name, "quelle": eintrag["addon_name"] if eintrag else addon_id}
        with self._sperre:
            if len(self._speicher) > 200:
                self._speicher.clear()
            self._speicher[schluessel] = (self.uhr(), ergebnis)
        return ergebnis

    # --- Themen (Cinemeta) ------------------------------------------------------------------------
    def thema(self, tid, skip=0):
        if tid not in THEMEN:
            raise KatalogFehler("Unbekannter Katalog")
        name, typ, art = THEMEN[tid]
        if "genre" in art:
            extra = "genre=%s" % quote(art["genre"], safe="") + ("&skip=%d" % int(skip) if skip else "")
            metas = self._json("%s/catalog/%s/top/%s.json" % (CINEMETA, typ, extra)).get("metas") or []
            titel = [karte(m, typ) for m in metas if isinstance(m, dict) and m.get("id")]
            return {"titel": titel, "mehr": len(metas) >= 20, "weiter": int(skip or 0) + len(metas), "name": name}
        titel, gesehen = [], set()
        for wort in art["suche"]:
            try:
                metas = self._json("%s/catalog/%s/top/search=%s.json" % (CINEMETA, typ, quote(wort, safe=""))).get("metas") or []
            except Exception:  # eine Suche darf fehlen
                continue
            for m in metas:
                if isinstance(m, dict) and m.get("id") and m["id"] not in gesehen:
                    gesehen.add(m["id"])
                    titel.append(karte(m, typ))
        return {"titel": titel, "mehr": False, "name": name}

    # --- xREL -------------------------------------------------------------------------------------
    def xrel(self, art, seite=1):
        if art not in XREL_ARTEN:
            raise KatalogFehler("xREL: movie, series oder xxx")
        kategorie, typ, name = XREL_ARTEN[art]
        try:
            seite = max(1, min(50, int(seite or 1)))
        except (TypeError, ValueError):
            seite = 1
        d = self._json("%s/release/browse_category.json?category_name=%s&ext_info_type=%s&per_page=100&page=%d" % (XREL, kategorie, typ, seite))
        titel, nach_id = [], {}
        for r in d.get("list") or []:
            info = r.get("ext_info") or {}
            imdb = next((u[5:] for u in info.get("uris") or [] if isinstance(u, str) and u.startswith("imdb:tt")), "")
            schluessel = info.get("id") or r.get("dirname")
            release = {"name": r.get("dirname", ""), "zeit": r.get("time", 0), "link": r.get("link_href", ""),
                       "groesse": "%s %s" % ((r.get("size") or {}).get("number", ""), (r.get("size") or {}).get("unit", "")),
                       "folge": "S%02dE%02d" % (r["tv_season"], r["tv_episode"]) if r.get("tv_season") and r.get("tv_episode") else ""}
            if schluessel in nach_id:
                nach_id[schluessel]["releases"].append(release)
                continue
            eintrag = {"id": imdb or "", "typ": "series" if art == "series" else "movie", "titel": info.get("title") or r.get("dirname", ""),
                       "jahr": "", "bewertung": "", "poster": POSTER % imdb if imdb else "", "hintergrund": "", "logo": "",
                       "genres": [], "beschreibung": "", "quelle": "xREL", "xrel": info.get("link_href", ""), "releases": [release]}
            nach_id[schluessel] = eintrag
            titel.append(eintrag)
        seiten = (d.get("pagination") or {}).get("total_pages", 1)
        return {"titel": titel, "mehr": seite < seiten, "weiter": seite + 1, "name": "xREL – neu: " + name, "quelle": "Daten: xREL.to"}

    # --- RSS/Atom ---------------------------------------------------------------------------------
    def feed(self, url, daten=None):
        eintrag = next((f for f in feeds(daten) if f["url"] == url), None)
        if not eintrag:
            raise KatalogFehler("Diesen Feed erst unter Kataloge eintragen")
        text = self._holen(url, heimnetz_erlaubt=eintrag.get("heimnetz_erlaubt", False))
        return {"eintraege": feed_lesen(text)[:100], "name": eintrag["name"]}
