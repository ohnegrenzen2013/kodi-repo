"""Kataloge: Feeds, Listen, Quellen und Schluessel aendern."""

import re

from . import eigene_quelle, streaming_dienste, tmdb
from .kataloge_grund import (KatalogFehler, MAX_FEEDS, MAX_LISTEN, SCHLUESSEL, _MDBLIST, _TRAKT,
                             _mdblist_key, feeds, listen)


def aendern(daten, wunsch):
    """{feed_dazu: {name, url}} | {feed_weg: url} | {liste_dazu: {name, url}} | {liste_weg: url}
    | {quelle_dazu: {name, url, muster?, typ?}} | {quelle_weg: url} | {mdblist_key: text} | {tmdb_key: text}
    | {dienst_dazu: {name, seite, suche?, katalog?, art?, symbol?, farbe?, id?}} | {dienst_weg: id}"""
    e = dict(daten.get(SCHLUESSEL) or {})
    if "mdblist_key" in wunsch:
        schluessel = str(wunsch.get("mdblist_key") or "").strip()
        if len(schluessel) > 100 or not re.match(r"^[\w-]*$", schluessel):
            raise KatalogFehler("Ungültiger MDBList-Schlüssel")
        e["mdblist_key"] = schluessel
    if "tmdb_key" in wunsch:
        tmdb.einstellen(daten, {"api_key": wunsch.get("tmdb_key")})
    if isinstance(wunsch.get("liste_dazu"), dict) or "liste_weg" in wunsch:
        eigene = listen({SCHLUESSEL: e})
        if isinstance(wunsch.get("liste_dazu"), dict):
            url = str(wunsch["liste_dazu"].get("url") or "").strip()[:300].rstrip("/")
            m = _MDBLIST.match(url) or _TRAKT.match(url.split("?")[0])
            if not m:
                raise KatalogFehler("Adresse einer Liste: https://mdblist.com/lists/NAME/LISTE oder https://trakt.tv/users/NAME/lists/LISTE")
            url = url.split("?")[0]
            if len(eigene) >= MAX_LISTEN:
                raise KatalogFehler("Höchstens %d Listen" % MAX_LISTEN)
            name = " ".join(str(wunsch["liste_dazu"].get("name") or "").split())[:60] or m.group(2).replace("-", " ")
            eigene = [x for x in eigene if x["url"] != url] + [{"name": name, "url": url}]
        if "liste_weg" in wunsch:
            eigene = [x for x in eigene if x["url"] != wunsch["liste_weg"]]
        e["listen"] = eigene
    liste = [f for f in (e.get("feeds") or []) if isinstance(f, dict)]
    if isinstance(wunsch.get("feed_dazu"), dict):
        url = str(wunsch["feed_dazu"].get("url") or "").strip()[:500]
        if not re.match(r"^https?://[^\s/]+", url):
            raise KatalogFehler("Feed-Adresse mit http(s)://")
        if len(liste) >= MAX_FEEDS:
            raise KatalogFehler("Höchstens %d eigene Feeds" % MAX_FEEDS)
        name = " ".join(str(wunsch["feed_dazu"].get("name") or "").split())[:40] or url.split("/")[2]
        neu = {"name": name, "url": url}
        if wunsch["feed_dazu"].get("heimnetz_erlaubt"):
            neu["heimnetz_erlaubt"] = True
        liste = [f for f in liste if f.get("url") != url] + [neu]
    if "feed_weg" in wunsch:
        liste = [f for f in liste if f.get("url") != wunsch["feed_weg"]]
    e["feeds"] = liste
    if isinstance(wunsch.get("quelle_dazu"), dict) or "quelle_weg" in wunsch:
        try:
            eigene_quelle.aendern(e, wunsch)
        except eigene_quelle.KatalogFehler as fehler:
            raise KatalogFehler(str(fehler))
    if isinstance(wunsch.get("dienst_dazu"), dict) or "dienst_weg" in wunsch:
        try:
            e["dienste"] = streaming_dienste.aendern(e.get("dienste"), wunsch)
        except ValueError as fehler:
            raise KatalogFehler(str(fehler))
    daten[SCHLUESSEL] = e
    return {"feeds": feeds(daten), "listen": listen(daten), "quellen": eigene_quelle.quellen(daten),
            "dienste": streaming_dienste.mit_eigenen(e.get("dienste")),
            "mdblist": bool(_mdblist_key(daten)), "tmdb": tmdb.konfiguriert(daten)}
