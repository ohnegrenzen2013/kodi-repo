"""Kataloge: TMDb-Discover je Streaming-Anbieter in Deutschland.

Die Anbieter-IDs werden nicht geraten, sondern aus TMDbs Anbieterliste fuer DE
(/watch/providers/movie?watch_region=DE) gelesen und ueber das bestehende
streaming_dienste-Verzeichnis den H0rSt-Diensten Joyn, RTL+, WOW, waipu.tv und
Pluto TV zugeordnet. Fehlt ein Anbieter bei TMDb, bleibt seine Reihe einfach aus.
"""

from . import streaming_dienste
from .kataloge_grund import ZEIT, KatalogFehler
from .tmdb import TmdbFehler

ANBIETER = ("joyn", "rtlplus", "wow", "waipu", "pluto")


class KatalogeAnbieterMixin:
    def _tmdb_anbieter(self, daten):
        klient, schluessel = self._tmdb(daten)
        stelle = ("tmdb-anbieter", "DE")
        with self._sperre:
            alt = self._speicher.get(stelle)
            if alt and self.uhr() - alt[0] < ZEIT:
                return alt[1]
        try:
            roh = klient.watch_providers("movie", schluessel)
        except TmdbFehler as fehler:
            raise KatalogFehler(str(fehler))
        ids = {}
        for eintrag in roh:
            dienst = streaming_dienste.finde(eintrag.get("provider_name"))
            if dienst and dienst["id"] in ANBIETER and dienst["id"] not in ids:
                ids[dienst["id"]] = {"provider_id": eintrag.get("provider_id"), "name": dienst["name"]}
        with self._sperre:
            self._speicher[stelle] = (self.uhr(), ids)
        return ids

    def anbieter_liste(self, daten=None):
        try:
            ids = self._tmdb_anbieter(daten)
        except KatalogFehler:
            return []
        return [{"id": kennung, "name": ids[kennung]["name"]} for kennung in ANBIETER if kennung in ids]

    def tmdb_anbieter(self, kennung, typ, skip=0, daten=None):
        if typ not in ("movie", "series"):
            raise KatalogFehler("Typ movie oder series")
        try:
            skip = max(0, int(skip or 0))
        except (TypeError, ValueError):
            skip = 0
        ids = self._tmdb_anbieter(daten)
        if kennung not in ids:
            raise KatalogFehler("Kein TMDb-Anbieter fuer %s in Deutschland" % kennung)
        klient, schluessel = self._tmdb(daten)
        seite = skip // 20 + 1
        try:
            titel, seiten = klient.discover_seite(
                typ, schluessel, with_watch_providers=str(ids[kennung]["provider_id"]),
                watch_region="DE", sort_by="popularity.desc", page=seite)
        except TmdbFehler as fehler:
            raise KatalogFehler(str(fehler))
        return {"titel": titel, "mehr": seite < seiten, "weiter": skip + 20,
                "name": "Bei %s" % ids[kennung]["name"]}
