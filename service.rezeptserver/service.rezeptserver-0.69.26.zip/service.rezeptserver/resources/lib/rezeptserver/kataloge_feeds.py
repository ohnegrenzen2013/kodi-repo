"""Kataloge: RSS- und Atom-Feeds lesen."""

import html
import re


_EINTRAG = re.compile(r"<(item|entry)\b.*?</\1>", re.S | re.I)


def _feld(xml, *namen):
    for n in namen:
        m = re.search(r"<%s\b[^>]*>(.*?)</%s>" % (n, n), xml, re.S | re.I)
        if m:
            text = re.sub(r"^<!\[CDATA\[(.*)\]\]>$", r"\1", m.group(1).strip(), flags=re.S)
            return html.unescape(re.sub(r"<[^>]+>", " ", text)).strip()
    return ""


def feed_lesen(xml):
    """RSS 2.0 und Atom -> [{titel, link, zeit, text}]"""
    eintraege = []
    for m in _EINTRAG.finditer(xml or ""):
        x = m.group(0)
        link = _feld(x, "link")
        if not link:
            h = re.search(r"<link\b[^>]*href\s*=\s*[\"']([^\"']+)", x, re.I)
            link = html.unescape(h.group(1)) if h else ""
        eintraege.append({"titel": " ".join(_feld(x, "title").split())[:300], "link": link if link.startswith(("http://", "https://")) else "",
                          "zeit": _feld(x, "pubDate", "updated", "published", "dc:date"), "text": " ".join(_feld(x, "description", "summary").split())[:300]})
    return eintraege
