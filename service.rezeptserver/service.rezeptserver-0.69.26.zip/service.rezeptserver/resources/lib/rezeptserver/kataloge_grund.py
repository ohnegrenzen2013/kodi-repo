"""Kataloge: Konstanten, Fehler und gemeinsame Helfer."""

import re

from . import streaming_dienste

STREAMING_ADDON = "https://7a82163c306e-stremio-netflix-catalog-addon.baby-beamup.club"
LAND = "DE"
STREAMING = [("nfx", "Netflix"), ("amp", "Prime Video"), ("dnp", "Disney+"), ("atp", "Apple TV+"), ("hbm", "HBO Max"),
             ("pmp", "Paramount+"), ("cru", "Crunchyroll"), ("sgo", "Sky Go"), ("mbi", "Mubi"), ("sst", "SkyShowtime")]
CINEMETA = "https://v3-cinemeta.strem.io"
# Katalog-id: (Name, Typ, Cinemeta-Genre oder Suchbegriffe)
THEMEN = {
    "reality": ("Reality", "series", {"genre": "Reality-TV"}),
    "talkshow": ("Talkshows", "series", {"genre": "Talk-Show"}),
    "spielshow": ("Spielshows", "series", {"genre": "Game-Show"}),
    "konzerte": ("Konzerte & Musik", "movie", {"suche": ["concert", "live in concert", "world tour", "unplugged", "live at"]}),
    "dokus": ("Dokus", "movie", {"genre": "Documentary"}),
}
XREL = "https://api.xrel.to/v2"
XREL_ARTEN = {"movie": ("MOVIES", "movie", "Filme"), "series": ("TV", "tv", "Serien"), "xxx": ("XXX", "xxx", "Ab 18")}
XREL_FEED = "https://www.xrel.to/feeds/atom/releases.xml"
SCHLUESSEL = "kataloge"
MAX_FEEDS = 12
MAX_LISTEN = 30
MDBLIST_API = "https://api.mdblist.com"
TRAKT_API = "https://api.trakt.tv"
_MDBLIST = re.compile(r"^https?://(?:www\.)?mdblist\.com/lists/([\w.-]+)/([\w.-]+)/?$")
_TRAKT = re.compile(r"^https?://(?:www\.|app\.)?trakt\.tv/users/([\w.-]+)/lists/([\w.-]+)/?(?:\?.*)?$")
ZEIT = 1800
POSTER = "https://images.metahub.space/poster/medium/%s/img"


class KatalogFehler(ValueError):
    pass


def _mdblist_key(daten):
    return str(((daten or {}).get(SCHLUESSEL) or {}).get("mdblist_key") or "")


def _trakt_id(daten):
    t = (daten or {}).get("trakt")
    return str(((t.get("app") or {}) if isinstance(t, dict) else {}).get("client_id") or "")


def _trakt_kopf(daten):
    if not _trakt_id(daten):
        raise KatalogFehler("Für Trakt-Listen erst die Trakt-App eintragen (Einstellungen → Trakt, MDBList & Google Drive)")
    return {"trakt-api-version": "2", "trakt-api-key": _trakt_id(daten), "Content-Type": "application/json"}


def _mdblist_karte(x):
    if not isinstance(x, dict) or not str(x.get("imdb_id") or "").startswith("tt"):
        return None
    typ = "series" if x.get("mediatype") in ("show", "series", "tv") else "movie"
    return {"id": x["imdb_id"], "typ": typ, "titel": str(x.get("title") or x["imdb_id"]), "jahr": str(x.get("release_year") or ""),
            "bewertung": "", "poster": POSTER % x["imdb_id"], "hintergrund": "", "logo": "", "genres": [], "beschreibung": "", "laufzeit": ""}


def _trakt_karte(x):
    if not isinstance(x, dict) or x.get("type") not in ("movie", "show"):
        return None
    t = x.get(x["type"]) or {}
    imdb = str((t.get("ids") or {}).get("imdb") or "")
    if not imdb.startswith("tt"):
        return None
    return {"id": imdb, "typ": "series" if x["type"] == "show" else "movie", "titel": str(t.get("title") or imdb),
            "jahr": str(t.get("year") or ""), "bewertung": "", "poster": POSTER % imdb, "hintergrund": "", "logo": "",
            "genres": [], "beschreibung": "", "laufzeit": ""}


def listen(daten):
    eigene = ((daten or {}).get(SCHLUESSEL) or {}).get("listen") or []
    return [x for x in eigene if isinstance(x, dict) and x.get("url")]


def feeds(daten):
    eigene = ((daten or {}).get(SCHLUESSEL) or {}).get("feeds") or []
    return [{"name": "xREL Releases", "url": XREL_FEED, "fest": True}] + [f for f in eigene if isinstance(f, dict) and f.get("url")]


def dienste(daten):
    """Eingebaute Streaming-/Musik-/Mediathek-Dienste plus eigene aus kataloge.dienste."""
    eigene = ((daten or {}).get(SCHLUESSEL) or {}).get("dienste") or []
    return streaming_dienste.mit_eigenen(eigene)
