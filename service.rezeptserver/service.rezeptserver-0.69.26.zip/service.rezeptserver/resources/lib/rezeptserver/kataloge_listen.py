"""Kataloge: oeffentliche Listen von MDBList und Trakt."""

import re
from urllib.parse import quote, urlencode

from .kataloge_grund import (KatalogFehler, MDBLIST_API, TRAKT_API, _MDBLIST, _TRAKT, _mdblist_karte,
                             _mdblist_key, _trakt_id, _trakt_karte, _trakt_kopf, listen)


class KatalogeListenMixin:
    """Listen von MDBList und Trakt."""

    # --- Listen von MDBList und Trakt --------------------------------------------------------------------------------
    def liste(self, url, daten=None):
        eintrag = next((x for x in listen(daten) if x["url"] == url), None)
        if not eintrag:
            raise KatalogFehler("Diese Liste erst unter Kataloge eintragen")
        m = _MDBLIST.match(url)
        if m:
            schluessel = _mdblist_key(daten)
            if not schluessel:
                raise KatalogFehler("Für MDBList-Listen erst den API-Schlüssel eintragen (Einstellungen → Trakt, MDBList & Google Drive)")
            d = self._json("%s/lists/%s/%s/items?%s" % (MDBLIST_API, quote(m.group(1)), quote(m.group(2)),
                                                        urlencode({"apikey": schluessel, "limit": 200})))
            roh = (d.get("movies") or []) + (d.get("shows") or []) if isinstance(d, dict) else d if isinstance(d, list) else []
            titel = [k for k in (_mdblist_karte(x) for x in roh) if k]
        else:
            m = _TRAKT.match(url)
            d = self._json("%s/users/%s/lists/%s/items?limit=200" % (TRAKT_API, quote(m.group(1)), quote(m.group(2))), _trakt_kopf(daten))
            titel = [k for k in (_trakt_karte(x) for x in (d if isinstance(d, list) else [])) if k]
        return {"titel": titel, "mehr": False, "name": eintrag["name"], "quelle": "MDBList" if _MDBLIST.match(url) else "Trakt"}

    def trakt_liste(self, liste_id, seite=1, daten=None):
        """Oeffentliche Trakt-Liste per numerischer Kennung (auch fuer Sammlungen, ohne Eintrag unter Kataloge)."""
        kennung = str(liste_id or "").strip()
        if not kennung.isdigit():
            raise KatalogFehler("Ungültige Trakt-Liste")
        try:
            seite = max(1, min(1000, int(seite or 1)))
        except (TypeError, ValueError):
            seite = 1
        d = self._json("%s/lists/%s/items?limit=100&page=%d" % (TRAKT_API, kennung, seite), _trakt_kopf(daten))
        return [k for k in (_trakt_karte(x) for x in (d if isinstance(d, list) else [])) if k]

    def mdblist_liste(self, slug, seite=1, daten=None):
        """Oeffentliche MDBList-Liste per user/slug (auch fuer Sammlungen, ohne Eintrag unter Kataloge)."""
        treffer = re.fullmatch(r"([\w.-]+)/([\w.-]+)", str(slug or "").strip())
        if not treffer:
            raise KatalogFehler("Ungültige MDBList-Liste (user/liste)")
        schluessel = _mdblist_key(daten)
        if not schluessel:
            raise KatalogFehler("Für MDBList-Listen erst den API-Schlüssel eintragen (Einstellungen → Trakt, MDBList & Google Drive)")
        try:
            seite = max(1, min(1000, int(seite or 1)))
        except (TypeError, ValueError):
            seite = 1
        d = self._json("%s/lists/%s/%s/items?%s" % (MDBLIST_API, quote(treffer.group(1)), quote(treffer.group(2)),
                                                     urlencode({"apikey": schluessel, "limit": 200, "page": seite})))
        roh = (d.get("movies") or []) + (d.get("shows") or []) if isinstance(d, dict) else d if isinstance(d, list) else []
        return [k for k in (_mdblist_karte(x) for x in roh) if k]

    def listen_suchen(self, text, daten=None):
        """Oeffentliche Listen auf MDBList und Trakt zum Eintragen: [{name, url, quelle, anzahl, von}]."""
        text = " ".join(str(text or "").split())[:80]
        if len(text) < 2:
            raise KatalogFehler("Mindestens zwei Zeichen")
        gefunden = []
        if _mdblist_key(daten):
            d = self._json("%s/lists/search?%s" % (MDBLIST_API, urlencode({"query": text, "apikey": _mdblist_key(daten)})))
            for x in (d if isinstance(d, list) else (d or {}).get("lists") or [])[:20]:
                if isinstance(x, dict) and x.get("slug") and x.get("user_name"):
                    gefunden.append({"name": str(x.get("name") or x["slug"]), "quelle": "MDBList", "anzahl": x.get("items"),
                                     "von": str(x["user_name"]), "url": "https://mdblist.com/lists/%s/%s" % (x["user_name"], x["slug"])})
        if _trakt_id(daten):
            d = self._json("%s/search/list?%s" % (TRAKT_API, urlencode({"query": text, "limit": 20})), _trakt_kopf(daten))
            for x in d if isinstance(d, list) else []:
                l = (x or {}).get("list") or {}
                benutzer = ((l.get("user") or {}).get("ids") or {}).get("slug")
                slug = (l.get("ids") or {}).get("slug")
                if benutzer and slug:
                    gefunden.append({"name": str(l.get("name") or slug), "quelle": "Trakt", "anzahl": l.get("item_count"),
                                     "von": str(benutzer), "url": "https://trakt.tv/users/%s/lists/%s" % (benutzer, slug)})
        if not _mdblist_key(daten) and not _trakt_id(daten):
            raise KatalogFehler("Erst den MDBList-Schlüssel oder die Trakt-App eintragen")
        return {"listen": gefunden}
