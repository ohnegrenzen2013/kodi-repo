"""Oeffentliche Kennung fuer Geraete in Raeumen (Party, Gemeinsam schauen).

Die Geraete-Kennung (sid) ist wie ein Schluessel: wer sie kennt, handelt im Namen des Geraets – auch als Gastgeber. Andere
Geraete sehen deshalb nur eine davon abgeleitete Kennung, aus der sich die sid nicht zurueckrechnen laesst (HMAC mit einem
Geheimnis, das bei jedem Start neu entsteht; die Raeume leben ohnehin nur im Speicher). Wer auf jemanden zeigt (zulassen,
fuer jemanden zahlen, Aufgabe stellen), schickt diese oeffentliche Kennung; finden() macht daraus wieder die sid.
"""

import hashlib
import hmac
import secrets

_GEHEIM = secrets.token_bytes(16)


def oeffentlich(sid):
    return "p" + hmac.new(_GEHEIM, str(sid).encode("utf-8"), hashlib.sha256).hexdigest()[:16] if sid else ""


def dauerhaft(sid):
    """Kennung, die auch nach einem Neustart gleich bleibt (fuer Gespeichertes wie die Daumen bei Gutscheinen)."""
    return hashlib.sha256(("h0rst-geraet:" + str(sid)).encode("utf-8")).hexdigest()[:16]


def verbergen(daten, sids):
    """Ersetzt in einer Ansicht jede bekannte sid (als Wert, auch verschachtelt) durch ihre oeffentliche Kennung."""
    karte = {s: oeffentlich(s) for s in sids if s}

    def tausch(x):
        if isinstance(x, str):
            return karte.get(x, x)
        if isinstance(x, dict):
            return {k: tausch(v) for k, v in x.items()}
        if isinstance(x, (list, tuple)):
            return [tausch(v) for v in x]
        return x
    return tausch(daten)


def finden(kennung, sids):
    """Die sid zu einer oeffentlichen Kennung (oder zur sid selbst) unter den gegebenen; sonst ""."""
    kennung = str(kennung or "")
    if not kennung:
        return ""
    return next((s for s in sids if kennung in (s, oeffentlich(s))), "")
