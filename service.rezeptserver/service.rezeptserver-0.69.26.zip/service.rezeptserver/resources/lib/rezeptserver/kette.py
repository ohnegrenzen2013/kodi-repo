"""Ketten bilden und ausfuehren: Finder -> Aufloeser -> Anreicherer."""

import base64
import logging
from concurrent.futures import ThreadPoolExecutor, TimeoutError as ZeitUeberschritten, wait

from .netz import Abrufer, domain_erlaubt, urllib_holen
from .schritte import Kontext, fuehre_aus

log = logging.getLogger("rezeptserver")

ZEITGRENZEN = {"finder": 8.0, "aufloeser": 10.0, "anreicherer": 4.0}
MAX_TREFFER_AUFLOESEN = 15


class FehlendeEinstellung(Exception):
    """Ein Modul wird nicht ausgefuehrt, weil Pflicht-Einstellungen fehlen."""


class HostApi:
    """Was ein Skript (Notausgang) vom Host bekommt: nur der gepruefte Abruf."""

    def __init__(self, abrufer):
        self.abruf = abrufer.abruf


class Kette:
    def __init__(self, module, einstellungen=None, zeitgrenzen=None, holen=urllib_holen, arbeiter=8):
        self.module = module
        self.einstellungen = einstellungen or {}
        self.zeitgrenzen = dict(ZEITGRENZEN, **(zeitgrenzen or {}))
        self.holen = holen
        # zwei Pools: Module laufen in self.pool, ganze Teilketten in self.ketten_pool,
        # damit wartende Teilketten nie die Plaetze der Module blockieren
        self.pool = ThreadPoolExecutor(max_workers=arbeiter, thread_name_prefix="rezept")
        self.ketten_pool = ThreadPoolExecutor(max_workers=arbeiter, thread_name_prefix="kette")
        self.zaehler = None  # nutzung.Nutzung.zaehler: Rangliste der Module (Abfragen, Treffer, Fehler)

    def _zaehlen(self, modul, treffer=0, fehler=False):
        if self.zaehler:
            try:
                self.zaehler("module", modul.name, treffer, fehler)
            except Exception:  # Statistik darf nie stoeren
                pass

    def rolle(self, name):
        return sorted((m for m in self.module if m.rolle == name), key=lambda m: m.rang)

    def fuehre_modul_aus(self, modul, eingabe, protokoll=None):
        roh = self.einstellungen.get(modul.konto, {})
        fehlt = modul.fehlende_einstellungen(roh)
        if fehlt:
            raise FehlendeEinstellung("Einstellung %s fehlt in den Nutzerdaten unter einstellungen.%s"
                                      % (", ".join(fehlt), modul.konto))
        werte = modul.sichtbare_einstellungen(roh)
        abrufer = Abrufer(modul.netz, holen=self.holen, zeitgrenze=self.zeitgrenzen.get(modul.rolle, 10.0))
        if modul.skript:
            ergebnis = modul.skript_funktion()(dict(eingabe), dict(werte), HostApi(abrufer))
            return list(ergebnis or [])
        return fuehre_aus(modul.schritte, Kontext(eingabe, werte, abrufer, protokoll))

    def _mit_zeitgrenze(self, modul, eingabe):
        zukunft = self.pool.submit(self.fuehre_modul_aus, modul, eingabe)
        try:
            return zukunft.result(timeout=self.zeitgrenzen.get(modul.rolle, 10.0))
        except ZeitUeberschritten:
            log.warning("%s: Zeitgrenze ueberschritten, uebersprungen", modul.id)
        except Exception as fehler:  # ein Modul darf die Kette nie abbrechen
            log.warning("%s: %s", modul.id, fehler)
        return []

    def suche(self, anfrage, nur=None):
        """Alle Finder (oder nur die genannten) parallel, Treffer nach quelle markiert."""
        finder = [m for m in self.rolle("finder") if nur is None or m.id in nur]
        if not finder:
            return []
        zukuenfte = {self.pool.submit(self.fuehre_modul_aus, m, anfrage): m for m in finder}
        fertig, offen = wait(zukuenfte, timeout=self.zeitgrenzen["finder"])
        for zukunft in offen:
            log.warning("%s: Zeitgrenze ueberschritten, uebersprungen", zukuenfte[zukunft].id)
            self._zaehlen(zukuenfte[zukunft], fehler=True)
        treffer = []
        for zukunft in fertig:
            modul = zukuenfte[zukunft]
            try:
                ergebnis = zukunft.result()
            except Exception as fehler:
                fehlt = isinstance(fehler, FehlendeEinstellung)  # nicht eingerichtet ist kein Fehler (Fehlerliste)
                (log.info if fehlt else log.warning)("%s: %s", modul.id, fehler)
                self._zaehlen(modul, fehler=not fehlt)
                continue
            self._zaehlen(modul, len(ergebnis or []))
            for eintrag in ergebnis:
                if not eintrag.get("titel") or not eintrag.get("ref"):
                    continue
                eintrag.setdefault("quelle", modul.id)
                eintrag["_finder"] = modul.id
                eintrag["_anbieter"] = modul.konto  # fuer Filter, landet nicht in der Stremio-ID
                treffer.append(eintrag)
        # stabile Reihenfolge: nach Rang des Finders
        rang = {m.id: m.rang for m in finder}
        treffer.sort(key=lambda t: rang.get(t["_finder"], 50))
        for eintrag in treffer:
            eintrag.pop("_finder", None)
        return treffer

    def aufloesen(self, treffer):
        """Passende Aufloeser nach Rang, bei Fehler der naechste (Synonyme)."""
        for modul in self.rolle("aufloeser"):
            if not modul.passt(treffer):
                continue
            streams = [s for s in self._mit_zeitgrenze(modul, treffer) if s.get("url")]
            streams = [s for s in (self.mit_zugang(modul, s) for s in streams) if s]
            if streams:
                for stream in streams:
                    stream.setdefault("_modul", modul.name)
                    stream["_netz"] = list(modul.netz)  # fuer die Wiedergabe ueber den Server
                return streams
        return []

    def mit_zugang(self, modul, stream):
        """auth: basic im Stream -> Zugangsdaten als Header, nie in der Adresse.

        Nur an Domains aus darf.netz und nur, wenn das Modul das Passwort sehen darf.
        """
        if stream.get("auth") != "basic":
            return stream
        stream = dict(stream)
        stream.pop("auth")
        werte = modul.sichtbare_einstellungen(self.einstellungen.get(modul.konto, {}))
        if "pass" not in werte or not domain_erlaubt(stream["url"], modul.netz):
            log.warning("%s: Zugangsdaten fuer %s nicht erlaubt, Stream verworfen", modul.id, stream["url"])
            return None
        paar = ("%s:%s" % (werte.get("user", ""), werte["pass"])).encode("utf-8")
        header = dict(stream.get("header") or {})
        header["Authorization"] = "Basic " + base64.b64encode(paar).decode("ascii")
        stream["header"] = header
        return stream

    def aufloesen_alle(self, treffer_liste):
        auswahl = treffer_liste[:MAX_TREFFER_AUFLOESEN]
        zukuenfte = [(t, self.ketten_pool.submit(self.aufloesen, t)) for t in auswahl]
        # eine gemeinsame Frist fuer alle: Erstversuch plus ein Ersatzmodul
        wait([z for _, z in zukuenfte], timeout=self.zeitgrenzen["aufloeser"] * 2)
        paare = []
        for eintrag, zukunft in zukuenfte:
            if not zukunft.done():
                log.warning("Aufloesen von %s dauert zu lange, uebersprungen", eintrag.get("titel"))
                continue
            try:
                streams = zukunft.result()
            except Exception as fehler:
                log.warning("Aufloesen von %s fehlgeschlagen: %s", eintrag.get("titel"), fehler)
                continue
            paare.extend((eintrag, s) for s in streams)
        return paare

    def anreichern(self, eingabe, typ, art="treffer"):
        """Ergebnisse aller passenden Anreicherer; Daten werden ergaenzt, nie entfernt."""
        ergebnis = {}
        for modul in self.rolle("anreicherer"):
            if modul.nimmt != art or typ not in modul.gibt or not modul.passt(eingabe):
                continue
            for eintrag in self._mit_zeitgrenze(modul, eingabe)[:1]:
                for feld, wert in eintrag.items():
                    if wert not in (None, "") and feld not in ergebnis:
                        ergebnis[feld] = wert
        return ergebnis

    def untertitel(self, eingabe):
        liste = []
        for modul in self.rolle("anreicherer"):
            if "untertitel" in modul.gibt and modul.passt(eingabe):
                liste.extend(u for u in self._mit_zeitgrenze(modul, eingabe) if u.get("url"))
        return liste

    def schliessen(self):
        self.pool.shutdown(wait=False)
        self.ketten_pool.shutdown(wait=False)
