"""KI-Anbieter-Abstraktion für H0rSt / UNiQuanteX.

Unterstützte Modi (konfig["ki_modus"]):
  "cloud"   – Claude (Anthropic-Format) oder OpenAI-kompatibler Cloud-Dienst
  "lokal"   – Ollama oder llama.cpp auf demselben Gerät (inkl. Termux/Android)
  "remote"  – Beliebiger OpenAI-kompatibler Endpunkt im LAN/WAN

Eintrittspunkt: anfrage(prompt, konfig) → str
Mit Werkzeug-Aufruf (MCP, Phase 2 Schritt 2): anfrage_mit_werkzeugen(prompt, werkzeuge, konfig,
werkzeug_aufruf) → str - mehrstufiger Tool-Use-Loop, am Ende derselbe reine Antworttext wie anfrage().
Status-Abfrage: status(konfig) → dict
"""
from __future__ import annotations

import json as _json
import urllib.error
import urllib.request

OLLAMA_STANDARD = "http://localhost:11434"
LLAMA_CPP_STANDARD = "http://localhost:8080"
# Von Qwen selbst gepflegte GGUF-Quantisierung (huggingface.co/Qwen/Qwen2.5-Coder-7B-Instruct-GGUF). Der
# sonst uebliche Community-Mittelweg Q4_K_M liegt in diesem Repo zusaetzlich als sharded Datei-Paar vor
# (z. B. "...-q4_k_m-00001-of-00002.gguf" NEBEN der spaeter hochgeladenen zusammengefuehrten Datei) - Ollama
# loest den Tag dabei auf die sharded Variante auf und bricht mit "This tag is a sharded GGUF. Ollama does
# not yet support pulling sharded GGUF via the registry..." ab (per Datei-Listing bestaetigt). Q3_K_M liegt
# in den Repos der Groessen 0.5B-14B nur als einzelne Datei vor, deshalb hier gewaehlt. Ollama zieht
# HuggingFace-Repos direkt ueber den Modellnamen "hf.co/<repo>:<quantisierung>" (siehe ollama_setup.py).
QWEN_CODER_VORSCHLAG = "hf.co/Qwen/Qwen2.5-Coder-7B-Instruct-GGUF:Q3_K_M"

# Obergrenze fuer anfrage_mit_werkzeugen(): verhindert Endlosschleifen und begrenzt die synchrone
# Blockierzeit im Request-Handler (kein Hintergrund-Job in diesem Schritt) - bewusst fest, nicht
# konfigurierbar.
MAX_WERKZEUG_RUNDEN = 4


class KiAnbieterFehler(ValueError):
    pass


# ---------------------------------------------------------------------------
# Öffentliche API
# ---------------------------------------------------------------------------

def _ist_claude(konfig: dict) -> bool:
    return konfig.get("ki_modus", "cloud") == "cloud" and konfig.get("ki_cloud_backend", "claude") == "claude"


def _openai_ziel(modus: str, konfig: dict):
    """Loest (url, model, key) fuer den OpenAI-kompatiblen Pfad auf - gemeinsam fuer anfrage() und
    anfrage_mit_werkzeugen(), damit die Modus-Verzweigung nur an einer Stelle steht."""
    if modus == "cloud":
        url = konfig.get("ki_cloud_url", "").rstrip("/")
        if not url:
            raise KiAnbieterFehler("ki_cloud_url fehlt für OpenAI-kompatiblen Cloud-Anbieter.")
        return url, konfig.get("ki_cloud_modell", "gpt-4o-mini"), konfig.get("ki_cloud_key", "")
    elif modus == "lokal":
        backend = konfig.get("ki_lokal_backend", "ollama")
        if backend == "ollama":
            return (konfig.get("ki_lokal_url") or OLLAMA_STANDARD).rstrip("/"), konfig.get("ki_lokal_modell", "llama3"), ""
        return (konfig.get("ki_lokal_url") or LLAMA_CPP_STANDARD).rstrip("/"), konfig.get("ki_lokal_modell", "local"), ""
    elif modus == "remote":
        url = konfig.get("ki_remote_url", "").rstrip("/")
        if not url:
            raise KiAnbieterFehler("ki_remote_url fehlt.")
        return url, konfig.get("ki_remote_modell", ""), konfig.get("ki_remote_key", "")
    else:
        raise KiAnbieterFehler(f"Unbekannter ki_modus: {modus!r}")


def anfrage(prompt: str, konfig: dict) -> str:
    """Sendet `prompt` an den konfigurierten Anbieter und gibt den Antwort-Text zurück."""
    if _ist_claude(konfig):
        key = konfig.get("claude_api_key", "")
        if not key:
            raise KiAnbieterFehler("Kein claude_api_key in konfig.json.")
        model = konfig.get("ki_cloud_modell") or "claude-sonnet-5-5"
        return _claude_anfrage(model, prompt, key)
    modus = konfig.get("ki_modus", "cloud")
    url, model, key = _openai_ziel(modus, konfig)
    return _openai_anfrage(url, model, prompt, key)


def anfrage_mit_werkzeugen(prompt: str, werkzeuge: list, konfig: dict, werkzeug_aufruf,
                            max_runden: int = None) -> str:
    """Wie anfrage(), aber die KI darf dabei die uebergebenen `werkzeuge` (Form wie aus
    mcp_client.verbinden()s "werkzeuge": {"name","beschreibung","eingabe_schema"}) mehrfach aufrufen,
    bevor sie eine finale Textantwort liefert. `werkzeug_aufruf(name, argumente) -> str` ist ein vom
    Aufrufer gebundener Callback (z.B. an mcp_client.aufrufen()); jeder Fehler daraus (auch McpFehler)
    wird als fehlgeschlagenes Werkzeug-Ergebnis in den Verlauf zurückgegeben, statt die Schleife
    abzubrechen - die KI kann selbst darauf reagieren. Nach `max_runden` LLM-Anfragen ohne finale
    Textantwort: KiAnbieterFehler."""
    max_runden = MAX_WERKZEUG_RUNDEN if max_runden is None else max_runden
    claude = _ist_claude(konfig)
    modus = konfig.get("ki_modus", "cloud")
    verlauf = [{"rolle": "nutzer", "text": prompt}]
    for _ in range(max_runden):
        if claude:
            text, aufrufe = _claude_anfrage_werkzeuge(verlauf, werkzeuge, konfig)
        else:
            text, aufrufe = _openai_anfrage_werkzeuge(verlauf, werkzeuge, konfig, modus)
        if not aufrufe:
            return text or ""
        verlauf.append({"rolle": "ki", "text": text, "werkzeug_aufrufe": aufrufe})
        for aufruf in aufrufe:
            if aufruf.get("fehler"):
                verlauf.append({"rolle": "werkzeug_ergebnis", "aufruf_id": aufruf["id"],
                                 "text": aufruf["fehler"], "fehler": True})
                continue
            try:
                ergebnis = werkzeug_aufruf(aufruf["name"], aufruf["argumente"])
            except Exception as fehler:
                verlauf.append({"rolle": "werkzeug_ergebnis", "aufruf_id": aufruf["id"],
                                 "text": str(fehler), "fehler": True})
            else:
                verlauf.append({"rolle": "werkzeug_ergebnis", "aufruf_id": aufruf["id"],
                                 "text": ergebnis, "fehler": False})
    raise KiAnbieterFehler("Zu viele Werkzeug-Runden ohne Endantwort (max. %d)" % max_runden)


def ollama_pruefen(base_url: str = OLLAMA_STANDARD) -> list:
    """Fragt Ollama-Modelliste ab. Gibt Modell-Namen-Liste zurück, bei Fehler []."""
    url = base_url.rstrip("/") + "/api/tags"
    try:
        req = urllib.request.Request(url, headers={"Accept": "application/json"})
        with urllib.request.urlopen(req, timeout=3) as resp:
            daten = _json.loads(resp.read())
        return [m.get("name", "") for m in daten.get("models", []) if m.get("name")]
    except Exception:
        return []


def llama_cpp_pruefen(base_url: str = LLAMA_CPP_STANDARD) -> bool:
    """Prüft ob ein llama.cpp-Server läuft. Gibt True zurück wenn /health antwortet."""
    url = base_url.rstrip("/") + "/health"
    try:
        with urllib.request.urlopen(url, timeout=3) as resp:
            return resp.status == 200
    except Exception:
        return False


def status(konfig: dict) -> dict:
    """Gibt aktuellen Anbieter-Status zurück (für Frontend)."""
    modus = konfig.get("ki_modus", "cloud")
    out = {
        "modus": modus,
        "cloud_key": bool(konfig.get("claude_api_key")),
        "ki_cloud_key": bool(konfig.get("ki_cloud_key")),
    }
    if modus == "lokal":
        backend = konfig.get("ki_lokal_backend", "ollama")
        base = (konfig.get("ki_lokal_url") or (OLLAMA_STANDARD if backend == "ollama" else LLAMA_CPP_STANDARD))
        if backend == "ollama":
            modelle = ollama_pruefen(base)
            out["ollama_modelle"] = modelle
            out["ollama_erreichbar"] = bool(modelle)
        else:
            out["llama_cpp_erreichbar"] = llama_cpp_pruefen(base)
    elif modus == "remote":
        out["remote_url"] = konfig.get("ki_remote_url", "")
    return out


# ---------------------------------------------------------------------------
# Interne Hilfsfunktionen
# ---------------------------------------------------------------------------

def _claude_anfrage(model: str, prompt: str, key: str) -> str:
    body = _json.dumps({
        "model": model,
        "max_tokens": 2048,
        "messages": [{"role": "user", "content": prompt}],
    }).encode()
    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages",
        data=body,
        headers={
            "x-api-key": key,
            "anthropic-version": "2023-06-01",
            "content-type": "application/json",
        },
    )
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            antwort = _json.loads(resp.read())
        return antwort["content"][0]["text"]
    except urllib.error.HTTPError as e:
        raise KiAnbieterFehler(f"Anthropic-API HTTP {e.code}: {e.read()[:200]}") from e
    except (OSError, _json.JSONDecodeError, KeyError, IndexError) as e:
        raise KiAnbieterFehler(f"Claude-API-Fehler: {e}") from e


def _openai_anfrage(base_url: str, model: str, prompt: str, key: str) -> str:
    body = _json.dumps({
        "model": model,
        "messages": [{"role": "user", "content": prompt}],
        "max_tokens": 2048,
    }).encode()
    headers = {"content-type": "application/json"}
    if key:
        headers["authorization"] = f"Bearer {key}"
    req = urllib.request.Request(
        base_url + "/v1/chat/completions",
        data=body,
        headers=headers,
    )
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            antwort = _json.loads(resp.read())
        return antwort["choices"][0]["message"]["content"]
    except urllib.error.HTTPError as e:
        raise KiAnbieterFehler(f"OpenAI-kompatibel HTTP {e.code}: {e.read()[:200]}") from e
    except (OSError, _json.JSONDecodeError, KeyError, IndexError) as e:
        raise KiAnbieterFehler(f"OpenAI-kompatibler Anbieter Fehler: {e}") from e


# ---------------------------------------------------------------------------
# Werkzeug-Aufruf (Tool-Use, Phase 2 Schritt 2) - zwei Formate, je ein Uebersetzer fuer
# Werkzeug-Definitionen + Verlauf, eine Anfragefunktion, die (text, aufrufe) zurueckgibt.
# aufruf-Form: {"id", "name", "argumente": dict, "fehler": str|None}
# ---------------------------------------------------------------------------

def _claude_tools(werkzeuge: list) -> list:
    return [{"name": w["name"], "description": w.get("beschreibung", ""),
             "input_schema": w.get("eingabe_schema") or {"type": "object", "properties": {}}}
            for w in werkzeuge]


def _claude_messages(verlauf: list) -> list:
    messages = []
    for turn in verlauf:
        if turn["rolle"] == "nutzer":
            messages.append({"role": "user", "content": turn["text"]})
        elif turn["rolle"] == "ki":
            inhalt = []
            if turn.get("text"):
                inhalt.append({"type": "text", "text": turn["text"]})
            for aufruf in turn.get("werkzeug_aufrufe") or []:
                inhalt.append({"type": "tool_use", "id": aufruf["id"], "name": aufruf["name"],
                                "input": aufruf["argumente"]})
            messages.append({"role": "assistant", "content": inhalt})
        else:  # werkzeug_ergebnis
            block = {"type": "tool_result", "tool_use_id": turn["aufruf_id"], "content": turn["text"]}
            if turn.get("fehler"):
                block["is_error"] = True
            letzte = messages[-1] if messages else None
            if letzte and letzte["role"] == "user" and isinstance(letzte["content"], list):
                letzte["content"].append(block)
            else:
                messages.append({"role": "user", "content": [block]})
    return messages


def _claude_anfrage_werkzeuge(verlauf: list, werkzeuge: list, konfig: dict):
    key = konfig.get("claude_api_key", "")
    if not key:
        raise KiAnbieterFehler("Kein claude_api_key in konfig.json.")
    model = konfig.get("ki_cloud_modell") or "claude-sonnet-5-5"
    body = _json.dumps({
        "model": model, "max_tokens": 2048,
        "messages": _claude_messages(verlauf), "tools": _claude_tools(werkzeuge),
    }).encode()
    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages", data=body,
        headers={"x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=30) as resp:
            antwort = _json.loads(resp.read())
    except urllib.error.HTTPError as e:
        raise KiAnbieterFehler(f"Anthropic-API HTTP {e.code}: {e.read()[:200]}") from e
    except (OSError, _json.JSONDecodeError, KeyError) as e:
        raise KiAnbieterFehler(f"Claude-API-Fehler: {e}") from e
    text_teile, aufrufe = [], []
    for block in antwort.get("content") or []:
        if block.get("type") == "text":
            text_teile.append(block.get("text", ""))
        elif block.get("type") == "tool_use":
            aufrufe.append({"id": block.get("id", ""), "name": block.get("name", ""),
                             "argumente": block.get("input") or {}, "fehler": None})
    return "\n".join(text_teile), aufrufe


def _openai_tools(werkzeuge: list) -> list:
    return [{"type": "function", "function": {
        "name": w["name"], "description": w.get("beschreibung", ""),
        "parameters": w.get("eingabe_schema") or {"type": "object", "properties": {}}}}
        for w in werkzeuge]


def _openai_messages(verlauf: list) -> list:
    messages = []
    for turn in verlauf:
        if turn["rolle"] == "nutzer":
            messages.append({"role": "user", "content": turn["text"]})
        elif turn["rolle"] == "ki":
            nachricht = {"role": "assistant", "content": turn.get("text") or None}
            if turn.get("werkzeug_aufrufe"):
                nachricht["tool_calls"] = [
                    {"id": a["id"], "type": "function",
                     "function": {"name": a["name"], "arguments": _json.dumps(a["argumente"])}}
                    for a in turn["werkzeug_aufrufe"]]
            messages.append(nachricht)
        else:  # werkzeug_ergebnis
            messages.append({"role": "tool", "tool_call_id": turn["aufruf_id"], "content": turn["text"]})
    return messages


def _openai_anfrage_werkzeuge(verlauf: list, werkzeuge: list, konfig: dict, modus: str):
    url, model, key = _openai_ziel(modus, konfig)
    body = _json.dumps({
        "model": model, "messages": _openai_messages(verlauf),
        "tools": _openai_tools(werkzeuge), "max_tokens": 2048,
    }).encode()
    headers = {"content-type": "application/json"}
    if key:
        headers["authorization"] = f"Bearer {key}"
    req = urllib.request.Request(url + "/v1/chat/completions", data=body, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=60) as resp:
            antwort = _json.loads(resp.read())
    except urllib.error.HTTPError as e:
        raise KiAnbieterFehler(f"OpenAI-kompatibel HTTP {e.code}: {e.read()[:200]}") from e
    except (OSError, _json.JSONDecodeError, KeyError, IndexError) as e:
        raise KiAnbieterFehler(f"OpenAI-kompatibler Anbieter Fehler: {e}") from e
    nachricht = ((antwort.get("choices") or [{}])[0] or {}).get("message") or {}
    text = nachricht.get("content") or ""
    aufrufe = []
    for tc in nachricht.get("tool_calls") or []:
        fn = tc.get("function") or {}
        try:
            argumente = _json.loads(fn.get("arguments") or "{}")
        except _json.JSONDecodeError as fehler:
            aufrufe.append({"id": tc.get("id", ""), "name": fn.get("name", ""), "argumente": {},
                             "fehler": "Ungültiges JSON in arguments: %s" % fehler})
            continue
        aufrufe.append({"id": tc.get("id", ""), "name": fn.get("name", ""), "argumente": argumente,
                         "fehler": None})
    return text, aufrufe
