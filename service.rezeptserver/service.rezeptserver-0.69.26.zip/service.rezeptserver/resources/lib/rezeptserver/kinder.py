"""Regeln fuer Kinderprofile (ARVIO 2.3), serverseitig: was eine Kind-Sitzung ueberhaupt aufrufen darf.

Positivliste: ein Kinderprofil darf nur Filme und Serien ansehen (Entdecken, Suche, Kataloge, Details, Streams,
Merkliste/Verlauf/Weiterschauen, eigene YouTube-Reihen) und sein Profil verwalten. Alles andere unter /api/ ist zu -
auch Dinge, die es heute noch nicht gibt. Ab 18 bleibt fuer Kinder immer gesperrt, auch mit Eltern-PIN.

Zwei Aufrufe sind erlaubt, aber nur mit Eltern-Freigabe (5 Minuten nach Eingabe der Eltern-PIN): Einstellungen
aendern und die YouTube-Reihen des Profils bearbeiten. Profil wechseln, abmelden, loeschen: siehe oberflaeche_profile.py.
"""

import re

FREIGABE_SEK = 300
EXAKT_GET = frozenset({
    "/api/profile", "/api/einstellungen", "/api/sehen", "/api/entdecken", "/api/titelsuche", "/api/titel",
    "/api/titelstreams", "/api/streams", "/api/genres", "/api/katalog", "/api/kataloge", "/api/suche", "/api/trailer",
    "/api/reihen", "/api/bild", "/api/avatar", "/api/dank", "/api/startanimation", "/api/sammlungen"})
PRAEFIX_GET = ("/api/hls/", "/api/wiedergabe/")
EXAKT_POST = frozenset({"/api/profile", "/api/sehen", "/api/einstellungen", "/api/reihen", "/api/youtube/abspielen"})
MIT_FREIGABE = frozenset({"/api/einstellungen", "/api/reihen"})
TITEL_PFADE = ("/api/titel", "/api/titelstreams", "/api/streams", "/api/trailer")
_FOLGE = re.compile(r"^(tt\d{1,10})(?::\d{1,4}:\d{1,5})?$")


def ist_kind(profil):
    return bool(profil and profil.get("kind"))


def grenze(profil):
    try:
        return int(profil.get("kind_alter"))
    except (TypeError, ValueError):
        return 0  # kaputter Eintrag: lieber zu streng


def pfad_erlaubt(pfad, methode):
    """Darf eine Kind-Sitzung diesen Aufruf machen? (Nur /api/ ist geregelt; Seitendateien sind frei.)"""
    if not pfad.startswith("/api/"):
        return not pfad.startswith(("/tmdbhelper/", "/brause/", "/api"))
    if methode == "POST":
        return pfad in EXAKT_POST
    return pfad in EXAKT_GET or pfad.startswith(PRAEFIX_GET)


def titel_aus_anfrage(pfad, werte):
    """(typ oder None, IMDb-Kennung) der Anfrage, wenn sie einen einzelnen Titel betrifft - sonst None."""
    if pfad not in TITEL_PFADE:
        return None
    m = _FOLGE.match(str(werte.get("id", "")))
    return (werte.get("typ") if pfad != "/api/streams" else None), (m.group(1) if m else str(werte.get("id", "")))
