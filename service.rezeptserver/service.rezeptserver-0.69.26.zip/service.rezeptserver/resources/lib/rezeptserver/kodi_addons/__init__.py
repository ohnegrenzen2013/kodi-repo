"""Kodi-Addons in H0rSt: Plugins (plugin.video.*, plugin.audio.*) installieren und ohne Kodi nutzen.

H0rSt stellt den Plugins die Kodi-Module nach (xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs, xbmcdrm – im Ordner
stubs/) und ruft sie wie Kodi mit einer plugin://-Adresse auf. Was ein Plugin meldet, wird zu einer Liste
(Ordner, abspielbare Eintraege, Bilder, Infos, Kontextmenue) oder zu einem Stream (setResolvedUrl, Player.play).
Fragt ein Plugin nach (Tastatur, Auswahl, Ja/Nein), kommt die Frage in die Oberflaeche; mit der Antwort laeuft
derselbe Aufruf noch einmal (Plugins sind zustandslos, Kodi macht es bei "Zurueck" genauso).

  verwaltung.py   Installieren aus Repositories (offizielles Kodi-Repo, eigene repository.*), ZIP oder Adresse,
                  mit Abhaengigkeiten (script.module.*); Entfernen; Updates.
  einstellungen.py  settings.xml (alt und neu) lesen, Werte in userdata/addon_data/<id>/settings.xml, strings.po.
  laufzeit.py     Ein Aufruf: Kontext fuer die Stubs, sys.argv/sys.path/sys.modules sauber setzen und zuruecksetzen.

Ordner (wie Kodi): <Datenordner>/kodi/addons/<id>, <Datenordner>/kodi/userdata/addon_data/<id>, .../temp.
Wie in Kodi laufen Plugins mit allen Rechten des Servers – nur aus Quellen installieren, denen man traut.
"""

from .verwaltung import KodiAddons, KodiFehler  # noqa: F401
