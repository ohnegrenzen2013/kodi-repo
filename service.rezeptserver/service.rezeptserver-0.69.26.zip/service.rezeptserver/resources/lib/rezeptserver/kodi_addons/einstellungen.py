"""Einstellungen und Texte eines Kodi-Addons.

settings.xml gibt es in zwei Formen:
  alt (bis Kodi 18, noch oft):  <settings><category label="…"><setting id type default values lvalues …/></category></settings>
  neu (Kodi 19+, version="1"):  <settings version="1"><section><category label><group><setting id type label>
                                 <default>…</default><constraints><options>…</options></constraints><control …/></setting>
Gespeichert wird wie in Kodi: userdata/addon_data/<id>/settings.xml  <settings version="2"><setting id="…">wert</setting>.
Texte: resources/language/resource.language.<sprache>/strings.po (msgctxt "#30001").
"""

import os
import re
import xml.etree.ElementTree as ET
from xml.sax.saxutils import escape

SPRACHEN = ("resource.language.de_de", "resource.language.en_gb", "resource.language.en_us", "English", "German")
_UNGUELTIG = re.compile("[\x00-\x08\x0b\x0c\x0e-\x1f\ufffe\uffff]")  # in XML 1.0 verboten – die Datei waere sonst unlesbar
_PO_ZEILE = re.compile(r'^(msgctxt|msgid|msgstr)\s+"(.*)"\s*$|^"(.*)"\s*$')
# Kodis eigene Texte, die Plugins oft abfragen (getLocalizedString ohne Addon-Bezug)
KODI_TEXTE = {137: "Suchen", 222: "Abbrechen", 186: "OK", 106: "Nein", 107: "Ja", 1036: "Favoriten", 13208: "Weiter",
              19033: "Information", 20329: "Filme", 20343: "Serien", 33063: "Fehler", 342: "Filme", 20373: "Staffel",
              20359: "Folge", 10005: "Einstellungen", 14028: "Abbrechen", 15015: "Entfernen", 33081: "Diese Datei ist gestapelt"}


def _unescape(text):
    return text.replace('\\"', '"').replace("\\n", "\n").replace("\\\\", "\\")


def _po(inhalt):
    """{nummer: text} aus einer .po-Datei (mehrzeilige Eintraege, msgstr leer = msgid)."""
    ergebnis, eintrag, feld = {}, {}, None

    def fertig():
        ctx = eintrag.get("msgctxt", "")
        if ctx.startswith("#") and ctx[1:].isdigit():
            text = eintrag.get("msgstr") or eintrag.get("msgid") or ""
            if text:
                ergebnis[int(ctx[1:])] = text
    for zeile in inhalt.splitlines():
        m = _PO_ZEILE.match(zeile.strip())
        if not m:
            continue
        if m.group(1):
            if m.group(1) == "msgctxt":
                fertig()
                eintrag = {}
            feld = m.group(1)
            eintrag[feld] = _unescape(m.group(2))
        elif feld:
            eintrag[feld] = eintrag.get(feld, "") + _unescape(m.group(3))
    fertig()
    return ergebnis


def texte(addon_ordner):
    """{nummer: text} aus strings.po (Deutsch vor Englisch); aeltere strings.xml gehen auch."""
    ergebnis = {}
    basis = os.path.join(addon_ordner, "resources", "language")
    for sprache in reversed(SPRACHEN):  # Englisch zuerst, Deutsch ueberschreibt
        po = os.path.join(basis, sprache, "strings.po")
        if os.path.exists(po):
            try:
                with open(po, encoding="utf-8", errors="replace") as f:
                    ergebnis.update(_po(f.read()))
            except OSError:
                pass
        xml = os.path.join(basis, sprache, "strings.xml")
        if os.path.exists(xml):
            try:
                for s in ET.parse(xml).getroot().iter("string"):
                    if (s.get("id") or "").isdigit() and s.text:
                        ergebnis[int(s.get("id"))] = s.text
            except (OSError, ET.ParseError):
                pass
    return ergebnis


def _text(t, roh):
    roh = (roh or "").strip()
    if roh.isdigit():
        return t.get(int(roh)) or KODI_TEXTE.get(int(roh)) or roh
    return roh


def _alt(root, t):
    seiten = []
    for kat in root.findall("category") or [root]:
        felder = []
        for s in kat.findall("setting"):
            art, sid = (s.get("type") or "").lower(), s.get("id")
            if art in ("lsep", "sep"):
                if s.get("label"):
                    felder.append({"art": "ueberschrift", "titel": _text(t, s.get("label"))})
                continue
            if not sid:
                continue
            f = {"id": sid, "titel": _text(t, s.get("label")) or sid, "standard": s.get("default") or "",
                 "versteckt": "hidden" in (s.get("option") or "") or s.get("visible") == "false"}
            if art == "bool":
                f.update(art="schalter", standard=(s.get("default") or "false").lower())
            elif art in ("number", "slider", "ipaddress"):
                f["art"] = "zahl" if art != "ipaddress" else "text"
            elif art == "enum":  # gespeichert wird die Nummer
                namen = [_text(t, x) for x in (s.get("lvalues") or s.get("values") or "").split("|")]
                f.update(art="auswahl", optionen=[[str(i), n] for i, n in enumerate(namen)], standard=s.get("default") or "0")
            elif art in ("labelenum", "select"):  # gespeichert wird der Text
                namen = [_text(t, x) for x in (s.get("lvalues") or s.get("values") or "").split("|")]
                f.update(art="auswahl", optionen=[[n, n] for n in namen])
            elif art == "action":
                f.update(art="aktion", befehl=s.get("action") or "")
            elif art == "text" and "hidden" in (s.get("option") or ""):
                f.update(art="passwort", versteckt=False)
            else:
                f["art"] = "text"
            felder.append(f)
        seiten.append({"titel": _text(t, kat.get("label")) or "Allgemein", "felder": felder})
    return seiten


def _neu(root, t):
    seiten = []
    for kat in root.iter("category"):
        felder = []
        for gruppe in kat.findall("group") or [kat]:
            if gruppe.get("label"):
                felder.append({"art": "ueberschrift", "titel": _text(t, gruppe.get("label"))})
            for s in gruppe.findall("setting"):
                sid, art = s.get("id"), (s.get("type") or "").lower()
                if not sid:
                    continue
                stufe = (s.findtext("level") or "0").strip()
                standard = (s.findtext("default") or "").strip()
                kontrolle = s.find("control")
                kart = (kontrolle.get("type") if kontrolle is not None else "") or ""
                f = {"id": sid, "titel": _text(t, s.get("label")) or sid, "standard": standard, "versteckt": stufe == "4"}
                optionen = s.find("constraints/options")
                if optionen is not None and optionen.findall("option"):
                    f.update(art="auswahl", optionen=[[(o.text or "").strip(), _text(t, o.get("label")) or (o.text or "").strip()]
                                                      for o in optionen.findall("option")])
                elif art == "boolean":
                    f.update(art="schalter", standard=standard.lower() or "false")
                elif art in ("integer", "number"):
                    f["art"] = "zahl"
                elif art == "action":
                    f.update(art="aktion", befehl=(s.findtext("data") or (kontrolle.findtext("data") if kontrolle is not None else "") or "").strip())
                elif kontrolle is not None and kontrolle.find("hidden") is not None and (kontrolle.findtext("hidden") or "").strip() == "true":
                    f["art"] = "passwort"
                elif kart == "button" and art != "string":
                    continue
                else:
                    f["art"] = "text"
                felder.append(f)
        seiten.append({"titel": _text(t, kat.get("label")) or kat.get("id") or "Allgemein", "felder": felder})
    return seiten


def definitionen(addon_ordner, t=None):
    """Seiten mit Feldern: [{titel, felder: [{id, titel, art, standard, optionen?, versteckt}]}]."""
    pfad = os.path.join(addon_ordner, "resources", "settings.xml")
    if not os.path.exists(pfad):
        return []
    try:
        root = ET.parse(pfad).getroot()
    except (OSError, ET.ParseError):
        return []
    t = texte(addon_ordner) if t is None else t
    return _neu(root, t) if root.find("section") is not None else _alt(root, t)


def standardwerte(addon_ordner):
    return {f["id"]: f.get("standard", "") for s in definitionen(addon_ordner, {}) for f in s["felder"] if "id" in f}


def lesen(datei):
    werte = {}
    if not os.path.exists(datei):
        return werte
    try:
        for s in ET.parse(datei).getroot().iter("setting"):
            if s.get("id"):
                werte[s.get("id")] = s.text if s.text is not None else (s.get("value") or "")
    except (OSError, ET.ParseError):
        pass
    return werte


def schreiben(datei, werte):
    os.makedirs(os.path.dirname(datei), exist_ok=True)
    rein = lambda t: _UNGUELTIG.sub("", str(t))
    zeilen = ['<settings version="2">'] + ['    <setting id="%s">%s</setting>' % (escape(rein(k), {'"': "&quot;"}), escape(rein(v)))
                                          for k, v in sorted(werte.items())] + ["</settings>"]
    neu = datei + ".neu"
    with open(neu, "w", encoding="utf-8") as f:
        f.write("\n".join(zeilen) + "\n")
    os.replace(neu, datei)
