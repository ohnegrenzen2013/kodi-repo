"""Ein Plugin-Aufruf wie in Kodi: plugin://<id>/<pfad>?<abfrage> -> Liste, Stream oder Rueckfrage.

Immer nur ein Aufruf zur Zeit (Plugins lesen sys.argv und teilen sich Module). Waehrend des Aufrufs stehen die
Kodi-Module (stubs/) in sys.modules, der Ordner des Plugins und die Bibliotheken seiner Abhaengigkeiten vorn in
sys.path; danach ist alles wie vorher und die Module des Plugins sind vergessen (der naechste Aufruf laedt frisch).
"""

import contextlib
import importlib.util
import logging
import os
import sys
import types
import threading

from .einstellungen import KODI_TEXTE  # noqa: F401 – fuer xbmc.getLocalizedString
from .laufzeit_grund import *  # noqa: F403
from .laufzeit_ergebnis import *  # noqa: F403

log = logging.getLogger("rezeptserver")

STUB_NAMEN = ("xbmc", "xbmcgui", "xbmcplugin", "xbmcaddon", "xbmcvfs", "xbmcdrm", "inputstreamhelper")
ZEITGRENZE = 90
HANDLE = 1
_SPERRE = threading.Lock()
KOMPAT = os.path.join(os.path.dirname(os.path.abspath(__file__)), "kompat")  # imp, distutils … fuer Python >= 3.12
_stubs = {}
AKTUELL = None  # der laufende Aufruf (Lauf), fuer die Stubs

# Beide erben von BaseException wie SystemExit: Plugins fangen oft "except Exception" ab und liefen sonst weiter.
class Rueckfrage(BaseException):
    """Ein Plugin fragt nach (Tastatur, Auswahl, Ja/Nein …) und es gibt noch keine Antwort."""

    def __init__(self, frage):
        super().__init__(frage.get("titel", ""))  # nicht Exception.__init__: das lehnt eine BaseException bis Python 3.12 ab
        self.frage = frage


class Abbruch(BaseException):
    """Der Aufruf hat die Zeitgrenze ueberschritten; der naechste Stub-Aufruf beendet ihn (oder _stoppen)."""


def stub(name):
    return _stubs[name]


def _python_wie_kodi():
    """Was Python ab 3.12 entfernt hat, Kodi 21 (Python 3.11) aber noch kennt – nur ergaenzen, nie ersetzen."""
    import locale
    import sqlite3
    if not hasattr(sqlite3, "version"):  # seit 3.14 weg (MediathekView prueft es)
        sqlite3.version, sqlite3.version_info = "2.6.0", (2, 6, 0)
    if not hasattr(locale, "format"):  # seit 3.12 weg
        locale.format = lambda percent, value, grouping=False, monetary=False, *rest: locale.format_string(percent, value, grouping, monetary)


def _stubs_laden():
    if _stubs:
        return _stubs
    _python_wie_kodi()
    ordner = os.path.join(os.path.dirname(os.path.abspath(__file__)), "stubs")
    for name in STUB_NAMEN:
        spec = importlib.util.spec_from_file_location(name, os.path.join(ordner, name + ".py"))
        modul = importlib.util.module_from_spec(spec)
        spec.loader.exec_module(modul)
        modul.L = sys.modules[__name__]  # nach dem Laden: die Module setzen L = None
        _stubs[name] = modul
    return _stubs


class Lauf:
    """Alles, was ein Aufruf sammelt."""

    def __init__(self, verwaltung, addon, url, antworten=()):
        self.verwaltung = verwaltung
        self.addon = addon
        self.url = url
        self.antworten = list(antworten)
        self.gefragt = 0
        self.eintraege = []
        self.aufgeloest = None   # (url, ListItem) aus setResolvedUrl oder Player.play
        self.ende = None         # endOfDirectory: True/False
        self.inhalt = ""         # setContent: movies, tvshows, episodes, videos …
        self.kategorie = ""
        self.meldungen = []      # Notification, Dialog.ok, textviewer
        self.weiter = None       # Container.Update / ActivateWindow mit plugin://
        self.befehle = []        # RunPlugin u. a. fuer spaeter
        self.neu_laden = False
        self.frage = None
        self.fehler = None
        self.abgebrochen = False
        self.fenster = verwaltung.fenster  # Window(10000).setProperty … – bleibt wie in Kodi ueber Aufrufe hinweg
        self.im_plugin = False   # nur dann darf _stoppen den Faden unterbrechen

    def pruefen(self):
        if self.abgebrochen:
            raise Abbruch("Zeitgrenze")

    def fragen(self, frage):
        """Naechste Antwort aus der Oberflaeche oder Rueckfrage."""
        self.pruefen()
        if self.gefragt < len(self.antworten):
            antwort = self.antworten[self.gefragt]
            self.gefragt += 1
            return antwort
        frage["nummer"] = self.gefragt
        raise Rueckfrage(frage)

    def melden(self, titel, text=""):
        self.meldungen.append({"titel": ohne_format(titel), "text": ohne_format(text)})

    def pfad(self, pfad):
        return self.verwaltung.pfad_uebersetzen(pfad)


@contextlib.contextmanager
def kein_lauf(warten=ZEITGRENZE + 10):
    """Solange kein Plugin laufen lassen (Installieren, Entfernen); laeuft eines zu lange, geht es trotzdem weiter."""
    frei = _SPERRE.acquire(timeout=warten)
    try:
        yield
    finally:
        if frei:
            _SPERRE.release()


def _stoppen(faden, lauf):
    """Abbruch im Faden des Plugins ausloesen – auch in Endlosschleifen ohne Kodi-Aufrufe (nicht in blockierendem C-Code).

    Nur solange der Faden noch im Plugin steckt: endet er gerade, koennte seine Kennung schon einem anderen Faden gehoeren."""
    if not (faden.is_alive() and lauf.im_plugin):
        return
    try:
        import ctypes
        anzahl = ctypes.pythonapi.PyThreadState_SetAsyncExc(ctypes.c_ulong(faden.ident), ctypes.py_object(Abbruch))
        if anzahl > 1:  # darf nicht sein – zuruecknehmen
            ctypes.pythonapi.PyThreadState_SetAsyncExc(ctypes.c_ulong(faden.ident), None)
    except (ImportError, AttributeError, OSError, ValueError):
        pass


def ausfuehren(verwaltung, url, antworten=(), zeitgrenze=None):
    """Ein Aufruf; gibt den fertigen Lauf zurueck (oder wirft ValueError)."""
    zeitgrenze = zeitgrenze or ZEITGRENZE
    addon_id, argv0, abfrage = zerlegen(url)
    addon = verwaltung.info(addon_id)
    if not addon:
        raise ValueError("Addon %s ist nicht installiert" % addon_id)
    if not addon.get("skript"):
        raise ValueError("%s ist kein Plugin" % addon_id)
    _stubs_laden()
    verwaltung.zertifikate()
    lauf = Lauf(verwaltung, addon, url, antworten)
    if not _SPERRE.acquire(timeout=zeitgrenze):
        raise ValueError("Ein anderes Kodi-Addon läuft noch – gleich noch einmal versuchen")
    faden = threading.Thread(target=_laufen, args=(lauf, argv0, abfrage), name="kodi-" + addon_id, daemon=True)
    try:
        faden.start()
    except RuntimeError:  # kein Faden mehr zu haben
        _SPERRE.release()
        raise ValueError("H0rSt kann gerade keinen weiteren Faden starten")
    faden.join(zeitgrenze)
    if faden.is_alive():
        lauf.abgebrochen = True
        _stoppen(faden, lauf)  # sonst hielte ein haengendes Plugin die Sperre, und kein Addon liefe mehr
        faden.join(5)
        raise ValueError("%s antwortet nicht (über %d s)%s" % (addon.get("name") or addon_id, zeitgrenze,
                         "" if not faden.is_alive() else " und hängt noch – andere Kodi-Addons warten, bis es fertig ist"))
    return lauf


def _laufen(lauf, argv0, abfrage):
    global AKTUELL
    addon = lauf.addon
    alt_argv, alt_pfad = sys.argv, list(sys.path)
    alt_stubs = {n: sys.modules.get(n) for n in STUB_NAMEN}
    vorher = set(sys.modules)
    wurzel_log = logging.getLogger()
    alt_log = (list(wurzel_log.handlers), wurzel_log.level, logging.root.manager.disable)  # Addons haengen gern Handler an
    try:
        sys.argv = [argv0, str(HANDLE), abfrage, "resume:false"]
        # wie Kodi: zuerst der Ordner des Startskripts (z. B. resources/lib), dann das Addon und seine Abhaengigkeiten;
        # die uebrigen Module und der Python-3.11-Ersatz ganz hinten, damit sie nichts verdecken
        vorn = [os.path.dirname(os.path.join(addon["pfad"], addon["skript"])), addon["pfad"]] + lauf.verwaltung.bibliotheken(addon["id"])
        sys.path[:0] = [p for n, p in enumerate(vorn) if p not in vorn[:n] and p not in sys.path]
        sys.path.extend([p for p in lauf.verwaltung.notnagel(addon["id"]) if p not in sys.path] + [KOMPAT])
        sys.modules.update(_stubs)
        AKTUELL = lauf  # kein chdir: das Arbeitsverzeichnis gilt fuer den ganzen Server
        lauf.im_plugin = True
        try:
            _starten(os.path.join(addon["pfad"], addon["skript"]))
        finally:
            lauf.im_plugin = False
    except SystemExit:
        pass
    except Rueckfrage as r:
        lauf.frage = r.frage
    except Abbruch:
        pass
    except BaseException as fehler:  # noqa: B902 – ein Plugin darf H0rSt nie mitreissen
        lauf.fehler = "%s: %s" % (type(fehler).__name__, fehler)
        try:
            fehlend = lauf.verwaltung.fehlende(addon["id"]) if isinstance(fehler, ImportError) else []
        except Exception:  # der Hinweis darf die Fehlermeldung nie verhindern
            fehlend = []
        if fehlend:  # meist eine Abhaengigkeit aus einem Repository, das noch nicht eingerichtet ist
            lauf.fehler += " – es fehlt %s. Das Repository, das es anbietet, unter „Quelle hinzufügen“ eintragen." % ", ".join(fehlend)
        log.warning("Kodi-Addon %s (%s): %s", addon["id"], lauf.url, lauf.fehler, exc_info=True)
    finally:
        try:
            AKTUELL = None
            sys.argv = alt_argv
            sys.path[:] = alt_pfad
            for n, m in alt_stubs.items():
                if m is None:
                    sys.modules.pop(n, None)
                else:
                    sys.modules[n] = m
            wurzel_log.handlers[:] = alt_log[0]
            wurzel_log.setLevel(alt_log[1])
            logging.disable(alt_log[2])
            _vergessen((addon["pfad"], KOMPAT), vorher)
        except Exception:  # noqa: BLE001 – die Sperre muss immer frei werden, sonst laeuft kein Addon mehr
            log.warning("Kodi-Addon %s: Aufräumen unvollständig", addon["id"], exc_info=True)
        finally:
            _SPERRE.release()


def _starten(skript):
    """Wie Kodi: das Skript als __main__, sys.argv bleibt (runpy.run_path wuerde argv[0] durch den Pfad ersetzen)."""
    with open(skript, "rb") as f:
        code = compile(f.read(), skript, "exec")
    modul = types.ModuleType("__main__")
    modul.__file__ = skript
    exec(code, modul.__dict__)


def _vergessen(ordner_liste, vorher):
    """Module des Plugins aus sys.modules nehmen – sonst saehe das naechste Plugin dessen 'resources.lib'.

    Erst alle bestimmen, dann entfernen: Namespace-Pakete (resources/ ohne __init__.py) berechnen ihren __path__ ueber das
    Elternpaket in sys.modules neu und scheitern, wenn das schon weg ist."""
    ordner = tuple(os.path.abspath(o) + os.sep for o in ordner_liste)
    weg = []
    for name in [n for n in list(sys.modules) if n not in vorher]:
        m = sys.modules.get(name)
        try:
            datei = getattr(m, "__file__", None) or ""
            pfade = list(getattr(m, "__path__", []) or [])
        except Exception:  # noqa: BLE001 – kaputter Namespace: im Zweifel weg
            weg.append(name)
            continue
        if (datei and os.path.abspath(datei).startswith(ordner)) or any(os.path.abspath(p).startswith(ordner) for p in pfade):
            weg.append(name)
    for name in weg:
        sys.modules.pop(name, None)
