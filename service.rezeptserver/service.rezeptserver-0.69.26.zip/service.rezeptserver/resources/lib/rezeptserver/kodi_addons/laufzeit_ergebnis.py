"""Kodi-Addon-Laufzeit: das Ergebnis eines Aufrufs fuer die Oberflaeche.

Bildadressen, Listeneintraege, Streams und die fertige Antwort. Die reinen Text- und Adresshelfer stehen in
laufzeit_grund.py, der Aufruf in laufzeit.py.
"""

import os
import time
from urllib.parse import parse_qsl, quote, unquote, urlsplit

from .laufzeit_grund import MAX_EINTRAEGE, ohne_format, stream_zerlegen


# --- Ergebnis fuer die Oberflaeche ----------------------------------------------------------------------
def bild(verwaltung, wert):
    """Bildadresse fuer den Browser: http(s) ohne Kodi-Header, lokale Dateien ueber H0rSt."""
    wert = str(wert or "").strip()
    if not wert:
        return ""
    if wert.startswith("image://"):
        wert = unquote(wert[len("image://"):].rstrip("/"))
    if wert.lower().startswith(("http://", "https://")):
        return wert.split("|", 1)[0]
    pfad = verwaltung.pfad_uebersetzen(wert)
    rel = verwaltung.relativ(pfad)
    return "api/kodiaddons/datei?pfad=" + quote(rel) if rel and os.path.isfile(pfad) else ""


def eintrag(verwaltung, url, li, ordner):
    info = li.info_daten() if li is not None else {}
    kunst = li.kunst() if li is not None else {}
    url = str(url or "")
    abspielbar = not ordner  # wie Kodi: kein Ordner heisst ausfuehren (setResolvedUrl, Player.play oder ein Befehl)
    titel = ohne_format(li.getLabel() if li is not None else url) or ohne_format(info.get("title")) or url
    return {"url": url, "ordner": bool(ordner), "abspielbar": abspielbar, "titel": titel,
            "titel2": ohne_format(li.getLabel2()) if li is not None else "",
            "bild": bild(verwaltung, kunst.get("thumb") or kunst.get("poster") or kunst.get("icon") or kunst.get("landscape")),
            "fanart": bild(verwaltung, kunst.get("fanart")),
            "info": {k: v for k, v in info.items() if k in ("plot", "plotoutline", "year", "duration", "genre", "mediatype", "rating",
                                                           "season", "episode", "tvshowtitle", "premiered", "aired", "studio",
                                                           "mpaa", "director", "tagline", "originaltitle")},
            "kontext": [{"titel": ohne_format(t), "befehl": str(b)} for t, b in (li.kontext() if li is not None else [])][:20]}


def stream_aus_adresse(url, titel=""):
    """Abspielbarer Eintrag mit direkter Adresse (kein plugin://) -> Stream wie aus setResolvedUrl."""
    adresse, header = stream_zerlegen(url)
    pfad = urlsplit(adresse).path.lower()
    return {"url": adresse, "header": header, "art": "hls" if pfad.endswith(".m3u8") else "dash" if pfad.endswith(".mpd") else "datei",
            "drm": False, "lizenz": "", "mime": "", "untertitel": [], "titel": ohne_format(titel)}


def stream(lauf):
    """setResolvedUrl / Player.play -> {url, header, art: hls|dash|datei, drm, lizenz, untertitel, mime, titel}."""
    url, li = lauf.aufgeloest
    if li is not None and not url:
        url = li.getPath()
    adresse, header = stream_zerlegen(url)
    eigen = li.eigenschaften() if li is not None else {}
    for schluessel in ("inputstream.adaptive.stream_headers", "inputstream.adaptive.manifest_headers"):
        if eigen.get(schluessel):
            header.update(dict(parse_qsl(eigen[schluessel])))
    mime = (li.mime() if li is not None else "") or ""
    typ = (eigen.get("inputstream.adaptive.manifest_type") or "").lower()
    pfad = urlsplit(adresse).path.lower()
    art = "hls" if typ == "hls" or pfad.endswith(".m3u8") or "mpegurl" in mime.lower() else \
        "dash" if typ in ("mpd", "ism") or pfad.endswith(".mpd") or "dash" in mime.lower() else "datei"
    lizenz = eigen.get("inputstream.adaptive.license_key") or ""
    drm = bool(lizenz or eigen.get("inputstream.adaptive.license_type") or eigen.get("inputstream.adaptive.drm"))
    return {"url": adresse, "header": header, "art": art, "drm": drm, "lizenz": lizenz, "mime": mime,
            "untertitel": list(li.untertitel() if li is not None else [])[:10],
            "titel": ohne_format(li.getLabel()) if li is not None else ""}


def ergebnis(lauf):
    v = lauf.verwaltung
    antwort = {"url": lauf.url, "addon": {"id": lauf.addon["id"], "name": lauf.addon.get("name", "")},
               "kategorie": ohne_format(lauf.kategorie), "inhalt": lauf.inhalt, "meldungen": lauf.meldungen,
               "befehle": lauf.befehle, "zeit": int(time.time())}
    if lauf.frage:
        antwort["frage"] = lauf.frage
    if lauf.fehler:
        antwort["fehler"] = lauf.fehler
    if lauf.aufgeloest:
        antwort["stream"] = stream(lauf)
    if lauf.weiter:
        antwort["weiter"] = lauf.weiter
    if lauf.neu_laden:
        antwort["neu_laden"] = True
    antwort["eintraege"] = [eintrag(v, u, li, o) for u, li, o in lauf.eintraege[:MAX_EINTRAEGE]]
    return antwort
