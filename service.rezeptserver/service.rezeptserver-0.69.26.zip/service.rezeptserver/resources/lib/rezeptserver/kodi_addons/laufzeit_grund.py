"""Kodi-Addon-Laufzeit, Grundlage: Text, Kodi-Formatierung und plugin://-Adressen.

text() und ohne_format() bilden Kodis String-Umwandlung nach, zerlegen()/stream_zerlegen() lesen die
plugin://- und Stream-Adressen. Der Aufruf selbst und das Ergebnis stehen in laufzeit.py und
laufzeit_ergebnis.py.
"""

import re
from urllib.parse import parse_qsl, urlsplit

MAX_EINTRAEGE = 3000
_FORMAT = re.compile(r"\[/?(?:B|I|UPPERCASE|LOWERCASE|CAPITALIZE|LIGHT)\]|\[/?COLOR[^\]]*\]|\[/?TABS?\]", re.I)


def text(wert):
    """Wie Kodis String-Umwandlung: Bytes sind UTF-8 (sonst stuende "b'…'" in der Oberflaeche)."""
    if isinstance(wert, (bytes, bytearray)):
        return bytes(wert).decode("utf-8", "replace")
    return "" if wert is None else str(wert)


def ohne_format(wert):
    """Kodi-Formatierung ([B], [COLOR red], [CR] …) entfernen."""
    return _FORMAT.sub("", text(wert or "")).replace("[CR]", "\n").replace("[cr]", "\n").strip()


def zerlegen(url):
    """plugin://id/pfad?abfrage -> (id, argv0, abfrage mit ?)."""
    t = urlsplit(str(url or ""))
    if t.scheme != "plugin" or not t.netloc:
        raise ValueError("Keine plugin://-Adresse: %s" % url)
    return t.netloc, "plugin://%s%s" % (t.netloc, t.path or "/"), ("?" + t.query) if t.query else ""


def stream_zerlegen(url):
    """Kodi-Schreibweise 'adresse|User-Agent=…&Referer=…' -> (adresse, header)."""
    url = str(url or "")
    if "|" not in url:
        return url, {}
    adresse, rest = url.split("|", 1)
    return adresse, dict(parse_qsl(rest, keep_blank_values=False))
