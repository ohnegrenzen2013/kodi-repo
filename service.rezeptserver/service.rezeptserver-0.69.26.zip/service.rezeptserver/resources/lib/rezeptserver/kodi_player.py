"""Kodi-Player (Format von TMDb Helper): Sammlung, Ausfuellen und Ausliefern an Kodi.

Ein Player sagt Kodi, wie ein Addon einen Film oder eine Folge oeffnet, z. B.
  "play_movie": "plugin://plugin.video.vavooto/?action=get&id=movie.{tmdb}"
oder als Liste von Schritten (Suche, Tastatur, Auswahl), die nur TMDb Helper selbst abarbeiten kann.

H0rSt
  * verwaltet die Player (Import als ZIP oder JSON, in den Nutzerdaten unter "kodi_player"; Jacktook ist dabei),
  * liefert sie gesammelt als /tmdbhelper/players.zip aus (TMDb Helper: Player per Adresse laden),
  * startet einen Titel auf einem Kodi im Netz: einfache Player direkt mit ausgefuellter Adresse,
    mehrstufige ueber TMDb Helper (Auswahl auf dem Fernseher).
Werte werden fuer die Adresse kodiert; unbekannte Platzhalter bleiben leer.
"""

import base64
import io
import json
import re
import zipfile
from urllib.parse import quote

from .archiv import ZIP_FEHLER

SCHLUESSEL = "kodi_player"
MAX_PLAYER = 300
MAX_DATEI = 64 * 1024
MAX_ZIP = 4 * 1024 * 1024
TMDBHELPER = "plugin.video.themoviedb.helper"
_DATEINAME = re.compile(r"^[\w .()+\-]{1,80}\.json$")
_PLATZHALTER = re.compile(r"\{(\w+)\}")
_FARBE = re.compile(r"\[/?(COLOR[^\]]*|B|I|UPPERCASE|LOWERCASE)\]", re.I)

# Jacktook (plugin.video.jacktook): sucht ueber die eingetragenen Quellen, z. B. H0rSt als Stremio-Addon
EINGEBAUT = {
    "jacktook.select.json": {
        "name": "Jacktook", "plugin": "plugin.video.jacktook", "priority": 200, "is_resolvable": "true",
        "play_movie": "plugin://plugin.video.jacktook/?action=search&mode=movies&rescrape=True&query={title}"
                      "&ids=%7B%22tmdb_id%22%3A+%22{tmdb}%22%2C+%22tvdb_id%22%3A+%22{tvdb}%22%2C+%22imdb_id%22%3A+%22{imdb}%22%7D",
        "play_episode": "plugin://plugin.video.jacktook/?action=search&mode=tv&rescrape=True&query={showname}"
                        "&ids=%7B%22tmdb_id%22%3A+%22{tmdb}%22%2C+%22tvdb_id%22%3A+%22{tvdb}%22%2C+%22imdb_id%22%3A+%22{imdb}%22%7D"
                        "&tv_data=%7B%22name%22%3A+%22{title}%22%2C+%22episode%22%3A+%22{episode}%22%2C+%22season%22%3A+%22{season}%22%7D",
    },
}


class PlayerFehler(ValueError):
    pass


def anzeigename(player):
    """Name ohne Kodi-Formatierung ([COLORyellow]KinoX[/COLOR] -> KinoX)."""
    return _FARBE.sub("", str(player.get("name") or "")).strip() or str(player.get("plugin") or "?")


def pruefe_player(datei, player):
    if not _DATEINAME.match(str(datei)):
        raise PlayerFehler("Dateiname ungültig: %s" % datei)
    if not isinstance(player, dict) or not isinstance(player.get("plugin"), str) or not player["plugin"].strip():
        raise PlayerFehler("%s: kein Player (plugin fehlt)" % datei)
    if not any(k in player for k in ("play_movie", "play_episode", "search_movie", "search_episode")):
        raise PlayerFehler("%s: weder play_movie noch play_episode" % datei)
    if len(json.dumps(player)) > MAX_DATEI:
        raise PlayerFehler("%s: zu groß" % datei)
    return player


def pruefe(einstellung):
    """{"player": {datei: player}} -> bereinigt (fuer Nutzerdaten und Import)."""
    e = einstellung if isinstance(einstellung, dict) else {}
    player = e.get("player") or {}
    if not isinstance(player, dict):
        raise PlayerFehler("kodi_player.player muss ein Objekt sein")
    if len(player) > MAX_PLAYER:
        raise PlayerFehler("Höchstens %d Player" % MAX_PLAYER)
    return {"player": {str(d): pruefe_player(d, p) for d, p in player.items()}}


def _json_laden(text, datei):
    try:
        return json.loads(text)
    except ValueError:
        # Kodi-Player enthalten oft Tabs und Kommentare nicht; Tabs sind in JSON erlaubt, also echter Fehler
        raise PlayerFehler("%s ist kein gültiges JSON" % datei)


def aus_upload(name, inhalt):
    """ZIP (beliebig verschachtelt, nur *.json) oder eine einzelne JSON-Datei -> {datei: player}."""
    if len(inhalt) > MAX_ZIP:
        raise PlayerFehler("Datei zu groß (höchstens 4 MB)")
    gefunden = {}
    if inhalt[:2] == b"PK":
        try:
            archiv = zipfile.ZipFile(io.BytesIO(inhalt))
        except zipfile.BadZipFile:
            raise PlayerFehler("ZIP unlesbar")
        except ZIP_FEHLER as fehler:
            raise PlayerFehler("ZIP unlesbar: %s" % fehler)
        try:
            for info in archiv.infolist():
                datei = info.filename.rsplit("/", 1)[-1]
                if info.is_dir() or not datei.lower().endswith(".json") or datei.startswith("."):
                    continue
                if info.file_size > MAX_DATEI:
                    raise PlayerFehler("%s ist zu groß" % datei)
                gefunden[datei] = pruefe_player(datei, _json_laden(archiv.read(info).decode("utf-8-sig", "replace"), datei))
                if len(gefunden) > MAX_PLAYER:
                    raise PlayerFehler("Höchstens %d Player" % MAX_PLAYER)
        except PlayerFehler:
            raise
        except ZIP_FEHLER as fehler:
            raise PlayerFehler("ZIP unlesbar: %s" % fehler)
        finally:
            archiv.close()
    else:
        datei = (name or "player.json").rsplit("/", 1)[-1]
        if not datei.lower().endswith(".json"):
            datei += ".json"
        gefunden[datei] = pruefe_player(datei, _json_laden(inhalt.decode("utf-8-sig", "replace"), datei))
    if not gefunden:
        raise PlayerFehler("Keine Player (*.json) gefunden")
    return gefunden


def alle(daten):
    """Eingebaute und eigene Player; eigene mit gleichem Namen ersetzen eingebaute."""
    eigene = pruefe(daten.get(SCHLUESSEL))["player"]
    return dict(EINGEBAUT, **eigene)


def _zahl(wert):
    try:
        return int(wert)
    except (TypeError, ValueError):
        return 0


def liste(daten, installiert=None):
    """Fuer die Oberflaeche, nach Prioritaet. installiert: Plugin-IDs des Kodi (None = unbekannt)."""
    eigene = pruefe(daten.get(SCHLUESSEL))["player"]
    ergebnis = []
    for datei, p in alle(daten).items():
        film, folge = p.get("play_movie"), p.get("play_episode")
        ergebnis.append({"datei": datei, "name": anzeigename(p), "plugin": p["plugin"],
                         "prioritaet": _zahl(p.get("priority")),
                         "film": bool(film or p.get("search_movie")), "folge": bool(folge or p.get("search_episode")),
                         "direkt_film": isinstance(film, str), "direkt_folge": isinstance(folge, str),
                         "eingebaut": datei in EINGEBAUT and datei not in eigene,
                         "installiert": None if installiert is None else p["plugin"] in installiert})
    ergebnis.sort(key=lambda x: (x["prioritaet"], x["name"].lower()))
    return ergebnis


def zip_bauen(daten):
    puffer = io.BytesIO()
    with zipfile.ZipFile(puffer, "w", zipfile.ZIP_DEFLATED) as z:
        for datei, p in sorted(alle(daten).items()):
            z.writestr(datei, json.dumps(p, ensure_ascii=False, indent=2))
    return puffer.getvalue()


def werte(info, staffel=None, folge=None):
    """Platzhalter von TMDb Helper aus den H0rSt-Details (Cinemeta)."""
    serie = info.get("typ") == "series"
    folge_info = {}
    if serie and staffel is not None:
        folge_info = next((f for f in info.get("folgen") or [] if f["staffel"] == staffel and f["folge"] == folge), {})
    jahr = re.match(r"\d{4}", str(info.get("jahr") or ""))
    name = str(info.get("titel") or "")
    titel = (folge_info.get("titel") or "Folge %s" % folge) if serie and staffel is not None else name
    return {"title": titel, "originaltitle": titel, "showname": name if serie else "", "name": name,
            "clearname": re.sub(r"[^\w\s]", "", name).strip(), "year": jahr.group(0) if jahr else "",
            "tmdb": str(info.get("tmdb") or ""), "imdb": str(info.get("id") or ""), "tvdb": str(info.get("tvdb") or ""),
            "season": "" if staffel is None else str(staffel), "episode": "" if folge is None else str(folge),
            "poster": str(info.get("poster") or ""), "fanart": str(info.get("hintergrund") or ""),
            "plot": str(info.get("beschreibung") or "")[:500], "de_plot": str(info.get("beschreibung") or "")[:500],
            "premiered": folge_info.get("datum") or "", "firstaired": folge_info.get("datum") or "",
            "epid": "", "epimdb": "", "eptmdb": "", "eptvdb": "", "id": str(info.get("tmdb") or "")}


def ausfuellen(vorlage, w):
    """{platzhalter} -> kodierter Wert (fehlende leer)."""
    return _PLATZHALTER.sub(lambda m: quote(str(w.get(m.group(1).lower(), "")), safe=""), vorlage)


def adresse(daten, datei, info, staffel=None, folge=None):
    """plugin://-Adresse fuer Kodi. datei "tmdbhelper" oder mehrstufiger Player -> ueber TMDb Helper."""
    w = werte(info, staffel, folge)
    if not w["tmdb"] and datei == "tmdbhelper":
        raise PlayerFehler("Für TMDb Helper fehlt die TMDb-Nummer dieses Titels")
    episode = info.get("typ") == "series"
    if episode and staffel is None:
        raise PlayerFehler("Erst eine Folge wählen")
    player = None if datei == "tmdbhelper" else alle(daten).get(datei)
    if datei != "tmdbhelper" and player is None:
        raise PlayerFehler("Unbekannter Player: %s" % datei)
    vorlage = player.get("play_episode" if episode else "play_movie") if player else None
    if isinstance(vorlage, str):
        return ausfuellen(vorlage, w), anzeigename(player)
    if not w["tmdb"]:
        raise PlayerFehler("Dieser Player braucht TMDb Helper, dafür fehlt die TMDb-Nummer")
    url = "plugin://%s/?info=play&tmdb_type=%s&tmdb_id=%s" % (TMDBHELPER, "tv" if episode else "movie", w["tmdb"])
    if episode:
        url += "&season=%s&episode=%s" % (w["season"], w["episode"])
    return url, "TMDb Helper" + (" (" + anzeigename(player) + " auf dem Fernseher wählen)" if player else "")


def import_text(text):
    """JSON aus dem Browser: einzelner Player oder {datei: player}."""
    roh = _json_laden(text, "Eingabe")
    if isinstance(roh, dict) and "plugin" in roh:
        name = re.sub(r"[^\w]+", "_", anzeigename(roh)).strip("_").lower() or "player"
        return {name + ".json": pruefe_player(name + ".json", roh)}
    if isinstance(roh, dict):
        return {d: pruefe_player(d, p) for d, p in roh.items()}
    raise PlayerFehler("Erwartet: ein Player oder {\"datei.json\": player}")


def b64(text):
    try:
        return base64.b64decode(text, validate=True)
    except (ValueError, TypeError):
        raise PlayerFehler("Datei unlesbar (base64)")
