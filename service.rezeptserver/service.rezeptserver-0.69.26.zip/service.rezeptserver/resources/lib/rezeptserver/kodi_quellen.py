"""Kodi-Quellen: Michaz-Repository, Builds, EPG, Senderliste und Player.

Vorbilder: michaz1988/michaz1988.github.io (Kodi-Repository mit EPG und Senderliste,
eigener Build ueber h1.nu/michazbuild), Mastaaa1987/Mastaaa1987.github.io (Kodi-Omega-
Build als Release-ZIP) und das offizielle xbmc/xbmc als Referenz. H0rSt kopiert keine
Addons und startet kein Kodi. Es prueft die Adressen, traegt sie als Quelle ein und
uebernimmt Senderliste und EPG auf Wunsch in Live-TV.
"""

import urllib.request

from .netz import USER_AGENT

NAME = "Kodi-Quellen"
MICHAS = "https://michaz1988.github.io/"
MASTAAA = "https://github.com/Mastaaa1987/Mastaaa1987.github.io"

QUELLEN = [
    {"id": "michaz-repo", "name": "Michaz Repository", "art": "repository",
     "url": "https://michaz1988.github.io/repo/repository.michaz/",
     "addons": "https://michaz1988.github.io/repo/addons.xml",
     "repo": "https://github.com/michaz1988/michaz1988.github.io", "lizenz": "keine Lizenzdatei",
     "hinweis": "In H0rSt als Quelle eintragen; Kodi installiert daraus repository.michaz."},
    {"id": "michaz-epg", "name": "Michaz EPG", "art": "epg",
     "url": "https://github.com/michaz1988/michaz1988.github.io/releases/download/EPG/guide.xml.gz",
     "repo": "https://github.com/michaz1988/michaz1988.github.io", "lizenz": "keine Lizenzdatei",
     "hinweis": "Taeglich erneuerte XMLTV-Datei; als EPG-Quelle in Live-TV uebernehmen."},
    {"id": "michaz-tv", "name": "Michaz Senderliste", "art": "m3u",
     "url": "https://michaz1988.github.io/tv.m3u",
     "repo": "https://github.com/michaz1988/michaz1988.github.io", "lizenz": "keine Lizenzdatei",
     "hinweis": "M3U fuer IPTV Simple und H0rSt; passt zur Michaz-EPG."},
    {"id": "michaz-build", "name": "Michaz Build", "art": "build",
     "url": "https://h1.nu/michazbuild", "repo": "https://github.com/michaz1988/michaz1988.github.io",
     "lizenz": "Sammelbuild (Addons mit eigenen Lizenzen)",
     "hinweis": "Fertiger Kodi-Build mit Addons und userdata (rund 62 MB). H0rSt laedt ihn nicht "
                "automatisch; der Link fuehrt zu Dropbox."},
    {"id": "mastaaa-omega", "name": "Kodi Omega Build (Mastaaa1987)", "art": "build",
     "url": "https://github.com/Mastaaa1987/Mastaaa1987.github.io/releases/download/Test/default.kodi-omega.zip",
     "repo": MASTAAA, "lizenz": "Sammelbuild (Addons mit eigenen Lizenzen)",
     "hinweis": "Kodi-Omega-Build als Release-ZIP (rund 249 MB). Nur von der offiziellen "
                "Release-Seite laden und vor dem Entpacken pruefen."},
    {"id": "mastaaa-releases", "name": "Mastaaa1987 Releases", "art": "build",
     "url": "https://github.com/Mastaaa1987/Mastaaa1987.github.io/releases",
     "repo": MASTAAA, "lizenz": "Sammelbuild (Addons mit eigenen Lizenzen)",
     "hinweis": "Uebersicht der Builds und Test-Fassungen."},
    {"id": "michaz-players", "name": "Player fuer TMDB Helper", "art": "players",
     "url": "https://michaz1988.github.io/players.zip", "repo": "https://github.com/michaz1988/michaz1988.github.io",
     "lizenz": "keine Lizenzdatei",
     "hinweis": "Player-Dateien fuer das Addon context.themoviedb.helper (TMDB Helper)."},
]

ARTEN = {"repository": "Repository", "epg": "EPG", "m3u": "Senderliste", "build": "Build", "players": "Player"}


def _holen(url, zeitgrenze=8.0):
    try:
        anfrage = urllib.request.Request(url, headers={"User-Agent": USER_AGENT}, method="HEAD")
        with urllib.request.urlopen(anfrage, timeout=zeitgrenze) as antwort:
            return int(getattr(antwort, "status", 0) or antwort.getcode() or 0)
    except Exception:
        try:
            anfrage = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
            with urllib.request.urlopen(anfrage, timeout=zeitgrenze) as antwort:
                return int(getattr(antwort, "status", 0) or antwort.getcode() or 0)
        except Exception:
            return 0


def pruefen(holen=None, art=None):
    """Adressen pruefen (nur die gewaehlte Art); gibt den Stand je Quelle zurueck."""
    ergebnis = []
    for q in QUELLEN:
        if art and q["art"] != art:
            continue
        status = int((holen or _holen)(q["url"]))
        ergebnis.append(dict(q, status=status, erreichbar=200 <= status < 400))
    return ergebnis


def zustand(holen=None, pruefen_lassen=False, art=None):
    quellen = pruefen(holen=holen, art=art) if pruefen_lassen else [dict(q, status=0, erreichbar=None) for q in QUELLEN
                                                                    if not art or q["art"] == art]
    return {"name": NAME, "repo": MICHAS, "quellen": quellen, "arten": ARTEN,
            "michaz": MICHAS, "mastaaa": MASTAAA,
            "hinweis": "Repositories werden als Quelle eingetragen, Builds und Player nur verlinkt. "
                       "Fremde Addons stehen unter ihren eigenen Lizenzen; H0rSt installiert sie erst nach Klick."}


def live_tv_quellen():
    """Senderliste und EPG fuer Live-TV, passend zueinander."""
    return {"liste": {"name": "Michaz TV", "url": "https://michaz1988.github.io/tv.m3u", "an": True},
            "epg": "https://github.com/michaz1988/michaz1988.github.io/releases/download/EPG/guide.xml.gz"}
