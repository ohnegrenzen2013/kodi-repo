"""Grundlage des Komplett-Backups: Importe, Logger, Konstanten und der Fehler.
Alles hier wird samt Importen wieder exportiert (rezeptserver.komplettbackup.*)."""


import logging
import os
import shutil
import threading
import time

log = logging.getLogger("rezeptserver")

SCHLUESSEL = "komplettbackup"
DRIVE_ORDNER = "Komplettbackup"  # eigener Drive-Ordner, getrennt von "Sicherungen" (DB-Sicherung)
# Teile, bei denen bestimmte Unterordner nie mitgesichert werden - markenerkennung/tmp ist nach jeder
# Analyse (markenerkennung_lauf.py::_lauf()) immer wieder leer, nie wirklich Daten.
AUSSCHLUSS = {"markenerkennung": ("tmp",)}
INTERVALL_STANDARD = 24
INTERVALL_WAHL = (24, 48, 168)
MAX_TEILE = 40


class KomplettBackupFehler(ValueError):
    pass
