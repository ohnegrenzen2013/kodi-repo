"""Lokale Dateioperationen fuers Komplett-Backup: jeder gewaehlte Teil wird in eine eigene ZIP-Datei
gepackt (ersetzt den frueheren inkrementellen Ordner-Kopierer) und kann von dort wieder eingespielt
werden. Verknuepfungen (Symlinks) werden nie mitgenommen - gleiche Regel wie speicher.groesse(). Ein
eingespielter Teil wird komplett durch den Inhalt der ZIP-Datei ersetzt: Dateien, die seither dazukamen
und nicht im Backup stehen, werden entfernt."""

import zipfile

from . import dateien
from .komplettbackup_grund import KomplettBackupFehler, os, shutil


def _sicherer_name(name):
    if name.startswith("/") or ".." in name.split("/"):
        raise KomplettBackupFehler("Unsichere ZIP-Datei: %s" % name)
    return name


def _hinzufuegen(zf, quelle, arcname, ausschluss, zaehler):
    if os.path.islink(quelle):
        return
    if os.path.isfile(quelle):
        zf.write(quelle, arcname)
        zaehler["dateien"] += 1
        return
    for wurzel, ordner, dateinamen in os.walk(quelle):
        ordner[:] = sorted(o for o in ordner if not o.startswith(".") and o not in ausschluss
                            and not os.path.islink(os.path.join(wurzel, o)))
        rel = os.path.relpath(wurzel, quelle)
        for name in sorted(n for n in dateinamen if not os.path.islink(os.path.join(wurzel, n))):
            pfad = os.path.join(wurzel, name)
            ziel_name = os.path.join(arcname, name) if rel == "." else os.path.join(arcname, rel, name)
            zf.write(pfad, ziel_name)
            zaehler["dateien"] += 1


def zip_erstellen(teile, ziel_zip):
    """teile: [(arcname, quelle, ausschluss), ...] - quelle ist eine Datei oder ein Ordner, landet unter
    arcname im Archiv. Erstellt/ueberschreibt ziel_zip atomar (erst als .tmp schreiben, dann umbenennen).
    Gibt {"dateien": n} zurueck."""
    zaehler = {"dateien": 0}
    os.makedirs(os.path.dirname(ziel_zip) or ".", exist_ok=True)
    tmp = ziel_zip + ".tmp"
    with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zf:
        for arcname, quelle, ausschluss in teile:
            _hinzufuegen(zf, quelle, arcname, ausschluss, zaehler)
    os.replace(tmp, ziel_zip)
    return zaehler


def zip_wiederherstellen(ziel_zip, datenordner):
    """Ersetzt jeden in ziel_zip enthaltenen Top-Level-Namen unter datenordner durch den Inhalt der
    ZIP-Datei - ein vorhandener gleichnamiger Ordner/Datei wird vorher entfernt. Wirft
    KomplettBackupFehler bei fehlender/kaputter ZIP-Datei oder unsicheren Pfaden darin. Gibt
    {"teile": Anzahl der ersetzten Top-Level-Namen} zurueck."""
    if not os.path.isfile(ziel_zip):
        raise KomplettBackupFehler("Gibt es nicht: %s" % ziel_zip)
    try:
        with zipfile.ZipFile(ziel_zip) as zf:
            namen = zf.namelist()
            for name in namen:
                _sicherer_name(name)
            oben = sorted({n.split("/", 1)[0] for n in namen if n.split("/", 1)[0]})
            for name in oben:
                ziel = os.path.join(datenordner, name)
                if os.path.islink(ziel) or os.path.isfile(ziel):
                    os.remove(ziel)
                elif os.path.isdir(ziel):
                    shutil.rmtree(ziel)
            zf.extractall(datenordner)
    except zipfile.BadZipFile as fehler:
        raise KomplettBackupFehler("ZIP-Datei beschädigt: %s" % fehler)
    return {"teile": len(oben)}


def ziel_pruefen(pfad):
    """Validiert/erzeugt das Backup-Ziel: braucht einen vollstaendigen Pfad, legt ihn bei Bedarf an und
    prueft die Schreibbarkeit. Wirft KomplettBackupFehler, gibt sonst den aufgeloesten Pfad zurueck."""
    pfad = str(pfad or "").strip()
    if not os.path.isabs(pfad):
        raise KomplettBackupFehler("Zielordner braucht einen vollständigen Pfad")
    try:
        os.makedirs(pfad, exist_ok=True)
    except OSError as fehler:
        raise KomplettBackupFehler("Zielordner nicht anlegbar: %s" % (fehler.strerror or fehler))
    if not dateien._schreibbar(pfad):
        raise KomplettBackupFehler("In %s darf H0rSt nicht schreiben" % pfad)
    return os.path.realpath(pfad)
