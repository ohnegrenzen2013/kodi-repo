"""Welche Teile das Komplett-Backup einzeln anbietet: speicher.BEREICHE (dieselbe, schon gepflegte
Aufteilung wie bei Belegung/Aufräumen), PLUS jeder einzelne Ordner, den speicher.py nur in seinem
"Sonstiges"-Sammeltopf zusammenfasst (markenerkennung, traum, appstore, badges, ...) - hier aber
einzeln waehlbar, nicht als ein Klumpen.

"aktualisierung" (Code aus GitHub, App-Update) bleibt aussen vor - aus GitHub rekonstruierbar, gleiche
Ausnahme wie beim "Aufräumen"-Feature. Alle anderen BEREICHE-Teile (auch "system" = nutzerdaten.db)
bleiben waehlbar: der Nutzer bat um "alle Ordner und alle Daten", die Datenbank ist zwar schon ueber
die bestehende Sicherung abgedeckt, aber ihr Fehlen hier waere eine stille Lücke in "alle Daten"."""

from . import speicher
from .komplettbackup_grund import AUSSCHLUSS, MAX_TEILE, os

_AUSGESCHLOSSENE_BEREICHE = {"aktualisierung"}


def _bekannte_namen(namen):
    bekannt = set()
    for _bid, _name, _bereich, pfade, _art in speicher.BEREICHE:
        for muster in pfade:
            if muster.endswith("*"):
                bekannt.update(n for n in namen if n.startswith(muster[:-1]))
            else:
                bekannt.add(muster)
    return bekannt


def roh(datenordner):
    """Alle waehlbaren Teile: [{"id", "name", "pfade": [rel,...], "ausschluss": (name,...)}].
    pfade wie speicher.BEREICHE ("name*" = Praefix-Muster), ausschluss: Unterordnernamen, die beim
    Sichern an jeder Tiefe uebersprungen werden."""
    teile = [{"id": bid, "name": name, "pfade": list(pfade), "ausschluss": AUSSCHLUSS.get(bid, ())}
             for bid, name, _bereich, pfade, _art in speicher.BEREICHE if bid not in _AUSGESCHLOSSENE_BEREICHE]
    try:
        namen = os.listdir(datenordner)
    except OSError:
        namen = []
    bekannt = _bekannte_namen(namen)
    for name in sorted(namen):
        if name in bekannt or name.startswith("."):
            continue
        teile.append({"id": name, "name": name, "pfade": [name], "ausschluss": AUSSCHLUSS.get(name, ())})
    return teile[:MAX_TEILE]


def aufgeloest(namen, muster):
    """Ein pfade-Eintrag ("name" oder "name*") gegen die tatsaechlichen Top-Level-Namen aufgeloest."""
    if not muster.endswith("*"):
        return [muster]
    return [n for n in namen if n.startswith(muster[:-1])]


def liste(datenordner):
    """roh() + Groesse/Dateizahl je Teil (speicher.groesse() je aufgeloestem Pfad - ein Durchgang, reicht
    fuer eine Einstellungsseite). Groesste zuerst."""
    try:
        namen = os.listdir(datenordner)
    except OSError:
        namen = []
    ergebnis = []
    for t in roh(datenordner):
        summe = anzahl = 0
        for muster in t["pfade"]:
            for rel in aufgeloest(namen, muster):
                b, n = speicher.groesse(os.path.join(datenordner, rel))
                summe, anzahl = summe + b, anzahl + n
        ergebnis.append({"id": t["id"], "name": t["name"], "groesse": summe, "dateien": anzahl})
    return sorted(ergebnis, key=lambda x: -x["groesse"])
