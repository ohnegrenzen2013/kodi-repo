"""Nutzerdaten: Token, Zugangsdaten je Anbieter, eigene Anbieter, Zeitgrenzen, Sprachen.

Gespeichert in einer SQLite-Datenbank (nutzerdaten.db), nur fuer den Besitzer
lesbar (0600). Sicherungen koennen auf Wunsch mit Passwort verschluesselt
werden (verschluesseln/entschluesseln, PBKDF2-SHA256); die Datenbank selbst
liegt im Klartext.

Nach aussen bleibt alles ein dict im frueheren konfig.json-Format:
  {"token": "", "einstellungen": {konto: {schluessel: wert}},
   "anbieter": {id: {"name", "kategorie", "anmeldung"[, "typ", "vorlage", "geaendert"]}}, "zeitgrenzen": {}, "sprachen": {}, ...}

exportiere()/importiere() schreiben und lesen eine JSON-Sicherung. importiere()
nimmt auch eine alte konfig.json. Eine konfig.json neben der Datenbank wird beim
ersten Zugriff automatisch uebernommen und danach in konfig.json.uebernommen umbenannt.
"""

import base64
import hashlib
import hmac
import json
import logging
import os
import secrets
import sqlite3
import time
from contextlib import closing

from .ab18 import SCHLUESSEL as AB18_SCHLUESSEL, Ab18Fehler, pruefe as pruefe_ab18
from .anbieter import AnbieterFehler, pruefe_eigene
from .kodi_player import SCHLUESSEL as KODI_SCHLUESSEL, PlayerFehler, pruefe as pruefe_kodi_player
from .waechter import SCHLUESSEL as WAECHTER_SCHLUESSEL, WaechterFehler, pruefe as pruefe_waechter
from .beobachtungen import SCHLUESSEL as BEOBACHTUNGEN_SCHLUESSEL, BeobachtungFehler, pruefe as pruefe_beobachtungen
from .badges import SCHLUESSEL as BADGES_SCHLUESSEL, BadgeFehler, pruefe as pruefe_badges
from .youtube import SCHLUESSEL as YOUTUBE_SCHLUESSEL, YoutubeFehler, pruefe as pruefe_youtube
from .ed2k import SCHLUESSEL as ED2K_SCHLUESSEL, Ed2kFehler, pruefe as pruefe_ed2k
from .sicherheit import SCHLUESSEL as SICHERHEIT_SCHLUESSEL, SicherheitsFehler, pruefe as pruefe_sicherheit
from .filtern import FilterFehler, pruefe as pruefe_filter
from .links import LinkFehler, pruefe as pruefe_links
from .livetv import LiveTvFehler, pruefe as pruefe_livetv

log = logging.getLogger("rezeptserver")

DATEINAME = "nutzerdaten.db"
ALTDATEI = "konfig.json"
SCHEMA = 4  # 1: optionen, einstellungen; 2: anbieter; 3: anbieter.typ und anbieter.vorlage; 4: anbieter.geaendert
FORMAT = "rezeptserver-nutzerdaten"
FORMAT_VERSION = 2  # 1: Klartext; 2: zusaetzlich verschluesselt ("verschluesselt") und Geraetedaten ("geraet")
KDF_RUNDEN = 200000

STANDARD = {"token": "", "einstellungen": {}, "anbieter": {}, "zeitgrenzen": {},
            "sprachen": {"audio": ["de", "en"], "untertitel": ["de", "en"]}}


class DatenFehler(ValueError):
    """Datenbank oder Sicherung ist unbrauchbar."""


def _kopie(daten):
    return json.loads(json.dumps(daten))


def datenbank_pfad(pfad):
    """Alte Aufrufe mit .../konfig.json zeigen auf nutzerdaten.db im selben Ordner."""
    if pfad.lower().endswith(".json"):
        return os.path.join(os.path.dirname(pfad), DATEINAME)
    return pfad


def _altdatei(pfad):
    if pfad.lower().endswith(".json"):
        return pfad
    return os.path.join(os.path.dirname(pfad), ALTDATEI)


def _verbinde(db):
    ordner = os.path.dirname(os.path.abspath(db))
    os.makedirs(ordner, exist_ok=True)
    if not os.path.exists(db):
        os.close(os.open(db, os.O_WRONLY | os.O_CREAT, 0o600))
    con = sqlite3.connect(db, timeout=10)
    version = con.execute("PRAGMA user_version").fetchone()[0]
    if version > SCHEMA:
        con.close()
        raise DatenFehler("%s stammt aus einer neueren Version des Rezeptservers (Schema %d)" % (db, version))
    if version < SCHEMA:
        with con:
            con.execute("CREATE TABLE IF NOT EXISTS optionen ("
                        "schluessel TEXT PRIMARY KEY, wert TEXT NOT NULL)")
            con.execute("CREATE TABLE IF NOT EXISTS einstellungen ("
                        "konto TEXT NOT NULL, schluessel TEXT NOT NULL, wert TEXT NOT NULL, "
                        "PRIMARY KEY (konto, schluessel))")
            con.execute("CREATE TABLE IF NOT EXISTS anbieter ("
                        "id TEXT PRIMARY KEY, name TEXT NOT NULL, kategorie TEXT NOT NULL, anmeldung TEXT NOT NULL, "
                        "typ TEXT NOT NULL DEFAULT '', vorlage TEXT NOT NULL DEFAULT '', "
                        "geaendert INTEGER NOT NULL DEFAULT 0)")
            spalten = {zeile[1] for zeile in con.execute("PRAGMA table_info(anbieter)")}
            for spalte in ("typ", "vorlage"):
                if spalte not in spalten:
                    con.execute("ALTER TABLE anbieter ADD COLUMN %s TEXT NOT NULL DEFAULT ''" % spalte)
            if "geaendert" not in spalten:
                con.execute("ALTER TABLE anbieter ADD COLUMN geaendert INTEGER NOT NULL DEFAULT 0")
            con.execute("PRAGMA user_version = %d" % SCHEMA)
    return con


def _pruefe(daten):
    """Gibt eine bereinigte Kopie zurueck oder wirft DatenFehler."""
    if not isinstance(daten, dict):
        raise DatenFehler("Nutzerdaten muessen ein JSON-Objekt sein")
    daten = _kopie(daten)
    einstellungen = daten.get("einstellungen")
    if einstellungen is None:
        einstellungen = {}
    if not isinstance(einstellungen, dict) or not all(isinstance(w, dict) for w in einstellungen.values()):
        raise DatenFehler("einstellungen muss die Form {konto: {schluessel: wert}} haben")
    daten["einstellungen"] = einstellungen
    eigene = daten.get("anbieter")
    daten["anbieter"] = {} if eigene is None else eigene
    from . import heimspeicher, kameras, telegram
    try:
        pruefe_eigene(daten["anbieter"])
        if "filter" in daten:
            daten["filter"] = pruefe_filter(daten["filter"])
        if "livetv" in daten:
            daten["livetv"] = pruefe_livetv(daten["livetv"])
        if "links" in daten:
            daten["links"] = pruefe_links(daten["links"])
        if AB18_SCHLUESSEL in daten:
            daten[AB18_SCHLUESSEL] = pruefe_ab18(daten[AB18_SCHLUESSEL])
        if SICHERHEIT_SCHLUESSEL in daten:
            daten[SICHERHEIT_SCHLUESSEL] = pruefe_sicherheit(daten[SICHERHEIT_SCHLUESSEL])
        if KODI_SCHLUESSEL in daten:
            daten[KODI_SCHLUESSEL] = pruefe_kodi_player(daten[KODI_SCHLUESSEL])
        if WAECHTER_SCHLUESSEL in daten:
            daten[WAECHTER_SCHLUESSEL] = pruefe_waechter(daten[WAECHTER_SCHLUESSEL])
        if BEOBACHTUNGEN_SCHLUESSEL in daten:
            daten[BEOBACHTUNGEN_SCHLUESSEL] = pruefe_beobachtungen(daten[BEOBACHTUNGEN_SCHLUESSEL])
        if BADGES_SCHLUESSEL in daten:
            daten[BADGES_SCHLUESSEL] = pruefe_badges(daten[BADGES_SCHLUESSEL])
        if YOUTUBE_SCHLUESSEL in daten:
            daten[YOUTUBE_SCHLUESSEL] = pruefe_youtube(daten[YOUTUBE_SCHLUESSEL])
        if ED2K_SCHLUESSEL in daten:
            daten[ED2K_SCHLUESSEL] = pruefe_ed2k(daten[ED2K_SCHLUESSEL])
        if heimspeicher.SCHLUESSEL in daten:
            daten[heimspeicher.SCHLUESSEL] = heimspeicher.pruefe(daten[heimspeicher.SCHLUESSEL])
        if kameras.SCHLUESSEL in daten:
            daten[kameras.SCHLUESSEL] = kameras.pruefe(daten[kameras.SCHLUESSEL])
        if telegram.SCHLUESSEL in daten:
            try:
                daten[telegram.SCHLUESSEL] = telegram.pruefe(daten[telegram.SCHLUESSEL])
            except telegram.TelegramFehler as fehler:
                raise DatenFehler("telegram: %s" % fehler)
    except (heimspeicher.SpeicherFehler, kameras.KameraFehler) as e:
        raise DatenFehler(str(e))
    except (AnbieterFehler, FilterFehler, LiveTvFehler, LinkFehler, Ab18Fehler, SicherheitsFehler, PlayerFehler,
            WaechterFehler, BeobachtungFehler, BadgeFehler, YoutubeFehler, Ed2kFehler) as e:
        raise DatenFehler(str(e))
    return daten


def _schreibe(con, daten):
    with con:
        con.execute("DELETE FROM optionen")
        con.execute("DELETE FROM einstellungen")
        con.execute("DELETE FROM anbieter")
        con.executemany("INSERT INTO optionen VALUES (?, ?)",
                        [(k, json.dumps(w, ensure_ascii=False)) for k, w in daten.items()
                         if k not in ("einstellungen", "anbieter")])
        con.executemany("INSERT INTO anbieter (id, name, kategorie, anmeldung, typ, vorlage, geaendert) "
                        "VALUES (?, ?, ?, ?, ?, ?, ?)",
                        [(i, a["name"], a["kategorie"], a["anmeldung"], a.get("typ", ""), a.get("vorlage", ""),
                          int(a.get("geaendert") or 0))
                         for i, a in daten["anbieter"].items()])
        con.executemany("INSERT INTO einstellungen VALUES (?, ?, ?)",
                        [(konto, k, json.dumps(w, ensure_ascii=False))
                         for konto, werte in daten["einstellungen"].items() for k, w in werte.items()])


def _lies(con):
    daten = {k: json.loads(w) for k, w in con.execute("SELECT schluessel, wert FROM optionen")}
    einstellungen = {}
    for konto, k, w in con.execute("SELECT konto, schluessel, wert FROM einstellungen ORDER BY konto, schluessel"):
        einstellungen.setdefault(konto, {})[k] = json.loads(w)
    daten["einstellungen"] = einstellungen
    anbieter = {}
    for i, n, k, a, t, v, g in con.execute(
            "SELECT id, name, kategorie, anmeldung, typ, vorlage, geaendert FROM anbieter ORDER BY id"):
        eintrag = anbieter[i] = {"name": n, "kategorie": k, "anmeldung": a}
        if t:
            eintrag["typ"] = t
        if v:
            eintrag["vorlage"] = v
        if g:
            eintrag["geaendert"] = g
    daten["anbieter"] = anbieter
    return daten


def _altdatei_uebernehmen(pfad, db):
    alt = _altdatei(pfad)
    if os.path.exists(db) or not os.path.isfile(alt):
        return
    with open(alt, encoding="utf-8") as f:
        daten = _pruefe(json.load(f))
    with closing(_verbinde(db)) as con:
        _schreibe(con, daten)
    os.replace(alt, alt + ".uebernommen")
    log.info("%s in die Datenbank %s uebernommen (alte Datei: %s.uebernommen)", alt, db, alt)


def lade(pfad):
    db = datenbank_pfad(pfad)
    _altdatei_uebernehmen(pfad, db)
    if os.path.isfile(db):
        with closing(_verbinde(db)) as con:
            daten = _lies(con)
    else:
        daten = {}
    for schluessel, wert in STANDARD.items():
        daten.setdefault(schluessel, _kopie(wert))
    return daten


def speichere(pfad, daten):
    db = datenbank_pfad(pfad)
    _altdatei_uebernehmen(pfad, db)
    daten = _pruefe(daten)
    with closing(_verbinde(db)) as con:
        _schreibe(con, daten)


def neues_token():
    return secrets.token_urlsafe(18)


# --- Sicherung -------------------------------------------------------------

def _schluessel(passwort, salz):
    roh = hashlib.pbkdf2_hmac("sha256", str(passwort).encode("utf-8"), salz, KDF_RUNDEN, dklen=64)
    return roh[:32], roh[32:]


def _strom(schluessel, nonce, daten):
    """HMAC-SHA256 im Zaehlermodus als Schluesselstrom (nur Standardbibliothek)."""
    ausgabe = bytearray(len(daten))
    for block in range(0, len(daten), 32):
        strom = hmac.new(schluessel, nonce + block.to_bytes(8, "big"), hashlib.sha256).digest()
        teil = daten[block:block + 32]
        ausgabe[block:block + len(teil)] = bytes(a ^ b for a, b in zip(teil, strom))
    return bytes(ausgabe)


def verschluesseln(klartext, passwort):
    salz, nonce = secrets.token_bytes(16), secrets.token_bytes(16)
    schluessel, mac = _schluessel(passwort, salz)
    geheim = _strom(schluessel, nonce, klartext)
    pruefung = hmac.new(mac, salz + nonce + geheim, hashlib.sha256).digest()
    b64 = lambda b: base64.b64encode(b).decode("ascii")
    return {"kdf": "pbkdf2-sha256", "runden": KDF_RUNDEN, "salz": b64(salz), "nonce": b64(nonce),
            "daten": b64(geheim), "pruefung": b64(pruefung)}


def entschluesseln(teil, passwort):
    try:
        salz, nonce, geheim, pruefung = (base64.b64decode(teil[k]) for k in ("salz", "nonce", "daten", "pruefung"))
    except (KeyError, TypeError, ValueError):
        raise DatenFehler("Verschluesselte Sicherung ist beschaedigt")
    if teil.get("kdf") != "pbkdf2-sha256" or teil.get("runden") != KDF_RUNDEN:
        raise DatenFehler("Unbekannte Verschluesselung")
    if not passwort:
        raise DatenFehler("Die Sicherung ist verschluesselt: Passwort angeben")
    schluessel, mac = _schluessel(passwort, salz)
    if not hmac.compare_digest(hmac.new(mac, salz + nonce + geheim, hashlib.sha256).digest(), pruefung):
        raise DatenFehler("Passwort falsch oder Sicherung veraendert")
    return _strom(schluessel, nonce, geheim)


def sicherung(pfad, passwort=None, geraet=None):
    """Alle Nutzerdaten (Anbieter, Zugangsdaten, alle Einstellungen, Telegram, Speicher, FTP-Server, Aktualisierung,
    Ab 18, Sammlungen ...) als eine JSON-Datei, auf Wunsch mit Geraetedaten des Browsers (geraet) und mit Passwort
    verschluesselt (PBKDF2-SHA256, HMAC-SHA256-Strom, HMAC-Pruefsumme). Ohne Passwort stehen Passwoerter im Klartext."""
    from . import __version__

    inhalt = {"daten": lade(pfad)}
    if geraet:
        inhalt["geraet"] = geraet
    kopf = {"format": FORMAT, "version": FORMAT_VERSION if (passwort or geraet) else 1,
            "erstellt": time.strftime("%Y-%m-%dT%H:%M:%SZ", time.gmtime()), "programm": __version__}
    if passwort:
        kopf["verschluesselt"] = verschluesseln(json.dumps(inhalt, ensure_ascii=False).encode("utf-8"), passwort)
    else:
        kopf.update(inhalt)
    return json.dumps(kopf, indent=2, ensure_ascii=False) + "\n"


def ist_verschluesselt(text):
    try:
        roh = json.loads(text)
    except ValueError:
        return False
    return isinstance(roh, dict) and "verschluesselt" in roh


def aus_sicherung(text, passwort=None, mit_geraet=False):
    """Liest eine Sicherung oder eine alte konfig.json und gibt die Nutzerdaten zurueck
    (mit mit_geraet: (daten, geraetedaten))."""
    try:
        roh = json.loads(text)
    except ValueError as e:
        raise DatenFehler("Keine gueltige JSON-Datei: %s" % e)
    geraet = {}
    if isinstance(roh, dict) and "format" in roh:
        if roh["format"] != FORMAT:
            raise DatenFehler("Unbekanntes Format: %s" % roh["format"])
        if not isinstance(roh.get("version"), int) or roh["version"] > FORMAT_VERSION:
            raise DatenFehler("Sicherung stammt aus einer neueren Version des Rezeptservers")
        if "verschluesselt" in roh:
            try:
                roh = dict(roh, **json.loads(entschluesseln(roh["verschluesselt"], passwort).decode("utf-8")))
            except (ValueError, UnicodeDecodeError):
                raise DatenFehler("Passwort falsch oder Sicherung veraendert")
        geraet = roh.get("geraet") if isinstance(roh.get("geraet"), dict) else {}
        roh = roh.get("daten")
    daten = _pruefe(roh)
    return (daten, geraet) if mit_geraet else daten


def einlesen(pfad, text, zusammenfuehren=False, passwort=None):
    """Uebernimmt eine Sicherung. Ohne zusammenfuehren ersetzt sie alle Nutzerdaten,
    mit zusammenfuehren gewinnt die Sicherung nur bei den Werten, die sie enthaelt.
    Gibt die Zahl der Einstellungen in der Sicherung zurueck."""
    neu = aus_sicherung(text, passwort)
    anzahl = sum(len(w) for w in neu["einstellungen"].values())
    if zusammenfuehren:
        daten = lade(pfad)
        for konto, werte in neu.pop("einstellungen").items():
            daten["einstellungen"].setdefault(konto, {}).update(werte)
        daten["anbieter"].update(neu.pop("anbieter"))
        daten.update(neu)
        neu = daten
    speichere(pfad, neu)
    return anzahl


def exportiere(pfad, ziel, passwort=None):
    """Schreibt die Sicherung nach ziel (nur fuer den Besitzer lesbar)."""
    text = sicherung(pfad, passwort)
    temp = ziel + ".neu"
    fd = os.open(temp, os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="utf-8") as f:
        f.write(text)
    os.replace(temp, ziel)


def importiere(pfad, quelle, zusammenfuehren=False, passwort=None):
    with open(quelle, encoding="utf-8") as f:
        return einlesen(pfad, f.read(), zusammenfuehren, passwort)
