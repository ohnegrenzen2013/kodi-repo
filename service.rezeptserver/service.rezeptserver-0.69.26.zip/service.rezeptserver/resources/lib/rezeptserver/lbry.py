"""LBRY/Odysee: suchen, Treffer anzeigen und eine Wiedergabe-Adresse holen.

Vorbild: lbryio/lbry-sdk (MIT). H0rSt startet den LBRY-Daemon nicht. Es fragt entweder
den lokalen Daemon (JSON-RPC, Standard http://127.0.0.1:5279) oder die oeffentliche
Odysee-SDK-Bruecke (https://api.na-backend.odysee.com/api/v1/proxy). Gesucht wird mit
`claim_search`, die Wiedergabe-Adresse kommt aus `get` (`streaming_url`).

Es werden keine Konten, Schluessel oder Wallets angelegt. Die oeffentliche Suche ist
nur aktiv, wenn `lbry_an` in den Einstellungen nicht ausgeschaltet ist.
"""

import ipaddress
import json
import urllib.request
from urllib.parse import quote, urlsplit

from .netz import USER_AGENT

NAME = "LBRY/Odysee"
REPO = "https://github.com/lbryio/lbry-sdk"
STAND = "LBRY SDK"
LIZENZ = "MIT"
DAEMON = "http://127.0.0.1:5279"
PROXY = "https://api.na-backend.odysee.com/api/v1/proxy"
SUCHE = "https://lighthouse.odysee.tv/search"
MAX_TREFFER = 40


class LbryFehler(ValueError):
    pass


def _lokal(host):
    host = str(host or "").lower()
    if host == "localhost" or host.endswith(".local"):
        return True
    try:
        ip = ipaddress.ip_address(host)
    except ValueError:
        return False
    return ip.is_loopback or ip.is_private or ip.is_link_local


def daemon_url(werte=None):
    werte = werte if isinstance(werte, dict) else {}
    roh = str(werte.get("lbry_daemon") or DAEMON).strip()
    try:
        teile = urlsplit(roh)
    except ValueError:
        return DAEMON
    if teile.scheme not in ("http", "https") or not teile.hostname or not _lokal(teile.hostname):
        return DAEMON
    return roh.rstrip("/")[:300]


def _holen(url, kopf=None, daten=None, zeitgrenze=12.0):
    header = {"User-Agent": USER_AGENT, "Accept": "application/json"}
    header.update(kopf or {})
    try:
        anfrage = urllib.request.Request(url, data=daten, headers=header)
        with urllib.request.urlopen(anfrage, timeout=zeitgrenze) as antwort:
            return int(getattr(antwort, "status", 0) or antwort.getcode() or 0), antwort.read(2 * 1024 * 1024)
    except Exception:
        return 0, b""


def rpc(methode, params=None, werte=None, holen=None):
    """JSON-RPC an den lokalen Daemon oder an die Odysee-Bruecke; gibt result zurueck."""
    werte = werte if isinstance(werte, dict) else {}
    ziel = daemon_url(werte) if str(werte.get("lbry_daemon") or "").strip() else PROXY + "?m=" + quote(methode)
    koerper = json.dumps({"jsonrpc": "2.0", "method": methode, "params": params or {}, "id": 1}).encode("utf-8")
    status, inhalt = (holen or _holen)(ziel, {"Content-Type": "application/json"}, koerper)
    if status != 200 or not inhalt:
        raise LbryFehler("LBRY antwortet nicht (HTTP %d)" % status)
    try:
        daten = json.loads(inhalt.decode("utf-8", "replace"))
    except (ValueError, UnicodeDecodeError):
        raise LbryFehler("LBRY-Antwort ist kein JSON")
    if not isinstance(daten, dict):
        raise LbryFehler("LBRY-Antwort ist kein Objekt")
    if daten.get("error"):
        fehler = daten["error"]
        raise LbryFehler(str(fehler.get("message") if isinstance(fehler, dict) else fehler)[:300])
    return daten.get("result")


def _text(wert, grenze=300):
    return " ".join(str(wert or "").split())[:grenze]


def treffer(item):
    """Einen claim_search-Treffer in die Form der Oberflaeche bringen."""
    if not isinstance(item, dict):
        raise LbryFehler("Treffer ist kein Objekt")
    name = _text(item.get("name"), 200)
    claim_id = _text(item.get("claim_id") or item.get("claimId"), 80)
    if not name or not claim_id:
        return None
    wert = item.get("value") if isinstance(item.get("value"), dict) else {}
    video = wert.get("video") if isinstance(wert.get("video"), dict) else {}
    audio = wert.get("audio") if isinstance(wert.get("audio"), dict) else {}
    kanal = ""
    for quelle in (item, wert):
        for feld in ("signing_channel", "channel"):
            k = quelle.get(feld) if isinstance(quelle.get(feld), dict) else {}
            if not k:
                continue
            wert_k = k.get("value") if isinstance(k.get("value"), dict) else {}
            kanal = k.get("name") or wert_k.get("title") or ""
            if kanal:
                break
        if kanal:
            break
    bild = ""
    if isinstance(wert.get("thumbnail"), dict):
        bild = _text(wert["thumbnail"].get("url"), 500)
    dauer = video.get("duration") or audio.get("duration") or wert.get("duration") or 0
    try:
        dauer = int(dauer or 0)
    except (TypeError, ValueError):
        dauer = 0
    return {"name": name, "claim_id": claim_id, "titel": _text(wert.get("title") or name),
            "kanal": _text(kanal, 120), "bild": bild, "dauer": dauer,
            "url": "https://odysee.com/" + quote(name, safe="") + ":" + claim_id,
            "lbry": "lbry://" + name + "#" + claim_id,
            "beschreibung": _text(wert.get("description") or "", 500)}


def suchen(text, werte=None, holen=None, grenze=MAX_TREFFER):
    """Volltextsuche; gibt eine Liste von Treffern zurueck (ohne Netz nur mit holen)."""
    text = _text(text, 200)
    if not text:
        raise LbryFehler("Suchbegriff fehlt")
    werte = werte if isinstance(werte, dict) else {}
    if werte.get("lbry_an") is False:
        raise LbryFehler("LBRY/Odysee ist in den Einstellungen ausgeschaltet")
    try:
        grenze = max(1, min(MAX_TREFFER, int(grenze)))
    except (TypeError, ValueError):
        grenze = MAX_TREFFER
    ergebnis = rpc("claim_search", {"text": text, "page_size": grenze, "has_source": True,
                                    "order_by": ["trending_group", "release_time"]}, werte, holen)
    eintraege = ergebnis.get("items") if isinstance(ergebnis, dict) else []
    treffer_liste = []
    for item in eintraege if isinstance(eintraege, list) else []:
        try:
            t = treffer(item)
        except LbryFehler:
            t = None
        if t:
            treffer_liste.append(t)
    return {"text": text, "treffer": treffer_liste, "anzahl": len(treffer_liste)}


def aufloesen(name, claim_id, werte=None, holen=None):
    """Wiedergabe-Adresse (streaming_url) eines Treffers holen."""
    name, claim_id = _text(name, 200), _text(claim_id, 80)
    if not name or not claim_id:
        raise LbryFehler("Name und claim_id noetig")
    uri = "lbry://" + name + "#" + claim_id
    ergebnis = rpc("get", {"uri": uri, "save_file": False}, werte, holen)
    if not isinstance(ergebnis, dict):
        raise LbryFehler("LBRY lieferte keine Datei")
    url = _text(ergebnis.get("streaming_url"), 2000)
    if not url.startswith(("http://", "https://")):
        raise LbryFehler("Keine Wiedergabe-Adresse (kein Stream oder keine Seeds)")
    art = "hls" if ".m3u8" in url.lower() else "video"
    return {"name": name, "claim_id": claim_id, "url": url, "art": art,
            "mime": _text(ergebnis.get("mime_type"), 100), "groesse": int(ergebnis.get("total_bytes") or 0)}


def zustand(werte=None, holen=None, pruefen=False):
    """Verbindung und Einstellungen; die oeffentliche Suche wird nur auf Wunsch geprueft."""
    werte = werte if isinstance(werte, dict) else {}
    an = werte.get("lbry_an") is not False
    daemon = daemon_url(werte)
    daemon_an = bool(str(werte.get("lbry_daemon") or "").strip())
    erreichbar, meldung = False, ""
    if not an:
        meldung = "Ausgeschaltet – LBRY/Odysee wird nicht gefragt."
    elif not pruefen:
        meldung = "Nicht geprueft – Suche und Wiedergabe werden erst auf Knopfdruck gefragt."
    else:
        try:
            ergebnis = rpc("claim_search", {"text": "odysee", "page_size": 1, "has_source": True}, werte, holen)
            erreichbar = isinstance(ergebnis, dict)
            meldung = "LBRY/Odysee antwortet." if erreichbar else "LBRY/Odysee antwortet ohne Ergebnis."
        except LbryFehler as fehler:
            meldung = str(fehler)
    return {"name": NAME, "repo": REPO, "stand": STAND, "lizenz": LIZENZ, "an": an,
            "daemon": daemon, "daemon_an": daemon_an, "proxy": PROXY, "suche": SUCHE, "erreichbar": erreichbar,
            "meldung": meldung, "max_treffer": MAX_TREFFER}
