"""Link-Reiniger: Tracking entfernen, soziale Links umschreiben, private Werte erkennen.

Vorbild ist FixupXer (NeatCode-Labs, GPL-3.0-or-later, https://fixupxer.com): Alles
laeuft lokal, ohne Netz, ohne Konto. H0rSt baut die Regeln in eigenem Python nach.
Unbekannte Parameter bleiben stehen, weil sie oft Suche, Artikel oder Variante waehlen.
Die Regeln und der Frontend-Katalog stehen in link_reiniger_regeln.py.
"""

import re
from urllib.parse import parse_qs, unquote, urlsplit, urlunsplit

from .link_reiniger_regeln import (FRONTENDS, MAX_REGELN, MAX_VERLAUF, PRAEFIXE, REGELN, SCHLUESSEL,
                                   SENSIBLE, STANDARD, TRACKING, ReinigerFehler, _EMAIL, _JWT, _ZAHL,
                                   _frontend, _host, _passt, _regel_fuer, einstellungen, pruefe)

__all__ = ["FRONTENDS", "MAX_REGELN", "MAX_VERLAUF", "PRAEFIXE", "REGELN", "SCHLUESSEL", "SENSIBLE",
           "STANDARD", "TRACKING", "ReinigerFehler", "aendern", "einstellungen", "pruefe", "private_funde",
           "reinigen", "verlauf_merken"]


def _params(query):
    return [x for x in query.split("&") if x]


def _name(pair):
    return pair.split("=", 1)[0]


def _wert(pair):
    return pair.split("=", 1)[1] if "=" in pair else ""


def _clean(url, cfg):
    geteilt = urlsplit(url)
    if geteilt.scheme not in ("http", "https") or not geteilt.hostname:
        raise ReinigerFehler("Nur http(s)-Adressen")
    host = geteilt.hostname.lower()
    if any(_passt(host, h) for h in cfg.get("hosts_aus") or []):
        return url, [], host
    entfernt = []
    eigene = _regel_fuer(host)
    entfernen, behalten, praefixe = (eigene if eigene else (set(), set(), ()))
    entfernen = set(entfernen) | set(cfg.get("entfernen") or [])
    behalten = set(behalten) | set(cfg.get("behalten") or [])
    for r in cfg.get("regeln") or []:
        if r.get("an") is False or not _passt(host, r["host"]):
            continue
        if r["aktion"] == "entfernen":
            entfernen.update(r["parameter"])
        elif r["aktion"] == "behalten":
            behalten.update(r["parameter"])
    # 1. Bekannte Regeln und allgemeine Tracking-Parameter entfernen.
    pairs = _params(geteilt.query)
    neue = []
    for pair in pairs:
        key = _name(pair)
        low = key.lower()
        ist_tracking = low in TRACKING or any(low.startswith(p) for p in PRAEFIXE)
        ist_tracking = ist_tracking or low in entfernen or (eigene and low in entfernen)
        if eigene and low in praefixe:
            ist_tracking = True
        if low in behalten:
            neue.append(pair)
        elif ist_tracking:
            if key not in entfernt:
                entfernt.append(key)
        else:
            neue.append(pair)
    # 2. Spezielle Pfade: vollstaendige X-/Instagram-Posts behalten nur Funktion.
    path = geteilt.path or "/"
    fragment = geteilt.fragment
    if _passt(host, "x.com") or _passt(host, "twitter.com"):
        if re.match(r"^/(?:[A-Za-z0-9_]{1,15}/status|i/web/status)/[1-9][0-9]*(?:/(?:photo|video)/[1-9][0-9]*)?/?$", path):
            neue = [p for p in neue if _name(p) in ("lang", "theme", "display", "tz")]
            fragment = ""
    elif _passt(host, "instagram.com"):
        if re.match(r"^/(?:[A-Za-z0-9._]+/)?(?:p|reel|reels|tv)/[A-Za-z0-9_-]+/?$", path):
            idx = [p for p in neue if _name(p) == "img_index" and re.match(r"^[1-9][0-9]*$", _wert(p))]
            neue = idx[:1] if idx and all(p == idx[0] for p in idx) else []
            fragment = ""
        elif re.match(r"^/stories/(?!highlights/)[A-Za-z0-9._]+/[1-9][0-9]*/?$", path):
            neue = []
            fragment = ""
    # 3. Echobox-Fragment und leere Query aufraeumen.
    if fragment.startswith("Echobox="):
        fragment = ""
    if not neue:
        query = ""
    else:
        query = "&".join(neue)
    # 4. Benutzerdefinierte Weiterleitung vor dem Saubermachen.
    for r in cfg.get("regeln") or []:
        if r.get("an") is False or not _passt(host, r["host"]) or r["aktion"] != "weiterleitung":
            continue
        for pair in _params(geteilt.query):
            if _name(pair).lower() in r["parameter"]:
                ziel = unquote(_wert(pair))
                if ziel.startswith(("http://", "https://")):
                    return ziel, ["weiterleitung:" + _name(pair)], _host(ziel)
    sauber = urlunsplit((geteilt.scheme, geteilt.netloc, geteilt.path, query, fragment))
    # 5. Bekannte Redirect-Huellen auspacken (einmal, nur gültige http(s)-Ziele).
    for domain, pfad, param in (("facebook.com", "/l.php", "u"), ("linkedin.com", "/safety/go", "url"),
                                ("youtube.com", "/redirect", "q"), ("google.com", "/url", "q"),
                                ("google.com", "/pagead/aclk", "adurl"), ("go.bsky.app", "/redirect", "u"),
                                ("out.reddit.com", "", "url"), ("georiot.com", "/Proxy.ashx", "GR_URL"),
                                ("linksynergy.com", "/link", "murl")):
        if _passt(host, domain) and (not pfad or path == pfad or path.startswith(pfad + "/")):
            for pair in _params(geteilt.query):
                if _name(pair) == param:
                    ziel = unquote(_wert(pair))
                    if ziel.startswith(("http://", "https://")) and _host(ziel):
                        return ziel, ["weiterleitung:" + param], _host(ziel)
    return sauber, entfernt, host


def _frontend_url(url, cfg):
    host = _host(url)
    key = _frontend(host)
    ziel = (cfg.get("frontends") or {}).get(key, "")
    if not key or not ziel:
        return url, ""
    teile = urlsplit(url)
    if key == "x" and not re.match(r"^/(?:[A-Za-z0-9_]{1,15}/status|i/web/status)/[1-9][0-9]*", teile.path or ""):
        return url, ""
    if key == "instagram" and not re.match(r"^(?:/(?:[A-Za-z0-9._]+/)?(?:p|reel|reels|tv)/[A-Za-z0-9_-]+|/stories/(?!highlights/)[A-Za-z0-9._]+/[1-9][0-9]*)/?$", teile.path or ""):
        return url, ""
    return urlunsplit((teile.scheme, ziel, teile.path, teile.query, "")), key


def private_funde(url):
    """Nur Fundstellen, nie Werte: E-Mail, JWT, sensible Parameter, genaue Koordinaten."""
    teile = urlsplit(url)
    funde = []
    for teil, text in (("pfad", teile.path), ("query", teile.query), ("fragment", teile.fragment)):
        for m in _EMAIL.findall(unquote(text)):
            funde.append({"art": "E-Mail", "teil": teil, "wert": m.split("@")[0][:2] + "…@" + m.split("@")[1]})
        if _JWT.search(text):
            funde.append({"art": "Anmelde-Token (JWT)", "teil": teil, "wert": ""})
    paare = parse_qs(teile.query, keep_blank_values=True)
    for name, werte in paare.items():
        if name.lower() in SENSIBLE and any(len(str(w)) >= 8 for w in werte):
            funde.append({"art": "sensibler Parameter", "teil": "query", "wert": name})
    lat = any(name.lower() in ("lat", "latitude") and _ZAHL.match(w) for name, w in paare.items() for w in w)
    lon = any(name.lower() in ("lon", "lng", "longitude") and _ZAHL.match(w) for name, w in paare.items() for w in w)
    if lat and lon:
        funde.append({"art": "genaue Koordinaten", "teil": "query", "wert": "lat/lon"})
    return funde[:10]


def reinigen(url, cfg=None, tiefe=0):
    """Adresse lokal bereinigen und optional auf ein Frontend umschreiben. Ohne Netz."""
    cfg = cfg or STANDARD
    original = " ".join(str(url or "").split())
    if not cfg.get("an"):
        return {"original": original, "sauber": original, "geaendert": False, "entfernt": [],
                "frontend": "", "warnungen": [], "status": "aus"}
    if not original:
        raise ReinigerFehler("Keine Adresse")
    sauber, entfernt, _ = _clean(original, cfg)
    for _ in range(4 if tiefe < 5 else 1):
        neu, mehr, _ = _clean(sauber, cfg)
        if neu == sauber:
            break
        sauber = neu
        entfernt = entfernt + [x for x in mehr if x not in entfernt]
    sauber, frontend = _frontend_url(sauber, cfg)
    warnungen = private_funde(sauber) if cfg.get("guard", True) else []
    warnungen_original = private_funde(original) if cfg.get("guard", True) else []
    return {"original": original, "sauber": sauber, "geaendert": sauber != original,
            "entfernt": entfernt, "frontend": frontend, "warnungen": warnungen,
            "warnungen_original": warnungen_original, "status": "ok"}


def verlauf_merken(daten, ergebnis, jetzt=0):
    """Optionalen Verlauf fortschreiben; private Originale werden nie gespeichert."""
    e = einstellungen(daten)
    if not e.get("verlauf_an") or not ergebnis.get("sauber"):
        return e
    if ergebnis.get("warnungen") or ergebnis.get("warnungen_original"):
        return e
    e["verlauf"] = [x for x in e["verlauf"] if x.get("sauber") != ergebnis["sauber"]][:MAX_VERLAUF - 1]
    e["verlauf"].insert(0, {"original": ergebnis.get("original", ""), "sauber": ergebnis["sauber"], "zeit": int(jetzt)})
    daten[SCHLUESSEL] = e
    return e


def aendern(daten, wunsch):
    if not isinstance(wunsch, dict):
        raise ReinigerFehler("JSON-Objekt erwartet")
    e = einstellungen(daten)
    if wunsch.get("aktion") == "verlauf_loeschen":
        e["verlauf"] = []
    elif wunsch.get("aktion") == "einstellen":
        werte = wunsch.get("werte") if isinstance(wunsch.get("werte"), dict) else wunsch
        e = pruefe(dict(e, **{k: v for k, v in werte.items() if k != "aktion"}))
    else:
        raise ReinigerFehler("Unbekannte Aktion")
    daten[SCHLUESSEL] = e
    return e
