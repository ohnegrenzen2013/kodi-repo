"""FixupXer-Regeln: Tracking-Parameter, Frontend-Katalog und Konfiguration des Link-Reinigers."""
import re
from urllib.parse import urlsplit

SCHLUESSEL = "link_reiniger"
MAX_VERLAUF = 100
MAX_REGELN = 40

# Die haeufigsten Tracking-Parameter (FixupXer GeneralTrackingCleaner + ClearURLs-Umfeld).
TRACKING = {
    "utm_source", "utm_medium", "utm_campaign", "utm_term", "utm_content", "utm_id", "utm_name",
    "utm_reader", "utm_brand", "utm_pubreferrer", "utm_swu", "utm_viz_id", "utm_referrer",
    "utm_social", "utm_social-type", "utm_source_platform", "utm_creative_format",
    "utm_marketing_tactic", "fbclid", "gclid", "gclsrc", "gad_source", "dclid", "twclid",
    "msclkid", "gad_campaignid", "srsltid", "ttclid", "li_fat_id", "sccid", "rdt_cid",
    "ef_id", "s_kwcid", "yclid", "gbraid", "wbraid", "ko_click_id", "epik", "_ga", "_gl",
    "_hsenc", "_hsmi", "__hssc", "__hstc", "__hsfp", "hsctatracking", "mc_cid", "mc_eid",
    "_openstat", "_ke", "_kx", "__s", "vgo_ee", "rb_clickid", "_bta_tid", "_bta_c",
    "ml_subscriber", "ml_subscriber_hash", "oly_anon_id", "oly_enc_id", "vero_conv", "vero_id",
    "wickedid", "irclickid", "irgwc", "sscid", "zanpid", "sharedid", "ranmid", "raneaid",
    "ransiteid", "shareasale_site_id", "shareasale_user_id", "spjobid", "spmailingid",
    "spreportid", "spuserid", "__twitter_impression", "mkt_tok", "sfmc_activityid",
    "guccounter", "guce_referrer", "guce_referrer_sig",
}
PRAEFIXE = ("pk_", "mtm_", "matomo_", "piwik_", "wt.", "wt_", "itm_", "elq", "xtor", "at_")
# Hosts -> (zu entfernende Parameter, immer zu behaltende Parameter, Parameter mit Praefix)
REGELN = {
    "twitter.com": ({"s", "t", "ref_src", "ref_url", "via", "cn", "src", "twclid", "twgr", "twcamp",
                     "twterm", "share", "shared_via", "ref", "referer", "__twitter_impression"},
                    {"lang", "theme", "display", "tz"}, ()),
    "x.com": ({"s", "t", "ref_src", "ref_url", "via", "cn", "src", "twclid", "twgr", "twcamp",
               "twterm", "share", "shared_via", "ref", "referer", "__twitter_impression"},
              {"lang", "theme", "display", "tz"}, ()),
    "instagram.com": ({"igsh", "igshid", "igsi", "stkn", "ig_cache_key", "ig_mid", "ig_share_sheet",
                       "__a", "__d", "_rdr", "share_app_id", "share_sheet_id", "share_id", "ig_rid",
                       "exln", "obrf", "ig_did", "share_campaign_id", "share_link_id", "_u_code",
                       "_u_source", "_r", "_t", "attribution_link", "ig_nux_id", "ig_referrer"},
                      set(), ()),
    "youtube.com": ({"si", "is", "pp", "feature", "app", "attribution_link", "embeds_referring_euri",
                     "embeds_referring_origin", "embeds_euri", "source_ve_path", "gclid", "ytclid",
                     "share", "shared_via", "ref", "referer", "referrer", "fbclid", "sms_ss",
                     "ucbcb", "share_source", "session_id", "ei", "ved", "sourceid", "ssfr"},
                    {"v", "t", "list", "index", "start", "end", "ab_channel", "search_query", "q",
                     "radio", "p", "page", "sort", "view", "shelf_id", "hl", "gl"}, ()),
    "youtu.be": (set(), {"t"}, ()),
    "facebook.com": ({"fbclid", "__cft__", "__tn__", "mibextid", "epa", "_gl", "fb_action_ids",
                      "fb_action_types", "fb_source", "fb_ref", "share_id", "share_source",
                      "share_campaign", "share_medium", "branch_data", "_branch_match_id",
                      "_branch_referrer", "sk", "sfnsn", "s", "hc", "hc_ref", "hc_location",
                      "pn_ref", "aref", "medium", "linkshim", "next", "acontext", "paipv",
                      "entrypoint", "fref", "rc", "_rdr"},
                     {"id", "story_fbid", "fbid", "set", "type", "theater", "av", "v", "locale",
                      "ref", "comment_id", "reply_comment_id", "tab", "filter", "section"}, ("fb_",)),
    "reddit.com": ({"context", "correlator", "rdt_cid", "share_id", "ref", "ref_source",
                    "ref_campaign", "ref_share", "_branch_match_id", "_branch_referrer", "_bta_tid",
                    "app", "app_name", "app_id", "device_id", "utm_id", "utm_name", "utm_reader",
                    "session_id", "request_id", "correlation_id", "impression_id", "experiment_id",
                    "variant_id", "share", "shared_via", "share_from", "share_source", "source",
                    "medium", "campaign", "nav_source", "entry_point", "surface", "trigger",
                    "source_element", "action_source", "ref_ui", "variant", "experiment",
                    "treatment", "bucket", "feature", "rollout_hash", "test_group"},
                   {"sort", "t", "q", "type", "restrict_sr", "include_over_18", "after", "before",
                    "limit", "count", "show", "raw_json", "depth", "showmore", "sr_detail", "sr",
                    "is_multi"}, ()),
    "tiktok.com": ({"_r", "_t", "_d", "tt_from", "tt_content", "share_source", "u_code", "preview_pb",
                    "share_app_id", "share_link_id", "share_item_id", "share_author_id",
                    "share_app_name", "timestamp", "enter_from", "enter_method", "from_page",
                    "refer", "referer_url", "referer_video_id", "anchor_id", "source", "session_id",
                    "request_id", "webcast_app_id", "room_id", "sec_user_id", "sec_uid", "u_ser",
                    "user_id", "device_platform", "device_type", "browser_language", "browser_name",
                    "browser_version", "os_version", "screen_width", "screen_height", "client_ab_test",
                    "previous_page", "current_page", "depth", "tab_name", "gd_label", "category_name",
                    "schema_type", "obj_id", "item_id", "group_id", "music_id", "mix_id", "poi_id",
                    "region", "priority_region", "language", "verifyFp", "is_copy_url", "checksum",
                    "openudid", "uuid", "_aem", "_aem_test", "msToken", "X-Bogus", "magic", "scene"},
                   {"lang", "q", "t", "embed", "video_id", "modal", "search_keyword", "sort_type",
                    "content_type", "creation_time", "hashtag", "sound", "effect", "display_method",
                    "is_fullscreen"}, ()),
    "linkedin.com": ({"trk", "trkInfo", "trkEmail", "li_theme", "li_ft", "li_mc", "li_tc", "li_uuid",
                      "li_at", "li_rm", "share", "src", "veh", "trackingId", "refId", "lipi", "licu",
                      "lici", "lict", "lics", "mcid", "msgConversationId", "sessionId", "requestId",
                      "contextId", "csrfToken", "pageKey", "sessionRedirect", "fromSignIn", "position",
                      "pageNum", "secureUrl", "startTask", "submissionId", "upsellOrderOrigin",
                      "fromEmail", "midToken", "midSig", "fromSuggestionID", "suggestedToFollow",
                      "updateEntityUrn", "originTrackingId"},
                     {"keywords", "origin", "q", "start", "count", "filters", "sortBy", "facet",
                      "geoUrn", "network", "schoolFilter", "companySize", "datePosted", "jobType",
                      "location", "redirectUrl", "response_type", "client_id", "state", "scope"}, ("f_",)),
    "amazon.de": ({"tag", "linkCode", "linkId", "camp", "creative", "creativeASIN", "ref_", "ref",
                   "refRID", "ie", "pf_rd_m", "pf_rd_s", "pf_rd_r", "pf_rd_t", "pf_rd_p", "pf_rd_i",
                   "pd_rd_w", "pd_rd_wg", "pd_rd_r", "pd_rd_i", "pd_rd_sg", "pf_rd_sg", "pd_dcr",
                   "qid", "rank", "spIA", "spLa", "suggestionType", "sprefix", "crid", "cv_ct_cx",
                   "cv_ct_id", "cv_ct_pg", "share", "share_at", "socialMediaReferral", "referer",
                   "ms3_c", "spLM", "spPD", "spIAC", "smid", "ascsubtag", "tag_id", "_encoding",
                   "bbn", "dc", "dcm", "fst", "lo", "me", "pf", "th", "psc", "dchild", "almBrandId",
                   "navLanguage", "rnid", "rh", "srs", "starsLeft", "qsid", "sr", "sres", "colid",
                   "coliid", "ubid", "visitId", "asc_campaign", "asc_source", "asc_refurl"},
                  {"keywords", "k", "i", "s", "page", "node", "field-keywords", "field-brand",
                   "field-price-range", "field-availability", "sort", "fs", "sku", "asin"}, ()),
    "substack.com": ({"r", "ref", "referrer", "token", "access_token", "auth_token", "jwt",
                      "session_id", "source", "src", "origin", "attribution", "action", "clicked",
                      "opened", "shared", "forwarded", "replied", "reaction", "email_source",
                      "email_type", "isFreemail", "isFromEmail", "newsletter_id", "edition_id",
                      "issue_id", "subscriber_id", "list_id", "segment_id", "triedRedirect"},
                     {"publication_id", "post_id"}, ()),
    "google.com": ({"ved", "ei", "usg", "sa", "source", "sourceid", "sxsrf", "biw", "bih", "dpr",
                    "cad", "uact", "oq", "aq", "aqs", "gs_lcp", "gs_lcrp", "sclient", "gs_l",
                    "gs_ssp", "gs_rn", "gs_ri", "gs_mss", "rct", "cd", "vet", "esrc", "espv", "cshid",
                    "ictx", "sig2", "act", "rc", "jfp", "bvm", "ion", "prmd", "iflsig", "rlz",
                    "pccc", "psi", "stick", "tci", "sqi", "bav", "pf", "atyp", "asst", "client",
                    "hs", "authuser", "pq", "pdl", "nfpr", "spell", "npsic", "mvs", "agsad",
                    "gfe_rd", "gws_rd", "complete", "pval", "noj", "btnG", "btnI", "site", "output",
                    "domains", "tbm", "ijn", "imgrc", "imgrefurl", "imgurl", "docid", "tbnid",
                    "zoom", "vt", "sll", "sspn", "vps", "vpsrc", "msa", "msid", "mid", "skstate",
                    "rtlr", "rlha", "rllag", "amp", "amp_ct", "amp_url", "ampshare", "usqp"},
                   {"q", "tbs", "start", "num", "hl", "lr", "safe", "filter", "as_q", "as_epq",
                    "as_oq", "as_eq", "as_qdr", "as_rights", "imgsz", "imgtype", "imgc", "gl", "cr"}, ()),
    "theguardian.com": ({"cmp"}, set(), ()),
    "nytimes.com": ({"smid"}, set(), ()),
    "wikipedia.org": ({"wprov"}, set(), ()),
    "threads.net": ({"igshid", "xmt"}, set(), ()),
    "threads.com": ({"igshid", "xmt"}, set(), ()),
    "twitch.tv": ({"tt_medium", "tt_content"}, set(), ()),
    "spotify.com": ({"si", "dl_branch", "dl_mobileapp"}, {"context", "uri"}, ()),
    "pinterest.com": ({"e_t", "e_t_s", "e_t_cs", "ouuid", "pin_unauth"}, set(), ()),
    "snapchat.com": ({"share_id"}, set(), ()),
    "whatsapp.com": ({"link_source", "link_medium"}, set(), ()),
    "medium.com": ({"source", "sk"}, set(), ()),
    "bing.com": ({"cvid"}, set(), ()),
    "duckduckgo.com": ({"t", "atb"}, {"q"}, ()),
    "ebay.de": ({"mkevt", "mkcid", "mkrid", "campid", "customid", "toolid", "ssspo", "sssrc",
                 "ssuid", "widget_ver", "media", "_trkparms", "_trksid"}, {"var", "selected", "hash", "epid"}, ()),
    "netflix.com": ({"trkid", "tctx"}, set(), ()),
    "aliexpress.com": ({"spm", "srcSns", "businessType", "templateKey", "aff_fcid", "aff_fsk",
                        "aff_platform", "aff_trace_key", "terminal_id", "afSmartRedirect",
                        "utparam-url", "pdp_npi", "afTraceInfo", "algo_pvid", "algo_exp_id",
                        "algo_expid", "curPageLogUid", "scm", "scm_id", "scm-url", "utparam",
                        "aff_short_key", "aff_request_id", "gps-id", "ws_ab_test", "btsid", "mall_affr"},
                       {"sku_id", "currency", "language", "gatewayAdapt"}, ()),
    "bilibili.com": ({"vd_source", "seid", "share_source", "copy_link"}, set(), ()),
}
FRONTENDS = {
    "x": ("X / Twitter", "fixupx.com", [("", "Original"), ("fixupx.com", "FixupX (Embed)"), ("xcancel.com", "XCancel"),
                                         ("nitter.net", "Nitter"), ("twitterviewer.net", "TwitterViewer")]),
    "instagram": ("Instagram", "toinstagram.com", [("", "Original"), ("toinstagram.com", "ToInstagram"),
                                                    ("adamlikes.com", "AdamLikes"), ("instagram7.com", "Instagram7")]),
    "tiktok": ("TikTok", "tnktok.com", [("", "Original"), ("tnktok.com", "TNKTок"), ("tfxktok.com", "TFXKTок"),
                                         ("tiktokez.com", "TikTokEZ")]),
    "facebook": ("Facebook", "", [("", "Original")]),
    "bluesky": ("Bluesky", "fxbsky.app", [("", "Original"), ("fxbsky.app", "FXBluesky")]),
    "reddit": ("Reddit", "redlib.catsarch.com", [("", "Original"), ("safereddit.com", "SafeReddit"),
                                                  ("redlib.catsarch.com", "Redlib")]),
    "youtube": ("YouTube", "invidious.nerdvpn.de", [("", "Original"), ("invidious.nerdvpn.de", "Invidious")]),
    "pinterest": ("Pinterest", "pinterest.bunk.im", [("", "Original"), ("pinterest.bunk.im", "Bunk.im")]),
    "threads": ("Threads", "shoelace.mint", [("", "Original"), ("shoelace.mint", "Shoelace")]),
}
STANDARD = {"an": True, "frontends": {k: v[1] for k, v in FRONTENDS.items()}, "guard": True,
            "verlauf_an": False, "regeln": [], "behalten": [], "entfernen": [], "hosts_aus": [],
            "verlauf": []}
SENSIBLE = {"token", "access_token", "auth", "auth_token", "api_key", "apikey", "key", "secret",
            "password", "passwort", "email", "mail", "session", "session_id", "signature", "sig"}
_JWT = re.compile(r"eyJ[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}\.[A-Za-z0-9_-]{10,}")
_EMAIL = re.compile(r"[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}")
_ZAHL = re.compile(r"^-?\d{1,3}(?:\.\d{3,})$")


class ReinigerFehler(ValueError):
    pass


def pruefe(roh):
    e = dict(STANDARD, frontends=dict(STANDARD["frontends"]), regeln=[], behalten=[], entfernen=[],
             hosts_aus=[], verlauf=[])
    if not isinstance(roh, dict):
        return e
    e["an"] = roh.get("an") is not False
    e["guard"] = roh.get("guard") is not False
    e["verlauf_an"] = roh.get("verlauf_an") is True
    for k, (_, _, auswahl) in FRONTENDS.items():
        if k not in (roh.get("frontends") or {}):
            continue
        wert = str((roh.get("frontends") or {}).get(k) or "").strip().lower()
        erlaubt = {x[0] for x in auswahl}
        if wert in erlaubt:
            e["frontends"][k] = wert
    for key, max_n in (("behalten", 100), ("entfernen", 100), ("hosts_aus", 100)):
        if isinstance(roh.get(key), list):
            e[key] = [" ".join(str(x).split()).lower()[:80] for x in roh[key] if str(x).strip()][:max_n]
    if isinstance(roh.get("regeln"), list):
        for r in roh["regeln"][:MAX_REGELN]:
            if not isinstance(r, dict):
                continue
            host = " ".join(str(r.get("host") or "").split()).lower()[:120]
            aktion = r.get("aktion") if r.get("aktion") in ("entfernen", "behalten", "weiterleitung") else ""
            parameter = [str(x).strip().lower() for x in (r.get("parameter") or []) if str(x).strip()][:40] if isinstance(r.get("parameter"), list) else []
            if host and aktion and parameter:
                e["regeln"].append({"name": " ".join(str(r.get("name") or host).split())[:60], "host": host,
                                    "aktion": aktion, "parameter": parameter, "an": r.get("an") is not False})
    if isinstance(roh.get("verlauf"), list):
        for x in roh["verlauf"][:MAX_VERLAUF]:
            if isinstance(x, dict) and x.get("sauber"):
                e["verlauf"].append({"original": str(x.get("original") or "")[:2000],
                                     "sauber": str(x.get("sauber") or "")[:2000],
                                     "zeit": int(x.get("zeit") or 0)})
    return e


def einstellungen(daten):
    return pruefe((daten or {}).get(SCHLUESSEL))


def _host(url):
    try:
        return (urlsplit(url).hostname or "").lower()
    except ValueError:
        return ""


def _passt(host, domain):
    return host == domain or host.endswith("." + domain) or (domain.startswith("www.") and host == domain[4:])


def _regel_fuer(host):
    for d, regel in REGELN.items():
        if _passt(host, d):
            return regel
    return None


def _frontend(host):
    for key, domain in (("x", ("x.com", "twitter.com")), ("instagram", ("instagram.com",)),
                        ("tiktok", ("tiktok.com",)), ("facebook", ("facebook.com", "fb.com")),
                        ("bluesky", ("bsky.app",)), ("reddit", ("reddit.com",)),
                        ("youtube", ("youtube.com", "youtu.be")), ("pinterest", ("pinterest.com",)),
                        ("threads", ("threads.net", "threads.com"))):
        if any(_passt(host, d) for d in domain):
            return key
    return ""
