"""Heim-Links: Lesezeichen zu Geraeten und Diensten im Heimnetz.

Ein Ort, an dem die Weboberflaechen der Heimserver-Funktionen zusammenstehen, z. B. die
FRITZ!Box, eine NAS, Nextcloud, Jellyfin, Pi-hole oder eine Cloud. Der Server speichert und
zeigt die Links nur und macht sie von allen Geraeten im Netzwerk erreichbar (mit Token); er
ruft sie nicht ab und leitet nichts durch.

Nutzerdaten, Abschnitt "links": [{"name": "...", "url": "...", "gruppe": "..."}]
"""

MAX_LINKS = 100
STANDARD = []
# bekannte Heimserver mit Standardadresse, nur als Vorschlag in der Oberflaeche
VORSCHLAEGE = [
    {"name": "FRITZ!Box", "url": "http://fritz.box", "gruppe": "Router"},
    {"name": "FRITZ!NAS", "url": "http://fritz.nas", "gruppe": "Speicher"},
    {"name": "MyFRITZ!", "url": "https://myfritz.net", "gruppe": "Router"},
    {"name": "ASUS Router", "url": "http://router.asus.com", "gruppe": "Router"},
    # AiCloud: Dateien der USB-Platte am ASUS-Router, Cloud Disk und Smart Access (HTTPS, Standard-Port 443)
    {"name": "ASUS AiCloud", "url": "https://router.asus.com", "gruppe": "Cloud"},
    {"name": "ASUS AiCloud unterwegs (DDNS)", "url": "https://DEINNAME.asuscomm.com", "gruppe": "Cloud"},
    {"name": "Synology DSM", "url": "http://diskstation:5000", "gruppe": "Speicher"},
    {"name": "Nextcloud", "url": "http://nextcloud.local", "gruppe": "Cloud"},
    {"name": "Jellyfin", "url": "http://jellyfin.local:8096", "gruppe": "Medien"},
    {"name": "Pi-hole", "url": "http://pi.hole/admin", "gruppe": "Netzwerk"},
    {"name": "Home Assistant", "url": "http://homeassistant.local:8123", "gruppe": "Smart Home"},
]


class LinkFehler(ValueError):
    pass


def pruefe(roh):
    roh = roh or []
    if not isinstance(roh, list) or len(roh) > MAX_LINKS:
        raise LinkFehler("links muss eine Liste mit hoechstens %d Eintraegen sein" % MAX_LINKS)
    ergebnis = []
    for eintrag in roh:
        if not isinstance(eintrag, dict) or set(eintrag) - {"name", "url", "gruppe"}:
            raise LinkFehler("Jeder Link braucht name und url (optional gruppe)")
        name = " ".join(str(eintrag.get("name") or "").split())[:60]
        url = str(eintrag.get("url") or "").strip()
        gruppe = " ".join(str(eintrag.get("gruppe") or "").split())[:40] or "Allgemein"
        if not name:
            raise LinkFehler("Link ohne Namen")
        if not url.lower().startswith(("http://", "https://")):
            raise LinkFehler("Link %s: Adresse muss mit http:// oder https:// beginnen" % name)
        ergebnis.append({"name": name, "url": url, "gruppe": gruppe})
    return ergebnis


def gruppiert(links):
    """Links nach Gruppe, Reihenfolge des ersten Auftretens erhalten."""
    gruppen = {}
    for link in links:
        gruppen.setdefault(link["gruppe"], []).append(link)
    return [{"gruppe": g, "links": ls} for g, ls in gruppen.items()]
