"""Live-TV: offizielle Livestreams der oeffentlich-rechtlichen Sender als M3U, dazu eine EPG-Weitergabe.

Im Netzwerk (unter der Addon-Adresse, im Heimnetz mit Token):
  /tv.m3u       Senderliste fuer IPTV-Apps (Kodi IPTV Simple Client, TiviMate, VLC ...)
  /epg.xml.gz   Programmzeitschrift (XMLTV) aus der eingetragenen Quelle oder dem EPG-Grabber, taeglich erneuert
  /epg.xml      dieselbe, entpackt
  /logos/<id>.png  Senderlogo (mitgeliefert in rezeptserver/logos/, Quelle Wikimedia Commons)

  /listen/<id>.m3u  eigene M3U/M3U8 aus dem Internet (taeglich neu geladen), auch in /tv.m3u enthalten
  kostenlose Sender (Samsung TV Plus, Pluto TV, siehe frei_tv.py) als Listen frei-<quelle>-<region>,
  ihr Programm wird an die EPG angehaengt

Nutzerdaten, Abschnitt "livetv":
  {"aus": [sender-ids], "epg_quelle": "https://...", "epg_grabber": "" | "magenta",
   "listen": [{"name": "...", "url": "https://...", "an": true}], "frei": ["samsung-de", "pluto-de"],
   "adressen": {sender-id: "https://..."}, "adressen_quelle": "https://.../adressen.json"}

EPG: Ist epg_grabber gesetzt, holt der Server die Programmdaten selbst (epg_magenta.py) und epg_quelle ruht.

Sender-Adressen sind austauschbar: eigene Adresse (adressen) vor Adressen-Liste (adressen_quelle, JSON
{sender-id: adresse}, taeglich neu geladen) vor der mitgelieferten Adresse in SENDER.
"""

from .livetv_grund import *
from .livetv_m3u import *
from .livetv_epg import *
from .livetv_raster import *
from .livetv_quellen import *
from .livetv_ausgabe import *
from .livetv_grund import _ATTRIBUT, _Abholer, _IDS, _STANDARD_ADRESSEN, _pruefe_listen, _pruefe_quelle, _pruefe_xmltv, _urllib_oeffnen, _xmltv_innen
from .livetv_m3u import _attribut
