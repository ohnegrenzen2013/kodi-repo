"""Ausgabe: mitgelieferte Senderlogos sowie das Schicken von Logos und EPG-Dateien."""

from .livetv_grund import (
    LOGOS,
    LOGO_ORDNER,
    gzip,
    os,
    shutil,
)

class Logos:
    """Mitgelieferte Senderlogos (rezeptserver/logos/<id>.png)."""

    def __init__(self, ordner=None):
        self.ordner = ordner or os.path.join(os.path.dirname(os.path.abspath(__file__)), LOGO_ORDNER)

    def pfad(self, sender_id):
        """Pfad zur PNG-Datei, None fuer unbekannte Sender oder fehlende Datei."""
        if sender_id not in LOGOS:
            return None
        datei = os.path.join(self.ordner, sender_id + ".png")
        return datei if os.path.isfile(datei) else None


def logo_senden(handler, pfad):
    with open(pfad, "rb") as f:
        inhalt = f.read()
    handler.send_response(200)
    handler.send_header("Content-Type", "image/png")
    handler.send_header("Content-Length", str(len(inhalt)))
    handler.send_header("Cache-Control", "max-age=604800")
    handler.end_headers()
    if handler.command != "HEAD":
        handler.wfile.write(inhalt)


def senden(handler, pfad, entpacken):
    """Schickt die EPG-Datei, gepackt oder entpackt, ohne sie ganz in den Speicher zu laden."""
    try:
        datei = gzip.open(pfad, "rb") if entpacken else open(pfad, "rb")
    except OSError:
        handler.send_error(404)
        return
    with datei:
        handler.send_response(200)
        handler.send_header("Content-Type", "application/xml; charset=utf-8" if entpacken else "application/gzip")
        if not entpacken:
            handler.send_header("Content-Length", str(os.path.getsize(pfad)))
        handler.send_header("Cache-Control", "max-age=3600")
        handler.end_headers()
        if handler.command == "HEAD":
            return
        try:
            shutil.copyfileobj(datei, handler.wfile, 256 * 1024)
        except (BrokenPipeError, ConnectionResetError):
            pass
