"""EPG: XMLTV-Quelle, eingebauter Grabber und das Zusammenfuehren mehrerer Quellen."""

import time
import xml.etree.ElementTree as ET
from datetime import datetime

from .livetv_grund import (
    EPG_DATEI,
    GRENZEN,
    GRABBER,
    SENDER,
    _Abholer,
    _pruefe_xmltv,
    _xmltv_innen,
    epg_magenta,
    frei_tv,
    gzip,
    log,
    os,
    zu_gross,
)

class Epg(_Abholer):
    """XMLTV-Quelle, gepackt neben den Nutzerdaten abgelegt. zusatz: weitere XMLTV-Adressen (z. B. kostenlose
    Sender), deren Kanaele und Sendungen angehaengt werden."""

    art = "EPG"

    def __init__(self, ordner, quelle, holen=None, zusatz=()):
        super().__init__(os.path.join(ordner, EPG_DATEI), quelle, holen)
        self._zusatz = list(zusatz)
        self.zusatz_fn = None  # weitere Adressen erst beim Laden erfragen (EPG-Angaben aus den Playlists)
        self._stand_zusatz = None

    @property
    def zusatz(self):
        mehr = []
        if self.zusatz_fn:
            try:
                mehr = [u for u in self.zusatz_fn() if u not in self._zusatz]
            except Exception as fehler:  # eine kaputte Playlist darf die EPG nicht blockieren
                log.warning("EPG aus Playlists: %s", fehler)
        return self._zusatz + mehr

    @zusatz.setter
    def zusatz(self, neu):
        self._zusatz = list(neu)

    def _frisch(self):
        """Neue Adressen (z. B. eine Playlist, die ihr EPG erst jetzt nennt) gelten als veraltet, auch wenn die Datei frisch ist."""
        jetzt = self.zusatz
        if self._stand_zusatz is None:
            self._stand_zusatz = jetzt  # beim Start: die Datei gilt als passend zum Stand
        return jetzt == self._stand_zusatz

    def _laden(self, temp):
        self._stand_zusatz = self.zusatz
        if self.quelle:
            self._haupt(temp)
        if self._stand_zusatz:
            self._anhaengen(temp)

    def _haupt(self, temp):
        super()._laden(temp)

    def _anhaengen(self, temp):
        """Haupt-EPG (falls da) und Zusatzquellen zu einer XMLTV-Datei zusammenfuehren."""
        teile = []
        if os.path.isfile(temp):
            with gzip.open(temp, "rb") as f:
                teile.append(_xmltv_innen(f.read(GRENZEN["epg"] + 1)))
        for url in self._stand_zusatz:
            try:
                with self.holen(url) as antwort:
                    roh = antwort.read(GRENZEN["epg"] + 1)
                teile.append(_xmltv_innen(gzip.decompress(roh) if roh[:2] == b"\x1f\x8b" else roh))
            except Exception as fehler:  # eine Zusatzquelle darf den Rest nicht verhindern
                log.warning("EPG-Zusatz %s: %s", url, fehler)
        if not any(teile):
            raise ValueError("keine EPG-Daten")
        with gzip.open(temp, "wb") as f:
            f.write(b'<?xml version="1.0" encoding="UTF-8"?>\n<tv generator-info-name="H0rSt">\n')
            for teil in teile:
                f.write(teil)
            f.write(b"</tv>\n")

    def _schreiben(self, antwort, temp):
        anfang = antwort.read(2)
        gepackt = anfang == b"\x1f\x8b"
        with open(temp, "wb") as roh:
            ziel = roh if gepackt else gzip.GzipFile(fileobj=roh, mode="wb")
            try:
                ziel.write(anfang)
                geschrieben = len(anfang)
                while True:
                    block = antwort.read(256 * 1024)
                    if not block:
                        break
                    geschrieben += len(block)
                    if geschrieben > GRENZEN["epg"]:
                        raise zu_gross("EPG", "epg")
                    ziel.write(block)
            finally:
                if ziel is not roh:
                    ziel.close()

    def _pruefen(self, temp):
        _pruefe_xmltv(temp)


class EpgGrabber(Epg):
    """EPG, die der Server selbst zusammenstellt (eingebauter Grabber statt XMLTV-Adresse).

    Gleiche Datei und gleiche Auslieferung wie Epg; quelle ist der Anzeigename des Grabbers."""

    def __init__(self, ordner, grabber, sitzung=None):
        super().__init__(ordner, GRABBER[grabber])
        self.grabber = grabber
        self.sitzung = sitzung  # nur fuer Tests: Ersatz fuer die Magenta-Verbindung

    def _haupt(self, temp):
        sender_liste = [(s[0], s[1], s[3]) for s in SENDER]
        epg_magenta.schreibe(temp, sender_liste, sitzung=self.sitzung() if self.sitzung else None)


def epg_abholer(ordner, einstellung, holen=None, grabber_sitzung=None, playlist_epg=None):
    """Epg fuer die Einstellung: eingebauter Grabber vor XMLTV-Adresse; kostenlose Sender kommen dazu.
    playlist_epg: Funktion mit den EPG-Adressen der Playlists; sie gelten nur, wenn weder Grabber noch eigene
    EPG-Quelle gesetzt sind (die Wahl des Nutzers gewinnt)."""
    zusatz = frei_tv.epg_quellen(einstellung.get("frei") or [])
    if einstellung.get("epg_grabber"):
        epg = EpgGrabber(ordner, einstellung["epg_grabber"], sitzung=grabber_sitzung)
        epg.zusatz = zusatz
        return epg
    epg = Epg(ordner, einstellung.get("epg_quelle") or "", holen=holen, zusatz=zusatz)
    if not einstellung.get("epg_quelle"):
        epg.zusatz_fn = playlist_epg
    return epg


def _xmltv_zeit_lesen(wert):
    try:
        return datetime.strptime(wert, "%Y%m%d%H%M%S %z").timestamp()
    except (TypeError, ValueError):
        return None


def jetzt_sendungen(ordner, tvg_ids, jetzt=None):
    """Aktuell laufende Sendung je angefragter tvg_id aus der gespeicherten XMLTV-Datei.

    {tvg_id: {"titel", "von", "bis"}} - nur fuer Kanaele mit Treffer; leer bei fehlender/kaputter Datei
    (reine Lesefunktion, wirft nie - die Rohdatei ist fuer IPTV-Apps gedacht, nicht fuer diese Abfrage)."""
    tvg_ids = set(tvg_ids)
    if not tvg_ids:
        return {}
    pfad = os.path.join(ordner, EPG_DATEI)
    jetzt = time.time() if jetzt is None else jetzt
    try:
        with gzip.open(pfad, "rt", encoding="utf-8") as f:
            wurzel = ET.fromstring(f.read())
    except (OSError, ET.ParseError, UnicodeDecodeError):
        return {}
    ergebnis = {}
    for p in wurzel.findall("programme"):
        kanal = p.get("channel")
        if kanal not in tvg_ids or kanal in ergebnis:
            continue
        start, bis = _xmltv_zeit_lesen(p.get("start")), _xmltv_zeit_lesen(p.get("stop"))
        if start is None or bis is None or not (start <= jetzt < bis):
            continue
        titel = p.findtext("title")
        if titel:
            ergebnis[kanal] = {"titel": titel, "von": start, "bis": bis}
    return ergebnis


def programm_liste(ordner, tvg_id, jetzt=None, anzahl=3, zurueck=0):
    """Die naechsten Sendungen eines einzelnen Kanals aus der gleichen gespeicherten XMLTV-Datei wie
    jetzt_sendungen() (kein neuer Netzzugriff): [{"titel","beginn","ende"}, ...], aelteste zuerst, hoechstens
    anzahl Eintraege; die zuerst noch nicht beendete Sendung ist die aktuell laufende (falls bekannt).
    zurueck (Sekunden) holt zusaetzlich beendete Sendungen in diesem Fenster — fuer Mitschnitt, nicht fuer
    die normale Vorschau. Leer bei fehlender/kaputter Datei oder unbekannter tvg_id - reine Lesefunktion, wirft nie."""
    if not tvg_id:
        return []
    pfad = os.path.join(ordner, EPG_DATEI)
    jetzt = time.time() if jetzt is None else jetzt
    try:
        zurueck = max(0.0, float(zurueck or 0))
    except (TypeError, ValueError):
        zurueck = 0.0
    try:
        with gzip.open(pfad, "rt", encoding="utf-8") as f:
            wurzel = ET.fromstring(f.read())
    except (OSError, ET.ParseError, UnicodeDecodeError):
        return []
    sendungen = []
    for p in wurzel.findall("programme"):
        if p.get("channel") != tvg_id:
            continue
        beginn, ende = _xmltv_zeit_lesen(p.get("start")), _xmltv_zeit_lesen(p.get("stop"))
        if beginn is None or ende is None or ende <= jetzt - zurueck:
            continue
        titel = p.findtext("title")
        if titel:
            sendungen.append({"titel": titel, "beginn": beginn, "ende": ende})
    sendungen.sort(key=lambda s: s["beginn"])
    return sendungen[:anzahl]
