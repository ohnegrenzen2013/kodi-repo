"""M3U: Sender-dicts, M3U-Kopf und -Eintraege sowie das Zerlegen fremder M3U/M3U8."""

import re

from .livetv_grund import (
    ERLAUBTE_SCHEMATA,
    LISTE_MAX_EINTRAEGE,
    SENDER,
    _ATTRIBUT,
    logo_quelle,
    urljoin,
    urlsplit,
)

def sender(einstellung, fern=None):
    """Alle Sender als dicts, mit an (True/False) und logo (Adresse bei Wikimedia oder None).

    url ist die gueltige Adresse: eigene (einstellung["adressen"]) vor fern (Adressen-Liste) vor mitgeliefert;
    herkunft sagt, woher sie stammt ("eigen", "liste", "standard"), standard ist die mitgelieferte."""
    aus = set(einstellung.get("aus") or [])
    eigene = einstellung.get("adressen") or {}
    fern = fern or {}
    ergebnis = []
    for i, n, g, t, u in SENDER:
        herkunft = "eigen" if eigene.get(i) else "liste" if fern.get(i) else "standard"
        ergebnis.append({"id": i, "name": n, "gruppe": g, "tvg_id": t, "url": eigene.get(i) or fern.get(i) or u,
                         "herkunft": herkunft, "standard": u, "an": i not in aus, "logo": logo_quelle(i)})
    return ergebnis


_EPG_KOPF = re.compile(r"""(?:url-tvg|x-tvg-url|tvg-url)\s*=\s*(?:"([^"]*)"|'([^']*)')""", re.I)
MAX_PLAYLIST_EPG = 5


def epg_aus_m3u(text):
    """EPG-Adressen, die eine Playlist im Kopf (#EXTM3U url-tvg="a,b") nennt: nur http(s), ohne Doppelte, hoechstens fuenf."""
    kopf = str(text or "").lstrip("\ufeff \t\r\n").split("\n", 1)[0]
    if not kopf.startswith("#EXTM3U"):
        return []
    adressen = []
    for treffer in _EPG_KOPF.finditer(kopf):
        for roh in (treffer.group(1) or treffer.group(2) or "").split(","):
            url = roh.strip()
            if url.lower().startswith(("http://", "https://")) and url not in adressen:
                adressen.append(url)
    return adressen[:MAX_PLAYLIST_EPG]


def _attribut(text):
    return str(text).replace('"', "'").replace("\n", " ")


def m3u(einstellung, epg_adresse=None, logo_basis=None, zusatz=None, fern=None):
    """M3U-Liste der eingeschalteten Sender; mit epg_adresse steht url-tvg im Kopf.

    logo_basis: Adresse des eigenen Servers (".../"), dann zeigen die Logos auf dessen Zwischenspeicher,
    sonst direkt auf Wikimedia Commons. fern: Sender-Adressen aus der Adressen-Liste."""
    kopf = '#EXTM3U url-tvg="%s"' % _attribut(epg_adresse) if epg_adresse else "#EXTM3U"
    zeilen = [kopf]
    for s in sender(einstellung, fern):
        if s["an"]:
            logo = ""
            if s["logo"]:
                logo = ' tvg-logo="%s"' % _attribut(
                    "%slogos/%s.png" % (logo_basis, s["id"]) if logo_basis else s["logo"])
            zeilen.append('#EXTINF:-1 tvg-id="%s" tvg-name="%s"%s group-title="%s",%s'
                          % (_attribut(s["tvg_id"]), _attribut(s["name"]), logo, _attribut(s["gruppe"]),
                             s["name"]))
            zeilen.append(s["url"])
    zeilen.extend(m3u_eintraege(zusatz or []))
    return "\n".join(zeilen) + "\n"


def zerlege_m3u(text, quelle, name):
    """M3U/M3U8 -> Liste von Eintraegen {"name", "url", "attribute", "optionen"}.

    Ein HLS-Stream (#EXT-X-...) wird zu einem einzigen Eintrag mit der Quell-Adresse."""
    zeilen = [z.strip() for z in text.splitlines()]
    if not zeilen or not zeilen[0].startswith("#EXTM3U"):
        return []
    if any(z.startswith("#EXT-X-") for z in zeilen):
        return [{"name": name, "url": quelle, "attribute": {"group-title": name}, "optionen": []}]
    eintraege, aktuell, optionen = [], None, []
    for zeile in zeilen[1:]:
        if not zeile:
            continue
        if zeile.startswith("#EXTINF"):
            kopf, _, titel = zeile.partition(",")
            aktuell = {"name": titel.strip() or name, "attribute": dict(_ATTRIBUT.findall(kopf))}
            optionen = []
        elif zeile.startswith(("#EXTVLCOPT", "#KODIPROP", "#EXTGRP")):
            optionen.append(zeile)
        elif zeile.startswith("#"):
            continue
        else:
            url = urljoin(quelle, zeile)
            if urlsplit(url).scheme.lower() in ERLAUBTE_SCHEMATA:
                eintrag = aktuell or {"name": url.rsplit("/", 1)[-1] or name, "attribute": {}}
                eintrag["attribute"].setdefault("group-title", name)
                eintraege.append(dict(eintrag, url=url, optionen=optionen))
                if len(eintraege) >= LISTE_MAX_EINTRAEGE:
                    break
            aktuell, optionen = None, []
    return eintraege


def m3u_eintraege(eintraege):
    """Eintraege wieder als M3U-Zeilen (ohne Kopf)."""
    zeilen = []
    for e in eintraege:
        attribute = "".join(' %s="%s"' % (k, _attribut(v)) for k, v in e["attribute"].items())
        zeilen.append("#EXTINF:-1%s,%s" % (attribute, e["name"].replace("\n", " ")))
        zeilen.extend(e["optionen"])
        zeilen.append(e["url"])
    return zeilen
