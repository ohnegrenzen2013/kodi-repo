"""Internet-Quellen: Sender-Adressen, eigene M3U-Listen, kostenlose Sender und Xtream-Adressen."""

import re

from .livetv_grund import (
    ADRESSEN_DATEI,
    GRENZEN,
    LISTEN_ORDNER,
    SENDER,
    LiveTvFehler,
    _Abholer,
    frei_tv,
    json,
    os,
    pruefe_adressen,
    quote,
    urlsplit,
    zu_gross,
)
from .livetv_m3u import (
    epg_aus_m3u,
    zerlege_m3u,
)

def _schluessel(text):
    return "".join(c for c in str(text or "").lower() if c.isalnum())


def adressen_aus_m3u(text):
    """M3U-Senderliste (z. B. iptv-org) -> {sender-id: adresse} fuer die mitgelieferten Sender (per tvg-id oder Name)."""
    nach_tvg = {_schluessel(s[3]): s[0] for s in SENDER if s[3]}
    nach_name = {_schluessel(s[1]): s[0] for s in SENDER}
    adressen = {}
    for e in zerlege_m3u(text, "", ""):
        attr = e.get("attribute") or {}
        tvg = _schluessel(attr.get("tvg-id", "").split("@")[0])
        name = _schluessel(re.sub(r"\s*[\[(].*?[\])]", "", e.get("name") or ""))  # "ZDF (1080p)" -> zdf
        sid = nach_tvg.get(tvg) or nach_name.get(name) or nach_name.get(_schluessel(attr.get("tvg-name")))
        if sid and sid not in adressen and str(e.get("url", "")).lower().startswith(("http://", "https://")):
            adressen[sid] = e["url"]
    return adressen


class Adressen(_Abholer):
    """Adressen-Liste aus dem Internet: JSON {sender-id: adresse}, ersetzt die mitgelieferten Sender-Adressen.

    Unbekannte Sender und Adressen ohne http(s) werden uebergangen, eigene Adressen haben weiter Vorrang."""

    art = "Adressen-Liste"

    def __init__(self, ordner, quelle, holen=None):
        super().__init__(os.path.join(ordner, ADRESSEN_DATEI), quelle, holen)

    def _schreiben(self, antwort, temp):
        inhalt = antwort.read(GRENZEN["adressen"] + 1)
        if len(inhalt) > GRENZEN["adressen"]:
            raise zu_gross("Adressen-Liste", "adressen")
        with open(temp, "wb") as f:
            f.write(inhalt)

    def _pruefen(self, temp):
        self._lies(temp)

    def _lies(self, pfad):
        with open(pfad, "rb") as f:
            text = f.read().decode("utf-8-sig", "replace")
        if text.lstrip().startswith("#EXTM3U"):
            return pruefe_adressen(adressen_aus_m3u(text), streng=False)
        try:
            roh = json.loads(text)
        except ValueError:
            raise ValueError("keine JSON-Datei {sender-id: adresse} und keine M3U-Senderliste")
        if not isinstance(roh, dict):
            raise ValueError("JSON-Objekt {sender-id: adresse} erwartet")
        return pruefe_adressen(roh, streng=False)

    def adressen(self):
        """Gueltige Adressen der zuletzt geladenen Fassung (leer ohne Quelle oder solange nichts geladen ist)."""
        if not self.quelle or not os.path.isfile(self.pfad):
            return {}
        try:
            return self._lies(self.pfad)
        except (OSError, ValueError):
            return {}

    def zustand(self):
        z = super().zustand()
        z["anzahl"] = len(self.adressen())
        return z


def xtream_basis(server):
    """Nur Schema + Host + Port aus einer Xtream-Serveradresse (ohne get.php, Pfad, Abfrage)."""
    server = str(server or "").strip()
    if not server:
        raise LiveTvFehler("Server-Adresse fehlt")
    if not server.lower().startswith(("http://", "https://")):
        server = "http://" + server
    teile = urlsplit(server)
    if not teile.hostname:
        raise LiveTvFehler("Server-Adresse unverstaendlich")
    netz = teile.hostname + ((":%d" % teile.port) if teile.port else "")
    return "%s://%s" % (teile.scheme, netz)


def xtream_m3u_url(server, benutzer, passwort, typ="m3u_plus"):
    """Baut die M3U-Adresse eines Xtream-Zugangs (get.php) aus den eigenen Zugangsdaten.

    Nur fuer das eigene Abo gedacht: Benutzer und Passwort sind dieselben, die der Anbieter vergibt.
    Es wird keine fremde Anmeldung umgangen, nur die uebliche get.php-Adresse zusammengesetzt."""
    benutzer = str(benutzer or "").strip()
    passwort = str(passwort or "").strip()
    if not benutzer or not passwort:
        raise LiveTvFehler("Benutzername und Passwort noetig")
    if typ not in ("m3u_plus", "m3u"):
        raise LiveTvFehler("Unbekannter Typ: %s" % typ)
    return "%s/get.php?username=%s&password=%s&type=%s&output=ts" % (
        xtream_basis(server), quote(benutzer, safe=""), quote(passwort, safe=""), typ)


class Liste(_Abholer):
    """Eine M3U/M3U8 aus dem Internet: Senderliste oder einzelner HLS-Stream."""

    art = "Liste"

    def __init__(self, ordner, liste_id, name, quelle, holen=None):
        super().__init__(os.path.join(ordner, LISTEN_ORDNER, liste_id + ".m3u"), quelle, holen)
        self.id = liste_id
        self.name = name
        self.art = "Liste %s" % name

    def _schreiben(self, antwort, temp):
        inhalt = antwort.read(GRENZEN["liste"] + 1)
        if len(inhalt) > GRENZEN["liste"]:
            raise zu_gross("Liste", "liste")
        with open(temp, "wb") as f:
            f.write(inhalt)

    def _pruefen(self, temp):
        if not self._lies(temp):
            raise ValueError("keine M3U/M3U8 oder keine abspielbaren Eintraege")

    def eintraege(self):
        """Sender der zuletzt geladenen Fassung (leer, solange nichts geladen ist)."""
        return self._lies(self.pfad) if os.path.isfile(self.pfad) else []

    def _lies(self, pfad):
        with open(pfad, "rb") as f:
            text = f.read().decode("utf-8-sig", errors="replace")
        return zerlege_m3u(text, self.quelle, self.name)

    def epg_adressen(self):
        """EPG-Adressen aus dem Kopf der zuletzt geladenen Fassung (url-tvg); leer ohne Datei oder ohne Angabe."""
        try:
            with open(self.pfad, "rb") as f:
                kopf = f.read(8192)
        except OSError:
            return []
        return epg_aus_m3u(kopf.decode("utf-8-sig", errors="replace"))

    def zustand(self):
        z = super().zustand()
        z.update(id=self.id, name=self.name, anzahl=len(self.eintraege()))
        return z


class FreiListe(_Abholer):
    """Kostenlose Sender (frei_tv) wie eine Liste: einmal am Tag geladen, als JSON zwischengespeichert."""

    def __init__(self, ordner, liste_id, holen=None):
        quelle, region = frei_tv._zerlegen(liste_id)
        self.id = "frei-" + liste_id
        super().__init__(os.path.join(ordner, LISTEN_ORDNER, self.id + ".json"), frei_tv.QUELLEN[quelle]["daten"], holen)
        self.liste_id = liste_id
        self.name = "%s · %s" % (frei_tv.QUELLEN[quelle]["name"], frei_tv.REGIONEN[region])
        self.art = "Liste %s" % self.name
        self._frei_holen = holen
        self._zwischen = (None, [])

    def _laden(self, temp):
        holen = None
        if self._frei_holen:
            def holen(url):
                with self._frei_holen(url) as a:
                    return a.read(frei_tv.MAX_DATEN + 1)
        eintraege = frei_tv.sender(self.liste_id, holen)
        with open(temp, "w", encoding="utf-8") as f:
            json.dump(eintraege, f, ensure_ascii=False)

    def eintraege(self):
        try:
            stand = os.path.getmtime(self.pfad)
        except OSError:
            return []
        if self._zwischen[0] != stand:
            with open(self.pfad, encoding="utf-8") as f:
                self._zwischen = (stand, json.load(f))
        return self._zwischen[1]

    def zustand(self):
        z = super().zustand()
        z.update(id=self.id, name=self.name, anzahl=len(self.eintraege()))
        return z
