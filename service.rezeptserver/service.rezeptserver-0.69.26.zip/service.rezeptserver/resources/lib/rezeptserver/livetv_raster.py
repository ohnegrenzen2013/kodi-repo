"""Live-TV: Programmuebersicht (Zeitraster) aus der gespeicherten XMLTV-Datei.

Idee aus der Kanalliste von Vavoo (aktuelle Sendung mit Zeit und Fortschritt) und der Programmuebersicht klassischer
TV-Apps; hier selbst gebaut und nur auf die eigene EPG-Datei gestuetzt - kein Netzzugriff, keine fremde Schnittstelle.

raster(ordner, tvg_ids, von, bis): {tvg_id: [{"titel", "beginn", "ende"}, ...]} aller Sendungen, die im Zeitfenster
[von, bis) laufen (auch angeschnittene). Hoechstens MAX_KANAELE Kanaele und MAX_FENSTER Sekunden; leer bei fehlender
oder kaputter Datei (reine Lesefunktion, wirft nie).
"""

import gzip
import os
import xml.etree.ElementTree as ET

from .livetv_epg import EPG_DATEI, _xmltv_zeit_lesen

MAX_KANAELE = 60
MAX_FENSTER = 12 * 3600
MAX_PRO_KANAL = 80


def fenster_pruefen(von, bis):
    """(von, bis) als Zahlen; bis wird auf MAX_FENSTER gekappt. Wirft ValueError bei Unsinn."""
    try:
        von, bis = float(von), float(bis)
    except (TypeError, ValueError):
        raise ValueError("von/bis müssen Zeitstempel sein") from None
    if not (von == von and bis == bis) or bis <= von:  # NaN oder leeres Fenster
        raise ValueError("Zeitfenster ist leer")
    return von, min(bis, von + MAX_FENSTER)


def raster(ordner, tvg_ids, von, bis):
    tvg_ids = set(sorted(set(tvg_ids))[:MAX_KANAELE])
    if not tvg_ids:
        return {}
    try:
        von, bis = fenster_pruefen(von, bis)
        with gzip.open(os.path.join(ordner, EPG_DATEI), "rt", encoding="utf-8") as f:
            wurzel = ET.fromstring(f.read())
    except (OSError, ET.ParseError, UnicodeDecodeError, ValueError, EOFError):
        return {}
    ergebnis = {}
    for p in wurzel.findall("programme"):
        kanal = p.get("channel")
        if kanal not in tvg_ids:
            continue
        beginn, ende = _xmltv_zeit_lesen(p.get("start")), _xmltv_zeit_lesen(p.get("stop"))
        if beginn is None or ende is None or ende <= beginn or ende <= von or beginn >= bis:
            continue
        titel = p.findtext("title")
        liste = ergebnis.setdefault(kanal, [])
        if titel and len(liste) < MAX_PRO_KANAL:
            liste.append({"titel": titel, "beginn": beginn, "ende": ende})
    for liste in ergebnis.values():
        liste.sort(key=lambda s: s["beginn"])
    return {k: v for k, v in ergebnis.items() if v}
