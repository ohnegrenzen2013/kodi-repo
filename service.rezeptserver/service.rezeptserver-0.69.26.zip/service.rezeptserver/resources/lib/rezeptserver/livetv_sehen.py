"""Live-TV: Favoriten und Zuletzt angesehen je Profil, auf allen Geraeten gleich (Muster sehen.py).

Sender sind, anders als Filme/Serien, schon durch ihre id eindeutig beschrieben (kein Jahr/Bild/Bewertung
noetig) - deshalb ein eigenes, viel kleineres Modul statt sehen.py mitzubenutzen.

Nutzerdaten "livetv_sehen": {"<profil-id oder ''>": {"favoriten": [sender_id, ...],
                                                       "verlauf": [{"id", "zeit"}, ...]}}
Nutzerdaten "livetv_zaehler": {"<profil-id oder ''>": {sender_id: wie oft eingeschaltet}} - nur lokal gezaehlt, ergibt die
Sortierung "Beliebt" der Senderliste (Idee: Vavoos Sortierung nach Beliebtheit; hier ohne fremden Dienst, nur die eigenen Aufrufe).
"""

import time

SCHLUESSEL = "livetv_sehen"
MAX_VERLAUF = 50
MAX_FAVORITEN = 300
ZAEHLER = "livetv_zaehler"
MAX_ZAEHLER = 500


def _eintrag(daten, profil_id):
    alle = daten.get(SCHLUESSEL) if isinstance(daten.get(SCHLUESSEL), dict) else {}
    eigen = alle.get(profil_id or "") if isinstance(alle.get(profil_id or ""), dict) else {}
    favoriten, gesehen_fav = [], set()
    for i in eigen.get("favoriten") or []:
        if isinstance(i, str) and i and i not in gesehen_fav:
            gesehen_fav.add(i)
            favoriten.append(i)
        if len(favoriten) >= MAX_FAVORITEN:
            break
    verlauf = []
    gesehen = set()
    for roh in eigen.get("verlauf") or []:
        if not isinstance(roh, dict):
            continue
        sender_id = roh.get("id")
        if not isinstance(sender_id, str) or not sender_id or sender_id in gesehen:
            continue
        try:
            zeit = float(roh.get("zeit") or 0)
        except (TypeError, ValueError):
            zeit = 0.0
        gesehen.add(sender_id)
        verlauf.append({"id": sender_id, "zeit": zeit})
        if len(verlauf) >= MAX_VERLAUF:
            break
    return {"favoriten": favoriten, "verlauf": verlauf}


def lesen(daten, profil_id=""):
    """Favoriten und Verlauf dieses Profils; kaputte Eintraege fallen weg."""
    return _eintrag(daten if isinstance(daten, dict) else {}, profil_id)


def _speichern(daten, profil_id, eintrag):
    alle = daten.get(SCHLUESSEL) if isinstance(daten.get(SCHLUESSEL), dict) else {}
    alle[profil_id or ""] = eintrag
    daten[SCHLUESSEL] = alle
    return eintrag


def favorit_setzen(daten, profil_id, sender_id, an):
    """Sender als Favorit ein-/austragen. Gibt die neuen Listen zurueck."""
    sender_id = str(sender_id or "")
    if not sender_id:
        raise ValueError("Sender-Id fehlt")
    eintrag = _eintrag(daten, profil_id)
    rest = [i for i in eintrag["favoriten"] if i != sender_id]
    eintrag["favoriten"] = ([sender_id] + rest if an else rest)[:MAX_FAVORITEN]
    return _speichern(daten, profil_id, eintrag)


def angesehen_setzen(daten, profil_id, sender_id, jetzt=None):
    """Sender vorn in den Verlauf setzen (wie 'gesehen' bei Filmen/Serien). Gibt die neuen Listen zurueck."""
    sender_id = str(sender_id or "")
    if not sender_id:
        raise ValueError("Sender-Id fehlt")
    eintrag = _eintrag(daten, profil_id)
    rest = [x for x in eintrag["verlauf"] if x["id"] != sender_id]
    neu = {"id": sender_id, "zeit": time.time() if jetzt is None else jetzt}
    eintrag["verlauf"] = ([neu] + rest)[:MAX_VERLAUF]
    zaehlen(daten, profil_id, sender_id)
    return _speichern(daten, profil_id, eintrag)


def _zaehler(daten, profil_id):
    alle = daten.get(ZAEHLER) if isinstance(daten.get(ZAEHLER), dict) else {}
    roh = alle.get(profil_id or "") if isinstance(alle.get(profil_id or ""), dict) else {}
    ergebnis = {}
    for sender_id, n in roh.items():
        if isinstance(sender_id, str) and sender_id and isinstance(n, int) and not isinstance(n, bool) and n > 0:
            ergebnis[sender_id] = n
    return ergebnis


def zaehlen(daten, profil_id, sender_id):
    """Zaehlt einen Aufruf mit. Ueber MAX_ZAEHLER Sender bleiben nur die am haeufigsten gesehenen."""
    sender_id = str(sender_id or "")
    if not sender_id:
        raise ValueError("Sender-Id fehlt")
    z = _zaehler(daten, profil_id)
    z[sender_id] = z.get(sender_id, 0) + 1
    if len(z) > MAX_ZAEHLER:
        z = dict(sorted(z.items(), key=lambda kv: -kv[1])[:MAX_ZAEHLER])
    alle = daten.get(ZAEHLER) if isinstance(daten.get(ZAEHLER), dict) else {}
    alle[profil_id or ""] = z
    daten[ZAEHLER] = alle
    return z


def haeufig(daten, profil_id="", anzahl=MAX_ZAEHLER):
    """Sender-Ids, am haeufigsten gesehen zuerst (bei Gleichstand der zuletzt gesehene vorn)."""
    daten = daten if isinstance(daten, dict) else {}
    z = _zaehler(daten, profil_id)
    stelle = {e["id"]: i for i, e in enumerate(_eintrag(daten, profil_id)["verlauf"])}
    return sorted(z, key=lambda i: (-z[i], stelle.get(i, 10**6), i))[:anzahl]
