"""Sport-Events im Live-TV (ESPN-Scoreboard, ohne Schluessel).

Die ESPN-Site-API liefert kommende Spiele grosser Ligen als JSON. H0rSt liest nur
Name, Termin, Wettbewerb, Teams, Status und die genannten Sender, ordnet die Sender
den vorhandenen Live-TV-Kanaelen zu und zeigt daraus eine Sport-Ansicht. Es werden
keine Events erfunden und keine Streams von ESPN uebernommen; gespielt wird nur der
eigene, passende Live-TV-Sender.
"""

import json
import re
import time
import urllib.request

from .netz import USER_AGENT

LIGEN = [
    ("soccer/ger.1", "Bundesliga"), ("soccer/uefa.champions", "Champions League"),
    ("soccer/eng.1", "Premier League"), ("soccer/esp.1", "La Liga"),
    ("basketball/nba", "NBA"), ("football/nfl", "NFL"), ("hockey/nhl", "NHL"),
    ("baseball/mlb", "MLB"), ("football/college-football", "College Football"),
]
BASIS = "https://site.api.espn.com/apis/site/v2/sports/"
CACHE_ZEIT = 600
MAX_EVENTS = 200
_CACHE = {}


class SportFehler(ValueError):
    pass


def _holen(url):
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": USER_AGENT}), timeout=12) as antwort:
            return int(getattr(antwort, "status", 0) or antwort.getcode() or 0), antwort.read(4 * 1024 * 1024)
    except Exception:  # noqa: BLE001
        return 0, b""


def _normal(text):
    text = " ".join(str(text or "").lower().split())
    return re.sub(r"\s+(?:hd|sd|uhd|4k|plus|\+)$", "", text)


def _daten_holen(url, holen):
    stand = _CACHE.get(url)
    if stand and time.time() - stand[0] < CACHE_ZEIT:
        return stand[1]
    holen = holen or _holen
    status, inhalt = holen(url)
    if status != 200 or not inhalt:
        return None
    try:
        daten = json.loads(inhalt.decode("utf-8", "replace"))
    except (ValueError, UnicodeDecodeError):
        return None
    _CACHE[url] = (time.time(), daten)
    return daten


def _sender_zuordnen(namen, kanaele):
    text = _normal(namen)
    if not text:
        return ""
    for sender_id, sender_name in kanaele:
        if _normal(sender_name) and _normal(sender_name) in text:
            return sender_id
    return ""


def _event(roh, liga, kanaele):
    if not isinstance(roh, dict):
        return None
    wettbewerb = (roh.get("competitions") or [{}])[0] if isinstance(roh.get("competitions"), list) else {}
    teams = []
    for teil in wettbewerb.get("competitors") or []:
        if isinstance(teil, dict):
            team = teil.get("team") or {}
            teams.append({"name": str(team.get("displayName") or team.get("name") or teil.get("name") or ""),
                          "heim": teil.get("homeAway") == "home", "punkte": str(teil.get("score") or "")})
    teams.sort(key=lambda x: not x["heim"])
    sender = []
    for ausstrahlung in wettbewerb.get("broadcasts") or []:
        if isinstance(ausstrahlung, dict):
            sender.extend(str(x) for x in ausstrahlung.get("names") or [] if x)
    status = wettbewerb.get("status") or roh.get("status") or {}
    status_art = status.get("type") if isinstance(status.get("type"), dict) else {}
    return {"id": str(roh.get("id") or ""), "liga": liga, "titel": str(roh.get("name") or "Spiel"),
            "datum": str(roh.get("date") or ""), "status": str((status_art or {}).get("detail") or status.get("displayClock") or ""),
            "beendet": bool((status_art or {}).get("completed")),
            "teams": teams, "sender": sender,
            "sender_id": _sender_zuordnen(" ".join(sender), kanaele),
            "link": str((roh.get("links") or [{}])[0].get("href") if isinstance(roh.get("links"), list) and roh.get("links") else "")}


def events(tage=2, kanaele=None, holen=None):
    kanaele = kanaele or []
    try:
        tage = max(1, min(7, int(tage or 2)))
    except (TypeError, ValueError):
        tage = 2
    gesammelt, gesehen = [], set()
    for pfad, liga in LIGEN:
        for tag in range(tage):
            if tag == 0:
                von = bis = time.strftime("%Y%m%d")
            else:
                von = bis = time.strftime("%Y%m%d", time.localtime(time.time() + tag * 86400))
            url = BASIS + pfad + "/scoreboard?dates=" + von if von == bis else BASIS + pfad + "/scoreboard?dates=" + von + "-" + bis
            daten = _daten_holen(url, holen)
            if not daten:
                continue
            for roh in daten.get("events") or []:
                eintrag = _event(roh, liga, kanaele)
                if not eintrag or eintrag["id"] in gesehen:
                    continue
                gesehen.add(eintrag["id"])
                gesammelt.append(eintrag)
                if len(gesammelt) >= MAX_EVENTS:
                    break
            if len(gesammelt) >= MAX_EVENTS:
                break
        if len(gesammelt) >= MAX_EVENTS:
            break
    gesammelt.sort(key=lambda e: (e["datum"], e["liga"], e["titel"]))
    return {"events": gesammelt, "tage": tage,
            "hinweis": "" if gesammelt else "Keine Sportereignisse gefunden (ESPN nicht erreichbar oder keine Spiele eingetragen)."}
