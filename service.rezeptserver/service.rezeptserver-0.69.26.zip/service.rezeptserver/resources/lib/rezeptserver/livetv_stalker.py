"""Stalker-Portale als Live-TV-Quelle (MAG/STB-API).

Unterstuetzte Aufrufe: handshake, get_profile, get_all_channels, get_short_epg und
create_link. Die Zugangsdaten (Portaladresse und MAC) stammen aus den Live-TV-
Einstellungen; H0rSt umgeht keine Anmeldung, sondern nutzt nur das eigene Portal.
Kanaladressen werden erst beim Abspielen ueber create_link aufgeloest, weil sie
ablaufen koennen. Kanallisten liegen 10 Minuten im Speicher.
"""

import json
import re
import time
import urllib.request
from urllib.parse import urlencode

KOPF = {
    "User-Agent": "Mozilla/5.0 (QtEmbedded; U; Linux; C) AppleWebKit/533.3 (KHTML, like Gecko) MAG200 stbapp ver: 2 rev: 250 Safari/533.3",
    "X-User-Agent": "Model: MAG250; Link: WiFi",
    "Accept": "application/json, text/plain, */*",
}
CACHE_ZEIT = 600
MAX_KANAELE = 5000
ENDPUNKTE = ("/server/load.php", "/portal.php", "/stalker_portal/server/load.php", "/c/server/load.php")


class StalkerFehler(ValueError):
    pass


def _standard_holen(url, kopf):
    try:
        with urllib.request.urlopen(urllib.request.Request(url, headers=kopf), timeout=15) as antwort:
            return int(getattr(antwort, "status", 0) or antwort.getcode() or 0), antwort.read(8 * 1024 * 1024)
    except Exception as fehler:  # noqa: BLE001
        return 0, str(fehler).encode()


def _mac_kopf(mac):
    kopf = dict(KOPF)
    if mac:
        kopf["Cookie"] = "mac=%s; stb_lang=de; timezone=Europe/Berlin" % mac
    return kopf


class StalkerPortal:
    def __init__(self, name, url, mac="", holen=None):
        self.name = name
        self.url = str(url or "").rstrip("/")
        self.mac = str(mac or "").strip().upper()
        self.holen = holen or _standard_holen
        self.endpunkt = ""
        self.token = ""

    def _kandidaten(self):
        if self.endpunkt:
            return [self.endpunkt]
        ziele = []
        for stelle in (self.url, self.url.rsplit("/", 1)[0] if "/" in self.url[8:] else self.url):
            for pfad in ENDPUNKTE:
                ziel = stelle + pfad
                if ziel not in ziele:
                    ziele.append(ziel)
        return ziele

    def _ruf(self, params, token=None):
        basis = self.endpunkt or (self.url + "/server/load.php")
        adresse = basis + ("?" + urlencode(params) if params else "")
        kopf = _mac_kopf(self.mac)
        if token:
            kopf["Authorization"] = "Bearer " + token
        status, inhalt = self.holen(adresse, kopf)
        if status != 200 or not inhalt:
            raise StalkerFehler("Portal antwortet nicht (HTTP %s)" % status)
        try:
            daten = json.loads(inhalt.decode("utf-8", "replace"))
        except (ValueError, UnicodeDecodeError):
            raise StalkerFehler("Portal liefert kein JSON")
        return daten if isinstance(daten, dict) else {}

    def _js(self, daten):
        innen = daten.get("js")
        return innen if isinstance(innen, dict) else daten

    def handshake(self):
        letzte = ""
        for endpunkt in self._kandidaten():
            adresse = endpunkt + "?type=stb&action=handshake"
            kopf = _mac_kopf(self.mac)
            status, inhalt = self.holen(adresse, kopf)
            if status != 200 or not inhalt:
                letzte = "HTTP %s" % status
                continue
            try:
                daten = json.loads(inhalt.decode("utf-8", "replace"))
            except (ValueError, UnicodeDecodeError):
                letzte = "kein JSON"
                continue
            js = self._js(daten)
            token = str(daten.get("token") or js.get("token") or "")
            if token:
                self.endpunkt, self.token = endpunkt, token
                return token
            letzte = "kein Token"
        raise StalkerFehler("Handshake fehlgeschlagen: %s" % (letzte or "unbekannt"))

    def _itv(self, aktion, **params):
        if not self.token:
            self.handshake()
        daten = self._ruf(dict({"type": "itv", "action": aktion}, **params), token=self.token)
        return self._js(daten)

    def profile(self):
        if not self.token:
            self.handshake()
        data = self._ruf({"type": "stb", "action": "get_profile"}, token=self.token)
        return self._js(data)

    def kanaele(self):
        ergebnis, seen = [], set()
        for seite in range(1, 41):
            daten = self._itv("get_all_channels", p=seite)
            roh = daten.get("data") if isinstance(daten.get("data"), list) else []
            if not roh:
                break
            for eintrag in roh:
                if not isinstance(eintrag, dict):
                    continue
                kid = str(eintrag.get("id") or "")
                name = str(eintrag.get("name") or "").strip()
                cmd = str(eintrag.get("cmd") or "")
                if not kid or not name or kid in seen:
                    continue
                seen.add(kid)
                ergebnis.append({"id": kid, "name": name[:120], "cmd": cmd,
                                 "logo": str(eintrag.get("logo") or "")[:500],
                                 "genre": str(eintrag.get("tv_genre_id") or "")[:40]})
                if len(ergebnis) >= MAX_KANAELE:
                    return ergebnis
        return ergebnis

    def epg(self, kanal_id):
        daten = self._itv("get_short_epg", ch_id=kanal_id, size=6)
        return daten.get("data") if isinstance(daten.get("data"), list) else []

    def link(self, cmd):
        daten = self._itv("create_link", cmd=cmd, series="0", forced_storage="0", disable_ad="0", download="0")
        adresse = str(daten.get("cmd") or daten.get("url") or "")
        if not re.match(r"^(https?|rtmp|rtsp)://", adresse):
            raise StalkerFehler("Portal liefert keine abspielbare Adresse")
        return adresse


_CACHE = {}


def _stelle(portal):
    return (portal["url"], portal.get("mac", ""))


def laden(portale, holen=None):
    """Alle Portale pruefen und die Kanallisten 10 Minuten zwischenspeichern."""
    bericht = []
    for portal in portale or []:
        client = StalkerPortal(portal.get("name") or "Portal", portal.get("url"), portal.get("mac"), holen)
        try:
            client.handshake()
            kanaele = client.kanaele()
            _CACHE[_stelle(portal)] = (time.time(), kanaele)
            bericht.append({"name": client.name, "ok": True, "kanaele": len(kanaele), "fehler": ""})
        except StalkerFehler as fehler:
            bericht.append({"name": client.name, "ok": False, "kanaele": 0, "fehler": str(fehler)})
    return bericht


def zustand(portale):
    ergebnis = []
    for portal in portale or []:
        stand = _CACHE.get(_stelle(portal))
        frisch = bool(stand and time.time() - stand[0] <= CACHE_ZEIT)
        ergebnis.append({"name": portal.get("name") or "Portal", "url": portal.get("url", ""),
                         "kanaele": len(stand[1]) if frisch else 0, "frisch": frisch})
    return ergebnis


def sender(portale):
    """Zwischengespeicherte Kanaele als Sender-Eintraege fuer die Live-TV-Liste."""
    ergebnis = []
    for nummer, portal in enumerate(portale or []):
        stand = _CACHE.get(_stelle(portal))
        if not stand or time.time() - stand[0] > CACHE_ZEIT:
            continue
        for kanal in stand[1]:
            ergebnis.append({"id": "stalker-%d-%s" % (nummer, kanal["id"]), "name": kanal["name"],
                             "logo": kanal["logo"] or None, "url": "", "gruppe": portal.get("name") or "Stalker",
                             "kategorie": kanal.get("genre") or "Stalker", "stalker": {"portal": nummer,
                                                                                       "cmd": kanal["cmd"]}})
    return ergebnis


def link(portale, sender_id, holen=None):
    treffer = re.match(r"^stalker-(\d+)-(.+)$", str(sender_id or ""))
    if not treffer:
        raise StalkerFehler("Unbekannter Portal-Sender")
    nummer, kanal_id = int(treffer.group(1)), treffer.group(2)
    if nummer >= len(portale or []):
        raise StalkerFehler("Unbekanntes Portal")
    portal = portale[nummer]
    stand = _CACHE.get(_stelle(portal))
    kanal = next((k for k in (stand[1] if stand else []) if k["id"] == kanal_id), None)
    if not kanal:
        raise StalkerFehler("Kanal nicht geladen – bitte Portale neu laden")
    client = StalkerPortal(portal.get("name") or "Portal", portal.get("url"), portal.get("mac"), holen)
    client.handshake()
    return client.link(kanal["cmd"])
