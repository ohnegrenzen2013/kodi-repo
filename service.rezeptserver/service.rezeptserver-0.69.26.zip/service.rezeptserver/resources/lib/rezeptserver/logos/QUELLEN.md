# Senderlogos

Quelle: Wikimedia Commons, jeweils die aktuelle Fassung laut Wikidata (Eigenschaft P154), als PNG-Vorschau mit 330 px Breite.
Alle Dateien sind dort als gemeinfrei (Public Domain, einfache Schrift-/Bildmarken) gekennzeichnet. Die Marken gehören den Sendern.

Neu laden: `python3 tools/logos_holen.py --alle` (Liste in `rezeptserver/livetv.py`, `LOGOS`).

| Datei | Commons-Datei |
|---|---|
| daserste.png | [Das_Erste_2014.svg](https://commons.wikimedia.org/wiki/File:Das_Erste_2014.svg) |
| zdf.png | [ZDF_logo.svg](https://commons.wikimedia.org/wiki/File:ZDF_logo.svg) |
| 3sat.png | [3sat_2019.svg](https://commons.wikimedia.org/wiki/File:3sat_2019.svg) |
| arte.png | [Arte_Logo_2026.svg](https://commons.wikimedia.org/wiki/File:Arte_Logo_2026.svg) |
| phoenix.png | [Phoenix-logo-2018.svg](https://commons.wikimedia.org/wiki/File:Phoenix-logo-2018.svg) |
| kika.png | [KIKA-Logo.svg](https://commons.wikimedia.org/wiki/File:KIKA-Logo.svg) |
| zdfneo.png | [ZDFneo_2017.svg](https://commons.wikimedia.org/wiki/File:ZDFneo_2017.svg) |
| zdfinfo.png | [ZDFinfo_2011.svg](https://commons.wikimedia.org/wiki/File:ZDFinfo_2011.svg) |
| tagesschau24.png | [Tagesschau24-2012.svg](https://commons.wikimedia.org/wiki/File:Tagesschau24-2012.svg) |
| one.png | [One_2022.svg](https://commons.wikimedia.org/wiki/File:One_2022.svg) |
| ardalpha.png | [ARD_alpha.svg](https://commons.wikimedia.org/wiki/File:ARD_alpha.svg) |
| br.png | [Logo_Bayerischer_Rundfunk_2024.svg](https://commons.wikimedia.org/wiki/File:Logo_Bayerischer_Rundfunk_2024.svg) |
| hr.png | [HR-Fernsehen_Logo_2023.svg](https://commons.wikimedia.org/wiki/File:HR-Fernsehen_Logo_2023.svg) |
| mdr.png | [MDR_Logo_2017.svg](https://commons.wikimedia.org/wiki/File:MDR_Logo_2017.svg) |
| ndr.png | [Logo_NDR_Fernsehen_2017.svg](https://commons.wikimedia.org/wiki/File:Logo_NDR_Fernsehen_2017.svg) |
| rbb.png | [Rbb_Fernsehen_Logo_2017.08.svg](https://commons.wikimedia.org/wiki/File:Rbb_Fernsehen_Logo_2017.08.svg) |
| sr.png | [SR_Fernsehen_Logo_2023.svg](https://commons.wikimedia.org/wiki/File:SR_Fernsehen_Logo_2023.svg) |
| swr.png | [SWR_Logo_2023.svg](https://commons.wikimedia.org/wiki/File:SWR_Logo_2023.svg) |
| wdr.png | [Wdr_fernsehen_logo_2016.svg](https://commons.wikimedia.org/wiki/File:Wdr_fernsehen_logo_2016.svg) |
| dw.png | [Deutsche_Welle_symbol_2012.svg](https://commons.wikimedia.org/wiki/File:Deutsche_Welle_symbol_2012.svg) |
