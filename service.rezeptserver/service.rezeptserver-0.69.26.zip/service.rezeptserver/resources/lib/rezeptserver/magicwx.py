"""MagicWX: lokale Chat- und Bildparameter als Block fuer die App austauschen.

MagicWX (Pangu-Immortal/MagicWX, MIT, Stand 1.1.5) spricht im Bildbereich
dasselbe LocalDream-Protokoll wie H0rSt. Sein Advanced-Dialog kann Parameter
als Text teilen und aus der Zwischenablage importieren:

    prompt=…
    steps=20
    size=512x512
    …

H0rSt baut denselben Block aus den Einstellungen und liest ihn zurueck. Die
Startparameter lowram, seq_dit und patch gelten beim Start des nativen
Bildservers; H0rSt nimmt sie in den Block auf, sendet sie aber nicht als
Bildauftrag.
"""

NAME = "MagicWX"
REPO = "Pangu-Immortal/MagicWX"
STAND = "1.2.0"
LIZENZ = "MIT"
APK_VERSION = "v1.2.0"
APK = "https://github.com/Pangu-Immortal/MagicWX/releases/download/v1.2.0/app-release.apk"
PAKET = "com.qihao.open.rwkv"
SERVER = "http://127.0.0.1:18081"
MODELLE = [
    {"id": "builtin", "name": "MagicWX built-in experience", "art": "BUILTIN_TEXT", "download": False},
    {"id": "rwkv-7", "name": "RWKV-7 World 0.4B", "art": "ONNX_TEXT_GENERATION", "download": True},
    {"id": "qwen3", "name": "Qwen3 0.6B", "art": "ONNX_TEXT_GENERATION", "download": True},
    {"id": "qwen25", "name": "Qwen2.5 0.5B", "art": "ONNX_TEXT_GENERATION", "download": True},
    {"id": "smollm", "name": "SmolLM2 360M", "art": "ONNX_TEXT_GENERATION", "download": True},
    {"id": "tinyllama", "name": "TinyLlama 1.1B Chat", "art": "LITERT_LM", "download": True},
]
MODI = ("txt2img", "img2img", "inpaint")
SAMPLER = ("dpm", "dpm_karras", "dpm_sde", "dpm_sde_karras", "euler_a", "euler", "lcm")
FORMATE = ("png", "jpeg", "raw")
SEITEN = ("1:1", "3:4", "4:3", "9:16", "16:9")
FELDER = ("prompt", "negative_prompt", "mode", "steps", "cfg", "seed", "size", "scheduler", "aspect_ratio",
          "denoise_strength", "show_diffusion_process", "show_diffusion_stride", "output_format", "batch_count",
          "ultrafix_steps", "ultrafix_denoise_steps", "ultrafix_quality_denoise", "lowram", "seq_dit", "patch")

_SETTING = {
    "prompt": "magicwx_prompt", "negative_prompt": "magicwx_negativ", "mode": "magicwx_modus",
    "steps": "magicwx_schritte", "cfg": "magicwx_cfg", "seed": "magicwx_seed", "width": "magicwx_breite",
    "height": "magicwx_hoehe", "scheduler": "magicwx_sampler", "aspect_ratio": "magicwx_aspect",
    "denoise_strength": "magicwx_denoise", "show_diffusion_process": "magicwx_vorschau",
    "show_diffusion_stride": "magicwx_stride", "output_format": "magicwx_format", "batch_count": "magicwx_batch",
    "ultrafix_steps": "magicwx_ultrafix_steps", "ultrafix_denoise_steps": "magicwx_ultrafix_denoise",
    "ultrafix_quality_denoise": "magicwx_ultrafix_qualitaet", "lowram": "magicwx_lowram",
    "seq_dit": "magicwx_seqdit", "patch": "magicwx_patch",
}

_STANDARD = {
    "prompt": "masterpiece, best quality, a cat on a windowsill, warm light,",
    "negative_prompt": "worst quality, low quality, blurry, watermark, signature, text,",
    "mode": "txt2img", "steps": "20", "cfg": "7", "seed": "-1", "width": "512", "height": "512",
    "scheduler": "dpm", "aspect_ratio": "1:1", "denoise_strength": "0.6", "show_diffusion_process": True,
    "show_diffusion_stride": "2", "output_format": "png", "batch_count": "1", "ultrafix_steps": "10",
    "ultrafix_denoise_steps": "4", "ultrafix_quality_denoise": True, "lowram": False, "seq_dit": False, "patch": "",
}


def _wert(werte, schluessel):
    einstellung = _SETTING.get(schluessel, schluessel)
    if einstellung in werte:
        return werte.get(einstellung)
    if schluessel in werte:
        return werte.get(schluessel)
    return _STANDARD[schluessel]


def _wahr(wert):
    return wert is True or str(wert).strip().lower() in ("true", "1", "an", "ja", "ein")


def _zahl(wert, standard):
    text = str(wert if wert is not None else "").strip()
    try:
        zahl = float(text)
        if not (-float("inf") < zahl < float("inf")):
            return standard
        return str(int(zahl))
    except (TypeError, ValueError, OverflowError):
        return standard


def _begrenzt(wert, klein, gross, standard):
    try:
        zahl = int(_zahl(wert, standard))
    except (TypeError, ValueError, OverflowError):
        zahl = klein
    return str(max(klein, min(gross, zahl)))


def _komma(wert, klein, gross, standard):
    try:
        zahl = float(str(wert).replace(",", "."))
        if not (-float("inf") < zahl < float("inf")):
            raise ValueError
    except (TypeError, ValueError, OverflowError):
        return standard
    return ("%.4f" % max(klein, min(gross, zahl))).rstrip("0").rstrip(".")


def block(werte):
    """Parameterblock im Format von MagicWX' „Teilen“ und „Importieren“."""
    w = werte if isinstance(werte, dict) else {}
    breite = _begrenzt(_wert(w, "width"), 64, 2048, "512")
    hoehe = _begrenzt(_wert(w, "height"), 64, 2048, "512")
    seed = _begrenzt(_wert(w, "seed"), -1, 2 ** 32 - 1, "-1")
    zeilen = [
        ("prompt", str(_wert(w, "prompt"))[:300]),
        ("negative_prompt", str(_wert(w, "negative_prompt"))[:300]),
        ("mode", str(_wert(w, "mode")) if _wert(w, "mode") in MODI else "txt2img"),
        ("steps", _begrenzt(_wert(w, "steps"), 1, 150, "20")),
        ("cfg", _komma(_wert(w, "cfg"), 1, 30, "7")),
        ("seed", seed),
        ("size", "%sx%s" % (breite, hoehe)),
        ("scheduler", str(_wert(w, "scheduler")) if _wert(w, "scheduler") in SAMPLER else "dpm"),
        ("aspect_ratio", str(_wert(w, "aspect_ratio")) if _wert(w, "aspect_ratio") in SEITEN else "1:1"),
        ("denoise_strength", _komma(_wert(w, "denoise_strength"), 0, 1, "0.6")),
        ("show_diffusion_process", "true" if _wahr(_wert(w, "show_diffusion_process")) else "false"),
        ("show_diffusion_stride", _zahl(_wert(w, "show_diffusion_stride"), "2")),
        ("output_format", str(_wert(w, "output_format")) if _wert(w, "output_format") in FORMATE else "png"),
        ("batch_count", _zahl(_wert(w, "batch_count"), "1")),
        ("ultrafix_steps", _zahl(_wert(w, "ultrafix_steps"), "10")),
        ("ultrafix_denoise_steps", _zahl(_wert(w, "ultrafix_denoise_steps"), "4")),
        ("ultrafix_quality_denoise", "true" if _wahr(_wert(w, "ultrafix_quality_denoise")) else "false"),
    ]
    if _wahr(_wert(w, "lowram")):
        zeilen.append(("lowram", "true"))
    if _wahr(_wert(w, "seq_dit")):
        zeilen.append(("seq_dit", "true"))
    patch = str(_wert(w, "patch") or "").strip()[:300]
    if patch:
        zeilen.append(("patch", patch))
    return "".join("%s=%s\n" % (k, v) for k, v in zeilen)


def lesen(text):
    """Block aus der Zwischenablage -> Einstellungswerte (nur bekannte, gepruefte Felder)."""
    roh = str(text or "")
    if len(roh) > 20000:
        roh = roh[:20000]
    gefunden = {}
    for zeile in roh.splitlines():
        schluessel, trenner, wert = zeile.partition("=")
        if not trenner:
            continue
        key = schluessel.strip().lower()
        wert = wert.strip()
        if key and key not in gefunden:
            gefunden[key] = wert
    if not gefunden:
        return {}
    ergebnis = {}
    zuordnung = {"prompt": "magicwx_prompt", "negative_prompt": "magicwx_negativ", "mode": "magicwx_modus",
                 "steps": "magicwx_schritte", "cfg": "magicwx_cfg", "seed": "magicwx_seed",
                 "scheduler": "magicwx_sampler", "aspect_ratio": "magicwx_aspect",
                 "denoise_strength": "magicwx_denoise", "show_diffusion_stride": "magicwx_stride",
                 "batch_count": "magicwx_batch", "ultrafix_steps": "magicwx_ultrafix_steps",
                 "ultrafix_denoise_steps": "magicwx_ultrafix_denoise", "patch": "magicwx_patch"}
    for key, ziel in zuordnung.items():
        if key not in gefunden:
            continue
        wert = gefunden[key]
        if key == "mode" and wert not in MODI:
            continue
        if key == "scheduler" and wert not in SAMPLER:
            continue
        if key == "aspect_ratio" and wert not in SEITEN:
            continue
        if key == "show_diffusion_stride":
            wert = _begrenzt(wert, 1, 20, "2")
        elif key == "batch_count":
            wert = _begrenzt(wert, 1, 10, "1")
        elif key == "steps":
            wert = _begrenzt(wert, 1, 150, "20")
        elif key == "ultrafix_steps":
            wert = _begrenzt(wert, 1, 150, "10")
        elif key == "ultrafix_denoise_steps":
            wert = _begrenzt(wert, 1, 150, "4")
        elif key == "cfg":
            wert = _komma(wert, 1, 30, "7")
        elif key == "seed":
            wert = _begrenzt(wert, -1, 2 ** 32 - 1, "-1")
        elif key == "denoise_strength":
            wert = _komma(wert, 0, 1, "0.6")
        ergebnis[ziel] = wert[:300]
    if "size" in gefunden:
        teile = gefunden["size"].lower().split("x")
        if len(teile) == 2:
            breite = _begrenzt(teile[0], 64, 2048, "512")
            hoehe = _begrenzt(teile[1], 64, 2048, "512")
            if breite and hoehe:
                ergebnis["magicwx_breite"], ergebnis["magicwx_hoehe"] = breite, hoehe
    if "output_format" in gefunden and gefunden["output_format"] in FORMATE:
        ergebnis["magicwx_format"] = gefunden["output_format"]
    if "show_diffusion_process" in gefunden:
        ergebnis["magicwx_vorschau"] = _wahr(gefunden["show_diffusion_process"])
    if "ultrafix_quality_denoise" in gefunden:
        ergebnis["magicwx_ultrafix_qualitaet"] = _wahr(gefunden["ultrafix_quality_denoise"])
    if "lowram" in gefunden:
        ergebnis["magicwx_lowram"] = _wahr(gefunden["lowram"])
    if "seq_dit" in gefunden:
        ergebnis["magicwx_seqdit"] = _wahr(gefunden["seq_dit"])
    return ergebnis


def zustand(werte=None):
    """Was die Oberflaeche und die Route ueber MagicWX wissen muessen."""
    return {"name": NAME, "repo": REPO, "stand": STAND, "lizenz": LIZENZ, "paket": PAKET,
            "apk": APK, "apk_version": APK_VERSION,
            "server": SERVER, "modelle": MODELLE, "modi": list(MODI), "sampler": list(SAMPLER),
            "formate": list(FORMATE), "seiten": list(SEITEN), "felder": list(FELDER),
            "block": block(werte or {}), "aktiv": bool((werte or {}).get("magicwx_an"))}
