"""Sprungmarken im Player: Intro und Abspann (Outro) überspringen – wie SponsorBlock, aber für Filme und Serien.

Je Profil und je Titel merkt sich H0rSt, wo das Intro endet und wo der Abspann anfängt. Für Serien gilt die Marke dem
ganzen Titel (nicht der einzelnen Folge): einmal am Intro „Ende hier“ getippt, überspringt H0rSt es in jeder Folge. Der
Player blendet dann „⏭ Intro überspringen“ bzw. „⏭ Abspann“ ein und springt auf Wunsch von selbst (auto).

Nutzerdaten "marken": {"<profil-id oder ''>": {"<ref>": {"intro": [start, ende], "outro": anfang, "auto": bool,
                                                          "erkannt": {"intro": [...], "outro": ..., "konfidenz":
                                                          "sicher"|"unsicher", "quelle": "ton"|"ton+bild"|"bild"|
                                                          "introdb"|"aniskip"}}}}
  ref ist die IMDb-ID des Titels (tt…); bei Serien die Serien-ID ohne :staffel:folge, damit alle Folgen sie teilen.

"erkannt" ist ein automatischer Vorschlag der Markenerkennung (markenerkennung.py), kein aktiver Wert - er
wird nie von selbst zu "intro"/"outro"/"auto", solange der Nutzer ihn nicht per "vorschlag_uebernehmen"
bestaetigt. Der Hintergrund-Job erkennt serienweit, nicht je Profil, und schreibt deshalb immer in den
profillosen Bucket ("" statt profil_id); lesen() laedt ihn dort nach, wenn das Profil selbst noch keinen hat.
"""

import re

SCHLUESSEL = "marken"
MAX_REFS = 2000
MAX_ZEIT = 48 * 3600  # Sekunden; großzügige Obergrenze gegen Unsinn
_REF = re.compile(r"^[A-Za-z0-9_.:+@/%-]{1,120}$")


class MarkenFehler(ValueError):
    pass


def ref_grund(ref):
    """Serienweite Marke: tt123:1:2 -> tt123 (alle Folgen teilen Intro/Abspann); sonst unverändert."""
    ref = str(ref or "").strip()
    teile = ref.split(":")
    if len(teile) >= 3 and teile[-1].isdigit() and teile[-2].isdigit():
        ref = ":".join(teile[:-2])
    if not _REF.match(ref):
        raise MarkenFehler("Ungültige Titel-Kennung")
    return ref


def _zeit(wert):
    try:
        z = float(wert)
    except (TypeError, ValueError):
        raise MarkenFehler("Zeit muss eine Zahl sein (Sekunden)")
    if z < 0 or z > MAX_ZEIT or z != z:  # z != z faengt NaN
        raise MarkenFehler("Zeit außerhalb des erlaubten Bereichs")
    return round(z, 2)


def _marke(roh):
    if not isinstance(roh, dict):
        return None
    e = {}
    intro = roh.get("intro")
    if isinstance(intro, (list, tuple)) and len(intro) == 2:
        try:
            a, b = _zeit(intro[0]), _zeit(intro[1])
        except MarkenFehler:
            a = b = None
        if a is not None and b is not None and b > a:
            e["intro"] = [a, b]
    if roh.get("outro") is not None:
        try:
            e["outro"] = _zeit(roh["outro"])
        except MarkenFehler:
            pass
    if roh.get("auto") is True:
        e["auto"] = True
    erkannt = _erkannt(roh.get("erkannt"))
    if erkannt:
        e["erkannt"] = erkannt
    segmente = _segmente(roh.get("segmente"))
    if segmente:
        e["segmente"] = segmente
    return e or None


def _segmente(roh):
    segmente = []
    for teil in roh or []:
        if not isinstance(teil, dict) or teil.get("art") not in ("intro", "recap", "outro", "credits", "preview"):
            continue
        try:
            start = _zeit(teil.get("start"))
            ende = _zeit(teil["ende"]) if teil.get("ende") is not None else None
        except MarkenFehler:
            continue
        if ende is not None and ende <= start:
            continue
        segmente.append({"art": teil["art"], "start": start, **({"ende": ende} if ende is not None else {})})
    return segmente[:8]


def _erkannt(roh):
    """Sanitisiert einen automatischen Vorschlag - gleiche Validierung wie _marke(), aber zusaetzlich
    Konfidenz/Quelle. None, wenn nichts Brauchbares uebrig bleibt."""
    if not isinstance(roh, dict):
        return None
    e = {}
    intro = roh.get("intro")
    if isinstance(intro, (list, tuple)) and len(intro) == 2:
        try:
            a, b = _zeit(intro[0]), _zeit(intro[1])
        except MarkenFehler:
            a = b = None
        if a is not None and b is not None and b > a:
            e["intro"] = [a, b]
    if roh.get("outro") is not None:
        try:
            e["outro"] = _zeit(roh["outro"])
        except MarkenFehler:
            pass
    if roh.get("konfidenz") in ("sicher", "unsicher"):
        e["konfidenz"] = roh["konfidenz"]
    if roh.get("quelle") in ("ton", "ton+bild", "bild", "introdb", "aniskip", "theintrodb"):
        e["quelle"] = roh["quelle"]
    segmente = _segmente(roh.get("segmente"))
    if segmente:
        e["segmente"] = segmente
    return e or None


def _alle(daten):
    alle = daten.get(SCHLUESSEL)
    return alle if isinstance(alle, dict) else {}


def pruefe(roh):
    roh = roh if isinstance(roh, dict) else {}
    ergebnis = {}
    for ref, m in list(roh.items())[:MAX_REFS]:
        try:
            schluessel = ref_grund(ref)
        except MarkenFehler:
            continue
        marke = _marke(m)
        if marke:
            ergebnis[schluessel] = marke
    return ergebnis


def _mit_geteiltem_vorschlag(marke, schluessel, geteilt):
    if "erkannt" not in marke and schluessel in geteilt and "erkannt" in geteilt[schluessel]:
        return dict(marke, erkannt=geteilt[schluessel]["erkannt"])
    return marke


def lesen(daten, profil_id, ref=None):
    """Alle Marken des Profils, oder (mit ref) die eine Marke zu diesem Titel ({} wenn keine).

    Fehlt bei der Einzelabfrage (mit ref) ein eigenes "erkannt", wird es nur zum Lesen (nie dauerhaft
    geschrieben) aus dem profillosen Bucket nachgeladen - der Erkennungs-Hintergrundjob erkennt serienweit,
    nicht je Profil, und schreibt deshalb immer dorthin (siehe Moduldocstring). Die Gesamtliste (ohne ref)
    bleibt bewusst unvermischt - sie zeigt nur Titel, mit denen das Profil selbst schon zu tun hatte."""
    eigen = pruefe(_alle(daten).get(profil_id or ""))
    if ref is None:
        return eigen
    geteilt = pruefe(_alle(daten).get("")) if profil_id else {}
    try:
        schluessel = ref_grund(ref)
    except MarkenFehler:
        return {}
    return _mit_geteiltem_vorschlag(eigen.get(schluessel, {}), schluessel, geteilt)


def aendern(daten, profil_id, wunsch):
    """Eine Änderung: {ref, aktion: intro|intro_ende|outro|auto|loeschen, wert/zeit/an}. Gibt die neue Marke zurück."""
    if not isinstance(wunsch, dict):
        raise MarkenFehler("JSON-Objekt erwartet")
    schluessel = ref_grund(wunsch.get("ref"))
    alle = dict(_alle(daten))
    eigen = dict(pruefe(alle.get(profil_id or "")))
    marke = dict(eigen.get(schluessel) or {})
    aktion = wunsch.get("aktion")
    if aktion == "intro":  # ganzes Intro setzen {anfang, ende}
        a, b = _zeit(wunsch.get("anfang", 0)), _zeit(wunsch.get("ende"))
        if b <= a:
            raise MarkenFehler("Das Intro-Ende muss nach dem Anfang liegen")
        marke["intro"] = [a, b]
    elif aktion == "intro_ende":  # bequemster Fall: nur „Intro endet hier"; Anfang 0 (oder bisheriger)
        ende = _zeit(wunsch.get("zeit"))
        anfang = marke.get("intro", [0])[0] if marke.get("intro") and marke["intro"][0] < ende else 0
        marke["intro"] = [anfang, ende]
    elif aktion == "outro":
        marke["outro"] = _zeit(wunsch.get("zeit"))
    elif aktion == "auto":
        if wunsch.get("an") is True:
            marke["auto"] = True
        else:
            marke.pop("auto", None)
    elif aktion == "intro_weg":
        marke.pop("intro", None)
    elif aktion == "outro_weg":
        marke.pop("outro", None)
    elif aktion == "loeschen":
        marke = {}
    elif aktion == "vorschlag":  # nur vom Hintergrund-Job gesetzt, HTTP lehnt das explizit ab (oberflaeche_sehen.py)
        erkannt = _erkannt(wunsch)
        if erkannt:
            marke["erkannt"] = erkannt
    elif aktion == "vorschlag_uebernehmen":  # Nutzer bestaetigt einen Vorschlag - nie automatisch
        vorschlag = marke.get("erkannt") or {}
        if vorschlag.get("intro"):
            marke["intro"] = vorschlag["intro"]
        if vorschlag.get("outro") is not None:
            marke["outro"] = vorschlag["outro"]
        if vorschlag.get("segmente"):
            marke["segmente"] = vorschlag["segmente"]
        if wunsch.get("auto") is True:
            marke["auto"] = True
        marke.pop("erkannt", None)
    elif aktion == "vorschlag_ablehnen":
        marke.pop("erkannt", None)
    else:
        raise MarkenFehler("Unbekannte Aktion")
    marke = _marke(marke) or {}
    if marke:
        eigen[schluessel] = marke
    else:
        eigen.pop(schluessel, None)
    if len(eigen) > MAX_REFS:
        raise MarkenFehler("Zu viele gemerkte Titel")
    alle[profil_id or ""] = eigen
    daten[SCHLUESSEL] = alle
    return marke
