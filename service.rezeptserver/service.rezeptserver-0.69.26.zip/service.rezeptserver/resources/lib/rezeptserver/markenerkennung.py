"""Automatische Intro/Abspann-Erkennung: ffmpeg berechnet Huellkurve/Stille/Schwarzbild, H0rSt vergleicht
und schlaegt eine Marke vor - nie automatisch uebernommen, der Vorschlag muss in der Oberflaeche bestaetigt
werden (siehe marken.py). Laeuft dort, wo H0rSt wirklich Dateien besitzt (XDCC-Downloads, YouTube-Download/
REC); bei reinen Proxy-/Weiterleitungs-Quellen (Stremio/mHub-Addons, Debrid, Usenet-Streaming) nur nach
einem bewusst angestossenen, temporaeren Download zur Analyse (siehe markenerkennung_download.py).
"""

from .markenerkennung_download import herunterladen
from .markenerkennung_grund import *
from .markenerkennung_lauf import MarkenErkennung, serie_aus_namen
from .markenerkennung_ton import analysieren, dauer, huellkurve, schwarzbilder, stille, vergleichen
