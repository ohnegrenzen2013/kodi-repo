"""Opt-in-Download fuer die Markenerkennung: eine bereits aufgeloeste Stream-Adresse (dasselbe "ziel"-
Tupel wie oberflaeche_grund.weiterreichen()) wird - anders als bei normaler Wiedergabe - bis zu einer
Obergrenze in eine lokale Datei geschrieben, statt nur durchgereicht zu werden. Fuer Quellen, die sonst
nie eigene Bytes bekommen (Stremio/mHub-Addons, Debrid, Usenet-Streaming) - XDCC/YouTube haben das schon
(siehe markenerkennung_lauf.py). Gleiche Domain-/SSRF-Schranken wie bei normaler Wiedergabe, weil dasselbe
"ziel"-Tupel aus derselben Aufloesung (Stremio-Addon/Debrid/Usenet) stammt, nie aus einer rohen Client-URL."""

import urllib.error
import urllib.request
from urllib.parse import urljoin

from . import heimspeicher
from .markenerkennung_grund import MarkenErkennungFehler, time
from .netz import _OEFFNER, USER_AGENT, NichtOeffentlich, domain_erlaubt, pin_oeffner

BLOCK = 256 * 1024  # dieselbe Blockgroesse wie weiterreichen()
MAX_WEITERLEITUNGEN = 6  # dasselbe Limit wie weiterreichen()


def herunterladen(ziel, pfad, max_bytes, zeitlimit_gesamt):
    """Schreibt bis zu max_bytes von ziel (url, header, netz[, eigenes]) nach pfad, mit Range wo moeglich.
    Folgt Weiterleitungen wie weiterreichen(). Wirft MarkenErkennungFehler bei FTP-Zielen, Netzfehlern,
    zu vielen Weiterleitungen oder Zeitueberschreitung. Gibt die Anzahl geschriebener Bytes zurueck."""
    url, header, netz = ziel[:3]
    eigenes = len(ziel) > 3 and ziel[3]
    oeffentlich = len(ziel) > 4 and ziel[4]
    if url.startswith(("ftp://", "ftps://")):
        raise MarkenErkennungFehler("FTP wird für die Markenerkennung nicht unterstützt")
    oeffner = heimspeicher.oeffner(True) if eigenes else _OEFFNER
    kopf = {"User-Agent": USER_AGENT, "Range": "bytes=0-%d" % (max(max_bytes, 1) - 1)}
    kopf.update(header)
    start = time.time()
    for _ in range(MAX_WEITERLEITUNGEN):
        hop = oeffner
        if oeffentlich:
            try:
                hop = pin_oeffner(url)
            except NichtOeffentlich as fehler:
                raise MarkenErkennungFehler(str(fehler))
        if not domain_erlaubt(url, netz):
            kopf = {k: v for k, v in kopf.items() if k in ("User-Agent", "Range")}
        try:
            antwort = hop.open(urllib.request.Request(url, headers=kopf), timeout=20)
        except urllib.error.HTTPError as fehler:
            ziel_url = fehler.headers.get("Location") if fehler.headers else None
            status = fehler.code
            if fehler.fp is not None:  # Python 3.8: HTTPError(fp=None).close() wirft KeyError('file')
                fehler.close()
            if status in (301, 302, 303, 307, 308) and ziel_url:
                url = urljoin(url, ziel_url)
                continue
            raise MarkenErkennungFehler("HTTP %d bei %s" % (status, url))
        except (urllib.error.URLError, OSError) as fehler:
            raise MarkenErkennungFehler("Abruf fehlgeschlagen: %s" % fehler)
        with antwort, open(pfad, "wb") as f:
            geschrieben = 0
            while geschrieben < max_bytes:
                if time.time() - start > zeitlimit_gesamt:
                    raise MarkenErkennungFehler("Zeitlimit beim Herunterladen überschritten")
                block = antwort.read(min(BLOCK, max_bytes - geschrieben))
                if not block:
                    break
                f.write(block)
                geschrieben += len(block)
        return geschrieben
    raise MarkenErkennungFehler("Zu viele Weiterleitungen")
