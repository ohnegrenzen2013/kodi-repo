"""Grundlage der Markenerkennung: Importe, Logger, Konstanten und der Fehler.
Alles hier wird samt Importen wieder exportiert (rezeptserver.markenerkennung.*)."""


import logging
import os
import re
import shutil
import subprocess
import tempfile
import threading
import time

from . import ereignisse

log = logging.getLogger("rezeptserver")

SCHLUESSEL = "markenerkennung"
ORDNER = "markenerkennung"
MAX_GLEICHZEITIG = 1     # ffmpeg-Dekodierung ist CPU-gebunden, Parallelitaet bringt hier nichts
INTRO_FENSTER = 210      # Sekunden ab Start, in denen ein Intro gesucht wird
OUTRO_FENSTER = 360      # Sekunden vor Ende, in denen ein Abspann gesucht wird
BUCKET = 0.5             # Sekunden pro Huellkurven-Wert
ZEITLIMIT_FFMPEG = 60    # je ffmpeg-/ffprobe-Aufruf (Rechenzeit, nicht Medienzeit)


class MarkenErkennungFehler(ValueError):
    pass


def ffmpeg():
    return shutil.which("ffmpeg")


def ffprobe():
    return shutil.which("ffprobe")
