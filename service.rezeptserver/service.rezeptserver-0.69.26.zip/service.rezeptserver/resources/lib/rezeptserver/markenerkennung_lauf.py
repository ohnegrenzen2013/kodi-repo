"""Hintergrund-Job der Markenerkennung: ein Thread je Auftrag (Muster xdcc_client.Xdcc/
youtube_speichern.Speichern), schreibt das Ergebnis direkt per Verwaltung.bearbeiten() in marken.py -
kein Umweg ueber die eigene HTTP-API, gleiches Prinzip wie aktualisierung_hintergrund.py.

serie_aus_namen() loest aus einem rohen Dateinamen (z. B. ein XDCC-Angebot "Show.Name.S01E05.1080p.mkv")
eine volle marken.py-ref auf ("tt1234567:1:5"), ueber die schon bestehende Titel-Erkennung/Cinemeta-
Aufloesung aus entdecken.py (titel_bereinigen()/Entdecken.aufloesen(), gebaut fuer "Eigene Quellen" -
hier wiederverwendet statt neu erfunden). Nur fuer XDCC gedacht: YouTube-Videos haben keinen Serien-
/Episoden-Bezug in diesem Projekt, bleiben deshalb aussen vor (siehe WISSEN.md)."""

from . import marken
from . import markenerkennung_download
from .entdecken import titel_bereinigen
from .markenerkennung_grund import (
    MAX_GLEICHZEITIG,
    ORDNER,
    MarkenErkennungFehler,
    log,
    os,
    re,
    threading,
)
from .markenerkennung_ton import analysieren

SCHLUESSEL_REFERENZ = "markenerkennung"
MAX_REFERENZEN = 2000
MAX_AUFTRAEGE = 30
MAX_DOWNLOAD_MB_STANDARD = 500
ZEITLIMIT_DOWNLOAD = 180  # Sekunden fuer den gesamten Download (nicht je Lesevorgang)

_SXXEYY = re.compile(r"[Ss](\d{1,2})[Ee](\d{1,3})")


def serie_aus_namen(name, entdecken):
    """name -> volle ref ("tt1234567:1:5") per Staffel/Folge-Muster + Cinemeta-Abgleich, oder None
    (kein Muster im Namen, oder Cinemeta kennt den Titel nicht/nicht eindeutig genug).

    Alles ab dem SxxEyy-Muster (Aufloesung, Codec, Release-Gruppe) wird verworfen, nur der Teil davor
    geht in titel_bereinigen() - das ist fuer Fliesstext von Webseiten gebaut, nicht fuer punktgetrennte
    Release-Dateinamen, daher die Punkte/Unterstriche vorher durch Leerzeichen ersetzt."""
    name = str(name or "")
    treffer = _SXXEYY.search(name)
    if not treffer:
        return None
    staffel, folge = int(treffer.group(1)), int(treffer.group(2))
    roh = name[:treffer.start()].replace(".", " ").replace("_", " ")
    titel, jahr, _ = titel_bereinigen(roh)
    if not titel:
        return None
    try:
        gefunden = entdecken.aufloesen(titel, jahr, typ="series")
    except Exception as fehler:
        log.warning("Markenerkennung: Titel-Abgleich fuer %r fehlgeschlagen: %s", name, fehler)
        return None
    if not gefunden or not gefunden.get("sicher") or not gefunden.get("id"):
        return None
    return "%s:%d:%d" % (gefunden["id"], staffel, folge)


def _referenz_lesen(daten, ref):
    alle = daten.get(SCHLUESSEL_REFERENZ)
    eintrag = alle.get(ref) if isinstance(alle, dict) else None
    return eintrag if isinstance(eintrag, dict) else None


def _referenz_aus_ergebnis(ergebnis):
    """Baut aus einem Analyse-Ergebnis die Referenz fuer die naechste Folge (Huellkurven + Versatz der
    jetzt gefundenen Grenzen). {} wenn nichts davon brauchbar ist - dann wird nichts gespeichert."""
    eintrag = {}
    if ergebnis.get("intro_huellkurve") and ergebnis.get("intro"):
        eintrag["intro_huellkurve"] = ergebnis["intro_huellkurve"]
        eintrag["intro_versatz"] = ergebnis["intro"][1]
    if ergebnis.get("outro_huellkurve") and ergebnis.get("outro") is not None:
        eintrag["outro_huellkurve"] = ergebnis["outro_huellkurve"]
        eintrag["outro_versatz"] = round(ergebnis["outro"] - ergebnis.get("outro_fenster_start", 0), 2)
    return eintrag


class MarkenErkennung:
    """verwaltung: rezeptserver.dienst.Verwaltung (fuer marken.py/Referenz-Speicherung)."""

    def __init__(self, verwaltung, datenordner="."):
        self.verwaltung = verwaltung
        self.tmp_ordner = os.path.join(datenordner or ".", ORDNER, "tmp")
        self.auftraege = {}
        self._nummer = 0
        self._sperre = threading.Lock()

    def erlaubt(self, daten=None):
        if daten is None:
            daten = self.verwaltung.daten() if self.verwaltung else {}
        return bool(daten.get("markenerkennung_an"))

    def erlaubt_download(self, daten=None):
        if daten is None:
            daten = self.verwaltung.daten() if self.verwaltung else {}
        return self.erlaubt(daten) and bool(daten.get("markenerkennung_download_an"))

    def starten(self, ref, pfad=None, ziel=None, max_bytes=None, zeitlimit_download=ZEITLIMIT_DOWNLOAD):
        """pfad: Datei liegt schon lokal vor (XDCC/YouTube). ziel: muss zuerst heruntergeladen werden
        (markenerkennung_download.herunterladen(), fuer Stremio/Debrid/Usenet-Streaming) - genau eines
        von beiden angeben. Die Download-Datei wird nach der Analyse immer geloescht (Erfolg oder
        Fehler). Wirft MarkenErkennungFehler, wenn schon eine Erkennung laeuft (MAX_GLEICHZEITIG), ref
        ungueltig ist, oder weder pfad noch ziel angegeben wurde."""
        try:
            schluessel = marken.ref_grund(ref)
        except marken.MarkenFehler as fehler:
            raise MarkenErkennungFehler(str(fehler))
        if pfad is None and ziel is None:
            raise MarkenErkennungFehler("Weder Datei noch Download-Ziel angegeben")
        with self._sperre:
            if sum(1 for a in self.auftraege.values() if a["laeuft"]) >= MAX_GLEICHZEITIG:
                raise MarkenErkennungFehler("Es läuft schon eine Erkennung, bitte warten")
            self._nummer += 1
            a = {"id": str(self._nummer), "ref": schluessel, "status": "läuft", "fehler": "", "laeuft": True}
            self.auftraege[a["id"]] = a
            for alt in sorted((x for x in self.auftraege.values() if not x["laeuft"]), key=lambda x: int(x["id"]))[:-MAX_AUFTRAEGE]:
                del self.auftraege[alt["id"]]
        threading.Thread(target=self._lauf, args=(a, pfad, ziel, max_bytes, zeitlimit_download),
                          name="markenerkennung-" + a["id"], daemon=True).start()
        return dict(a)

    def _lauf(self, a, pfad, ziel, max_bytes, zeitlimit_download):
        tmp = None
        try:
            if ziel is not None:
                os.makedirs(self.tmp_ordner, exist_ok=True)
                tmp = os.path.join(self.tmp_ordner, a["id"] + ".tmp")
                markenerkennung_download.herunterladen(
                    ziel, tmp, max_bytes or MAX_DOWNLOAD_MB_STANDARD * 1024 * 1024, zeitlimit_download)
                datei = tmp
            else:
                datei = pfad
            daten = self.verwaltung.daten() if self.verwaltung else {}
            referenz = _referenz_lesen(daten, a["ref"])
            ergebnis = analysieren(datei, referenz)
            if ergebnis and (ergebnis.get("intro") or ergebnis.get("outro") is not None):
                vorschlag = {k: ergebnis[k] for k in ("intro", "outro", "konfidenz", "quelle") if k in ergebnis}
                if self.verwaltung:
                    self.verwaltung.bearbeiten(
                        lambda d: marken.aendern(d, "", dict(vorschlag, ref=a["ref"], aktion="vorschlag")))
            if ergebnis:
                self._referenz_speichern(a["ref"], ergebnis)
            a["status"] = "fertig"
        except Exception as fehler:  # noqa: BLE001 - ein Analysefehler darf den Hintergrund-Thread nie reissen
            a.update(status="fehler", fehler=str(fehler)[:300])
            log.warning("Markenerkennung %s: %s", a["ref"], fehler)
        finally:
            if tmp:
                try:
                    os.remove(tmp)
                except OSError:
                    pass
            a["laeuft"] = False

    def _referenz_speichern(self, ref, ergebnis):
        eintrag = _referenz_aus_ergebnis(ergebnis)
        if not eintrag or not self.verwaltung:
            return

        def tun(daten):
            alle = daten.get(SCHLUESSEL_REFERENZ)
            alle = dict(alle) if isinstance(alle, dict) else {}
            if len(alle) >= MAX_REFERENZEN and ref not in alle:
                alle.pop(next(iter(alle)), None)  # einfachste Verdraengung: aeltester Eintrag zuerst raus
            alle[ref] = eintrag
            daten[SCHLUESSEL_REFERENZ] = alle
            return eintrag

        self.verwaltung.bearbeiten(tun)

    def zustand(self):
        with self._sperre:
            return {"auftraege": sorted((dict(a) for a in self.auftraege.values()),
                                         key=lambda a: -int(a["id"]))[:MAX_AUFTRAEGE]}
