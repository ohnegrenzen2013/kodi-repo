"""Erkennungs-Engine: ffmpeg berechnet die Rohdaten (Lautstaerke-Huellkurve, Stille, Schwarzbild),
dieses Modul parst nur die Textausgabe und vergleicht - keine neue pip-Abhaengigkeit (kein numpy/
librosa/audioop), ffmpeg ist ohnehin schon eine Systemabhaengigkeit dieses Projekts.

Die Huellkurve (astats, 0,5-Sekunden-Buckets der RMS-Lautstaerke) ist das eigentliche, inhaltsbezogene
Signal: zwei Folgen derselben Serie mit demselben Vorspann ergeben vergleichbare Kurven (vergleichen()).
silencedetect/blackdetect liefern dagegen echte Zeitgrenzen, aber kein Wiedererkennungs-Signal - sie
bestaetigen oder ersetzen (ohne Referenz) den Korrelations-Treffer, siehe _abschnitt().

Jede Funktion hier gibt bei Problemen (ffmpeg fehlt, Abbruch, kein brauchbares Ergebnis) None/[] zurueck
statt zu werfen - ein Analysefehler darf den Hintergrund-Job (markenerkennung.py) nie reissen."""

from .markenerkennung_grund import (
    BUCKET,
    INTRO_FENSTER,
    OUTRO_FENSTER,
    ZEITLIMIT_FFMPEG,
    ffmpeg,
    ffprobe,
    log,
    os,
    re,
    subprocess,
    tempfile,
)

MIN_DAUER = 30           # Sekunden; kuerzere Titel werden nicht analysiert (zu wenig Material)
KORRELATION_SCHWELLE = 6.0    # dB mittlere Abweichung, ab der eine Korrelation nicht mehr als Treffer zaehlt
BESTAETIGUNG_TOLERANZ = 2.0   # Sekunden: Korrelations-Grenze nahe einer Stille/Schwarzbild-Grenze -> "sicher"

_RMS = re.compile(r"RMS_level=(-?[\d.]+|-?inf)")
_STILLE = re.compile(r"silence_start:\s*([\d.]+).*?silence_end:\s*([\d.]+)", re.S)
_SCHWARZ = re.compile(r"black_start:([\d.]+)\s+black_end:([\d.]+)")


def dauer(quelle, zeitlimit=20):
    """Mediendauer in Sekunden (float) per ffprobe, oder None bei Fehler/fehlendem ffprobe."""
    pfad = ffprobe()
    if not pfad:
        return None
    befehl = [pfad, "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", quelle]
    try:
        ergebnis = subprocess.run(befehl, capture_output=True, text=True, timeout=zeitlimit)
    except subprocess.TimeoutExpired:
        return None
    except OSError:
        return None
    if ergebnis.returncode != 0:
        return None
    try:
        return float((ergebnis.stdout or "").strip())
    except ValueError:
        return None


def huellkurve(quelle, start, dauer_s, zeitlimit=ZEITLIMIT_FFMPEG):
    """Liste von RMS-Lautstaerke-Werten (dB, gegen -90 geklippt), ein Wert je BUCKET Sekunden, im
    Fenster [start, start+dauer_s). None bei Fehler oder leerem Ergebnis."""
    pfad = ffmpeg()
    if not pfad or dauer_s <= 0:
        return None
    sidecar = tempfile.mktemp(prefix="markenerkennung_", suffix=".txt")
    samples = max(1, int(8000 * BUCKET))
    filterkette = ("aresample=8000,asetnsamples=n=%d:p=0,astats=metadata=1:reset=1,"
                   "ametadata=print:key=lavfi.astats.Overall.RMS_level:file=%s") % (samples, sidecar)
    befehl = [pfad, "-nostdin", "-loglevel", "error", "-ss", str(max(0, start)), "-t", str(dauer_s),
              "-i", quelle, "-map", "0:a:0?", "-ac", "1", "-af", filterkette, "-f", "null", "-"]
    try:
        try:
            ergebnis = subprocess.run(befehl, capture_output=True, text=True, timeout=zeitlimit)
        except subprocess.TimeoutExpired:
            return None
        except OSError:
            return None
        if ergebnis.returncode != 0:
            log.warning("Markenerkennung: ffmpeg-Fehler bei Huellkurve: %s", (ergebnis.stderr or "")[-300:])
            return None
        try:
            with open(sidecar, "r", encoding="utf-8", errors="replace") as f:
                text = f.read()
        except OSError:
            return None
        werte = []
        for m in _RMS.finditer(text):
            roh = m.group(1)
            werte.append(-90.0 if roh in ("-inf", "inf") else max(round(float(roh), 2), -90.0))
        return werte or None
    finally:
        try:
            os.remove(sidecar)
        except OSError:
            pass


def vergleichen(neu, referenz, max_verschiebung=40, min_ueberlappung=20):
    """Beste Verschiebung (in BUCKET-Schritten) von `neu` gegen `referenz`.
    Gibt (verschiebung, mittlere_abweichung_db, ueberlappung) zurueck, oder None, wenn keine
    Verschiebung eine Ueberlappung von mindestens min_ueberlappung Werten erreicht."""
    if not neu or not referenz:
        return None
    bester = None
    for s in range(-max_verschiebung, max_verschiebung + 1):
        a_off, b_off = max(0, -s), max(0, s)
        paare = list(zip(neu[a_off:], referenz[b_off:]))
        if len(paare) < min_ueberlappung:
            continue
        abweichung = sum(abs(a - b) for a, b in paare) / len(paare)
        if bester is None or abweichung < bester[1]:
            bester = (s, round(abweichung, 2), len(paare))
    return bester


def stille(quelle, start, dauer_s, zeitlimit=ZEITLIMIT_FFMPEG, schwelle_db=-30, mindest_s=0.5):
    """Liste von (start, ende)-Sekunden-Tupeln erkannter Stille im Fenster [start, start+dauer_s).
    Leere Liste bei Fehler oder keinem Treffer - nie eine Ausnahme."""
    pfad = ffmpeg()
    if not pfad or dauer_s <= 0:
        return []
    befehl = [pfad, "-nostdin", "-loglevel", "info", "-ss", str(max(0, start)), "-t", str(dauer_s),
              "-i", quelle, "-af", "silencedetect=n=%ddB:d=%s" % (schwelle_db, mindest_s), "-f", "null", "-"]
    try:
        ergebnis = subprocess.run(befehl, capture_output=True, text=True, timeout=zeitlimit)
    except (subprocess.TimeoutExpired, OSError) as fehler:
        log.warning("Markenerkennung: Stille-Erkennung fehlgeschlagen: %s", fehler)
        return []
    return [(float(a), float(b)) for a, b in _STILLE.findall(ergebnis.stderr or "")]


def schwarzbilder(quelle, start, dauer_s, zeitlimit=ZEITLIMIT_FFMPEG, dauer_min=0.3):
    """Liste von (start, ende)-Sekunden-Tupeln erkannter Schwarzbilder im Fenster. Leere Liste bei
    Fehler/keinem Treffer - nie eine Ausnahme."""
    pfad = ffmpeg()
    if not pfad or dauer_s <= 0:
        return []
    befehl = [pfad, "-nostdin", "-loglevel", "info", "-ss", str(max(0, start)), "-t", str(dauer_s),
              "-i", quelle, "-vf", "blackdetect=d=%s:pic_th=0.98" % dauer_min, "-an", "-f", "null", "-"]
    try:
        ergebnis = subprocess.run(befehl, capture_output=True, text=True, timeout=zeitlimit)
    except (subprocess.TimeoutExpired, OSError) as fehler:
        log.warning("Markenerkennung: Schwarzbild-Erkennung fehlgeschlagen: %s", fehler)
        return []
    return [(float(a), float(b)) for a, b in _SCHWARZ.findall(ergebnis.stderr or "")]


def _grenze_aus_korrelation(huelle, referenz_huelle, referenz_versatz):
    """Schaetzt einen Grenz-Zeitpunkt (Sekunden ab Fensterbeginn) aus dem Vergleich mit einer
    Referenz-Huellkurve + deren bekanntem Versatz (die Zeit der dort schon bestaetigten Grenze,
    gemessen ab demselben Fensterbeginn). None ohne Referenz oder bei schlechter Korrelation."""
    if not referenz_huelle or referenz_versatz is None:
        return None
    treffer = vergleichen(huelle, referenz_huelle)
    if not treffer:
        return None
    verschiebung, abweichung, _ = treffer
    if abweichung > KORRELATION_SCHWELLE:
        return None
    bucket = referenz_versatz / BUCKET + verschiebung
    if bucket < 0:
        return None
    return bucket * BUCKET


def _naechste(grenzen, zeit, toleranz=BESTAETIGUNG_TOLERANZ):
    """Die Stille-/Schwarzbild-Grenze (Start oder Ende) am naechsten zu `zeit`, wenn sie innerhalb
    `toleranz` Sekunden liegt - sonst None."""
    beste = None
    for a, b in grenzen:
        for kandidat in (a, b):
            if beste is None or abs(kandidat - zeit) < abs(beste - zeit):
                beste = kandidat
    return beste if beste is not None and abs(beste - zeit) <= toleranz else None


def _abschnitt(quelle, start, dauer_s, huelle, referenz_huelle, referenz_versatz, bild):
    """Ein Intro- oder Abspann-Kandidat fuer einen Fensterausschnitt.
    Gibt (zeit_relativ_zum_fenster, konfidenz, quelle_art) oder None zurueck."""
    grenze = _grenze_aus_korrelation(huelle, referenz_huelle, referenz_versatz)
    stillen = stille(quelle, start, dauer_s)
    schwarz = schwarzbilder(quelle, start, dauer_s) if bild else []

    if grenze is not None:
        bestaetigt = _naechste(stillen, grenze)
        quelle_art = "ton"
        if bestaetigt is None and bild:
            bestaetigt = _naechste(schwarz, grenze)
            if bestaetigt is not None:
                quelle_art = "bild"
        if bestaetigt is not None:
            return (bestaetigt, "sicher", quelle_art)
        return (grenze, "unsicher", "ton")

    # Keine (brauchbare) Referenz: nur Stille/Schwarzbild als schwaches Einzel-Signal, immer "unsicher" -
    # das Ende der ersten erkannten Stille/des ersten Schwarzbilds im Fenster ist die einfachste brauchbare
    # Naeherung (z. B. der Uebergang vom Vorspann in den ersten Dialog).
    if stillen:
        return (stillen[0][1], "unsicher", "ton")
    if bild and schwarz:
        return (schwarz[0][1], "unsicher", "bild")
    return None


def analysieren(quelle, referenz=None):
    """Analysiert eine lokale Mediendatei (oder jede ffmpeg-lesbare Quelle) auf Intro-Ende und
    Abspann-Anfang.

    referenz (optional, aus einer schon bestaetigten Folge derselben Serie):
        {"intro_huellkurve": [...], "intro_versatz": float, "outro_huellkurve": [...], "outro_versatz": float}
    "versatz" ist die Sekunden-Zeit der dort bekannten Grenze, gemessen ab Beginn des jeweiligen
    Analysefensters (0 fuer Intro, Fensterbeginn fuer Outro).

    Gibt bei jedem Problem None zurueck (nie eine Ausnahme). Sonst ein Vorschlag-Dict mit optionalen
    "intro"/"outro"-Feldern (fehlen, wenn fuer diesen Teil nichts gefunden wurde) plus den neu berechneten
    Huellkurven und "outro_fenster_start" (zur Weiterverwendung als Referenz fuer die naechste Folge -
    das Intro-Fenster beginnt immer bei 0, das Outro-Fenster variiert je nach Gesamtdauer)."""
    referenz = referenz or {}
    gesamt = dauer(quelle)
    if not gesamt or gesamt < MIN_DAUER:
        return None
    intro_dauer = min(INTRO_FENSTER, gesamt / 2)
    outro_dauer = min(OUTRO_FENSTER, gesamt / 2)
    outro_start = gesamt - outro_dauer

    ergebnis = {}
    konfidenzen = []

    intro_huelle = huellkurve(quelle, 0, intro_dauer)
    if intro_huelle:
        ergebnis["intro_huellkurve"] = intro_huelle
        kandidat = _abschnitt(quelle, 0, intro_dauer, intro_huelle,
                               referenz.get("intro_huellkurve"), referenz.get("intro_versatz"), bild=True)
        if kandidat:
            zeit, konfidenz, quelle_art = kandidat
            ergebnis["intro"] = [0, round(zeit, 2)]
            konfidenzen.append((konfidenz, quelle_art))

    outro_huelle = huellkurve(quelle, outro_start, outro_dauer)
    if outro_huelle:
        ergebnis["outro_huellkurve"] = outro_huelle
        ergebnis["outro_fenster_start"] = round(outro_start, 2)  # fuer die naechste Folge: outro_versatz = outro - outro_fenster_start
        kandidat = _abschnitt(quelle, outro_start, outro_dauer, outro_huelle,
                               referenz.get("outro_huellkurve"), referenz.get("outro_versatz"), bild=True)
        if kandidat:
            zeit, konfidenz, quelle_art = kandidat
            ergebnis["outro"] = round(outro_start + zeit, 2)
            konfidenzen.append((konfidenz, quelle_art))

    if konfidenzen:
        # Die schwaechere der beiden Teil-Konfidenzen gewinnt fuers Gesamtergebnis - keine falsche
        # Sicherheit vorspiegeln, wenn nur einer von zwei Teilen bestaetigt wurde.
        ergebnis["konfidenz"] = "sicher" if all(k == "sicher" for k, _ in konfidenzen) else "unsicher"
        arten = {a for _, a in konfidenzen}
        ergebnis["quelle"] = "bild" if arten == {"bild"} else ("ton+bild" if "bild" in arten else "ton")

    return ergebnis or None
