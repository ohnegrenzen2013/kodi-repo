"""Suchmatrix: geprueftes Verzeichnis von Apps mit ihren offiziellen Quellen (App-Store).

Wozu. APKs kursieren auf Filehostern unter Namen wie "zxm9ak.apk" oder "STUBE.BOXlegacy_64.apk".
Woher so eine Datei stammt und ob sie veraendert wurde, sieht man ihr nicht an. Die Matrix stellt dem
die offizielle Herkunft gegenueber: je App eine Zeile, je Quelle eine Spalte, und in der Zelle steht,
ob die App dort zu holen ist. Ein Tipp auf eine Zelle startet die Suche im App-Store in genau dieser
Quelle; ein Tipp auf die Zeile oeffnet das Projekt.

Aufnahmekriterium. Eine App kommt nur hinein, wenn ihre Identitaet geklaert ist: Paketname bekannt
UND offizielle Quelle (Repo oder Herstellerseite) auffindbar. Das ist dieselbe Huerde wie die
belegbare Palette bei UNiQuanteX (WISSEN.md 7) - was man nicht belegen kann, steht nicht drin.
Bewusst NICHT aufgenommen:

  * STUBE.BOX / Stubebox (alle Fassungen) - umbenannte Kodi-Umbauten ohne Quellcode-Angebot,
    verbreitet ueber Filehoster und Foren, Umfeld mit fragwuerdigen Streams. Statt ihrer steht
    Kodi selbst in der Matrix.
  * Dateien ohne erkennbare Identitaet (etwa "zxm9ak.apk") - ohne Paketname und Signatur ist nicht
    zu sagen, was das ist.
  * Apps, deren Zuordnung offen blieb (etwa ein "civit"-Build: Civitai hat keine offizielle
    Android-App, die Play-Store-Eintraege sind von Dritten).

"warnung" steht an Eintraegen, bei denen beim Laden etwas zu beachten ist (Forks mit identischem
Dateinamen, Vorabversionen, heikler Einsatzzweck). "pruefen" sagt, womit sich eine vorhandene Datei
gegen das Original pruefen laesst.

Schnittstelle: GET /api/matrix -> {quellen, gruppen: [{id, name, text, apps: [...]}], hinweis}
"""

# Spalten der Matrix. Die vier ersten sind Quellen des App-Stores (appstore.QUELLEN), "web" ist die
# Herstellerseite bzw. das Repo selbst.
SPALTEN = [("fdroid", "F-Droid"), ("izzy", "IzzyOnDroid"), ("github", "GitHub"),
           ("codeberg", "Codeberg"), ("web", "Projektseite")]

HINWEIS = ("Jede Zeile ist eine App, deren Herkunft geklärt ist. Ein Tipp auf ein Häkchen sucht sie "
           "im App-Store in genau dieser Quelle. Apps ohne nachweisbare Herkunft stehen bewusst "
           "nicht hier – siehe den Hinweis am Ende.")

AUSGESCHLOSSEN = [
    {"name": "STUBE.BOX / Stubebox (alle Fassungen)",
     "grund": "Umbenannte Kodi-Umbauten ohne Quellcode-Angebot, verbreitet über Filehoster. "
              "Herkunft und Änderungen nicht nachvollziehbar. Nimm Kodi selbst."},
    {"name": "Dateien mit Zufallsnamen (z. B. zxm9ak.apk)",
     "grund": "Ohne Paketname und Signatur ist nicht zu sagen, was darin steckt. "
              "Erst mit „aapt dump badging“ und „apksigner verify --print-certs“ prüfen."},
    {"name": "„civit“-Builds",
     "grund": "Civitai hat keine offizielle Android-App; die Einträge im Play Store stammen von Dritten. "
              "Welches Projekt gemeint ist, bleibt offen."},
]


def _app(aid, name, paket, was, nutzen, quellen, repo="", seite="", lizenz="",
         warnung="", pruefen="", suche=""):
    return {"id": aid, "name": name, "paket": paket, "was": was, "nutzen": nutzen,
            "quellen": quellen, "repo": repo, "seite": seite, "lizenz": lizenz,
            "warnung": warnung, "pruefen": pruefen, "suche": suche or name}


GRUPPEN = [
    {"id": "medien", "name": "Medien & Wiedergabe",
     "text": "Abspielen, Mediathek, Fernseher – das Umfeld, in dem H0rSt selbst steht.",
     "apps": [
        _app("kodi", "Kodi", "org.xbmc.kodi",
             "Das Mediacenter, auf dem H0rSts Kodi-Teile aufsetzen (Addons ohne Kodi, Kodi-Skins).",
             "Vorbild und Ziel zugleich: H0rSt läuft als Stremio-Addon in Jacktook und schickt Streams an Kodi.",
             {"fdroid": False, "izzy": False, "github": True, "codeberg": False, "web": True},
             repo="https://github.com/xbmc/xbmc", seite="https://kodi.tv/download/",
             lizenz="GPL-2.0-or-later", suche="kodi",
             warnung="Vorabversionen (Beta, RC) stehen nur auf kodi.tv, nicht im GitHub-Release.",
             pruefen="Prüfsummen und Signatur stehen auf kodi.tv neben dem Download."),
        _app("tvbro", "TV Bro", "com.phlox.tvwebbrowser",
             "Browser für Android-TV, mit Fernbedienung bedienbar.",
             "Zeigt H0rSts Oberfläche auf einer TV-Box, wo kein normaler Browser taugt.",
             {"fdroid": True, "izzy": True, "github": True, "codeberg": False, "web": False},
             repo="https://github.com/truefedex/tv-bro", lizenz="eigene BSD-artige Lizenz",
             suche="tv bro",
             warnung="Die Lizenz erlaubt unveränderte Binärdateien nur aus den offiziellen Releases; "
                     "veränderte Builds dürfen „TV Bro“ nicht im Namen führen."),
     ]},
    {"id": "bilder", "name": "Bilder & Modelle",
     "text": "On-Device-Bilderzeugung und Verschlagwortung – das Umfeld des LocalDream-Reiters.",
     "apps": [
        _app("localdream", "Local Dream", "io.github.xororz.localdream",
             "Stable Diffusion auf dem Gerät, über NPU, GPU oder CPU.",
             "H0rSt hat dafür schon einen Reiter; Local Dream bringt zusätzlich eine eigene Schnittstelle mit.",
             {"fdroid": False, "izzy": False, "github": True, "codeberg": False, "web": False},
             repo="https://github.com/xororz/local-dream", lizenz="CC BY-NC 4.0", suche="local dream",
             warnung="Forks veröffentlichen Dateien mit identischem Namen. Es gibt zwei Varianten: "
                     "mit und ohne NSFW-Filter.",
             pruefen="Signatur-Fingerprint gegen das Release bei xororz/local-dream vergleichen."),
        _app("nightmare", "Nightmare Mobile", "com.abrah.nightmare.api",
             "Node-Graph für Stable Diffusion auf Android, im Geist von ComfyUI; setzt auf Local Dreams NPU-Teil auf.",
             "Vorbild für einen Arbeitsablauf-Editor im LocalDream-Reiter.",
             {"fdroid": False, "izzy": False, "github": True, "codeberg": False, "web": False},
             repo="https://github.com/AbrahamPaulJ/nightmare-mobile", lizenz="CC BY-NC 4.0",
             suche="nightmare mobile",
             warnung="Nicht kommerziell nutzen (CC BY-NC). Ein Fork bietet eine parallel "
                     "installierbare Fassung mit derselben Versionsnummer an."),
     ]},
    {"id": "netz", "name": "Netz & Anonymität",
     "text": "Passt zum Bereich Sicherheit: VPN, Tor, I2P, Proxy.",
     "apps": [
        _app("orbot", "Orbot", "org.torproject.android",
             "Tor als Proxy oder VPN für einzelne Apps.",
             "H0rSts Sicherheits-Bereich kennt Tor bereits; Orbot ist der Weg dorthin auf Android.",
             {"fdroid": True, "izzy": True, "github": True, "codeberg": False, "web": True},
             repo="https://github.com/guardianproject/orbot-android",
             seite="https://orbot.app", lizenz="BSD-3-Clause", suche="orbot",
             warnung="„RC“ im Dateinamen heißt Vorabversion."),
        _app("i2pd", "i2pd", "org.purplei2p.i2pd",
             "I2P-Router in C++, als Dienst mit Status-Ansicht.",
             "Anonymer Transportweg für Quellen; H0rSts Sicherheits-Bereich nennt I2P bereits.",
             {"fdroid": True, "izzy": False, "github": True, "codeberg": False, "web": True},
             repo="https://github.com/PurpleI2P/i2pd-android", seite="https://i2pd.website",
             lizenz="BSD-3-Clause", suche="i2pd",
             warnung="Die F-Droid-Fassung ist von F-Droid gebaut und signiert, nicht vom Projekt."),
     ]},
    {"id": "werkzeug", "name": "Werkzeuge",
     "text": "Dateien, Speicher, Prüfen – Handwerkszeug rund um H0rSt.",
     "apps": [
        _app("sdmaid", "SD Maid SE", "eu.darken.sdmse",
             "Speicher aufräumen: Reste, Doppelte, große Dateien, App-Caches.",
             "Vorbild für Aufräumfunktionen; praktisch neben H0rSts Downloads und Zwischenspeichern.",
             {"fdroid": False, "izzy": True, "github": True, "codeberg": False, "web": True},
             repo="https://github.com/d4rken-org/sdmaid-se", seite="https://darken.eu",
             lizenz="GPL-3.0 (Icons und Logos ausgenommen)", suche="sd maid",
             warnung="Die FOSS-Fassung ist die ohne Google-Dienste. „rc“ im Namen heißt Vorabversion."),
        _app("omnisearch", "OmniSearch", "com.omnisearch.app",
             "Windows-Dateisuche mit NTFS USN/MFT, Duplikatfinder und Android-Begleit-App für das Heimnetz.",
             "H0rSt durchsucht die freigegebenen Datei-Orte, findet Inhaltsduplikate und installiert die offizielle Begleit-App.",
             {"fdroid": False, "izzy": False, "github": True, "codeberg": False, "web": True},
             repo="https://github.com/Eul45/omni-search", seite="https://www.eyuel.com.et/omni-search",
             lizenz="MIT", suche="omni-search",
             warnung="Die Desktop-Indizierung braucht Windows 10/11, NTFS und Administratorrechte. Die Android-App "
                     "verbindet sich erst nach QR-Pairing und Freigabe am Desktop.",
             pruefen="Im offiziellen Release heißt die Android-Datei OmniSearch-Android.apk; Paket und Signatur vor dem Installieren prüfen."),
        _app("mtmanager", "MT Manager", "bin.mt.plus",
             "Datei- und APK-Werkzeugkasten mit lokalem APK-MCP-Dienst (Port 8787) für KI-Clients.",
             "H0rSt übernimmt die belegbare Palette als Style und kann den MCP-Dienst als Werkzeugserver anbinden.",
             {"fdroid": False, "izzy": False, "github": False, "codeberg": False, "web": True},
             seite="https://mt2.cn/download/", lizenz="proprietär", suche="mt manager",
             warnung="Nur von mt2.cn oder dem offiziellen Xiaomi-Store laden. APK-Spiegel und umbenannte Fassungen "
                     "können verändert sein; vor dem Installieren Paketname und Signatur prüfen.",
             pruefen="Paket bin.mt.plus, Signatur mit „apksigner verify --print-certs“ gegen die offizielle Fassung."),
        _app("shizuku", "Shizuku", "moe.shizuku.privileged.api",
             "ADB- und Root-Rechte für normale Apps über einen Dienst und die rish-Shell.",
             "H0rSt merkt sich die Shizuku-Einstellungen, baut rish-Befehle für pm, settings und appops und übernimmt "
             "die Material-3-Palette als Style.",
             {"fdroid": False, "izzy": False, "github": True, "codeberg": False, "web": True},
             repo="https://github.com/yangFenTuoZi/Shizuku", seite="https://shizuku.rikka.app/",
             lizenz="Apache-2.0", suche="shizuku",
             warnung="Nur aus dem Projekt (RikkaApps/yangFenTuoZi) oder dem Play Store laden. Der Fork trägt denselben "
                     "Paketnamen wie das Original; Signatur vor dem Installieren vergleichen.",
             pruefen="Paket moe.shizuku.privileged.api, Signatur mit „apksigner verify --print-certs“ gegen die "
                     "gewählte Quelle."),
        _app("keepadb", "KeepADB", "de.hohnepeople.keepadb",
             "Wireless Debugging wach halten: Schalter, Netzregel, Kraft-Modus und Webhook.",
             "H0rSt merkt sich Regel, vertraute Netze und Endpunkt, bewertet Netze, maskiert Adressen und baut die "
             "Schaltbefehle; die Palette dient als Style.",
             {"fdroid": True, "izzy": False, "github": True, "codeberg": False, "web": True},
             repo="https://github.com/m00sfett/KeepADB",
             seite="https://f-droid.org/packages/de.hohnepeople.keepadb/",
             lizenz="AGPL-3.0-or-later", suche="keepadb",
             warnung="Die App braucht WRITE_SECURE_SETTINGS per ADB. H0rSt setzt die Systemeinstellung nicht selbst "
                     "und liefert keine APK mit; nur aus dem Projekt oder von F-Droid laden.",
             pruefen="Paket de.hohnepeople.keepadb, Signatur mit „apksigner verify --print-certs“ gegen die "
                     "gewählte Quelle."),
        _app("aicloud", "ASUS AiCloud", "com.asustek.aicloud",
             "Fernzugriff auf den USB-Speicher am ASUS-Router.",
             "H0rSt bindet AiCloud im Bereich Heim bereits als Quelle an – die App ist der Gegenpart am Gerät.",
             {"fdroid": False, "izzy": False, "github": False, "codeberg": False, "web": True},
             seite="https://www.asus.com/support/", lizenz="proprietär", suche="aicloud",
             warnung="Nur vom Hersteller oder aus dem Play Store laden; die kursierenden Fassungen "
                     "stammen von APK-Spiegeln."),
     ]},
]

APPS = [a for g in GRUPPEN for a in g["apps"]]


def zustand():
    """Die Matrix, wie sie die Oberflaeche braucht. Reine Daten, kein Netz, kein Zustand."""
    return {"spalten": [{"id": s, "name": n} for s, n in SPALTEN], "hinweis": HINWEIS,
            "gruppen": [{"id": g["id"], "name": g["name"], "text": g["text"], "apps": g["apps"]}
                        for g in GRUPPEN],
            "ausgeschlossen": AUSGESCHLOSSEN, "anzahl": len(APPS)}
