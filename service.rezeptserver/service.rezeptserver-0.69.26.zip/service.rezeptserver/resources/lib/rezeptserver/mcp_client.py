"""MCP-Client: Verbindung zu einem Model-Context-Protocol-Server eintragen, pruefen (Schritt 1) und
dessen Werkzeuge aufrufen (Schritt 2, `aufrufen()`). Nur HTTP(S) (kein stdio/Subprocess - auf
Android/Kodi nicht verlaesslich verfuegbar).

Nutzerdaten (flach wie ki_modus & Co.): mcp_server_url, mcp_server_name, mcp_server_key,
mcp_server_heimnetz_erlaubt.
"""

import json
import urllib.error
import urllib.request

from . import __version__, netz

_JSONRPC = "2.0"
_PROTOKOLL_VERSION = "2025-06-18"
MAX_BYTES = 2 * 1024 * 1024


class McpFehler(ValueError):
    pass


def konfiguriert(daten):
    return bool(str(daten.get("mcp_server_url") or "").strip())


def _senden(url, body, session_id=None, key=None, zeitgrenze=15.0, holen=None, oeffentlich=True):
    """POST ein JSON-RPC-Objekt, gibt (status, headers, text) zurueck. Eigener schlanker Abruf statt
    netz.urllib_holen, weil Content-Type (JSON vs. SSE) und Mcp-Session-Id aus der Antwort gebraucht
    werden - netz.py gibt nur (status, text) zurueck. Ohne heimnetz_erlaubt an die gepruefte Adresse."""
    kopf = {"Content-Type": "application/json", "Accept": "application/json, text/event-stream",
            "User-Agent": netz.USER_AGENT}
    if session_id:
        kopf["Mcp-Session-Id"] = session_id
    if key:
        kopf["Authorization"] = "Bearer " + key
    koerper = json.dumps(body).encode("utf-8")
    if holen:
        return holen(url, kopf, koerper, zeitgrenze)
    anfrage = urllib.request.Request(url, data=koerper, headers=kopf, method="POST")
    oeffnen = netz.oeffentlich_oeffnen if oeffentlich else urllib.request.urlopen
    try:
        with oeffnen(anfrage, timeout=zeitgrenze) as antwort:
            inhalt = antwort.read(MAX_BYTES + 1)
            if len(inhalt) > MAX_BYTES:
                raise McpFehler("Antwort groesser als %d Bytes" % MAX_BYTES)
            return antwort.status, dict(antwort.headers), inhalt.decode("utf-8", "replace")
    except urllib.error.HTTPError as fehler:
        text = fehler.read(64 * 1024).decode("utf-8", "replace")
        fehler.close()
        return fehler.code, dict(fehler.headers or {}), text
    except (urllib.error.URLError, OSError) as fehler:
        raise McpFehler("Abruf fehlgeschlagen: %s" % fehler) from fehler


def _antwort_lesen(headers, text):
    typ = (headers.get("Content-Type") or "").split(";")[0].strip().lower()
    if typ == "text/event-stream":
        for zeile in text.splitlines():
            if zeile.startswith("data:"):
                text = zeile[len("data:"):].strip()
                break
        else:
            raise McpFehler("SSE-Antwort ohne lesbares Datenfeld - echtes Streaming wird nicht unterstützt")
    try:
        antwort = json.loads(text)
    except json.JSONDecodeError as fehler:
        raise McpFehler("Antwort ist kein gültiges JSON: %s" % fehler) from fehler
    if isinstance(antwort, dict) and antwort.get("error"):
        fehler = antwort["error"]
        raise McpFehler("MCP-Fehler: %s" % (fehler.get("message", fehler) if isinstance(fehler, dict) else fehler))
    return antwort


def verbinden(daten, holen=None):
    """Handshake (initialize + notifications/initialized) und tools/list gegen den eingetragenen
    MCP-Server. Gibt {"ok": True, "server_name", "server_version", "werkzeuge": [{"name","beschreibung"}]}
    zurueck. Wirft McpFehler bei jedem Problem (nicht erreichbar, SSRF-Sperre, kaputte Antwort)."""
    url = str(daten.get("mcp_server_url") or "").strip()
    if not url:
        raise McpFehler("Keine MCP-Server-Adresse eingetragen")
    if not daten.get("mcp_server_heimnetz_erlaubt"):
        try:
            netz.ip_oeffentlich_pruefen(url)
        except netz.NetzFehler as fehler:
            raise McpFehler(str(fehler)) from fehler
    key = str(daten.get("mcp_server_key") or "").strip() or None
    offen = not daten.get("mcp_server_heimnetz_erlaubt")

    init_body = {"jsonrpc": _JSONRPC, "id": 1, "method": "initialize",
                 "params": {"protocolVersion": _PROTOKOLL_VERSION, "capabilities": {},
                            "clientInfo": {"name": "H0rSt", "version": __version__}}}
    status, headers, text = _senden(url, init_body, key=key, holen=holen, oeffentlich=offen)
    if status >= 400:
        raise McpFehler("HTTP %d bei initialize" % status)
    ergebnis = (_antwort_lesen(headers, text) or {}).get("result") or {}
    session_id = headers.get("Mcp-Session-Id")
    server_info = ergebnis.get("serverInfo") or {}

    _senden(url, {"jsonrpc": _JSONRPC, "method": "notifications/initialized"},
            session_id=session_id, key=key, holen=holen, oeffentlich=offen)

    status, headers, text = _senden(url, {"jsonrpc": _JSONRPC, "id": 2, "method": "tools/list"},
                                     session_id=session_id, key=key, holen=holen, oeffentlich=offen)
    if status >= 400:
        raise McpFehler("HTTP %d bei tools/list" % status)
    ergebnis = (_antwort_lesen(headers, text) or {}).get("result") or {}
    werkzeuge = [{"name": w.get("name", ""), "beschreibung": w.get("description", ""),
                  "eingabe_schema": w.get("inputSchema") or {}}
                 for w in ergebnis.get("tools") or [] if isinstance(w, dict)]

    return {"ok": True, "server_name": server_info.get("name", ""),
            "server_version": server_info.get("version", ""), "werkzeuge": werkzeuge,
            "session_id": session_id}


def aufrufen(daten, session_id, name, argumente, holen=None):
    """Ruft ein Werkzeug des eingetragenen MCP-Servers auf (tools/call) und gibt den reinen Text-Anteil
    des Ergebnisses zurueck. `session_id` kommt aus einem vorherigen verbinden()-Aufruf (oder None, wenn
    der Server keine Sitzung vergibt). Wirft McpFehler bei jedem Problem, auch wenn der Server selbst
    result.isError meldet."""
    url = str(daten.get("mcp_server_url") or "").strip()
    if not url:
        raise McpFehler("Keine MCP-Server-Adresse eingetragen")
    if not daten.get("mcp_server_heimnetz_erlaubt"):
        try:
            netz.ip_oeffentlich_pruefen(url)
        except netz.NetzFehler as fehler:
            raise McpFehler(str(fehler)) from fehler
    key = str(daten.get("mcp_server_key") or "").strip() or None
    offen = not daten.get("mcp_server_heimnetz_erlaubt")

    body = {"jsonrpc": _JSONRPC, "id": 3, "method": "tools/call",
            "params": {"name": name, "arguments": argumente}}
    status, headers, text = _senden(url, body, session_id=session_id, key=key, holen=holen, oeffentlich=offen)
    if status >= 400:
        raise McpFehler("HTTP %d bei tools/call (%s)" % (status, name))
    ergebnis = (_antwort_lesen(headers, text) or {}).get("result") or {}
    teile = [t.get("text", "") for t in ergebnis.get("content") or []
             if isinstance(t, dict) and t.get("type") == "text"]
    ausgabe = "\n".join(teile)
    if ergebnis.get("isError"):
        raise McpFehler(ausgabe or "Werkzeug %s meldet einen Fehler" % name)
    return ausgabe
