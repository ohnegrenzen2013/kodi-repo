"""H0rSt als MCP-Server (Model Context Protocol, Phase 3): bietet einer EXTERNEN KI/einem externen Agenten
(z.B. Claude Desktop) eine feste Werkzeugliste an. Ab Werk aus - der Admin muss die Rolle einschalten UND
einen eigenen Schluessel erzeugen (unabhaengig von app.token, das sonst fuer jede externe Schnittstelle
wiederverwendet wird).

Sicherheits-Invariante: Kein Werkzeug schreibt/committet direkt. "vorschlag_einreichen" legt nur einen
Eintrag in der bestehenden Freigabe-Warteschlange an (rezeptserver/vorschlaege.py, Phase 1) - ein
Mensch muss ihn ueber die Oberflaeche noch annehmen, bevor irgendetwas geschrieben/committed wird.

Pfad ohne Token-Praefix erreichbar (wie xtream.py/die Newznab-Schnittstelle) - ein externer MCP-Client
kann keinen Pfad-Praefix im Server-URL-Feld unterbringen. Eigene Authentifizierung per
"Authorization: Bearer <schluessel>", unabhaengig von app.token und vom Profil-/Rechte-System.
"""

import hmac
import json
import secrets

from . import __version__, vorschlaege

_JSONRPC = "2.0"
_PROTOKOLL_VERSION = "2025-06-18"
PFAD = "/mcp"

WERKZEUGE = [
    {"name": "vorschlag_einreichen",
     "beschreibung": "Legt einen Datei-Aenderungsvorschlag in H0rSts Freigabe-Warteschlange an. Schreibt "
                      "nichts direkt - ein Admin muss den Vorschlag ueber die Oberflaeche noch annehmen.",
     "eingabe_schema": {"type": "object", "properties": {
         "dateien": {"type": "object", "description": "Pfad -> vollstaendiger neuer Dateiinhalt"},
         "begruendung": {"type": "string"},
         "herkunft": {"type": "string", "description": "Name des aufrufenden Agenten, nur zur Anzeige"}},
         "required": ["dateien"]}},
    {"name": "warteschlange_ansehen",
     "beschreibung": "Zeigt die offenen Vorschlaege und den Verlauf der Freigabe-Warteschlange.",
     "eingabe_schema": {"type": "object", "properties": {}}},
    {"name": "aktualisierung_status",
     "beschreibung": "Zeigt den Aktualisierungsstand von H0rSt (Repo, Zweig, installierte Version).",
     "eingabe_schema": {"type": "object", "properties": {}}},
    {"name": "kataloge_auflisten",
     "beschreibung": "Zeigt die konfigurierten Kataloge (Streaming, Themen, xREL, Feeds, Listen, Addons, "
                      "eigene Quellen) - ohne Zugangsdaten.",
     "eingabe_schema": {"type": "object", "properties": {}}},
]
_NAMEN = {w["name"] for w in WERKZEUGE}


class McpFehler(ValueError):
    pass


def eingeschaltet(daten):
    return bool(daten.get("mcp_eingehend_erlaubt")) and bool(daten.get("mcp_eingehend_schluessel"))


def schluessel_neu():
    return secrets.token_urlsafe(24)


class McpServer:
    def __init__(self, app):
        self.app = app

    def ist_route(self, pfad):
        return pfad.split("?", 1)[0] == PFAD

    def _autorisiert(self, kopf, daten):
        schluessel = str(daten.get("mcp_eingehend_schluessel") or "")
        if not schluessel:
            return False
        kopfwert = (kopf.get("Authorization") or "").strip()
        if not kopfwert.startswith("Bearer "):
            return False
        return hmac.compare_digest(kopfwert[len("Bearer "):].encode("utf-8"), schluessel.encode("utf-8"))

    def bearbeite(self, pfad, methode, koerper, kopf):
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        if not eingeschaltet(daten):
            return 404, "application/json", {"fehler": "Nicht gefunden"}
        if methode != "POST":
            return 405, "application/json", {"fehler": "Nur POST"}
        if not self._autorisiert(kopf, daten):
            return 401, "application/json", {"fehler": "Nicht autorisiert"}
        try:
            anfrage = json.loads(koerper.decode("utf-8") or "{}")
        except (ValueError, UnicodeDecodeError):
            return 400, "application/json", _fehler(None, "Ungültiges JSON")
        if not isinstance(anfrage, dict):
            return 400, "application/json", _fehler(None, "JSON-Objekt erwartet")
        rpc_id = anfrage.get("id")
        methode_name = anfrage.get("method")
        params = anfrage.get("params") or {}

        if methode_name == "initialize":
            return 200, "application/json", _erfolg(rpc_id, {
                "protocolVersion": _PROTOKOLL_VERSION, "capabilities": {"tools": {}},
                "serverInfo": {"name": "H0rSt", "version": __version__}})
        if methode_name == "notifications/initialized":
            return 202, "application/json", {}
        if methode_name == "tools/list":
            return 200, "application/json", _erfolg(rpc_id, {"tools": [
                {"name": w["name"], "description": w["beschreibung"], "inputSchema": w["eingabe_schema"]}
                for w in WERKZEUGE]})
        if methode_name == "tools/call":
            return 200, "application/json", self._werkzeug_aufrufen(rpc_id, daten, params)
        return 200, "application/json", _fehler(rpc_id, "Methode unbekannt: %s" % methode_name, code=-32601)

    def _werkzeug_aufrufen(self, rpc_id, daten, params):
        name = params.get("name")
        if name not in _NAMEN:
            return _fehler(rpc_id, "Unbekanntes Werkzeug: %s" % name, code=-32602)
        argumente = params.get("arguments") or {}
        if not isinstance(argumente, dict):
            return _fehler(rpc_id, "arguments muss ein Objekt sein", code=-32602)
        try:
            text = self._werkzeuge[name](daten, argumente)
        except (McpFehler, vorschlaege.VorschlagFehler, ValueError) as fehler:
            return _erfolg(rpc_id, {"isError": True, "content": [{"type": "text", "text": str(fehler)}]})
        return _erfolg(rpc_id, {"content": [{"type": "text", "text": text}]})

    def _vorschlag_einreichen(self, daten, argumente):
        dateien = argumente.get("dateien")
        if not isinstance(dateien, dict) or not dateien:
            raise McpFehler("dateien muss ein nicht-leeres Objekt {pfad: inhalt} sein")
        begruendung = argumente.get("begruendung", "")
        herkunft = str(argumente.get("herkunft") or "extern")[:40]
        wer = {"id": "mcp:" + herkunft}

        def tun(d):
            return vorschlaege.einreichen(d, wer, "mcp:" + herkunft, dateien, begruendung)

        eintrag = self.app.verwaltung.bearbeiten(tun)
        return "Vorschlag eingereicht (id=%s), wartet auf Freigabe." % eintrag["id"]

    def _warteschlange_ansehen(self, daten, argumente):
        return json.dumps(vorschlaege.zustand(daten), ensure_ascii=False)

    def _aktualisierung_status(self, daten, argumente):
        return json.dumps(self.app.aktualisierung.zustand(), ensure_ascii=False)

    def _kataloge_auflisten(self, daten, argumente):
        return json.dumps(self.app.kataloge.uebersicht(daten), ensure_ascii=False)

    @property
    def _werkzeuge(self):
        return {"vorschlag_einreichen": self._vorschlag_einreichen,
                "warteschlange_ansehen": self._warteschlange_ansehen,
                "aktualisierung_status": self._aktualisierung_status,
                "kataloge_auflisten": self._kataloge_auflisten}


def _erfolg(rpc_id, result):
    return {"jsonrpc": _JSONRPC, "id": rpc_id, "result": result}


def _fehler(rpc_id, meldung, code=-32603):
    return {"jsonrpc": _JSONRPC, "id": rpc_id, "error": {"code": code, "message": meldung}}
