"""Titel zu eigenen MDBList-Listen hinzufuegen (ARVIO 2.3). API nach https://api.mdblist.com/schema/ (OpenAPI):

  * Eigene Listen: GET  /lists/user?apikey=KEY            -> [{id, name, slug, items, mediatype, ...}]
  * Hinzufuegen:   POST /lists/{listid}/items/add?apikey=KEY, JSON {"movies": [{"imdb": "tt…"}], "shows": [{"imdb": "tt…"}]}
                   -> {added, existing, not_found, ...} (Zaehler je Art; nur statische Listen sind beschreibbar)
Der API-Schluessel ist der der vorhandenen MDBList-Einstellung (kataloge.mdblist_key) und taucht nie in Meldungen auf.
Jeder Titel geht einzeln, damit die Rueckmeldung je Titel stimmt; Limit bei MDBList: 300 Schreibzugriffe je 5 Minuten.
"""

import json
import re

from .netz import NetzFehler

API = "https://api.mdblist.com"
MAX_TITEL = 20
_ZEICHEN = re.compile(r"(apikey=)[^&\s\"']+", re.I)


class MdblistFehler(ValueError):
    pass


def _meldung(fehler):
    """Verstaendliche Meldung ohne API-Schluessel aus einem NetzFehler (Text "HTTP 401 bei …")."""
    roh = _ZEICHEN.sub(r"\1***", str(fehler))
    m = re.match(r"HTTP (\d{3})", roh)
    if not m:
        return "MDBList nicht erreichbar"
    status = int(m.group(1))
    if status in (401, 403):
        return "MDBList lehnt den API-Schlüssel ab – unter Einstellungen → Trakt, MDBList & Google Drive prüfen"
    if status == 404:
        return "MDBList kennt die Liste nicht oder es ist keine eigene statische Liste"
    if status == 429:
        return "MDBList-Anfrage-Limit erreicht – später noch einmal versuchen"
    return "MDBList-Fehler (HTTP %d)" % status


def _schluessel(key):
    key = str(key or "").strip()
    if not key:
        raise MdblistFehler("Für MDBList erst den API-Schlüssel eintragen (Einstellungen → Trakt, MDBList & Google Drive)")
    return key


def _zaehler(x):
    if isinstance(x, bool):
        return 0
    if isinstance(x, (int, float)):
        return int(x)
    if isinstance(x, (list, dict)):
        return len(x)
    return 0


def _anzahl(antwort, feld, art):
    teil = antwort.get(feld)
    return _zaehler(teil.get(art)) if isinstance(teil, dict) else 0


def eigene_listen(abrufer, key):
    """[{id, name, anzahl, art}] der eigenen Listen (art: movie, show oder '' fuer gemischt)."""
    key = _schluessel(key)
    try:
        roh = json.loads(abrufer.abruf("%s/lists/user?apikey=%s" % (API, key)))
    except NetzFehler as fehler:
        raise MdblistFehler(_meldung(fehler))
    except ValueError:
        raise MdblistFehler("MDBList antwortet nicht verständlich")
    listen = []
    for x in roh if isinstance(roh, list) else []:
        kennung = x.get("id") if isinstance(x, dict) else None
        if isinstance(kennung, int) and not isinstance(kennung, bool):
            listen.append({"id": str(kennung), "name": str(x.get("name") or kennung)[:100], "anzahl": int(x.get("items") or 0),
                           "art": str(x.get("mediatype") or "")[:10]})
    return listen


def zur_liste(abrufer, key, liste_id, titel):
    """Titel ([{typ: movie|series, id: tt…}], hoechstens 20) einzeln hinzufuegen -> [{id, typ, ergebnis, ok}]."""
    key = _schluessel(key)
    if not re.fullmatch(r"\d{1,12}", str(liste_id or "")):
        raise MdblistFehler("Liste fehlt")
    if not isinstance(titel, list) or not 0 < len(titel) <= MAX_TITEL:
        raise MdblistFehler("1 bis %d Titel angeben" % MAX_TITEL)
    for t in titel:
        if not isinstance(t, dict) or t.get("typ") not in ("movie", "series") or not re.fullmatch(r"tt\d{1,12}", str(t.get("id") or "")):
            raise MdblistFehler("Titel brauchen typ (movie oder series) und eine IMDb-Kennung (tt…)")
    ergebnis = []
    for t in titel:
        art = "movies" if t["typ"] == "movie" else "shows"
        try:
            antwort = json.loads(abrufer.abruf("%s/lists/%s/items/add?apikey=%s" % (API, liste_id, key), methode="POST",
                                               header={"Content-Type": "application/json"},
                                               daten=json.dumps({art: [{"imdb": t["id"]}]})))
            antwort = antwort if isinstance(antwort, dict) else {}
            if _anzahl(antwort, "not_found", art) > 0:
                text = "nicht gefunden"
            elif _anzahl(antwort, "added", art) > 0:
                text = "hinzugefügt"
            elif _anzahl(antwort, "existing", art) > 0:
                text = "schon drin"
            else:
                text = "Antwort von MDBList unklar"
        except NetzFehler as fehler:
            text = _meldung(fehler)
        except ValueError:
            text = "Antwort von MDBList unklar"
        ergebnis.append({"id": t["id"], "typ": t["typ"], "ergebnis": text, "ok": text in ("hinzugefügt", "schon drin")})
    return ergebnis
