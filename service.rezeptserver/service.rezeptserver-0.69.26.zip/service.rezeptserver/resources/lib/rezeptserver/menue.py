"""Rezepte-StammBaum: alle Module, Reiter, eigenen Tabs und Rezepte als ein Baum.

Der Baum ist die gemeinsame Sicht fuer Einstellungen -> Menue: Welten und Module
kommen aus dem Modulregister, die Reihenfolge aus der Navigation, eigene Reiter aus
den Oberflaechen-Einstellungen. Rezepte (JSON-Quellen) haengen als eigener Ast
darunter. Geaendert wird weiterhin ueber die bestehenden Einstellungen; damit gilt
ueberall dieselbe Pruefung und ein geloeschter Reiter rueckt automatisch nach.
"""

from . import __version__, baukasten, einstellungen, pass_tresor


def _nav_werte(daten, werte=None):
    if werte is None:
        werte = einstellungen.werte(daten or {})
    eintraege = werte.get("navigation") or []
    an = {x.get("id"): x.get("an") is not False for x in eintraege if isinstance(x, dict)}
    pos = {x.get("id"): n for n, x in enumerate(eintraege) if isinstance(x, dict)}
    gruppe, aktuelle = {}, ""
    for x in eintraege:
        if not isinstance(x, dict):
            continue
        if str(x.get("id", "")).startswith("g:"):
            aktuelle = x.get("id")
        else:
            gruppe[x.get("id")] = aktuelle
    sicht = {x.get("id"): n for n, x in enumerate([y for y in eintraege if y.get("an") is not False])
             if isinstance(x, dict)}
    return werte, an, pos, gruppe, sicht


def _gruppe_namen(nav):
    return {i: n for i, n in nav if str(i).startswith("g:")}


def _tab_namen(nav):
    return dict(nav)


def baum(daten=None, datenordner="", module=(), werte=None):
    daten = daten or {}
    werte, an, pos, gruppe, sicht = _nav_werte(daten, werte)
    tab_namen = _tab_namen(einstellungen.NAV)
    gruppen_namen = _gruppe_namen(einstellungen.NAV)
    eigene = [dict(x) for x in werte.get("eigene_tabs") or []]
    eig_namen = {t["id"]: t["name"] for t in eigene}

    welten = []
    for welt in baukasten.WELTEN:
        module_liste = []
        for eintrag in welt["module"]:
            tabs = []
            for tab in eintrag["tabs"]:
                tabs.append({"id": tab, "name": tab_namen.get(tab, tab), "an": an.get(tab, True),
                             "position": pos.get(tab, -1), "sicht": sicht.get(tab, -1), "gruppe": gruppe.get(tab, "")})
            module_liste.append({
                "id": eintrag["id"], "name": eintrag["name"], "symbol": eintrag.get("symbol", ""),
                "welt": welt["id"], "welt_name": welt["name"], "an": all(t["an"] for t in tabs),
                "tabs": tabs, "standard": bool(eintrag.get("standard")), "nur_app": bool(eintrag.get("nur_app")),
                "assistent": eintrag.get("assistent") or "",
            })
        welten.append({"id": welt["id"], "name": welt["name"], "symbol": welt.get("symbol", ""),
                       "gruppe": welt.get("gruppe") or "", "text": welt.get("text", ""),
                       "an": any(m["an"] for m in module_liste), "module": module_liste})

    feste = []
    for tab in baukasten.FEST:
        feste.append({"id": tab, "name": tab_namen.get(tab, tab), "an": an.get(tab, True),
                      "position": pos.get(tab, -1), "sicht": sicht.get(tab, -1), "gruppe": gruppe.get(tab, ""), "pflicht": True})

    eigene_liste = []
    for t in eigene:
        tid = "eigen:" + t["id"]
        eigene_liste.append(dict(t, nav="eigen:" + t["id"], an=an.get(tid, True), position=pos.get(tid, -1),
                                 sicht=sicht.get(tid, -1), gruppe=gruppe.get(tid, ""), menue=bool(t.get("menue")),
                                 name=eig_namen.get(t["id"], t.get("name", t["id"]))))

    gruppen = []
    for gid, name in einstellungen.NAV:
        if not str(gid).startswith("g:"):
            continue
        gruppen.append({"id": gid, "name": gruppen_namen.get(gid, name), "an": an.get(gid, True),
                        "position": pos.get(gid, -1)})

    rezepte = []
    for m in module or ():
        d = getattr(m, "daten", {}) or {}
        felder = []
        for feld in getattr(m, "einstellungen", []) or []:
            felder.append({"key": feld.get("key", ""), "label": feld.get("label", feld.get("key", "")),
                           "typ": feld.get("typ", "text"), "optional": bool(feld.get("optional"))})
        rezepte.append({"id": getattr(m, "id", d.get("id", "")), "name": getattr(m, "name", d.get("name", "")),
                        "version": str(getattr(m, "version", d.get("version", ""))),
                        "rolle": getattr(m, "rolle", d.get("rolle", "")),
                        "konto": getattr(m, "konto", d.get("konto", "")),
                        "kategorie": d.get("kategorie", ""), "einstellungen": felder,
                        "eigen": bool(d.get("skript")), "hat_skript": bool(d.get("skript"))})
    rezepte.sort(key=lambda x: (x["name"].casefold(), x["id"]))

    tresor = None
    try:
        tresor = pass_tresor.zustand(daten, datenordner)
    except Exception:  # noqa: BLE001 - ein fehlender Tresor darf den Menue-Baum nicht kippen
        tresor = None

    return {"version": __version__, "welten": welten, "feste": feste, "eigene": eigene_liste,
            "gruppen": gruppen, "rezepte": rezepte, "tresor": tresor,
            "zaehler": {"welten": len(welten), "module": sum(len(w["module"]) for w in welten),
                        "tabs": len(einstellungen.NAV), "eigene": len(eigene_liste),
                        "rezepte": len(rezepte), "gruppen": len(gruppen)},
            "optionen": {
                "darstellung": [["tab", "Als Reiter oben"], ["verknuepfung", "Als Verknuepfung"],
                                ["seitenmenue", "Ins Seitenmenue (Extras)"]],
                "arten": [["app", "App starten (Android)"], ["web", "Webseite einbetten"],
                          ["link", "Verknuepfung (neues Fenster)"], ["kodi", "Kodi-Addon"]],
                "ziele": ["intern", "extern"],
            },
            "hinweis": "Der Baum nutzt dieselbe Navigation wie die Reiter oben. Wird ein Eintrag geloescht, "
                        "ruecken die uebrigen nach; Start und Einstellungen bleiben immer erreichbar."}
