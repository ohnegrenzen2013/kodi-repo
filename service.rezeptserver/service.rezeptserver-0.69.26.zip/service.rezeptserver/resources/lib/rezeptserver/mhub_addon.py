"""H0rSt als mHub-Addon (MediaHubMX Addon Protocol v2, https://github.com/mediahubmx/protocol).

Neben dem Stremio-Addon spricht H0rSt die zweite grosse Addon-Sprache: Apps wie Vuma binden ihn ueber
http://<host>:<port>/<token>/mhub-addon.json ein. Die Antworten kommen aus denselben Teilen wie beim Stremio-Addon
(Suche, Details, Streams, Untertitel) und werden nur uebersetzt. Dazu ist H0rSt ein Tracker: die App meldet, was
geschaut wurde (POST /playback), und das landet in Weiterschauen, Verlauf und Merkliste (sehen.py) – auf allen
Geraeten, auch im Browser und in der H0rSt-App.

  GET  /mhub-addon.json                     Manifest
  GET  /catalog/{video|series}/{id}.json    Suchkataloge (?search=)
  GET  /item/{type}/{id}.json               Details eigener Treffer (rz:…)
  GET  /source/{type}/{id}.json             Streams zu imdb:tt123, imdb:tt123:2:5 (Folge) oder rz:…
  GET  /subtitle/{type}/{id}.json           Untertitel
  GET  /playback                            Stand des Profils (Weiterschauen, Verlauf, Merkliste)
  POST /playback                            Ereignisse der App: progress, reset, watched, unwatched, listed, unlisted
  GET  /configure.html                      Profil verbinden (nur mit Profilen): Schluessel geht als Mhub-Config

Typen: mHub "video" ist Stremios "movie", "series" bleibt. Mit Profilen schickt die App den Sitzungsschluessel des
gewaehlten Profils in der Kopfzeile Mhub-Config ({"sitzung": …}); ohne Profile gilt alles fuer alle.
"""

import hashlib
import json
import os
import re
from urllib.parse import parse_qs, quote, unquote, urlencode

from . import profile, sehen
from .stremio_grund import ID_PRAEFIX, id_zu_treffer, log
from .mhub_addon_grund import *  # noqa: F403
from .mhub_addon_grund import (_titel_id, _v1_ids, _zeit, v1_catalog, v1_item, v1_manifest,  # noqa: F401
                               v1_source, v1_subtitle)

ROUTE = re.compile(r"^/(catalog|item|source|subtitle)/(video|series)/([^/]+)\.json$")
V1_ROUTE = re.compile(r"^/(mediahubmx|mediaurl)(?:-(addon|catalog|item|source|subtitle|resolve))?\.json$")
TYP_STREMIO = {"video": "movie", "series": "series"}
_ORDNER = os.path.join(os.path.dirname(os.path.abspath(__file__)), "statisch", "mhub")
# Profil verbinden: eigene Seite plus die Bausteine der Spezifikation (MIT, nichts von fremden Servern)
SEITEN = {"/configure.html": ("configure.html", "text/html"), "/configure/v1.js": ("v1.js", "text/javascript"),
          "/configure/v1.css": ("v1.css", "text/css"), "/configure/h0rst.js": ("h0rst.js", "text/javascript")}
MAX_EREIGNISSE = 2000
MAX_NACHSCHLAGEN = 40  # Titel je Meldung, deren Namen H0rSt bei Cinemeta nachschlaegt (Rest: Kennung als Name)
SEITENLAENGE = 40  # Katalogseite der mHub-Antworten (cursor/nextCursor)


def ist_route(pfad):
    """Pfade des mHub-Addons (ohne Token, ohne Abfrage)."""
    return pfad in ("/mhub-addon.json", "/playback") or pfad in SEITEN or ROUTE.match(pfad) is not None


def ist_v1_route(pfad):
    """Alte MediaHubMX-Pfade der v1-Bruecke (POST /mediahubmx*.json)."""
    return V1_ROUTE.match(pfad) is not None


def privat(pfad):
    """Antworten mit dem Stand eines Profils: nie zwischenspeichern (alles ausser Manifest und Seiten)."""
    return ist_route(pfad) and pfad != "/mhub-addon.json" and pfad not in SEITEN


class MhubMixin:
    def mhub_v1(self, pfad, koerper, kopf):
        """Minimale v1-Bruecke: mediahubmx.json + addon/catalog/item/source/subtitle in v1-Form."""
        m = V1_ROUTE.match(pfad)
        try:
            daten = json.loads((koerper or b"").decode("utf-8"))
        except (UnicodeDecodeError, ValueError):
            daten = {}
        daten = daten if isinstance(daten, dict) else {}
        aktion = str(daten.get("action") or (m.group(2) if m else "") or "addon")
        if aktion == "addon":
            return 200, "application/json", v1_manifest(self.mhub_manifest(kopf))
        if aktion not in ("catalog", "item", "source", "subtitle"):
            return 404, "application/json", {"error": "unknown action"}
        if aktion == "catalog":
            typ = "series" if daten.get("type") == "series" else "video"
            kid = str(daten.get("catalogId") or daten.get("id") or "")
            werte = {}
            if daten.get("search"):
                werte["search"] = daten["search"]
            if daten.get("cursor") not in (None, ""):
                werte["cursor"] = str(daten["cursor"])
            if daten.get("sort"):
                werte["sort"] = str(daten["sort"])
            filter_werte = daten.get("filter")
            if isinstance(filter_werte, dict):
                for k, v in filter_werte.items():
                    if v not in (None, ""):
                        werte["filter[%s]" % k] = str(v)
            status, _, antwort = self.mhub_bearbeite("/catalog/%s/%s.json" % (typ, quote(kid, safe="")),
                                                     urlencode(werte), "GET", b"", kopf)
            if status != 200 or not isinstance(antwort, dict):
                return status, "application/json", antwort
            return 200, "application/json", v1_catalog(antwort)
        kandidaten = _v1_ids(daten.get("ids"), daten.get("episode"))
        typen = ["series", "video"] if daten.get("type") == "series" else ["video", "series"]
        for typ in typen:
            for kid in kandidaten:
                status, _, antwort = self.mhub_bearbeite("/%s/%s/%s.json" % (aktion, typ, quote(kid, safe=":")),
                                                         "", "GET", b"", kopf)
                if status != 200 or not isinstance(antwort, dict):
                    continue
                if aktion == "item":
                    return 200, "application/json", v1_item(antwort)
                if aktion == "source":
                    return 200, "application/json", [v1_source(s) for s in antwort.get("sources") or []]
                return 200, "application/json", [v1_subtitle(s) for s in antwort.get("subtitles") or []]
        return 404, "application/json", {"error": "not found"}

    def mhub_bearbeite(self, pfad, abfrage, methode, koerper, kopf):
        werte = {k: v[0] for k, v in parse_qs(abfrage).items()}
        if pfad in SEITEN:
            datei, art = SEITEN[pfad]
            with open(os.path.join(_ORDNER, datei), encoding="utf-8") as f:
                return 200, art, f.read()
        if pfad == "/playback":
            if methode == "POST":
                return self._mhub_melden(koerper, kopf)
            if methode in ("GET", "HEAD"):
                return self._mhub_stand(werte, kopf)
            return 405, "application/json", {"error": "method not allowed"}
        if methode not in ("GET", "HEAD"):
            return 405, "application/json", {"error": "method not allowed"}
        if pfad == "/mhub-addon.json":
            return 200, "application/json", self.mhub_manifest(kopf)
        art, typ, kennung = ROUTE.match(pfad).groups()
        kennung, styp = unquote(kennung), TYP_STREMIO[typ]
        if art == "catalog":
            suche = (werte.get("search") or "").strip()
            antwort = self.katalog(styp, kennung, {"search": suche} if suche else {})
            alle = [item_von(m, typ) for m in antwort.get("metas") or []]
            try:
                start = max(0, int(werte.get("cursor") or 0))
            except (TypeError, ValueError):
                start = 0
            seite = alle[start:start + SEITENLAENGE]
            weiter = str(start + SEITENLAENGE) if len(alle) > start + SEITENLAENGE else None
            self._mhub_zustaende(kopf, seite)
            # ohne Suchwort sieht der Pfad aus wie Stremios Katalog (/catalog/series/…): beide Antworten, beide leer
            return 200, "application/json", {"items": seite, "nextCursor": weiter, **({} if suche else {"metas": []})}
        if art == "item":
            sid = stremio_id_von(kennung)
            if kennung.startswith(ID_PRAEFIX):
                meta = self.meta(styp, kennung).get("meta")
            elif sid and sid.startswith("tt") and ":" not in sid:
                meta = self.meta(styp, sid).get("meta")  # idPrefixes: auch fremde IMDb-Titel beschreiben
            else:
                meta = None
            if not meta:
                return 404, "application/json", {"error": "not found"}
            items = [item_von(meta, typ)]
            self._mhub_zustaende(kopf, items)
            return 200, "application/json", items[0]
        sid = stremio_id_von(kennung)
        if art == "source":
            if not sid:
                return 404, "application/json", {"error": "unknown id"}
            quellen = [q for q in (quelle_von(s) for s in self.stream(styp, sid, kopf).get("streams") or []) if q]
            return 200, "application/json", {"sources": quellen}
        if not sid or not sid.startswith("tt"):
            return 200, "application/json", {"subtitles": []}
        untertitel = []
        for u in self.untertitel(styp, sid, kopf).get("subtitles") or []:
            if not u.get("url"):
                continue
            eintrag = {"url": u["url"], "language": u.get("lang") or "und"}
            if u.get("name"):
                eintrag["name"] = str(u["name"])[:120]
            endung = str(u["url"]).split("?", 1)[0].rsplit(".", 1)[-1].lower()
            if endung in ("srt", "vtt", "ass", "ssa", "ttml"):
                eintrag["format"] = endung
            untertitel.append(eintrag)
        return 200, "application/json", {"subtitles": untertitel}

    def mhub_manifest(self, kopf):
        st = self.manifest()
        stremio_ressourcen = {r["name"] for r in st["resources"]}
        ressourcen = (["catalog", "item"] if "catalog" in stremio_ressourcen else []) + \
            (["source"] if "stream" in stremio_ressourcen else []) + \
            (["subtitle"] if "subtitles" in stremio_ressourcen else []) + (["playback"] if self.verwaltung else [])
        m = {"id": "org.rezeptserver", "name": st["name"], "specVersion": 2, "version": st["version"],
             "description": st["description"], "resources": ressourcen, "types": ["video", "series"],
             "idPrefixes": ["imdb", ID_PRAEFIX.rstrip(":")],
             "catalogs": [{"id": c["id"], "name": c["name"], "type": TYP_MHUB[c["type"]], "features": {"search": True}}
                          for c in st["catalogs"] if c["type"] in TYP_MHUB]}
        basis = self.eigene_basis(kopf)
        if basis:
            m["icon"] = basis + "logo.svg"
        if st.get("behaviorHints", {}).get("adult"):
            m["adult"] = True
        daten = self.verwaltung.daten() if self.verwaltung else {}
        if profile.aktiv(daten):
            # die App holt den Schluessel ueber ./configure.html (Profil waehlen, PIN) und schickt ihn mit
            m["config"] = {"fields": [{"id": "sitzung", "name": "H0rSt-Profil", "type": "secret", "optional": True,
                                       "help": "Verbindet die App mit deinem Profil: Weiterschauen, Verlauf und Merkliste."}],
                           "required": False}
        return m

    # --- Profil und Stand ---------------------------------------------------------------------------------
    def _mhub_profil(self, kopf):
        """Profil-ID der App ('' ohne Profile) oder None, wenn Profile aktiv sind und kein gueltiger Schluessel kommt."""
        daten = self.verwaltung.daten() if self.verwaltung else {}
        if not profile.aktiv(daten):
            return ""
        try:
            werte = json.loads(kopf.get("Mhub-Config") or "{}")
        except ValueError:
            return None
        x = profile.profil_zu(daten, str(werte.get("sitzung") or "")) if isinstance(werte, dict) else None
        return x["id"] if x else None

    def _mhub_zustaende(self, kopf, items):
        """PlaybackState an jedes Item, das H0rSt einem Titel zuordnen kann (nur mit bekanntem Profil)."""
        pid = self._mhub_profil(kopf) if self.verwaltung else None
        if pid is None:
            return
        listen = sehen.lesen(self.verwaltung.daten(), pid)
        for item in items:
            if item.get("ids"):
                item["playback"] = zustand(listen, TYP_STREMIO[item["type"]], item["id"])

    def _mhub_stand(self, werte, kopf):
        pid = self._mhub_profil(kopf) if self.verwaltung else None
        if pid is None:
            return 428, "application/json", {"error": "config_required", "fields": ["sitzung"]}
        items = stand(sehen.lesen(self.verwaltung.daten(), pid))
        version = hashlib.sha1(json.dumps(items, sort_keys=True).encode("utf-8")).hexdigest()[:16]
        if werte.get("version") == version:
            return 200, "application/json", {"version": version, "unchanged": True}
        return 200, "application/json", {"version": version, "items": items}

    def _mhub_karte(self, typ, titel_id, bekannt, nachschlagen):
        """Karte fuer Weiterschauen/Verlauf/Merkliste: schon bekannt, aus Cinemeta (imdb, hoechstens
        nachschlagen["rest"] Titel je Meldung) oder dem Treffer (rz)."""
        if (typ, titel_id) in bekannt:
            return bekannt[(typ, titel_id)]
        karte = {"id": titel_id, "typ": typ, "titel": titel_id}
        if titel_id.startswith(ID_PRAEFIX):
            treffer = id_zu_treffer(titel_id) or {}
            karte.update(titel=treffer.get("titel") or titel_id, poster=treffer.get("poster") or "")
        elif nachschlagen["rest"] > 0:
            nachschlagen["rest"] -= 1
            meta = self.cinemeta(typ, titel_id) or {}
            karte.update(titel=meta.get("name") or titel_id, jahr=meta.get("releaseInfo") or meta.get("year") or "",
                         poster=meta.get("poster") or "", hintergrund=meta.get("background") or "", logo=meta.get("logo") or "",
                         genres=meta.get("genres") or [], laufzeit=meta.get("runtime") or "",
                         bewertung=meta.get("imdbRating") or "", beschreibung=meta.get("description") or "")
        bekannt[(typ, titel_id)] = karte
        return karte

    def _mhub_melden(self, koerper, kopf):
        if not self.verwaltung:
            return 503, "application/json", {"error": "no user data"}
        pid = self._mhub_profil(kopf)
        if pid is None:
            return 428, "application/json", {"error": "config_required", "fields": ["sitzung"]}
        try:
            ereignisse = json.loads((koerper or b"").decode("utf-8"))
        except (UnicodeDecodeError, ValueError):
            return 400, "application/json", {"error": "JSON-Liste erwartet"}
        if not isinstance(ereignisse, list) or not ereignisse or len(ereignisse) > MAX_EREIGNISSE:
            return 400, "application/json", {"error": "1 bis %d Ereignisse als Liste" % MAX_EREIGNISSE}
        # Namen und Bilder vor dem Schreiben holen (Cinemeta), nicht waehrend die Nutzerdaten gesperrt sind
        listen = sehen.lesen(self.verwaltung.daten(), pid)
        bekannt = {(k["typ"], k["id"]): k for name in ("weiterschauen", "verlauf", "merkliste") for k in listen[name]}
        nachschlagen = {"rest": MAX_NACHSCHLAGEN}
        schritte = []
        for e in ereignisse:
            item = e.get("item") if isinstance(e, dict) else None
            typ = TYP_STREMIO.get(item.get("type")) if isinstance(item, dict) else None
            titel_id = _titel_id(item.get("ids")) if typ else None
            if not titel_id:
                continue  # Bilder, Seiten, Live-TV oder Kennungen, die H0rSt nicht kennt
            karte = self._mhub_karte(typ, titel_id, bekannt, nachschlagen)
            zeit = _zeit(e.get("at"))
            schritte.extend((zeit, w) for w in wuensche_von(e, karte))

        def tun(d):
            for zeit, wunsch in schritte:
                try:
                    sehen.aendern(d, pid, wunsch, jetzt=zeit)
                except sehen.SehenFehler as fehler:
                    log.info("mHub-Meldung uebergangen: %s", fehler)
        if schritte:
            self.verwaltung.bearbeiten(tun)
        return 204, "text/plain", ""
