"""mHub-Uebersetzung: Kennungen, Items, Quellen und der Stand eines Profils (ohne die HTTP-Routen).

Die Funktionen hier sind die reine Uebersetzung zwischen Stremio und dem MediaHubMX-Addon-Protokoll v2; sie
kennen weder Anfrage noch Antwort und lassen sich ohne Netz testen. Die Routen und die App-Anbindung stehen in
mhub_addon.py.
"""

import re
from datetime import datetime

from .stremio_grund import ID_PRAEFIX

TYP_MHUB = {"movie": "video", "series": "series"}
_IMDB = re.compile(r"^tt\d{5,10}$")


def ids_von(stremio_id):
    """Stremio-Kennung -> mHub-ids: tt123 -> {"imdb": "tt123"}, rz:XYZ -> {"rz": "XYZ"}; sonst {}."""
    sid = str(stremio_id or "")
    if sid.startswith(ID_PRAEFIX):
        return {"rz": sid[len(ID_PRAEFIX):]}
    return {"imdb": sid} if _IMDB.match(sid) else {}


def stremio_id_von(mhub_id):
    """imdb:tt123:2:5 -> tt123:2:5; rz:XYZ bleibt (eigene Kennung, gleiche Schreibweise); sonst None."""
    mid = str(mhub_id or "")
    if mid.startswith("imdb:"):
        rest = mid[5:]
        return rest if re.match(r"^tt\d{5,10}(:\d{1,4}:\d{1,5})?$", rest) else None
    return mid if mid.startswith(ID_PRAEFIX) and len(mid) > len(ID_PRAEFIX) else None


def _titel_id(ids):
    """Kennung des Titels in H0rSt aus den ids einer App: imdb (ohne :Staffel:Folge) oder rz."""
    if not isinstance(ids, dict):
        return None
    imdb = str(ids.get("imdb") or "").split(":")[0]
    if _IMDB.match(imdb):
        return imdb
    rz = str(ids.get("rz") or "")
    return ID_PRAEFIX + rz if re.match(r"^[\w=-]{1,2000}$", rz) else None


def item_von(meta, typ):
    """Stremio-Meta (Katalog oder Details) -> mHub-Item."""
    item = {"id": meta["id"], "type": typ, "name": str(meta.get("name") or meta["id"])}
    ids = ids_von(meta["id"])
    if ids:
        item["ids"] = ids
    bilder = {}
    if meta.get("poster"):
        bilder["poster"] = meta["poster"]
    if meta.get("background"):
        bilder["backdrops"] = [meta["background"]]
    if meta.get("logo"):
        bilder["logo"] = meta["logo"]
    if bilder:
        item["images"] = bilder
    jahr = re.match(r"\d{4}", str(meta.get("releaseInfo") or ""))
    if jahr:
        item["year"] = int(jahr.group(0))
    if meta.get("description"):
        item["description"] = str(meta["description"])
    if isinstance(meta.get("genres"), list):
        item["genres"] = [str(g) for g in meta["genres"]]
    try:
        item["ratings"] = {"imdb": float(meta["imdbRating"])}
    except (KeyError, TypeError, ValueError):
        pass
    return item


def quelle_von(stream):
    """Stremio-Stream -> mHub-Source; None ohne Adresse. externalUrl wird eine Website-Quelle."""
    url = str(stream.get("url") or "")
    extern = str(stream.get("externalUrl") or "")
    hinweise = stream.get("behaviorHints") if isinstance(stream.get("behaviorHints"), dict) else {}
    name = " · ".join(dict.fromkeys(z.strip() for z in str(stream.get("name") or "").split("\n") if z.strip()))
    titel = str(stream.get("title") or stream.get("description") or "").split("\n")[0].strip()
    if extern.startswith(("http://", "https://")):
        return {"url": extern, "kind": "website", "name": " – ".join(x for x in (name, titel) if x)[:200] or "Website"}
    if not url.startswith(("http://", "https://")):
        return None
    q = {"url": url, "name": " – ".join(x for x in (name, titel) if x)[:200] or "H0rSt"}
    qualitaet = re.search(r"\b(2160p|4K|1080p|720p|480p)\b", name + " " + titel, re.I)
    if qualitaet:
        q["quality"] = qualitaet.group(1)
    groesse = hinweise.get("videoSize")
    if isinstance(groesse, int) and not isinstance(groesse, bool) and groesse > 0:
        q["size"] = groesse
    kopf = (hinweise.get("proxyHeaders") or {}).get("request") if isinstance(hinweise.get("proxyHeaders"), dict) else None
    if isinstance(kopf, dict) and kopf:
        q["headers"] = {str(k): str(v) for k, v in kopf.items()}
    return q


def _zeit(roh):
    """ISO-Zeitpunkt aus der App (at) -> Unix-Sekunden; None ohne oder bei Unsinn."""
    if not isinstance(roh, str) or not roh:
        return None
    try:
        return datetime.fromisoformat(roh.replace("Z", "+00:00")).timestamp()
    except ValueError:
        return None


def wuensche_von(ereignis, karte):
    """Ein Ereignis der App -> Aenderungen fuer sehen.aendern (leer, wenn H0rSt dafuer keinen Platz hat)."""
    art, item = ereignis.get("type"), ereignis.get("item")
    typ = karte["typ"]
    staffel, folge = item.get("season"), item.get("episode")
    ist_folge = typ == "series" and all(isinstance(x, int) and not isinstance(x, bool) and x >= 0 for x in (staffel, folge))
    video = karte["id"] + (":%d:%d" % (staffel, folge) if ist_folge else "")
    if art == "progress":
        p = ereignis.get("progress")
        if typ == "series" and not ist_folge or not isinstance(p, (int, float)) or isinstance(p, bool) or not 0 <= p <= 100:
            return []
        return [{"aktion": "fortschritt", "titel": karte, "video": video, "anteil": p / 100.0}]
    return {"reset": [{"aktion": "weiterschauen_weg", "titel": karte}],
            "watched": [{"aktion": "gesehen", "titel": karte}, {"aktion": "weiterschauen_weg", "titel": karte}],
            "unwatched": [{"aktion": "verlauf_weg", "titel": karte}],
            "listed": [{"aktion": "merken", "titel": karte}],
            "unlisted": [{"aktion": "weg", "titel": karte}]}.get(art, [])


def ereignis_von(wunsch):
    """sehen.aendern-Wunsch -> mHub-PlaybackEvent fuer fremde Tracker (None, wenn es keins gibt)."""
    if not isinstance(wunsch, dict):
        return None
    titel = wunsch.get("titel") if isinstance(wunsch.get("titel"), dict) else {}
    kennung = str(titel.get("id") or "")
    if not kennung.startswith("tt"):
        return None
    typ = "series" if titel.get("typ") == "series" else "video"
    item = {"type": typ, "ids": {"imdb": kennung}}
    video = str(wunsch.get("video") or kennung)
    if typ == "series":
        teile = video.split(":")
        if len(teile) >= 3 and teile[-1].isdigit() and teile[-2].isdigit():
            item["season"], item["episode"] = int(teile[-2]), int(teile[-1])
    art = {"merken": "listed", "weg": "unlisted", "gesehen": "watched", "verlauf_weg": "unwatched",
           "weiterschauen_weg": "reset", "fortschritt": "progress"}.get(wunsch.get("aktion"))
    if not art:
        return None
    ereignis = {"type": art, "item": item}
    if art == "progress":
        anteil = wunsch.get("anteil")
        if anteil is None:
            try:
                anteil = float(wunsch.get("position") or 0) / float(wunsch.get("dauer") or 0)
            except (TypeError, ValueError, ZeroDivisionError):
                return None
        try:
            ereignis["progress"] = max(0, min(100, int(round(float(anteil) * 100))))
        except (TypeError, ValueError):
            return None
        ereignis["playing"] = False
    return ereignis


def stand(listen):
    """Der ganze Stand eines Profils als PlaybackSnapshot-Eintraege (Weiterschauen, Verlauf, Merkliste)."""
    eintraege = {}

    def eintrag(k):
        ids = ids_von(k["id"])
        if not ids:
            return None
        e = eintraege.setdefault((k["typ"], k["id"]), {"type": TYP_MHUB[k["typ"]], "ids": ids, "name": k["titel"],
                                                     "watched": False, "listed": False})
        if k["id"].startswith(ID_PRAEFIX):
            e["id"] = k["id"]  # eigene Treffer kann die App hier oeffnen (/item/…)
        if k.get("poster") and "images" not in e:
            e["images"] = {"poster": k["poster"]}
        return e

    for w in listen["weiterschauen"]:
        e = eintrag(w)
        if e is not None:
            e["progress"] = max(1, min(99, int(round(float(w.get("anteil") or 0) * 100))))
            teile = w["video"].split(":")
            if w["typ"] == "series" and len(teile) >= 3 and teile[-1].isdigit() and teile[-2].isdigit():
                e["season"], e["episode"] = int(teile[-2]), int(teile[-1])
    for k in listen["verlauf"]:
        e = eintrag(k)
        if e is not None:
            e["watched"] = True
    for k in listen["merkliste"]:
        e = eintrag(k)
        if e is not None:
            e["listed"] = True
    return list(eintraege.values())


def zustand(listen, typ, stremio_id):
    """PlaybackState eines Titels fuer Katalog und Details (gesehen, auf der Liste, wie weit)."""
    schluessel = (typ, str(stremio_id).split(":")[0] if not str(stremio_id).startswith(ID_PRAEFIX) else stremio_id)
    z = {"watched": any((k["typ"], k["id"]) == schluessel for k in listen["verlauf"]),
         "listed": any((k["typ"], k["id"]) == schluessel for k in listen["merkliste"])}
    for w in listen["weiterschauen"]:
        if (w["typ"], w["id"]) == schluessel:
            z["progress"] = max(1, min(99, int(round(float(w.get("anteil") or 0) * 100))))
    return z


# --- v1-Bruecke: v2-Antworten fuer alte MediaHubMX-Clients -----------------------------------------
def _v1_ids(ids, episode):
    """ids/episode einer v1-Anfrage -> Kandidaten in mHub-Schreibweise (imdb:tt..., rz:...)."""
    ids = ids if isinstance(ids, dict) else {}
    staffel = episode.get("season") if isinstance(episode, dict) else None
    folge = episode.get("episode") if isinstance(episode, dict) else None
    suffix = ":%s:%s" % (staffel, folge) if isinstance(staffel, int) and isinstance(folge, int) else ""
    ergebnis = []

    def dazu(wert):
        wert = str(wert or "")
        if wert.startswith("tt"):
            wert = "imdb:" + wert
        if wert and wert not in ergebnis:
            ergebnis.append(wert)

    if ids.get("id"):
        dazu(str(ids["id"]) + suffix)
    for key, wert in ids.items():
        if key == "id" or wert in (None, ""):
            continue
        name = key[:-3] if key.endswith("_id") else key
        dazu("%s:%s%s" % (name, wert, suffix))
    if suffix:
        for wert in list(ergebnis):
            if wert.endswith(suffix):
                dazu(wert[:-len(suffix)])
    return ergebnis


def v1_manifest(m):
    """Manifest v2 -> v1 (mediahubmx.json): Aktionen, itemTypes, Kataloge."""
    ressourcen = [r for r in ("catalog", "item", "source", "subtitle", "resolve") if r in (m.get("resources") or [])]
    typen = {TYP_MHUB.get(t, "movie") for t in m.get("types") or ["video"]}
    if "series" in (m.get("types") or []):
        typen.add("series")
    e = {"id": m.get("id") or "org.rezeptserver", "name": m.get("name") or m.get("id") or "H0rSt",
         "version": m.get("version") or "1.0.0", "sdkVersion": "1.3.2", "actions": ressourcen,
         "itemTypes": sorted(typen or {"movie"})}
    if m.get("description"):
        e["description"] = m["description"]
    if m.get("icon"):
        e["icon"] = m["icon"]
    if m.get("catalogs"):
        e["catalogs"] = [{"id": c["id"], "name": c.get("name") or c["id"], "kind": "vod",
                          "features": {"search": {"enabled": True}}} for c in m["catalogs"]]
    return e


def v1_item(item):
    """mHub-Item -> v1-Item (type movie/series, ids mit id, Bilder, Metadaten)."""
    typ = "series" if item.get("type") == "series" else "movie"
    ids = dict(item.get("ids") or {})
    if item.get("id") and ":" not in str(item["id"]):
        ids["id"] = str(item["id"])
    e = {"type": typ, "name": item.get("name") or item.get("id") or ""}
    if ids:
        e["ids"] = ids
    bilder = item.get("images") if isinstance(item.get("images"), dict) else {}
    if bilder:
        v1_bilder = {}
        if bilder.get("poster"):
            v1_bilder["poster"] = bilder["poster"]
        if isinstance(bilder.get("backdrops"), list) and bilder["backdrops"]:
            v1_bilder["backdrop"] = bilder["backdrops"][0]
        if bilder.get("logo"):
            v1_bilder["logo"] = bilder["logo"]
        if v1_bilder:
            e["images"] = v1_bilder
    if item.get("description"):
        e["description"] = item["description"]
    if item.get("year"):
        e["year"] = item["year"]
    if item.get("genres"):
        e["genres"] = item["genres"]
    if item.get("ratings"):
        e["ratings"] = item["ratings"]
    if item.get("runtime"):
        e["runtime"] = int(item["runtime"]) * 1000
    return e


def v1_catalog(antwort):
    return {"items": [v1_item(i) for i in antwort.get("items") or [] if isinstance(i, dict)],
            "nextCursor": antwort.get("nextCursor")}


def v1_source(s):
    e = {"type": "externalUrl" if s.get("kind") == "website" else "url", "url": s.get("url") or "",
         "name": s.get("name") or "Quelle"}
    if s.get("languages"):
        e["languages"] = s["languages"]
    if s.get("quality"):
        e["quality"] = s["quality"]
    return e


def v1_subtitle(s):
    return {"url": s.get("url") or "", "language": s.get("language") or "unknown",
            "name": s.get("name") or s.get("language") or "Untertitel",
            "type": s.get("format") or "srt"}
