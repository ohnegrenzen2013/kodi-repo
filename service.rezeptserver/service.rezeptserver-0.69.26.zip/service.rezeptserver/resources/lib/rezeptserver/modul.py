"""Module (Rezepte) laden und gegen die Spezifikation pruefen."""

import importlib.util
import json
import logging
import os
import re

from .html_auswahl import AuswahlFehler, zerlege as zerlege_selektor
from .jsonpath import PfadFehler, zerlege

log = logging.getLogger("rezeptserver")

SPEC_VERSIONEN = ("0.1",)
MAX_SCHRITTE = 8
DATENTYPEN = ("anfrage", "treffer", "stream", "metadaten", "untertitel")
ROLLEN = {
    # rolle: (erlaubte Eingaben, erlaubte Ausgaben)
    "finder": (("anfrage",), ("treffer",)),
    "aufloeser": (("treffer",), ("stream",)),
    "anreicherer": (("treffer", "stream"), ("metadaten", "untertitel")),
    "abspieler": (("stream",), ()),
}
BAUSTEINE = ("abruf", "json", "html", "regex", "vorlage", "filter")
EINSTELLUNG_TYPEN = ("text", "passwort", "zahl", "schalter")
_ID = re.compile(r"^[a-z0-9][a-z0-9\-]{0,63}$")


class ModulFehler(ValueError):
    pass


class Modul:
    def __init__(self, daten, ordner):
        self.daten = daten
        self.ordner = ordner
        self.id = daten["id"]
        self.name = daten["name"]
        self.version = daten["version"]
        self.rolle = daten["rolle"]
        self.nimmt = daten["nimmt"]
        gibt = daten["gibt"]
        self.gibt = [gibt] if isinstance(gibt, str) else list(gibt)
        self.passt_zu = daten.get("passt_zu") or {}
        # mehrere Rezepte eines Dienstes teilen sich die Einstellungen ueber konto
        self.konto = daten.get("konto") or self.id
        self.rang = int(daten.get("rang", 50))
        self.einstellungen = daten.get("einstellungen") or []
        darf = daten.get("darf") or {}
        self.netz = list(darf.get("netz") or [])
        self.geheimnisse = list(darf.get("geheimnisse") or [])
        self.speicher = bool(darf.get("speicher", False))
        self.schritte = daten.get("schritte")
        self.skript = daten.get("skript")
        self._skript_funktion = None

    def passt(self, treffer):
        return all(treffer.get(feld) == wert for feld, wert in self.passt_zu.items())

    def sichtbare_einstellungen(self, werte):
        """Einstellungen, die das Modul lesen darf: Passwoerter nur, wenn in darf.geheimnisse."""
        erlaubt = {}
        for feld in self.einstellungen:
            schluessel = feld["key"]
            if feld.get("typ") == "passwort" and schluessel not in self.geheimnisse:
                continue
            if schluessel in werte:
                erlaubt[schluessel] = werte[schluessel]
        return erlaubt

    def fehlende_einstellungen(self, werte):
        """Pflicht-Einstellungen (alle ohne "optional": true), die leer sind oder fehlen."""
        return [f["key"] for f in self.einstellungen
                if not f.get("optional") and str((werte or {}).get(f["key"], "")).strip() == ""]

    def skript_funktion(self):
        if self._skript_funktion is None:
            pfad = os.path.join(self.ordner, self.skript)
            spec = importlib.util.spec_from_file_location("rezept_" + self.id.replace("-", "_"), pfad)
            modul = importlib.util.module_from_spec(spec)
            spec.loader.exec_module(modul)
            if not hasattr(modul, "ausfuehren"):
                raise ModulFehler("%s: Skript hat keine Funktion ausfuehren()" % self.id)
            self._skript_funktion = modul.ausfuehren
        return self._skript_funktion


def pruefe(daten, ordner=None):
    """Gibt eine Liste von Fehlermeldungen zurueck (leer = gueltig)."""
    fehler = []

    def pflicht(feld):
        if feld not in daten:
            fehler.append("Pflichtfeld fehlt: %s" % feld)
            return False
        return True

    if not isinstance(daten, dict):
        return ["manifest.json muss ein JSON-Objekt sein"]
    for feld in ("spec", "id", "name", "version", "rolle", "nimmt", "gibt", "darf"):
        pflicht(feld)
    if fehler:
        return fehler

    if daten["spec"] not in SPEC_VERSIONEN:
        fehler.append("Unbekannte spec-Version: %s" % daten["spec"])
    if not isinstance(daten["id"], str) or not _ID.match(daten["id"]):
        fehler.append("id nur a-z, 0-9 und Bindestrich: %r" % daten["id"])

    if "konto" in daten and (not isinstance(daten["konto"], str) or not _ID.match(daten["konto"])):
        fehler.append("konto nur a-z, 0-9 und Bindestrich: %r" % daten["konto"])

    from .anbieter import ANMELDUNGEN, KATEGORIEN

    if "kategorie" in daten and daten["kategorie"] not in KATEGORIEN:
        fehler.append("Unbekannte kategorie: %s (erlaubt: %s)" % (daten["kategorie"], ", ".join(KATEGORIEN)))
    if "anmeldung" in daten and daten["anmeldung"] not in ANMELDUNGEN:
        fehler.append("Unbekannte anmeldung: %s (erlaubt: %s)" % (daten["anmeldung"], ", ".join(ANMELDUNGEN)))

    rolle = daten["rolle"]
    if rolle not in ROLLEN:
        fehler.append("Unbekannte rolle: %s" % rolle)
    else:
        eingaben, ausgaben = ROLLEN[rolle]
        if daten["nimmt"] not in eingaben:
            fehler.append("rolle %s nimmt nur %s, nicht %s" % (rolle, "/".join(eingaben), daten["nimmt"]))
        gibt = daten["gibt"] if isinstance(daten["gibt"], list) else [daten["gibt"]]
        for typ in gibt:
            if typ not in ausgaben:
                fehler.append("rolle %s gibt nur %s, nicht %s" % (rolle, "/".join(ausgaben) or "nichts", typ))

    darf = daten["darf"]
    if not isinstance(darf, dict):
        fehler.append("darf muss ein Objekt sein")
        darf = {}
    namen = set()
    for feld in daten.get("einstellungen") or []:
        if not isinstance(feld, dict) or "key" not in feld:
            fehler.append("Jede Einstellung braucht ein key")
            continue
        namen.add(feld["key"])
        if feld.get("typ", "text") not in EINSTELLUNG_TYPEN:
            fehler.append("Unbekannter Einstellungstyp: %s" % feld.get("typ"))
    for geheimnis in darf.get("geheimnisse") or []:
        if geheimnis not in namen:
            fehler.append("darf.geheimnisse nennt unbekannte Einstellung: %s" % geheimnis)

    hat_schritte = "schritte" in daten
    hat_skript = "skript" in daten
    if hat_schritte == hat_skript:
        fehler.append("Genau eines von schritte oder skript angeben")
    if hat_schritte:
        schritte = daten["schritte"]
        if not isinstance(schritte, list) or not schritte:
            fehler.append("schritte muss eine nicht leere Liste sein")
        else:
            if len(schritte) > MAX_SCHRITTE:
                fehler.append("Hoechstens %d Schritte, mehr nur ueber skript (hier: %d)"
                              % (MAX_SCHRITTE, len(schritte)))
            for nummer, schritt in enumerate(schritte, 1):
                fehler.extend(_pruefe_schritt(nummer, schritt, darf))
    if hat_skript:
        if ordner and not os.path.isfile(os.path.join(ordner, daten["skript"])):
            fehler.append("Skriptdatei fehlt: %s" % daten["skript"])
    return fehler


def _pruefe_schritt(nummer, schritt, darf):
    if not isinstance(schritt, dict) or len(schritt) != 1:
        return ["Schritt %d: genau ein Baustein pro Schritt" % nummer]
    (name, param), = schritt.items()
    if name not in BAUSTEINE:
        return ["Schritt %d: unbekannter Baustein %s" % (nummer, name)]
    if not isinstance(param, dict):
        return ["Schritt %d: Parameter von %s muessen ein Objekt sein" % (nummer, name)]
    fehler = []
    if name == "abruf":
        if "url" not in param:
            fehler.append("Schritt %d: abruf braucht url" % nummer)
        if not darf.get("netz"):
            fehler.append("Schritt %d: abruf ohne darf.netz" % nummer)
    if name == "json":
        pfade = list((param.get("felder") or {}).values())
        if param.get("liste"):
            pfade.append(param["liste"])
        for pfad in pfade:
            try:
                zerlege(pfad[1:] if isinstance(pfad, str) and pfad.startswith("$$") else pfad)
            except PfadFehler as e:
                fehler.append("Schritt %d: %s" % (nummer, e))
    if name == "html":
        angaben = [a.partition("@")[0] for a in (param.get("felder") or {}).values()]
        if param.get("liste"):
            angaben.append(param["liste"])
        for selektor in angaben:
            if not selektor.strip():
                continue
            try:
                zerlege_selektor(selektor)
            except AuswahlFehler as e:
                fehler.append("Schritt %d: %s" % (nummer, e))
    if name in ("json", "html") and param.get("max") is not None and not isinstance(param["max"], int):
        fehler.append("Schritt %d: max muss eine ganze Zahl sein" % nummer)
    if name == "regex":
        try:
            re.compile(param.get("muster", ""))
        except re.error as e:
            fehler.append("Schritt %d: Muster ungueltig: %s" % (nummer, e))
    if name == "filter":
        wenn = param.get("wenn")
        bedingungen = wenn if isinstance(wenn, list) else [wenn]
        if not wenn or not all(isinstance(b, dict) for b in bedingungen):
            fehler.append("Schritt %d: filter braucht wenn (Bedingung oder Liste)" % nummer)
        for b in bedingungen:
            for schluessel in ("muster", "nicht_muster"):
                if isinstance(b, dict) and schluessel in b:
                    try:
                        re.compile(b[schluessel])
                    except re.error as e:
                        fehler.append("Schritt %d: %s ungueltig: %s" % (nummer, schluessel, e))
    return fehler


def lade_ordner(ordner):
    """Laedt alle Module aus Unterordnern. Ungueltige werden protokolliert und uebersprungen."""
    module = []
    if not os.path.isdir(ordner):
        log.warning("Rezept-Ordner fehlt: %s", ordner)
        return module
    gesehen = set()
    for name in sorted(os.listdir(ordner)):
        unterordner = os.path.join(ordner, name)
        datei = os.path.join(unterordner, "manifest.json")
        if not os.path.isfile(datei):
            continue
        try:
            with open(datei, encoding="utf-8") as f:
                daten = json.load(f)
        except (OSError, ValueError) as e:
            log.error("%s: nicht lesbar: %s", datei, e)
            continue
        fehler = pruefe(daten, unterordner)
        if fehler:
            log.error("%s ungueltig:\n  %s", datei, "\n  ".join(fehler))
            continue
        if daten["id"] in gesehen:
            log.error("%s: id %s doppelt, uebersprungen", datei, daten["id"])
            continue
        gesehen.add(daten["id"])
        modul = Modul(daten, unterordner)
        if modul.skript:
            log.warning("%s nutzt ein Skript. Skripte koennen die Berechtigungen umgehen, "
                        "nur aus vertrauenswuerdiger Quelle installieren.", modul.id)
        module.append(modul)
    log.info("%d Module geladen: %s", len(module), ", ".join(m.id for m in module))
    return module
