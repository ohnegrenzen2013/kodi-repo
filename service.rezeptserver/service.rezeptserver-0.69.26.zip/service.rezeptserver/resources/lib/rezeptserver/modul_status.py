"""Status der Module: Sollzustand, Istzustand und strukturelle Gesundheit.

Das Register (`modulregister.py`) sagt, welche Module und Tabs es gibt. Die
Navigation in den Nutzerdaten sagt, was angedockt ist. Dieser Bericht führt
beides zusammen und meldet Abweichungen – die Grundlage für `/api/module/status`.

Die Prüfung ist bewusst schlank und ohne neue Abhängigkeit: Sie liest nur
Register, Navigation und die Rezept-Manifeste. Ob eine Quelle erreichbar ist,
prüfen die Module selbst (Dienste, Wächter, Aktualisierung).
"""

from . import __version__, einstellungen, modulregister


def _nav_an(werte):
    """Tab-ID -> angedockt? Fehlerhafte Daten fallen auf die Standardnavigation zurück."""
    return {eintrag["id"]: eintrag.get("an") is not False for eintrag in (werte or {}).get("navigation", [])}


def bericht(daten=None, werte=None):
    """Alles, was die Oberflaeche und der Admin ueber die Module wissen muessen.

    Ohne `werte` gelten die gemeinsamen Einstellungen aus `daten`; die Oberflaeche uebergibt
    die bereits mit den Profilwerten zusammengefuehrten Werte (`_einstellungen_lesen()`).
    """
    register = modulregister.pruefe()
    if werte is None:
        try:
            werte = einstellungen.pruefe((daten or {}).get(einstellungen.SCHLUESSEL))
        except einstellungen.EinstellungsFehler:
            werte = {}
    nav_an = _nav_an(werte)
    module = []
    for eintrag in modulregister.module():
        tabs = list(eintrag["tabs"])
        tabs_an = [tab for tab in tabs if nav_an.get(tab, True)]
        module.append({
            "id": eintrag["id"],
            "name": eintrag["name"],
            "symbol": eintrag.get("symbol") or "",
            "welt": eintrag["welt"],
            "welt_name": eintrag["welt_name"],
            "tabs": tabs,
            "tabs_an": tabs_an,
            "tabs_aus": [tab for tab in tabs if tab not in tabs_an],
            "an": all(nav_an.get(tab, True) for tab in tabs),
            "standard": bool(eintrag.get("standard")),
            "nur_app": bool(eintrag.get("nur_app")),
            "assistent": eintrag.get("assistent") or "",
        })
    return {"version": __version__, "gesund": register["gesund"], "reconcile": register, "module": module,
            "tab_namen": dict(einstellungen.NAV)}
