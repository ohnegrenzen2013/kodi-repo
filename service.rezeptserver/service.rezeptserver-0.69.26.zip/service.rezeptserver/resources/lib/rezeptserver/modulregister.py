"""Modulregister: eine Quelle für Module, Tabs und ihre Beziehungen.

H0rSt ist ein Modul-Host: Jedes Modul bringt Reiter mit, der Baukasten dockt sie an
oder ab. Die Listen stehen heute in `baukasten.WELTEN` und `einstellungen.NAV`.
Dieses Register liest beide, prüft ihre Beziehungen und liefert den Baukasten-
Modulen ihre Welt. Es ändert nichts am Verhalten; es macht Abweichungen sichtbar.

Kubernetes-Analogie (bewusst schlank, ohne neue Laufzeitabhängigkeit):

  * Sollzustand  = Module + Tabs (dieses Register)
  * Reconcile    = fehlende Tabs ergänzt die Navigation (`navigation_pruefe`)
  * Labels       = Welten (`sehen`, `laden`, `zuhause`, `schutz`) und Gruppen (`g:*`)
  * Health       = strukturelle Prüfung: jeder Modultab existiert, jeder Tab gehört
                   zu genau einem Modul, keine doppelten IDs
  * Rollout      = atomarer Ordner-Tausch in `webhosting`, `arvio_web`,
                   `aktualisierung` und `kodi_addons`

Neue Module werden weiterhin in `baukasten.WELTEN` angelegt; das Register meldet,
wenn ein Tab dort fehlt oder doppelt vergeben ist.
"""

from . import baukasten, einstellungen


class RegisterFehler(ValueError):
    """Das Register passt nicht zur Navigation."""


def module():
    """Alle Module mit ihrer Welt, in der Reihenfolge des Baukastens."""
    ergebnis = []
    for welt in baukasten.WELTEN:
        for eintrag in welt["module"]:
            ergebnis.append(dict(eintrag, welt=welt["id"], welt_name=welt["name"]))
    return ergebnis


def tab_besitzer():
    """Tab -> Liste der Modul-IDs, die ihn beanspruchen."""
    ergebnis = {}
    for eintrag in module():
        for tab in eintrag["tabs"]:
            ergebnis.setdefault(tab, []).append(eintrag["id"])
    return ergebnis


def ueberschriften():
    """Reine Überschriften der Navigation (`g:…`)."""
    return {tab for tab, _name in einstellungen.NAV if tab.startswith("g:")}


def pruefe():
    """Vergleicht Module und Navigation; liefert Befunde als Datenstruktur."""
    alle = module()
    ids = [eintrag["id"] for eintrag in alle]
    besitzer = tab_besitzer()
    nav = [tab for tab, _name in einstellungen.NAV]
    fest = set(baukasten.FEST) | ueberschriften()
    fehler = []

    doppelte_module = sorted({i for i in ids if ids.count(i) > 1})
    doppelte_tabs = {tab: namen for tab, namen in besitzer.items() if len(namen) > 1}
    module_ohne_tabs = [eintrag["id"] for eintrag in alle if not eintrag["tabs"]]
    fehlende_tabs = sorted(tab for tab in besitzer if tab not in nav)
    unbekannte_tabs = sorted(tab for tab in nav if tab not in besitzer and tab not in fest)

    if doppelte_module:
        fehler.append("Doppelte Modul-IDs: %s" % ", ".join(doppelte_module))
    for tab, namen in sorted(doppelte_tabs.items()):
        fehler.append("Tab %s gehört zu mehreren Modulen: %s" % (tab, ", ".join(namen)))
    if module_ohne_tabs:
        fehler.append("Module ohne Tab: %s" % ", ".join(module_ohne_tabs))
    if fehlende_tabs:
        fehler.append("Tabs fehlen in der Navigation: %s" % ", ".join(fehlende_tabs))
    if unbekannte_tabs:
        fehler.append("Tabs ohne Modul: %s" % ", ".join(unbekannte_tabs))

    return {"module": len(alle), "tabs": len(nav), "doppelte_module": doppelte_module,
            "doppelte_tabs": doppelte_tabs, "module_ohne_tabs": module_ohne_tabs,
            "fehlende_tabs": fehlende_tabs, "unbekannte_tabs": unbekannte_tabs,
            "gesund": not fehler, "fehler": fehler}
