"""MT Manager 2.26.11: Style-Eckdaten und MCP-Preset.

MT Manager (bin.mt.plus, Lin Jin Bin, proprietaer) bietet seit 2.26.10/2.26.11
einen lokalen MCP-Dienst (APK MCP) auf Port 8787 unter /mcp. H0rSt verbindet
sich als MCP-Client und kann die angebotenen Datei-, ZIP- und APK-Werkzeuge
nutzen. Es wird kein MT-Code uebernommen und keine APK mitgeliefert.
"""

NAME = "MT Manager"
STAND = "2.26.11"
PAKET = "bin.mt.plus"
LIZENZ = "proprietaer"
URL = "https://mt2.cn/download/"
APK_SEITE = "https://pan.mt2.cn/apk/26110366"
MCP_URL = "http://127.0.0.1:8787/mcp"
MCP_NAME = "MT Manager"
HOME = "/storage/emulated/0/MT2/mcp"
PORT = 8787
WERKZEUGE = [
    ("Dateien", "Verzeichnisse browsen, Dateiinfo lesen, Text/Binaer lesen und schreiben, Ordner anlegen, kopieren, verschieben, loeschen."),
    ("APK", "App-Info, Manifest, Ressourcen, Layouts, Strings, Dex/Smali und SO-Bibliotheken lesen; unterstuetzte Aenderungen bauen, optional signieren und in 2.26.11 installieren."),
    ("ZIP", "Archiv browsen, Eintraege lesen/erstellen/ersetzen, entpacken und pruefen; seit 2.26.10."),
    ("Transfer", "Dateien zwischen Geraeten ueber den MCP-Dienst hoch- und herunterladen; seit 2.26.11."),
]
FARBEN = {"blau": ("#5b85fa", "#ffffff"), "gold": ("#ecb82b", "#121315"),
          "violett": ("#9c6bff", "#ffffff"), "gruen": ("#4caf50", "#ffffff")}


def preset(werte=None):
    """MCP-Konfiguration fuer den vorhandenen H0rSt-MCP-Client."""
    w = werte if isinstance(werte, dict) else {}
    return {"mcp_server_url": str(w.get("mt_url") or MCP_URL).strip()[:300],
            "mcp_server_name": MCP_NAME,
            "mcp_server_heimnetz_erlaubt": True,
            "mt_an": True}


def zustand(werte=None, mcp=None):
    w = werte if isinstance(werte, dict) else {}
    m = mcp if isinstance(mcp, dict) else {}
    return {"name": NAME, "stand": STAND, "paket": PAKET, "lizenz": LIZENZ, "url": URL,
            "apk_seite": str(w.get("mt_apk_url") or APK_SEITE), "mcp_url": str(w.get("mt_url") or MCP_URL),
            "mcp_name": m.get("name") or MCP_NAME, "mcp_verbunden": bool(m.get("url")),
            "heimnetz_erlaubt": bool(m.get("heimnetz_erlaubt")),
            "werkzeuge": [{"name": n, "text": t} for n, t in WERKZEUGE],
            "farben": dict(FARBEN),
            "an": w.get("mt_an") is True}
