"""SoundCloud und Mixcloud: Suche, eigene Reihen aus Profilen/Playlists/Sets, Wiedergabe NUR ueber die offiziellen Player-Widgets.

Mixcloud   api.mixcloud.com (Lesen ohne Konto: search, <user>/cloudcasts, <user>/playlists/<slug>/cloudcasts) - developers:
           https://www.mixcloud.com/developers/. Audio-Streams gibt die API absichtlich NICHT heraus (Lizenz/Abrechnung): Abspielen
           geht nur ueber das Widget player-widget.mixcloud.com (hier: eingebettet, nicht nachgebaut).
SoundCloud oEmbed/Widget (w.soundcloud.com/player) brauchen keinen Schluessel; die SUCHE verlangt eigene API-Zugangsdaten
           (client_id/client_secret der eigenen App, Client-Credentials-Ablauf, https://developers.soundcloud.com/docs/api).
           Sie liegen nur in den Nutzerdaten ("musik"), erscheinen nie in Antworten, Protokoll oder Fehlertext. Abgespielt wird
           ueber das Widget; stream_url/Rip-Umwege gibt es hier nicht.
Eigene Reihen: Nutzerdaten "musik_reihen" {profil-id oder "": [{id, name, quelle, art, url}]} - gespeichert wird nur die Adresse.
Kinderprofile: /api/musik ist in der Kinder-Positivliste nicht enthalten, also gesperrt.
"""

import json
import re
import secrets
import threading
import time
from urllib.parse import urlencode, urlsplit

SCHLUESSEL, REIHEN = "musik", "musik_reihen"
MAX_REIHEN, MAX_NAME, MAX_TREFFER = 20, 60, 25
_MC_PART = r"[A-Za-z0-9_.-]{1,80}"
_MC_KEY = re.compile(r"^/(%s)/((?:playlists/)?%s)?/?$" % (_MC_PART, _MC_PART))
_SC_PART = r"[A-Za-z0-9_-]{1,100}"
_SC_PFAD = re.compile(r"^/(%s)(?:/(sets/%s|%s))?(?:/%s)?/?$" % (_SC_PART, _SC_PART, _SC_PART, _SC_PART))
MC_HOSTS, SC_HOSTS = {"mixcloud.com", "www.mixcloud.com"}, {"soundcloud.com", "www.soundcloud.com", "m.soundcloud.com"}


class MusikFehler(ValueError):
    pass


def _text(w, g=200):
    return " ".join(str(w or "").split())[:g]


def _bild(url):
    u = str(url or "")
    return u if re.match(r"^https://[\w.-]+\.(?:mixcloud\.com|sndcdn\.com|soundcloud\.com|mixcloud-static\.com)/", u) else ""


def mixcloud_pfad(text):
    """Mixcloud-Adresse -> (art, schluessel). art: user, show, playlist. Sonst MusikFehler."""
    roh = _text(text, 300)
    if not re.match(r"^https?://", roh, re.I):
        roh = "https://" + roh
    try:
        u = urlsplit(roh)
    except ValueError:
        raise MusikFehler("Keine Mixcloud-Adresse")
    if u.scheme not in ("http", "https") or (u.hostname or "").lower() not in MC_HOSTS:
        raise MusikFehler("Das ist keine Mixcloud-Adresse (mixcloud.com/Nutzer/…)")
    teile = [t for t in u.path.split("/") if t]
    if not teile or not all(re.fullmatch(_MC_PART, t) for t in teile) or teile[0] in ("discover", "search", "popular", "live", "genres"):
        raise MusikFehler("Diese Mixcloud-Adresse zeigt weder ein Profil noch eine Show noch eine Playlist")
    if len(teile) == 1:
        return "user", "/%s/" % teile[0]
    if len(teile) == 2 and teile[1] not in ("playlists", "favorites", "listens", "uploads", "stream", "followers", "following"):
        return "show", "/%s/%s/" % tuple(teile)
    if len(teile) == 3 and teile[1] == "playlists":
        return "playlist", "/%s/playlists/%s/" % (teile[0], teile[2])
    if len(teile) == 2 and teile[1] in ("uploads",):
        return "user", "/%s/" % teile[0]
    raise MusikFehler("Diese Mixcloud-Adresse zeigt weder ein Profil noch eine Show noch eine Playlist")


def mixcloud_widget(schluessel, spielen=True):
    if not re.match(r"^/[A-Za-z0-9_.-]{1,80}/(?:playlists/)?[A-Za-z0-9_.-]{1,80}/$", str(schluessel or "")):
        raise MusikFehler("Nur einzelne Shows und Playlists lassen sich im Widget abspielen")
    return "https://player-widget.mixcloud.com/widget/iframe/?" + urlencode({"hide_cover": 1, "light": 0, "autoplay": 1 if spielen else 0, "feed": schluessel})


def soundcloud_adresse(text):
    """SoundCloud-Adresse -> (art, adresse): track, set oder user. Sonst MusikFehler."""
    roh = _text(text, 300)
    if not re.match(r"^https?://", roh, re.I):
        roh = "https://" + roh
    try:
        u = urlsplit(roh)
    except ValueError:
        raise MusikFehler("Keine SoundCloud-Adresse")
    if u.scheme not in ("http", "https") or (u.hostname or "").lower() not in SC_HOSTS:
        raise MusikFehler("Das ist keine SoundCloud-Adresse (soundcloud.com/Nutzer/…; Kurzlinks on.soundcloud.com bitte aufloesen)")
    teile = [t for t in u.path.split("/") if t]
    if not teile or not all(re.fullmatch(r"[A-Za-z0-9_-]{1,100}", t) for t in teile) or teile[0] in ("discover", "search", "stream", "charts", "you", "upload", "pages"):
        raise MusikFehler("Diese SoundCloud-Adresse zeigt weder ein Profil noch einen Titel noch ein Set")
    if len(teile) == 1:
        return "user", "https://soundcloud.com/%s" % teile[0]
    if len(teile) == 3 and teile[1] == "sets":
        return "set", "https://soundcloud.com/%s/sets/%s" % (teile[0], teile[2])
    if len(teile) == 2 and teile[1] not in ("sets", "tracks", "albums", "reposts", "likes", "following", "followers", "popular-tracks"):
        return "track", "https://soundcloud.com/%s/%s" % tuple(teile)
    raise MusikFehler("Diese SoundCloud-Adresse zeigt weder ein Profil noch einen Titel noch ein Set")


def soundcloud_widget(adresse, spielen=True):
    art, sauber = soundcloud_adresse(adresse)
    return "https://w.soundcloud.com/player/?" + urlencode({"url": sauber, "auto_play": "true" if spielen else "false", "show_comments": "false",
                                                           "visual": "true" if art != "track" else "false", "hide_related": "true"})


def mixcloud_lesen(text):
    try:
        d = json.loads(text)
    except (ValueError, TypeError):
        raise MusikFehler("Antwort von Mixcloud ist kein JSON")
    if not isinstance(d, dict) or d.get("error"):
        raise MusikFehler("Mixcloud: %s" % _text(((d or {}).get("error") or {}).get("message") if isinstance(d, dict) and isinstance(d.get("error"), dict) else "Fehler", 80))
    liste = []
    for e in d.get("data") or []:
        if not isinstance(e, dict):
            continue
        key = str(e.get("key") or "")
        bilder = e.get("pictures") if isinstance(e.get("pictures"), dict) else {}
        user = e.get("user") if isinstance(e.get("user"), dict) else {}
        try:
            kein = mixcloud_pfad("https://www.mixcloud.com" + key)
        except MusikFehler:
            continue
        liste.append({"quelle": "mixcloud", "art": kein[0], "titel": _text(e.get("name") or e.get("username")), "von": _text(user.get("name") or user.get("username") or e.get("username"), 60),
                      "dauer": int(e.get("audio_length") or 0), "bild": _bild(bilder.get("medium") or bilder.get("large") or bilder.get("320wx320h")),
                      "adresse": "https://www.mixcloud.com" + key, "schluessel": key, "spielbar": kein[0] in ("show", "playlist")})
        if len(liste) >= MAX_TREFFER:
            break
    return liste


def soundcloud_lesen(text):
    try:
        d = json.loads(text)
    except (ValueError, TypeError):
        raise MusikFehler("Antwort von SoundCloud ist kein JSON")
    roh = d.get("collection") if isinstance(d, dict) else d
    if isinstance(d, dict) and not roh and (d.get("tracks") or d.get("kind")):
        roh = d.get("tracks") or [d]
    liste = []
    for e in roh or []:
        if not isinstance(e, dict):
            continue
        try:
            art, adresse = soundcloud_adresse(e.get("permalink_url"))
        except MusikFehler:
            continue
        user = e.get("user") if isinstance(e.get("user"), dict) else {}
        liste.append({"quelle": "soundcloud", "art": art, "titel": _text(e.get("title") or e.get("username")), "von": _text(user.get("username") or e.get("username"), 60),
                      "dauer": int(e.get("duration") or 0) // 1000, "bild": _bild(e.get("artwork_url") or e.get("avatar_url")), "adresse": adresse,
                      "schluessel": "", "spielbar": art in ("track", "set")})
        if len(liste) >= MAX_TREFFER:
            break
    return liste


def zugang(daten):
    s = ((daten or {}).get(SCHLUESSEL) or {}).get("soundcloud") or {}
    return str(s.get("client_id") or "").strip(), str(s.get("client_secret") or "").strip()


def zugang_einstellen(daten, client_id, client_secret):
    i, s = _text(client_id, 100), _text(client_secret, 100)
    if (i or s) and not (re.fullmatch(r"[\w-]{16,100}", i) and re.fullmatch(r"[\w-]{16,100}", s)):
        raise MusikFehler("client_id und client_secret deiner SoundCloud-App (nur Buchstaben, Ziffern, - und _)")
    daten.setdefault(SCHLUESSEL, {})["soundcloud"] = {"client_id": i, "client_secret": s} if i else {}
    return {"gesetzt": bool(i)}


def reihen_lesen(daten, profil):
    r = ((daten or {}).get(REIHEN) or {}).get(profil or "")
    return [x for x in r if isinstance(x, dict)] if isinstance(r, list) else []


def reihe_anlegen(daten, profil, name, adresse):
    """Neue Reihe aus einer Mixcloud-/SoundCloud-Adresse (Profil, Playlist, Set oder Show/Titel)."""
    name = _text(name, MAX_NAME)
    adresse = _text(adresse, 300)
    try:
        art, ziel = mixcloud_pfad(adresse)
        quelle, url = "mixcloud", "https://www.mixcloud.com" + ziel
    except MusikFehler:
        art, url = soundcloud_adresse(adresse)
        quelle = "soundcloud"
    alle = daten.setdefault(REIHEN, {}).setdefault(profil or "", [])
    if len(alle) >= MAX_REIHEN:
        raise MusikFehler("Höchstens %d Musik-Reihen" % MAX_REIHEN)
    if any(r.get("url") == url for r in alle):
        raise MusikFehler("Diese Reihe gibt es schon")
    neu = {"id": secrets.token_hex(4), "name": name or url.rsplit("/", 2)[-2 if url.endswith("/") else -1], "quelle": quelle, "art": art, "url": url}
    alle.append(neu)
    return neu


def reihe_loeschen(daten, profil, rid):
    alle = daten.setdefault(REIHEN, {}).setdefault(profil or "", [])
    vorher = len(alle)
    alle[:] = [r for r in alle if r.get("id") != rid]
    if len(alle) == vorher:
        raise MusikFehler("Reihe nicht gefunden")
    return {"ok": True}


class Musik:
    def __init__(self, holen=None, uhr=time.time):
        self._holen, self.uhr = holen, uhr
        self._token, self._sperre = None, threading.Lock()
        self._gebremst = []

    def _abruf(self, url, hosts, header=None, methode="GET", daten=None, basic=None):
        from .netz import Abrufer, NetzFehler, oeffentlich_holen, urllib_holen
        try:
            return Abrufer(hosts, holen=self._holen or oeffentlich_holen(urllib_holen), zeitgrenze=12.0).abruf(url, methode, header, daten, basic)
        except NetzFehler as fehler:
            raise MusikFehler("Nicht erreichbar: %s" % _text(str(fehler).split(" bei ")[0], 60))

    def _bremse(self):
        jetzt = self.uhr()
        self._gebremst = [t for t in self._gebremst if jetzt - t < 60]
        if len(self._gebremst) >= 30:
            raise MusikFehler("Bitte einen Moment warten (höchstens 30 Abfragen je Minute)")
        self._gebremst.append(jetzt)

    # Mixcloud
    def mixcloud_suche(self, text, art="cloudcast"):
        q = _text(text, 100)
        if len(q) < 2:
            raise MusikFehler("Suchbegriff zu kurz")
        if art not in ("cloudcast", "user"):
            raise MusikFehler("Unbekannte Art")
        self._bremse()
        return mixcloud_lesen(self._abruf("https://api.mixcloud.com/search/?" + urlencode({"q": q, "type": art, "limit": MAX_TREFFER}), ["api.mixcloud.com"]))

    def mixcloud_reihe(self, art, schluessel):
        if art == "user":
            url = "https://api.mixcloud.com" + schluessel + "cloudcasts/?limit=%d" % MAX_TREFFER
        elif art == "playlist":
            url = "https://api.mixcloud.com" + schluessel + "cloudcasts/?limit=%d" % MAX_TREFFER
        else:
            url = "https://api.mixcloud.com" + schluessel
            self._bremse()
            e = json.loads(self._abruf(url, ["api.mixcloud.com"]) or "{}")
            return mixcloud_lesen(json.dumps({"data": [e]}))
        self._bremse()
        return mixcloud_lesen(self._abruf(url, ["api.mixcloud.com"]))

    # SoundCloud
    def _token_holen(self, daten):
        i, s = zugang(daten)
        if not i or not s:
            raise MusikFehler("Für die SoundCloud-Suche zuerst die eigenen API-Zugangsdaten eintragen")
        with self._sperre:
            if self._token and self._token[1] > self.uhr() + 60 and self._token[2] == i:
                return self._token[0]
        try:
            antwort = json.loads(self._abruf("https://secure.soundcloud.com/oauth/token", ["secure.soundcloud.com"], {"Accept": "application/json; charset=utf-8",
                                 "Content-Type": "application/x-www-form-urlencoded"}, "POST", "grant_type=client_credentials", basic=(i, s)))
        except ValueError:
            raise MusikFehler("SoundCloud: Anmeldung unverständlich beantwortet")
        except MusikFehler as f:
            raise MusikFehler(str(f).replace(s, "***").replace(i, "***"))
        token = str(antwort.get("access_token") or "")
        if not token:
            raise MusikFehler("SoundCloud lehnt die Zugangsdaten ab")
        with self._sperre:
            self._token = (token, self.uhr() + int(antwort.get("expires_in") or 3000), i)
        return token

    def soundcloud_suche(self, daten, text):
        q = _text(text, 100)
        if len(q) < 2:
            raise MusikFehler("Suchbegriff zu kurz")
        token = self._token_holen(daten)
        self._bremse()
        url = "https://api.soundcloud.com/tracks?" + urlencode({"q": q, "access": "playable", "limit": MAX_TREFFER, "linked_partitioning": "true"})
        return soundcloud_lesen(self._abruf(url, ["api.soundcloud.com"], {"Authorization": "OAuth " + token, "Accept": "application/json; charset=utf-8"}))

    def soundcloud_reihe(self, daten, art, adresse):
        """Titel eines Sets/Profils (mit eigener API-Anmeldung); ohne Zugangsdaten ein einzelner Eintrag fuer das ganze Set im Widget."""
        einzel = [{"quelle": "soundcloud", "art": art, "titel": adresse.rsplit("/", 1)[-1], "von": "", "dauer": 0, "bild": "", "adresse": adresse, "schluessel": "",
                   "spielbar": art in ("track", "set")}]
        if art == "track" or not all(zugang(daten)):
            return einzel
        token = self._token_holen(daten)
        self._bremse()
        kopf = {"Authorization": "OAuth " + token, "Accept": "application/json; charset=utf-8"}
        try:
            d = json.loads(self._abruf("https://api.soundcloud.com/resolve?" + urlencode({"url": adresse}), ["api.soundcloud.com"], kopf))
        except ValueError:
            return einzel
        if art == "user" and isinstance(d, dict) and d.get("id"):
            self._bremse()
            return soundcloud_lesen(self._abruf("https://api.soundcloud.com/users/%d/tracks?limit=%d&linked_partitioning=true" % (int(d["id"]), MAX_TREFFER),
                                                ["api.soundcloud.com"], kopf)) or einzel
        return soundcloud_lesen(json.dumps(d)) or einzel
