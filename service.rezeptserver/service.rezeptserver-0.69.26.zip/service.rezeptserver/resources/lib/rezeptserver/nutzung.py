"""Nutzung je Profil wie in einer Foren-Mitgliederliste: Traffic, Anfragen, Verbindungen, Zeit – und Grenzen.

  * Jede HTTP-Anfrage wird dem Profil ihrer Sitzung zugerechnet (ohne Profil: "" = Gaeste, Stremio, Fernseher …):
    gesendete und empfangene Bytes, Anzahl, Dauer, neue Verbindungen, zuletzt gesehen, dazu je Tag (35 Tage).
  * Bereiche (Reiter, Stremio-Addon, Medienserver …) zaehlen Besuche und Anfragen -> Rangliste der Top-Bereiche.
  * Module (Anbieter der Kette) und fremde Stremio-Addons zaehlen Abfragen, Treffer und Fehler -> Top-Module/Addons.
  * Nutzungsdauer je Bereich (Online-Zeit seiner Anfragen) und zuletzt genutzt; Kodi-Addons zaehlen Aufrufe, Dauer,
    Fehler und zuletzt – daraus schlaegt "Speicher & Aufraeumen" (speicher.py) Unbenutztes zum Entfernen vor.
  * Grenzen je Profil (setzt der Admin, profile.py "grenzen"): gesperrt, Traffic pro Tag/Monat, Anfragen pro Minute,
    gleichzeitige Verbindungen, Online-Zeit pro Tag, Upload-Groesse. Fuer Admins gelten keine Grenzen.

Gespeichert wird in <datenordner>/nutzung.json (hoechstens jede Minute, nicht in den Nutzerdaten).
"""

import collections
import json
import logging
import os
import re
import threading
import time
from .nutzung_grenzen import *

log = logging.getLogger("rezeptserver")

DATEI = "nutzung.json"
TAGE = 35
SPEICHERN_ALLE = 60.0
NEUER_BESUCH = 30 * 60  # gleicher Bereich nach 30 Minuten Pause zaehlt wieder als Besuch
LUECKE = 120  # Online-Zeit: Pausen bis 2 Minuten zwischen Anfragen zaehlen mit (Lesen, Schauen)
# Grenzen je Profil: Schluessel -> (Anzeige, Einheit, Hoechstwert); 0 = unbegrenzt
GRENZEN = {
    "traffic_tag_mb": ("Traffic pro Tag", "MB", 10 ** 7),
    "traffic_monat_mb": ("Traffic pro Monat", "MB", 10 ** 8),
    "anfragen_minute": ("Anfragen pro Minute", "", 100000),
    "verbindungen": ("Gleichzeitige Verbindungen (Streams, Downloads)", "", 1000),
    "zeit_tag_min": ("Online-Zeit pro Tag", "Min.", 1440),
    "upload_mb": ("Upload höchstens", "MB", 10 ** 5),
}
_BEREICH = re.compile(r"^[a-z0-9][a-z0-9_:-]{0,39}$")


def pruefe_grenzen(roh):
    """Grenzen eines Profils aus der Oberflaeche -> {schluessel: int >= 0, "gesperrt": bool}."""
    roh = roh if isinstance(roh, dict) else {}
    g = {"gesperrt": roh.get("gesperrt") is True}
    for k, (_, _, hoechst) in GRENZEN.items():
        try:
            g[k] = max(0, min(hoechst, int(roh.get(k) or 0)))
        except (TypeError, ValueError):
            raise ValueError("%s: bitte eine ganze Zahl (0 = unbegrenzt)" % GRENZEN[k][0])
    return g


def bereich_von(pfad, kopf_bereich=""):
    """Bereich einer Anfrage: der Reiter aus dem Header X-Bereich, sonst aus dem Pfad."""
    b = str(kopf_bereich or "").strip().lower()
    if _BEREICH.match(b):
        return b
    if not pfad or pfad in ("/", "/hls.js", "/logo.svg"):
        return "oberflaeche"
    if pfad == "/manifest.json" or re.match(r"^/(stream|catalog|meta|subtitles)/", pfad):
        return "stremio-addon"
    for anfang, name in (("/dlna/", "medienserver"), ("/tv.m3u", "livetv"), ("/epg.xml", "livetv"), ("/liste/", "livetv"),
                         ("/live/", "xtream"), ("/player_api.php", "xtream"), ("/debrid/", "debrid"), ("/usenet/", "usenet"),
                         ("/radio.m3u", "radio"), ("/binsearch/", "binsearch"), ("/logo/", "livetv")):
        if pfad.startswith(anfang):
            return name
    m = re.match(r"^/api/([a-z0-9]+)", pfad)
    return m.group(1) if m else "sonstiges"


def _leer():
    return {"aus": 0, "ein": 0, "anfragen": 0, "verbindungen": 0, "zeit": 0.0, "erste": 0, "zuletzt": 0, "tage": {}, "bereiche": {}}


class Anfrage:
    """Eine laufende Anfrage: zaehlt die gesendeten Bytes mit und bricht ab, wenn das Tageskontingent voll ist."""

    __slots__ = ("nutzung", "pid", "bereich", "beginn", "ein", "aus", "grenze_aus")

    def __init__(self, nutzung, pid, bereich, ein, grenze_aus):
        self.nutzung, self.pid, self.bereich = nutzung, pid, bereich
        self.beginn, self.ein, self.aus, self.grenze_aus = nutzung.uhr(), ein, 0, grenze_aus

    def gesendet(self, n):
        self.aus += n
        if self.grenze_aus is not None and self.aus > self.grenze_aus:
            raise BrokenPipeError("Traffic-Grenze erreicht")


class Nutzung:
    def __init__(self, ordner=None, uhr=time.time):
        self.pfad = os.path.join(ordner, DATEI) if ordner else None
        self.uhr = uhr
        self._sperre = threading.Lock()
        self._laufend = collections.Counter()   # pid -> laufende Anfragen
        self._minute = {}                        # pid -> deque der letzten Zeitpunkte
        self._zuletzt_bereich = {}               # (pid, client) -> (bereich, zeit)
        self._aktiv_bis = {}                     # pid -> bis wann die Online-Zeit schon gezaehlt ist
        self._geaendert, self._gespeichert = False, time.monotonic()
        self.daten = {"profile": {}, "module": {}, "addons": {}, "kodi": {}, "seit": int(uhr())}
        if self.pfad and os.path.isfile(self.pfad):
            try:
                with open(self.pfad, encoding="utf-8") as f:
                    roh = json.load(f)
                if isinstance(roh, dict):
                    for k in ("profile", "module", "addons", "kodi"):
                        if isinstance(roh.get(k), dict):
                            self.daten[k] = roh[k]
                    self.daten["seit"] = int(roh.get("seit") or self.daten["seit"])
            except (OSError, ValueError) as fehler:
                log.warning("Nutzung nicht lesbar (%s), beginnt neu", fehler)

    # --- Zaehlen ---------------------------------------------------------------------------------
    def _tag(self, t=None):
        return time.strftime("%Y-%m-%d", time.localtime(self.uhr() if t is None else t))

    def _profil(self, pid):
        p = self.daten["profile"].get(pid)
        if p is None:
            p = self.daten["profile"][pid] = _leer()
            p["erste"] = int(self.uhr())
        return p

    def _heute(self, p):
        tag = self._tag()
        t = p["tage"].get(tag)
        if t is None:
            t = p["tage"][tag] = {"aus": 0, "ein": 0, "anfragen": 0, "zeit": 0.0}
            for alt in sorted(p["tage"])[:-TAGE]:
                del p["tage"][alt]
        return t

    def verbrauch(self, pid):
        """(Traffic heute, Traffic diesen Monat, Online-Zeit heute in Sekunden) eines Profils."""
        with self._sperre:
            p = self.daten["profile"].get(pid) or _leer()
            tag = self._tag()
            monat = tag[:7]
            heute = p["tage"].get(tag) or {}
            return (heute.get("aus", 0) + heute.get("ein", 0),
                    sum(t.get("aus", 0) + t.get("ein", 0) for k, t in p["tage"].items() if k.startswith(monat)),
                    heute.get("zeit", 0.0))

    def pruefen(self, pid, grenzen):
        """Fehlermeldung, wenn das Profil gerade nichts (mehr) darf, sonst ''. Zaehlt die Anfrage fuer das Minutenlimit."""
        if not grenzen:
            return ""
        if grenzen.get("gesperrt"):
            return "Dieses Profil ist gesperrt – frag deinen Admin."
        tag, monat, zeit = self.verbrauch(pid)
        if grenzen.get("traffic_tag_mb") and tag >= grenzen["traffic_tag_mb"] * MB:
            return "Traffic für heute aufgebraucht (%d MB) – morgen geht es weiter oder der Admin erhöht die Grenze." % grenzen["traffic_tag_mb"]
        if grenzen.get("traffic_monat_mb") and monat >= grenzen["traffic_monat_mb"] * MB:
            return "Traffic für diesen Monat aufgebraucht (%d MB)." % grenzen["traffic_monat_mb"]
        if grenzen.get("zeit_tag_min") and zeit >= grenzen["zeit_tag_min"] * 60:
            return "Online-Zeit für heute aufgebraucht (%d Minuten)." % grenzen["zeit_tag_min"]
        with self._sperre:
            if grenzen.get("verbindungen") and self._laufend[pid] >= grenzen["verbindungen"]:
                return "Zu viele gleichzeitige Verbindungen (höchstens %d)." % grenzen["verbindungen"]
            if grenzen.get("anfragen_minute"):
                jetzt = time.monotonic()
                q = self._minute.setdefault(pid, collections.deque())
                while q and jetzt - q[0] > 60:
                    q.popleft()
                if len(q) >= grenzen["anfragen_minute"]:
                    return "Zu viele Anfragen (höchstens %d pro Minute) – kurz warten." % grenzen["anfragen_minute"]
                q.append(jetzt)
        return ""

    def beginn(self, pid, bereich, client="", ein=0, neue_verbindung=False, grenzen=None, besuch=None):
        """Anfrage beginnt -> Anfrage-Objekt fuer ende(). grenzen: Traffic pro Tag bricht laufende Streams ab.

        besuch: True/False meldet die Oberflaeche selbst (X-Besuch beim Oeffnen eines Reiters); None (Stremio,
        Fernseher …): ein Wechsel des Bereichs oder 30 Minuten Pause zaehlen als Besuch."""
        pid = pid or ""
        grenze_aus = None
        if grenzen and grenzen.get("traffic_tag_mb"):
            tag = self.verbrauch(pid)[0]
            grenze_aus = max(0, grenzen["traffic_tag_mb"] * MB - tag)
        jetzt = self.uhr()
        with self._sperre:
            self._laufend[pid] += 1
            p = self._profil(pid)
            if neue_verbindung:
                p["verbindungen"] += 1
            b = p["bereiche"].setdefault(bereich, {"besuche": 0, "anfragen": 0, "aus": 0, "zeit": 0.0, "zuletzt": 0})
            b["anfragen"] += 1
            b["zuletzt"] = int(jetzt)
            schluessel = (pid, client)
            alt = self._zuletzt_bereich.get(schluessel)
            if besuch is True or (besuch is None and (not alt or alt[0] != bereich or jetzt - alt[1] > NEUER_BESUCH)):
                b["besuche"] += 1
            self._zuletzt_bereich[schluessel] = (bereich, jetzt)
            if len(self._zuletzt_bereich) > 5000:
                self._zuletzt_bereich.clear()
        return Anfrage(self, pid, bereich, ein, grenze_aus)

    def ende(self, a):
        jetzt = self.uhr()
        start = min(a.beginn, jetzt)
        with self._sperre:
            self._laufend[a.pid] = max(0, self._laufend[a.pid] - 1)
            # Online-Zeit: gleichzeitige Anfragen nicht doppelt, kurze Pausen dazwischen mit
            bis = self._aktiv_bis.get(a.pid, 0)
            if start - bis <= LUECKE:
                start = bis
            dauer = max(0.0, jetzt - max(start, bis))
            self._aktiv_bis[a.pid] = max(bis, jetzt)
            p = self._profil(a.pid)
            heute = self._heute(p)
            for ziel in (p, heute):
                ziel["aus"] += a.aus
                ziel["ein"] += a.ein
                ziel["anfragen"] += 1
                ziel["zeit"] = round(ziel["zeit"] + dauer, 1)
            p["zuletzt"] = int(self.uhr())
            b = p["bereiche"].setdefault(a.bereich, {"besuche": 0, "anfragen": 0, "aus": 0})
            b["aus"] += a.aus
            b["zeit"] = round(b.get("zeit", 0.0) + dauer, 1)  # Nutzungsdauer des Bereichs
            self._geaendert = True
        self.speichern()

    def zaehler(self, art, name, treffer=0, fehler=False):
        """Hook fuer Kette (art "modul") und Stremio-Addons (art "addon"): Abfrage mit n Treffern oder Fehler."""
        if art not in ("module", "addons") or not name:
            return
        with self._sperre:
            z = self.daten[art].setdefault(str(name)[:60], {"abfragen": 0, "mit_treffern": 0, "treffer": 0, "fehler": 0, "zuletzt": 0})
            z["abfragen"] += 1
            z["treffer"] += max(0, int(treffer or 0))
            z["mit_treffern"] += 1 if treffer else 0
            z["fehler"] += 1 if fehler else 0
            z["zuletzt"] = int(self.uhr())
            if len(self.daten[art]) > 500:  # Altlasten (geloeschte Module) zuerst raus
                for alt in sorted(self.daten[art], key=lambda k: self.daten[art][k]["zuletzt"])[:100]:
                    del self.daten[art][alt]
            self._geaendert = True

    def kodi(self, aid, dauer=0.0, fehler=False):
        """Kodi-Addon genutzt (Aufruf eines Plugins, Skin als Heim-Style): Aufrufe, Dauer, Fehler, zuletzt."""
        if not aid:
            return
        with self._sperre:
            z = self.daten["kodi"].setdefault(str(aid)[:120], {"aufrufe": 0, "dauer": 0.0, "fehler": 0, "zuletzt": 0})
            z["aufrufe"] += 1
            z["dauer"] = round(z["dauer"] + max(0.0, float(dauer or 0)), 1)
            z["fehler"] += 1 if fehler else 0
            z["zuletzt"] = int(self.uhr())
            if len(self.daten["kodi"]) > 1000:
                for alt in sorted(self.daten["kodi"], key=lambda k: self.daten["kodi"][k]["zuletzt"])[:200]:
                    del self.daten["kodi"][alt]
            self._geaendert = True
        self.speichern()

    def module_nutzung(self):
        """Ueber alle Profile: je Bereich Besuche, Anfragen, Nutzungsdauer, zuletzt; je Kodi-Addon die Zaehler."""
        with self._sperre:
            bereiche = collections.defaultdict(lambda: {"besuche": 0, "anfragen": 0, "zeit": 0.0, "zuletzt": 0, "profile": 0})
            for p in self.daten["profile"].values():
                for k, v in p["bereiche"].items():
                    z = bereiche[k]
                    for feld in ("besuche", "anfragen"):
                        z[feld] += v.get(feld, 0)
                    z["zeit"] = round(z["zeit"] + v.get("zeit", 0.0), 1)
                    z["zuletzt"] = max(z["zuletzt"], v.get("zuletzt", 0))
                    z["profile"] += 1
            return {"seit": self.daten["seit"], "bereiche": dict(bereiche), "kodi": {k: dict(v) for k, v in self.daten["kodi"].items()}}

    # --- Speichern und Ansicht --------------------------------------------------------------------
    def speichern(self, sofort=False):
        if not self.pfad or not self._geaendert or (not sofort and time.monotonic() - self._gespeichert < SPEICHERN_ALLE):
            return
        with self._sperre:
            text = json.dumps(self.daten, ensure_ascii=False)
            self._geaendert, self._gespeichert = False, time.monotonic()
        try:
            temp = self.pfad + ".tmp"
            with open(temp, "w", encoding="utf-8") as f:
                f.write(text)
            os.replace(temp, self.pfad)
        except OSError as fehler:
            log.warning("Nutzung nicht gespeichert: %s", fehler)

    def zuruecksetzen(self, pid=None):
        with self._sperre:
            if pid is None:
                self.daten.update(profile={}, module={}, addons={}, kodi={}, seit=int(self.uhr()))
            else:
                self.daten["profile"].pop(pid, None)
            self._geaendert = True
        self.speichern(sofort=True)

    def uebersicht(self, profile_liste):
        """Mitgliederliste (Admin): je Profil Verbrauch, Anfragen, Verbindungen, Zeit, online, Grenzen; dazu Ranglisten."""
        tag = self._tag()
        monat = tag[:7]
        with self._sperre:
            zeilen = []
            for x in list(profile_liste) + [{"id": "", "name": "Ohne Profil (Gäste, Stremio, Fernseher)", "rolle": "", "farbe": "#888"}]:
                p = self.daten["profile"].get(x["id"]) or _leer()
                heute = p["tage"].get(tag) or {}
                zeilen.append({
                    "id": x["id"], "name": x["name"], "rolle": x.get("rolle", ""), "farbe": x.get("farbe", "#888"),
                    "grenzen": pruefe_grenzen(x.get("grenzen")) if x["id"] else None,
                    "aus": p["aus"], "ein": p["ein"], "anfragen": p["anfragen"], "verbindungen": p["verbindungen"],
                    "zeit": int(p["zeit"]), "erste": p["erste"], "zuletzt": p["zuletzt"], "jetzt": self._laufend[x["id"]],
                    "heute": {"traffic": heute.get("aus", 0) + heute.get("ein", 0), "anfragen": heute.get("anfragen", 0), "zeit": int(heute.get("zeit", 0))},
                    "monat": sum(t.get("aus", 0) + t.get("ein", 0) for k, t in p["tage"].items() if k.startswith(monat)),
                    "verlauf": [{"tag": k, "traffic": t.get("aus", 0) + t.get("ein", 0), "anfragen": t.get("anfragen", 0)}
                                for k, t in sorted(p["tage"].items())[-14:]],
                    "top": sorted(({"bereich": k, **v} for k, v in p["bereiche"].items()), key=lambda b: (-b["besuche"], -b["anfragen"]))[:5]})
            bereiche = collections.defaultdict(lambda: {"besuche": 0, "anfragen": 0, "aus": 0, "zeit": 0.0, "profile": 0})
            for p in self.daten["profile"].values():
                for k, v in p["bereiche"].items():
                    for feld in ("besuche", "anfragen", "aus", "zeit"):
                        bereiche[k][feld] += v.get(feld, 0)
                    bereiche[k]["profile"] += 1
            def rang(art):
                return sorted(({"name": k, **v} for k, v in self.daten[art].items()), key=lambda z: (-z["mit_treffern"], -z["abfragen"]))[:50]
            return {"seit": self.daten["seit"], "profile": zeilen, "grenzen_felder": {k: {"name": n, "einheit": e} for k, (n, e, _) in GRENZEN.items()},
                    "bereiche": sorted(({"name": k, **v} for k, v in bereiche.items()), key=lambda z: (-z["besuche"], -z["anfragen"]))[:50],
                    "module": rang("module"), "addons": rang("addons")}


