"""Grenzen des ganzen Servers: Listengroessen und Uploads (Admin-Panel)."""

MB = 1024 * 1024

# --- Grenzen des ganzen Servers (Nutzerdaten "server_grenzen", setzt der Admin) ------------------------------------
SERVER_SCHLUESSEL = "server_grenzen"
# Schluessel -> (Anzeige, Hinweis, Standard, kleinster, groesster Wert in MB)
SERVER_GRENZEN = {
    "adressen_mb": ("Adressen-Liste (Live-TV)", "JSON {sender-id: adresse} oder M3U-Senderliste aus dem Internet", 50, 1, 2048),
    "liste_mb": ("Eigene M3U-Listen", "Senderlisten, die der Server einmal am Tag lädt", 50, 1, 2048),
    "epg_mb": ("EPG (Programmführer)", "XMLTV-Quellen, entpackt", 300, 10, 4096),
    "upload_mb": ("Uploads", "NZB, Sicherung, nodes.dat/server.met, IP-Filter, Bilder, Startanimation – liegt beim Hochladen ganz im Speicher", 70, 1, 1024),
}


def server_grenzen(roh):
    roh = roh if isinstance(roh, dict) else {}
    werte = {}
    for k, (name, _, standard, klein, gross) in SERVER_GRENZEN.items():
        try:
            werte[k] = max(klein, min(gross, int(roh.get(k) or standard)))
        except (TypeError, ValueError):
            raise ValueError("%s: bitte eine ganze Zahl in MB" % name)
    return werte


def server_grenzen_anwenden(roh):
    """Wirksam machen: Live-TV-Listen und Upload-Groesse (ohne Neustart)."""
    from . import livetv_grund, oberflaeche
    w = server_grenzen(roh)
    livetv_grund.GRENZEN.update(adressen=w["adressen_mb"] * MB, liste=w["liste_mb"] * MB, epg=w["epg_mb"] * MB)
    oberflaeche.MAX_NZB_KOERPER = w["upload_mb"] * MB
    return w
