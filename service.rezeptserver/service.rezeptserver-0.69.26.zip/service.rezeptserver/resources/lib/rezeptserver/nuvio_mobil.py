"""Nuvio Mobile: der Client als H0rSt-Modul (ein Repo, voll verdrahtet).

Nuvio Mobile (NuvioMedia/NuvioMobile, GPL-3.0) ist ein Kotlin-Multiplatform-Client
fuer Android und iOS mit Filmen, Serien, Live-TV, Downloads und Plugins. H0rSt
bleibt der Modul-Host: die App haengt H0rSt als Stremio-Addon ein und nutzt die
H0rSt-Schnittstellen fuer Suche, Streams, Untertitel, Downloads, Fortschritt und
Tracker. Dieses Modul liefert der App und der Oberflaeche den Stand der
Verdrahtung: Addon-Adresse, API-Basis und die Liste der gemeinsamen Funktionen.

  GET  /api/nuvio   Stand: an, addon, api, funktionen, einstellungen
  POST /api/nuvio   {aktion: einstellungen, ...} speichert die Schalter (wie /api/einstellungen)
"""

from . import __version__

SCHLUESSEL = "nuvio"
NAME = "Nuvio Mobile"
SYMBOL = "🎬"
REPO = "https://github.com/NuvioMedia/NuvioMobile"
LIZENZ = "GPL-3.0"
PAKET = "com.nuvio.app"
APP_VERSION = "0.6.10"

AN = "nuvio_an"
ADRESSE = "nuvio_adresse"

# Was die App mitbringt und welche H0rSt-Schnittstelle es bedient (Bruecke, nicht Kopie)
FUNKTIONEN = [
    {"id": "katalog", "name": "Kataloge & Suche", "app": "Start, Entdecken, Suche",
     "h0rst": ["/api/kataloge", "/api/titelsuche", "/api/titel", "/api/entdecken", "/api/genres"]},
    {"id": "streams", "name": "Streams & Wiedergabe", "app": "Player, Quellenwahl, Autoplay",
     "h0rst": ["/api/titelstreams", "/api/streams", "/api/sehen"]},
    {"id": "addon", "name": "Stremio-Addon-Bruecke", "app": "Addons, Manifest, Kataloge, Streams",
     "h0rst": ["/manifest.json", "/catalog/…", "/meta/…", "/stream/…"]},
    {"id": "untertitel", "name": "Untertitel", "app": "Untertitelquellen, Sprache, Stil",
     "h0rst": ["/api/untertitel/<sprache>/<imdb>"]},
    {"id": "fortschritt", "name": "Weiterschauen & Verlauf", "app": "Weiterschauen, gesehen, Resume",
     "h0rst": ["/api/sehen", "/api/titel"]},
    {"id": "downloads", "name": "Downloads", "app": "Offline-Speicher, Fortschritt",
     "h0rst": ["/api/downloads"]},
    {"id": "tracker", "name": "Tracker", "app": "Trakt, SIMKL, MDBList",
     "h0rst": ["/api/trakt", "/api/simkl", "/api/mdblist"]},
    {"id": "debrid", "name": "Debrid & Cloud", "app": "TorBox, Premiumize, Aufloeser",
     "h0rst": ["/api/debrid", "/api/debrid/cloud", "/api/einstellungen"]},
]


def schalter(werte):
    """Schalter des Moduls aus den gemeinsamen Einstellungen (Standard: an)."""
    w = werte or {}
    adresse = str(w.get(ADRESSE) or "").strip()
    return {"an": w.get(AN) is not False, "adresse": adresse[:300]}


def basis_adresse(adresse, ersatz=""):
    """Eigene Adresse (Einstellungen) vor der Adresse der Anfrage; immer mit Slash am Ende."""
    wahl = str(adresse or "").strip().rstrip("/") + "/" if str(adresse or "").strip() else ""
    if wahl:
        return wahl
    ersatz = str(ersatz or "").strip()
    return ersatz.rstrip("/") + "/" if ersatz else ""


def addon_adresse(basis):
    """Stremio-Addon-Adresse von H0rSt (das Token steckt bereits in der Basis)."""
    return basis + "manifest.json" if basis else ""


def api_basis(basis):
    """Basis fuer die H0rSt-APIs (Token-Praefix bleibt erhalten)."""
    return basis + "api/" if basis else ""


def stand(werte, basis=""):
    """Antwort fuer GET /api/nuvio: was die App verbindet und was H0rSt dafuer anbietet."""
    s = schalter(werte)
    adresse = basis_adresse(s["adresse"], basis)
    return {
        "modul": SCHLUESSEL,
        "name": NAME,
        "symbol": SYMBOL,
        "version": APP_VERSION,
        "repo": REPO,
        "lizenz": LIZENZ,
        "paket": PAKET,
        "h0rst": __version__,
        "an": s["an"],
        "adresse": adresse,
        "addon": addon_adresse(adresse),
        "api": api_basis(adresse),
        "funktionen": [dict(f, an=s["an"]) for f in FUNKTIONEN],
        "einstellungen": {AN: s["an"], ADRESSE: s["adresse"]},
    }


def einstellungen_pruefen(werte, wunsch):
    """Nur die beiden Modulwerte aus einem POST uebernehmen; unbekannte Felder bleiben weg."""
    neu = dict(werte or {})
    if AN in wunsch:
        neu[AN] = bool(wunsch.get(AN))
    if ADRESSE in wunsch:
        adresse = str(wunsch.get(ADRESSE) or "").strip()
        if " " in adresse or '"' in adresse or "<" in adresse or ">" in adresse:
            raise ValueError("Ungueltige Adresse")
        neu[ADRESSE] = adresse[:300]
    return {AN: neu.get(AN, True), ADRESSE: neu.get(ADRESSE, "")}
