"""nuvio_plugin.py: voller Nuvio-kompatibler getStreams()-Plugin mit Fetch-Bridge (NuvioMobile-Plan,
NV5-To-Do - Fortsetzung von js_sandbox.py/NV5a und eigene_quelle.py/NV5b).

Anders als NV5b (eigene_quelle.py::kandidaten_aus_js(), nie Netzzugriff aus dem JS heraus) braucht Nuvios
eigentliches Plugin-Modell selbst Netzzugriff: eine Funktion `getStreams(tmdbId, mediaType, season,
episode)`, die ueber eine synchrone `fetchSync(argument)`-Host-Funktion (js_sandbox.py::
ausfuehren_mit_fetch(), NV5-To-Do P3) beliebige Streaming-Anbieter-Seiten selbst abruft und eine Liste
`[{"url"[, "title", "quality", "infoHash", "name"]}]` liefert.

Nutzerentscheidung (AskUserQuestion, NV5-To-Do-Planung): **jeder oeffentliche Host erlaubt** (nicht nur
eine admin-gepflegte Domain-Liste je Plugin) - wie bei Stremio-/mHub-Addons schon heute, weil Nuvio-
Plugins typischerweise mehrere/wechselnde CDN-Domains anspringen. Nur private/interne Adressen bleiben
gesperrt (netz.ip_oeffentlich_pruefen, ohne Ausnahme - anders als bei Addons gibt es hier keinen
heimnetz_erlaubt-Opt-out, weil nicht der Admin selbst die Ziel-Adresse eintraegt, sondern beliebiger
Plugin-Code sie zur Laufzeit waehlt).

Zwei Verteidigungslinien gegen einen haengenden/missbrauchten fetchSync()-Aufruf (empirisch bestaetigt,
siehe js_sandbox.py/WISSEN.md 0.68.141 - das Context-Timeout von quickjs-rs schuetzt NICHT vor einem
haengenden Host-Callback): (1) jeder einzelne Netzaufruf hat eine eigene Socket-Zeitgrenze
(FETCH_ZEITGRENZE, via netz.Abrufer), (2) ein Aufruf-Deckel (MAX_FETCH_JE_LAUF) pro getStreams()-Lauf.

Global per Schalter abgeschaltet (Standard aus, Muster mcp_server.eingeschaltet()) UND mindestens ein
aktives Plugin noetig - zwei bewusste Schritte. Nur auf PC/Pi/Docker/Android (Kodi-Addons koennen nie
zur Laufzeit pip-installieren, strukturell ausgeschlossen wie NV5a/NV5b)."""

import logging
import re
from concurrent.futures import ThreadPoolExecutor

from . import js_sandbox
from . import netz
from .netz import urllib_holen

log = logging.getLogger("rezeptserver")


def _staffel_folge(stremio_id):
    """"tt0903747:1:2" -> (1, 2), sonst (None, None). Eigene, kleine Kopie von
    AddonMixin.staffel_folge() (stremio_addon.py) statt eines Imports von dort - ein Modul-Kopf-Import
    aus stremio_addon.py waere hier zirkulaer (nuvio_plugin.py wird u. a. von oberflaeche_nuvio_plugin.py
    importiert, das wiederum frueh in der Modul-Kette via oberflaeche.py/stremio_grund.py laedt, bevor
    stremio_addon.py fertig waere)."""
    teile = str(stremio_id).split(":")
    if len(teile) >= 3 and teile[-2].isdigit() and teile[-1].isdigit():
        return int(teile[-2]), int(teile[-1])
    return None, None

SCHLUESSEL = "nuvio_plugins"
UNTER = "plugins"
MAX_PLUGINS = 12
MAX_FETCH_JE_LAUF = 8
FETCH_ZEITGRENZE = 15.0  # Sekunden, pro einzelnem fetchSync()-Aufruf (Socket-Zeitgrenze, netz.Abrufer)
_ID = re.compile(r"[^a-z0-9]")


class NuvioPluginFehler(ValueError):
    pass


def eingeschaltet(daten):
    """Globaler Schalter (Standard aus) UND mindestens ein aktives Plugin - zwei bewusste Schritte,
    Muster mcp_server.eingeschaltet()."""
    daten = daten or {}
    return bool(daten.get(SCHLUESSEL + "_an")) and any(p["aktiv"] for p in plugins(daten))


def kennung(name):
    return "nuvio_" + (_ID.sub("", str(name or "").lower())[:20] or "plugin")


def plugins(daten):
    eigene = ((daten or {}).get(SCHLUESSEL) or {}).get(UNTER) or []
    # "aktiv" nachtragen: vor diesem Feld gespeicherte Eintraege (sollte es nie geben, aber wie bei
    # eigene_quelle.py defensiv) gelten weiterhin als an (Standard)
    return [dict(p, aktiv=bool(p.get("aktiv", True))) for p in eigene if isinstance(p, dict) and p.get("js")]


def _eintrag_pruefen(roh):
    roh = roh if isinstance(roh, dict) else {}
    js = str(roh.get("js") or "").strip()[:js_sandbox.MAX_CODE]
    if not js:
        raise NuvioPluginFehler("JS-Code darf nicht leer sein")
    name = " ".join(str(roh.get("name") or "").split())[:60] or "Plugin"
    aktiv = bool(roh.get("aktiv", True))  # Standard an; fehlt das Feld, gilt "an"
    eigene_id = str(roh.get("id") or "").strip()[:30]
    return {"id": eigene_id or kennung(name), "name": name, "js": js, "aktiv": aktiv}


def aendern(e, wunsch):
    """{plugin_dazu: {id?, name, js, aktiv?}} | {plugin_weg: id} - Muster eigene_quelle.aendern(), hier
    aber dedupliziert nach "id" statt "url" (kein eindeutiger natuerlicher Schluessel wie eine Adresse -
    die id wird aus dem Namen abgeleitet, siehe kennung())."""
    liste = [p for p in (e.get(UNTER) or []) if isinstance(p, dict)]
    if isinstance(wunsch.get("plugin_dazu"), dict):
        neu = _eintrag_pruefen(wunsch["plugin_dazu"])
        vorhandene_ids = {p.get("id") for p in liste}
        if neu["id"] not in vorhandene_ids and len(liste) >= MAX_PLUGINS:
            raise NuvioPluginFehler("Höchstens %d Nuvio-Plugins" % MAX_PLUGINS)
        liste = [p for p in liste if p.get("id") != neu["id"]] + [neu]
    if "plugin_weg" in wunsch:
        liste = [p for p in liste if p.get("id") != wunsch["plugin_weg"]]
    e[UNTER] = liste
    return liste


# --- Fetch-Bridge: synchroner fetchSync()-Host-Callback mit Socket-Zeitgrenze + Aufruf-Deckel ------------

def _fetch_gate(holen=urllib_holen, max_aufrufe=MAX_FETCH_JE_LAUF, zeitgrenze=FETCH_ZEITGRENZE):
    """Baut einen frischen fetchSync()-Callback (js_sandbox.ausfuehren_mit_fetch()) mit eigenem Aufruf-
    Zaehler je Lauf (Closure, nicht geteilt). Jeder einzelne Aufruf laeuft durch netz.Abrufer(erlaubt=None)
    (P2, NV5-To-Do) - jeder oeffentliche Host erlaubt (Nutzerentscheidung), nur private/interne Adressen
    gesperrt (netz.ip_oeffentlich_pruefen ueber netz.oeffentlich_holen); Umleitungsschleife und
    Antwortgroessen-Deckel (netz.MAX_BYTES) greifen automatisch aus netz.py, kein eigener Code hier noetig.
    Gibt NIE eine Exception nach aussen (js_sandbox.ausfuehren_mit_fetch()s Vertrag) - jeder Fehlerfall
    (Deckel erreicht, SSRF gesperrt, Netzfehler, HTTP-Fehlerstatus) liefert ein Fehler-Dict, das das
    Plugin selbst auswerten kann. Vereinfachung: der echte HTTP-Statuscode wird bei einem Fehler nicht
    durchgereicht (Abrufer.abruf() unterscheidet selbst nicht zwischen 404/500/Netzfehler) - fuer diese
    erste Fassung reicht ein einheitliches Fehler-Dict."""
    abrufer = netz.Abrufer(erlaubt=None, holen=netz.oeffentlich_holen(holen), zeitgrenze=zeitgrenze)
    zaehler = {"n": 0}

    def fetch_sync(argument):
        zaehler["n"] += 1
        if zaehler["n"] > max_aufrufe:
            return {"fehler": "Zu viele Netzaufrufe (Deckel: %d)" % max_aufrufe}
        argument = argument if isinstance(argument, dict) else {}
        url = str(argument.get("url") or "")
        if not url:
            return {"fehler": "Keine Adresse angegeben"}
        header = argument.get("header") if isinstance(argument.get("header"), dict) else None
        methode = str(argument.get("methode") or "GET").upper()
        koerper = argument.get("koerper") if isinstance(argument.get("koerper"), str) else None
        try:
            text = abrufer.abruf(url, methode=methode, header=header, daten=koerper)
        except netz.NetzFehler as fehler:
            return {"fehler": str(fehler)[:300]}
        return {"status": 200, "text": text}

    return fetch_sync


def _stream_dict(plugin_name, eintrag):
    """Validiert einen einzelnen, vom Plugin gelieferten Stream-Eintrag und bringt ihn in Stremios
    Protokollform (Muster StremioAddons.streams(): Name mit dem Plugin-Namen praefixiert, Zeile
    anbindungen_stremio.py:217-225). url ist Pflicht - unbrauchbare Eintraege liefern None und werden
    vom Aufrufer einzeln ausgelassen (ein kaputter Treffer darf die anderen nicht verwerfen)."""
    if not isinstance(eintrag, dict):
        return None
    url = str(eintrag.get("url") or "").strip()[:2000]
    if not url:
        return None
    eigener_name = str(eintrag.get("name") or eintrag.get("quality") or "").strip()[:200]
    s = {"url": url, "name": "\n".join(x for x in (plugin_name, eigener_name) if x)}
    titel = str(eintrag.get("title") or "").strip()[:500]
    if titel:
        s["title"] = titel
    info_hash = str(eintrag.get("infoHash") or "").strip()
    if info_hash:
        s["infoHash"] = info_hash
    return s


class NuvioPlugins:
    """Orchestriert alle aktiven Nuvio-Plugins fuer einen Stremio-Stream-Request (Muster Ab18._parallel()/
    EigeneQuellen.suche(): jedes Plugin parallel, Fehler isoliert, eine kaputte/langsame Quelle haelt die
    anderen nicht auf). tmdb_klient liefert (lazy, wie kataloge.Kataloge) den tmdb.Tmdb-Klienten der App
    oder None, falls nicht verdrahtet."""

    def __init__(self, tmdb_klient=lambda: None, holen=urllib_holen,
                 zeitlimit_gesamt=js_sandbox.ZEITLIMIT_FETCH_STANDARD):
        self.tmdb_klient = tmdb_klient
        self.holen = holen
        self.zeitlimit_gesamt = zeitlimit_gesamt

    def streams(self, typ, stremio_id, daten):
        """typ: "movie"|"series", stremio_id: "tt..." oder "tt...:staffel:folge". Liefert [] (nie einen
        Fehler) ohne Schluessel/Treffer/aktive Plugins - stillschweigend, Muster der TMDb-gestuetzten
        Reihen ("ohne Schluessel bleiben sie einfach ausgeblendet")."""
        stremio_id = str(stremio_id or "")
        if not stremio_id.startswith("tt") or not eingeschaltet(daten):
            return []
        aktive = [p for p in plugins(daten) if p["aktiv"]]
        if not aktive:
            return []
        from . import tmdb as tmdb_modul
        api_key = tmdb_modul.schluessel(daten)
        klient = self.tmdb_klient()
        if not api_key or not klient:
            return []
        imdb_id = stremio_id.split(":", 1)[0]
        tmdb_id = klient.find_by_imdb(imdb_id, typ, api_key)
        if not tmdb_id:
            return []
        staffel, folge = _staffel_folge(stremio_id)
        with ThreadPoolExecutor(max_workers=min(8, len(aktive)), thread_name_prefix="nuvioplugin") as pool:
            ergebnisse = list(pool.map(lambda p: self._ein_plugin(p, tmdb_id, typ, staffel, folge), aktive))
        return [s for liste in ergebnisse for s in liste]

    def _ein_plugin(self, plugin, tmdb_id, typ, staffel, folge):
        try:
            roh = js_sandbox.ausfuehren_mit_fetch(plugin["js"], "getStreams", [tmdb_id, typ, staffel, folge],
                                                  _fetch_gate(self.holen), zeitlimit=self.zeitlimit_gesamt)
        except js_sandbox.JsSandboxFehler as fehler:
            log.warning("Nuvio-Plugin %r fehlgeschlagen: %s", plugin["name"], fehler)
            return []
        if not isinstance(roh, list):
            return []
        ergebnis = []
        for eintrag in roh:
            s = _stream_dict(plugin["name"], eintrag)
            if s:
                ergebnis.append(s)
        return ergebnis
