"""NZB-XML-Parsing und Stichproben-Auswahl fuer die Usenet-Gesundheitspruefung (usenet_triage.py). Reine
Funktionen, kein Netzzugriff - rustnzb.nzb_laden() liefert die rohen (ggf. gzip-komprimierten, siehe
dortige Pruefung) Bytes."""

import gzip
import xml.etree.ElementTree as ET


def _ohne_namensraum(wurzel):
    """NZB-Dateien tragen ueblicherweise den Namensraum http://www.newzbin.com/DTD/2003/nzb, manche
    Indexer lassen ihn weg - Namensraum entfernen, damit beide Formen mit denselben, einfachen Tag-Namen
    gelesen werden koennen."""
    for el in wurzel.iter():
        if isinstance(el.tag, str) and "}" in el.tag:
            el.tag = el.tag.split("}", 1)[1]
    return wurzel


def lesen(roh_bytes):
    """Parst eine NZB-Datei zu {"dateien": [{"name", "bytes", "segmente": [{"message_id", "groups"}]}]}.
    Wirft nie - kaputtes/unbekanntes/leeres XML ergibt ein leeres Ergebnis statt eine Exception (Muster
    wie an anderer Stelle im Projekt bereits fuer XML aus nicht vertrauenswuerdigen Quellen etabliert)."""
    if not roh_bytes:
        return {"dateien": []}
    if roh_bytes[:2] == b"\x1f\x8b":
        try:
            roh_bytes = gzip.decompress(roh_bytes)
        except OSError:
            return {"dateien": []}
    try:
        wurzel = _ohne_namensraum(ET.fromstring(roh_bytes))
    except ET.ParseError:
        return {"dateien": []}
    dateien = []
    for datei in wurzel.findall("file"):
        gruppen = [g.text.strip() for g in datei.findall("groups/group") if g.text and g.text.strip()]
        segmente = []
        groesse = 0
        for seg in datei.findall("segments/segment"):
            mid = (seg.text or "").strip()
            if not mid:
                continue
            segmente.append({"message_id": mid, "groups": gruppen})
            try:
                groesse += int(seg.get("bytes") or 0)
            except ValueError:
                pass
        if segmente:
            dateien.append({"name": str(datei.get("subject") or ""), "bytes": groesse, "segmente": segmente})
    return {"dateien": dateien}


def stichprobe(nzb, anzahl=6):
    """Waehlt bis zu `anzahl` gleichmaessig verteilte Segmente (erstes, letztes, dazwischen gestreut) aus
    der groessten Datei (wahrscheinlichste Videodatei, meist die mit den meisten/groessten Segmenten) -
    reine Index-Streuung, kein Archiv-Format-Wissen noetig. Gibt [(message_id, group), ...] zurueck -
    group ist "" wenn die Datei keine Gruppe nennt. Leere Liste, wenn die NZB nichts Brauchbares hat."""
    dateien = (nzb or {}).get("dateien") or []
    if not dateien:
        return []
    groesste = max(dateien, key=lambda d: d.get("bytes") or 0)
    segmente = groesste.get("segmente") or []
    if not segmente:
        return []
    anzahl = max(1, min(int(anzahl or 1), len(segmente)))
    if anzahl >= len(segmente):
        indizes = range(len(segmente))
    elif anzahl == 1:
        indizes = [0]
    else:
        indizes = sorted({round(i * (len(segmente) - 1) / (anzahl - 1)) for i in range(anzahl)})
    ergebnis = []
    for i in indizes:
        seg = segmente[i]
        gruppen = seg.get("groups") or []
        ergebnis.append((seg["message_id"], gruppen[0] if gruppen else ""))
    return ergebnis
