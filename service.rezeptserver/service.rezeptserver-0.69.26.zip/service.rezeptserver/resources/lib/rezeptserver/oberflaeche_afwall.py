"""afwall im Bereich Sicherheit (afwall.py): Netz-Freigaben je App und iptables-Skript.

  GET  /api/afwall             Stand: Einstellungen, Profile, Apps mit Regeln, iptables-Skript, Root ja/nein
  GET  /api/afwall/export      Regeln als JSON zum Sichern
  POST /api/afwall             {aktiv|modus|profil|systemfilter|apps|regel|regeln|alle|profil_*|importieren}
  POST /api/afwall/apps        {apps: [{paket, name, system, uid}]} von der Android-App
  POST /api/afwall/anwenden    Skript setzen (Server als root) oder zum Kopieren zurückgeben
"""

import json

from . import afwall


class AfwallMixin:

    def afwall_lesen(self, pfad):
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        if pfad == "/api/afwall/export":
            return 200, "application/json", afwall.exportieren(daten)
        return 200, "application/json", afwall.zustand(daten)

    def afwall_post(self, pfad, koerper):
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(wunsch, dict):
                raise ValueError("JSON-Objekt erwartet")
            if not self.app.verwaltung:
                raise ValueError("Nutzerdaten nicht verfügbar")
            if pfad == "/api/afwall/apps":
                wunsch = {"apps": wunsch.get("apps") or wunsch.get("liste") or []}
                self.app.verwaltung.bearbeiten(lambda d: afwall.aendern(d, wunsch))
                return 200, "application/json", afwall.zustand(self.app.verwaltung.daten())
            if pfad == "/api/afwall/anwenden":
                if wunsch.get("einstellungen"):
                    self.app.verwaltung.bearbeiten(lambda d: afwall.aendern(d, wunsch["einstellungen"]))
                e = afwall.pruefe((self.app.verwaltung.daten() or {}).get(afwall.SCHLUESSEL))
                ergebnis = afwall.anwenden(e)
                return 200, "application/json", dict(afwall.zustand(self.app.verwaltung.daten()), **ergebnis)
            if pfad == "/api/afwall/export":
                return 200, "application/json", afwall.exportieren(self.app.verwaltung.daten())
            # /api/afwall
            self.app.verwaltung.bearbeiten(lambda d: afwall.aendern(d, wunsch))
            return 200, "application/json", afwall.zustand(self.app.verwaltung.daten())
        except (ValueError, UnicodeDecodeError) as fehler:  # AfwallFehler ist ValueError
            return 400, "application/json", {"fehler": str(fehler)}
