"""AIOStreams: eigene Instanz prüfen und als Stremio-Addon in H0rSt übernehmen.

  GET  /api/aiostreams              Stand, Befehle, Clients und der Eintrag in H0rSt
  POST /api/aiostreams              {aktion: pruefen | uebernehmen | entfernen}
"""

from . import aiostreams

from .oberflaeche_grund import (
    anbieter,
    anbindungen,
    json,
    log,
)


class AioStreamsMixin:

    def _aiostreams_eintrag(self, daten, url):
        if not url:
            return None
        for kennung, eintrag, werte in anbindungen.eigene(daten, "stremio-addon"):
            if aiostreams.gleiche(werte.get("url"), url):
                return {"id": kennung, "name": eintrag.get("name") or kennung}
        return None

    def _aiostreams_daten(self):
        return self.app.verwaltung.daten() if self.app.verwaltung else {}

    def _aiostreams_stand(self, werte):
        stand = aiostreams.zustand(werte)
        stand["h0rst_addon"] = self._aiostreams_eintrag(self._aiostreams_daten(), stand["manifest"])
        return stand

    def aiostreams_lesen(self):
        werte = self._einstellungen_lesen().get("werte") or {}
        return 200, "application/json", self._aiostreams_stand(werte)

    def aiostreams_post(self, koerper):
        werte = self._einstellungen_lesen().get("werte") or {}
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(wunsch, dict):
                raise aiostreams.AioStreamsFehler("JSON-Objekt erwartet")
            aktion = wunsch.get("aktion")
            if aktion == "pruefen":
                if werte.get("aiostreams_an") is False:
                    return 403, "application/json", {"fehler": "AIOStreams ist in den Einstellungen ausgeschaltet."}
                stand = aiostreams.zustand(werte, pruefen=True)
                stand["h0rst_addon"] = self._aiostreams_eintrag(self._aiostreams_daten(), stand["manifest"])
                return 200, "application/json", stand
            if aktion == "uebernehmen":
                return self._aiostreams_uebernehmen(werte)
            if aktion == "entfernen":
                return self._aiostreams_entfernen(werte)
            raise aiostreams.AioStreamsFehler("aktion: pruefen, uebernehmen oder entfernen")
        except (ValueError, UnicodeDecodeError, anbieter.AnbieterFehler) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}

    def _aiostreams_uebernehmen(self, werte):
        if werte.get("aiostreams_an") is False:
            return 403, "application/json", {"fehler": "AIOStreams ist in den Einstellungen ausgeschaltet."}
        verwaltung = self.app.verwaltung
        if not verwaltung:
            return 503, "application/json", {"fehler": "Anbieter-Verwaltung nicht verfügbar"}
        url = aiostreams.manifest_url(werte.get("aiostreams_manifest"))
        heimnetz = werte.get("aiostreams_heimnetz") is True
        info = aiostreams.manifest_lesen(url, heimnetz)

        def anlegen(daten):
            vorhanden = self._aiostreams_eintrag(daten, url)
            if vorhanden:
                raise aiostreams.AioStreamsFehler("Dieses AIOStreams-Addon ist schon eingetragen (%s)."
                                                  % vorhanden["name"])
            return anbieter.hinzufuegen(
                daten, verwaltung.module, info["name"], "addons", "url",
                {"url": url, "heimnetz_erlaubt": "1" if heimnetz else ""},
                typ="stremio-addon", anbieter_id=anbieter.freie_id(daten, verwaltung.module, info["name"]))

        kennung = verwaltung.aendern(anlegen)
        log.info("AIOStreams als Stremio-Addon übernommen: %s", info["name"])
        stand = aiostreams.zustand(werte)
        stand["meldung"] = "%s ist jetzt als Stremio-Addon in H0rSt eingetragen." % info["name"]
        stand["h0rst_addon"] = {"id": kennung, "name": info["name"]}
        return 200, "application/json", stand

    def _aiostreams_entfernen(self, werte):
        verwaltung = self.app.verwaltung
        if not verwaltung:
            return 503, "application/json", {"fehler": "Anbieter-Verwaltung nicht verfügbar"}
        url = aiostreams.manifest_url(werte.get("aiostreams_manifest"))

        def entfernen(daten):
            vorhanden = self._aiostreams_eintrag(daten, url)
            if not vorhanden:
                raise aiostreams.AioStreamsFehler("Dieses AIOStreams-Addon ist nicht in H0rSt eingetragen.")
            anbieter.entfernen(daten, vorhanden["id"])
            return vorhanden

        vorhanden = verwaltung.aendern(entfernen)
        log.info("AIOStreams-Addon aus H0rSt entfernt: %s", vorhanden["name"])
        stand = aiostreams.zustand(werte)
        stand["meldung"] = "%s wurde aus H0rSt entfernt." % vorhanden["name"]
        stand["h0rst_addon"] = None
        return 200, "application/json", stand
