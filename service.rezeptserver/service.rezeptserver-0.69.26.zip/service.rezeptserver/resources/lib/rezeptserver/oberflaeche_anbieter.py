"""AnbieterMixin
"""

from .oberflaeche_anbieter_grund import *

from .oberflaeche_anbieter_suche import _SucheMixin
from .oberflaeche_anbieter_anbieter import _AnbieterMixin
from .oberflaeche_anbieter_livetv import _LivetvMixin


class AnbieterMixin(_SucheMixin, _AnbieterMixin, _LivetvMixin):
    """AnbieterMixin aus den Teil-Mixins; aussen bleibt alles gleich (rezeptserver.oberflaeche_anbieter.*)."""
