"""Anbieter-Verwaltung: Vorlagen, JSON, Zugangsdaten und entfernen."""

from .oberflaeche_anbieter_grund import (
    NetzFehler,
    anbieter,
    anbindungen,
    dienste,
    json,
    livetv,
    log,
    rustnzb,
    urllib_holen,
    verweise,
    vorlagen,
    vxparser,
)

class _AnbieterMixin:

    # --- Anbieter ---------------------------------------------------------------
    def _holen(self):
        return getattr(self.app.verwaltung, "holen", None) or urllib_holen

    def _verwaltet(self, funktion):
        if not self.app.verwaltung:
            return 503, "application/json", {"fehler": "Anbieter-Verwaltung nicht verfügbar"}
        try:
            return 200, "application/json", funktion()
        except (anbieter.AnbieterFehler, vorlagen.VorlagenFehler, vxparser.VxFehler, livetv.LiveTvFehler,
                rustnzb.RustnzbFehler, NetzFehler, ValueError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}

    def anbieter_lesen(self):
        verwaltung = self.app.verwaltung
        daten = verwaltung.daten()
        eintraege = anbieter.liste(verwaltung.module, daten)
        for a in eintraege:
            a["kategorie_name"] = anbieter.KATEGORIEN[a["kategorie"]]
            a["anmeldung_name"] = anbieter.ANMELDUNGEN[a["anmeldung"]]
            a["typ_name"] = anbieter.TYPEN.get(a.get("typ", ""), "")
            vorlage = vorlagen.NACH_ID.get(a.get("vorlage", ""))
            a["seite"] = vorlage["seite"] if vorlage else ""
            a["hinweis"] = vorlage["hinweis"] if vorlage else ""
            for feld in a["felder"]:
                if feld.get("typ") == "passwort":
                    feld["gesetzt"] = bool(feld["wert"].strip())
                    feld["wert"] = ""  # Passwoerter verlassen den Server nicht
        return {"anbieter": eintraege, "vorlagen": vorlagen.liste(),
                "kategorien": [{"id": k, "name": n} for k, n in anbieter.KATEGORIEN.items()],
                "typen": [{"id": k, "name": n} for k, n in anbieter.TYPEN.items()],
                "anmeldungen": [{"id": k, "name": anbieter.ANMELDUNGEN[k], "felder": anbieter.FELDER[k]}
                                for k in anbieter.EIGENE_ANMELDUNGEN],
                "usenet_server": len(self.app.usenet_server)}

    def _json_post(self, pfad, koerper):
        try:
            daten = json.loads(koerper.decode("utf-8") or "{}")
        except (ValueError, UnicodeDecodeError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        if not isinstance(daten, dict):
            return 400, "application/json", {"fehler": "JSON-Objekt erwartet"}
        aktionen = {
            "/api/anbieter/vorlage": self.aus_vorlage, "/api/anbieter/neu": self.neu_anlegen,
            "/api/anbieter/json": self.aus_json, "/api/anbieter/zugang": self.zugang,
            "/api/anbieter/entfernen": self.entfernen, "/api/anbieter/pruefen": self.pruefen,
            "/api/anbieter/livetv": self.als_livetv, "/api/senden": self.senden,
            "/api/vx/links": self.vx_links, "/api/vx/liste": self.vx_liste,
            "/api/debrid/freischalten": self.debrid_freischalten,
            "/api/debrid/cloud": self.debrid_cloud_link,
            "/api/debrid/bibliothek": self.debrid_bibliothek_abspielen,
            "/api/rustnzb/aktion": self.rustnzb_aktion, "/api/rustnzb/nzb": self.rustnzb_nzb,
            "/api/rustnzb/server": self.rustnzb_server,
            "/api/dienste/aktion": self.dienst_aktion, "/api/dienste/hinzu": self.dienst_hinzu,
            "/api/dienste/einstellungen": self.dienst_einstellungen,
            "/api/dienste/anfrage": self.dienst_anfrage, "/api/dienste/seerr/anfrage": self.seerr_anfrage_stellen, "/api/dienste/holen": self.dienst_holen,
            "/api/dienste/hinzufuegen": self.dienst_hinzufuegen, "/api/dienste/arr_suchen": self.dienst_arr_suchen,
            "/api/dienste/fehlgeschlagen": self.dienst_fehlgeschlagen, "/api/dienste/release_holen": self.dienst_release_holen,
            "/api/dienste/speicher_filter": self.dienst_speicher_filter,
            "/api/dienste/stack/vorschau": self.stack_vorschau, "/api/dienste/stack/anwenden": self.stack_anwenden,
        }
        if pfad not in aktionen:
            return 404, "application/json", {"fehler": "nicht gefunden"}
        if pfad in ("/api/debrid/freischalten", "/api/debrid/cloud", "/api/debrid/bibliothek") \
                or pfad in ("/api/rustnzb/aktion", "/api/rustnzb/nzb") \
                or pfad.startswith("/api/dienste/"):
            # brauchen keine Anbieter-Verwaltung
            try:
                return 200, "application/json", aktionen[pfad](daten)
            except (ValueError, rustnzb.RustnzbFehler, dienste.DienstFehler, NetzFehler) as fehler:
                return 400, "application/json", {"fehler": str(fehler)}
        return self._verwaltet(lambda: aktionen[pfad](daten))

    @staticmethod
    def _werte(daten):
        werte = daten.get("werte") or {}
        if not isinstance(werte, dict):
            raise ValueError("werte muss ein Objekt sein")
        return {str(k): str(w) for k, w in werte.items()}

    def aus_vorlage(self, daten):
        verwaltung = self.app.verwaltung
        neu = verwaltung.aendern(lambda d: vorlagen.anlegen(d, verwaltung.module, str(daten.get("vorlage", "")),
                                                            self._werte(daten), daten.get("name")))
        log.info("Anbieter %s aus Vorlage angelegt", neu)
        return dict(self.anbieter_lesen(), neu=[neu])

    def neu_anlegen(self, daten):
        verwaltung = self.app.verwaltung

        def anlegen(d):
            name = str(daten.get("name", ""))
            return anbieter.hinzufuegen(d, verwaltung.module, name, daten.get("kategorie"), daten.get("anmeldung"),
                                        self._werte(daten), typ=daten.get("typ") or "",
                                        anbieter_id=anbieter.freie_id(d, verwaltung.module, name))
        neu = verwaltung.aendern(anlegen)
        log.info("Anbieter %s angelegt", neu)
        return dict(self.anbieter_lesen(), neu=[neu])

    def aus_json(self, daten):
        verwaltung = self.app.verwaltung
        if daten.get("url"):
            roh, quelle = vorlagen.holen_json(daten["url"])
            if vorlagen.ist_manifest(roh) and not vorlagen.ist_mhub_manifest(roh):
                quelle = vorlagen.manifest_adresse(quelle)
        elif daten.get("json"):
            roh, quelle = vorlagen.aus_text(str(daten["json"])), None
        else:
            raise ValueError("url oder json angeben")
        neu = verwaltung.aendern(lambda d: vorlagen.einlesen(d, verwaltung.module, roh, quelle))
        log.info("Anbieter per JSON: %s", ", ".join(neu))
        return dict(self.anbieter_lesen(), neu=neu)

    def zugang(self, daten):
        verwaltung = self.app.verwaltung
        anbieter_id = str(daten.get("id", ""))

        def setzen(d):
            eintrag = next((a for a in anbieter.liste(verwaltung.module, d) if a["id"] == anbieter_id), None)
            if eintrag is None:
                raise anbieter.AnbieterFehler("Unbekannter Anbieter: %s" % anbieter_id)
            geheim = {f["key"] for f in eintrag["felder"] if f.get("typ") == "passwort"}
            werte = {k: w for k, w in self._werte(daten).items() if not (k in geheim and not w.strip())}
            anbieter.zugang_setzen(d, verwaltung.module, anbieter_id, werte)
        verwaltung.aendern(setzen)
        return self.anbieter_lesen()

    def _eingebaut(self, daten):
        return [a["id"] for a in anbieter.liste(self.app.verwaltung.module, daten) if not a.get("eigen")]

    def entfernen(self, daten):
        def weg(d):
            anbieter.entfernen(d, str(daten.get("id", "")))
            verweise.aufraeumen(d, self._eingebaut(d))  # Netzweg, Waechter-Ersatz ... nicht ins Leere zeigen lassen
        self.app.verwaltung.aendern(weg)
        return self.anbieter_lesen()

    def _eigener(self, anbieter_id):
        daten = self.app.verwaltung.daten()
        eintrag = (daten.get("anbieter") or {}).get(anbieter_id)
        if not eintrag:
            raise anbieter.AnbieterFehler("%s ist kein eigener Anbieter" % anbieter_id)
        return eintrag, {k: str(w) for k, w in ((daten.get("einstellungen") or {}).get(anbieter_id) or {}).items()}

    def pruefen(self, daten):
        eintrag, werte = self._eigener(str(daten.get("id", "")))
        ok, meldung = anbindungen.pruefen(eintrag, werte, holen=self._holen())
        return {"ok": ok, "meldung": meldung}
