"""Live-TV-Listen und Senden an den Downloader."""

from .oberflaeche_anbieter_grund import (
    anbieter,
    anbindungen,
    livetv,
    log,
    re,
)

class _LivetvMixin:

    def liste_aufnehmen(self, name, url):
        name = " ".join(str(name or "").split())[:60]
        listen = list(self.app.livetv["listen"])
        if any(l["url"] == url for l in listen):
            raise livetv.LiveTvFehler("Diese Liste ist schon aufgenommen")
        self.app.setze_livetv(dict(self.app.livetv, listen=listen + [{"name": name, "url": url, "an": True}]))
        log.info("Live-TV-Liste %s aufgenommen", name)
        return {"name": name, "id": livetv.liste_id(name)}

    def als_livetv(self, daten):
        eintrag, werte = self._eigener(str(daten.get("id", "")))
        if eintrag.get("typ") == "vxparser":
            # get.php von vxparser enthaelt auch alle Filme und Folgen, deshalb die eigenen M3U8-Listen nehmen
            raise anbieter.AnbieterFehler("Im Bereich vxparser unter „Listen & EPG“ die gewünschte M3U8-Liste aufnehmen")
        if eintrag.get("typ") == "xtream":
            url = livetv.xtream_m3u_url(werte.get("url"), werte.get("user"), werte.get("pass"))
        else:
            raise anbieter.AnbieterFehler("Nur Xtream- und vxparser-Anbieter lassen sich als Live-TV-Liste aufnehmen")
        return self.liste_aufnehmen(eintrag["name"], url)

    def senden(self, daten):
        if daten.get("magnet"):
            eintrag, werte = self._eigener(str(daten.get("downloader", "")))
            return {"meldung": anbindungen.torrent_senden(eintrag, werte, str(daten["magnet"]))}
        ziel = self.wiedergabe_ziel(str(daten.get("stream", "")))
        if ziel is None:
            raise ValueError("Stream abgelaufen, bitte neu suchen")
        eintrag, werte = self._eigener(str(daten.get("downloader", "")))
        name = re.sub(r"[^\w .\-()\[\]]+", "", str(daten.get("name") or "h0rst"))[:120] or "h0rst"
        return {"meldung": anbindungen.nzb_senden(eintrag, werte, ziel[0], name, holen=self._holen())}
