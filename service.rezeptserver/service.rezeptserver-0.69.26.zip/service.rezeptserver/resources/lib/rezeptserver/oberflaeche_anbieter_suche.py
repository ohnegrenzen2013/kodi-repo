"""Titelsuche und Entdecken (wie ARVIO): Streams aus Rezepten, Anbietern und Addons."""

from .oberflaeche_anbieter_grund import (
    NetzFehler,
    anbindungen,
    debrid,
    dienste,
    einstellungen,
    entdecken,
    filtern,
    log,
    re,
    sprachen,
    stremio,
)

class _SucheMixin:
    def _ausschliessen(self, liste):
        """Einstellung "Releases ausschliessen" (Regex) auf Name, Titel und Quelle."""
        muster = einstellungen.ausschluss(self.app.ui)
        if not muster:
            return liste
        return [s for s in liste if not muster.search(" ".join(str(s.get(k) or "") for k in ("name", "titel", "quelle")))]

    def _badges(self, liste):
        """Badges wie Nuvio (4K, HDR, Atmos, Sprache ...) aus Release-Name und Beschreibung."""
        for e in liste:
            if e:
                text = " ".join(str(e.get(k) or "") for k in ("titel", "name", "aufloesung", "_text"))
                e["badges"] = self.app.badges.zuordnen(text)
                e.pop("_text", None)
        return liste

    def _torrent_debrid(self, eintrag, staffel=None, folge=None, name=None):
        """Torrent-Stream: zusaetzlich ueber Debrid abspielbar (debrid_url, schaltet beim Abspielen frei)."""
        if eintrag and eintrag.get("art") == "torrent" and self.app.debrid.verfuegbar \
                and debrid.ist_torrent(eintrag.get("url")):
            try:
                eintrag = dict(eintrag, debrid_url=self.app.debrid_adresse(eintrag["url"], "", staffel, folge,
                                                                           name or eintrag.get("titel")))
            except (debrid.DebridFehler, ValueError):
                pass
        return eintrag

    def _debrid_markieren(self, eintrag, stream, domains):
        """Hoster-Link: abspielen ueber /debrid/ (schaltet beim Abspielen mit dem Debrid-Konto frei)."""
        url = stream.get("url") if isinstance(stream, dict) else None
        if eintrag and not eintrag["art"] and not eintrag["ueber_server"] and url \
                and self.app.debrid.ist_hoster(url, domains):
            eintrag = dict(eintrag, url=self.app.debrid_adresse(url), debrid=True, hoster=debrid.host_von(url))
        return eintrag

    def _stream_eintrag(self, treffer, s):
        """Stream eines Rezepts fuer die Seite; Zugangsdaten bleiben auf dem Server."""
        art = "nzb" if s.get("nzb") else ("torrent" if s.get("infohash") else "")
        schluessel = ""
        if s.get("header") or art == "nzb":
            # Zugangsdaten (Header oder API-Schluessel in der NZB-Adresse) bleiben auf dem Server
            schluessel = self._wiedergabe_merken(s["url"], s.get("header") or {}, s.get("_netz") or [])
            url = "api/wiedergabe/" + schluessel
        else:
            url = s["url"]
        aufloesung = str(s.get("aufloesung") or treffer.get("aufloesung") or "")
        eintrag = {"name": s.get("_modul", ""), "aufloesung": aufloesung,
                   "qualitaet": filtern.qualitaet(aufloesung) or "", "url": url,
                   "ueber_server": bool(s.get("header")), "art": art,
                   "schluessel": schluessel if art == "nzb" else "",
                   # NZB ueber rustnzbs Mediathek abspielen (jeder Player)
                   "rustnzb": self.app.usenet_adresse(s["url"], treffer.get("titel"))
                   if art == "nzb" and self.app.rustnzb else "",
                   # NZB ueber NzbDAV/AltMount: einbinden statt herunterladen, per WebDAV abspielen
                   "streamer": [{"name": c.typ_name, "url": self.app.usenet_adresse(s["url"], treffer.get("titel"), "", aid,
                                                                                "TV" if re.search(r"S\d\dE\d\d", str(treffer.get("titel") or ""), re.I) else "Movies")}
                                for aid, c in sorted(self.app.dienste.items()) if getattr(c, "typ", "") in ("nzbdav", "altmount")]
                   if art == "nzb" else [],
                   "titel": str(treffer.get("titel") or ""), "groesse": stremio._groesse(treffer),
                   "sprachen": [sprachen.anzeige([c]) or c for c in sprachen.audio_von(treffer, s)]}
        if s.get("usenet"):
            eintrag["usenet"] = s["usenet"]
        if s.get("usenet_ref"):
            eintrag["usenet_ref"] = s["usenet_ref"]
        return eintrag

    @staticmethod
    def _addon_eintrag(s):
        """Stream eines fremden Stremio-Addons fuer die Seite."""
        zeilen = str(s.get("name") or "").split("\n")
        beschreibung = str(s.get("description") or s.get("title") or "")
        eintrag = {"name": zeilen[0], "aufloesung": " ".join(zeilen[1:]), "titel": beschreibung.split("\n")[0],
                   "ueber_server": False, "schluessel": "", "groesse": "", "sprachen": [], "art": "",
                   "_text": beschreibung + " " + str((s.get("behaviorHints") or {}).get("filename") or "")}
        aufloesung = filtern.qualitaet(beschreibung + " " + eintrag["aufloesung"]) or ""
        eintrag["qualitaet"] = aufloesung
        if s.get("infoHash"):
            eintrag.update(art="torrent", url="magnet:?xt=urn:btih:" + str(s["infoHash"]))
        elif s.get("nzbUrl"):
            eintrag.update(art="nzb", url=str(s["nzbUrl"]))
        elif s.get("url"):
            eintrag["url"] = str(s["url"])
        elif s.get("externalUrl"):
            eintrag.update(art="extern", url=str(s["externalUrl"]))
        else:
            return None
        return eintrag

    def _downloader(self, liste):
        downloader = []
        arten = {e["art"] for e in liste if e}
        if arten & {"nzb", "torrent"} and self.app.verwaltung:
            daten = self.app.verwaltung.daten()
            for art, typen in (("nzb", dienste.NZB_CLIENTS), ("torrent", dienste.TORRENT_CLIENTS)):
                if art in arten:
                    downloader += [{"id": i, "name": e["name"], "art": art} for t in typen
                                   for i, e, _ in anbindungen.eigene(daten, t)]
        return downloader

    def _eigene_quellen_suche(self, text):
        """Treffer aus eigenen Quellen (eigene_quelle.py) fuer die normale Titelsuche - wie die bestehende
        "Aus deinen Addons"-Zeile, nur mit dem Namen der jeweiligen Quelle als "quelle". Darf die Titelsuche
        nie verhindern: ohne Suchbegriff/Nutzerdaten oder bei einem Fehler einfach eine leere Liste."""
        if not text or not self.app.verwaltung:
            return []
        try:
            daten = self.app.verwaltung.daten()
            bekannt, karten = set(), []
            for ergebnis in self.app.eigene_quellen.suche(text, daten)["ergebnisse"]:
                for k in ergebnis["titel"]:
                    if k["id"] not in bekannt:
                        bekannt.add(k["id"])
                        karten.append(dict(k, quelle=ergebnis["name"]))
            return karten
        except Exception as fehler:
            log.warning("Eigene-Quellen-Suche: %s", fehler)
            return []

    # --- Titelsuche und Entdecken (wie ARVIO) ------------------------------------------
    def titel_api(self, pfad, werte):
        e = self.app.entdecken
        try:
            if pfad == "/api/genres":
                return 200, "application/json", e.genres()
            if pfad == "/api/titelsuche":
                text = " ".join(str(werte.get("q", "")).split())[:120]
                deutung = entdecken.smart(text)
                if deutung:
                    return 200, "application/json", {"smart": deutung, "titel": e.smart_suche(deutung),
                                                     "filme": [], "serien": [], "addons": [], "eigen": []}
                return 200, "application/json", dict(e.suche(text), smart=None, titel=[], eigen=self._eigene_quellen_suche(text))
            if pfad == "/api/entdecken":
                if werte.get("neu") == "1":
                    e.leeren()
                skip = werte.get("skip", "0")
                return 200, "application/json", e.katalog(werte.get("typ", "movie"), werte.get("sortierung", "top"),
                                                          werte.get("genre", ""), werte.get("jahr", ""),
                                                          int(skip) if skip.isdigit() else 0,
                                                          werte.get("bewertung", ""))
            if pfad == "/api/titel":
                return 200, "application/json", e.details(werte.get("typ", "movie"), werte.get("id", ""))
            if pfad == "/api/titeluntertitel":
                return 200, "application/json", self.titel_untertitel(werte.get("typ", "movie"), werte.get("id", ""))
            return 200, "application/json", self.titel_streams(werte.get("typ", "movie"), werte.get("id", ""))
        except ValueError as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        except NetzFehler as fehler:
            return 502, "application/json", {"fehler": str(fehler)}

    def titel_untertitel(self, typ, sid):
        """Addon-Untertitel-Kandidaten eines Titels fuer den internen Player (NV1a) - reicht unveraendert an
        die bereits vorhandene AddonMixin.untertitel() durch (dieselbe Funktion, die H0rSts eigene
        Stremio-Addon-Schnittstelle nach aussen bedient), nur fuer die eigene Oberflaeche erreichbar."""
        if typ not in ("movie", "series") or not re.match(r"^[\w.\-]{1,80}(:\d{1,4}:\d{1,5})?$", sid):
            raise ValueError("ungueltige ID")
        return self.app.untertitel(typ, sid)

    def titel_streams(self, typ, sid):
        """Streams zu einem Titel aus allen Quellen: Rezepte und eigene Anbieter (ueber die IMDb-ID) und
        fremde Stremio-Addons, mit dem gespeicherten Filter."""
        if typ not in ("movie", "series") or not re.match(r"^[\w.\-]{1,80}(:\d{1,4}:\d{1,5})?$", sid):
            raise ValueError("ungueltige ID")
        app = self.app
        fremd = app.kette.ketten_pool.submit(app.addons.streams, typ, sid) if app.addons and app.addons.addons else None
        paare = []
        if sid.startswith("tt"):
            gefunden = app.kette.suche(app.anfrage_aus_id(typ, sid))
            paare = filtern.streams_anwenden(app.kette.aufloesen_alle(filtern.treffer_anwenden(gefunden, app.filter)),
                                             app.filter)
            if app.audio_wunsch and app.filter["sortierung"] == "relevanz":
                paare.sort(key=lambda p: sprachen.rang(sprachen.audio_von(p[0], p[1]), app.audio_wunsch))
        paare = app.usenet_paare_pruefen(paare)
        domains = app.debrid.hoster()
        staffel, folge = app.staffel_folge(sid)
        liste = [dict(self._torrent_debrid(self._debrid_markieren(self._stream_eintrag(t, s), s, domains), staffel, folge),
                      quelle=app.anbieter_namen.get(t.get("_anbieter", ""), t.get("quelle", "")))
                 for t, s in paare]
        if fremd is not None:
            try:
                for s in fremd.result(timeout=app.addons.zeitgrenze + 2):
                    eintrag = self._torrent_debrid(self._debrid_markieren(self._addon_eintrag(s), s, domains),
                                                   staffel, folge)
                    q = app.filter["qualitaet"]
                    if eintrag and (not q or eintrag["qualitaet"] in q or (not eintrag["qualitaet"]
                                                                          and app.filter["ohne_angabe"])):
                        liste.append(dict(eintrag, quelle=eintrag["name"]))
            except Exception as fehler:
                log.warning("Stremio-Addons: %s", fehler)
        return {"streams": self._badges(self._ausschliessen(liste)), "downloader": self._downloader(liste)}

    def bild(self, titel, jahr):
        titel = " ".join(str(titel).split())[:120]
        if not titel:
            return {"bild": ""}
        schluessel = (titel.lower(), str(jahr))
        with self._sperre:
            if schluessel in self._bilder:
                return {"bild": self._bilder[schluessel]}
        eingabe = {"titel": titel, "text": titel, "art": "film"}
        if str(jahr).isdigit():
            eingabe["jahr"] = int(jahr)
        info = self.app.kette.anreichern(eingabe, "metadaten")
        bild = str(info.get("poster") or "")
        if bild.endswith("/w500"):  # Vorlage ohne poster_pfad
            bild = ""
        with self._sperre:
            if len(self._bilder) > 2000:
                self._bilder.clear()
            self._bilder[schluessel] = bild
        return {"bild": bild}
