"""Anime-Tracker (anime_tracker.py): AniList, MyAnimeList und Kitsu.

  GET  /api/anime-tracker       Stand der drei Dienste und der App-Zugänge
  POST /api/anime-tracker       {aktion: verbinden_start|verbinden|abgleichen|trennen, anbieter, token|code|benutzer|passwort}
  POST /api/anime-tracker/app   {mal_client_id, mal_client_secret, mal_redirect, kitsu_client_id, kitsu_client_secret}
"""

from . import anime_tracker
from .oberflaeche_grund import json


class AnimeTrackerMixin:
    def _anime_profil(self):
        ich = self.aktuelles_profil()
        return ich["id"] if ich else ""

    def anime_tracker_lesen(self):
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        return 200, "application/json", self.app.anime_tracker.stand(daten, self._anime_profil())

    def anime_tracker_post(self, pfad, koerper):
        if not self.app.verwaltung:
            return 503, "application/json", {"fehler": "Nutzerdaten nicht verfügbar"}
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(wunsch, dict):
                raise ValueError("JSON-Objekt erwartet")
            if pfad.endswith("/app"):
                return 200, "application/json", self.app.verwaltung.bearbeiten(
                    lambda d: anime_tracker.AnimeTracker.app_setzen(d, wunsch))
            profil, t = self._anime_profil(), self.app.anime_tracker
            aktion, anbieter = wunsch.get("aktion"), str(wunsch.get("anbieter") or "")
            if aktion == "verbinden_start":
                return 200, "application/json", t.verbinden_start(profil, anbieter)
            if aktion == "verbinden":
                return 200, "application/json", t.verbinden_fertig(profil, anbieter, wunsch)
            if aktion == "abgleichen":
                return 200, "application/json", {"ergebnis": t.abgleichen(profil)}
            if aktion == "trennen":
                return 200, "application/json", t.trennen(profil, anbieter)
            raise ValueError("aktion: verbinden_start, verbinden, abgleichen oder trennen")
        except (ValueError, UnicodeDecodeError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
