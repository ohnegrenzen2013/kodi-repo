"""Tor & I2P im Bereich Sicherheit (anonym.py).

  GET  /api/anonym                 Werkzeuge, offene Dienste (Ports), gesetzte Wege, Token ja/nein
  GET  /api/anonym/release?id=…    neueste Fassung eines Werkzeugs (GitHub) mit Dateien
  POST /api/anonym/verknuepfen     {netz: tor|i2p}: Verbindung anlegen (oder vorhandene nehmen) und als Weg setzen
  POST /api/anonym/konfig          {art, port}: Bausteine fuer i2pd, Java-I2P, torrc/Orbot, OnionCat
  POST /api/anonym/adresse         {adresse}: .onion/.b32.i2p -> IPv6 fuer OnionCat/GarliCat
"""

import json

from . import anonym, sicherheit, vorlagen


class AnonymMixin:

    def anonym_lesen(self, pfad, werte):
        try:
            if pfad == "/api/anonym/release":
                return 200, "application/json", self.app.anonym_releases.neueste(werte.get("id", ""))
        except anonym.AnonymFehler as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        return 200, "application/json", dict(anonym.zustand(daten), token=bool(self.app.token))

    def anonym_post(self, pfad, koerper):
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(wunsch, dict):
                raise ValueError("JSON-Objekt erwartet")
            if pfad == "/api/anonym/konfig":
                return 200, "application/json", anonym.konfig(wunsch.get("art"), wunsch.get("port") or 7000, bool(self.app.token))
            if pfad == "/api/anonym/adresse":
                return 200, "application/json", anonym.adresse(wunsch.get("adresse"))
            if pfad == "/api/anonym/verknuepfen":
                return self._verwaltet(lambda: self.anonym_verknuepfen(wunsch.get("netz")))
        except (ValueError, UnicodeDecodeError) as fehler:  # AnonymFehler ist ValueError
            return 400, "application/json", {"fehler": str(fehler)}
        return 404, "application/json", {"fehler": "nicht gefunden"}

    def anonym_verknuepfen(self, netz):
        """Tor: Vorlage "tor" -> Weg fuer .onion. I2P: i2pd (SOCKS 4447) oder sonst der HTTP-Proxy 4444 -> Weg fuer .i2p.
        Eine schon vorhandene Verbindung aus derselben Vorlage wird wiederverwendet."""
        if netz not in ("tor", "i2p"):
            raise anonym.AnonymFehler("netz: tor oder i2p")
        z = anonym.zustand()
        vorlage = "tor" if netz == "tor" else ("i2p-http" if z["i2p_router"] == "java" else "i2p")
        schluessel = "onion" if netz == "tor" else "i2p"
        verwaltung = self.app.verwaltung

        def setzen(d):
            vorhanden = [aid for aid, e in (d.get("anbieter") or {}).items() if e.get("vorlage") == vorlage]
            aid = vorhanden[0] if vorhanden else vorlagen.anlegen(d, verwaltung.module, vorlage)
            e = dict(sicherheit.pruefe(d.get(sicherheit.SCHLUESSEL)), **{schluessel: aid})
            d[sicherheit.SCHLUESSEL] = sicherheit.pruefe(e)
            return aid, not vorhanden
        aid, neu = verwaltung.aendern(setzen)  # laedt neu und wendet den Netzweg an
        name = (verwaltung.daten().get("anbieter") or {}).get(aid, {}).get("name", aid)
        laeuft = z["dienste"]["tor_socks" if netz == "tor" else ("i2p_http" if vorlage == "i2p-http" else "i2p_socks")]["offen"]
        meldung = "%s %s und als Weg für %s gesetzt." % (name, "angelegt" if neu else "genommen", ".onion" if netz == "tor" else ".i2p")
        if not laeuft:
            meldung += " Der Dienst läuft noch nicht – %s starten." % ("Orbot oder tor" if netz == "tor" else "i2pd oder I2P")
        return dict(anonym.zustand(verwaltung.daten()), token=bool(self.app.token), meldung=meldung)
