"""App-Store (appstore.py): Apps aus F-Droid, IzzyOnDroid, GitHub, Codeberg, GitLab und APKMB finden, laden und aktuell halten.

  GET  /api/appstore                     Stand (an, Verlauf, Favoriten, eigene Repos, ...) - immer erreichbar, auch wenn aus
  GET  /api/appstore/matrix              Suchmatrix: geprüfte Apps und ihre offiziellen Quellen (matrix.py) - immer erreichbar
  GET  /api/appstore/suche?q=&quellen=   Suche in allen (oder den genannten, mit Komma) Quellen
  GET  /api/appstore/app?id=             eine App mit Versionen und APKs (fdroid:paket, izzy:paket, github:o/r, codeberg:o/r, gitlab:gruppe/projekt, apkmb:slug)
  GET  /api/appstore/repo?id=            ein eingetragenes eigenes Repository (appstore.eigene_repos): Versionen bzw. Apps
  GET  /api/appstore/datei?name=         eine geladene APK (zum Speichern im Browser; per ?sitzung=…)
  POST /api/appstore                     {an: bool}  globaler Schalter - immer erlaubt, auch wenn gerade aus
                                         {aktion: laden, id, url, name}  -> {pfad, name, groesse}  (die App installiert dann)
                                         {aktion: updates, apps: {paket: {code, version, name}}} -> {updates: [...]}
                                         {aktion: sterne, benutzer}  Sterne eines GitHub-Nutzers als Favoriten
                                         oder eine Aenderung fuer appstore.aendern (installiert, favorit, beobachten, …)
Laden, Updates und Aenderungen brauchen das Recht "einstellungen". Bei appstore_an=False (Standard: an)
liefern alle Routen ausser dem Stand/der Matrix/dem Schalter selbst 404 - kein Fehler, nur Abwesenheit
(Muster mcp_server.py/nuvio_plugin.py).
"""

from . import appstore, matrix
from .oberflaeche_grund import json


class AppStoreMixin:

    def _store(self):
        if getattr(self.app, "appstore", None) is None:
            self.app.appstore = appstore.AppStore(self.app.datenordner, lambda: self.app.verwaltung)
        return self.app.appstore

    def appstore_lesen(self, pfad, werte):
        if pfad == "/api/appstore/matrix":
            return 200, "application/json", matrix.zustand()   # reine Daten, braucht weder Netz noch Nutzerdaten
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        if pfad == "/api/appstore":
            return 200, "application/json", appstore.oeffentlich(daten)
        if not appstore.eingeschaltet(daten):
            return 404, "application/json", {"fehler": "App-Store ist ausgeschaltet"}
        s = self._store()
        try:
            if pfad == "/api/appstore/suche":
                quellen = [q for q in str(werte.get("quellen") or "").split(",") if q] or None
                return 200, "application/json", s.suchen(werte.get("q", ""), quellen)
            if pfad == "/api/appstore/app":
                return 200, "application/json", s.app(werte.get("id", ""))
            if pfad == "/api/appstore/repo":
                repo = next((r for r in appstore.eigene_repos(daten) if r["id"] == werte.get("id")), None)
                if not repo:
                    return 400, "application/json", {"fehler": "Dieses Repository erst eintragen"}
                return 200, "application/json", s.eigener_repo_app(repo)
            return "lokal", s.datei(werte.get("name", ""))  # pfad == "/api/appstore/datei", letzte verbleibende Route
        except appstore.StoreFehler as fehler:
            return 400, "application/json", {"fehler": str(fehler)}

    def appstore_post(self, koerper):
        if not self.app.verwaltung:
            return 503, "application/json", {"fehler": "Nutzerdaten nicht verfügbar"}
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(wunsch, dict):
                raise ValueError("JSON-Objekt erwartet")
            if set(wunsch) == {"an"}:  # NUR der globale Schalter - {"favorit": ..., "an": ...} ist etwas anderes
                def schalten(d):
                    d["appstore_an"] = bool(wunsch.get("an"))
                    return appstore.oeffentlich(d)
                return 200, "application/json", self.app.verwaltung.bearbeiten(schalten)
            if not appstore.eingeschaltet(self.app.verwaltung.daten()):
                return 404, "application/json", {"fehler": "App-Store ist ausgeschaltet"}
            s = self._store()
            aktion = wunsch.get("aktion")
            if aktion == "laden":
                return 200, "application/json", s.laden(wunsch.get("id"), wunsch.get("url"), wunsch.get("name"))
            if aktion == "updates":
                ergebnis = s.updates(wunsch.get("apps"), self.app.verwaltung.daten())
                self.app.verwaltung.bearbeiten(lambda d: appstore.AppStore.schnappschuss_merken(d, wunsch.get("apps")))
                return 200, "application/json", {"updates": ergebnis}
            if aktion == "sterne":
                ids = s.sterne_holen(wunsch.get("benutzer"))

                def merken(d):
                    for app_id in reversed(ids):
                        appstore.AppStore.aendern(d, {"favorit": app_id, "an": True})
                    return dict(appstore.oeffentlich(d), neu=len(ids))
                return 200, "application/json", self.app.verwaltung.bearbeiten(merken)
            return 200, "application/json", self.app.verwaltung.bearbeiten(lambda d: appstore.AppStore.aendern(d, wunsch))
        except (ValueError, UnicodeDecodeError, OSError) as fehler:  # StoreFehler ist ein ValueError
            return 400, "application/json", {"fehler": str(fehler)}
