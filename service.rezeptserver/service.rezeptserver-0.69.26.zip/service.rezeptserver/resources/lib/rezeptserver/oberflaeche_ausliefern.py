"""Dateien und Kamerastreams an Browser ausliefern."""

import logging
import mimetypes
import os
import re
from urllib.parse import quote

from . import kameras

log = logging.getLogger("rezeptserver")


def datei_senden(handler, pfad):
    """Lokale Datei mit Range (Springen im Player); Typ nach Endung."""
    groesse = os.path.getsize(pfad)
    typ = mimetypes.guess_type(pfad)[0] or ("video/x-matroska" if pfad.lower().endswith(".mkv") else "application/octet-stream")
    anfang, ende = 0, groesse - 1
    bereich = re.match(r"bytes=(\d*)-(\d*)$", handler.headers.get("Range") or "")
    if bereich and groesse:
        if bereich.group(1):
            anfang = int(bereich.group(1))
            ende = min(int(bereich.group(2)), ende) if bereich.group(2) else ende
        elif bereich.group(2):
            anfang = max(0, groesse - int(bereich.group(2)))
        if anfang > ende:
            handler.send_response(416)
            handler.send_header("Content-Range", "bytes */%d" % groesse)
            handler.end_headers()
            return
    handler.send_response(206 if bereich else 200)
    handler.send_header("Content-Type", typ)
    handler.send_header("Accept-Ranges", "bytes")
    handler.send_header("Content-Length", str(ende - anfang + 1))
    if bereich:
        handler.send_header("Content-Range", "bytes %d-%d/%d" % (anfang, ende, groesse))
    handler.send_header("Content-Disposition", "inline; filename*=UTF-8''" + quote(os.path.basename(pfad)))
    handler.send_header("Cache-Control", "no-store")
    handler.end_headers()
    if handler.command == "HEAD":
        return
    rest = ende - anfang + 1
    try:
        with open(pfad, "rb") as f:
            f.seek(anfang)
            while rest > 0:
                block = f.read(min(rest, 256 * 1024))
                if not block:
                    break
                handler.wfile.write(block)
                rest -= len(block)
    except (BrokenPipeError, ConnectionResetError):
        pass


def kamera_senden(handler, kamera):
    """MJPEG-Strom einer IP-Kamera an den Browser durchreichen (bis der Browser schliesst)."""
    try:
        antwort = kameras.oeffnen(kamera, zeit=20)
    except kameras.KameraFehler as fehler:
        log.warning("Kamera %s: %s", kamera.get("name"), fehler)
        handler.send_error(502)
        return
    with antwort:
        handler.send_response(200)
        handler.send_header("Content-Type", antwort.headers.get("Content-Type") or "multipart/x-mixed-replace")
        handler.send_header("Cache-Control", "no-store")
        handler.end_headers()
        try:
            while True:
                teil = antwort.read(65536)
                if not teil:
                    break
                handler.wfile.write(teil)
        except (BrokenPipeError, ConnectionResetError, OSError):
            pass
