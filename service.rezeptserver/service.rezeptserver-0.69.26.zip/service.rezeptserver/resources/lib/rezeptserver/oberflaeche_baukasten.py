"""m0dul-Baukasten (Rundgang beim ersten Start) und Startanimation der App.

  GET  /api/baukasten               Katalog (Welten, Module mit Erklaerung, Stand), Sprachen, Layouts
  POST /api/baukasten               Auswahl uebernehmen {module, sprache, layout, akzent, startanimation} oder
                                    {ueberspringen: true}; danach gilt der Rundgang als erledigt
  POST /api/baukasten/neu           Rundgang beim naechsten Oeffnen wieder zeigen
  GET  /api/startanimation          die eigene Startanimation (Bild oder Video, mit Range)
  GET  /api/startanimation/info     {vorhanden, art, mime, groesse, zeit}
  POST /api/startanimation          Datei als Rohdaten (beliebige Endung, erkannt am Inhalt, bis 64 MB)
  POST /api/startanimation/weg      eigene Startanimation entfernen
"""

from .oberflaeche_grund import baukasten, einstellungen, json, sprachen, startanimation


class BaukastenMixin:

    def _nach_einstellungen(self, daten):
        """Nach Aenderungen an den Einstellungen: was der Server im Speicher haelt, nachziehen."""
        w = einstellungen.werte(daten)
        self.app.ui = einstellungen.pruefe(daten.get(einstellungen.SCHLUESSEL))
        self.app.audio_wunsch = sprachen.als_liste(w.get("audio"))
        self.app.untertitel_wunsch = sprachen.als_liste(w.get("untertitel"))

    def baukasten_lesen(self):
        if not self.app.verwaltung:
            return 503, "application/json", {"fehler": "Nutzerdaten nicht verfügbar"}
        # heimnetz: ob Fernseher Streams ueber H0rSt erreichen (Station "Fernseher & Geraete")
        return 200, "application/json", dict(baukasten.zustand(self.app.verwaltung.daten()), heimnetz=bool(self.app.token))

    def baukasten_post(self, pfad, koerper):
        if not self.app.verwaltung:
            return 503, "application/json", {"fehler": "Nutzerdaten nicht verfügbar"}
        try:
            wahl = json.loads(koerper.decode("utf-8") or "{}")
            if pfad == "/api/baukasten/neu":
                return 200, "application/json", self.app.verwaltung.bearbeiten(baukasten.neu_starten)
            ergebnis = self.app.verwaltung.bearbeiten(lambda d: baukasten.anwenden(d, wahl))
            self._nach_einstellungen(self.app.verwaltung.daten())
            return 200, "application/json", ergebnis
        except (ValueError, UnicodeDecodeError) as fehler:  # BaukastenFehler ist ein ValueError
            return 400, "application/json", {"fehler": str(fehler)}

    def startanimation_lesen(self, pfad):
        meta = startanimation.info(self.app.datenordner)
        if pfad == "/api/startanimation/info":
            if not meta:
                return 200, "application/json", {"vorhanden": False}
            return 200, "application/json", dict({k: v for k, v in meta.items() if k != "pfad"}, vorhanden=True)
        return ("lokal", meta["pfad"]) if meta else (404, "application/json", {"fehler": "keine eigene Startanimation"})

    def startanimation_post(self, pfad, koerper):
        try:
            if pfad == "/api/startanimation/weg":
                startanimation.entfernen(self.app.datenordner)
                return 200, "application/json", {"vorhanden": False}
            meta = startanimation.speichern(self.app.datenordner, koerper)
            return 200, "application/json", dict(meta, vorhanden=True)
        except (startanimation.AnimationsFehler, OSError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
