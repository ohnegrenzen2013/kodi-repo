"""Benachrichtigungen (benachrichtigungen.py): neue Folgen fuer Serien in Weiterschauen/Merkliste,
geprueft bei jedem Seitenaufruf - kein Push, nur eine aktualisierte Liste je Profil.

  GET /api/benachrichtigungen   prueft neue Folgen, liefert {"liste": [...]} des Profils der Anfrage
"""

from . import benachrichtigungen, sehen


class BenachrichtigungenMixin:

    def benachrichtigungen_lesen(self):
        if not self.app.verwaltung:
            return 503, "application/json", {"fehler": "Nutzerdaten nicht verfügbar"}
        profil_id = self._sehen_profil()

        def pruefen_und_lesen(d):
            listen = sehen.lesen(d, profil_id)
            serien = listen["weiterschauen"] + listen["merkliste"]
            benachrichtigungen.pruefen(d, profil_id, serien, self.app.entdecken)
            return {"liste": benachrichtigungen.lesen(d, profil_id)}

        return 200, "application/json", self.app.verwaltung.bearbeiten(pruefen_und_lesen)
