"""Beobachtungen (nach der Idee von autofetch.de): Suchen einmal anlegen, H0rSt prueft und meldet neue Treffer.

  GET  /api/beobachtungen                  Stand: Einstellung, Beobachtungen mit Treffern, moegliche Downloader
  POST /api/beobachtungen/einstellung      {an, minuten}  - ab Werk aus
  POST /api/beobachtungen/speichern        {id?, art, quelle, suche, name?, einmalig?, uebergeben?, ziel?, kategorie?, minuten?, min_mb?}
  POST /api/beobachtungen/loeschen         {id}
  POST /api/beobachtungen/pruefen          {id?}  jetzt pruefen (im Hintergrund, ohne id alle eingeschalteten)
  POST /api/beobachtungen/uebergeben       {id, treffer, ziel?}  einen Treffer an den eigenen Downloader geben

Nur mit Recht "downloads" (RECHT_FUER); Kinderprofile kommen nicht hin (kinder.py erlaubt den Pfad nie).
Zugangsschluessel (Indexer, Downloader) bleiben in ihrer eigenen Konfiguration und kommen in keine Antwort."""

import json
import threading

from . import beobachtungen, dienste


class _BeobachtungenMixin:
    def beobachtungen_aufbauen(self):
        """Callbacks fuer app.beobachtungen: eigene Indexer durchsuchen und Treffer an den Downloader geben."""
        def indexer(text):
            antwort = self._indexer_suche(text)
            ergebnis = []
            for t in antwort.get("treffer") or []:
                paket = str(t.get("nzb") or "").rsplit("/", 1)[-1]
                url = self.app.debrid.auspacken(paket) if paket else None
                if url:
                    ergebnis.append({"titel": t.get("titel"), "nzb_url": url, "datum": t.get("datum"), "groesse": t.get("groesse")})
            if antwort.get("fehler") and not ergebnis:
                raise beobachtungen.BeobachtungFehler(antwort["fehler"])
            return ergebnis

        def uebergabe(ziel, treffer, b):
            url = treffer["url"]
            daten = {"id": ziel, "name": treffer["titel"], "kategorie": b.get("kategorie") or ""}
            if treffer.get("art") == "torrent" and url.startswith("magnet:"):
                daten["magnet"] = url
            elif treffer.get("art") == "link":
                daten["link"] = url
            else:
                daten["url"] = url
            return self._dienst_hinzu(daten)["meldung"]

        self.app.beobachtungen.indexer = indexer
        self.app.beobachtungen.uebergabe = uebergabe

    def beobachtungen_lesen(self):
        self.beobachtungen_aufbauen()
        z = self.app.beobachtungen.zustand()
        z["ziele"] = [{"id": i, "name": c.name or c.typ_name, "kann": [k for k in ("nzb", "torrent", "link") if k in c.kann]}
                      for i, c in sorted(self.app.dienste.items()) if getattr(c, "typ", "") in dienste.DOWNLOAD_TYPEN
                      and any(k in c.kann for k in ("nzb", "torrent", "link"))]
        return z

    def beobachtungen_post(self, pfad, koerper):
        b = self.app.beobachtungen
        self.beobachtungen_aufbauen()
        try:
            daten = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(daten, dict):
                raise ValueError("JSON-Objekt erwartet")
            if not self.app.verwaltung:
                raise ValueError("Nutzerdaten nicht verfügbar")
            if pfad == "/api/beobachtungen/einstellung":
                b.einstellen({k: daten[k] for k in ("an", "minuten") if k in daten})
            elif pfad == "/api/beobachtungen/speichern":
                ziel = str(daten.get("ziel") or "")
                if ziel and ziel not in self.app.dienste:
                    raise ValueError("Unbekannter Downloader")
                b.speichern(daten)
            elif pfad == "/api/beobachtungen/loeschen":
                b.loeschen(str(daten.get("id") or ""))
            elif pfad == "/api/beobachtungen/pruefen":
                nur = str(daten.get("id") or "") or None
                if nur and not any(x["id"] == nur for x in b.einstellung()["liste"]):
                    raise ValueError("Beobachtung gibt es nicht")
                if daten.get("warten"):
                    b.pruefen(nur)
                elif not b.laeuft_gerade:
                    threading.Thread(target=b.pruefen, args=(nur,), name="beobachtungen-jetzt", daemon=True).start()
                return 200, "application/json", dict(self.beobachtungen_lesen(), laeuft=True)
            elif pfad == "/api/beobachtungen/uebergeben":
                ziel = str(daten.get("ziel") or "")
                if ziel and ziel not in self.app.dienste:
                    raise ValueError("Unbekannter Downloader")
                meldung = b.uebergeben(str(daten.get("id") or ""), str(daten.get("treffer") or ""), ziel or None)
                return 200, "application/json", dict(self.beobachtungen_lesen(), meldung=meldung)
            else:
                return 404, "application/json", {"fehler": "nicht gefunden"}
        except (ValueError, UnicodeDecodeError, beobachtungen.BeobachtungFehler) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        return 200, "application/json", self.beobachtungen_lesen()
