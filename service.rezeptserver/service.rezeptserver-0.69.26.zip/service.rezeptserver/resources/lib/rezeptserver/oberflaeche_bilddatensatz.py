"""Bild-Datensatz: lokale Bilder pruefen und als train/test aufteilen.

  GET  /api/bilddatensatz   Stand und Einstellungen (ohne Ordner zu lesen)
  POST /api/bilddatensatz   {aktion: "plan"|"start"} – plan liest nur, start
                            schreibt train/test und den Bericht.
"""

import json
import threading

from . import bild_datensatz

_SPERRE = threading.Lock()


class BildDatensatzMixin:

    def bilddatensatz_lesen(self):
        if not self.darf("dateien"):
            return 403, "application/json", {"fehler": "Kein Recht auf Dateien", "recht": True}
        werte = self._einstellungen_lesen().get("werte") or {}
        return 200, "application/json", bild_datensatz.zustand(werte)

    def bilddatensatz_post(self, koerper):
        if not self.darf("dateien"):
            return 403, "application/json", {"fehler": "Kein Recht auf Dateien", "recht": True}
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
        except (ValueError, UnicodeDecodeError):
            return 400, "application/json", {"fehler": "JSON-Fehler"}
        if not isinstance(wunsch, dict):
            return 400, "application/json", {"fehler": "JSON-Objekt erwartet"}
        aktion = str(wunsch.get("aktion") or "plan")
        if aktion not in ("plan", "start"):
            return 400, "application/json", {"fehler": "aktion: plan oder start"}
        werte = self._einstellungen_lesen().get("werte") or {}
        if werte.get("bildds_an") is not True:
            return 400, "application/json", {"fehler": "Bild-Datensatz-Werkzeug ist aus – erst in den Einstellungen einschalten."}
        if not _SPERRE.acquire(False):
            return 409, "application/json", {"fehler": "Es laeuft schon ein Lauf."}
        try:
            if aktion == "plan":
                p = bild_datensatz.plan(werte)
                return 200, "application/json", {
                    "aktion": "plan", "probe": p["probe"], "gesamt": p["gesamt"], "seed": p["w"]["seed"],
                    "klassen": {k: {"gelesen": v["gelesen"], "geprueft": v["geprueft"],
                                     "train": len(v["train"]), "test": len(v["test"])} for k, v in p["klassen"].items()},
                    "hinweis": "Nur gelesen – es wurde nichts geschrieben."}
            bericht = bild_datensatz.ausfuehren(werte)
            return 200, "application/json", {"aktion": "start", **bericht}
        except bild_datensatz.DatensatzFehler as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        except (OSError, ValueError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        finally:
            _SPERRE.release()
