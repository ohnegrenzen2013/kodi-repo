"""Brause – m0dul (brause.py): Lesezeichen, Favoriten, Erweiterungen und Einstellungen fuer die Brause-App.

  GET  /api/brause     Werte plus Such-Vorlage, Suchmaschinen und Vorschlaege fuer Erweiterungen
  POST /api/brause     eine Aenderung {aktion: lesezeichen|lesezeichen_weg|favorit|erweiterung|erweiterung_weg|einstellungen}
  GET  /brause/start   ressourcenleichte Quick-Link-Startseite (als "Startseite" in der Brause eintragen)
  GET  /brause/gx      O|Brause|GX: GX-Corner-Startseite mit Gaming-Zielen und Shortcuts
"""

import html

from .oberflaeche_grund import brause, json


def _start_html(kacheln):
    if kacheln:
        karten = "".join(
            '<a class="k" href="%s"><span class="b" style="background:%s">%s</span><span class="t">%s</span></a>'
            % (html.escape(k["url"], quote=True), k["farbe"], html.escape(k["buchstabe"]), html.escape(k["titel"]))
            for k in kacheln
        )
    else:
        karten = ('<p class="hinweis">Noch keine Lesezeichen – in der Brause mit ★ merken oder in H0rSt unter '
                  'Einstellungen → Brause eintragen.</p>')
    return """<!doctype html><html lang="de"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>H0rSt – Brause-Startseite</title>
<style>
body{margin:0;background:#141414;color:#eee;font:16px/1.4 Arial,Helvetica,sans-serif;
     display:flex;align-items:center;justify-content:center;min-height:100vh}
main{max-width:900px;width:100%%;padding:32px 16px;box-sizing:border-box}
h1{font-size:18px;font-weight:500;color:#999;text-align:center;margin:0 0 24px}
.raster{display:grid;grid-template-columns:repeat(auto-fill,minmax(120px,1fr));gap:16px}
.k{display:flex;flex-direction:column;align-items:center;gap:8px;text-decoration:none;color:#eee}
.k:focus,.k:hover{outline:2px solid #fff;border-radius:8px}
.b{width:64px;height:64px;border-radius:14px;display:flex;align-items:center;justify-content:center;
   font-size:28px;font-weight:600;color:#fff}
.t{font-size:13px;text-align:center;max-width:100px;overflow:hidden;text-overflow:ellipsis;white-space:nowrap}
.hinweis{color:#999;text-align:center}
</style></head><body><main><h1>H0rSt – Brause</h1><div class="raster">%s</div></main></body></html>""" % karten

_GX_ZIELE = [
    ("Kostenlos & Deals", "🎁", [
        ("Epic Games – Gratis-Spiele", "Jede Woche neue kostenlose Titel", "https://store.epicgames.com/de/free-games"),
        ("Steam-Angebote", "Aktuelle Rabatte im Steam Store", "https://store.steampowered.com/specials/"),
        ("GOG-Deals", "Rabatte und kostenlose Klassiker", "https://www.gog.com/de/games"),
        ("Humble Bundle", "Pakete und wohltätige Aktionen", "https://www.humblebundle.com/"),
        ("itch.io", "Indie-Spiele, kostenlos und experimentell", "https://itch.io/games/free"),
    ]),
    ("Gaming-News", "📰", [
        ("GameStar", "Tests, News und Hardware", "https://www.gamestar.de/"),
        ("PC Gamer", "PC-Gaming und Hardware", "https://www.pcgamer.com/"),
        ("IGN", "Spiele, Filme und Trailer", "https://de.ign.com/"),
        ("Eurogamer", "Tests und Hintergründe", "https://www.eurogamer.de/"),
    ]),
    ("Community & Streams", "🟣", [
        ("Twitch", "Live-Streams und Gaming", "https://www.twitch.tv/"),
        ("Discord", "Server und Sprachchat", "https://discord.com/app"),
        ("Reddit r/pcgaming", "Community und Diskussionen", "https://www.reddit.com/r/pcgaming/"),
    ]),
    ("Werkzeuge", "🛠", [
        ("ProtonDB", "Steam-Spiele unter Linux", "https://www.protondb.com/"),
        ("SteamDB", "Preise, Updates und Statistiken", "https://steamdb.info/"),
        ("IsThereAnyDeal", "Preisvergleich über alle Shops", "https://isthereanydeal.com/"),
        ("Can I Run It", "Systemanforderungen prüfen", "https://www.systemrequirementslab.com/cyri"),
    ]),
]


def _gx_html(d):
    akzent = html.escape(d.get("akzent") or "#ff2b4a", quote=True)
    seiten = "".join(
        '<a class="short" href="%s" target="_blank" rel="noopener noreferrer"><span>%s</span><b>%s</b></a>'
        % (html.escape(x.get("url", ""), quote=True), html.escape(x.get("symbol", "•")), html.escape(x.get("name", "")))
        for x in d.get("seiten") or [])
    gruppen = []
    for name, symbol, ziele in _GX_ZIELE:
        karten = "".join(
            '<a class="ziel" href="%s" target="_blank" rel="noopener noreferrer"><span class="sym">%s</span>'
            '<b>%s</b><small>%s</small></a>'
            % (html.escape(url, quote=True), html.escape(symbol), html.escape(titel), html.escape(text))
            for titel, text, url in ziele)
        gruppen.append('<section><h2><span>%s</span>%s</h2><div class="ziele">%s</div></section>' % (
            html.escape(symbol), html.escape(name), karten))
    return """<!doctype html><html lang="de"><head><meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>O|Brause|GX – GX Corner – H0rSt</title>
<style>
:root{--gx:%s;--grund:#08080b;--flaeche:#121218;--text:#f4f4f5;--leise:#a1a1aa}
*{box-sizing:border-box}body{margin:0;background:radial-gradient(1100px 600px at 85%% -10%%,color-mix(in srgb,var(--gx) 26%%,transparent),transparent 60%%),var(--grund);color:var(--text);font:16px/1.45 system-ui,Arial,sans-serif;min-height:100vh}
main{max-width:1180px;margin:0 auto;padding:28px 18px 56px}
header{display:flex;gap:14px;align-items:center;flex-wrap:wrap;margin-bottom:22px}
.logo{font:800 clamp(22px,4vw,38px)/1 system-ui;letter-spacing:-.04em}
.logo i{color:var(--gx);font-style:normal}
header p{color:var(--leise);margin:0;flex:1 1 260px}
header a.knopf{color:var(--text);text-decoration:none;border:1px solid var(--gx);border-radius:10px;padding:9px 14px;background:color-mix(in srgb,var(--gx) 14%%,transparent)}
.shortcuts{display:flex;gap:8px;flex-wrap:wrap;margin:0 0 22px}
.short{display:inline-flex;gap:8px;align-items:center;color:var(--text);text-decoration:none;background:var(--flaeche);border:1px solid #27272f;border-radius:12px;padding:8px 12px}
.short:hover,.short:focus-visible,.ziel:hover,.ziel:focus-visible{border-color:var(--gx);outline:none}
.short span{font-size:18px}
section{margin:24px 0}
h2{font-size:14px;letter-spacing:.12em;text-transform:uppercase;color:var(--leise);display:flex;gap:8px;align-items:center}
.ziele{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:10px}
.ziel{display:grid;gap:4px;text-decoration:none;color:var(--text);background:linear-gradient(160deg,#181820,#0e0e12);border:1px solid #27272f;border-radius:14px;padding:14px;position:relative;overflow:hidden}
.ziel::after{content:"";position:absolute;inset:auto -20%% -55%% auto;width:140px;height:140px;border-radius:50%%;background:var(--gx);opacity:.10;filter:blur(18px)}
.ziel .sym{font-size:24px}
.ziel b{font-size:15px}
.ziel small{color:var(--leise);font-size:12px}
.hinweis{color:var(--leise);font-size:13px;border-top:1px solid #27272f;padding-top:16px;margin-top:28px}
@media(max-width:520px){.ziele{grid-template-columns:1fr 1fr}main{padding:20px 12px 40px}.logo{font-size:24px}}
</style></head><body><main>
<header><div class="logo">O<i>|</i>Brause<i>|</i>GX</div>
<p>GX Corner: Der Firefox-Kern der Brause mit Shortcuts und dunkler Neon-Optik. Kein Konto, keine Cloud, keine fremde App nötig.</p>
<a class="knopf" href="https://operagx.gg/mobile-lp-android" target="_blank" rel="noopener noreferrer">Opera GX für Android</a></header>
<div class="shortcuts">%s</div>
%s
<p class="hinweis">O|Brause|GX ist H0rSt: Die Shortcuts öffnen die Dienste in der Brause. Spiele, Deals und News kommen von den verlinkten offiziellen Seiten; H0rSt lädt keine Werbe- oder Tracking-Skripte. Opera GX ist eine Marke von Opera Norway AS – H0rSt ist kein Opera-Produkt.</p>
</main></body></html>""" % (akzent, seiten, "".join(gruppen))


class BrauseMixin:

    def brause_lesen(self):
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        return 200, "application/json", brause.fuer_brause(brause.pruefe(daten.get(brause.SCHLUESSEL)))

    def brause_start_seite(self):
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        e = brause.pruefe(daten.get(brause.SCHLUESSEL))
        return 200, "text/html", _start_html(brause.start_kacheln(e))

    def brause_gx_seite(self):
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        e = brause.pruefe(daten.get(brause.SCHLUESSEL))
        return 200, "text/html", _gx_html(brause.gx_daten(e))

    def brause_post(self, koerper):
        if not self.app.verwaltung:
            return 503, "application/json", {"fehler": "Nutzerdaten nicht verfügbar"}
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
            return 200, "application/json", self.app.verwaltung.bearbeiten(lambda d: brause.aendern(d, wunsch))
        except (ValueError, UnicodeDecodeError) as fehler:  # BrauseFehler ist ein ValueError
            return 400, "application/json", {"fehler": str(fehler)}
