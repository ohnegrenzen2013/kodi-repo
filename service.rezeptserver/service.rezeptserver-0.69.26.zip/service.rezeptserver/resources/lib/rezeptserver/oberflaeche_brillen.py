"""Brille – HTTP-Endpunkte.

  GET  /api/brillen            -> brillen.zustand()
  GET  /api/autostart          -> autostart.zustand(daten)
  POST /api/autostart          -> autostart.speichern(daten, eintraege)
"""

import json as _json

from .oberflaeche_grund import autostart, brillen


class BrillenMixin:

    def brillen_lesen(self, pfad):
        if pfad == "/api/brillen":
            return 200, "application/json", brillen.zustand()
        if pfad == "/api/autostart":
            verwaltung = self.app.verwaltung
            daten = verwaltung.daten() if verwaltung else {}
            return 200, "application/json", autostart.zustand(daten)
        return None

    def autostart_speichern(self, koerper):
        if not self.app.verwaltung:
            return 503, "text/plain", "Keine Verwaltung"
        try:
            wunsch = _json.loads(koerper.decode("utf-8") or "{}")
        except Exception:
            return 400, "text/plain", "Kein gueltiges JSON"
        eintraege = wunsch.get("eintraege")
        if eintraege is None:
            return 400, "text/plain", "eintraege fehlt"
        try:
            ergebnis = self.app.verwaltung.bearbeiten(
                lambda d: autostart.speichern(d, eintraege)
            )
        except autostart.AutostartFehler as e:
            return 400, "text/plain", str(e)
        return 200, "application/json", ergebnis
