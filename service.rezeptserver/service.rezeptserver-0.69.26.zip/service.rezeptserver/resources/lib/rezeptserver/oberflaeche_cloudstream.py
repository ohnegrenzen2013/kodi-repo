"""CloudStream-Repositories: Listen ansehen, Extensions laden (keine DEX-Ausfuehrung)."""

from . import cloudstream_repo
from .oberflaeche_grund import json


class CloudStreamMixin:
    def cloudstream_lesen(self):
        d = getattr(self.app, "cloudstream", None)
        return 200, "application/json", {"repos": d.liste() if d else []}

    def cloudstream_post(self, koerper):
        d = getattr(self.app, "cloudstream", None)
        if d is None:
            return 503, "application/json", {"fehler": "CloudStream-Verwaltung nicht verfügbar"}
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
            aktion = wunsch.get("aktion") if isinstance(wunsch, dict) else None
            if aktion == "hinzufuegen":
                return 200, "application/json", {"repo": d.hinzufuegen(str(wunsch.get("url") or ""), str(wunsch.get("name") or "")),
                                                 "repos": d.liste()}
            if aktion == "entfernen":
                d.entfernen(str(wunsch.get("url") or ""))
            elif aktion == "installieren":
                return 200, "application/json", {"installiert": d.installieren(str(wunsch.get("url") or "")), "repos": d.liste()}
            else:
                raise cloudstream_repo.CloudStreamFehler("aktion: hinzufuegen, entfernen oder installieren")
            return 200, "application/json", {"repos": d.liste()}
        except (cloudstream_repo.CloudStreamFehler, ValueError, UnicodeDecodeError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
