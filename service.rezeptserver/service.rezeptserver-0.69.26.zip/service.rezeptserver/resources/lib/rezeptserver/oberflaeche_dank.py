"""Dank-Liste (dank.py) fuer Einstellungen -> Ueber.

  GET  /api/dank    {titel, untertitel, anzahl, gruppen: [{art, name, text, eintraege: [{..., aktiv}]}]}

aktiv ist True (eingerichtet bzw. angedockt), False (vorhanden, aber nicht in Betrieb) oder
None (nichts zu schalten - mitgelieferter Fremdcode und Vorbilder bekommen kein Laempchen).
Ohne Nutzerdaten gilt alles Schaltbare als nicht in Betrieb, die Liste selbst steht trotzdem.
"""

from .oberflaeche_grund import anbieter, baukasten, dank


class DankMixin:

    def dank_lesen(self):
        verwaltung = self.app.verwaltung
        daten = verwaltung.daten() if verwaltung else {}
        liste = anbieter.liste(verwaltung.module, daten) if verwaltung else []
        welten = baukasten.zustand(daten).get("welten") or []
        return 200, "application/json", dank.zustand(daten, liste, welten)
