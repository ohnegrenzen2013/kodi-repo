"""Dateibrowser (dateien.py): Downloads finden, abspielen, umbenennen, verschieben, loeschen; Ablage und externe Speicher.

  GET  /api/dateien                    Orte (mit freiem Platz), Ablage, ob ich die Ablage aendern darf
  GET  /api/dateien/liste?ort=&pfad=   Inhalt eines Ordners
  GET  /api/dateien/datei?ort=&pfad=   Datei abspielen oder laden (mit Range; im Browser per ?sitzung=…)
  POST /api/dateien                    {aktion: umbenennen|verschieben|loeschen|ordner, …}
                                       {aktion: ablage, pfad} | {aktion: ort_dazu, name, pfad} | {aktion: ort_weg, pfad}
                                       {aktion: app_orte, orte: [{pfad, name}]} (die App meldet SD-Karte/USB, ohne Root)
  Ablage und eigene Orte brauchen das Recht "speicher" (hoher Rang), alles andere "dateien".
"""

import json
import os

from . import dateien


class DateienMixin:

    def dateien_lesen(self, pfad, werte):
        d = self.app.dateien
        try:
            if pfad == "/api/dateien":
                return 200, "application/json", {"orte": d.orte(), "ablage": d.einstellung["ablage"], "speicher": self.darf("speicher")}
            if pfad == "/api/dateien/liste":
                return 200, "application/json", d.liste(werte.get("ort", ""), werte.get("pfad", ""))
            return "lokal", d.datei(werte.get("ort", ""), werte.get("pfad", ""))
        except (dateien.DateiFehler, OSError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}

    def dateien_post(self, koerper):
        d = self.app.dateien
        try:
            w = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(w, dict):
                raise ValueError("JSON-Objekt erwartet")
            a = w.get("aktion")
            if a in ("ablage", "ort_dazu", "ort_weg", "app_orte"):
                if not self.darf("speicher"):
                    return 403, "application/json", {"fehler": "Ablage und externe Speicher wählt, wer einen hohen Rang hat (Recht „Speicher“)", "recht": True}
                if a == "app_orte":
                    d.app_orte = [{"name": "Extern: " + (str(o.get("name") or "") or os.path.basename(str(o.get("pfad")).rstrip("/"))), "pfad": str(o["pfad"]),
                                   "art": "extern"} for o in (w.get("orte") or [])[:10] if isinstance(o, dict) and os.path.isabs(str(o.get("pfad") or ""))
                                  and os.path.isdir(str(o["pfad"]))]
                else:
                    wunsch = {"ablage": w.get("pfad")} if a == "ablage" else {"ort_dazu": {"name": w.get("name"), "pfad": w.get("pfad")}} \
                        if a == "ort_dazu" else {"ort_weg": w.get("pfad")}
                    if not self.app.verwaltung:
                        raise ValueError("Nutzerdaten nicht verfügbar")
                    e = self.app.verwaltung.bearbeiten(lambda daten: dateien.aendern(daten, wunsch, d))
                    dateien.anwenden(self.app, e)
                return 200, "application/json", {"orte": d.orte(), "ablage": d.einstellung["ablage"], "speicher": True}
            ort, rel = w.get("ort", ""), w.get("pfad", "")
            if a == "umbenennen":
                d.umbenennen(ort, rel, w.get("name"))
            elif a == "verschieben":
                d.verschieben(ort, rel, w.get("ziel_ort", ""), w.get("ziel_pfad", ""))
            elif a == "loeschen":
                d.loeschen(ort, rel)
            elif a == "ordner":
                d.ordner_neu(ort, rel, w.get("name"))
            else:
                raise ValueError("Unbekannte Aktion")
            ordner = w.get("zeigen", os.path.dirname(rel.rstrip("/")) if a != "ordner" else rel)
            return 200, "application/json", d.liste(ort, ordner)
        except (ValueError, UnicodeDecodeError, OSError) as fehler:  # DateiFehler ist ValueError
            return 400, "application/json", {"fehler": str(getattr(fehler, "strerror", None) or fehler)}
