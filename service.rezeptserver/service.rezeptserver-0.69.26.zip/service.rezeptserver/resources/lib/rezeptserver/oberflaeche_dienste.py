"""DiensteMixin
"""

from .oberflaeche_dienste_grund import *

from .oberflaeche_dienste_zentrale import _ZentraleMixin
from .oberflaeche_dienste_rustnzb import _RustnzbMixin
from .oberflaeche_dienste_debrid import _DebridMixin
from .oberflaeche_dienste_vxparser import _VxparserMixin
from .oberflaeche_dienste_stack import _StackMixin
from .oberflaeche_dienste_seerr import _SeerrMixin
from .oberflaeche_beobachtungen import _BeobachtungenMixin


class DiensteMixin(_BeobachtungenMixin, _SeerrMixin, _StackMixin, _ZentraleMixin, _RustnzbMixin, _DebridMixin, _VxparserMixin):
    """DiensteMixin aus den Teil-Mixins; aussen bleibt alles gleich (rezeptserver.oberflaeche_dienste.*)."""
