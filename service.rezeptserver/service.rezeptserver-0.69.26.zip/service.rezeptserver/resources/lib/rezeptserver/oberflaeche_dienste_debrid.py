"""Debrid: Hoster-Links freischalten und Uebersicht."""

from . import debrid_bibliothek
from .oberflaeche_dienste_grund import (
    NetzFehler,
    debrid,
    stremio,
)

class _DebridMixin:

    # --- Debrid: Hoster-Links freischalten -------------------------------------------
    def debrid_lesen(self):
        d = self.app.debrid
        return {"dienste": [{"id": i, "name": n, "dienst": debrid.NAMEN.get(t, t)} for i, n, t, _ in d.konten],
                "hoster": len(d.hoster()) if d.verfuegbar else 0}

    def debrid_cloud_lesen(self, werte):
        nur = str(werte.get("anbieter") or "") or None
        return 200, "application/json", self.app.debrid.cloud_liste(nur)

    def debrid_cloud_link(self, daten):
        try:
            r = self.app.debrid.cloud_link(str(daten.get("anbieter") or ""), str(daten.get("art") or "torrent"),
                                           str(daten.get("id") or ""), str(daten.get("datei") or ""))
        except (debrid.DebridFehler, NetzFehler) as fehler:
            raise ValueError(str(fehler))
        return {"url": r["url"], "dateiname": r.get("dateiname") or "", "groesse": r.get("groesse") or 0,
                "dienst": r.get("dienst") or ""}
    # --- Debrid-Cloud-Bibliothek (NV3, bisher nur TorBox) -----------------------------
    def _torbox_schluessel(self):
        for _, _, dienst, schluessel in self.app.debrid.konten:
            if dienst == debrid_bibliothek.DIENST:
                return schluessel
        return ""

    def debrid_bibliothek_lesen(self, werte):
        schluessel = self._torbox_schluessel()
        if not schluessel:
            return {"eingerichtet": False, "eintraege": []}
        art = werte.get("art", "torrents")
        if art not in debrid_bibliothek.ARTEN:
            raise ValueError("Art muss torrents, usenet oder web sein")
        return {"eingerichtet": True, "eintraege": debrid_bibliothek.liste(schluessel, art, self.app.debrid.holen)}

    def debrid_bibliothek_abspielen(self, daten):
        schluessel = self._torbox_schluessel()
        if not schluessel:
            raise ValueError("Kein TorBox-Konto eingetragen (Anbieter → Hoster & Debrid)")
        art = str(daten.get("art") or "")
        eintrag_id = daten.get("eintrag_id")
        datei_id = daten.get("datei_id")
        if art not in debrid_bibliothek.ARTEN or eintrag_id is None or datei_id is None:
            raise ValueError("art, eintrag_id und datei_id angeben")
        try:
            url = debrid_bibliothek.aufloesen(schluessel, art, eintrag_id, datei_id, self.app.debrid.holen)
        except (debrid.DebridFehler, NetzFehler) as fehler:
            raise ValueError(str(fehler))
        return {"url": url}

    def debrid_freischalten(self, daten):
        links = daten.get("links")
        if links is None:
            links = [daten.get("link", "")]
        if isinstance(links, str):
            links = links.split()
        if not isinstance(links, list):
            raise ValueError("links muss eine Liste sein")
        links = [str(l).strip() for l in links if str(l).strip()][:20]
        if not links:
            raise ValueError("Mindestens einen Link angeben")
        nur = str(daten.get("anbieter") or "") or None
        ergebnisse = []
        for link in links:
            try:
                r = self.app.debrid.freischalten(link, nur)
                ergebnisse.append({"link": link, "ok": True, "url": r["url"], "dateiname": r.get("dateiname") or "",
                                   "groesse": stremio._groesse({"groesse": r["groesse"]}) if r.get("groesse") else "",
                                   "dienst": r["dienst"], "abspielen": self.app.debrid_adresse(link)})
            except (debrid.DebridFehler, NetzFehler) as fehler:
                ergebnisse.append({"link": link, "ok": False, "fehler": str(fehler)})
        return {"ergebnisse": ergebnisse}
