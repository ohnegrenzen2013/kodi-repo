"""rustnzb: Status, Aktionen und Server aus den Usenet-Providern."""

from .oberflaeche_dienste_grund import (
    NetzFehler,
    anbieter,
    anbindungen,
    base64,
    log,
    rustnzb,
    urlsplit,
)

class _RustnzbMixin:

    # --- rustnzb ------------------------------------------------------------------------
    def _rustnzb(self):
        if not self.app.rustnzb:
            raise rustnzb.RustnzbFehler("rustnzb ist nicht eingerichtet: im Bereich Anbieter die Vorlage "
                                        "„rustnzb“ (Downloader) anlegen")
        return self.app.rustnzb

    def rustnzb_lesen(self):
        r = self.app.rustnzb
        if not r:
            return {"verfuegbar": False}
        ergebnis = {"verfuegbar": True, "url": r.url, "fehler": ""}
        try:
            s = r.status()
        except (rustnzb.RustnzbFehler, NetzFehler) as fehler:
            return dict(ergebnis, fehler=str(fehler))
        ergebnis["status"] = {"version": s.get("version", ""), "pausiert": bool(s.get("paused")),
                              "geschwindigkeit": int(s.get("speed_bps") or 0), "jobs": s.get("queue_size", 0),
                              "frei": s.get("disk_space_free"), "mediathek": bool(s.get("webdav_enabled")),
                              "mediathek_moeglich": bool(s.get("webdav_available")),
                              "verbindungen": sum(int(c.get("connected") or 0) for c in s.get("nntp_connections") or [])}
        for name, abruf in (("warteschlange", r.warteschlange), ("verlauf", r.verlauf)):
            try:
                ergebnis[name] = abruf()
            except (rustnzb.RustnzbFehler, NetzFehler) as fehler:
                ergebnis[name] = {"fehler": str(fehler)}
        if s.get("webdav_enabled"):
            try:
                m = r.mediathek_status()
                ergebnis["mediathek"] = {"wartet": [q.get("job_name") for q in m.get("queue") or []],
                                         "verlauf": [{"name": h.get("job_name"), "status": h.get("status"),
                                                      "fehler": h.get("fail_message") or ""}
                                                     for h in (m.get("history") or [])[:30]]}
            except (rustnzb.RustnzbFehler, NetzFehler) as fehler:
                ergebnis["mediathek"] = {"fehler": str(fehler)}
        return ergebnis

    def rustnzb_aktion(self, daten):
        self._rustnzb().aktion(str(daten.get("was", "")), daten.get("id") or None)
        return self.rustnzb_lesen()

    def rustnzb_nzb(self, daten):
        r = self._rustnzb()
        if daten.get("url"):
            name = daten.get("name") or urlsplit(str(daten["url"])).path.rsplit("/", 1)[-1] or "download"
            inhalt = rustnzb.nzb_laden(str(daten["url"]))
        elif daten.get("inhalt"):
            try:
                inhalt = base64.b64decode(str(daten["inhalt"]), validate=True)
            except ValueError:
                raise ValueError("inhalt muss Base64 sein")
            name = daten.get("name") or "upload"
        else:
            raise ValueError("url oder inhalt angeben")
        ids = r.nzb_hinzufuegen(str(name), inhalt, daten.get("kategorie"))
        log.info("NZB %s an rustnzb übergeben", rustnzb.job_name(name).split("{{")[0])
        return dict(self.rustnzb_lesen(), neu=ids)

    def rustnzb_server(self, daten):
        provider = [(i, e["name"], w) for i, e, w in anbindungen.eigene(self.app.verwaltung.daten(), "nntp")
                    if w.get("host") and w.get("user") and w.get("pass")]
        if not provider:
            raise anbieter.AnbieterFehler("Keine vollständigen Usenet-Provider (Kategorie Usenet-Provider)")
        ergebnis = self._rustnzb().server_uebernehmen(provider)
        return {"server": [{"name": n, "aktion": a, "test": t} for n, a, t in ergebnis]}
