"""Seerr-Anfragen (Overseerr/Jellyseerr) in H0rSt: Titel suchen, Film oder Serie anfragen, Stand sehen.

  GET  /api/dienste/seerr                 {aktiv, dienste:[{id, name}]} - ohne eingerichtetes Seerr ist alles aus
  GET  /api/dienste/seerr/suche?q=&id=    Treffer mit Stand (verfuegbar, angefragt ...) und "anfragbar"
  POST /api/dienste/seerr/anfrage         {id, art: movie|tv, tmdb, staffeln?, titel?} - nur auf ausdruecklichen Klick

Kinderprofile sind ausgesperrt (kinder.py erlaubt /api/dienste/ nie); Gaeste und Mitglieder ohne Recht "downloads" auch.
Der API-Schluessel bleibt im Dienst-Objekt und kommt nie in eine Antwort."""


class _SeerrMixin:
    def _seerr_waehlen(self, werte):
        alle = self._dienste(("seerr",))
        if not alle:
            raise ValueError("Seerr ist nicht eingerichtet (Bereich Anbieter → Vorlage „Seerr“)")
        kennung = str(werte.get("id") or "")
        if kennung:
            if kennung not in alle:
                raise ValueError("Unbekannter Dienst")
            return kennung, alle[kennung]
        return next(iter(alle.items()))

    def seerr_lesen(self, teil, werte):
        if teil == "seerr":
            alle = self._dienste(("seerr",))
            return {"aktiv": bool(alle), "dienste": [{"id": i, "name": c.name} for i, c in alle.items()]}
        if teil != "seerr/suche":
            return None
        kennung, c = self._seerr_waehlen(werte)
        text = " ".join(str(werte.get("q", "")).split())[:120]
        if len(text) < 2:
            return {"treffer": [], "dienst_id": kennung}
        return {"treffer": [dict(t, dienst_id=kennung) for t in c.suchen(text)], "dienst_id": kennung}

    def seerr_anfrage_stellen(self, daten):
        kennung, c = self._seerr_waehlen(daten)
        art = str(daten.get("art", ""))
        staffeln = daten.get("staffeln")
        tmdb = daten.get("tmdb")
        meldung = c.anfrage_stellen(art, tmdb, staffeln)
        titel = " ".join(str(daten.get("titel") or "").split())[:80]
        self._aktionslog().eintragen("anfrage", "%s: %s %s angefragt" % (c.name, "Serie" if art == "tv" else "Film", titel or "TMDb " + str(tmdb)))
        return {"meldung": meldung}
