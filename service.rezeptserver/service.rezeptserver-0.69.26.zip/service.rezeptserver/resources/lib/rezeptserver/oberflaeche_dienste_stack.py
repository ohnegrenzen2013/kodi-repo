"""Stack-Seite (Usenet-Kompass, StreamDocker-Ideen): Verbindungen mit Test, Gesundheit, Layout-Hinweise, Verbrauch und
der Verknuepfen-Assistent. Lesen ist frei; Aendern an Sonarr/Radarr/Prowlarr nur ueber Vorschau + Bestaetigung (plan_id)."""

from . import aktionslog, stack_verknuepfen, stack_zustand


class _StackMixin:
    def _stack_jellyfin(self):
        """Eingerichtete Jellyfin-Server (aus den eigenen Anbietern); der Schluessel bleibt hier."""
        from .anbindungen_grund import eigene
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        return [(i, e.get("name") or "Jellyfin", w) for i, e, w in eigene(daten, "jellyfin") if w.get("url")]

    def stack_lesen(self, teil, werte):
        alle = self._dienste()
        if teil == "stack/test":  # eine Verbindung pruefen (StreamDocker-Idee: Test-Knopf je Dienst)
            kennung = str(werte.get("id", ""))
            if kennung.startswith("jellyfin:"):
                treffer = [(i, n, w) for i, n, w in self._stack_jellyfin() if "jellyfin:" + i == kennung]
                if not treffer:
                    raise ValueError("Unbekannter Dienst")
                return stack_zustand.jellyfin(treffer[0][1], treffer[0][2].get("url"), treffer[0][2].get("api_key", ""))
            c = alle.get(kennung)
            if not c:
                raise ValueError("Unbekannter Dienst")
            return dict(stack_zustand.einzeln(c), id=kennung)
        if teil != "stack":
            return None
        auftraege = {i: (lambda c=c: stack_zustand.einzeln(c)) for i, c in alle.items()}
        for i, n, w in self._stack_jellyfin():
            auftraege["jellyfin:" + i] = (lambda n=n, w=w: stack_zustand.jellyfin(n, w.get("url"), w.get("api_key", "")))
        antworten = self._parallel(auftraege)
        zustaende = []
        for i, (r, f) in antworten.items():
            z = r or {"name": i, "typ": "", "typ_name": i, "ok": False, "text": f, "ms": None, "meldungen": []}
            zustaende.append(dict(z, id=i))
        hinweise, ordner, downloader = [], {}, {}
        arrs = [c for c in alle.values() if c.typ in ("sonarr", "radarr")]
        pro = [c for c in alle.values() if c.typ == "prowlarr"]
        lesen = {}
        for c in arrs:
            lesen["arr:" + c.name] = (lambda c=c: stack_zustand.arr_hinweise(c))
        for c in alle.values():
            if c.typ in ("nzbget", "sabnzbd"):
                lesen["dl:" + c.name] = (lambda c=c: stack_zustand.downloader_lesen(c))
        for c in pro:
            lesen["pro:" + c.name] = (lambda c=c: stack_zustand.prowlarr_hinweise(c, arrs))
        for k, (r, f) in self._parallel(lesen).items():
            if f:
                hinweise.append(stack_zustand._hinweis("hinweis", k.split(":", 1)[1], "Konnte nicht gelesen werden: " + f))
            elif k.startswith("arr:"):
                hinweise.extend(r[0])
                ordner[k[4:]] = r[1]
            elif k.startswith("dl:"):
                hinweise.extend(r["hinweise"])
                downloader[k[3:]] = r["pfade"]
            else:
                hinweise.extend(r)
        hinweise.extend(stack_zustand.pfad_abgleich(ordner, downloader))
        return {"dienste": zustaende, "hinweise": hinweise, "fazit": stack_zustand.zusammenstellen(zustaende, hinweise),
                "auswahl": {t: [{"id": i, "name": c.name} for i, c in alle.items() if c.typ in typen]
                            for t, typen in (("prowlarr", ("prowlarr",)), ("sonarr", ("sonarr",)), ("radarr", ("radarr",)),
                                             ("downloader", stack_verknuepfen.UNTERSTUETZTE_DOWNLOADER))}}

    def stack_verbrauch(self, werte):
        c = self._dienst({"id": werte.get("id")}, ("nzbget", "sabnzbd"))
        return {"server": stack_zustand.verbrauch(c)}

    def stack_profile(self, werte):
        c = self._dienst({"id": werte.get("id")}, ("sonarr", "radarr"))
        return {"profile": [{"id": p.get("id"), "name": p.get("name")} for p in c.api("qualityprofile") or [] if isinstance(p, dict)]}

    def stack_vorschau(self, daten):
        try:
            opt = stack_verknuepfen.optionen_lesen(daten, self.app.dienste)
            return stack_verknuepfen.vorschau(opt, self.app.dienste)
        except stack_verknuepfen.PlanFehler as fehler:
            raise ValueError(str(fehler))

    def stack_anwenden(self, daten):
        try:
            opt = stack_verknuepfen.optionen_lesen(daten, self.app.dienste)
            r = stack_verknuepfen.anwenden(opt, self.app.dienste, daten.get("plan_id"))
        except stack_verknuepfen.PlanFehler as fehler:
            raise ValueError(str(fehler))
        log = self._aktionslog()
        for e in r["ergebnis"]:
            log.eintragen("stack", "%s: %s" % (e["titel"], e["text"]), e["ok"])
        return r

    def _aktionslog(self):
        with self._sperre:
            if not hasattr(self, "_aktionslog_obj"):
                self._aktionslog_obj = aktionslog.AktionsLog(getattr(self.app, "datenordner", ""))
        return self._aktionslog_obj

    def aktionen_lesen(self):
        return {"aktionen": self._aktionslog().lesen(100)}
