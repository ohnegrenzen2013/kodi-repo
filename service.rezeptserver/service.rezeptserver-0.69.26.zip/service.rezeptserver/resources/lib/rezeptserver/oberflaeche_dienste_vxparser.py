"""vxparser: Server, Zugriff, Listen und EPG."""

from .oberflaeche_dienste_grund import (
    NetzFehler,
    anbieter,
    anbindungen,
    vorlagen,
    vxparser,
)

class _VxparserMixin:

    # --- vxparser ------------------------------------------------------------------
    def vx_lesen(self):
        daten = self.app.verwaltung.daten()
        server = [{"id": i, "name": e["name"], "url": w.get("url") or vxparser.STANDARD_ADRESSE}
                  for i, e, w in anbindungen.eigene(daten, "vxparser")]
        return {"server": server, "standard": vxparser.STANDARD_ADRESSE, "benutzer": vxparser.BENUTZER,
                "links": vxparser.links_uebersicht(daten), "urls_json": vxparser.urls_json(daten)}

    def _vx_client(self, anbieter_id):
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        server = anbindungen.eigene(daten, "vxparser")
        auswahl = next((s for s in server if s[0] == anbieter_id), None) or (server[0] if server else None)
        url = vxparser.adresse_pruefen(auswahl[2].get("url") if auswahl else "")
        with self._sperre:
            client = self._vx.get(url)
            if client is None:
                client = self._vx[url] = vxparser.Client(url, holen=self._holen())
        return client

    def vx_zugriff(self, was, werte):
        try:
            client = self._vx_client(werte.get("anbieter", ""))
            if was == "zustand":
                if werte.get("neu"):
                    client.leeren()
                ergebnis = client.zustand()
            elif was == "kategorien":
                ergebnis = {"kategorien": client.kategorien(werte.get("art", "live"))}
            elif was == "inhalte":
                ergebnis = {"inhalte": client.inhalte(werte.get("art", "live"), werte.get("kategorie"),
                                                      werte.get("q", ""))}
            elif was == "serie":
                ergebnis = {"folgen": client.serie(werte.get("id", ""))}
            elif was == "listen":
                ergebnis = {"listen": client.listen(), "m3u": client.m3u_adresse(),
                            "epg": client.url + "/xmltv.php?username=%s&password=%s" % (client.benutzer,
                                                                                         client.passwort)}
            elif was == "abspielen":
                ziel = client.aufloesen(werte.get("art", "live"), werte.get("id", ""), werte.get("endung"))
                if not ziel:
                    return 404, "application/json", {"fehler": "vxparser liefert keinen Stream"}
                ergebnis = {"url": ziel}
            else:
                return 404, "application/json", {"fehler": "nicht gefunden"}
        except (vxparser.VxFehler, NetzFehler) as fehler:
            return 502, "application/json", {"fehler": str(fehler)}
        return 200, "application/json", ergebnis

    def vx_links(self, daten):
        """{schluessel: url}; leere Adresse entfernt den eigenen Link (vxparser nimmt dann seinen Standard)."""
        verwaltung = self.app.verwaltung
        unbekannt = [k for k in daten if k not in vxparser.SCHLUESSEL]
        if unbekannt:
            raise ValueError("Unbekannte vxparser-Links: %s" % ", ".join(unbekannt))

        def setzen(d):
            for schluessel, url in daten.items():
                url = str(url or "").strip()
                if url and not url.lower().startswith(("http://", "https://")):
                    url = "https://" + url
                vorhanden = next((i for i, e in (d.get("anbieter") or {}).items()
                                  if e.get("vorlage") == vxparser.link_vorlage(schluessel)), None)
                if not url or url == vxparser.SCHLUESSEL[schluessel][0]:
                    if vorhanden:
                        anbieter.entfernen(d, vorhanden)
                    continue
                vorlagen.anlegen(d, verwaltung.module, vxparser.link_vorlage(schluessel), {"url": url})
        verwaltung.aendern(setzen)
        return self.vx_lesen()

    def vx_liste(self, daten):
        url = str(daten.get("url", "")).strip()
        if not url.lower().startswith(("http://", "https://")):
            raise ValueError("Adresse der Liste fehlt")
        return self.liste_aufnehmen(daten.get("name") or "vxparser", url)
