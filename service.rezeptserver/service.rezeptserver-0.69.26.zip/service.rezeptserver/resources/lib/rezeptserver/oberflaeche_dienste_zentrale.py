"""Dienste-Zentrale (wie nzb360): Uebersicht, Downloads, Kalender und Aktionen."""

import json
import os

from . import dienste_medien_verlauf as verlauf_modul
from .oberflaeche_dienste_grund import (
    NetzFehler,
    base64,
    dienste,
    rustnzb,
    urlsplit,
)

class _ZentraleMixin:
    # --- Dienste-Zentrale (wie nzb360) ------------------------------------------------
    def _parallel(self, auftraege, zeit=15.0):
        """{schluessel: funktion} parallel ausfuehren; {schluessel: (ergebnis, fehler)}."""
        if not auftraege:
            return {}
        with self._sperre:
            if not hasattr(self, "_dienst_pool"):
                from concurrent.futures import ThreadPoolExecutor
                self._dienst_pool = ThreadPoolExecutor(max_workers=8, thread_name_prefix="dienst")
        zukuenfte = {k: self._dienst_pool.submit(f) for k, f in auftraege.items()}
        ergebnis = {}
        for k, z in zukuenfte.items():
            try:
                ergebnis[k] = (z.result(timeout=zeit), "")
            except Exception as fehler:  # ein Dienst darf die Uebersicht nie abbrechen
                ergebnis[k] = (None, str(fehler) or fehler.__class__.__name__)
        return ergebnis

    def _dienste(self, typen=None):
        return {i: c for i, c in self.app.dienste.items() if typen is None or c.typ in typen}

    @staticmethod
    def _dienst_info(i, c):
        art = "download" if c.typ in dienste.DOWNLOAD_TYPEN else "arr" if c.typ in dienste.ARR_TYPEN else c.typ
        return {"id": i, "name": c.name, "typ": c.typ, "typ_name": c.typ_name, "art": art,
                "kann": list(getattr(c, "kann", ())), "url": c.url}

    def dienste_lesen(self, pfad, werte):
        teil = pfad[len("/api/dienste"):].strip("/")
        try:
            daten = self._dienste_teil(teil, werte)
        except (ValueError, dienste.DienstFehler, NetzFehler) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        if daten is None:
            return 404, "application/json", {"fehler": "nicht gefunden"}
        return 200, "application/json", daten

    def _dienste_teil(self, teil, werte):
        if teil in ("stack", "stack/test"):
            return self.stack_lesen(teil, werte)
        if teil == "stack/verbrauch":
            return self.stack_verbrauch(werte)
        if teil == "stack/profile":
            return self.stack_profile(werte)
        if teil in ("seerr", "seerr/suche"):
            return self.seerr_lesen(teil, werte)
        if teil == "aktionen":
            return self.aktionen_lesen()
        if teil == "linkziele":  # Downloader, die Links nehmen (ASUS Download Master: HTTP, FTP, Magnet, ed2k)
            return {"ziele": [self._dienst_info(i, c) for i, c in self._dienste().items() if "link" in getattr(c, "kann", ())]}
        if teil == "":
            alle = self._dienste()
            auftraege = {}
            for i, c in alle.items():
                if c.typ in dienste.DOWNLOAD_TYPEN:
                    auftraege[i] = c.zustand
                elif c.typ == "seerr":
                    auftraege[i] = lambda c=c: c.anfragen("pending")
                elif c.typ == "tautulli":
                    auftraege[i] = c.aktivitaet
                elif c.typ == "bazarr":
                    auftraege[i] = c.fehlend
                elif c.typ == "kodi":
                    auftraege[i] = c.jetzt
                elif c.typ == "pihole":
                    auftraege[i] = c.zustand
                elif c.typ in dienste.ARR_TYPEN:
                    auftraege[i] = lambda c=c: c.kalender(7)
            antworten = self._parallel(auftraege)
            karten = []
            for i, c in alle.items():
                info = self._dienst_info(i, c)
                ergebnis, fehler = antworten.get(i, (None, ""))
                info["fehler"] = fehler
                if ergebnis is not None:
                    if info["art"] == "download":
                        info["kurz"] = {"tempo": ergebnis["tempo"], "jobs": len(ergebnis["jobs"]),
                                        "pausiert": ergebnis["pausiert"], "version": ergebnis.get("version", "")}
                    elif c.typ == "seerr":
                        info["kurz"] = {"offen": len(ergebnis)}
                    elif c.typ == "tautulli":
                        info["kurz"] = {"streams": ergebnis["anzahl"]}
                    elif c.typ == "bazarr":
                        info["kurz"] = {"folgen": ergebnis["folgen"], "filme": ergebnis["filme"]}
                    elif c.typ in ("kodi", "pihole"):
                        info["kurz"] = ergebnis
                    elif info["art"] == "arr":
                        info["kurz"] = {"woche": len(ergebnis)}
                karten.append(info)
            return {"dienste": karten}
        if teil == "downloads":
            alle = self._dienste(dienste.DOWNLOAD_TYPEN)
            antworten = self._parallel({i: c.zustand for i, c in alle.items()})
            return {"clients": [dict(self._dienst_info(i, c), zustand=antworten[i][0], fehler=antworten[i][1])
                                for i, c in alle.items()]}
        if teil == "kalender":
            tage = max(1, min(int(werte.get("tage", "30")) if str(werte.get("tage", "30")).isdigit() else 30, 120))
            antworten = self._parallel({i: (lambda c=c: c.kalender(tage)) for i, c in self._dienste(dienste.ARR_TYPEN).items()})
            eintraege = sorted((e for r, _ in antworten.values() if r for e in r), key=lambda e: e["datum"])
            return {"eintraege": eintraege, "fehler": {self.app.dienste[i].name: f for i, (_, f) in antworten.items() if f}}
        if teil == "arr":
            was = werte.get("was", "warteschlange")
            if was not in ("warteschlange", "zuletzt", "fehlend"):
                raise ValueError("was muss warteschlange, zuletzt oder fehlend sein")
            antworten = self._parallel({i: getattr(c, was) for i, c in self._dienste(dienste.ARR_TYPEN).items()})
            return {"eintraege": [e for r, _ in antworten.values() if r for e in r],
                    "fehler": {self.app.dienste[i].name: f for i, (_, f) in antworten.items() if f}}
        if teil == "anfragen":
            filter_ = werte.get("filter", "pending")
            if filter_ not in ("pending", "all", "approved", "processing", "available"):
                raise ValueError("unbekannter Filter")
            antworten = self._parallel({i: (lambda c=c: c.anfragen(filter_)) for i, c in self._dienste(("seerr",)).items()})
            return {"anfragen": [dict(e, dienst_id=i) for i, (r, _) in antworten.items() if r for e in r],
                    "fehler": {self.app.dienste[i].name: f for i, (_, f) in antworten.items() if f}}
        if teil == "suche":
            text = " ".join(str(werte.get("q", "")).split())[:200]
            art = werte.get("art", "search")
            if art not in ("search", "movie", "tvsearch"):
                raise ValueError("unbekannte Suchart")
            if len(text) < 2:
                return {"treffer": []}
            antworten = self._parallel({i: (lambda c=c: c.suche(text, art)) for i, c in self._dienste(("prowlarr",)).items()},
                                       zeit=70.0)
            treffer = [dict(e, dienst_id=i) for i, (r, _) in antworten.items() if r for e in r]
            treffer.sort(key=lambda e: -(e.get("grabs") or 0))
            return {"treffer": treffer, "fehler": {self.app.dienste[i].name: f for i, (_, f) in antworten.items() if f}}
        if teil == "aktivitaet":
            auftraege = {i: c.aktivitaet for i, c in self._dienste(("tautulli",)).items()}
            auftraege.update({i: c.fehlend for i, c in self._dienste(("bazarr",)).items()})
            antworten = self._parallel(auftraege)
            return {"tautulli": [r for i, (r, _) in antworten.items() if r and self.app.dienste[i].typ == "tautulli"],
                    "bazarr": [r for i, (r, _) in antworten.items() if r and self.app.dienste[i].typ == "bazarr"],
                    "fehler": {self.app.dienste[i].name: f for i, (_, f) in antworten.items() if f}}
        if teil in ("verlauf", "folgen", "releases"):
            c = self._dienst({"id": werte.get("id")}, ("radarr", "sonarr"))
            if not str(werte.get("eintrag", "")).isdigit():
                raise ValueError("eintrag fehlt")
            eintrag = int(werte["eintrag"])
            if teil == "verlauf":
                return dict(c.verlauf(eintrag, werte.get("folge") or None), dienst=c.name)
            if teil == "releases":
                return {"dienst": c.name, "releases": c.release_suchen(eintrag, werte.get("folge") or None, werte.get("staffel") or None)}
            if c.typ != "sonarr":
                raise ValueError("Folgen gibt es nur bei Sonarr")
            return {"folgen": c.folgen(eintrag)}
        if teil == "speicher":
            return self._speicher_antwort()
        if teil == "titel":
            typ = werte.get("typ", "movie")
            imdb, tvdb = werte.get("imdb", ""), werte.get("tvdb", "")
            passend = self._dienste(("radarr",) if typ == "movie" else ("sonarr",))
            auftraege = {}
            for i, c in passend.items():
                auftraege[i] = lambda c=c: {"stand": c.status_titel(imdb=imdb, tvdb=tvdb), "profile": c.profile(),
                                            "ordner": c.ordner()}
            antworten = self._parallel(auftraege)
            return {"dienste": [dict(self._dienst_info(i, passend[i]), **(r or {}), fehler=f)
                                for i, (r, f) in antworten.items()]}
        return None

    def _dienst(self, daten, typen=None):
        c = self.app.dienste.get(str(daten.get("id", "")))
        if not c or (typen and c.typ not in typen):
            raise ValueError("Unbekannter Dienst")
        return c

    def dienst_aktion(self, daten):
        c = self._dienst(daten, dienste.DOWNLOAD_TYPEN + ("pihole",))
        was = str(daten.get("was", ""))
        if was not in c.kann:
            raise ValueError("%s kann %s nicht" % (c.typ_name, was))
        c.aktion(was, daten.get("job"), daten.get("wert"))
        self._aktionslog().eintragen("aktion", "%s: %s" % (c.name, was))
        return {"zustand": c.zustand()}

    def dienst_einstellungen(self, daten):
        """Einstellungen eines Downloaders lesen ({id}) oder aendern ({id, werte})."""
        from . import dienste_einstellungen
        c = self._dienst(daten, dienste.DOWNLOAD_TYPEN)
        if isinstance(daten.get("werte"), dict):
            return dict(dienste_einstellungen.schreiben(c, daten["werte"]), meldung="Gespeichert.")
        return dienste_einstellungen.lesen(c)

    def dienst_hinzu(self, daten):
        antwort = self._dienst_hinzu(daten)
        art = "magnet" if daten.get("magnet") else "link" if daten.get("link") else "nzb"
        name = str(daten.get("name") or "")
        self._aktionslog().eintragen("hinzufuegen", "%s an %s%s" % (art, self.app.dienste[str(daten.get("id"))].name,
                                     (": " + name.split("{{", 1)[0][:80]) if art == "nzb" and name else ""))
        return antwort

    def _dienst_hinzu(self, daten):
        c = self._dienst(daten, dienste.DOWNLOAD_TYPEN)
        if daten.get("link"):
            if "link" not in c.kann:
                raise ValueError("%s nimmt keine Links" % c.typ_name)
            c.link_hinzufuegen(str(daten["link"]))
            return {"meldung": "an %s übergeben" % c.typ_name}
        if daten.get("magnet"):
            if "torrent" not in c.kann:
                raise ValueError("%s nimmt keine Torrents" % c.typ_name)
            c.torrent_hinzufuegen(str(daten["magnet"]), daten.get("kategorie") or "")
            return {"meldung": "an %s übergeben" % c.typ_name}
        name = str(daten.get("name") or "")
        if daten.get("inhalt") and (name.lower().endswith(".torrent") or "nzb" not in c.kann):
            if "torrent_datei" not in c.kann:
                raise ValueError("%s nimmt keine Torrent-Dateien" % c.typ_name)
            try:
                inhalt = base64.b64decode(str(daten["inhalt"]), validate=True)
            except ValueError:
                raise ValueError("inhalt muss Base64 sein")
            c.torrent_datei_hinzufuegen(name or "datei.torrent", inhalt, daten.get("kategorie") or "")
            return {"meldung": "an %s übergeben" % c.typ_name}
        if daten.get("url") and "nzb" not in c.kann and "torrent" in c.kann:  # Adresse einer .torrent-Datei
            c.torrent_hinzufuegen(str(daten["url"]), daten.get("kategorie") or "")
            return {"meldung": "an %s übergeben" % c.typ_name}
        if "nzb" not in c.kann:
            raise ValueError("%s nimmt keine NZBs" % c.typ_name)
        if daten.get("url"):
            inhalt = rustnzb.nzb_laden(str(daten["url"]))
            name = daten.get("name") or urlsplit(str(daten["url"])).path.rsplit("/", 1)[-1] or "download"
        elif daten.get("inhalt"):
            try:
                inhalt = base64.b64decode(str(daten["inhalt"]), validate=True)
            except ValueError:
                raise ValueError("inhalt muss Base64 sein")
            name = daten.get("name") or "upload"
        else:
            raise ValueError("url, inhalt oder magnet angeben")
        c.nzb_hinzufuegen(rustnzb.job_name(name, daten.get("passwort")), inhalt, daten.get("kategorie") or "")
        return {"meldung": "an %s übergeben" % c.typ_name}

    def dienst_anfrage(self, daten):
        c = self._dienst(daten, ("seerr",))
        return {"meldung": c.entscheiden(daten.get("anfrage"), bool(daten.get("genehmigen")))}

    def dienst_holen(self, daten):
        c = self._dienst(daten, ("prowlarr",))
        return {"meldung": c.holen(str(daten.get("guid", "")), daten.get("indexer_id"))}

    def dienst_hinzufuegen(self, daten):
        c = self._dienst(daten, ("radarr", "sonarr"))
        if not str(daten.get("profil", "")).isdigit() or not daten.get("ordner"):
            raise ValueError("Profil und Ordner wählen")
        return {"meldung": c.hinzufuegen(daten["profil"], str(daten["ordner"]), imdb=daten.get("imdb"),
                                         tvdb=daten.get("tvdb"))}

    # --- Festplattenspeicher mit Verzeichnisfilter (* = alles inkl. Unterordner, ? = ein Zeichen) -----------
    def _speicher_filter_datei(self):
        return os.path.join(self.app.datenordner, "speicher-filter.json")

    def _speicher_filter(self):
        try:
            with open(self._speicher_filter_datei(), encoding="utf-8") as f:
                muster = json.load(f).get("muster")
        except (OSError, ValueError, AttributeError):
            return ""
        return "\n".join(verlauf_modul.muster_pruefen(muster)) if isinstance(muster, str) else ""

    def _speicher_antwort(self):
        antworten = self._parallel({i: c.speicher for i, c in self._dienste(dienste.ARR_TYPEN).items()})
        alle = [x for r, _ in antworten.values() if r for x in r]
        filter_ = self._speicher_filter()
        laufwerke = verlauf_modul.speicher_filtern(alle, filter_)
        unterschiedlich = len(verlauf_modul.speicher_filtern(alle, ""))
        return {"laufwerke": laufwerke, "filter": filter_, "versteckt": unterschiedlich - len(laufwerke),
                "fehler": {self.app.dienste[i].name: f for i, (_, f) in antworten.items() if f}}

    def dienst_speicher_filter(self, daten):
        if not isinstance(daten.get("filter", ""), str):
            raise ValueError("filter muss Text sein (ein Muster je Zeile)")
        muster = "\n".join(verlauf_modul.muster_pruefen(daten.get("filter", "")))
        datei = self._speicher_filter_datei()
        os.makedirs(os.path.dirname(datei) or ".", exist_ok=True)
        with open(datei + ".neu", "w", encoding="utf-8") as f:
            json.dump({"muster": muster}, f, ensure_ascii=False)
        os.replace(datei + ".neu", datei)
        return self._speicher_antwort()

    def dienst_fehlgeschlagen(self, daten):
        c = self._dienst(daten, ("radarr", "sonarr"))
        return {"meldung": c.als_fehlgeschlagen(daten.get("verlauf_id"))}

    def dienst_release_holen(self, daten):
        c = self._dienst(daten, ("radarr", "sonarr"))
        return {"meldung": c.release_holen(daten.get("guid"), daten.get("indexer_id"))}

    def dienst_arr_suchen(self, daten):
        c = self._dienst(daten, ("radarr", "sonarr"))
        return {"meldung": c.suchen(daten.get("eintrag"))}
