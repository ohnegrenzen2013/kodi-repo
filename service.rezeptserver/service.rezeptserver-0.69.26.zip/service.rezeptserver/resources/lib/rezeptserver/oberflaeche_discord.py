"""Discord-Bildbot: Zustand, Webhook-Pruefung und Versand aus dem Ab-18-Bereich."""

import json

from . import discord_bot
from .ab18 import Ab18Fehler, Gesperrt
from .netz import NetzFehler


class DiscordMixin:
    def discord_lesen(self):
        if not self.darf("einstellungen"):
            return 403, "application/json", {"fehler": "Kein Recht auf Einstellungen", "recht": True}
        werte = self._einstellungen_lesen().get("werte") or {}
        return 200, "application/json", discord_bot.zustand(werte)

    def discord_post(self, koerper, kopf):
        if not self.darf("einstellungen"):
            return 403, "application/json", {"fehler": "Kein Recht auf Einstellungen", "recht": True}
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
        except (ValueError, UnicodeDecodeError):
            return 400, "application/json", {"fehler": "JSON-Fehler"}
        if not isinstance(wunsch, dict):
            return 400, "application/json", {"fehler": "JSON-Objekt erwartet"}
        werte = self._einstellungen_lesen().get("werte") or {}
        aktion = str(wunsch.get("aktion") or "info")
        try:
            if aktion == "info":
                return 200, "application/json", discord_bot.zustand(werte)
            if aktion == "hilfe":
                return 200, "application/json", {"kategorien": discord_bot.kategorie_liste(),
                                                  "prefix": discord_bot.pruefe(werte)["discord_prefix"]}
            if aktion == "pruefen":
                return 200, "application/json", discord_bot.webhook_pruefen(werte)
            if aktion == "senden":
                if self.app.ab18 is None:
                    raise discord_bot.DiscordFehler("Ab-18-Bereich nicht verfuegbar")
                self.app.ab18.pruefen(kopf.get("X-Ab18") if kopf else None)
                return 200, "application/json", discord_bot.senden(
                    werte, wunsch.get("kategorie"), wunsch.get("anzahl"), wunsch.get("text"),
                    suche=self.app.ab18.suche)
            raise discord_bot.DiscordFehler("aktion: info, hilfe, pruefen oder senden")
        except Gesperrt as fehler:
            return 403, "application/json", {"fehler": str(fehler), "gesperrt": True, "ab18": True}
        except (discord_bot.DiscordFehler, Ab18Fehler, ValueError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        except NetzFehler as fehler:
            return 502, "application/json", {"fehler": str(fehler)}
