"""Nativer Downloader: Warteschlange und Dateiauslieferung unter /api/downloads."""

import os

from .download_manager import DownloadFehler
from .netz import NetzFehler
from .oberflaeche_grund import json


class DownloadsMixin:
    def downloads_lesen(self):
        d = getattr(self.app, "downloads", None)
        return 200, "application/json", {"downloads": d.liste() if d else []}

    def downloads_post(self, koerper):
        d = getattr(self.app, "downloads", None)
        if d is None:
            return 503, "application/json", {"fehler": "Downloader nicht verfügbar"}
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
            aktion = wunsch.get("aktion") if isinstance(wunsch, dict) else None
            if aktion == "start":
                header = wunsch.get("header")
                if header is not None and not isinstance(header, dict):
                    raise DownloadFehler("header: JSON-Objekt erwartet")
                job = d.start(str(wunsch.get("url") or ""), str(wunsch.get("name") or ""),
                              {str(k): str(v) for k, v in (header or {}).items()})
                return 200, "application/json", {"download": job, "downloads": d.liste()}
            if aktion == "stopp":
                d.stoppen(str(wunsch.get("id") or ""))
            elif aktion == "entfernen":
                d.entfernen(str(wunsch.get("id") or ""))
            else:
                raise DownloadFehler("aktion: start, stopp oder entfernen")
            return 200, "application/json", {"downloads": d.liste()}
        except (DownloadFehler, NetzFehler, ValueError, UnicodeDecodeError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}

    def downloads_datei(self, werte):
        d = getattr(self.app, "downloads", None)
        if d is None:
            return 404, "text/plain", b""
        try:
            pfad, _ = d.datei(str(werte.get("id") or ""))
        except DownloadFehler:
            return 404, "text/plain", b""
        return "lokal", os.path.abspath(pfad)
