"""eD2K-Netz: aMule, Rucio, aMuTorrent und die Kad-Tabelle.

  GET  /api/ed2knetz                  Kad-Tabelle, Dienste und Quellstaende
  POST /api/ed2knetz                  {aktion: pruefen | kad | docker}
"""

import json

from . import ed2knetz, kademlia


class Ed2kNetzMixin:

    def _kad_knoten(self):
        liste = getattr(self.app, "kadliste", None)
        if liste is None:
            return []
        try:
            return liste.eintraege()
        except Exception:  # noqa: BLE001 – eine kaputte nodes.dat darf den Reiter nicht sperren
            return []

    def ed2knetz_lesen(self):
        werte = self._einstellungen_lesen().get("werte") or {}
        kad = kademlia.zustand(werte, knoten=self._kad_knoten())
        return 200, "application/json", ed2knetz.zustand(werte, kad=kad)

    def ed2knetz_post(self, koerper):
        werte = self._einstellungen_lesen().get("werte") or {}
        if werte.get("ed2knetz_an") is False:
            return 403, "application/json", {"fehler": "eD2K-Netz ist in den Einstellungen ausgeschaltet."}
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(wunsch, dict):
                raise ValueError("JSON-Objekt erwartet")
            aktion = wunsch.get("aktion")
            if aktion == "pruefen":
                kad = kademlia.zustand(werte, knoten=self._kad_knoten())
                return 200, "application/json", ed2knetz.zustand(werte, kad=kad, pruefen=True)
            if aktion == "kad":
                ziel = str(wunsch.get("ziel") or "").strip()
                kad = kademlia.zustand(dict(werte, kad_ziel=ziel), knoten=self._kad_knoten())
                return 200, "application/json", {"kad": kad}
            if aktion == "docker":
                return 200, "application/json", {"befehl": ed2knetz.docker_befehl(werte),
                                                 "hinweis": "Passwoerter nur als Platzhalter – vor dem Start ersetzen."}
            return 400, "application/json", {"fehler": "aktion: pruefen, kad oder docker"}
        except (ValueError, UnicodeDecodeError, kademlia.KadFehler) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
