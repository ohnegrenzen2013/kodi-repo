"""Ember steuern (ember_steuerung.py) – wenn Ember auf demselben Rechner wie H0rSt laeuft.

  GET  /api/ember/steuerung    Zustand: laeuft?, Ports, Downloads mit Fortschritt, Einstellungen, Ordner, Programm
  POST /api/ember/steuerung    {aktion: starten|stoppen} | {aktion: einstellen, werte: {...}} |
                               {aktion: orte, ordner, programm} | {aktion: listen} (server.met, nodes.dat, ipfilter.dat an Ember)
"""

import json

from . import ember_steuerung, ipfilter


class EmberMixin:

    def _emberp2p_an(self):
        """Ember-P2P in den Einstellungen eingeschaltet? (Standard: an, wie bisher)"""
        try:
            return (self._einstellungen_lesen().get("werte") or {}).get("emberp2p_an", True) is not False
        except Exception:
            return True

    def _ember(self, daten=None):
        daten = daten if daten is not None else (self.app.verwaltung.daten() if self.app.verwaltung else {})
        return ember_steuerung.EmberSteuerung(ember_steuerung.pruefe(daten.get(ember_steuerung.SCHLUESSEL)))

    def ember_lesen(self):
        if not self._emberp2p_an():
            return 200, "application/json", {"an": False, "laeuft": False, "gefunden": False, "transfers": [],
                                             "ports": {"tcp": 0, "udp": 0, "tcp_offen": False}, "einstellungen": {},
                                             "ordner": "", "programm": "", "kandidaten": [], "listen": {},
                                             "meldung": "Ember-P2P ist in den Einstellungen ausgeschaltet."}
        return 200, "application/json", self._ember().zustand()

    def ember_post(self, koerper):
        if not self._emberp2p_an():
            return 403, "application/json", {"fehler": "Ember-P2P ist in den Einstellungen ausgeschaltet."}
        try:
            w = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(w, dict):
                raise ValueError("JSON-Objekt erwartet")
            a = w.get("aktion")
            if a == "orte":
                if not self.app.verwaltung:
                    raise ValueError("Nutzerdaten nicht verfügbar")
                neu = ember_steuerung.pruefe({"ordner": w.get("ordner"), "programm": w.get("programm")}, streng=True)

                def setzen(d):
                    d[ember_steuerung.SCHLUESSEL] = neu
                self.app.verwaltung.aendern(setzen)
                return self.ember_lesen()
            e = self._ember()
            if a == "starten":
                return 200, "application/json", e.starten()
            if a == "stoppen":
                return 200, "application/json", e.stoppen()
            if a == "einstellen":
                return 200, "application/json", e.einstellen(w.get("werte"))
            if a == "listen":
                server = self.app.ed2k_suche.serverliste
                dateien = {"server.met": server.datei() if server.eintraege() else b"",
                           "nodes.dat": self.app.kadliste.datei() if self.app.kadliste.eintraege() else b"",
                           "ipfilter.dat": ipfilter.AKTIV.als_dat() if len(ipfilter.AKTIV) else b""}
                geschrieben = e.listen_geben(dateien)
                return 200, "application/json", dict(e.zustand(), meldung="An Ember gegeben: " + (", ".join(geschrieben) or "nichts (Listen leer)") +
                                                     ". Ember liest sie beim nächsten Start.")
            raise ValueError("aktion: starten, stoppen, einstellen, orte oder listen")
        except (ValueError, UnicodeDecodeError, OSError) as fehler:  # EmberFehler ist ValueError
            return 400, "application/json", {"fehler": str(fehler)}
