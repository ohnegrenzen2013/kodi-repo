"""eMule eSE LiveTV: Status lesen und das Dashboard als Portal-Reiter oeffnen.

  GET  /api/emuleese          {name, repo, stand, lizenz, an, dashboard, api, rtmp, erreichbar, meldung}
  POST /api/emuleese          {aktion: "pruefen"} oder {aktion: "portal"}
                              "portal" oeffnet das eingestellte Dashboard im Portal (nur mit Schalter).
"""

import json

from . import emuleese


class EmuleEseMixin:

    def emuleese_lesen(self):
        werte = self._einstellungen_lesen().get("werte") or {}
        return 200, "application/json", emuleese.zustand(werte)

    def emuleese_post(self, koerper):
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
        except (ValueError, UnicodeDecodeError):
            return 400, "application/json", {"fehler": "JSON-Fehler"}
        if not isinstance(wunsch, dict):
            return 400, "application/json", {"fehler": "JSON-Objekt erwartet"}
        werte = self._einstellungen_lesen().get("werte") or {}
        if not werte.get("emuleese_an"):
            return 403, "application/json", {"fehler": "eSE LiveTV ist in den Einstellungen ausgeschaltet."}
        aktion = wunsch.get("aktion")
        if aktion == "pruefen":
            return self.emuleese_lesen()
        if aktion == "portal":
            stand = emuleese.zustand(werte, pruefen=False)
            return self.portal_post("/api/portal", json.dumps({
                "aktion": "oeffnen", "url": stand["dashboard"], "titel": "eMule eSE LiveTV",
                "symbol": "🐴", "modus": "rahmen"}, ensure_ascii=False).encode("utf-8"))
        return 400, "application/json", {"fehler": "aktion: pruefen oder portal"}
