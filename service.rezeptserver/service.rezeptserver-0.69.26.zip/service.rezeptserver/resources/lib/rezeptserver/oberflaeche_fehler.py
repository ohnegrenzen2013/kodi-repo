"""Fehlerliste (fehlerliste.py): ansehen, exportieren zum Einspeisen, einlesen, leeren.

  GET  /api/fehler                      {eintraege, anzahl, meldungen, version, plattform}
  GET  /api/fehler/export?format=md|json|txt[&ids=a,b]   Datei (Markdown zum Einspeisen, JSON zum Wiedereinlesen)
  POST /api/fehler/melden               {eintraege: [{art, text, ort, details, bereich}]} – die Oberflaeche meldet (jeder darf)
  POST /api/fehler/einlesen             JSON-Export eines anderen Geraets dazunehmen
  POST /api/fehler/leeren               {ids?: [...]} – ohne ids alles
"""

import json

from . import fehlerliste


class FehlerMixin:

    def fehler_lesen(self, pfad, werte):
        liste = self.app.fehler
        if pfad == "/api/fehler":
            return 200, "application/json", liste.liste()
        if pfad == "/api/fehler/export":
            ids = {i for i in (werte.get("ids") or "").split(",") if i}
            typ, text, _name = liste.export(werte.get("format", "md"), ids)
            return 200, typ, text
        return 404, "application/json", {"fehler": "nicht gefunden"}

    def fehler_post(self, pfad, koerper, kopf):
        liste = self.app.fehler
        try:
            daten = json.loads(koerper.decode("utf-8") or "{}")
            if pfad == "/api/fehler/melden":
                return 200, "application/json", liste.melden(daten, (kopf or {}).get("User-Agent", ""))
            if pfad == "/api/fehler/einlesen":
                return 200, "application/json", liste.einlesen(daten)
            if pfad == "/api/fehler/leeren":
                ids = daten.get("ids") if isinstance(daten, dict) else None
                return 200, "application/json", liste.leeren(ids if isinstance(ids, list) else None)
        except (ValueError, UnicodeDecodeError, fehlerliste.FehlerlisteFehler) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        return 404, "application/json", {"fehler": "nicht gefunden"}
