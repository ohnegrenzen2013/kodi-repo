"""Google Drive (gdrive.py): verbinden, Sicherungen, Ordner sichern und spiegeln. Alles braucht das Recht "einstellungen".

  GET  /api/gdrive                 Stand {eingerichtet, verbunden, email, auto, behalten, spiegeln, zuletzt, fehler, auftrag,
                                   geraet?, orte: [{id, name}]}
  GET  /api/gdrive/sicherungen     Sicherungen der Nutzerdaten in Drive
  POST /api/gdrive                 {aktion: verbinden | pruefen | trennen}
                                   {aktion: sichern_jetzt}           neue Sicherung der Nutzerdaten, gleich nach Drive
                                   {aktion: zurueckholen, id, name}  Sicherung aus Drive neben die lokalen legen
                                   {aktion: sichern, ort, pfad}      Datei oder Ordner aus dem Dateibrowser nach Drive
                                   {aktion: spiegeln_jetzt}          die gewaehlten Orte jetzt spiegeln
  POST /api/gdrive/einstellungen   {auto, behalten, spiegeln: [ort-id]}
  POST /api/gdrive/app             {client_id, client_secret} (leere client_id loescht)
"""

import os
import re

from . import gdrive
from .oberflaeche_grund import json


class GdriveMixin:

    def gdrive_lesen(self, pfad):
        try:
            if pfad == "/api/gdrive/sicherungen":
                return 200, "application/json", {"sicherungen": self.app.gdrive.sicherungen()}
            daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
            stand = self.app.gdrive.stand(daten)
            stand["orte"] = [{"id": o["id"], "name": o["name"]} for o in self.app.dateien.orte() if o["da"]]
            return 200, "application/json", stand
        except gdrive.DriveFehler as fehler:
            return 400, "application/json", {"fehler": str(fehler)}

    def gdrive_post(self, pfad, koerper):
        if not self.app.verwaltung:
            return 503, "application/json", {"fehler": "Nutzerdaten nicht verfügbar"}
        g = self.app.gdrive
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(wunsch, dict):
                raise ValueError("JSON-Objekt erwartet")
            if pfad == "/api/gdrive/app":
                return 200, "application/json", self.app.verwaltung.bearbeiten(lambda d: gdrive.GDrive.app_setzen(d, wunsch))
            if pfad == "/api/gdrive/einstellungen":
                return 200, "application/json", self.app.verwaltung.bearbeiten(lambda d: gdrive.GDrive.einstellungen_setzen(d, wunsch))
            aktion = wunsch.get("aktion")
            if aktion == "verbinden":
                return 200, "application/json", g.verbinden_start()
            if aktion == "pruefen":
                return 200, "application/json", g.verbinden_pruefen()
            if aktion == "trennen":
                return 200, "application/json", g.trennen()
            if aktion == "sichern_jetzt":
                g.kopf()  # verbunden? sonst gleich die Meldung statt einer Sicherung ohne Ziel
                name = self.app.aktualisierung.sichern()
                if not name:
                    raise ValueError("Noch keine Nutzerdaten zum Sichern")
                lokal = os.path.join(self.app.aktualisierung._sicherung_ordner(), name)
                if not g.stand(self.app.verwaltung.daten())["auto"]:  # sonst laedt nach_sicherung sie schon hoch
                    g.im_hintergrund("sicherung", lambda: {"fertig": 1, "gesamt": 1} if g.sicherung_hochladen(lokal) else {})
                return 200, "application/json", {"name": name, "meldung": "Sicherung %s geht nach Google Drive" % name}
            if aktion == "zurueckholen":
                name = str(wunsch.get("name") or "")
                if not re.match(r"^h0rst-sicherung-[\d-]+(?:-vor-update)?\.json$", name):
                    raise ValueError("Ungültige Sicherung")
                inhalt = g.herunterladen(str(wunsch.get("id") or ""))
                ordner = self.app.aktualisierung._sicherung_ordner()
                os.makedirs(ordner, mode=0o700, exist_ok=True)
                with open(os.path.join(ordner, name), "wb") as f:
                    f.write(inhalt)
                return 200, "application/json", {"meldung": "%s liegt jetzt bei den Sicherungen (Einstellungen → Aktualisierung) "
                                                            "und lässt sich dort wiederherstellen." % name}
            if aktion == "sichern":
                ort, rel = str(wunsch.get("ort") or ""), str(wunsch.get("pfad") or "")
                lokal = self.app.dateien.pfad(ort, rel)
                ortname = next((o["name"] for o in self.app.dateien.orte() if o["id"] == ort), ort)
                ziel = [ortname] + [t for t in os.path.dirname(rel.strip("/")).split("/") if t]
                if os.path.isdir(lokal) and rel.strip("/"):
                    ziel.append(os.path.basename(rel.strip("/")))
                return 200, "application/json", g.im_hintergrund("sichern", lambda: g.sichern(lokal, ziel))
            if aktion == "spiegeln_jetzt":
                gewaehlt = set(g.stand(self.app.verwaltung.daten())["spiegeln"])
                orte = [(o["id"], o["name"], o["pfad"]) for o in self.app.dateien.orte() if o["id"] in gewaehlt and o["da"]]
                if not orte:
                    raise ValueError("Erst Orte zum Spiegeln wählen")
                return 200, "application/json", g.im_hintergrund("spiegeln", lambda: g.spiegeln(orte))
            raise ValueError("Unbekannte Aktion")
        except (ValueError, UnicodeDecodeError, OSError) as fehler:  # DriveFehler und DateiFehler sind ValueError
            return 400, "application/json", {"fehler": str(fehler)}
