"""Geraete-Abgleich (geraete_sync_drive.py): Profile/Merkliste/Verlauf/Weiterschauen/eigene Anbieter/
Einstellungen mit anderen, unabhaengigen H0rSt-Installationen abgleichen - ueber einen eigenen Google-
Drive-Ordner. Alles braucht das Recht "einstellungen".

  GET  /api/geraete_abgleich                Stand {an, intervall_stunden, zuletzt, fehler, auftrag,
                                             geraet_id, drive_verbunden}
  POST /api/geraete_abgleich                {aktion: "jetzt"}
  POST /api/geraete_abgleich/einstellungen  {an, intervall_stunden}
"""

from .geraete_sync_grund import GeraeteAbgleichFehler
from .oberflaeche_grund import json


class GeraeteSyncMixin:

    def geraete_abgleich_lesen(self):
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        stand = self.app.geraete_abgleich.stand(daten)
        stand["drive_verbunden"] = self.app.gdrive.stand(daten)["verbunden"]
        return 200, "application/json", stand

    def geraete_abgleich_post(self, pfad, koerper):
        if not self.app.verwaltung:
            return 503, "application/json", {"fehler": "Nutzerdaten nicht verfügbar"}
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(wunsch, dict):
                raise ValueError("JSON-Objekt erwartet")
            if pfad == "/api/geraete_abgleich/einstellungen":
                return 200, "application/json", self.app.verwaltung.bearbeiten(
                    lambda d: self.app.geraete_abgleich.einstellungen_setzen(d, wunsch))
            if wunsch.get("aktion") == "jetzt":
                return 200, "application/json", self.app.geraete_abgleich.jetzt_starten()
            raise ValueError("Unbekannte Aktion")
        except (GeraeteAbgleichFehler, ValueError, UnicodeDecodeError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
