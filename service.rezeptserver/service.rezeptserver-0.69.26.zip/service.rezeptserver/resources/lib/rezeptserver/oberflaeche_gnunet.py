"""GNUnet-Werkzeuge (Sicherheit): geprüfte Links zu Netzwerk, Anwendungen und Betrieb."""

from . import gnunet_tools


class GnunetToolsMixin:

    def gnunet_tools_lesen(self):
        return 200, "application/json", gnunet_tools.zustand()
