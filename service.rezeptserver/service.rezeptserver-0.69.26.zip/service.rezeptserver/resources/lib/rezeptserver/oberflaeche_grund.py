"""Oberflaeche "Durchsuchen": Suche ueber alle nutzbaren Anbieter, Filter, Vorschaubilder, Abspielen.

Seite unter / (bzw. /<token>/), Schnittstelle unter /api/:
  GET  /api/easynews            Easynews-Tab: Zugang gesetzt?, Auswahl; /suche?q=&art=&sort=&aufl=&seite=; /bild?url=
  POST /api/easynews/zugang     {user, pass}; /abspielen {stream} -> Wiedergabe-Adresse (Zugangsdaten bleiben hier)
  GET  /api/hintergrund         eigenes Hintergrundbild; POST {bild: base64} | {kamera: id} | {weg: true}; /api/avatar ebenso
  GET  /api/web                 Webhosting: Adressen, erreichbar?, Anwendungen; POST /api/web/installieren {anwendung, tmdb?}, /einstellungen, /api/web/arvio/bauen
  GET  /api/assistent           Hinzufuegen-Assistent: Fragenkatalog als Baum (aus Vorlagen und Bausteinen)
  POST /api/assistent/verknuepfungen {id}: passende naechste Schritte; /verknuepfen {id, was: rustnzb_server|livetv|netzweg}
  GET  /api/verweise            tote Verweise (Netzweg, Waechter-Ersatz, Zugangsdaten ohne Anbieter); POST /api/verweise/aufraeumen
  GET  /api/chat/raeume         Videochat: Raeume; POST /api/chat/beitreten {raum, name}, /senden {raum, von, an, art, daten};
                                GET /api/chat/abholen?raum=&ich= (wartet bis 20 s)
  GET  /api/cast                Google Home/Nest/Chromecast: bekannte Geraete (?stand=<ip>); GET /api/cast/suchen (mDNS)
  POST /api/cast/abspielen {ip, url, titel, bild, live}; /steuern {ip, was: pause|weiter|stopp|lautstaerke|stumm, wert}; /hinzufuegen {ip, name}
  GET/POST /api/befehl {schluessel, text}: Sprachbefehl (Webhook); POST /api/sprachsteuerung {neu|aus}
  GET  /api/hue                 Philips Hue: Raeume, Lampen, Szenen; GET /api/hue/suchen (Bridges im Netz)
  POST /api/hue/koppeln {bridge}; /trennen; /alle {an}; /schalten {art: raum|lampe, id, an, hell, farbtemp, szene}
  GET  /api/kameras             IP-Kameras (ohne Passwoerter); POST {kameras: [...]}; GET /bild/<id> (JPEG), /live/<id> (MJPEG)
  GET  /api/kameras/snaps?id=   Snaps; /snap/<id>/<name>; POST /snap {id}, /snap_weg {id, name|alle}, /hls {id}
  GET  /api/start               Startseite: Version, Addon-/M3U-/EPG-Adresse, Wächter, Downloads, Telegram, FTP, Pi-hole, Update
  GET  /api/filter              gespeicherter Filter und Auswahlmoeglichkeiten
  POST /api/filter              Filter speichern (gilt danach auch fuer Stremio/Jacktook)
  GET  /api/suche?q=&art=       Treffer bei den Anbietern (gefiltert, sortiert) und Facetten der ungefilterten Treffer
  GET  /api/titelsuche?q=       Filme und Serien (Cinemeta, Addon-Suchkataloge) nach Rang, Smart-Suche wie ARVIO
  GET  /api/entdecken?typ=&sortierung=&genre=&jahr=&skip=   Entdecken-Kataloge (Beliebt, Top bewertet, Neu)
  GET  /api/genres              Genres je Typ
  GET  /api/traum…            LocalDream: Prompt Studio, Bilder erzeugen, Galerie, Quellen (oberflaeche_traum.py)
  GET  /api/portal…           ("_• )—*: Adressen, IPs, MACs als Reiter; pruefen, wecken, durchreichen (oberflaeche_portal.py)
  GET  /api/sehen               Merkliste und Verlauf (Filme, Serien) des Profils; POST {aktion, titel} (oberflaeche_sehen.py)
  GET  /api/titel?typ=&id=      Details eines Titels (tt...), bei Serien mit Folgen
  GET  /api/titelstreams?typ=&id=   Streams zu einem Titel (tt... oder tt...:staffel:folge) aus allen Quellen
  GET  /api/streams?id=         Streams eines Treffers (Qualitaetsfilter angewendet)
  GET  /api/bild?titel=&jahr=   Vorschaubild ueber die Metadaten-Rezepte (z. B. TMDb), zwischengespeichert
  GET  /api/wiedergabe/<key>    Stream mit Zugangsdaten-Header ueber den Server (fuer den Browser-Player)
  GET  /api/hls/<key>/<teil>    HLS ueber den Server: Listen umgeschrieben, Teile durchgereicht (Browser ohne CORS)
  GET  /hls.js                  hls.js (Apache-2.0) fuer Browser ohne eingebautes HLS
  GET  /api/livetv              Sender, EPG-Zustand, eingebaute EPG-Grabber
  POST /api/livetv              Sender ein/aus, eigene Sender-Adressen, Adressen-Liste, EPG-Quelle/-Grabber speichern
  GET  /api/livetv/jetzt        aktuell laufende Sendung je Oeffentlich-rechtlich-Kachel (aus der EPG-Datei)
  GET  /api/livetv/sehen        Favoriten, Zuletzt angesehen und "haeufig" (Beliebt, lokal gezaehlt) dieses Profils (livetv_sehen.py)
  POST /api/livetv/sehen        {aktion: favorit|angesehen, id, an?}
  GET  /api/livetv/raster       Programmuebersicht: ?ids=a,b,c&von=<Zeitstempel>&bis=<Zeitstempel> (livetv_raster.py, nur eigene EPG-Datei)
  GET  /api/poster              eigene Poster je Titel des Profils (poster_eigen.py)
  POST /api/poster              {aktion: setzen, id, url} | {aktion: weg, id}
  POST /api/xtream              aus eigenen Xtream-Zugangsdaten die M3U-Adresse bauen (speichert nichts)
  GET  /api/links               Heim-Links und Vorschlaege
  POST /api/links               Heim-Links speichern
  GET  /api/anbieter            alle Anbieter nach Kategorie (Passwoerter nur als "gesetzt"), Vorlagen, Typen
  POST /api/anbieter/vorlage    eigenen Anbieter aus einer Vorlage anlegen {vorlage, name, werte}
  POST /api/anbieter/neu        eigenen Anbieter anlegen {name, kategorie, typ, anmeldung, werte}
  POST /api/anbieter/json       Anbieter per JSON: {url} (auch Stremio-manifest.json) oder {json: "..."}
  GET  /api/anbieter/export     eigene Anbieter als JSON (?geheim=1 mit Passwoertern)
  POST /api/anbieter/zugang     Zugangsdaten setzen {id, werte}; leere Passwortfelder bleiben, wie sie sind
  POST /api/anbieter/entfernen  eigenen Anbieter entfernen {id}
  POST /api/anbieter/pruefen    Verbindungstest {id}
  POST /api/anbieter/livetv     Xtream-/vxparser-Anbieter als Live-TV-Liste aufnehmen {id}
  POST /api/senden              NZB an einen Downloader schicken {stream, downloader, name}
  GET  /api/rustnzb             rustnzb: Status, Warteschlange, Verlauf, Mediathek
  POST /api/rustnzb/aktion      {was: pause|resume|loeschen|wiederholen, id}
  POST /api/rustnzb/nzb         NZB an rustnzb: {url} oder {name, inhalt: base64}
  POST /api/rustnzb/server      Usenet-Provider aus H0rSt in rustnzb anlegen/aktualisieren und testen
  GET  /api/dienste             Dienste-Zentrale (wie nzb360): eingerichtete Dienste mit Kurzstand
  GET  /api/dienste/downloads   alle Download-Clients: Tempo, Warteschlange, Verlauf
  POST /api/dienste/aktion      {id, was: pause_alle|resume_alle|pause|resume|loeschen|wiederholen|verlauf_loeschen|limit, job, wert}
                                (Pi-hole: pause mit wert = Sekunden, resume)
  POST /api/dienste/hinzu       NZB {id, url|inhalt(base64), name, kategorie}, Magnet {id, magnet} oder Link {id, link}
                                (http/ftp/magnet/ed2k, ASUS Download Master); GET /api/dienste/linkziele
  GET  /api/dienste/kalender    Kalender aus Sonarr, Radarr, Lidarr (?tage=30)
  GET  /api/dienste/arr?was=    warteschlange|zuletzt|fehlend aus Sonarr, Radarr, Lidarr
  GET  /api/dienste/anfragen    Seerr-Anfragen (?filter=pending|all); POST /api/dienste/anfrage {id, anfrage, genehmigen}
  GET  /api/dienste/seerr[/suche?q=]  Seerr eingerichtet? / Titel suchen; POST /api/dienste/seerr/anfrage {id, art, tmdb, staffeln?} stellt eine Anfrage
  GET  /api/dienste/suche?q=    Prowlarr-Suche ueber alle Indexer; POST /api/dienste/holen {id, guid, indexer_id}
  GET  /api/dienste/aktivitaet  Tautulli-Streams und fehlende Untertitel (Bazarr)
  GET  /api/dienste/titel       Stand eines Titels in Radarr/Sonarr (?typ=&imdb=&tvdb=), Profile und Ordner
  POST /api/dienste/hinzufuegen {id, imdb, tvdb, profil, ordner}; POST /api/dienste/arr_suchen {id, eintrag}
  GET  /api/dienste/verlauf     Verlauf eines Titels nach Tag (?id=&eintrag=[&folge=]); POST /api/dienste/fehlgeschlagen {id, verlauf_id}
  GET  /api/dienste/releases    manuelle Suche mit Status (?id=&eintrag=[&folge=|&staffel=]); GET /api/dienste/folgen (?id=&eintrag=, Sonarr)
                                POST /api/dienste/release_holen {id, guid, indexer_id}
  GET  /api/dienste/speicher    Laufwerke aus Sonarr/Radarr/Lidarr mit Filter; POST /api/dienste/speicher_filter {filter} (* ? je Zeile)
  GET  /api/debrid              Debrid-Dienste mit API-Schluessel und Zahl der bekannten Hoster
  POST /api/debrid/freischalten Hoster-Links freischalten {links: [...], anbieter: ""} -> direkte Links
  GET  /api/vx                  vxparser: Server, Links (Domains & APIs)
  GET  /api/vx/zustand|kategorien|inhalte|serie|listen|abspielen   Zugriff auf vxparser (?anbieter=)
  POST /api/vx/links            vxparser-Links speichern {schluessel: url}
  POST /api/vx/liste            M3U8-Liste von vxparser als Live-TV-Liste aufnehmen {name, url}
  GET  /api/ab18                Ab 18: Freigabe, PIN, Seiten, Qualitaet, yt-dlp, Merkliste, Verlauf, letzte Suchen
  GET  /api/ab18/menue|kategorien|videos|suche   Inhalte (?seite=&reihenfolge=&suche=&kategorie=&nummer=, suche ?q=)
  GET  /api/ab18/start|genres|genre|aehnlich     Neuestes je Seite, Genres ueber alle Seiten (?name=&nummer=),
                                aehnliche Videos (?seite=&titel=&id=)
  POST /api/ab18/freigabe       {an, volljaehrig: true}; /entsperren {pin}; /sperren
  POST /api/ab18/einstellungen  {seiten: {id: bool}, eigene: [{name, start, suche, muster}], qualitaet, min_dauer,
                                pin_neu, pin_alt}
  POST /api/ab18/abspielen      {seite, id, url, titel, bild, dauer} -> Wiedergabe-Adresse; /link {url} (yt-dlp)
  POST /api/ab18/merken         {video, weg}; /leeren {was: verlauf|suchen|merkliste}
  Ab 18 braucht die Freigabe und, wenn eine PIN gesetzt ist, den Header X-Ab18 aus /entsperren.
  GET  /api/sicherheit          Netzweg, Notbremse, VPN-Erkennung, Liste "Sicher unterwegs", Verbindungen, Vorlagen
  POST /api/sicherheit/einstellungen  {weg, onion, i2p, notbremse, wireguard, wg_umfang}
  POST /api/sicherheit/pruefen  was Anbieter sehen: IP, Ort, Betreiber, Tor (ueber den eingestellten Weg)
  GET  /api/anonym              Tor & I2P: Werkzeuge, offene Ports, Wege; /api/anonym/release?id= neueste Fassung
  POST /api/anonym/verknuepfen  {netz: tor|i2p}; /konfig {art, port}; /adresse {adresse} (oberflaeche_anonym.py)
  GET/POST /api/afwall          Netz-Freigaben je App (WLAN, Mobilfunk, VPN, Roaming): Regeln, Profile, iptables-Skript;
                                /apps von der Android-App, /anwenden setzt das Skript, /export sichert die Regeln (oberflaeche_afwall.py)
  GET/POST /api/daumenkino       Daumenkino-Projekte; GET/POST /api/party Party-Raeume (oberflaeche_party.py)
  GET  /api/trakt               Trakt-Stand des Profils; POST {aktion: verbinden|pruefen|abgleichen|trennen}, /api/trakt/app (oberflaeche_trakt.py)
  GET  /api/gdrive              Google Drive: Stand, Sicherungen; POST Verbinden, Sichern, Spiegeln (oberflaeche_gdrive.py)
  GET  /api/appstore            App-Store: Suche, App, APK; POST laden, updates, Favoriten (oberflaeche_appstore.py)
  GET  /api/kataloge, /api/katalog?art=streaming|thema|xrel|feed  Kataloge zur Auswahl; POST /api/kataloge eigene Feeds
  GET/POST /api/ember/steuerung  Ember auf diesem Rechner: Zustand, Fortschritt, starten/stoppen, Einstellungen (oberflaeche_ember.py)
  GET  /api/kodi[?geraet=]      Kodi-Geraete und Player (TMDb Helper), mit geraet: welche Addons installiert sind
  GET  /api/kodi/jetzt?geraet=  was auf Kodi laeuft; POST /api/kodi/steuern {geraet, was: pause|stopp}
  POST /api/kodi/abspielen      {geraet, player: datei|tmdbhelper, typ, id: tt..., staffel, folge}
  POST /api/kodi/senden         {geraet, url}: Stream auf dem Fernseher starten
  POST /api/kodi/import         Player: {name, inhalt: base64 (ZIP oder JSON)} | {json} | {url}; /entfernen {datei}
  GET  /tmdbhelper/players.zip  alle Player fuer TMDb Helper (in Kodi per Adresse laden)
  GET  /api/badges              Stream-Badges (wie Nuvio): Einstellung, Sets, Vorschau; POST {an, eigene, urls}
  GET  /api/badges/test?text=   Badges zu einem Release-Namen
  GET  /api/xdcc                XDCC: Downloads und geladene Dateien; GET /api/xdcc/suche?q=&quellen=xdcceu,xdccit,xdccinfo,xdccrocks,xdccsearch,nibl
                                (alle Suchseiten parallel, zusammengefuehrt, je Quelle Anzahl oder Fehler)
  POST /api/xdcc/laden          {server, kanal, bot, paket, name}; /abbrechen {id}; /loeschen {name}; /quelle {aktion: hinzu|weg, name, url, id}
  GET  /api/xdcc/datei/<name>   geladene Datei abspielen (mit Range)
  GET  /api/youtube             YouTube: Abos, SponsorBlock, ob yt-dlp da ist; GET /api/youtube/suche?q=, /feed
  POST /api/youtube/abspielen   {id} -> Adresse (Browser ueber H0rSt, extern direkt) und SponsorBlock-Abschnitte
  POST /api/youtube/abonnieren  {kanal}; /abbestellen {id}; /einstellungen {sponsorblock}
  POST /api/youtube/speichern   {id, titel, tempo}: Download (tempo 1) oder REC mit Tempo; GET /api/youtube/downloads
  GET  /api/youtube/datei/<name>  gespeichertes Video (mit Range); POST /api/youtube/datei_weg {name}
  GET  /api/ed2k[?ember=1]      Ember: gesammelte ed2k-Links (mit Badges), mit ember=1 die neueste Ember-Version
  POST /api/ed2k/hinzu          {text} (Links, auch mehrere oder .emulecollection); /entfernen {hash} | {alle}
  GET  /api/ed2k/sammlung.emulecollection   alle Links fuer Ember
  GET  /api/waechter            Verfuegbarkeit aller Anbieter und Dienste, Meldungen, Einstellungen
  POST /api/waechter/pruefen    {id} einen sofort, ohne id alle im Hintergrund
  POST /api/waechter/einstellungen  {an, minuten, ersatz: {anbieter: adresse}}
  GET  /api/einstellungen       Einstellungen wie ARVIO: Kategorien, Zeilen, Werte; POST {schluessel: wert}
  GET  /api/telegram            Telegram-Bot: Zustand (Token nur als "gesetzt"), Chats, Meldungen
  POST /api/telegram/einstellungen {an, token, token_weg, melden, nur_stoerungen, befehle}; /koppeln; /test; /chat_weg {id}
  GET  /api/heimspeicher        Speicher (ASUS AiCloud, WebDAV, FTP, offene Verzeichnisse) ohne Passwoerter, Arten
  POST /api/heimspeicher        {speicher: [...]} speichern (leeres Passwort = bleibt); /pruefen {id}; /abspielen {id, pfad}
  GET  /api/heimspeicher/liste?id=&pfad=   Ordner; /crawl?id=&q=&medien=1  Crawler ueber den ganzen Speicher
  GET  /api/dateisuche/ftp?q=   NAPALM FTP Indexer; /verzeichnisse?q=&art=&pub=1  offene Verzeichnisse (Suchmaschine)
  GET  /api/dateisuche/web?url=&art=   Web-Crawler; /liste?url=&pfad=  offenes Verzeichnis ansehen
  POST /api/dateisuche/abspielen {url}  ftp://- oder http(s)-Datei ueber H0rSt abspielen
  GET  /api/ed2k/suche?q=&typ=  eD2K-Server-Suche (Treffer mit ed2k-Link und Badges)
  GET  /api/dht?q=              Quellen eines Magnet-Links/infoHash im BitTorrent-DHT
  GET  /api/ftpserver           FTP-Server: Zustand; POST {an, port, benutzer, passwort, ordner, schreiben}
  POST /api/sicherung/erstellen {passwort, geraet}: Komplettsicherung als eine Datei (mit Passwort verschluesselt)
  POST /api/sicherung/einspielen {inhalt, passwort, zusammenfuehren}: alles wiederherstellen, ohne Neustart
  GET  /api/aktualisierung      Aktualisierung aus GitHub: Stand, Einstellungen
  POST /api/aktualisierung/pruefen|installieren|zurueck|entfernen; /einstellungen {repo, zweig, token, auto, stunden}
  GET/POST /api/baukasten, /api/startanimation…: m0dul-Baukasten und Startanimation (oberflaeche_baukasten.py)
  GET  /api/dank                Dank-Liste fuer Einstellungen -> Ueber, mit Laempchen (oberflaeche_dank.py)
  GET/POST /api/radio…: Internetradio aus radio-browser.info, Favoriten (oberflaeche_radio.py)

Schreibende Anfragen brauchen den Header X-Rezeptserver: 1. Fremde Seiten koennen ihn nicht
ohne CORS-Vorabanfrage setzen, und die lehnt der Server fuer /api/ ab.
"""

from .seite import SEITE

import base64
import collections
import json
import logging
import mimetypes
import os
import posixpath
import re
import secrets
import shutil
import socket
import threading
import time
import urllib.error
import urllib.request
from urllib.parse import parse_qs, quote, unquote, urljoin, urlsplit

from . import __version__, aktualisierung, assistent, baukasten, brause, dank, sehen, traum, startanimation, cast, fernseher, radio, verweise, webhosting, easynews, hue, kameras, konfig, videochat, ab18, anbieter, badges as badges_modul, crawler, dht, ed2k, ed2k_suche, einstellungen, frei_tv, ftp, heimspeicher, telegram, xdcc, youtube, kodi_player, sicherheit, anbindungen, debrid, dienste, entdecken, rustnzb, filtern, links as heimlinks, livetv, livetv_sehen, sprachen, vorlagen, vxparser
from . import stremio
from . import autostart, brillen
from .netz import USER_AGENT, _OEFFNER, NetzFehler, NichtOeffentlich, domain_erlaubt, gepruefte_ips, ip_oeffentlich_pruefen, pin_oeffner, urllib_holen
from .oberflaeche_ausliefern import datei_senden, kamera_senden

log = logging.getLogger("rezeptserver")

MAX_KOERPER = 64 * 1024
MAX_NZB_KOERPER = 70 * 1024 * 1024  # NZB-Upload an rustnzb (base64)
MAX_TREFFER = 200
WIEDERGABE_DAUER = 6 * 3600
MAX_WIEDERGABEN = 300
BADGE_BEISPIELE = ["Film.2023.2160p.UHD.BluRay.REMUX.DV.HDR10.HEVC.TrueHD.Atmos.7.1-GRUPPE",
                   "Film.2023.German.DL.1080p.WEB-DL.DDP5.1.H.264-GRUPPE",
                   "Serie.S01E01.German.720p.HDTV.x264-GRUPPE"]
HLS_JS = os.path.join(os.path.dirname(os.path.abspath(__file__)), "statisch", "hls.min.js")
_HLS_URI = re.compile(r'URI="([^"]+)"')
with open(os.path.join(os.path.dirname(os.path.abspath(__file__)), "statisch", "logo.svg"), encoding="utf-8") as _f:
    LOGO = _f.read()  # eigenes Krokodil "cr0c0d0c", erzeugt von tools/logo_bauen.py
# Schriften der Heim-Styles (statisch/schriften/LIZENZ-OFL.txt); der Browser laedt sie erst, wenn ein Style sie nutzt
SCHRIFTEN_ORDNER = os.path.join(os.path.dirname(os.path.abspath(__file__)), "statisch", "schriften")
_SCHRIFT_NAME = re.compile(r"^[a-z0-9]{1,40}\.woff2$")
_SCHRIFTEN = {}


def schrift(name):
    """Inhalt einer Schrift aus statisch/schriften oder None (nur einfache Namen – kein Weg aus dem Ordner)."""
    if not _SCHRIFT_NAME.match(name or ""):
        return None
    if name not in _SCHRIFTEN:
        try:
            with open(os.path.join(SCHRIFTEN_ORDNER, name), "rb") as f:
                _SCHRIFTEN[name] = f.read()
        except OSError:
            return None
    return _SCHRIFTEN[name]
SPRACHNAMEN = {"de": "Deutsch", "en": "Englisch", "mul": "Mehrsprachig", "fr": "Französisch", "es": "Spanisch",
               "it": "Italienisch", "nl": "Niederländisch", "pl": "Polnisch", "tr": "Türkisch", "ru": "Russisch",
               "ja": "Japanisch", "ko": "Koreanisch"}
_RELEASE = re.compile(r"(?i)\b(19\d\d|20\d\d|s\d\d(e\d\d)?|2160p|1080p|720p|480p|german|deutsch|dl|multi|web|"
                      r"webrip|web-dl|bluray|bdrip|hdtv|x264|x265|h264|h265|hevc|uhd|remux)\b")


def such_titel(titel):
    """Kurzer Titel fuer die Bildersuche: 'Big.Buck.Bunny.2008.1080p' -> 'Big Buck Bunny'."""
    text = str(titel or "").split(" · ")[0]
    text = re.sub(r"[\(\[][^\)\]]*[\)\]]", " ", text)
    text = re.sub(r"[._]+", " ", text)
    gefunden = _RELEASE.search(text)
    if gefunden and gefunden.start() > 0:
        text = text[:gefunden.start()]
    return " ".join(text.split()).strip(" -–")


def _datum(treffer):
    datum = treffer.get("datum")
    if datum in (None, ""):
        return ""
    zeit = filtern.zeitpunkt({"datum": datum})
    return time.strftime("%Y-%m-%d", time.localtime(zeit)) if zeit else ""


_SPRACHE = [
    (r"^(?:das |mach(?:e)? (?:das )?)?radio (?:aus|stopp?|stoppen)$", lambda m: "/cast stopp"),
    (r"^(?:spiel(?:e)? |schalte? )?(?:das )?radio (?!aus\b)(.+?)(?: (?:an|ein))?$", lambda m: "/radio %s" % m.group(1)),
    (r"^(?:spiel(?:e)? )(.+?) im radio$", lambda m: "/radio %s" % m.group(1)),
    (r"^(?:schalte |mach(?:e)? )?(?:das )?licht (an|aus|ein)(?: im| in der| in)?\s*(.*)$",
     lambda m: "/licht %s %s" % ("aus" if m.group(1) == "aus" else "an", m.group(2))),
    (r"^(?:schalte |mach(?:e)? )?(?:das |die )?(.+?) (an|aus|ein)$",
     lambda m: "/licht %s %s" % ("aus" if m.group(2) == "aus" else "an", m.group(1))),
]


def sprachbefehl(text):
    """Gesprochenen Satz in einen H0rSt-Befehl uebersetzen; "/..." bleibt, wie es ist."""
    t = text.strip().lower().rstrip(".!?")
    if t.startswith("/"):
        return t
    t = re.sub(r"^(?:ok google|hey google|h0rst|horst)[, ]*", "", t)
    for wort, befehl in (("pi-hole", "pihole"), ("werbefilter", "pihole")):
        t = t.replace(wort, befehl)
    m = re.match(r"^pihole (aus|pause|an)(?: für)?\s*(\d+)?", t)
    if m:
        return "/pihole %s %s" % ("an" if m.group(1) == "an" else "aus", m.group(2) or "")
    for anfang, befehl in (("status", "/status"), ("downloads", "/downloads"), ("suche ", "/suche "), ("finde ", "/suche "),
                           ("pause", "/cast pause"), ("weiter", "/cast weiter"), ("stopp", "/cast stopp"), ("stop", "/cast stopp")):
        if t == anfang.strip() or t.startswith(anfang):
            return (befehl + t[len(anfang):]).strip() if anfang.endswith(" ") else befehl
    m = re.match(r"^lautst(?:ä|ae)rke (?:auf )?(\d+)", t)
    if m:
        return "/cast lautstaerke %s" % m.group(1)
    for muster, bauen in _SPRACHE:
        m = re.match(muster, t)
        if m:
            return bauen(m).strip()
    return "/" + t


def weiterreichen(handler, ziel):
    """Reicht einen Stream samt Range-Anfragen durch. Zugangsdaten nur an Domains aus darf.netz."""
    url, header, netz = ziel[:3]
    eigenes = len(ziel) > 3 and ziel[3]
    oeffentlich = len(ziel) > 4 and ziel[4]
    if url.startswith(("ftp://", "ftps://")):
        return ftp.senden(handler, url, eigenes)
    oeffner = heimspeicher.oeffner(True) if eigenes else _OEFFNER
    kopf = {"User-Agent": USER_AGENT}
    kopf.update(header)
    if handler.headers.get("Range"):
        kopf["Range"] = handler.headers["Range"]
    for _ in range(6):
        hop = oeffner
        if oeffentlich:  # z. B. dateisuche/abspielen: jede Weiterleitung erneut pruefen (SSRF)
            try:
                gepruefte_ips(url)
            except NichtOeffentlich:
                handler.send_error(403)
                return
        if not domain_erlaubt(url, netz):
            # fremde Domain (z. B. CDN nach Weiterleitung): ohne Zugangsdaten weiter
            kopf = {k: v for k, v in kopf.items() if k in ("User-Agent", "Range")}
        try:
            antwort = hop.open(urllib.request.Request(url, headers=kopf, method=handler.command), timeout=20)
        except urllib.error.HTTPError as fehler:
            ziel_url = fehler.headers.get("Location") if fehler.headers else None
            status = fehler.code
            fehler.close()
            if status in (301, 302, 303, 307, 308) and ziel_url:
                url = urljoin(url, ziel_url)
                continue
            handler.send_error(status)
            return
        except (urllib.error.URLError, OSError) as fehler:
            log.warning("Wiedergabe fehlgeschlagen: %s", fehler)
            handler.send_error(502)
            return
        with antwort:
            handler.send_response(antwort.status)
            for name in ("Content-Type", "Content-Length", "Content-Range", "Accept-Ranges", "Last-Modified"):
                if antwort.headers.get(name):
                    handler.send_header(name, antwort.headers[name])
            handler.send_header("Cache-Control", "no-store")
            handler.end_headers()
            if handler.command == "HEAD":
                return
            # weitergeben, was gerade da ist (read1): Live-Streams wie Radio (16 KB/s) sonst erst nach 256 KB hoerbar
            lesen = getattr(antwort, "read1", None) or (lambda n: antwort.read(min(n, 16384)))
            try:
                while True:
                    teil = lesen(256 * 1024)
                    if not teil:
                        break
                    handler.wfile.write(teil)
            except (BrokenPipeError, ConnectionResetError):
                pass  # Player hat abgebrochen oder springt
            except (socket.timeout, TimeoutError) as fehler:  # socket.timeout ist erst ab Python 3.10 dasselbe
                log.warning("Wiedergabe abgebrochen: %s", fehler)
                handler.close_connection = True
        return
    handler.send_error(508)
