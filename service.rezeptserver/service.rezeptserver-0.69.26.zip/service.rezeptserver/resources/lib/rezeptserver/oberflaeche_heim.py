"""HeimMixin
"""

from .oberflaeche_heim_grund import *

from .oberflaeche_afwall import AfwallMixin
from .oberflaeche_heim_sicherheit import _SicherheitMixin
from .oberflaeche_heim_ed2k import _Ed2kMixin
from .oberflaeche_heim_einstellungen import _EinstellungenMixin
from .oberflaeche_heim_router import _RouterMixin
from .oberflaeche_heim_medien import _MedienMixin


class HeimMixin(AfwallMixin, _SicherheitMixin, _Ed2kMixin, _EinstellungenMixin, _RouterMixin, _MedienMixin):
    """HeimMixin aus den Teil-Mixins; aussen bleibt alles gleich (rezeptserver.oberflaeche_heim.*)."""
