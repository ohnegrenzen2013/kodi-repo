"eD2K: Links lesen, hinzufuegen und entfernen."

from .oberflaeche_heim_grund import (
    ed2k,
    json,
    time,
)

class _Ed2kMixin:

    # --- Ember (eD2K) ----------------------------------------------------------------------------
    def _ed2k_links(self):
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        return ed2k.pruefe(daten.get(ed2k.SCHLUESSEL))["links"]

    def ed2k_lesen(self, mit_ember=False):
        links = [dict(l, badges=self.app.badges.zuordnen(l["name"])) for l in self._ed2k_links()]
        return {"links": links, "gesamt": sum(l["groesse"] for l in links),
                "ember": self.app.ember.version() if mit_ember else None}

    def ed2k_post(self, pfad, koerper):
        try:
            daten = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(daten, dict):
                raise ValueError("JSON-Objekt erwartet")
            if not self.app.verwaltung:
                raise ValueError("Nutzerdaten nicht verfügbar")
            links = self._ed2k_links()
            if pfad == "/api/ed2k/hinzu":
                neu = ed2k.links_lesen(daten.get("text", ""))
                if not neu:
                    raise ed2k.Ed2kFehler("Keine ed2k://|file|…-Links gefunden")
                vorhanden = {l["hash"] for l in links}
                jetzt = int(time.time())
                links = [dict(l, zeit=jetzt) for l in neu if l["hash"] not in vorhanden] + links
                antwort_neu = len(links) - len(vorhanden)
            elif pfad == "/api/ed2k/entfernen":
                links = [] if daten.get("alle") else [l for l in links if l["hash"] != str(daten.get("hash", "")).upper()]
                antwort_neu = 0
            else:
                return 404, "application/json", {"fehler": "nicht gefunden"}
            self.app.verwaltung.abschnitt(ed2k.SCHLUESSEL, ed2k.pruefe({"links": links}))
            return 200, "application/json", dict(self.ed2k_lesen(), neu=antwort_neu)
        except (ValueError, UnicodeDecodeError, ed2k.Ed2kFehler) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
