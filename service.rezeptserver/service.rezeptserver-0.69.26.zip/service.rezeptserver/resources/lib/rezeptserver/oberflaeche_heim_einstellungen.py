"Einstellungen und Daten: Werte, Usenet-Suche, Heimspeicher, Wiedergabe und FTP-Adresse."

from .oberflaeche_heim_grund import (
    NetzFehler,
    __version__,
    dienste,
    einstellungen,
    ftp,
    heimspeicher,
    re,
    urlsplit,
)

from . import einstellungen_heim, kinder


class _EinstellungenMixin:

    # --- Einstellungen (wie ARVIO), Telegram, Heimspeicher, Dateisuche, FTP-Server ----------------
    def _einstellungen_lesen(self):
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        w = einstellungen.werte(daten) if self.app.verwaltung else dict(
            self.app.ui, audio=", ".join(self.app.audio_wunsch), untertitel=", ".join(self.app.untertitel_wunsch))
        ich = self.aktuelles_profil() if hasattr(self, "aktuelles_profil") else None
        if ich and ich.get("einstellungen"):  # eigene Ansicht dieses Profils
            w = dict(w, **einstellungen.pruefe(dict(daten.get(einstellungen.SCHLUESSEL) or {}, **ich["einstellungen"])))
            w.update({k: v for k, v in einstellungen.werte(daten).items() if k in ("audio", "untertitel")})
            if "profilname" not in ich["einstellungen"]:
                w["profilname"] = ich["name"]
        elif ich:
            w = dict(w, profilname=ich["name"])
        kategorien = einstellungen.KATEGORIEN
        if kinder.ist_kind(ich) or not self.darf("ab18"):  # Ab 18 - Lesezeichen: fuer Kinder und ohne das Recht gar nicht erst aufgelistet
            kategorien = [k for k in kategorien if k["id"] != "lesezeichen18"]
        if not self.darf("einstellungen"):
            kategorien = [k for k in kategorien if k["id"] not in ("tresor", "menue")]  # Geheimnisse und globale Navigation
        return {"kategorien": kategorien, "werte": w, "akzente": einstellungen.AKZENTE,
                "nav": einstellungen.nav_liste(w.get("eigene_tabs")), "nav_pflicht": list(einstellungen.NAV_PFLICHT),
                "eigene_vorlagen": einstellungen.EIGENE_VORLAGEN, "version": __version__,
                "tasten": {"aktionen": einstellungen_heim.AKTIONEN, "schemata": einstellungen_heim.SCHEMATA},
                "brett_bereiche": list(einstellungen_heim.BEREICHE),
                "profil": {"name": ich["name"], "farbe": ich.get("farbe"), "bereiche": ich.get("bereiche") or []} if ich else None}

    def _reiter_uebernehmen(self, daten):
        """Anordnung der Reiter uebernehmen. {aktion: "von", quelle: profil_id | ""} holt sie von einem Profil (oder die
        gemeinsame) zu mir; {aktion: "an_alle"} gibt meine Anordnung allen Profilen und der gemeinsamen (Recht "profile")."""
        import json
        from . import profile
        app = self.app
        if not app.verwaltung:
            raise ValueError("Nutzerdaten nicht verfügbar")
        d = app.verwaltung.daten()
        gemeinsam = einstellungen.werte(d).get("navigation")
        if daten.get("aktion") == "von":
            quelle = str(daten.get("quelle") or "")
            nav = gemeinsam
            if quelle:
                x = next((y for y in profile.daten_von(d)["liste"] if y["id"] == quelle), None)
                if not x:
                    raise ValueError("Profil nicht gefunden")
                nav = (x.get("einstellungen") or {}).get("navigation") or gemeinsam
            # wie eine eigene Aenderung: mit Profil nur fuer mich, ohne Profil fuer alle (dann mit Recht "einstellungen")
            return self._neu_post("/api/einstellungen", json.dumps({"navigation": nav}).encode("utf-8"))
        if daten.get("aktion") == "an_alle":
            if not self.darf("profile"):
                return 403, "application/json", {"fehler": "Für alle Profile übernimmt, wer Profile verwalten darf", "recht": True}
            nav = self._einstellungen_lesen()["werte"].get("navigation")

            def alle(d):
                w = einstellungen.aendern(d, {"navigation": nav})
                for x in profile.daten_von(d)["liste"]:
                    x["einstellungen"] = dict(x.get("einstellungen") or {}, navigation=w["navigation"])
                return w
            app.ui = einstellungen.pruefe(app.verwaltung.bearbeiten(alle))
            self._profile_daten(frisch=True)
            self.profil_ermitteln({"X-Profil": getattr(self._anfrage_lokal(), "token", "")}, {})
            return 200, "application/json", dict(self._einstellungen_lesen(), profile=len(profile.daten_von(app.verwaltung.daten())["liste"]))
        raise ValueError("aktion: von oder an_alle")

    def _usenet_suche(self, text, seite="1"):
        """binsearch-Treffer mit Streaming-Zielen (NzbDAV, AltMount, rustnzb) und NZB-Downloadern."""
        from . import binsearch
        app = self.app
        try:
            seite = max(1, min(40, int(seite or 1)))
        except ValueError:
            seite = 1
        antwort = {"treffer": [], "fehler": "", "weiter": False, "suche": binsearch.such_adresse(text, seite)}
        try:
            roh = binsearch.suchen(text, app._binsearch.abruf, seite, nur_vollstaendig=False)
        except NetzFehler as fehler:
            antwort["fehler"] = "binsearch nicht erreichbar: %s" % fehler
            return antwort
        streamer = [(aid, c.typ_name) for aid, c in sorted(app.dienste.items()) if getattr(c, "typ", "") in dienste.USENET_STREAMER]
        if app.rustnzb:
            streamer.append(("", "rustnzb"))
        kandidaten = []
        for t in roh:
            kategorie = "TV" if re.search(r"S\d\dE\d\d", t["titel"], re.I) else "Movies"
            t["streams"] = [{"name": name, "url": app.usenet_adresse(t["nzb"], t["titel"], "", aid, kategorie)}
                            for aid, name in streamer] if t["vollstaendig"] else []
            kandidaten.append({"url": t["nzb"], "name": t["titel"], "treffer": t})
        geprueft = app.usenet_kandidaten_pruefen(kandidaten)
        # Blockierte NZBs bleiben als Zeile sichtbar, bekommen aber keine Streams.
        erlaubt = {k.get("url") for k in geprueft} if geprueft is not kandidaten else None
        extra = {k.get("url"): k for k in geprueft}
        for k in kandidaten:
            t = k["treffer"]
            if erlaubt is not None and k["url"] not in erlaubt:
                t["streams"] = []
            zusatz = extra.get(k["url"]) or {}
            if zusatz.get("usenet"):
                t["usenet"] = zusatz["usenet"]
            if zusatz.get("usenet_ref"):
                t["usenet_ref"] = zusatz["usenet_ref"]
            antwort["treffer"].append(t)
        antwort["weiter"] = len(roh) >= binsearch.PRO_SEITE
        antwort["ziele"] = [{"id": i, "name": c.name or c.typ_name} for i, c in sorted(app.dienste.items())
                            if getattr(c, "typ", "") in dienste.NZB_CLIENTS and "nzb" in getattr(c, "kann", ())]
        return antwort

    # Kategorien wie bei Newznab/Spotweb: 2000 Filme, 5000 Serien, 3000 Musik, 4000 PC, 6000 XXX
    INDEXER_KATEGORIEN = {"": "", "film": "2000", "serie": "5000", "musik": "3000", "pc": "4000", "xxx": "6000"}

    # Beliebte Binaer-Newsgroups als Vorschlag fuer "Nach Newsgroup stoebern" (frei eintragbar, keine Pflicht)
    GRUPPEN_VORSCHLAG = ("alt.binaries.teevee", "alt.binaries.moovee", "alt.binaries.multimedia", "alt.binaries.hdtv",
                         "alt.binaries.hdtv.x264", "alt.binaries.boneless", "alt.binaries.tv", "alt.binaries.movies",
                         "alt.binaries.documentaries", "alt.binaries.sounds.flac", "alt.binaries.ebook")
    _GRUPPE = re.compile(r"^[a-z0-9][a-z0-9.+_-]{2,100}$")
    _GRUPPE_AB18 = re.compile(r"erotic|porn|xxx|sex|adult|nude|fetish|hentai", re.I)

    @classmethod
    def gruppen_pruefen(cls, text):
        """'alt.binaries.a, alt.binaries.b' -> Liste (hoechstens 5, kleingeschrieben); ValueError bei ungueltigem Namen."""
        namen = []
        for n in re.split(r"[,;\s]+", str(text or "").strip().lower()):
            if not n:
                continue
            if not cls._GRUPPE.match(n):
                raise ValueError("Ungültiger Newsgroup-Name: %s" % n[:60])
            if n not in namen:
                namen.append(n)
        if len(namen) > 5:
            raise ValueError("Höchstens 5 Newsgroups auf einmal")
        return namen

    def _indexer_suche(self, text, kat="", gruppe=""):
        """Freie Suche bei allen eigenen Newznab-Indexern (auch Spotweb) gleichzeitig, auf Wunsch nur in bestimmten
        Newsgroups (Newznab-Parameter group; ohne Suchbegriff werden die neuesten Posts der Gruppe gelistet).
        NZB-Adressen mit API-Schluessel verlassen den Server nicht: die Seite bekommt eine verpackte H0rSt-Adresse."""
        from concurrent.futures import ThreadPoolExecutor
        from urllib.parse import urlencode
        from .anbindungen_anbieter import newznab_lesen
        from .anbindungen_grund import _api_adresse
        from .netz import Abrufer, urllib_holen
        app = self.app
        text = " ".join(str(text or "").split())[:200]
        if kat not in self.INDEXER_KATEGORIEN:
            kat = ""
        try:
            gruppen = self.gruppen_pruefen(gruppe)
        except ValueError as fehler:
            return {"treffer": [], "indexer": [], "ziele": [], "fehler": str(fehler)}
        if (kat == "xxx" or any(self._GRUPPE_AB18.search(g) for g in gruppen)) and not app.ab18.freigegeben:
            return {"treffer": [], "indexer": [], "ziele": [], "fehler": "XXX nur mit Ab-18-Freigabe"}
        if not text and not gruppen:
            return {"treffer": [], "indexer": [], "ziele": [], "fehler": "Suchbegriff oder Newsgroup eintragen"}
        daten = app.verwaltung.daten() if app.verwaltung else {}
        zugaenge = daten.get("einstellungen") or {}
        indexer = [(aid, e.get("name") or aid, zugaenge.get(aid) or {}) for aid, e in sorted((daten.get("anbieter") or {}).items())
                   if e.get("typ") == "newznab"]
        indexer = [(aid, name, z) for aid, name, z in indexer if z.get("url") and z.get("api_key")]
        if not indexer:
            return {"treffer": [], "indexer": [], "ziele": [], "fehler": "Noch kein Indexer: unter Einstellungen → Anbieter & Addons "
                    "„Spotweb (NZBFinder)“, NZBFinder, NZBgeek oder einen eigenen Newznab-Indexer anlegen."}

        def suchen(eintrag):
            aid, name, z = eintrag
            parameter = {"t": "search", "q": text, "limit": "60", "extended": "1", "apikey": z["api_key"]}
            if gruppen:
                parameter["group"] = ",".join(gruppen)
            if self.INDEXER_KATEGORIEN[kat]:
                parameter["cat"] = self.INDEXER_KATEGORIEN[kat]
            adresse = _api_adresse(z["url"])
            try:
                host = urlsplit(adresse).hostname or ""
                return name, newznab_lesen(Abrufer([host], holen=getattr(app.verwaltung, "holen", None) or urllib_holen, zeitgrenze=20.0)
                                           .abruf(adresse + "?" + urlencode(parameter))), ""
            except Exception as fehler:  # ein Indexer darf ausfallen
                return name, [], str(fehler).replace(z["api_key"], "<schlüssel>")[:200]
        with ThreadPoolExecutor(max_workers=min(6, len(indexer))) as pool:
            ergebnisse = list(pool.map(suchen, indexer))
        streamer = [(aid, c.typ_name) for aid, c in sorted(app.dienste.items()) if getattr(c, "typ", "") in dienste.USENET_STREAMER]
        if app.rustnzb:
            streamer.append(("", "rustnzb"))
        roh = []
        for name, liste, _ in ergebnisse:
            for r in liste:
                if not r["titel"] or not r["link"]:
                    continue
                # ignoriert ein Indexer den Parameter group, aber nennt die Gruppe im Treffer, filtern wir selbst
                if gruppen and r.get("gruppe") and not any(g in r["gruppe"].lower() for g in gruppen):
                    continue
                kategorie = "TV" if re.search(r"S\d\dE\d\d", r["titel"], re.I) else "Movies"
                eintrag = {"titel": r["titel"], "indexer": name, "groesse": int(r["groesse"]) if str(r["groesse"]).isdigit() else 0,
                           "datum": r["datum"], "nzb": "api/dateisuche/nzb/" + app.debrid.verpacken(r["link"]),
                           **{k: r[k] for k in ("gruppe", "grabs", "kommentare", "kategorie", "poster") if r.get(k)},
                           "streams": [{"name": sn, "url": app.usenet_adresse(r["link"], r["titel"], "", aid, kategorie)} for aid, sn in streamer]}
                roh.append((r["link"], eintrag))
        roh.sort(key=lambda paar: -(paar[1]["datum"] or 0))
        kandidaten = [{"url": url, "name": eintrag["titel"], "treffer": eintrag} for url, eintrag in roh]
        geprueft = app.usenet_kandidaten_pruefen(kandidaten)
        erlaubt = {k.get("url") for k in geprueft} if geprueft is not kandidaten else None
        extra = {k.get("url"): k for k in geprueft}
        treffer = []
        for k in kandidaten:
            t = k["treffer"]
            if erlaubt is not None and k["url"] not in erlaubt:
                t["streams"] = []
            zusatz = extra.get(k["url"]) or {}
            if zusatz.get("usenet"):
                t["usenet"] = zusatz["usenet"]
            if zusatz.get("usenet_ref"):
                t["usenet_ref"] = zusatz["usenet_ref"]
            treffer.append(t)
        return {"treffer": treffer[:300], "fehler": "", "gruppen": list(gruppen), "gruppen_vorschlag": list(self.GRUPPEN_VORSCHLAG),
                "indexer": [{"name": n, "anzahl": len(l), "fehler": f} for n, l, f in ergebnisse],
                "ziele": [{"id": i, "name": c.name or c.typ_name} for i, c in sorted(app.dienste.items())
                          if getattr(c, "typ", "") in dienste.NZB_CLIENTS and "nzb" in getattr(c, "kann", ())]}

    def _indexer_nzb(self, schluessel):
        """Verpackte NZB-Adresse (mit API-Schluessel) auspacken und die NZB durchreichen."""
        from .netz import Abrufer, urllib_holen
        url = self.app.debrid.auspacken(schluessel)
        if not url or not url.startswith(("http://", "https://")):
            return 404, "application/json", {"fehler": "unbekannter oder veralteter Link"}
        try:
            text = Abrufer([urlsplit(url).hostname or ""], holen=getattr(self.app.verwaltung, "holen", None) or urllib_holen, zeitgrenze=30.0).abruf(url)
        except NetzFehler as fehler:
            return 502, "application/json", {"fehler": str(fehler)}
        return 200, "application/x-nzb", text.encode("utf-8") if isinstance(text, str) else text

    def _speicher(self, sid):
        s = next((x for x in self.app.heimspeicher if x["id"] == str(sid or "")), None)
        if s is None:
            raise heimspeicher.SpeicherFehler("Speicher gibt es nicht (mehr)")
        return s

    def _heim_lesen(self):
        return {"speicher": heimspeicher.oeffentlich(self.app.heimspeicher), "arten": heimspeicher.ARTEN}

    def _datei_wiedergabe(self, s, pfad):
        if s["art"] == "ftp":
            return "api/wiedergabe/" + self._wiedergabe_merken(ftp.datei_url(s, pfad), {}, [],
                                                               s.get("zertifikat") == "eigenes")
        url = heimspeicher.adresse(s, pfad)
        return "api/wiedergabe/" + self._wiedergabe_merken(url, heimspeicher.kopf(s), [urlsplit(url).hostname or ""],
                                                           s.get("zertifikat") == "eigenes")

    def _ftp_adresse(self):
        from .dienst import eigene_adresse
        try:
            return eigene_adresse()
        except Exception:
            return ""
