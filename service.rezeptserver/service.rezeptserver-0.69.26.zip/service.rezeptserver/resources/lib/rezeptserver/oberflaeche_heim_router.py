"Hauptschalter GET und POST: Einstellungen, Telegram, Heimspeicher, Suche, FTP, Aktualisierung, Sicherung."

from .oberflaeche_heim_grund import (
    NichtOeffentlich,
    aktualisierung,
    crawler,
    dht,
    ed2k_suche,
    einstellungen,
    ftp,
    heimspeicher,
    ip_oeffentlich_pruefen,
    json,
    konfig,
    log,
    os,
    posixpath,
    sprachen,
    telegram,
    time,
    unquote,
    urlsplit,
)

class _RouterMixin:

    def _neu_get(self, pfad, werte):
        app = self.app
        try:
            if pfad == "/api/einstellungen":
                return 200, "application/json", self._einstellungen_lesen()
            if pfad == "/api/telegram":
                return 200, "application/json", app.telegram.zustand()
            if pfad == "/api/heimspeicher":
                return 200, "application/json", self._heim_lesen()
            if pfad == "/api/heimspeicher/liste":
                s = self._speicher(werte.get("id"))
                return 200, "application/json", {"pfad": heimspeicher.pfad_sauber(werte.get("pfad", "/")),
                                                 "eintraege": heimspeicher.liste(s, werte.get("pfad", "/"))}
            if pfad == "/api/heimspeicher/crawl":
                s = self._speicher(werte.get("id"))
                return 200, "application/json", crawler.crawlen(s, werte.get("q", ""), heimspeicher.liste,
                                                                werte.get("medien") == "1")
            if pfad == "/api/dht":
                return 200, "application/json", dht.peers_zaehlen(werte.get("q", ""))
            if pfad == "/api/ed2k/suche":
                r = app.ed2k_suche.suchen(werte.get("q", ""), werte.get("typ", ""))
                for t in r["treffer"]:
                    t["badges"] = app.badges.zuordnen(t["name"])
                return 200, "application/json", r
            if pfad == "/api/ftpserver":
                return 200, "application/json", app.ftp_server.zustand(self._ftp_adresse())
            if pfad == "/api/aktualisierung":
                return 200, "application/json", app.aktualisierung.zustand()
            if pfad.startswith("/api/aktualisierung/sicherung/"):
                return "lokal", app.aktualisierung.sicherung_pfad(unquote(pfad.rsplit("/", 1)[1]))
            if pfad == "/api/aktualisierung/app":  # neueste gebaute App (APK) und ob sie neuer ist
                return 200, "application/json", app.aktualisierung.app_pruefen(werte.get("sha", ""))
            if pfad == "/api/aktualisierung/app/apk":  # geladene APK, z. B. fuer ein anderes Geraet
                datei = os.path.join(app.datenordner, aktualisierung.APP_DATEI)
                return ("lokal", datei) if os.path.isfile(datei) else (404, "application/json", {"fehler": "noch nicht geladen"})
            if pfad == "/api/dateisuche/indexer":  # alle eigenen Newznab-Indexer und Spotweb zugleich
                return 200, "application/json", self._indexer_suche(werte.get("q", ""), werte.get("kat", ""), werte.get("gruppe", ""))
            if pfad.startswith("/api/dateisuche/nzb/"):  # NZB eines Indexers, ohne den API-Schluessel preiszugeben
                return self._indexer_nzb(pfad[len("/api/dateisuche/nzb/"):])
            if pfad == "/api/dateisuche/usenet":  # binsearch: freie Usenet-Suche, Treffer streamen oder laden
                return 200, "application/json", self._usenet_suche(werte.get("q", ""), werte.get("seite", "1"))
            if pfad == "/api/dateisuche/ftp":  # NAPALM FTP Indexer und Mamont (mmnt.net/mmnt.ru)
                q = werte.get("q", "")
                antwort = {"browser": crawler.browser_adresse(q), "browser_mamont": crawler.mamont_adresse(q), "treffer": [], "fehler": ""}
                try:
                    antwort.update(crawler.ftp_suchen(q, ab=str(werte.get("ab") or "")))
                except crawler.CrawlerFehler as fehler:
                    antwort["fehler"] = str(fehler)
                return 200, "application/json", antwort
            if pfad == "/api/dateisuche/verzeichnisse":
                return 200, "application/json", {"treffer": crawler.verzeichnisse_suchen(
                    werte.get("q", ""), werte.get("art", "video"), werte.get("pub") == "1")}
            if pfad == "/api/dateisuche/web":
                return 200, "application/json", crawler.webcrawl(werte.get("url", ""), werte.get("art", "video"))
            if pfad == "/api/dateisuche/liste":  # offenes Verzeichnis aus der Suche, ohne es zu speichern
                s = {"art": "verzeichnis", "url": str(werte.get("url", "")).rstrip("/"), "zertifikat": "pruefen"}
                if not s["url"].lower().startswith(("http://", "https://")):
                    raise heimspeicher.SpeicherFehler("Adresse muss mit http(s):// beginnen")
                return 200, "application/json", {"pfad": heimspeicher.pfad_sauber(werte.get("pfad", "/")),
                                                 "eintraege": heimspeicher.liste(s, werte.get("pfad", "/"))}
        except (ValueError, OSError, dht.DhtFehler, ed2k_suche.SucheFehler, crawler.CrawlerFehler,
                heimspeicher.SpeicherFehler, ftp.FtpFehler) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        return 404, "application/json", {"fehler": "nicht gefunden"}

    def _neu_post(self, pfad, koerper):
        app = self.app
        try:
            daten = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(daten, dict):
                raise ValueError("JSON-Objekt erwartet")
            if pfad == "/api/einstellungen/reiter":
                return self._reiter_uebernehmen(daten)
            if pfad == "/api/einstellungen":
                if not app.verwaltung:
                    raise ValueError("Nutzerdaten nicht verfügbar")
                from . import profile
                from .oberflaeche_profile import GEMEINSAM
                ich = self.aktuelles_profil()
                eigen = {k: v for k, v in daten.items() if k not in GEMEINSAM} if ich else {}
                gemeinsam = {k: v for k, v in daten.items() if k not in eigen}
                if gemeinsam and not self.darf("einstellungen"):
                    return 403, "application/json", {"fehler": "Gemeinsame Einstellungen ändert, wer das Recht dazu hat", "recht": True}
                if eigen:  # gilt nur fuer dieses Profil

                    def eigene(d):
                        x = next(y for y in profile.daten_von(d)["liste"] if y["id"] == ich["id"])
                        probe = {einstellungen.SCHLUESSEL: dict(d.get(einstellungen.SCHLUESSEL) or {}, **(x.get("einstellungen") or {}))}
                        neu = einstellungen.aendern(probe, eigen)  # prueft jeden Wert
                        x["einstellungen"] = dict(x.get("einstellungen") or {}, **{k: neu[k] for k in eigen if k in neu})
                    app.verwaltung.bearbeiten(eigene)
                    self._profile_daten(frisch=True)
                    self.profil_ermitteln({"X-Profil": getattr(self._anfrage_lokal(), "token", "")}, {})
                    if not gemeinsam:
                        return 200, "application/json", self._einstellungen_lesen()
                    daten = gemeinsam
                w = app.verwaltung.bearbeiten(lambda d: einstellungen.aendern(d, daten))
                app.ui = einstellungen.pruefe(w)
                if "dlna_server" in daten:
                    app.medienserver_setzen(app.ui.get("dlna_server", True))
                app.audio_wunsch = sprachen.als_liste(w.get("audio"))
                app.untertitel_wunsch = sprachen.als_liste(w.get("untertitel"))
                return 200, "application/json", self._einstellungen_lesen()
            if pfad.startswith("/api/telegram/"):
                t, was = app.telegram, pfad[len("/api/telegram/"):]
                if was == "einstellungen":
                    return 200, "application/json", t.einstellen(daten)
                if was == "koppeln":
                    return 200, "application/json", t.koppeln()
                if was == "test":
                    return 200, "application/json", dict(t.zustand(), meldung=t.testen())
                if was == "chat_weg":
                    return 200, "application/json", t.chat_entfernen(daten.get("id"))
                return 404, "application/json", {"fehler": "nicht gefunden"}
            if pfad == "/api/heimspeicher":
                if not app.verwaltung:
                    raise ValueError("Nutzerdaten nicht verfügbar")
                neu = heimspeicher.pruefe(daten.get("speicher"), app.heimspeicher)
                app.verwaltung.abschnitt(heimspeicher.SCHLUESSEL, neu)
                app.heimspeicher = neu
                return 200, "application/json", self._heim_lesen()
            if pfad == "/api/heimspeicher/pruefen":
                ok, meldung = heimspeicher.pruefen(self._speicher(daten.get("id")))
                return 200, "application/json", {"ok": ok, "meldung": meldung}
            if pfad == "/api/heimspeicher/abspielen":
                s = self._speicher(daten.get("id"))
                return 200, "application/json", {"url": self._datei_wiedergabe(s, daten.get("pfad", "")),
                                                 "name": posixpath.basename(str(daten.get("pfad", "")))}
            if pfad == "/api/dateisuche/abspielen":  # FTP-Treffer (NAPALM) oder Datei aus einem offenen Verzeichnis
                url = str(daten.get("url", "")).strip()
                t = urlsplit(url)
                if t.scheme in ("ftp", "ftps"):
                    return 200, "application/json", {"url": "api/wiedergabe/" + self._wiedergabe_merken(url, {}, [])}
                if t.scheme in ("http", "https") and t.hostname:
                    try:
                        ip_oeffentlich_pruefen(url)
                    except NichtOeffentlich as fehler:
                        raise ValueError(str(fehler))
                    return 200, "application/json", {"url": "api/wiedergabe/" + self._wiedergabe_merken(url, {}, [t.hostname], oeffentlich=True)}
                raise ValueError("ftp://- oder http(s)://-Adresse erwartet")
            if pfad == "/api/sicherung/erstellen":  # eine Datei mit allem; Geraetedaten kommen vom Browser
                if not app.verwaltung:
                    raise ValueError("Nutzerdaten nicht verfügbar")
                passwort = str(daten.get("passwort") or "")
                if passwort and len(passwort) < 8:
                    raise ValueError("Passwort für die Sicherung: mindestens 8 Zeichen")
                geraet = daten.get("geraet") if isinstance(daten.get("geraet"), dict) else None
                text = konfig.sicherung(app.verwaltung.konfig_pfad, passwort or None, geraet)
                return 200, "application/json", {"datei": text, "name": time.strftime("h0rst-sicherung-%Y-%m-%d.json"),
                                                 "verschluesselt": bool(passwort)}
            if pfad == "/api/sicherung/einspielen":
                if not app.verwaltung:
                    raise ValueError("Nutzerdaten nicht verfügbar")
                text = str(daten.get("inhalt") or "")
                neu, geraet = konfig.aus_sicherung(text, str(daten.get("passwort") or "") or None, mit_geraet=True)
                anzahl = konfig.einlesen(app.verwaltung.konfig_pfad, text, bool(daten.get("zusammenfuehren")),
                                         str(daten.get("passwort") or "") or None)
                token = app.nutzerdaten_neu()
                log.info("Sicherung eingespielt (%d Einstellungen, %d Anbieter)", anzahl, len(neu.get("anbieter") or {}))
                return 200, "application/json", {"anbieter": len(neu.get("anbieter") or {}), "einstellungen": anzahl,
                                                 "geraet": geraet, "basis": "/%s/" % token if token else "/"}
            if pfad.startswith("/api/aktualisierung/"):
                a, was = app.aktualisierung, pfad[len("/api/aktualisierung/"):]
                if was == "einstellungen":
                    return 200, "application/json", a.einstellen(daten)
                if was in ("pruefen", "installieren"):
                    try:
                        a.pruefen() if was == "pruefen" else a.installieren()
                    except Exception as fehler:  # noqa: BLE001 - wie der Hintergrund-Check (aktualisierung_hintergrund.py)
                        # einordnen, statt roh durchzuwerfen - sonst zeigt die Oberflaeche "Fehler: ..." auch
                        # fuer einen reinen Token-Hinweis (fehler_art="token"), und ein Netz-/JSON-/Platten-
                        # fehler (nicht aktualisierung.UpdateFehler) bliebe im manuellen Pfad unsichtbar,
                        # waehrend der Auto-Lauf ihn dauerhaft zeigt.
                        a.fehler, a.fehler_art = str(fehler) or type(fehler).__name__, getattr(fehler, "art", "")
                elif was == "zurueck":
                    a.zurueck()
                elif was == "entfernen":
                    a.entfernen()
                elif was == "sichern":
                    a.sichern()
                elif was == "app/laden":
                    return 200, "application/json", {"pfad": a.app_laden()}
                else:
                    return 404, "application/json", {"fehler": "nicht gefunden"}
                return 200, "application/json", a.zustand()
            if pfad == "/api/ftpserver":
                return 200, "application/json", dict(app.ftp_server.einstellen(daten),
                                                     adresse=app.ftp_server.zustand(self._ftp_adresse())["adresse"])
        except (ValueError, UnicodeDecodeError, OSError, telegram.TelegramFehler, heimspeicher.SpeicherFehler,
                einstellungen.EinstellungsFehler, ftp.FtpFehler, aktualisierung.UpdateFehler, konfig.DatenFehler) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        return 404, "application/json", {"fehler": "nicht gefunden"}
