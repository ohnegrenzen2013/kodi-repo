"Sicherheit: Zustand, Pruefen, Einstellungen (Netzweg)."

from .oberflaeche_heim_grund import (
    json,
    log,
    sicherheit,
)

class _SicherheitMixin:
    # --- Sicherheit ----------------------------------------------------------------
    def sicherheit_lesen(self):
        daten = self.app.verwaltung.daten()
        bereich = self.app.ab18
        antwort = sicherheit.zustand(daten, token=bool(self.app.token),
                                     ab18_pin=bereich.mit_pin if bereich.freigegeben else None)
        alle = self.anbieter_lesen()
        antwort["verbindungen"] = [a for a in alle["anbieter"] if a["kategorie"] == "sicherheit"]
        antwort["vorlagen"] = [v for v in alle["vorlagen"] if v["kategorie"] == "sicherheit"]
        return antwort

    def sicherheit_post(self, pfad, koerper):
        try:
            daten = json.loads(koerper.decode("utf-8") or "{}")
        except (ValueError, UnicodeDecodeError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        if not isinstance(daten, dict):
            return 400, "application/json", {"fehler": "JSON-Objekt erwartet"}
        if pfad == "/api/sicherheit/pruefen":
            try:
                return 200, "application/json", sicherheit.pruefen()
            except sicherheit.Gesperrt as fehler:
                return 200, "application/json", {"fehler": str(fehler), "gesperrt": True}
        if pfad == "/api/sicherheit/einstellungen":
            return self._verwaltet(lambda: self.sicherheit_speichern(daten))
        return 404, "application/json", {"fehler": "nicht gefunden"}

    def sicherheit_speichern(self, neu):
        erwartet = {"weg": sicherheit.WEG_TYPEN, "onion": ("tor",), "i2p": ("i2p",), "wireguard": ("wireguard",)}

        def setzen(d):
            eigene = d.get("anbieter") or {}
            e = dict(sicherheit.pruefe(d.get(sicherheit.SCHLUESSEL)))
            for k, w in neu.items():
                if k not in sicherheit.STANDARD:
                    raise ValueError("Unbekannte Einstellung: %s" % k)
                e[k] = w
            e = sicherheit.pruefe(e)
            for k, typen in erwartet.items():
                if e[k] and (eigene.get(e[k]) or {}).get("typ") not in typen:
                    raise ValueError("%s passt nicht zu %s" % (e[k], k))
            d[sicherheit.SCHLUESSEL] = e
        self.app.verwaltung.aendern(setzen)  # laedt neu und wendet den Netzweg an
        log.info("Sicherheit gespeichert")
        return self.sicherheit_lesen()
