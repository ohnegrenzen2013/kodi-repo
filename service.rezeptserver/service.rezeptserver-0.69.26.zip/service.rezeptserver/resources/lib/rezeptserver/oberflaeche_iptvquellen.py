"""IPTV-Quellen: freie Listen, Dispatcharr und die Listen-Diagnose.

  GET  /api/iptvquellen              Quellen, Werkzeuge und Dispatcharr-Stand
  POST /api/iptvquellen              {aktion: pruefen | liste_pruefen | uebernehmen | dispatcharr}
"""

import json

from . import iptv_quellen, livetv


class IptvQuellenMixin:

    def iptvquellen_lesen(self):
        werte = self._einstellungen_lesen().get("werte") or {}
        return 200, "application/json", iptv_quellen.zustand(werte)

    def _iptv_liste_uebernehmen(self, name, url, epg=""):
        if not isinstance(name, str) or not isinstance(url, str):
            raise ValueError("Name und Adresse noetig")
        alt = dict(self.app.livetv)
        eintrag = iptv_quellen.listen_eintrag(name, url)
        listen = [l for l in (alt.get("listen") or []) if l.get("url") != eintrag["url"]]
        if any(l.get("name") == eintrag["name"] for l in listen):
            raise livetv.LiveTvFehler("Eine Liste mit diesem Namen gibt es schon")
        neu = dict(alt, listen=listen + [eintrag])
        if epg and not str(neu.get("epg_quelle") or "").strip():
            neu["epg_quelle"] = epg
        self.app.setze_livetv(neu)
        return eintrag

    def iptvquellen_post(self, koerper):
        werte = self._einstellungen_lesen().get("werte") or {}
        if werte.get("iptvquellen_an") is False:
            return 403, "application/json", {"fehler": "IPTV-Quellen sind in den Einstellungen ausgeschaltet."}
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(wunsch, dict):
                raise ValueError("JSON-Objekt erwartet")
            aktion = wunsch.get("aktion")
            if aktion == "pruefen":
                return 200, "application/json", iptv_quellen.zustand(werte, pruefen=True)
            if aktion == "liste_pruefen":
                return 200, "application/json", iptv_quellen.liste_pruefen(wunsch.get("url"))
            if aktion == "uebernehmen":
                eintrag = self._iptv_liste_uebernehmen(wunsch.get("name"), wunsch.get("url"), wunsch.get("epg") or "")
                return 200, "application/json", {"ok": True, "liste": eintrag,
                                                 "meldung": "Liste in Live-TV aufgenommen."}
            if aktion == "dispatcharr":
                stand = iptv_quellen.dispatcharr_zustand(werte, pruefen=True)
                if not stand.get("erreichbar"):
                    return 400, "application/json", stand
                eintrag = self._iptv_liste_uebernehmen("Dispatcharr", stand["m3u"], stand["epg"])
                return 200, "application/json", {"ok": True, "liste": eintrag, "dispatcharr": stand}
            return 400, "application/json", {"fehler": "aktion: pruefen, liste_pruefen, uebernehmen oder dispatcharr"}
        except (ValueError, UnicodeDecodeError, livetv.LiveTvFehler) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
