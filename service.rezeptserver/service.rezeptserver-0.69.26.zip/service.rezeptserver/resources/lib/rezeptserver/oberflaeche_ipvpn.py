"""IPVPN: Schnittstellen, Peers und die Einrichtung.

  GET  /api/ipvpn                     Netz, Peers, Schnittstellen und Befehle
  POST /api/ipvpn                     {aktion: pruefen}
"""

import json

from . import ipvpn


class IpvpnMixin:

    def ipvpn_lesen(self):
        werte = self._einstellungen_lesen().get("werte") or {}
        return 200, "application/json", ipvpn.zustand(werte)

    def ipvpn_post(self, koerper):
        werte = self._einstellungen_lesen().get("werte") or {}
        if werte.get("ipvpn_an") is not True:
            return 403, "application/json", {"fehler": "IPVPN ist in den Einstellungen ausgeschaltet."}
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(wunsch, dict) or wunsch.get("aktion") != "pruefen":
                return 400, "application/json", {"fehler": "aktion: pruefen"}
            return 200, "application/json", ipvpn.zustand(werte, pruefen=True)
        except (ValueError, UnicodeDecodeError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
