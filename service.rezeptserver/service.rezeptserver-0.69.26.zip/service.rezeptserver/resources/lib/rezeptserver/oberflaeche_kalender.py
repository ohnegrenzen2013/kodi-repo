"""Release-Kalender der Bibliothek: Termine aus Merkliste, Weiterschauen und Verlauf."""

from . import release_kalender
from .netz import NetzFehler


class KalenderMixin:
    def kalender_lesen(self, werte):
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        profil_id = self._sehen_profil()
        try:
            return 200, "application/json", release_kalender.eintraege(
                daten, profil_id, getattr(self.app, "tmdb", None), werte.get("tage", 30))
        except (ValueError, NetzFehler) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
