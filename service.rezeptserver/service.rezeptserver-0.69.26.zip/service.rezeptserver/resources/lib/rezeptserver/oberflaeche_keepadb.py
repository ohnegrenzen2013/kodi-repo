"""KeepADB: Zustand, Netzbewertung, Webhook und Schaltbefehle.

  GET  /api/keepadb          {name, stand, paket, an, regel, kraft, befehle, …}
  POST /api/keepadb          {aktion: befehl|netz|meldung, …}

H0rSt setzt Settings.Global.adb_wifi_enabled nicht selbst; es bewertet Netze,
maskiert Adressen, baut Befehle und sendet auf Wunsch den Endpunkt an einen Webhook.
"""

import json

from . import keepadb


class KeepAdbMixin:

    def keepadb_lesen(self):
        daten = self._einstellungen_lesen()
        return 200, "application/json", keepadb.zustand(daten.get("werte") or {})

    def keepadb_post(self, koerper):
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
        except (ValueError, UnicodeDecodeError):
            return 400, "application/json", {"fehler": "JSON-Fehler"}
        if not isinstance(wunsch, dict):
            return 400, "application/json", {"fehler": "JSON-Objekt erwartet"}
        werte = self._einstellungen_lesen().get("werte") or {}
        aktion = str(wunsch.get("aktion") or "befehl")
        try:
            if aktion == "zustand":
                return 200, "application/json", keepadb.zustand(werte)
            if aktion == "befehl":
                return 200, "application/json", keepadb.befehl_bauen(werte, wunsch.get("befehl"),
                                                                     wunsch.get("werte"))
            if aktion == "netz":
                netz = wunsch.get("netz") if isinstance(wunsch.get("netz"), dict) else {}
                return 200, "application/json", keepadb.entscheidung(netz, werte)
            if aktion == "meldung":
                return 200, "application/json", keepadb.meldung(wunsch.get("endpunkt"), werte)
            if aktion == "senden":
                if not self.darf("einstellungen"):
                    return 403, "application/json", {"fehler": "Kein Recht auf Einstellungen", "recht": True}
                return 200, "application/json", keepadb.melden(wunsch.get("endpunkt"), werte)
            raise keepadb.KeepAdbFehler("aktion: zustand, befehl, netz, meldung oder senden")
        except keepadb.KeepAdbFehler as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        except ValueError as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
