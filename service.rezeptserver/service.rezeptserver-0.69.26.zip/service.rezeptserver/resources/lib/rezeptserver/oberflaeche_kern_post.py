"""POST-Routing des Oberflaechen-Kerns."""

import json


class KernPostMixin:
    def _post_route(self, pfad, koerper, kopf, werte):
        if pfad == "/api/profile":
            return self.profile_post(koerper)
        if pfad == "/api/tresor":
            return self.tresor_post(koerper)
        if pfad == "/api/linkreiniger":
            return self.linkreiniger_post(koerper)
        if pfad == "/api/admin":
            return self.admin_post(koerper)
        if pfad == "/api/dateien":
            return self.dateien_post(koerper)
        if pfad == "/api/downloads":
            return self.downloads_post(koerper)
        if pfad == "/api/cloudstream":
            return self.cloudstream_post(koerper)
        if pfad.startswith("/api/fehler/"):
            return self.fehler_post(pfad, koerper, kopf)
        if pfad.startswith("/api/kodiaddons/"):
            return self.kodiaddons_post(pfad, koerper)
        if pfad.startswith("/api/speicher/"):
            return self.speicher_post(pfad, koerper)
        if pfad == "/api/filter":
            return self.filter_speichern(koerper)
        if pfad == "/api/livetv":
            return self.livetv_speichern(koerper)
        if pfad == "/api/livetv/sehen":
            return self.livetv_sehen_post(koerper)
        if pfad == "/api/xtream":
            return self.xtream_url(koerper)
        if pfad == "/api/links":
            return self.links_speichern(koerper)
        if pfad.startswith("/api/ab18/lesezeichen/"):
            return self.lesezeichen_post(pfad, koerper, kopf)
        if pfad.startswith("/api/ab18/"):
            return self.ab18_post(pfad, koerper, kopf)
        if pfad.startswith("/api/anonym/"):
            return self.anonym_post(pfad, koerper)
        if pfad in ("/api/daumenkino", "/api/party"):
            return self.party_post(pfad, koerper)
        if pfad == "/api/gemeinsam":
            return self.gemeinsam_post(koerper)
        if pfad == "/api/fernsteuerung":
            return self.fernsteuerung_post(koerper)
        if pfad == "/api/kataloge":
            return self.kataloge_post(koerper)
        if pfad == "/api/sammlungen":
            return self.sammlungen_post(koerper)
        if pfad == "/api/kataloge/erkennen":
            return self.kataloge_erkennen(koerper)
        if pfad == "/api/seiten-suche/erkennen":
            return self.seiten_suche_erkennen(koerper)
        if pfad in ("/api/trakt", "/api/trakt/app"):
            return self.trakt_post(pfad, koerper)
        if pfad in ("/api/simkl", "/api/simkl/app"):
            return self.simkl_post(pfad, koerper)
        if pfad == "/api/nuvio":
            return self.nuvio_post(koerper, kopf)
        if pfad in ("/api/anime-tracker", "/api/anime-tracker/app"):
            return self.anime_tracker_post(pfad, koerper)
        if pfad == "/api/reihen":
            return self.reihen_post(koerper)
        if pfad == "/api/poster":
            return self.poster_post(koerper)
        if pfad == "/api/mdblist":
            return self.mdblist_post(koerper)
        if pfad in ("/api/gdrive", "/api/gdrive/einstellungen", "/api/gdrive/app"):
            return self.gdrive_post(pfad, koerper)
        if pfad == "/api/appstore":
            return self.appstore_post(koerper)
        if pfad in ("/api/uniqx/generieren", "/api/uniqx/anwenden", "/api/uniqx/ki_config",
                    "/api/uniqx/ollama_installieren", "/api/uniqx/ollama_modell_holen"):
            if pfad.endswith("generieren"):
                return self.uniqx_generieren(koerper)
            if pfad.endswith("ki_config"):
                return self.uniqx_ki_config(koerper)
            if pfad.endswith("ollama_installieren"):
                return self.uniqx_ollama_installieren_post()
            if pfad.endswith("ollama_modell_holen"):
                return self.uniqx_ollama_modell_post(koerper)
            return self.uniqx_anwenden(koerper)
        if pfad == "/api/ki/diff":
            return self.ki_diff(koerper)
        if pfad == "/api/magicwx":
            return self.magicwx_post(koerper)
        if pfad == "/api/shizuku":
            return self.shizuku_post(koerper)
        if pfad == "/api/keepadb":
            return self.keepadb_post(koerper)
        if pfad == "/api/bilddatensatz":
            return self.bilddatensatz_post(koerper)
        if pfad == "/api/vorschlaege":
            return self.vorschlaege_post(koerper)
        if pfad == "/api/mcp":
            return self.mcp_post(koerper)
        if pfad == "/api/mcp/server":
            return self.mcp_server_post(koerper)
        if pfad == "/api/markenerkennung/starten":
            return self.markenerkennung_starten(koerper)
        if pfad in ("/api/komplettbackup", "/api/komplettbackup/einstellungen"):
            return self.komplettbackup_post(pfad, koerper)
        if pfad == "/api/nuvio_plugins":
            return self.nuvio_plugins_post(koerper)
        if pfad in ("/api/geraete_abgleich", "/api/geraete_abgleich/einstellungen"):
            return self.geraete_abgleich_post(pfad, koerper)
        if pfad == "/api/understand_anything":
            return self.understand_anything_post(koerper)
        if pfad == "/api/p2p/torrent":
            return self.p2p_torrent_post(koerper)
        if pfad == "/api/autostart":
            return self.autostart_speichern(koerper)
        if pfad == "/api/ember/steuerung":
            return self.ember_post(koerper)
        if pfad == "/api/emuleese":
            return self.emuleese_post(koerper)
        if pfad == "/api/aiostreams":
            return self.aiostreams_post(koerper)
        if pfad == "/api/iptvquellen":
            return self.iptvquellen_post(koerper)
        if pfad == "/api/ed2knetz":
            return self.ed2knetz_post(koerper)
        if pfad == "/api/kodiquellen":
            return self.kodiquellen_post(koerper)
        if pfad == "/api/lbry":
            return self.lbry_post(koerper)
        if pfad == "/api/ipvpn":
            return self.ipvpn_post(koerper)
        if pfad == "/api/discord":
            return self.discord_post(koerper, kopf)
        if pfad == "/api/qwen-pose":
            return self.qwen_pose_post(koerper, kopf)
        if pfad.startswith("/api/sicherheit/"):
            return self.sicherheit_post(pfad, koerper)
        if pfad == "/api/afwall" or pfad.startswith("/api/afwall/"):
            return self.afwall_post(pfad, koerper)
        if pfad.startswith("/api/kodi/"):
            return self.kodi_post(pfad, koerper)
        if pfad.startswith("/api/waechter/"):
            return self.waechter_post(pfad, koerper)
        if pfad.startswith("/api/beobachtungen/"):
            return self.beobachtungen_post(pfad, koerper)
        if pfad.startswith("/api/szene/"):
            return self.szene_post(pfad, koerper)
        if pfad.startswith("/api/musik/"):
            return self.musik_post(pfad, koerper)
        if pfad == "/api/badges":
            return self.badges_speichern(koerper)
        if pfad.startswith("/api/xdcc/"):
            return self.xdcc_post(pfad, koerper)
        if pfad.startswith("/api/youtube/"):
            return self.youtube_post(pfad, koerper)
        if pfad in ("/api/ed2k/listen", "/api/ed2k/hochladen") or pfad == "/api/ipfilter" or pfad.startswith("/api/ipfilter/"):
            return self.listen_post(pfad, koerper, werte)
        if pfad.startswith("/api/ed2k/"):
            return self.ed2k_post(pfad, koerper)
        if pfad.startswith("/api/easynews/"):
            return self.easynews_post(pfad, koerper)
        if pfad.startswith("/api/usenet-stream/"):
            return self.usenet_stream_post(pfad, koerper)
        if pfad in ("/api/hintergrund", "/api/avatar"):
            return self.hintergrund_speichern(koerper, self._bildname(pfad))
        if pfad == "/api/kameras" or pfad.startswith("/api/kameras/"):
            return self.kameras_post(pfad, koerper)
        if pfad.startswith("/api/hue/"):
            return self.hue_post(pfad, koerper)
        if pfad.startswith("/api/chat/"):
            return self.chat_post(pfad, koerper)
        if pfad.startswith("/api/cast/"):
            return self.cast_post(pfad, koerper)
        if pfad == "/api/befehl":
            try:
                return self.befehl_ausfuehren(json.loads(koerper.decode("utf-8") or "{}"))
            except (ValueError, UnicodeDecodeError) as fehler:
                return 400, "application/json", {"fehler": str(fehler)}
        if pfad == "/api/brause":
            return self.brause_post(koerper)
        if pfad == "/api/sehen":
            return self.sehen_post(koerper)
        if pfad == "/api/marken":
            return self.marken_post(koerper)
        if pfad.startswith("/api/traum/"):
            return self.traum_post(pfad, koerper)
        if pfad == "/api/portal" or pfad.startswith("/api/portal/"):
            return self.portal_post(pfad, koerper)
        if pfad == "/api/usb":
            return self.usb_post(koerper)
        if pfad == "/api/videowerkstatt":
            return self.videowerkstatt_post(koerper)
        if pfad == "/api/community-addons":
            return self.community_addons_post(koerper)
        if pfad == "/api/radio/favorit":
            return self.radio_post(pfad, koerper)
        if pfad in ("/api/baukasten", "/api/baukasten/neu"):
            return self.baukasten_post(pfad, koerper)
        if pfad in ("/api/startanimation", "/api/startanimation/weg"):
            return self.startanimation_post(pfad, koerper)
        if pfad == "/api/sprachsteuerung":
            return self.sprachsteuerung_post(koerper)
        if pfad.startswith("/api/web/"):
            return self.web_post(pfad, koerper)
        if pfad in ("/api/assistent/verknuepfungen", "/api/assistent/verknuepfen", "/api/verweise/aufraeumen"):
            return self.assistent_post(pfad, koerper)
        if pfad in ("/api/einstellungen", "/api/einstellungen/reiter", "/api/ftpserver", "/api/heimspeicher", "/api/dateisuche/abspielen") \
                or pfad.startswith(("/api/telegram/", "/api/heimspeicher/", "/api/aktualisierung/", "/api/sicherung/")):
            return self._neu_post(pfad, koerper)
        if pfad.startswith(("/api/anbieter/", "/api/vx/", "/api/debrid/", "/api/rustnzb/", "/api/dienste/")) \
                or pfad == "/api/senden":
            return self._json_post(pfad, koerper)
        return 404, "application/json", {"fehler": "nicht gefunden"}
