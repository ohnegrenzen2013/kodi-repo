"""KI-Diff-Werkzeug: Diff-Review und Merge-Konflikt-Resolver per KI.

  POST /api/ki/diff   Sendet einen git diff oder Konfliktblock an das konfigurierte KI-Modell
"""
import json as _json

from . import ki_anbieter as _ki

_PROMPTS = {
    "review": (
        "Du bist Code-Reviewer. Prüfe folgenden git diff auf Korrektheit, Sicherheit und offensichtliche Fehler. "
        "Antworte auf Deutsch, maximal 10 Punkte, jeweils eine Zeile.\n\n"
        "```diff\n{text}\n```"
    ),
    "merge": (
        "Löse die folgenden Git-Merge-Konflikte auf. "
        "Gib nur den aufgelösten Code zurück, keine Erklärung, keine Markdown-Fences.\n\n"
        "{text}"
    ),
}


class KiDiffMixin:

    def ki_diff(self, koerper):
        try:
            daten = _json.loads(koerper.decode("utf-8") or "{}")
        except (ValueError, UnicodeDecodeError):
            return 400, "application/json", {"fehler": "JSON-Fehler"}
        if not isinstance(daten, dict):
            return 400, "application/json", {"fehler": "JSON-Objekt erwartet"}

        text = str(daten.get("text", "")).strip()[:20000]
        aufgabe = str(daten.get("aufgabe", "review"))
        if not text:
            return 400, "application/json", {"fehler": "text fehlt"}
        if aufgabe not in _PROMPTS:
            aufgabe = "review"

        konfig = self.app.verwaltung.daten() if self.app.verwaltung else {}
        if not self._ki_diff_verfuegbar(konfig):
            return 503, "application/json", {"fehler": "Kein KI-Anbieter konfiguriert."}

        prompt = _PROMPTS[aufgabe].format(text=text)
        try:
            antwort = _ki.anfrage(prompt, konfig)
        except _ki.KiAnbieterFehler as e:
            return 502, "application/json", {"fehler": str(e)}

        return 200, "application/json", {"ok": True, "antwort": antwort}

    def _ki_diff_verfuegbar(self, konfig: dict) -> bool:
        modus = konfig.get("ki_modus", "cloud")
        if modus == "cloud":
            backend = konfig.get("ki_cloud_backend", "claude")
            if backend == "claude":
                return bool(konfig.get("claude_api_key"))
            return bool(konfig.get("ki_cloud_url"))
        elif modus == "lokal":
            return True
        elif modus == "remote":
            return bool(konfig.get("ki_remote_url"))
        return False
