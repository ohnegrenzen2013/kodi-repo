"""Kinderprofile auf dem Server durchsetzen (kinder.py, altersfreigabe.py, profile.py).

  POST /api/profile {aktion: eltern_pin, neu, alt?}        Eltern-PIN festlegen oder aendern (Recht "profile")
  POST /api/profile {aktion: eltern_freigabe, pin}         5 Minuten Freigabe fuer diese Sitzung (Einstellungen, Reihen,
                                                           Profil wechseln, abmelden, loeschen)
  POST /api/profile {aktion: freigabe_ende}

kind_pruefen() laeuft vor jeder Anfrage, kind_filtern() nach jeder Antwort einer Kind-Sitzung.
"""

import hashlib
import json
import time

from . import kinder, profile, youtube_reihen

_FREIGABEN_NAME = "_kind_freigaben"


class KinderMixin:

    # --- Freigabe durch die Eltern-PIN ----------------------------------------------------------
    def _freigaben(self):
        return self.__dict__.setdefault(_FREIGABEN_NAME, {})

    @staticmethod
    def _sitzung_hash(token):
        return hashlib.sha256(str(token or "").encode()).hexdigest()

    def eltern_frei(self):
        """Hat diese Sitzung gerade eine gueltige Eltern-Freigabe?"""
        token = getattr(self._anfrage_lokal(), "token", "")
        if not token:
            return False
        frei = self._freigaben()
        bis = frei.get(self._sitzung_hash(token), 0)
        if bis < time.monotonic():
            frei.pop(self._sitzung_hash(token), None)
            return False
        return True

    def eltern_freigabe(self, daten, pin):
        """Eltern-PIN pruefen (mit der Bremse der Profil-PINs) und die Freigabe merken. Wirft KeinRecht."""
        self._anmelde_bremse("eltern")
        if not profile.eltern_pin_ok(daten, pin):
            self._fehlversuch("eltern")
            raise profile.PinFalsch("Eltern-PIN stimmt nicht")
        self._fehlzaehler().pop("eltern", None)
        token = getattr(self._anfrage_lokal(), "token", "")
        if not token:
            raise profile.KeinRecht("Ohne angemeldetes Profil gibt es nichts freizugeben")
        frei = self._freigaben()
        for h in [h for h, bis in frei.items() if bis < time.monotonic()]:
            del frei[h]
        frei[self._sitzung_hash(token)] = time.monotonic() + kinder.FREIGABE_SEK
        return {"freigabe": kinder.FREIGABE_SEK}

    def eltern_freigabe_ende(self):
        self._freigaben().pop(self._sitzung_hash(getattr(self._anfrage_lokal(), "token", "")), None)

    # --- vor der Anfrage ------------------------------------------------------------------------
    def kind_pruefen(self, pfad, methode, werte, koerper=b""):
        """None = weiter, sonst die Antwort (403) fuer die Kind-Sitzung."""
        ich = self.aktuelles_profil()
        if not kinder.ist_kind(ich):
            return None
        if not kinder.pfad_erlaubt(pfad, methode):
            return 403, "application/json", {"fehler": "Für Kinderprofile gesperrt.", "kind": True}
        if methode == "POST" and pfad in kinder.MIT_FREIGABE and not self.eltern_frei():
            return 403, "application/json", {"fehler": "Dafür ist die Eltern-PIN nötig.", "eltern_pin": True}
        if pfad == "/api/youtube/abspielen":  # nur Videos aus den eigenen Reihen, nie ein beliebiges
            try:
                vid = str((json.loads(koerper.decode("utf-8") or "{}") or {}).get("id", ""))
            except (ValueError, UnicodeDecodeError, AttributeError):
                vid = ""
            daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
            if not youtube_reihen.enthaelt(daten, ich["id"], vid):
                return 403, "application/json", {"fehler": "Für Kinderprofile gesperrt.", "kind": True}
        titel = kinder.titel_aus_anfrage(pfad, werte)
        if titel and not self._kind_titel_ok(titel, kinder.grenze(ich)):
            return 403, "application/json", {"fehler": "Für dieses Alter nicht freigegeben.", "kind": True}
        return None

    def _kind_titel_ok(self, titel, grenze):
        typ, sid = titel
        frei = getattr(self.app, "altersfreigabe", None)
        if frei is None:
            return False
        if typ in ("movie", "series"):
            return frei.erlaubt(typ, sid, grenze)
        return frei.erlaubt("movie", sid, grenze) or frei.erlaubt("series", sid, grenze)  # /api/streams kennt den Typ nicht

    # --- nach der Antwort -----------------------------------------------------------------------
    def kind_filtern(self, antwort):
        ich = self.aktuelles_profil()
        if not kinder.ist_kind(ich) or not isinstance(antwort, tuple) or len(antwort) < 3:
            return antwort
        status, art, inhalt = antwort[0], antwort[1], antwort[2]
        if status != 200 or art != "application/json" or not isinstance(inhalt, (dict, list)):
            return antwort
        frei = getattr(self.app, "altersfreigabe", None)
        if frei is None:
            return 403, "application/json", {"fehler": "Altersfreigabe nicht verfügbar.", "kind": True}
        return (status, art, frei.karten_filtern(inhalt, kinder.grenze(ich))) + tuple(antwort[3:])
