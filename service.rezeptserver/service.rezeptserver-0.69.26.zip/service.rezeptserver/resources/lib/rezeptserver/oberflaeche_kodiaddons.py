"""Kodi-Addons in H0rSt (kodi_addons/): installieren, durchblaettern, abspielen, Einstellungen.

  GET  /api/kodiaddons                    installierte Addons, Repositories, Kodi-Geraete (fuer "→ Kodi")
  GET  /api/kodiaddons/suchen?repo=&q=&art=plugin   Addons eines Repositories
  GET  /api/kodiaddons/einstellungen?id=  Seiten mit Feldern und Werten
  GET  /api/kodiaddons/updates            neuere Versionen in den Repositories
  GET  /api/kodiaddons/repos?laden=1      Repo-Center: alle Repositories und Quellen mit Einstellungen und Stand
  GET  /api/kodiaddons/world              World-Repo: geprüfte Repositories, Empfehlungen, Fehlermeldungen
  POST /api/kodiaddons/world              {aktion: quelle|installieren|empfohlen, ids?} – Quelle anlegen, Repositories installieren
  GET  /api/kodiaddons/datei?pfad=        Bilder und Schriften der Addons (nur unterhalb des Kodi-Ordners)
  GET  /api/kodiaddons/skins              installierte Skins als Heim-Style: Farbschemata, Schriften, Hintergruende
  POST /api/kodiaddons/aufrufen           {url, antworten} -> Liste | Stream (mit Wiedergabe-Adressen) | Rueckfrage
  POST /api/kodiaddons/stream             {url} – direkte Adresse aus einer Plugin-Liste abspielen (Header ueber H0rSt)
  POST /api/kodiaddons/installieren       {id, repo?, erneut?} | {url} | {zip: base64, name}
  POST /api/kodiaddons/entfernen          {id}
  POST /api/kodiaddons/einstellungen      {id, werte}
  POST /api/kodiaddons/aktualisieren      {id?} – ohne id alle
  POST /api/kodiaddons/quelle             {url, name?} – Quelle wie in Kodis Dateimanager merken (addons.xml = Repository)
  POST /api/kodiaddons/quelle_lesen       {url} – ZIP-Dateien und Unterordner einer Quelle
  POST /api/kodiaddons/quelle_entfernen   {id}
  POST /api/kodiaddons/repo_einstellen    {id, werte: {aktiv, auto, name}}
  POST /api/kodiaddons/repo_aktualisieren {id, installieren?} – addons.xml frisch holen, auf Wunsch Updates daraus installieren
  POST /api/kodiaddons/repo_entfernen     {id} – Quelle vergessen bzw. repository.*-Addon entfernen
  POST /api/kodiaddons/skins_aktiv        {aktiv: id} – dieser Skin ist jetzt Heim-Style (zaehlt fuer "zuletzt genutzt")
Aufrufen und Abspielen darf jeder mit Zugang zum Reiter; Installieren, Entfernen, Einstellungen (auch lesen: Passwoerter der
Addons), Quellen und Updates brauchen das Recht
"anbieter" (oberflaeche_profile.RECHT_FUER) – Addons sind Programme mit allen Rechten des Servers.
"""

import base64
import json
import mimetypes
import os
import threading
import time
import xml.etree.ElementTree as ET
from urllib.parse import urlsplit

from . import kodi_addons, world_repo

_SCHRIFTEN = {".ttf": "font/ttf", ".otf": "font/otf", ".woff": "font/woff", ".woff2": "font/woff2"}  # Skin-Schriften
_ANLEGEN = threading.Lock()


class KodiAddonsMixin:

    def _world_quelle(self, k):
        for q in k.quellen():
            if q.get("url", "").rstrip("/") + "/" == world_repo.QUELLE:
                return q
        return k.quelle_hinzufuegen(world_repo.QUELLE, "World-Repo")

    def _kodiaddons(self):
        k = getattr(self.app, "kodi_addons", None)
        if k is None:
            with _ANLEGEN:  # zwei erste Anfragen gleichzeitig: sonst zwei Verwaltungen, und eine vergaesse die Adressen der Plugins
                k = getattr(self.app, "kodi_addons", None)
                if k is None:
                    k = self.app.kodi_addons = kodi_addons.KodiAddons(self.app.datenordner)
        return k

    def kodiaddons_lesen(self, pfad, werte):
        k = self._kodiaddons()
        try:
            if pfad == "/api/kodiaddons":
                if k.auto_faellig():
                    threading.Thread(target=self._kodi_auto_updates, args=(k,), name="kodi-auto-updates", daemon=True).start()
                return 200, "application/json", dict(k.uebersicht(), geraete=[{"id": i, "name": c.name} for i, c in self.app.dienste.items()
                                                                               if getattr(c, "typ", "") == "kodi"])
            if pfad == "/api/kodiaddons/suchen":
                return 200, "application/json", {"treffer": k.suchen(werte.get("repo") or kodi_addons.verwaltung.OFFIZIELL["id"],
                                                                     werte.get("q", ""), werte.get("art", "plugin"))}
            if pfad == "/api/kodiaddons/einstellungen":
                return 200, "application/json", k.einstellungen_lesen(werte.get("id", ""))
            if pfad == "/api/kodiaddons/updates":
                return 200, "application/json", {"updates": k.updates()}
            if pfad == "/api/kodiaddons/repos":
                return 200, "application/json", k.repo_center(laden=werte.get("laden") == "1")
            if pfad == "/api/kodiaddons/world":
                d = dict(world_repo.daten())
                d["empfohlen"] = world_repo.empfohlene()
                d["quelle_vorhanden"] = any(q.get("url", "").rstrip("/") + "/" == world_repo.QUELLE for q in k.quellen())
                return 200, "application/json", d
            if pfad == "/api/kodiaddons/skins":
                return 200, "application/json", {"skins": k.skins()}
            if pfad == "/api/kodiaddons/datei":
                datei = k.datei(werte.get("pfad", ""))
                typ = _SCHRIFTEN.get(os.path.splitext(datei or "")[1].lower()) or mimetypes.guess_type(datei or "")[0] or ""
                if not datei or not typ.startswith(("image/", "font/")):
                    return 404, "application/json", {"fehler": "nicht gefunden"}
                with open(datei, "rb") as f:
                    return 200, typ, f.read()
        except (kodi_addons.KodiFehler, OSError, ValueError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        return 404, "application/json", {"fehler": "nicht gefunden"}

    def _kodi_nutzung(self, wer, dauer, fehler):
        """Nutzung fuer Speicher & Aufraeumen (zuletzt genutzt, Aufrufe, Dauer); wer: Addon-ID oder plugin://-Adresse."""
        nutzung = getattr(self.app, "nutzung", None)
        if nutzung is None:
            return
        aid = str(wer or "")
        if aid.startswith("plugin://"):
            aid = aid[len("plugin://"):].split("/", 1)[0].split("?", 1)[0]
        if kodi_addons.verwaltung.GUELTIGE_ID.match(aid) and self._kodiaddons().info(aid):
            nutzung.kodi(aid, dauer, fehler)

    @staticmethod
    def _kodi_auto_updates(k):
        try:
            k.auto_updates()
        except Exception:  # noqa: BLE001 – im Hintergrund, darf den Reiter nie stoeren
            kodi_addons.verwaltung.log.warning("Kodi-Addons: automatische Updates", exc_info=True)

    def _kodi_stream(self, s):
        """Stream eines Plugins -> Adressen fuer Browser und App (Header ueber H0rSt)."""
        if s.get("drm"):
            s["hinweis"] = "Geschützt (DRM/Widevine): spielt nur in Kodi selbst – „→ Kodi“ schickt es an ein Kodi im Heimnetz."
            return s
        if s["art"] == "hls":
            s["wiedergabe"] = self.hls_merken(s["url"], s["header"])
        elif s["art"] == "dash":
            s["wiedergabe"] = s["url"] if not s["header"] else ""
            s["hinweis"] = "DASH spielt der H0rSt-Player der App; im Browser die Adresse in VLC, mpv oder Kodi öffnen."
        else:
            host = urlsplit(s["url"]).hostname or ""
            if s["url"].lower().startswith(("http://", "https://")):
                s["wiedergabe"] = "api/wiedergabe/" + self._wiedergabe_merken(s["url"], s["header"], [host])
            else:
                s["wiedergabe"] = ""
                s["hinweis"] = "Diese Adresse (%s) kann nur Kodi öffnen." % (s["url"].split(":", 1)[0] + ":")
        return s

    def kodiaddons_post(self, pfad, koerper):
        k = self._kodiaddons()
        try:
            daten = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(daten, dict):
                raise ValueError("JSON-Objekt erwartet")
            was = pfad[len("/api/kodiaddons/"):]
            if was == "world":
                aktion = str(daten.get("aktion") or "")
                if aktion not in ("quelle", "installieren", "empfohlen"):
                    raise ValueError("aktion: quelle, installieren oder empfohlen")
                if aktion != "quelle" and not k.ausfuehren_erlaubt():
                    return 400, "application/json", {"fehler": (
                        "Installieren ist aus. Unter Kodi-Addons einschalten – Addons laufen mit allen Rechten von H0rSt.")}
                q = self._world_quelle(k)
                if aktion == "quelle":
                    return 200, "application/json", dict(world_repo.daten(), quelle=q, empfohlen=world_repo.empfohlene())
                ids = world_repo.empfohlene() if aktion == "empfohlen" else daten.get("ids")
                if not isinstance(ids, list) or not ids:
                    raise ValueError("ids als Liste erwartet")
                ids = list(dict.fromkeys(str(x) for x in ids))[:40]
                unbekannt = [x for x in ids if not world_repo.gueltig(x)]
                if unbekannt:
                    raise ValueError("Nicht als funktionsfähig geprüft: " + ", ".join(unbekannt[:8]))
                neu, fehler = [], []
                for aid in ids:
                    try:
                        neu += k.installieren(aid, q["id"])
                    except (kodi_addons.KodiFehler, OSError, ValueError) as problem:
                        fehler.append({"id": aid, "fehler": str(problem)[:300]})
                return 200, "application/json", dict(k.uebersicht(), neu=neu, fehler=fehler, quelle=q)
            if was == "aufrufen":
                antworten = daten.get("antworten") or []
                if not isinstance(antworten, list) or len(antworten) > 30:
                    raise ValueError("antworten als Liste")
                beginn = time.monotonic()
                try:
                    e = k.aufrufen(str(daten.get("url", "")), antworten)
                except (kodi_addons.KodiFehler, ValueError):
                    self._kodi_nutzung(daten.get("url"), time.monotonic() - beginn, True)
                    raise
                if not e.get("frage"):  # Rueckfragen zaehlen erst mit der Antwort
                    # das gewaehlte Addon – und das, an das es weitergereicht hat (plugin://plugin.video.youtube/play/…)
                    self._kodi_nutzung(daten.get("url"), time.monotonic() - beginn, bool(e.get("fehler")))
                    if e["addon"]["id"] != kodi_addons.laufzeit.zerlegen(str(daten.get("url", "")))[0]:
                        self._kodi_nutzung(e["addon"]["id"], 0, bool(e.get("fehler")))
                if e.get("stream"):
                    e["stream"] = self._kodi_stream(e["stream"])
                return 200, "application/json", e
            if was == "stream":
                return 200, "application/json", {"stream": self._kodi_stream(k.direkter_stream(daten.get("url")))}
            if was == "skins_aktiv":  # dieser Skin ist jetzt Heim-Style: zaehlt fuer "zuletzt genutzt"
                self._kodi_nutzung(daten.get("aktiv"), 0, False)
                return 200, "application/json", {"ok": True}
            if was == "ausfuehren":
                k.ausfuehren_setzen(daten.get("an") is True)
                return 200, "application/json", k.uebersicht()
            if was in ("installieren", "aktualisieren") or (was == "repo_aktualisieren" and daten.get("installieren")):
                if not k.ausfuehren_erlaubt():
                    return 400, "application/json", {"fehler": (
                        "Installieren aus ZIP, Adresse und Repository ist aus. "
                        "Unter Kodi-Addons einschalten – Addons laufen mit allen Rechten von H0rSt, das ist keine Sandbox.")}
            if was == "installieren":
                if daten.get("zip"):
                    neu = k.installieren_zip(base64.b64decode(str(daten["zip"]).split(",")[-1]))
                elif daten.get("url"):
                    neu = k.installieren_url(str(daten["url"]))
                else:
                    neu = k.installieren(str(daten.get("id", "")), daten.get("repo") or None, erneut=daten.get("erneut") is True)
                return 200, "application/json", dict(k.uebersicht(), neu=neu)
            if was == "entfernen":
                k.entfernen(str(daten.get("id", "")))
                return 200, "application/json", k.uebersicht()
            if was == "einstellungen":
                return 200, "application/json", k.einstellungen_setzen(str(daten.get("id", "")), daten.get("werte"))
            if was == "quelle":
                return 200, "application/json", dict(k.uebersicht(), quelle=k.quelle_hinzufuegen(daten.get("url"), daten.get("name")))
            if was == "quelle_lesen":
                return 200, "application/json", k.quelle_inhalt(daten.get("url"))
            if was == "quelle_entfernen":
                k.quelle_entfernen(str(daten.get("id", "")))
                return 200, "application/json", k.uebersicht()
            if was == "repo_einstellen":
                return 200, "application/json", k.repo_einstellen(str(daten.get("id", "")), daten.get("werte"))
            if was == "repo_entfernen":
                return 200, "application/json", dict(k.repo_entfernen(str(daten.get("id", ""))), uebersicht=k.uebersicht())
            if was == "repo_aktualisieren":
                rid = str(daten.get("id", ""))
                k.katalog(rid, frisch=True)
                neu = []
                if daten.get("installieren"):
                    for u in k.updates(rid):
                        neu += k.installieren(u["id"], rid)
                return 200, "application/json", dict(k.repo_center(), neu=neu, uebersicht=k.uebersicht())
            if was == "aktualisieren":
                ids = [str(daten["id"])] if daten.get("id") else [u["id"] for u in k.updates()]
                neu = []
                for aid in ids:
                    neu += k.installieren(aid)
                return 200, "application/json", dict(k.uebersicht(), neu=neu)
        except (kodi_addons.KodiFehler, OSError, ValueError, UnicodeDecodeError, ET.ParseError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        return 404, "application/json", {"fehler": "nicht gefunden"}
