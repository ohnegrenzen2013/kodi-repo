"""Kodi-Quellen: Repository, EPG, Senderliste und Builds.

  GET  /api/kodiquellen               Quellen und Arten
  POST /api/kodiquellen               {aktion: pruefen | uebernehmen, art?, id?}
"""

import json

from . import kodi_quellen, livetv


class KodiQuellenMixin:

    def kodiquellen_lesen(self):
        return 200, "application/json", kodi_quellen.zustand()

    def _kodi_live_liste(self):
        q = kodi_quellen.live_tv_quellen()
        alt = dict(self.app.livetv)
        listen = [l for l in (alt.get("listen") or []) if l.get("url") != q["liste"]["url"]]
        if any(l.get("name") == q["liste"]["name"] for l in listen):
            raise livetv.LiveTvFehler("Eine Liste mit diesem Namen gibt es schon")
        neu = dict(alt, listen=listen + [q["liste"]])
        if not str(neu.get("epg_quelle") or "").strip():
            neu["epg_quelle"] = q["epg"]
        self.app.setze_livetv(neu)
        return q

    def kodiquellen_post(self, koerper):
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(wunsch, dict):
                raise ValueError("JSON-Objekt erwartet")
            aktion = wunsch.get("aktion")
            if aktion == "pruefen":
                return 200, "application/json", kodi_quellen.zustand(pruefen_lassen=True,
                                                                      art=wunsch.get("art") or None)
            if aktion == "uebernehmen":
                q = self._kodi_live_liste()
                return 200, "application/json", {"ok": True, "liste": q["liste"], "epg": q["epg"],
                                                 "meldung": "Michaz-Senderliste und EPG sind in Live-TV eingetragen."}
            return 400, "application/json", {"fehler": "aktion: pruefen oder uebernehmen"}
        except (ValueError, UnicodeDecodeError, livetv.LiveTvFehler) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
