"""Komplett-Backup (komplettbackup.py): alle Ordner und Daten im Datenordner, einzeln waehlbar, nach
lokal (als ZIP je Teil) und/oder Google Drive. Alles braucht das Recht "einstellungen".

  GET  /api/komplettbackup                Stand {teile: [{id,name,groesse,dateien}], teile_gewaehlt,
                                           lokal_an, lokal_pfad, lokal_frei, drive_an, drive_verbunden,
                                           intervall_stunden, zuletzt, fehler, auftrag,
                                           wiederherstellbar: [{id,name,groesse,zeit}]}
  POST /api/komplettbackup                {aktion: "jetzt"} | {aktion: "wiederherstellen", teil: id}
  POST /api/komplettbackup/einstellungen  {teile: [id...], lokal_an, lokal_pfad, drive_an, intervall_stunden}
"""

from . import dateien
from .komplettbackup import KomplettBackupFehler, liste
from .oberflaeche_grund import json


class KomplettBackupMixin:

    def komplettbackup_lesen(self):
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        stand = self.app.komplettbackup.stand(daten)
        stand["teile_gewaehlt"] = stand.pop("teile")
        stand["teile"] = liste(self.app.datenordner)
        stand["lokal_frei"] = dateien.frei(stand["lokal_pfad"] or self.app.datenordner)
        stand["drive_verbunden"] = self.app.gdrive.stand(daten)["verbunden"]
        stand["wiederherstellbar"] = self.app.komplettbackup.wiederherstellbar(daten)
        return 200, "application/json", stand

    def komplettbackup_post(self, pfad, koerper):
        if not self.app.verwaltung:
            return 503, "application/json", {"fehler": "Nutzerdaten nicht verfügbar"}
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(wunsch, dict):
                raise ValueError("JSON-Objekt erwartet")
            if pfad == "/api/komplettbackup/einstellungen":
                return 200, "application/json", self.app.verwaltung.bearbeiten(
                    lambda d: self.app.komplettbackup.einstellungen_setzen(d, wunsch))
            aktion = wunsch.get("aktion")
            if aktion == "jetzt":
                return 200, "application/json", self.app.komplettbackup.jetzt_starten()
            if aktion == "wiederherstellen":
                return 200, "application/json", self.app.komplettbackup.jetzt_wiederherstellen(str(wunsch.get("teil") or ""))
            raise ValueError("Unbekannte Aktion")
        except (KomplettBackupFehler, ValueError, UnicodeDecodeError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
