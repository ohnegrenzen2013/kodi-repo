"""LBRY/Odysee: Status, Suche und Wiedergabe-Adresse.

  GET  /api/lbry                      Einstellungen und Verbindungsstand
  POST /api/lbry                      {aktion: pruefen | suche | aufloesen}
"""

import json

from . import lbry


class LbryMixin:

    def lbry_lesen(self):
        werte = self._einstellungen_lesen().get("werte") or {}
        return 200, "application/json", lbry.zustand(werte)

    def lbry_post(self, koerper):
        werte = self._einstellungen_lesen().get("werte") or {}
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(wunsch, dict):
                raise ValueError("JSON-Objekt erwartet")
            aktion = wunsch.get("aktion")
            if aktion == "pruefen":
                return 200, "application/json", lbry.zustand(werte, pruefen=True)
            if aktion == "suche":
                return 200, "application/json", lbry.suchen(wunsch.get("text"), werte)
            if aktion == "aufloesen":
                return 200, "application/json", lbry.aufloesen(wunsch.get("name"), wunsch.get("claim_id"), werte)
            return 400, "application/json", {"fehler": "aktion: pruefen, suche oder aufloesen"}
        except (ValueError, UnicodeDecodeError, lbry.LbryFehler) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
