"""Ab 18 - Lesezeichen auf dem Server (ab18_lesezeichen.py).

  GET  /api/ab18/lesezeichen                {an, eltern_pin, entsperrt[, liste]}   (Header X-Lz = Sitzungsschluessel)
  POST /api/ab18/lesezeichen/einstellung    {an, volljaehrig?, pin?}   einschalten: 18+-Bestaetigung und Eltern-PIN; ausschalten frei
  POST /api/ab18/lesezeichen/entsperren     {pin}  Eltern-/Erwachsenen-PIN -> {schluessel}, 10 Minuten
  POST /api/ab18/lesezeichen/sperren        {}
  POST /api/ab18/lesezeichen/hinzu|umbenennen|weg   nur mit Sitzungsschluessel

Unter /api/ab18/ gilt zusaetzlich: Kinderprofile sind fuer jeden /api/-Pfad ausserhalb der Kinder-Liste gesperrt (kinder.py),
andere Profile brauchen das Recht "ab18". Hier prueft der Server ein drittes Mal, damit nie ein Eintrag das Kind erreicht."""

import hashlib
import json
import secrets
import time

from . import ab18_lesezeichen as lz, kinder, profile

SITZUNG_SEK = 600


class _LesezeichenMixin:
    def _lz_sitzungen(self):
        return self.__dict__.setdefault("_lz_sitzungen_daten", {})

    @staticmethod
    def _lz_hash(schluessel):
        return hashlib.sha256(str(schluessel or "").encode()).hexdigest()

    def _lz_offen(self, schluessel):
        if not schluessel:
            return False
        s = self._lz_sitzungen()
        bis = s.get(self._lz_hash(schluessel), 0)
        if bis < time.monotonic():
            s.pop(self._lz_hash(schluessel), None)
            return False
        return True

    def _lz_daten(self):
        return self.app.verwaltung.daten() if self.app.verwaltung else {}

    def _lz_kind_sperre(self):
        """Antwort (403) fuer Kinder, sonst None."""
        if kinder.ist_kind(self.aktuelles_profil()):
            return 403, "application/json", {"fehler": "Für Kinderprofile gesperrt.", "kind": True}
        return None

    def lesezeichen_lesen(self, kopf):
        sperre = self._lz_kind_sperre()
        if sperre:
            return sperre
        daten = self._lz_daten()
        b = lz.lesen(daten)
        antwort = {"an": b["an"], "eltern_pin": bool(((daten.get(profile.SCHLUESSEL) or {}).get("eltern_pin"))), "entsperrt": False}
        if b["an"] and self._lz_offen((kopf or {}).get("X-Lz")):
            antwort.update(entsperrt=True, liste=b["liste"])
        return 200, "application/json", antwort

    def _lz_pin(self, daten, pin):
        self._anmelde_bremse("eltern")
        if not profile.eltern_pin_ok(daten, pin):
            self._fehlversuch("eltern")
            raise profile.PinFalsch("PIN stimmt nicht – oder es ist noch keine Eltern-PIN festgelegt (Einstellungen → Profile)")
        self._fehlzaehler().pop("eltern", None)

    def lesezeichen_post(self, pfad, koerper, kopf):
        sperre = self._lz_kind_sperre()
        if sperre:
            return sperre
        try:
            w = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(w, dict):
                raise ValueError("JSON-Objekt erwartet")
            if not self.app.verwaltung:
                raise ValueError("Nutzerdaten nicht verfügbar")
            was = pfad[len("/api/ab18/lesezeichen/"):]
            daten = self._lz_daten()
            if was == "einstellung":
                if w.get("an") is True:
                    if w.get("volljaehrig") is not True:
                        raise ValueError("Nur mit Bestätigung, dass du mindestens 18 Jahre alt bist")
                    self._lz_pin(daten, w.get("pin"))
                else:
                    self._lz_sitzungen().clear()
                an = self.app.verwaltung.aendern(lambda d: lz.einstellen(d, w.get("an") is True))
                return 200, "application/json", {"an": an}
            if was == "entsperren":
                if not lz.lesen(daten)["an"]:
                    raise ValueError("Der Bereich ist ausgeschaltet")
                self._lz_pin(daten, w.get("pin"))
                schluessel = secrets.token_urlsafe(24)
                s = self._lz_sitzungen()
                jetzt = time.monotonic()
                for h in [h for h, bis in s.items() if bis < jetzt]:
                    del s[h]
                s[self._lz_hash(schluessel)] = jetzt + SITZUNG_SEK
                return 200, "application/json", {"schluessel": schluessel, "sekunden": SITZUNG_SEK}
            if was == "sperren":
                self._lz_sitzungen().pop(self._lz_hash((kopf or {}).get("X-Lz")), None)
                return 200, "application/json", {"entsperrt": False}
            if was in ("hinzu", "umbenennen", "weg"):
                if not lz.lesen(daten)["an"] or not self._lz_offen((kopf or {}).get("X-Lz")):
                    return 403, "application/json", {"fehler": "PIN nötig", "gesperrt": True}
                if was == "hinzu":
                    e = self.app.verwaltung.aendern(lambda d: lz.hinzu(d, w.get("name"), w.get("url")))
                elif was == "umbenennen":
                    e = self.app.verwaltung.aendern(lambda d: lz.umbenennen(d, w.get("id"), w.get("name")))
                else:
                    self.app.verwaltung.aendern(lambda d: lz.weg(d, w.get("id")))
                    e = None
                return 200, "application/json", {"eintrag": e, "liste": lz.lesen(self._lz_daten())["liste"]}
            return 404, "application/json", {"fehler": "nicht gefunden"}
        except profile.KeinRecht as fehler:
            return 403, "application/json", {"fehler": str(fehler)}
        except profile.PinFalsch as fehler:
            return 403, "application/json", {"fehler": str(fehler)}
        except (ValueError, UnicodeDecodeError) as fehler:  # LesezeichenFehler ist ein ValueError
            return 400, "application/json", {"fehler": str(fehler)}
