"""Link-Reiniger (FixupXer): Tracking entfernen, Frontends und Private Link Guard.

  GET  /api/linkreiniger   Einstellungen, Frontend-Auswahl, Verlauf
  POST /api/linkreiniger   {aktion: reinigen, url} | {aktion: einstellen, werte} |
                           {aktion: verlauf_loeschen}

Alles laeuft lokal; H0rSt ruft fuer das Reinigen kein Netz auf. Der Verlauf ist
optional und speichert nie ein Original mit erkannten privaten Werten.
"""

import json
import time

from . import link_reiniger


class LinkReinigerMixin:

    def _reiniger_daten(self):
        return self.app.verwaltung.daten() if self.app.verwaltung else {}

    def _reiniger_antwort(self, daten=None):
        daten = daten if daten is not None else self._reiniger_daten()
        e = link_reiniger.einstellungen(daten)
        return {"einstellungen": e, "frontends": [
            {"key": k, "name": v[0], "standard": v[1], "auswahl": v[2]} for k, v in link_reiniger.FRONTENDS.items()],
            "max_verlauf": link_reiniger.MAX_VERLAUF, "max_regeln": link_reiniger.MAX_REGELN}

    def linkreiniger_lesen(self):
        return 200, "application/json", self._reiniger_antwort()

    def linkreiniger_post(self, koerper):
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(wunsch, dict):
                raise ValueError("JSON-Objekt erwartet")
            if not self.app.verwaltung:
                raise ValueError("Nutzerdaten nicht verfügbar")
            aktion = str(wunsch.get("aktion") or "")
            daten = self._reiniger_daten()
            if aktion == "reinigen":
                ergebnis = link_reiniger.reinigen(wunsch.get("url", ""), link_reiniger.einstellungen(daten))
                if ergebnis.get("sauber") and not ergebnis.get("warnungen") and not ergebnis.get("warnungen_original"):
                    def merken(d):
                        link_reiniger.verlauf_merken(d, ergebnis, time.time())
                    self.app.verwaltung.bearbeiten(merken)
                return 200, "application/json", ergebnis
            if aktion in ("einstellen", "verlauf_loeschen"):
                neu = self.app.verwaltung.bearbeiten(lambda d: link_reiniger.aendern(d, wunsch))
                return 200, "application/json", dict(self._reiniger_antwort(dict(daten, **{link_reiniger.SCHLUESSEL: neu})), meldung="Gespeichert.")
            return 400, "application/json", {"fehler": "Unbekannte Aktion"}
        except (ValueError, UnicodeDecodeError, link_reiniger.ReinigerFehler) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
