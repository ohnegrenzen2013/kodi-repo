"""Listen fuer P2P: server.met und nodes.dat (ed2k_listen.py) und der IP-Filter (ipfilter.py, Bereich Sicherheit).

  GET  /api/ed2k/listen                  Stand beider Listen (Anzahl, Quelle, Stand, eigene, gesperrt, Quellen)
  GET  /api/ed2k/server.met              Serverliste fuer eMule/Ember ("Aktualisieren von URL")
  GET  /api/ed2k/nodes.dat               Kad-Knoten fuer eMule/Ember
  POST /api/ed2k/listen                  {art: server|kad, aktion: aktualisieren|eigene_leeren} oder
                                         {art, quelle_dazu: url | quelle_weg: url | standard: bool}
  POST /api/ed2k/hochladen?art=…&dazu=1  server.met/nodes.dat als Rohdaten (ersetzt die eigene Liste, mit dazu=1 ergaenzt)
  GET  /api/ipfilter                     Stand, Auswahl, Katalog
  GET  /api/ipfilter/ipfilter.dat        alle gewaehlten Listen zusammengefuehrt (eMule-Format)
  POST /api/ipfilter                     {listen: [ids]} | {eigene_dazu: {name, url}} | {eigene_weg: url} | {eingehend: bool}
  POST /api/ipfilter/aktualisieren       alle gewaehlten Listen neu laden (im Hintergrund)
  POST /api/ipfilter/hochladen           eigene Liste als Rohdaten (.dat, .p2p, CIDR, auch .gz/.zip)
  POST /api/ipfilter/hochgeladen_weg     die hochgeladene Liste entfernen
"""

import json

from . import ed2k_listen, ipfilter


class ListenMixin:

    def _p2p_listen(self):
        return {"server": self.app.ed2k_suche.serverliste, "kad": self.app.kadliste}

    def listen_lesen(self, pfad):
        listen = self._p2p_listen()
        if pfad == "/api/ed2k/listen":
            return 200, "application/json", {art: l.stand() for art, l in listen.items()}
        if pfad in ("/api/ed2k/server.met", "/api/ed2k/nodes.dat"):
            liste = listen["server" if pfad.endswith(".met") else "kad"]
            eintraege = liste.eintraege()
            if not eintraege:
                return 404, "application/json", {"fehler": "Liste ist leer"}
            return 200, "application/octet-stream", liste.bauen(eintraege)
        if pfad == "/api/ipfilter/ipfilter.dat":
            return 200, "application/octet-stream", ipfilter.AKTIV.als_dat()
        return 200, "application/json", self.app.ipfilter.stand()

    def listen_post(self, pfad, koerper, werte):
        try:
            if pfad == "/api/ed2k/hochladen":
                liste = self._p2p_listen().get(werte.get("art", ""))
                if liste is None:
                    raise ed2k_listen.ListenFehler("art: server oder kad")
                return 200, "application/json", liste.hochladen(koerper, ersetzen=werte.get("dazu") != "1")
            if pfad == "/api/ipfilter/hochladen":
                return 200, "application/json", self.app.ipfilter.hochladen(koerper)
            if pfad == "/api/ipfilter/hochgeladen_weg":
                return 200, "application/json", self.app.ipfilter.hochgeladen_entfernen()
            if pfad == "/api/ipfilter/aktualisieren":
                self.app.ipfilter.im_hintergrund(alle=True)
                return 200, "application/json", self.app.ipfilter.stand()
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(wunsch, dict):
                raise ValueError("JSON-Objekt erwartet")
            if not self.app.verwaltung:
                raise ValueError("Nutzerdaten nicht verfügbar")
            if pfad == "/api/ipfilter":
                e = self.app.verwaltung.bearbeiten(lambda d: self.app.ipfilter.aendern(d, wunsch))
                self.app.ipfilter.anwenden(e, warten=False)  # neue Listen laden im Hintergrund
                return 200, "application/json", self.app.ipfilter.stand()
            # /api/ed2k/listen
            listen = self._p2p_listen()
            liste = listen.get(wunsch.get("art"))
            if liste is None:
                raise ed2k_listen.ListenFehler("art: server oder kad")
            if wunsch.get("aktion") == "aktualisieren":
                liste.aktualisieren()
            elif wunsch.get("aktion") == "eigene_leeren":
                liste.eigene_leeren()
            else:
                e = self.app.verwaltung.bearbeiten(lambda d: ed2k_listen.aendern(d, wunsch))
                ed2k_listen.anwenden(listen, e)
            return 200, "application/json", {art: l.stand() for art, l in listen.items()}
        except (ValueError, UnicodeDecodeError, OSError) as fehler:  # ListenFehler/FilterFehler sind ValueError
            return 400, "application/json", {"fehler": str(fehler)}
