"""MagicWX: Parameterblock fuer die App erzeugen und aus der Zwischenablage einlesen.

  GET  /api/magicwx          {name, repo, stand, paket, server, modelle, …, block, aktiv}
  POST /api/magicwx          {text} -> liest einen MagicWX-Parameterblock, speichert die bekannten
                             Werte als Einstellungen und liefert den neuen Stand zurueck.
"""

import json

from . import magicwx


class MagicWxMixin:

    def magicwx_lesen(self):
        daten = self._einstellungen_lesen()
        return 200, "application/json", magicwx.zustand(daten.get("werte") or {})

    def magicwx_post(self, koerper):
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
        except (ValueError, UnicodeDecodeError):
            return 400, "application/json", {"fehler": "JSON-Fehler"}
        if not isinstance(wunsch, dict):
            return 400, "application/json", {"fehler": "JSON-Objekt erwartet"}
        werte = magicwx.lesen(wunsch.get("text"))
        if not werte:
            return 400, "application/json", {"fehler": "Kein MagicWX-Parameterblock erkannt (Zeilen wie steps=20, size=512x512)."}
        status, typ, antwort = self._neu_post("/api/einstellungen", json.dumps(werte).encode("utf-8"))
        if status != 200:
            return status, typ, antwort
        neuer_stand = magicwx.zustand((antwort or {}).get("werte") or {})
        neuer_stand["uebernommen"] = sorted(werte)
        return 200, "application/json", neuer_stand
