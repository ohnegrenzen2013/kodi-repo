"""Markenerkennung: Status und das Anstossen einer Analyse fuer den Download-Opt-in (Stremio/mHub-
Addons, Debrid, Usenet-Streaming - Quellen ohne eigene Bytes, siehe markenerkennung_lauf.py). Der
automatische XDCC-Pfad braucht keine eigene Route (laeuft ganz im Hintergrund, siehe stremio_kern.py).

  GET  /api/markenerkennung            Zustand (laufende/letzte Auftraege, beide Schalter)
  POST /api/markenerkennung/starten     {ref, url} - url ist genau der "url"-Wert eines Streams aus der
                                        normalen Stream-Liste (eigener /debrid/-/usenet/-Pfad oder eine
                                        externe Addon-Adresse) - nie eine rohe Client-Eingabe.
"""

import json


class MarkenErkennungMixin:

    def _markenerkennung_zustand(self, daten):
        zustand = self.app.markenerkennung.zustand()
        zustand["erlaubt"] = self.app.markenerkennung.erlaubt(daten)
        zustand["download_erlaubt"] = self.app.markenerkennung.erlaubt_download(daten)
        return zustand

    def markenerkennung_lesen(self):
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        return 200, "application/json", self._markenerkennung_zustand(daten)

    def markenerkennung_starten(self, koerper):
        if not self.app.verwaltung:
            return 503, "application/json", {"fehler": "Nutzerdaten nicht verfügbar"}
        daten = self.app.verwaltung.daten()
        if not self.app.markenerkennung.erlaubt_download(daten):
            return 403, "application/json", {"fehler": "Download für die Markenerkennung ist ausgeschaltet"}
        try:
            w = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(w, dict):
                raise ValueError("JSON-Objekt erwartet")
            ziel = self.app.markenerkennung_ziel(w.get("url"))
            if not ziel:
                raise ValueError("Adresse nicht aufloesbar")
            max_bytes = int(daten.get("markenerkennung_download_mb") or 500) * 1024 * 1024
            auftrag = self.app.markenerkennung.starten(w.get("ref"), ziel=ziel, max_bytes=max_bytes)
            return 200, "application/json", auftrag
        except (ValueError, UnicodeDecodeError) as fehler:  # MarkenErkennungFehler/MarkenFehler sind ValueError
            return 400, "application/json", {"fehler": str(fehler)}
