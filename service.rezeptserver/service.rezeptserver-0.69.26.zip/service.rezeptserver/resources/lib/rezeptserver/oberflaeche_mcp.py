"""MCP-Server-Verbindung (Phase 2, Schritt 1): Adresse eintragen, Verbindung prüfen (initialize +
tools/list über mcp_client.py), Werkzeugliste anzeigen - noch KEIN Aufruf eines Werkzeugs durch eine KI.

  GET  /api/mcp   gespeicherte Konfiguration (Schlüssel nicht im Klartext, nur ob gesetzt)
  POST /api/mcp   {aktion: speichern|pruefen, ...}
"""

import json

from . import mcp_client

_ERLAUBT = {"mcp_server_url", "mcp_server_name", "mcp_server_key", "mcp_server_heimnetz_erlaubt"}


class McpMixin:

    def _mcp_zustand(self, daten):
        return {
            "url": daten.get("mcp_server_url", ""),
            "name": daten.get("mcp_server_name", ""),
            "key_gesetzt": bool(daten.get("mcp_server_key")),
            "heimnetz_erlaubt": bool(daten.get("mcp_server_heimnetz_erlaubt")),
        }

    def mcp_lesen(self):
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        return 200, "application/json", self._mcp_zustand(daten)

    def mcp_post(self, koerper):
        if not self.app.verwaltung:
            return 503, "application/json", {"fehler": "Nutzerdaten nicht verfügbar"}
        try:
            w = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(w, dict):
                raise ValueError("JSON-Objekt erwartet")
            a = w.get("aktion")
            if a == "speichern":
                unbekannt = set(w) - _ERLAUBT - {"aktion"}
                if unbekannt:
                    raise ValueError("Unbekannte Felder: %s" % ", ".join(sorted(unbekannt)))

                def tun(d):
                    if "mcp_server_url" in w:
                        d["mcp_server_url"] = str(w["mcp_server_url"]).strip()
                    if "mcp_server_name" in w:
                        d["mcp_server_name"] = str(w["mcp_server_name"]).strip()
                    if w.get("mcp_server_key"):  # leer gelassen = vorhandenen Schlüssel behalten
                        d["mcp_server_key"] = str(w["mcp_server_key"]).strip()
                    if "mcp_server_heimnetz_erlaubt" in w:
                        d["mcp_server_heimnetz_erlaubt"] = w["mcp_server_heimnetz_erlaubt"] is True

                self.app.verwaltung.bearbeiten(tun)
                return 200, "application/json", self._mcp_zustand(self.app.verwaltung.daten())
            elif a == "pruefen":
                daten = self.app.verwaltung.daten()
                try:
                    e = mcp_client.verbinden(daten)
                    meldung = "Verbunden: %s %s" % (e["server_name"], e["server_version"]) \
                        if e["server_name"] else "Verbunden."
                    return 200, "application/json", {"ok": True, "meldung": meldung, "werkzeuge": e["werkzeuge"]}
                except mcp_client.McpFehler as fehler:
                    return 200, "application/json", {"ok": False, "meldung": str(fehler), "werkzeuge": []}
            else:
                raise ValueError("Unbekannte Aktion")
        except (ValueError, UnicodeDecodeError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
