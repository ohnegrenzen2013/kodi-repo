"""H0rSt als MCP-Server (Phase 3): Admin-Konfiguration fuer die eingehende Rolle - getrennt von
oberflaeche_mcp.py (dort geht es um die ausgehende Verbindung zu einem FREMDEN MCP-Server).

  GET  /api/mcp/server   Status (Schalter, ob ein Schluessel gesetzt ist - nie der Schluessel selbst,
                          fester Pfad, Werkzeugliste zur Anzeige)
  POST /api/mcp/server   {aktion: schalten|schluessel_neu, ...}
"""

import json

from . import mcp_server

_ERLAUBT = {"an"}


class McpServerMixin:

    def _mcp_server_zustand(self, daten):
        return {
            "eingeschaltet": mcp_server.eingeschaltet(daten),
            "schluessel_gesetzt": bool(daten.get("mcp_eingehend_schluessel")),
            "pfad": mcp_server.PFAD,
            "werkzeuge": [{"name": w["name"], "beschreibung": w["beschreibung"]} for w in mcp_server.WERKZEUGE],
        }

    def mcp_server_lesen(self):
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        return 200, "application/json", self._mcp_server_zustand(daten)

    def mcp_server_post(self, koerper):
        if not self.app.verwaltung:
            return 503, "application/json", {"fehler": "Nutzerdaten nicht verfügbar"}
        try:
            w = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(w, dict):
                raise ValueError("JSON-Objekt erwartet")
            a = w.get("aktion")
            if a == "schalten":
                unbekannt = set(w) - _ERLAUBT - {"aktion"}
                if unbekannt:
                    raise ValueError("Unbekannte Felder: %s" % ", ".join(sorted(unbekannt)))

                def tun(d):
                    d["mcp_eingehend_erlaubt"] = w.get("an") is True

                self.app.verwaltung.bearbeiten(tun)
                return 200, "application/json", self._mcp_server_zustand(self.app.verwaltung.daten())
            elif a == "schluessel_neu":
                neu = mcp_server.schluessel_neu()

                def tun(d):
                    d["mcp_eingehend_schluessel"] = neu

                self.app.verwaltung.bearbeiten(tun)
                ergebnis = self._mcp_server_zustand(self.app.verwaltung.daten())
                ergebnis["schluessel"] = neu  # einzige Stelle, an der der Schluessel im Klartext erscheint
                return 200, "application/json", ergebnis
            else:
                raise ValueError("Unbekannte Aktion")
        except (ValueError, UnicodeDecodeError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
