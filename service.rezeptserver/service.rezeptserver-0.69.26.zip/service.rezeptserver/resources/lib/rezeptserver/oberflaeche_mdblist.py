"""MDBList: eigene Listen lesen und Titel hinzufuegen (mdblist_listen.py).

  POST /api/mdblist  {aktion: listen}                                       -> {listen: [{id, name, anzahl, art}]}
                     {aktion: zur_liste, liste, titel: [{typ, id}]}         -> {ergebnis: [{id, typ, ergebnis, ok}]}
Der API-Schluessel kommt aus der vorhandenen MDBList-Einstellung (kataloge.mdblist_key).
"""

import json

from . import kataloge, mdblist_listen


class MdblistMixin:

    def mdblist_post(self, koerper):
        if not self.app.verwaltung:
            return 503, "application/json", {"fehler": "Nutzerdaten nicht verfügbar"}
        try:
            w = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(w, dict):
                raise ValueError("JSON-Objekt erwartet")
            key = kataloge._mdblist_key(self.app.verwaltung.daten())
            a = w.get("aktion")
            if a == "listen":
                return 200, "application/json", {"listen": mdblist_listen.eigene_listen(self.app.mdblist_abrufer, key)}
            if a == "zur_liste":
                return 200, "application/json", {"ergebnis": mdblist_listen.zur_liste(
                    self.app.mdblist_abrufer, key, w.get("liste"), w.get("titel"))}
            raise ValueError("aktion: listen oder zur_liste")
        except (ValueError, UnicodeDecodeError) as fehler:  # MdblistFehler ist ein ValueError
            return 400, "application/json", {"fehler": str(fehler)}
