"""Menue (Rezepte-StammBaum): alle Module, Reiter, eigenen Tabs, Rezepte und der Tresor.

  GET /api/menue   Baum fuer Einstellungen -> Menue (Rezepte-StammBaum)

Geaendert wird ueber /api/einstellungen (navigation, eigene_tabs) und /api/tresor;
so gelten dieselben Rechte, Pruefungen und Rueckfallregeln wie ueberall.
"""

from . import menue


class MenueMixin:

    def menue_lesen(self):
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        werte = self._einstellungen_lesen()["werte"] if hasattr(self, "_einstellungen_lesen") else None
        module = self.app.verwaltung.module if self.app.verwaltung else ()
        return 200, "application/json", menue.baum(daten, getattr(self.app, "datenordner", "") or "",
                                                   module, werte)
