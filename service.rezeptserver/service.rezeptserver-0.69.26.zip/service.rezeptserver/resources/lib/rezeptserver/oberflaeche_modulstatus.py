"""Modulstatus: Register, Navigation und strukturelle Gesundheit der Module.

  GET /api/module/status   Module mit Welt, Reitern, angedockt/abgedockt und Befunden des Registers
"""

from . import modul_status


class ModulStatusMixin:

    def modul_status_lesen(self):
        """Auch ohne Nutzerdaten lesbar: dann gilt die Standardnavigation."""
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        werte = self._einstellungen_lesen()["werte"] if hasattr(self, "_einstellungen_lesen") else None
        return 200, "application/json", modul_status.bericht(daten, werte)
