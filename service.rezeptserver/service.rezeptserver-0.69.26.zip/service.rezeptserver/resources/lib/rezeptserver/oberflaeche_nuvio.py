"""Nuvio Mobile (nuvio_mobil.py): Stand der Verdrahtung und Modulschalter.

  GET  /api/nuvio   Stand: an, addon, api, funktionen, einstellungen
  POST /api/nuvio   {aktion: einstellungen, nuvio_an, nuvio_adresse}
"""

import json

from . import nuvio_mobil


class NuvioMixin:
    def nuvio_lesen(self, kopf):
        werte = self._einstellungen_lesen().get("werte") or {}
        basis = ""
        eigene = getattr(self.app, "eigene_basis", None)
        if callable(eigene):
            basis = eigene(kopf or {}) or ""
        return 200, "application/json", nuvio_mobil.stand(werte, basis)

    def nuvio_post(self, koerper, kopf):
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
        except (ValueError, UnicodeDecodeError):
            return 400, "application/json", {"fehler": "JSON-Fehler"}
        if not isinstance(wunsch, dict):
            return 400, "application/json", {"fehler": "JSON-Objekt erwartet"}
        aktion = str(wunsch.get("aktion") or "einstellungen")
        if aktion != "einstellungen":
            return 400, "application/json", {"fehler": "aktion: einstellungen"}
        try:
            werte = nuvio_mobil.einstellungen_pruefen(self._einstellungen_lesen().get("werte") or {}, wunsch)
        except ValueError as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        status, _typ, stand = self._neu_post("/api/einstellungen", json.dumps(werte).encode("utf-8"))
        if status != 200:
            return status, "application/json", stand
        return self.nuvio_lesen(kopf or {})
