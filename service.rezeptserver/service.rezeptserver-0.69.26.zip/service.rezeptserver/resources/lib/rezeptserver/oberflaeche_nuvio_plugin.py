"""Nuvio-kompatible JS-Plugins mit Fetch-Bridge (nuvio_plugin.py, NuvioMobile-Plan NV5-To-Do) - alles
braucht das Recht "einstellungen". ⚠ Alpha/experimentell, jedes Plugin kann im Namen dieses Servers
beliebige oeffentliche Adressen aufrufen - siehe nuvio_plugin.py-Modulkopf.

  GET  /api/nuvio_plugins   Stand {an, plugins: [{id,name,aktiv}], js_sandbox_verfuegbar, tmdb_konfiguriert}
  POST /api/nuvio_plugins   {an: bool} | {plugin_dazu: {id?,name,js,aktiv?}} | {plugin_weg: id}
"""

import json

from . import js_sandbox, nuvio_plugin, tmdb
from .nuvio_plugin import NuvioPluginFehler


def _stand(d):
    return {"an": bool(d.get(nuvio_plugin.SCHLUESSEL + "_an")),
            "plugins": [{"id": p["id"], "name": p["name"], "aktiv": p["aktiv"]} for p in nuvio_plugin.plugins(d)]}


class NuvioPluginMixin:

    def nuvio_plugins_lesen(self):
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        stand = _stand(daten)
        stand["js_sandbox_verfuegbar"] = js_sandbox.verfuegbar()
        stand["tmdb_konfiguriert"] = tmdb.konfiguriert(daten)
        return 200, "application/json", stand

    def nuvio_plugins_post(self, koerper):
        if not self.app.verwaltung:
            return 503, "application/json", {"fehler": "Nutzerdaten nicht verfügbar"}
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(wunsch, dict):
                raise ValueError("JSON-Objekt erwartet")
            if "an" in wunsch:
                def schalten(d):
                    d[nuvio_plugin.SCHLUESSEL + "_an"] = bool(wunsch.get("an"))
                    return _stand(d)
                return 200, "application/json", self.app.verwaltung.bearbeiten(schalten)

            def aendern(d):
                nuvio_plugin.aendern(d.setdefault(nuvio_plugin.SCHLUESSEL, {}), wunsch)
                return _stand(d)
            return 200, "application/json", self.app.verwaltung.bearbeiten(aendern)
        except (NuvioPluginFehler, ValueError, UnicodeDecodeError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
