"""OmniSearch API: lokale Namenssuche und Duplikatgruppen auf freigegebenen Orten.

  GET /api/omnisearch             Projekt, Android-Paket, Orte und Grenzen
  GET /api/omnisearch/suche       q/ext/art/ort/min/max/von/bis/ordner/sort/offset/limit
  GET /api/omnisearch/duplikate   ort/min -> Gruppen mit SHA-256 und frei werdendem Platz
"""

from . import omnisearch


class OmniSearchMixin:

    def omnisearch_lesen(self, pfad, werte):
        try:
            if pfad == "/api/omnisearch":
                return 200, "application/json", omnisearch.zustand(self.app.dateien)
            if pfad == "/api/omnisearch/suche":
                return 200, "application/json", omnisearch.suchen(self.app.dateien, werte)
            if pfad == "/api/omnisearch/duplikate":
                return 200, "application/json", omnisearch.duplikate(self.app.dateien, werte)
            return 404, "application/json", {"fehler": "nicht gefunden"}
        except (ValueError, OSError) as fehler:  # OmniFehler und DateiFehler sind ValueError
            return 400, "application/json", {"fehler": str(getattr(fehler, "strerror", None) or fehler)}
