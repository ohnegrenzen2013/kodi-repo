"""P2P-Torrent (NV4, Server-Pfad, p2p_torrent.py): Magnet-Link/infoHash ueber ein extern laufendes
aria2c herunterladen, danach lokal abspielen.

  GET  /api/p2p/torrent                {an, auftraege: [...]}
  POST /api/p2p/torrent                {aktion: "laden", link, name?, staffel?, folge?} -> Auftrag
                                        {aktion: "abbrechen", id}
  GET  /api/p2p/torrent/datei/<id>     die fertig geladene Datei (Range, wie XDCC)
"""

from .debrid_grund import DebridFehler
from .netz import NetzFehler
from .oberflaeche_grund import json, unquote
from .p2p_torrent import P2pTorrentFehler


class P2pTorrentMixin:

    def p2p_torrent_lesen(self):
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        return 200, "application/json", self.app.p2p_torrent.zustand(daten)

    def p2p_torrent_post(self, koerper):
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(wunsch, dict):
                raise ValueError("JSON-Objekt erwartet")
            daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
            aktion = wunsch.get("aktion")
            if aktion == "laden":
                ergebnis = self.app.p2p_torrent.laden(daten, str(wunsch.get("link") or ""),
                                                      str(wunsch.get("name") or ""),
                                                      wunsch.get("staffel"), wunsch.get("folge"))
                return 200, "application/json", ergebnis
            if aktion == "abbrechen":
                self.app.p2p_torrent.abbrechen(wunsch.get("id"))
                return 200, "application/json", self.app.p2p_torrent.zustand(daten)
            raise ValueError("Unbekannte Aktion")
        except (P2pTorrentFehler, DebridFehler, NetzFehler, ValueError, UnicodeDecodeError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}

    def p2p_torrent_datei(self, pfad):
        try:
            return "lokal", self.app.p2p_torrent.pfad(unquote(pfad[len("/api/p2p/torrent/datei/"):]))
        except P2pTorrentFehler as fehler:
            return 404, "application/json", {"fehler": str(fehler)}
