"""Party: Daumenkino (daumenkino.py) und Party-Raeume fuer Karaoke und das Synchron-Spiel (party.py).

  GET  /api/daumenkino                 Liste; /api/daumenkino/projekt?id=… ein Projekt
  POST /api/daumenkino                 {aktion: speichern, projekt} | {aktion: loeschen, id}
  GET  /api/party?raum=…&sid=…         Stand eines Raums (Spieler, Runde, Aufgaben)
  POST /api/party                      {aktion: neu|beitreten|zulassen|offen|runde|ergebnis|stimme|ende|aufgabe|
                                        aufgabe_erledigt|video|verlassen, sid, raum, …}
  Das Synchron-Spiel gehoert zu Ab 18: ein Raum im Modus "synchro" braucht die Freigabe.
  GET  /api/gemeinsam?raum=…&sid=…&position=…&zustand=…   Gemeinsam schauen (gemeinsam.py): Stand des Raums; das Geraet
                                       meldet dabei seine Stelle und ob es spielt, pausiert oder puffert
  POST /api/gemeinsam                  {aktion: neu|beitreten|zulassen|offen|alle_steuern|verlassen|medium|steuern|chat|
                                        reaktion, sid, raum, …} – Essen: bestellung_neu|posten|posten_weg|drehen|drehteller|
                                        lieferung|trinkgeld|zahlen|bestellt|bestellung_ende, Gutscheine: gutschein|
                                        gutschein_gut|gutschein_kopiert
  GET/POST /api/fernsteuerung          Mit dem Handy steuern (fernsteuerung.py): koppeln per Code, Eingaben weiterreichen
  GET  /api/fernsteuerung/qr.svg?text= QR-Code mit der Kopplungsadresse
"""

import json

from . import daumenkino, fernsteuerung, gemeinsam, party


class PartyMixin:

    def party_lesen(self, pfad, werte):
        try:
            if pfad == "/api/daumenkino":
                return 200, "application/json", self.app.daumenkino.liste()
            if pfad == "/api/daumenkino/projekt":
                return 200, "application/json", self.app.daumenkino.projekt(werte.get("id", ""))
            return 200, "application/json", self.app.party.lesen(werte.get("raum", ""), werte.get("sid", ""))
        except (daumenkino.DaumenkinoFehler, party.PartyFehler) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}

    def gemeinsam_lesen(self, werte):
        try:
            position = werte.get("position")
            return 200, "application/json", self.app.gemeinsam.lesen(werte.get("raum", ""), werte.get("sid", ""),
                                                                    position if position not in (None, "") else None, werte.get("zustand"))
        except gemeinsam.GemeinsamFehler as fehler:
            return 400, "application/json", {"fehler": str(fehler)}

    def fernsteuerung_lesen(self, pfad, werte):
        try:
            if pfad == "/api/fernsteuerung/qr.svg":
                return 200, "image/svg+xml", fernsteuerung.qr_svg(werte.get("text", ""))
            f = self.app.fernsteuerung
            if werte.get("tv"):  # der Fernseher wartet hier auf Eingaben
                return 200, "application/json", f.abholen(werte["tv"], werte.get("nach", 0),
                                                          float(werte.get("warten") or fernsteuerung.WARTEN))
            return 200, "application/json", f.stand(werte.get("handy", ""))
        except ValueError as fehler:  # FernFehler ist ein ValueError
            return 400, "application/json", {"fehler": str(fehler)}

    def fernsteuerung_post(self, koerper):
        try:
            w = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(w, dict):
                raise ValueError("JSON-Objekt erwartet")
            f, aktion = self.app.fernsteuerung, w.get("aktion")
            if aktion == "neu":
                return 200, "application/json", f.neu(w.get("tv"))
            if aktion == "koppeln":
                return 200, "application/json", f.koppeln(w.get("code"), w.get("name"))
            if aktion == "senden":
                return 200, "application/json", f.senden(w.get("handy"), w.get("eingaben"))
            if aktion == "trennen":
                return 200, "application/json", f.trennen(w.get("tv"), w.get("handy"))
            raise ValueError("Unbekannte Aktion")
        except (ValueError, UnicodeDecodeError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}

    def gemeinsam_post(self, koerper):
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(wunsch, dict):
                raise ValueError("JSON-Objekt erwartet")
            ich = self.aktuelles_profil()  # Raeume fuer eine Gruppe: nur wer darin ist (wie bei der Party)
            wunsch["_gruppen"] = list(ich.get("gruppen") or []) if ich else (None if not getattr(self._anfrage_lokal(), "aktiv", False) else [])
            return 200, "application/json", self.app.gemeinsam.aktion(wunsch)
        except (ValueError, UnicodeDecodeError) as fehler:  # GemeinsamFehler ist ein ValueError
            return 400, "application/json", {"fehler": str(fehler)}

    def party_post(self, pfad, koerper):
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(wunsch, dict):
                raise ValueError("JSON-Objekt erwartet")
            if pfad == "/api/daumenkino":
                if wunsch.get("aktion") == "loeschen":
                    return 200, "application/json", self.app.daumenkino.loeschen(wunsch.get("id"))
                return 200, "application/json", self.app.daumenkino.speichern(wunsch.get("projekt"))
            if wunsch.get("aktion") == "neu" and wunsch.get("modus") == "synchro" and not self.app.ab18.freigegeben:
                raise party.PartyFehler("Das Synchron-Spiel gehört zu Ab 18 – erst dort freigeben")
            ich = self.aktuelles_profil()
            wunsch["_gruppen"] = list(ich.get("gruppen") or []) if ich else (None if not getattr(self._anfrage_lokal(), "aktiv", False) else [])
            return 200, "application/json", self.app.party.aktion(wunsch)
        except (ValueError, UnicodeDecodeError) as fehler:  # DaumenkinoFehler und PartyFehler sind ValueError
            return 400, "application/json", {"fehler": str(fehler)}
