"""Passwort-Tresor in der Oberflaeche: pass-kompatible Eintraege, OpenPGP, Git und TOTP.

  GET  /api/tresor              Zustand, Konfiguration, Verknuepfung zur Android-App
  GET  /api/tresor/liste        Eintraege (ohne Entschluesseln), Suche/Ordner
  POST /api/tresor              {aktion: einstellen|einrichten|lesen|speichern|loeschen|umbenennen|
                                 ordner|generieren|otp|git|passkeys, ...}

Der Tresor ist ein geheimes Modul: Lesen und Aendern brauchen das Recht "einstellungen".
Passphrasen werden nur fuer den einen GnuPG-Aufruf angenommen und nie gespeichert.
"""

import json

from . import pass_tresor


class PassTresorMixin:

    def _tresor_datenordner(self):
        return getattr(self.app, "datenordner", "") or ""

    def tresor_lesen(self, pfad, werte):
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        try:
            if pfad == "/api/tresor/liste":
                return 200, "application/json", pass_tresor.liste(
                    daten, self._tresor_datenordner(), werte.get("q", ""), werte.get("ordner", ""),
                    werte.get("sortierung", ""))
        except (ValueError, OSError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        zustand = pass_tresor.zustand(daten, self._tresor_datenordner())
        zustand["verknuepfung"] = pass_tresor.verknuepfung()
        return 200, "application/json", zustand

    def tresor_post(self, koerper):
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(wunsch, dict):
                raise ValueError("JSON-Objekt erwartet")
            if not self.app.verwaltung:
                raise ValueError("Nutzerdaten nicht verfügbar")
            daten = self.app.verwaltung.daten()
            ordner = self._tresor_datenordner()
            aktion = str(wunsch.get("aktion") or "")
            if aktion in ("einstellen", "einrichten"):
                werte = wunsch.get("werte") if isinstance(wunsch.get("werte"), dict) else wunsch
                neu = dict(daten.get(pass_tresor.SCHLUESSEL) or {})
                neu.update({k: v for k, v in werte.items() if k != "aktion"})
                from .pass_tresor_grund import pruefe
                neu = pruefe(neu)
                if wunsch.get("anlegen") and neu.get("ort") == "intern":
                    import os
                    os.makedirs(os.path.join(ordner, "passwort-tresor"), exist_ok=True)
                self.app.verwaltung.abschnitt(pass_tresor.SCHLUESSEL, neu)
                antwort = pass_tresor.zustand(dict(daten, **{pass_tresor.SCHLUESSEL: neu}), ordner)
                antwort["verknuepfung"] = pass_tresor.verknuepfung()
                return 200, "application/json", antwort
            if aktion == "lesen":
                return 200, "application/json", pass_tresor.lesen(daten, ordner, wunsch.get("id", ""),
                                                                  wunsch.get("passphrase", ""))
            if aktion == "otp":
                return 200, "application/json", pass_tresor.otp(daten, ordner, wunsch.get("id", ""),
                                                                wunsch.get("passphrase", ""))
            if aktion == "speichern":
                werte = wunsch.get("eintrag") if isinstance(wunsch.get("eintrag"), dict) else wunsch
                return 200, "application/json", pass_tresor.schreiben(
                    daten, ordner, werte, ueberschreiben=wunsch.get("ueberschreiben") is True)
            if aktion == "loeschen":
                return 200, "application/json", pass_tresor.loeschen(daten, ordner, wunsch.get("id", ""))
            if aktion == "umbenennen":
                return 200, "application/json", pass_tresor.umbenennen(
                    daten, ordner, wunsch.get("id", ""), wunsch.get("name", ""), wunsch.get("ordner", ""))
            if aktion == "ordner":
                return 200, "application/json", pass_tresor.ordner_anlegen(daten, ordner, wunsch.get("ordner", ""))
            if aktion == "generieren":
                return 200, "application/json", pass_tresor.generieren(daten, wunsch)
            if aktion == "git":
                return 200, "application/json", pass_tresor.git(daten, ordner, wunsch.get("was", "status"))
            if aktion == "passkeys":
                return 200, "application/json", {"passkeys": pass_tresor.passkeys(daten, ordner)}
            return 400, "application/json", {"fehler": "Unbekannte Aktion"}
        except (ValueError, OSError, UnicodeDecodeError, pass_tresor.TresorFehler) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
