"""("_• )—* – Portal (portal.py, portal_pruefen.py, portal_durch.py): Adressen, IPs und MACs als eigene Reiter.

  GET  /api/portal            Reiter, Verlauf, Favoriten, Einstellungen des Profils, Vorschlaege aus H0rSt, darf_durch
  GET  /api/portal/status     {reiter-id: [erreichbar je Teil]} (Waechter-Punkt in der Leiste)
  POST /api/portal/pruefen    {eingabe} -> Bericht: erkannt (url|ip|host|mac), erreichbar, Titel, Geraet, einbettbar …
  POST /api/portal/wecken     {mac}  Wake-on-LAN
  POST /api/portal/kekse      {id}   Cookies eines durchgereichten Reiters vergessen (abmelden)
  GET  /api/portal/programme?host=   System und Programme mit Weboberflaeche (dieser Rechner oder host im Heimnetz)
  POST /api/portal            {aktion, …} (portal.aendern)
  *    /portal/<schluessel>/… Durchreicher (ausserhalb des Tokens, siehe portal_durch.py)

  USB Magic (usb.py), nur mit Recht "speicher" (Wiederherstellen: "einstellungen"):
  GET  /api/usb               angesteckte USB-/Wechsel-Datentraeger, System, Sicherungen auf dem Stick
  POST /api/usb               {aktion: mount|unmount|auswerfen|sichern|wiederherstellen|export, …}
"""

import os
import time

from . import brause, konfig, portal, portal_durch, portal_programme, portal_pruefen, usb
from .oberflaeche_grund import json, log


class PortalMixin:

    def _portal_profil(self):
        ich = self.aktuelles_profil()
        return ich["id"] if ich else ""

    def _portal_daten(self):
        return self.app.verwaltung.daten() if self.app.verwaltung else {}

    def portal_durchreicher(self):
        d = getattr(self, "_portal_durch", None)
        if d is None:
            d = self._portal_durch = portal_durch.Durchreicher(self._portal_daten)
        return d

    def _portal_vorschlaege(self, daten):
        """Adressen, die H0rSt schon kennt: Brause-Favoriten, Heim-Links, eigene Web-Reiter, Dienste (ohne Schluessel)."""
        liste = []
        for l in brause.pruefe(daten.get(brause.SCHLUESSEL))["lesezeichen"]:
            if l["favorit"]:
                liste.append({"name": l["titel"], "url": l["url"], "quelle": "Brause ★"})
        for l in getattr(self.app, "links", None) or []:
            liste.append({"name": l.get("name") or l.get("url"), "url": l.get("url"), "quelle": "Heim-Link"})
        for t in self.app.ui.get("eigene_tabs") or [] if isinstance(getattr(self.app, "ui", None), dict) else []:
            if t.get("art") == "web":
                liste.append({"name": t["name"], "url": t["ziel"], "quelle": "Eigener Reiter"})
        for name, c in (getattr(self.app, "dienste", None) or {}).items():
            url = getattr(c, "url", "")
            if isinstance(url, str) and url.startswith(("http://", "https://")):
                liste.append({"name": getattr(c, "name", "") or name, "url": url, "quelle": "Dienst"})
        gesehen, ergebnis = set(), []
        for v in liste:
            if v["url"] and v["url"] not in gesehen and str(v["url"]).startswith(("http://", "https://")):
                gesehen.add(v["url"])
                ergebnis.append(v)
        return ergebnis[:60]

    def _portal_antwort(self, werte, daten=None):
        werte = dict(werte)
        werte["darf_durch"] = self.darf("einstellungen")
        werte["name"] = portal.NAME
        if daten is not None:
            werte["vorschlaege"] = self._portal_vorschlaege(daten)
        return 200, "application/json", werte

    def portal_lesen(self, pfad, werte):
        daten = self._portal_daten()
        e = portal.lesen(daten, self._portal_profil())
        if pfad == "/api/portal/status":
            urls = [t["url"] for r in e["reiter"] for t in r["teile"]]
            da = portal_pruefen.erreichbar(urls)
            return 200, "application/json", {r["id"]: [da.get(t["url"], False) for t in r["teile"]] for r in e["reiter"]}
        if pfad == "/api/portal/programme":
            return self._portal_programme(werte)
        if pfad != "/api/portal":
            return 404, "application/json", {"fehler": "unbekannt"}
        return self._portal_antwort(e, daten)

    def _portal_programme(self, werte):
        host = str(werte.get("host") or "").strip() or "127.0.0.1"
        try:
            erkannt = portal.erkenne(host)
        except portal.PortalFehler as f:
            return 400, "application/json", {"fehler": str(f)}
        if erkannt["art"] not in ("ip", "host") or not portal.ist_lokal(erkannt["host"]):
            return 400, "application/json", {"fehler": "Nur Geräte im Heimnetz (IP oder Name)"}
        web = portal_programme.finden(erkannt["host"])
        if not (self._einstellungen_lesen().get("werte") or {}).get("emuleese_an"):
            web = [p for p in web if p.get("id") != "emuleese"]  # eSE nur vorschlagen, wenn angebunden
        return 200, "application/json", {"system": portal_programme.system(), "host": erkannt["host"], "web": web}

    def portal_post(self, pfad, koerper):
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(wunsch, dict):
                raise portal.PortalFehler("JSON-Objekt erwartet")
            st = portal.lesen(self._portal_daten(), self._portal_profil())["einstellungen"]
            if pfad == "/api/portal/pruefen":
                return 200, "application/json", self._portal_pruefen(wunsch, st)
            if pfad == "/api/portal/wecken":
                n = portal_pruefen.wecken(wunsch.get("mac"))
                return 200, "application/json", {"ok": True, "gesendet": n}
            if pfad == "/api/portal/kekse":
                for r in portal.lesen(self._portal_daten(), self._portal_profil())["reiter"]:
                    if r["id"] == wunsch.get("id"):
                        for t in r["teile"]:
                            if t["schluessel"]:
                                self.portal_durchreicher().kekse_leeren(t["schluessel"])
                return 200, "application/json", {"ok": True}
            if pfad != "/api/portal":
                return 404, "application/json", {"fehler": "unbekannt"}
            if not self.app.verwaltung:
                return 503, "application/json", {"fehler": "Nutzerdaten nicht verfügbar"}
            pid, darf = self._portal_profil(), self.darf("einstellungen")
            neu = self.app.verwaltung.bearbeiten(lambda d: portal.aendern(d, pid, wunsch, darf))
            self.portal_durchreicher().vergessen()
            return self._portal_antwort(neu)
        except (ValueError, UnicodeDecodeError) as fehler:  # PortalFehler ist ein ValueError
            return 400, "application/json", {"fehler": str(fehler)}

    def _portal_pruefen(self, wunsch, st):
        erkannt = portal.erkenne(wunsch.get("eingabe"))
        ergebnis = {"erkannt": erkannt}
        if erkannt["art"] == "mac":
            ip, hinweis = portal_pruefen.mac_zu_ip(erkannt["mac"], anstossen=st["anstossen"])
            ergebnis["mac_hinweis"] = hinweis
            if not ip:
                return dict(ergebnis, bericht=None)
            erkannt["url"] = "http://%s/" % ("[%s]" % ip if ":" in ip else ip)
            erkannt["host"] = ip
        bericht = portal_pruefen.pruefen(erkannt["url"], unsicher_lokal=st["zertifikat"],
                                         abklopfen=st["ports"] and not erkannt.get("port") and erkannt["art"] in ("ip", "host", "mac"))
        log.info("Portal: %s geprüft (%s)", erkannt["host"] or erkannt["url"], bericht["status"] or bericht["fehler"])
        return dict(ergebnis, bericht=bericht)

    def portal_durch(self, schluessel, rest, abfrage, methode, koerper, kopf):
        if methode not in ("GET", "POST"):
            return 405, "application/json", {"err": "method not allowed"}
        if rest is None:  # /portal/<schluessel> ohne Schraegstrich: relative Adressen der Seite brauchen ihn
            return "weiter", "/portal/%s/%s" % (schluessel, "?" + abfrage if abfrage else "")
        return self.portal_durchreicher().anfrage(schluessel, rest, abfrage, methode, koerper, kopf)

    # --- USB Magic ---------------------------------------------------------------------------------------------------
    def _usb_mountpunkte(self):
        """Realpfade der gerade eingehaengten USB-/Wechsel-Datentraeger – nur dort darf gesichert/gelesen werden."""
        return [os.path.realpath(g["pfad"]) for g in usb.geraete() if g["eingehaengt"] and g["pfad"]]

    def _usb_pfad(self, roh, muss_da=False):
        """Einen vom Browser genannten Pfad auf einen eingehaengten USB-Datentraeger einschraenken (nie woanders hin)."""
        pfad = os.path.realpath(str(roh or ""))
        if not any(pfad == w or pfad.startswith(w + os.sep) for w in self._usb_mountpunkte()):
            raise usb.UsbFehler("Dieser Ort liegt nicht auf einem eingehängten USB-Datenträger")
        if muss_da and not os.path.isfile(pfad):
            raise usb.UsbFehler("Datei nicht gefunden")
        return pfad

    def _usb_sicherungen(self, mountpunkte=None):
        """Sicherungsdateien (h0rst-...json) auf den eingehaengten Datentraegern."""
        funde = []
        for w in mountpunkte or self._usb_mountpunkte():
            ordner = os.path.join(w, "H0rSt-Sicherungen")
            for basis in (ordner, w):
                try:
                    namen = sorted(os.listdir(basis), reverse=True)
                except OSError:
                    continue
                for n in namen:
                    p = os.path.join(basis, n)
                    if n.lower().endswith(".json") and ("h0rst" in n.lower() or "sicherung" in n.lower()) and os.path.isfile(p):
                        try:
                            funde.append({"name": n, "pfad": p, "groesse": os.path.getsize(p), "zeit": int(os.path.getmtime(p))})
                        except OSError:
                            pass
        return funde

    def usb_lesen(self):
        if not self.darf("speicher"):
            return 403, "application/json", {"fehler": "Dafür fehlt das Recht „Ablage und externe Speicher“.", "recht": True}
        geraete = usb.geraete()
        mp = [os.path.realpath(g["pfad"]) for g in geraete if g["eingehaengt"] and g["pfad"]]
        return 200, "application/json", {"geraete": geraete, "sicherungen": self._usb_sicherungen(mp),
                                         "system": portal_programme.system(), "nutzerdaten": bool(self.app.verwaltung)}

    def usb_post(self, koerper):
        if not self.darf("speicher"):
            return 403, "application/json", {"fehler": "Dafür fehlt das Recht „Ablage und externe Speicher“.", "recht": True}
        try:
            w = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(w, dict):
                raise usb.UsbFehler("JSON-Objekt erwartet")
            aktion, knoten = w.get("aktion"), str(w.get("knoten") or "")
            meldung = ""
            if aktion == "mount":
                pfad, meldung = usb.einhaengen(knoten, nur_lesbar=w.get("nur_lesbar") is True)
                log.info("USB: %s eingehängt nach %s", knoten, pfad)
            elif aktion in ("unmount", "auswerfen"):
                meldung = usb.aushaengen(knoten, auswerfen=(aktion == "auswerfen"))
                log.info("USB: %s %s", knoten, aktion)
            elif aktion == "sichern":
                meldung = self._usb_sichern(w)
            elif aktion == "export":
                meldung = self._usb_export(w)
            elif aktion == "wiederherstellen":
                return self._usb_wiederherstellen(w)
            else:
                raise usb.UsbFehler("Unbekannte Aktion")
            s, _, d = self.usb_lesen()
            return s, "application/json", dict(d, meldung=meldung) if isinstance(d, dict) else d
        except (ValueError, UnicodeDecodeError, OSError) as fehler:  # UsbFehler/DatenFehler sind ValueError
            return 400, "application/json", {"fehler": str(fehler)}

    def _usb_zielordner(self, w):
        ziel = self._usb_pfad(w.get("pfad"))
        ordner = os.path.join(ziel, "H0rSt-Sicherungen") if os.path.isdir(ziel) and os.path.basename(ziel) != "H0rSt-Sicherungen" else ziel
        os.makedirs(ordner, exist_ok=True)
        return ordner

    def _usb_sichern(self, w):
        if not self.app.verwaltung:
            raise usb.UsbFehler("Nutzerdaten nicht verfügbar")
        passwort = str(w.get("passwort") or "")
        if passwort and len(passwort) < 8:
            raise usb.UsbFehler("Passwort für die Sicherung: mindestens 8 Zeichen")
        datei = os.path.join(self._usb_zielordner(w), time.strftime("h0rst-sicherung-%Y-%m-%d-%H%M.json"))
        konfig.exportiere(self.app.verwaltung.konfig_pfad, datei, passwort or None)
        log.info("USB: Komplettsicherung geschrieben nach %s%s", datei, " (verschlüsselt)" if passwort else "")
        return "Gesichert nach %s%s" % (os.path.basename(datei), " – verschlüsselt" if passwort else "")

    def _usb_export(self, w):
        """Nur die Reiter und/oder Einstellungen des Profils als lesbare Datei auf den Stick (ohne Passwörter)."""
        daten = self._portal_daten()
        was = w.get("was") if w.get("was") in ("portal", "oberflaeche", "beide") else "portal"
        inhalt = {}
        if was in ("portal", "beide"):
            e = portal.lesen(daten, self._portal_profil())
            inhalt["portal"] = {"reiter": [dict(r, teile=[dict(t, schluessel="") for t in r["teile"]]) for r in e["reiter"]],
                                "favoriten": e["favoriten"], "einstellungen": e["einstellungen"]}
        if was in ("oberflaeche", "beide"):
            inhalt["oberflaeche"] = self.app.ui if isinstance(self.app.ui, dict) else {}
        datei = os.path.join(self._usb_zielordner(w), time.strftime("h0rst-export-%Y-%m-%d-%H%M.json"))
        with open(datei, "w", encoding="utf-8") as f:
            json.dump(inhalt, f, ensure_ascii=False, indent=1)
        return "Exportiert nach %s" % os.path.basename(datei)

    def _usb_wiederherstellen(self, w):
        if not self.darf("einstellungen"):
            return 403, "application/json", {"fehler": "Wiederherstellen braucht das Recht „Einstellungen“.", "recht": True}
        if not self.app.verwaltung:
            return 400, "application/json", {"fehler": "Nutzerdaten nicht verfügbar"}
        pfad = self._usb_pfad(w.get("pfad"), muss_da=True)
        passwort = str(w.get("passwort") or "") or None
        with open(pfad, encoding="utf-8") as f:
            text = f.read()
        if konfig.ist_verschluesselt(text) and not passwort:
            return 400, "application/json", {"fehler": "Diese Sicherung ist verschlüsselt – Passwort angeben", "passwort": True}
        anzahl = konfig.einlesen(self.app.verwaltung.konfig_pfad, text, bool(w.get("zusammenfuehren")), passwort)
        token = self.app.nutzerdaten_neu()
        log.info("USB: Sicherung %s eingespielt (%d Einstellungen)", os.path.basename(pfad), anzahl)
        return 200, "application/json", {"meldung": "Wiederhergestellt (%d Einstellungen) aus %s" % (anzahl, os.path.basename(pfad)),
                                         "einstellungen": anzahl, "basis": "/%s/" % token if token else "/"}
