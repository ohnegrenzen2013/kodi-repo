"""Eigene Poster je Titel (poster_eigen.py).

  GET  /api/poster   {poster: {titel-id: adresse}} des Profils der Anfrage
  POST /api/poster   {aktion: setzen, id, url} | {aktion: weg, id}
"""

import json

from . import poster_eigen


class PosterMixin:

    def poster_lesen(self):
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        return 200, "application/json", {"poster": poster_eigen.lesen(daten, self._sehen_profil())}

    def poster_post(self, koerper):
        if not self.app.verwaltung:
            return 503, "application/json", {"fehler": "Nutzerdaten nicht verfügbar"}
        profil = self._sehen_profil()
        try:
            w = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(w, dict):
                raise ValueError("JSON-Objekt erwartet")
            a = w.get("aktion")
            if a == "setzen":
                tun = lambda d: poster_eigen.setzen(d, profil, w.get("id"), w.get("url"))  # noqa: E731
            elif a == "weg":
                tun = lambda d: poster_eigen.weg(d, profil, w.get("id"))  # noqa: E731
            else:
                return 400, "application/json", {"fehler": "Unbekannte Aktion"}
            return 200, "application/json", {"poster": self.app.verwaltung.bearbeiten(tun)}
        except (ValueError, TypeError, UnicodeDecodeError) as fehler:  # PosterFehler ist ein ValueError
            return 400, "application/json", {"fehler": str(fehler)}
