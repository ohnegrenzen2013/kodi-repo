"""Qwen Pose Studio: ComfyUI-Status, Posen, Auftraege und Bilder."""

import json

from . import qwen_pose
from .ab18 import Gesperrt
from .netz import NetzFehler
from .qwen_pose import QwenFehler


class QwenPoseMixin:
    def _qwen(self):
        return getattr(self.app, "qwen_pose", None)

    def qwen_pose_lesen(self, werte):
        if not self.darf("einstellungen"):
            return 403, "application/json", {"fehler": "Kein Recht auf Einstellungen", "recht": True}
        q = self._qwen()
        if q is None:
            return 503, "application/json", {"fehler": "Qwen Pose Studio nicht verfuegbar"}
        w = self._einstellungen_lesen().get("werte") or {}
        aktion = str(werte.get("aktion") or "")
        try:
            if aktion == "doctor":
                return 200, "application/json", q.doctor(w)
            if aktion == "posen":
                return 200, "application/json", q.posen(w, werte.get("stufe") or "L0")
            if aktion == "job":
                job = q.job(werte.get("id"))
                if job is None:
                    raise QwenFehler("Unbekannter Auftrag")
                return 200, "application/json", job
            if aktion == "liste":
                return 200, "application/json", {"jobs": q.liste()}
            return 200, "application/json", qwen_pose.zustand(w)
        except QwenFehler as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        except NetzFehler as fehler:
            return 502, "application/json", {"fehler": str(fehler)}

    def qwen_pose_bild(self, name):
        if not self.darf("einstellungen"):
            return 403, "application/json", {"fehler": "Kein Recht auf Einstellungen", "recht": True}
        q = self._qwen()
        if q is None:
            return 404, "application/json", {"fehler": "nicht gefunden"}
        try:
            return "lokal", q.bild(name)
        except QwenFehler as fehler:
            return 404, "application/json", {"fehler": str(fehler)}

    def qwen_pose_post(self, koerper, kopf):
        if not self.darf("einstellungen"):
            return 403, "application/json", {"fehler": "Kein Recht auf Einstellungen", "recht": True}
        q = self._qwen()
        if q is None:
            return 503, "application/json", {"fehler": "Qwen Pose Studio nicht verfuegbar"}
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
        except (ValueError, UnicodeDecodeError):
            return 400, "application/json", {"fehler": "JSON-Fehler"}
        if not isinstance(wunsch, dict):
            return 400, "application/json", {"fehler": "JSON-Objekt erwartet"}
        werte = self._einstellungen_lesen().get("werte") or {}
        try:
            aktion = str(wunsch.get("aktion") or "start")
            if aktion == "abbrechen":
                return 200, "application/json", q.abbrechen(wunsch.get("id"))
            if aktion != "start":
                raise QwenFehler("aktion: start oder abbrechen")
            if wunsch.get("nsfw") is True:
                if not qwen_pose.pruefe(werte)["qwen_nsfw_an"]:
                    raise QwenFehler("NSFW ist in den Qwen-Einstellungen nicht freigegeben")
                if self.app.ab18 is None:
                    raise Gesperrt("Ab-18-Bereich nicht verfuegbar")
                self.app.ab18.pruefen(kopf.get("X-Ab18") if kopf else None)
            return 200, "application/json", q.start(werte, wunsch)
        except Gesperrt as fehler:
            return 403, "application/json", {"fehler": str(fehler), "gesperrt": True, "ab18": True}
        except (QwenFehler, ValueError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        except NetzFehler as fehler:
            return 502, "application/json", {"fehler": str(fehler)}
