"""Radio (radio.py): Sender suchen, Favoriten, Stream ueber H0rSt fuer HTTPS-Seiten.

  GET  /api/radio                    Favoriten, Genres, Adresse der Senderliste
  GET  /api/radio/suche              ?q=&tag=&land=&sort=clickcount|votes&seite=
  GET  /api/radio/strom?id=          Stream eines bekannten Senders ueber H0rSt (z. B. http-Sender auf der HTTPS-Seite)
  POST /api/radio/favorit            {sender} merken oder {id, weg: true} entfernen
  GET  /radio.m3u                    Favoriten als Senderliste (Kodi, IPTV-Apps, VLC)
"""

from .oberflaeche_grund import json, radio


class RadioMixin:

    def _radio_favoriten(self):
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        return self.app.radio.merken(radio.pruefe_favoriten((daten.get(radio.SCHLUESSEL) or {}).get("favoriten")))

    def radio_lesen(self, pfad, werte):
        r = self.app.radio
        try:
            if pfad == "/api/radio/suche":
                try:
                    seite = max(0, int(werte.get("seite") or 0))
                except ValueError:
                    seite = 0
                treffer = r.suchen(werte.get("q", ""), werte.get("tag", ""), werte.get("land", ""), werte.get("sort", "clickcount"),
                                   60, seite * 60)
                return 200, "application/json", {"sender": treffer, "weiter": len(treffer) == 60}
            if pfad == "/api/radio/strom":
                s = r.bekannt(werte.get("id")) or next((x for x in self._radio_favoriten() if x["id"] == werte.get("id")), None)
                if not s:
                    return 404, "application/json", {"fehler": "Sender unbekannt – erst suchen"}
                return "wiedergabe", (s["url"], {}, [])
            return 200, "application/json", {"favoriten": self._radio_favoriten(), "genres": radio.GENRES, "m3u": "radio.m3u"}
        except radio.RadioFehler as fehler:
            return 502, "application/json", {"fehler": str(fehler)}

    def radio_post(self, pfad, koerper):
        if not self.app.verwaltung:
            return 503, "application/json", {"fehler": "Nutzerdaten nicht verfügbar"}
        try:
            daten = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(daten, dict):
                raise ValueError("JSON-Objekt erwartet")

            def aendern(d):
                abschnitt = dict(d.get(radio.SCHLUESSEL) or {})
                liste = radio.pruefe_favoriten(abschnitt.get("favoriten"))
                if daten.get("weg"):
                    liste = [s for s in liste if s["id"] != str(daten.get("id") or "")]
                else:
                    s = radio.sender(daten.get("sender"))
                    if not s:
                        raise ValueError("Sender mit id, name und url erwartet")
                    if len(liste) >= radio.MAX_FAVORITEN:
                        raise ValueError("Höchstens %d Favoriten" % radio.MAX_FAVORITEN)
                    liste = [x for x in liste if x["id"] != s["id"]] + [s]
                abschnitt["favoriten"] = liste
                d[radio.SCHLUESSEL] = abschnitt
                return liste
            liste = self.app.verwaltung.bearbeiten(aendern)
            self.app.radio.merken(liste)
            return 200, "application/json", {"favoriten": liste}
        except (ValueError, UnicodeDecodeError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}

    def radio_m3u(self):
        return 200, "audio/x-mpegurl", radio.m3u(self._radio_favoriten())
