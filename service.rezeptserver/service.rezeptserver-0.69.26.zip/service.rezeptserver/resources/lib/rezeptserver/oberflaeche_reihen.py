"""Eigene YouTube-Reihen je Profil (youtube_reihen.py).

  GET  /api/reihen   {reihen: [{id, name, videos: [{id, titel, kanal, bild}]}]} des Profils der Anfrage
  POST /api/reihen   {aktion: neu, name, link?} | {aktion: umbenennen, reihe, name} | {aktion: weg, reihe}
                     {aktion: reihe_nach, reihe, nach} | {aktion: video_dazu, reihe, link} | {aktion: video_weg, reihe, video}
                     {aktion: video_nach, reihe, video, nach}
                     {aktion: kanal_dazu, eingabe: @Name|Kanal-Adresse|UC-Kennung, name?} | {aktion: playlist_dazu, eingabe: Playlist-Adresse|Kennung, name?}
                     (Quellen-Reihen: neueste Videos aus dem RSS-Feed; Kinderprofile brauchen dafuer die Eltern-PIN)
Abspielen laeuft ueber POST /api/youtube/abspielen (vorhandener Weg).
"""

import json

from . import youtube_quellen as yq, youtube_reihen as yr


class ReihenMixin:

    def _reihen_mit_feeds(self, reihen):
        """Quellen-Reihen (Kanal/Playlist) bekommen ihre neuesten Videos aus dem Feed; Fehler stehen an der Reihe."""
        holen = self.app.youtube.holen
        from .youtube_kanal import bild
        for r in reihen:
            q = r.get("quelle")
            if q:
                try:
                    r["videos"] = yq.videos_holen(q["art"], q["id"], holen, bild)
                except yq.QuellenFehler as fehler:
                    r["fehler"] = str(fehler)
        return reihen

    def reihen_lesen(self):
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        return 200, "application/json", {"reihen": self._reihen_mit_feeds(yr.lesen(daten, self._sehen_profil())),
                                         "api_schluessel": bool(yq.schluessel(daten))}

    def youtube_api_schluessel(self, daten):
        """POST /api/youtube/api_schluessel {api_key} (leer entfernt). Antwort nennt nur, ob einer gesetzt ist."""
        if not self.app.verwaltung:
            raise ValueError("Nutzerdaten nicht verfügbar")
        return self.app.verwaltung.bearbeiten(lambda d: yq.schluessel_einstellen(d, daten.get("api_key")))

    def reihen_post(self, koerper):
        if not self.app.verwaltung:
            return 503, "application/json", {"fehler": "Nutzerdaten nicht verfügbar"}
        profil = self._sehen_profil()
        try:
            w = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(w, dict):
                raise ValueError("JSON-Objekt erwartet")
            a, rid = w.get("aktion"), str(w.get("reihe") or "")
            info = None
            if a in ("video_dazu", "neu") and w.get("link"):
                vid = yr.video_id_aus(w.get("link"))
                if not vid:
                    raise yr.ReihenFehler("Das ist kein Link zu einem einzelnen YouTube-Video (youtu.be, watch?v=, shorts, embed)")
                info = yr.oembed(vid, lambda url: self.app.yt_oembed.abruf(url))  # ausserhalb der Sperre, darf warten

            quelle = None
            if a in ("kanal_dazu", "playlist_dazu"):  # Netz ausserhalb der Sperre
                eingabe = str(w.get("eingabe") or "").strip()
                if a == "kanal_dazu":
                    k = self.app.youtube.kanal_finden(eingabe)
                    quelle = ("kanal", k["id"], str(w.get("name") or k["name"]))
                else:
                    pid = yq.playlist_id_aus(eingabe)
                    if not pid:
                        raise yr.ReihenFehler("Das ist keine Playlist-Adresse (…/playlist?list=PL…)")
                    try:
                        titel, _ = yq.feed_lesen(self.app.youtube.holen(yq.feed_adresse("playlist", pid)), lambda v: "")
                    except yq.QuellenFehler:
                        raise
                    except Exception as fehler:
                        raise yr.ReihenFehler("Playlist nicht ladbar (privat oder gelöscht?): %s" % str(fehler)[:100])
                    quelle = ("playlist", pid, str(w.get("name") or titel or "Playlist"))

            def tun(d):
                if quelle:
                    yr.quelle_dazu(d, profil, *quelle)
                elif a == "neu":
                    r = yr.neu(d, profil, w.get("name"))
                    if w.get("link"):
                        yr.video_dazu(d, profil, r["id"], w["link"], info)
                elif a == "umbenennen":
                    yr.umbenennen(d, profil, rid, w.get("name"))
                elif a == "weg":
                    yr.weg(d, profil, rid)
                elif a == "reihe_nach":
                    yr.reihe_verschieben(d, profil, rid, w.get("nach"))
                elif a == "video_dazu":
                    yr.video_dazu(d, profil, rid, w.get("link"), info)
                elif a == "video_weg":
                    yr.video_weg(d, profil, rid, str(w.get("video") or ""))
                elif a == "video_nach":
                    yr.verschieben(d, profil, rid, str(w.get("video") or ""), w.get("nach"))
                else:
                    raise yr.ReihenFehler("Unbekannte Aktion")
                return yr.lesen(d, profil)
            return 200, "application/json", {"reihen": self._reihen_mit_feeds(self.app.verwaltung.bearbeiten(tun))}
        except (ValueError, TypeError, UnicodeDecodeError, OSError) as fehler:  # ReihenFehler ist ein ValueError
            return 400, "application/json", {"fehler": str(fehler)}
