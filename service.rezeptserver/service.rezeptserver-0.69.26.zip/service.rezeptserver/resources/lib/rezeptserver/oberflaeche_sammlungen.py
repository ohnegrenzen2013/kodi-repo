"""Sammlungen (Collections, ARVIO 2.2): Uebersicht, Ordner und Import/Verwaltung.

  GET  /api/sammlungen                              alle Reihen und Ordner (eingebaut und importiert)
  GET  /api/sammlungen?ordner=standard/genres/action&typ=movie&skip=0   Titel eines Ordners
  POST /api/sammlungen {aktion: importieren, json|url, name?}            Pack importieren oder ersetzen
                       {aktion: aktualisieren, id}                        Pack von seiner Adresse neu laden
                       {aktion: entfernen, id}
                       {aktion: standard, an}
                       {aktion: sichtbar, key, an}
"""

import json

from .sammlungen import SammlungenFehler


class SammlungenMixin:

    def sammlungen_lesen(self, werte):
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        try:
            if werte.get("ordner"):
                return 200, "application/json", self.app.sammlungen.ordner(
                    werte.get("ordner", ""), werte.get("typ", ""), werte.get("skip", 0), daten)
            return 200, "application/json", self.app.sammlungen.uebersicht(daten)
        except SammlungenFehler as fehler:
            return 400, "application/json", {"fehler": str(fehler)}

    def sammlungen_post(self, koerper):
        if not self.app.verwaltung:
            return 503, "application/json", {"fehler": "Nutzerdaten nicht verfügbar"}
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(wunsch, dict):
                raise ValueError("JSON-Objekt erwartet")
            aktion = wunsch.get("aktion")
            if aktion == "importieren":
                pack = self.app.sammlungen.pack_bauen(wunsch)
                return 200, "application/json", self.app.verwaltung.bearbeiten(
                    lambda d: self.app.sammlungen.speichern(d, pack))
            if aktion == "aktualisieren":
                daten = self.app.verwaltung.daten()
                pack = next((p for p in (daten.get("sammlungen") or {}).get("packs") or []
                             if isinstance(p, dict) and p.get("id") == wunsch.get("id")), None)
                if not pack:
                    raise SammlungenFehler("Sammlung nicht gefunden")
                if not pack.get("url"):
                    raise SammlungenFehler("Diese Sammlung wurde als JSON eingespielt – zum Aktualisieren neu importieren")
                neu = self.app.sammlungen.pack_bauen({"url": pack["url"], "name": pack.get("name")})
                return 200, "application/json", self.app.verwaltung.bearbeiten(
                    lambda d: self.app.sammlungen.speichern(d, neu))
            if aktion == "entfernen":
                return 200, "application/json", self.app.verwaltung.bearbeiten(
                    lambda d: self.app.sammlungen.entfernen(d, wunsch.get("id")))
            if aktion == "standard":
                return 200, "application/json", self.app.verwaltung.bearbeiten(
                    lambda d: self.app.sammlungen.standard(d, wunsch.get("an") is not False))
            if aktion == "sichtbar":
                return 200, "application/json", self.app.verwaltung.bearbeiten(
                    lambda d: self.app.sammlungen.sichtbar(d, wunsch.get("key"), wunsch.get("an") is not False))
            raise ValueError("aktion: importieren, aktualisieren, entfernen, standard oder sichtbar")
        except (ValueError, UnicodeDecodeError) as fehler:  # SammlungenFehler ist ein ValueError
            return 400, "application/json", {"fehler": str(fehler)}
