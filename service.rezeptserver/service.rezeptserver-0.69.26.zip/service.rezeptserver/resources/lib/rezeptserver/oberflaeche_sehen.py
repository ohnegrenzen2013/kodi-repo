"""Filme und Serien (sehen.py): Merkliste, Verlauf und Weiterschauen je Profil, auf allen Geraeten gleich.

  GET  /api/sehen     {merkliste: [...], verlauf: [...], weiterschauen: [...]} des Profils der Anfrage
  POST /api/sehen     {aktion: merken|weg|gesehen|verlauf_weg|weiterschauen_weg, titel: {...}}
                      | {aktion: fortschritt, titel: {...}, video, position, dauer} (Sekunden; meldet der Player)
                      | {aktion: leeren, was: merkliste|verlauf|weiterschauen}
  GET  /api/marken?ref=   Sprungmarke (Intro/Abspann) des Titels fuer das Profil (marken.py)
  POST /api/marken        {ref, aktion: intro|intro_ende|outro|auto|intro_weg|outro_weg|loeschen|
                                         vorschlag_uebernehmen|vorschlag_ablehnen, …}
                          aktion "vorschlag" ist intern (Erkennungs-Hintergrundjob) und wird hier abgelehnt.
"""

import threading

from . import marken
from .oberflaeche_grund import json, sehen


class SehenMixin:

    def _sehen_profil(self):
        ich = self.aktuelles_profil()
        return ich["id"] if ich else ""

    def sehen_lesen(self):
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        self.trakt_bei_bedarf(daten, self._sehen_profil())
        self.simkl_bei_bedarf(daten, self._sehen_profil())
        return 200, "application/json", sehen.lesen(daten, self._sehen_profil())

    def sehen_post(self, koerper):
        if not self.app.verwaltung:
            return 503, "application/json", {"fehler": "Nutzerdaten nicht verfügbar"}
        profil_id = self._sehen_profil()
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
            antwort = self.app.verwaltung.bearbeiten(lambda d: sehen.aendern(d, profil_id, wunsch))
            from .mhub_addon_grund import ereignis_von  # erst hier: mhub_addon_grund zieht stremio_grund nach
            ereignis = ereignis_von(wunsch)
            addons = getattr(self.app, "addons", None)
            if ereignis and addons is not None and hasattr(addons, "melden"):
                threading.Thread(target=addons.melden, args=(ereignis,), name="mhub-melden", daemon=True).start()
            return 200, "application/json", antwort
        except (ValueError, UnicodeDecodeError) as fehler:  # SehenFehler ist ein ValueError
            return 400, "application/json", {"fehler": str(fehler)}

    def marken_lesen(self, werte):
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        ref = werte.get("ref")
        if not ref:
            return 200, "application/json", {"marken": marken.lesen(daten, self._sehen_profil())}
        marke = marken.lesen(daten, self._sehen_profil(), ref)
        if not (marke.get("intro") or marke.get("outro") is not None or marke.get("erkannt")):
            segmente = getattr(self.app, "skip_segmente", None)
            if segmente is not None:
                werte = self._einstellungen_lesen().get("werte") or {}
                segmente.anfragen(self.app.verwaltung, werte, ref)  # IntroDB/AniSkip im Hintergrund
        return 200, "application/json", marke

    def marken_post(self, koerper):
        if not self.app.verwaltung:
            return 503, "application/json", {"fehler": "Nutzerdaten nicht verfügbar"}
        profil_id = self._sehen_profil()
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
            if wunsch.get("aktion") == "vorschlag":  # nur der Erkennungs-Hintergrundjob darf das, nie HTTP
                return 400, "application/json", {"fehler": "nur intern gesetzt"}
            return 200, "application/json", self.app.verwaltung.bearbeiten(lambda d: marken.aendern(d, profil_id, wunsch))
        except (ValueError, UnicodeDecodeError) as fehler:  # MarkenFehler ist ein ValueError
            return 400, "application/json", {"fehler": str(fehler)}
