"""Shizuku: Zustand und freigegebene rish-Befehle.

  GET  /api/shizuku          {name, stand, paket, an, modus, rish, befehle, farben, …}
  POST /api/shizuku          {befehl, werte} -> baut den rish-Befehl, wenn die Einstellung ihn freigibt.

H0rSt fuehrt den Befehl nicht aus; er wird nur angezeigt und kopiert.
"""

import json

from . import shizuku


class ShizukuMixin:

    def shizuku_lesen(self):
        daten = self._einstellungen_lesen()
        return 200, "application/json", shizuku.zustand(daten.get("werte") or {})

    def shizuku_post(self, koerper):
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
        except (ValueError, UnicodeDecodeError):
            return 400, "application/json", {"fehler": "JSON-Fehler"}
        if not isinstance(wunsch, dict):
            return 400, "application/json", {"fehler": "JSON-Objekt erwartet"}
        daten = self._einstellungen_lesen()
        return 200, "application/json", shizuku.befehl_bauen(daten.get("werte") or {}, wunsch.get("befehl"),
                                                             wunsch.get("werte"))
