"""SIMKL (simkl.py): verbinden per PIN und Watchlist, Verlauf und Weiterschauen abgleichen.

  GET  /api/simkl        Stand fuer das Profil der Anfrage {eingerichtet, verbunden, benutzer, zuletzt, fehler, geraet?}
  POST /api/simkl        {aktion: verbinden}  -> {code, url, bis, intervall}
                         {aktion: pruefen}    -> {fertig, warten, fehler?}
                         {aktion: abgleichen} -> {herein, hinaus}
                         {aktion: trennen}
  POST /api/simkl/app    {client_id}  SIMKL-App des Servers (Recht "einstellungen"); leere client_id loescht
"""

from . import simkl
from .oberflaeche_grund import json


class SimklMixin:

    def _simkl_profil(self):
        ich = self.aktuelles_profil()
        return ich["id"] if ich else ""

    def simkl_lesen(self):
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        return 200, "application/json", self.app.simkl.stand(daten, self._simkl_profil())

    def simkl_bei_bedarf(self, daten, profil):
        """Beim Oeffnen von Merkliste, Verlauf oder Weiterschauen: alle 15 Minuten im Hintergrund abgleichen."""
        s = getattr(self.app, "simkl", None)
        if s is not None and s.faellig(daten, profil):
            s.im_hintergrund(profil)

    def simkl_post(self, pfad, koerper):
        if not self.app.verwaltung:
            return 503, "application/json", {"fehler": "Nutzerdaten nicht verfügbar"}
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(wunsch, dict):
                raise ValueError("JSON-Objekt erwartet")
            if pfad == "/api/simkl/app":
                return 200, "application/json", self.app.verwaltung.bearbeiten(lambda d: simkl.Simkl.app_setzen(d, wunsch))
            profil, s = self._simkl_profil(), self.app.simkl
            aktion = wunsch.get("aktion")
            if aktion == "verbinden":
                return 200, "application/json", s.verbinden_start(profil)
            if aktion == "pruefen":
                return 200, "application/json", s.verbinden_pruefen(profil)
            if aktion == "abgleichen":
                return 200, "application/json", s.abgleichen(profil)
            if aktion == "trennen":
                return 200, "application/json", s.trennen(profil)
            raise ValueError("aktion: verbinden, pruefen, abgleichen oder trennen")
        except (ValueError, UnicodeDecodeError) as fehler:  # SimklFehler ist ein ValueError
            return 400, "application/json", {"fehler": str(fehler)}
