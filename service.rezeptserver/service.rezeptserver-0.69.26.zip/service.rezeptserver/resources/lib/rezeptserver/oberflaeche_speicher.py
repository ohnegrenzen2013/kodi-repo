"""Speicher & Aufraeumen (speicher.py) in der Oberflaeche.

  GET  /api/speicher?tage=60          Belegung je Bereich, Nutzung der Module und Kodi-Addons, Vorschlaege
  POST /api/speicher/aufraeumen       {ids: [vorschlag-id …], tage} -> {frei, erledigt, fehler} und die neue Uebersicht
Ansehen braucht das Recht "einstellungen", Aufraeumen das Recht "anbieter" (es entfernt auch Kodi-Addons).
"""

import json
import os

from . import einstellungen, speicher
from .kodi_addons import laufzeit


class SpeicherMixin:

    def _speicher_verwalter(self):
        reiter, skin = set(), set()
        if self.app.verwaltung:
            w = einstellungen.werte(self.app.verwaltung.daten())
            for t in w.get("eigene_tabs") or []:
                if t.get("art") == "kodi":
                    try:
                        reiter.add(laufzeit.zerlegen(t.get("ziel"))[0])
                    except ValueError:
                        pass
            if w.get("stil") == "kodiskin" and (w.get("kodiskin") or {}).get("id"):
                skin.add(w["kodiskin"]["id"])
        # Kodi nur, wenn es schon genutzt wurde – sonst legte schon das Ansehen leere Kodi-Ordner an
        kodi = self._kodiaddons() if getattr(self.app, "kodi_addons", None) or os.path.isdir(os.path.join(self.app.datenordner, "kodi")) else None
        return speicher.Speicher(self.app.datenordner, kodi, getattr(self.app, "nutzung", None), reiter, skin)

    @staticmethod
    def _speicher_tage(wert):
        try:
            tage = int(wert or speicher.TAGE_STANDARD)
        except (TypeError, ValueError):
            tage = speicher.TAGE_STANDARD
        return max(1, min(3650, tage))

    def speicher_lesen(self, werte):
        return 200, "application/json", self._speicher_verwalter().uebersicht(self._speicher_tage(werte.get("tage")))

    def speicher_post(self, pfad, koerper):
        try:
            daten = json.loads(koerper.decode("utf-8") or "{}")
        except (ValueError, UnicodeDecodeError):
            return 400, "application/json", {"fehler": "JSON erwartet"}
        if pfad != "/api/speicher/aufraeumen" or not isinstance(daten, dict) or not isinstance(daten.get("ids"), list):
            return 400, "application/json", {"fehler": "{ids: [...]} erwartet"}
        tage = self._speicher_tage(daten.get("tage"))
        s = self._speicher_verwalter()
        ergebnis = s.aufraeumen(daten["ids"], tage)
        return 200, "application/json", dict(ergebnis, uebersicht=s.uebersicht(tage))
