"""SpotWeb-Tools (Usenet): geprüfte Links zu Spotweb, Docker, Forks und Abgrenzung."""

from . import spotweb_tools


class SpotwebToolsMixin:

    def usenet_tools_lesen(self):
        return 200, "application/json", spotweb_tools.zustand()

    def spotweb_tools_lesen(self):
        return self.usenet_tools_lesen()
