"""SucheGlobalMixin: Stufe 2 der globalen Inhaltssuche im Hauptmenue (G2) - XDCC, Easynews, Ab 18,
Dateisuche (vier Engines) und YouTube gleichzeitig durchsuchen. Stufe 1 (Filme/Serien, Radio, Live-TV)
laeuft bereits live beim Tippen direkt im Frontend (G1) - diese Route hier ist bewusst nur fuer die
langsamen/kontogebundenen Quellen, die nie automatisch beim Tippen feuern duerfen.

  GET /api/suche_global?q=    einmalig auf Klick "Weitere Quellen durchsuchen"

Urspruenglich als eigenstaendiges Modul geplant; _usenet_suche()/_indexer_suche() sind aber bereits
vorhandene Mixin-Methoden (brauchen self.app/self.INDEXER_KATEGORIEN) - deshalb direkt als Mixin-Methode
umgesetzt statt sie zu duplizieren.
"""

from concurrent.futures import ThreadPoolExecutor

from . import crawler, easynews, xdcc

MAX_TREFFER_JE_QUELLE = 5
ZEITGRENZE_JE_QUELLE = 15.0  # grosszuegig, weil XDCC (IRC) und Dateisuche-Verzeichnisse (Websuche) selbst
                             # schon bis zu 20-40s eigene Zeitgrenzen haben - zu knapp wuerde sie oefter
                             # als "Zeitueberschreitung" statt mit ihrem echten Ergebnis zurueckkommen


def _mit_zielen(antwort):
    """treffer + ziele (eingetragene NZB-Downloader) statt nur treffer - fuer usenetZeile()/indexerZeile()."""
    return {"treffer": antwort["treffer"], "ziele": antwort.get("ziele") or []}


class SucheGlobalMixin:

    def _suche_global_aufgaben(self, text, ab18_schluessel):
        app = self.app
        daten = app.verwaltung.daten() if app.verwaltung else {}
        aufgaben = [
            ("xdcc", "XDCC", lambda: xdcc.suchen_alle(text, eigene=xdcc.eigene_pruefe(daten))[0]),
            ("easynews", "Easynews", lambda: easynews.suchen(*easynews.zugang(daten), text, ab18=app.ab18.freigegeben)["treffer"]),
            ("youtube", "YouTube", lambda: app.youtube.suchen(text)),
            # Usenet/Indexer liefern zusaetzlich "ziele" (eingetragene NZB-Downloader) - das Frontend (G3)
            # braucht das fuer dieselben "→ Downloader"-Knoepfe wie die normale Dateisuche-Zeile.
            ("dateisuche_usenet", "Dateisuche: Usenet", lambda: _mit_zielen(self._usenet_suche(text))),
            ("dateisuche_ftp", "Dateisuche: FTP", lambda: crawler.ftp_suchen(text)["treffer"]),
            ("dateisuche_verzeichnisse", "Dateisuche: Verzeichnisse", lambda: crawler.verzeichnisse_suchen(text)),
            ("dateisuche_indexer", "Dateisuche: Indexer", lambda: _mit_zielen(self._indexer_suche(text))),
        ]
        # Ab 18 nur, wenn BEIDE Zugriffssperren explizit geprueft sind (Profil-Recht UND Konto-Freigabe/
        # PIN-Sitzung) - eine andere Route als /api/ab18/... prueft das nicht automatisch. Nicht erfuellt:
        # der Zweig wird gar nicht erst aufgenommen, kein Fehler, kein PIN-Prompt.
        if self.darf("ab18") and app.ab18.entsperrt(ab18_schluessel):
            aufgaben.append(("ab18", "Ab 18",
                lambda: [v for e in app.ab18.suche(text)["ergebnisse"] for v in e.get("videos", [])]))
        return aufgaben

    def suche_global_lesen(self, werte, kopf):
        text = " ".join(str(werte.get("q", "")).split())[:200]
        if len(text) < 2:
            return 200, "application/json", {"quellen": []}
        ab18_schluessel = (kopf or {}).get("X-Ab18")
        aufgaben = self._suche_global_aufgaben(text, ab18_schluessel)

        def eine(aufgabe):
            quelle, name, funktion = aufgabe
            try:
                ergebnis = funktion()
                zusatz = {} if isinstance(ergebnis, list) else {k: v for k, v in ergebnis.items() if k != "treffer"}
                treffer = ergebnis if isinstance(ergebnis, list) else ergebnis["treffer"]
                return dict(zusatz, quelle=quelle, name=name, fehler="", treffer=list(treffer)[:MAX_TREFFER_JE_QUELLE])
            except Exception as fehler:  # eine Quelle darf die anderen nicht aufhalten
                return {"quelle": quelle, "name": name, "fehler": str(fehler)[:300], "treffer": []}

        # Kein "with"/shutdown(wait=True): das wuerde beim Verlassen auf JEDEN Thread warten, auch auf
        # einen, dessen Ergebnis wir unten schon per Zeitgrenze aufgegeben haben - der Sinn der Zeitgrenze
        # (eine haengende Quelle darf die Antwort nicht aufhalten) waere sonst wieder hinfaellig. Ein
        # aufgegebener Thread laeuft im Hintergrund zu Ende und verschwindet dann von selbst.
        pool = ThreadPoolExecutor(max_workers=min(8, len(aufgaben)))
        futures = {pool.submit(eine, a): a for a in aufgaben}
        ergebnisse = []
        for future, aufgabe in futures.items():
            quelle, name, _ = aufgabe
            try:
                ergebnisse.append(future.result(timeout=ZEITGRENZE_JE_QUELLE))
            except Exception as fehler:  # Zeitueberschreitung oder sonstiger Ausfall des Threads selbst
                ergebnisse.append({"quelle": quelle, "name": name, "fehler": "Zeitüberschreitung" if
                                   "timeout" in type(fehler).__name__.lower() else str(fehler)[:300], "treffer": []})
        pool.shutdown(wait=False)
        ergebnisse.sort(key=lambda e: [a[0] for a in aufgaben].index(e["quelle"]))
        return 200, "application/json", {"quellen": ergebnisse}
