"""SuchenMixin-Mixin
"""

import time  # noqa: F401 - Tests patchen oberflaeche_suchen.time

from .oberflaeche_grund import (
    MAX_TREFFER,
    SPRACHNAMEN,
    __version__,
    _datum,
    easynews,
    filtern,
    heimlinks,
    json,
    log,
    sprachen,
    stremio,
    such_titel,
    urllib,
)
from .oberflaeche_suchen_livetv import SuchenLivetvMixin

class SuchenMixin(SuchenLivetvMixin):

    # --- Easynews (eigener Tab, Zugangsdaten aus einstellungen.easynews) -------
    def _easynews_zugang(self):
        return easynews.zugang(self.app.verwaltung.daten() if self.app.verwaltung else {})

    def easynews_lesen(self, pfad, werte):
        benutzer, passwort = self._easynews_zugang()
        try:
            if pfad == "/api/easynews":
                return 200, "application/json", {"zugang": bool(benutzer and passwort), "benutzer": benutzer,
                                                 "arten": easynews.ARTEN, "aufloesungen": list(easynews.AUFLOESUNGEN),
                                                 "sortierungen": list(easynews.SORTIERUNGEN), "alter": list(easynews.ALTER_STUFEN), "mitglieder": easynews.MITGLIEDER}
            if pfad == "/api/easynews/suche":
                r = easynews.suchen(benutzer, passwort, werte.get("q", ""), werte.get("art", "VIDEO"),
                                    werte.get("sort", "relevanz"), werte.get("aufl", ""), werte.get("seite", 1),
                                    ab18=self.app.ab18.freigegeben, min_mb=werte.get("min_mb", ""),
                                    max_mb=werte.get("max_mb", ""), alter=werte.get("alter", ""))
                for t in r["treffer"]:
                    t["badges"] = self.app.badges.zuordnen(t["name"])
                return 200, "application/json", r
            if pfad == "/api/easynews/gruppen":  # Gruppen durchsuchen (eigenes Konto; ohne Zugangsdaten Fehler)
                r = easynews.gruppen_suchen(benutzer, passwort, werte.get("q", ""), werte.get("sort", "anzahl"), werte.get("ns", ""),
                                            ab18=self.app.ab18.freigegeben)
                for t in r["treffer"]:
                    t["badges"] = self.app.badges.zuordnen(t["name"])
                r["sortierungen"] = easynews.GRUPPEN_SORT
                return 200, "application/json", r
            if pfad == "/api/easynews/bild":  # Vorschaubild mit Zugangsdaten ueber den Server
                url = werte.get("url", "")
                if not easynews.erlaubt(url):
                    return 400, "application/json", {"fehler": "nur Bilder von easynews.com"}
                anfrage = urllib.request.Request(url, headers=easynews.kopf(benutzer, passwort))
                with urllib.request.urlopen(anfrage, timeout=20) as a:
                    return 200, a.headers.get_content_type() or "image/jpeg", a.read(2 * 1024 * 1024)
        except (easynews.EasynewsFehler, ValueError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        except (urllib.error.URLError, OSError) as fehler:
            return 502, "application/json", {"fehler": "Bild nicht ladbar: %s" % getattr(fehler, "reason", fehler)}
        return 404, "application/json", {"fehler": "nicht gefunden"}

    def easynews_post(self, pfad, koerper):
        try:
            daten = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(daten, dict):
                raise ValueError("JSON-Objekt erwartet")
            if pfad == "/api/easynews/zugang":
                if not self.app.verwaltung:
                    raise ValueError("Nutzerdaten nicht verfügbar")
                benutzer, passwort = str(daten.get("user") or "").strip(), str(daten.get("pass") or "")

                def setzen(d):
                    alt = d.setdefault("einstellungen", {}).setdefault(easynews.KONTO, {})
                    alt["user"] = benutzer
                    if passwort:
                        alt["pass"] = passwort
                self.app.verwaltung.aendern(setzen)  # Rezepte easynews-finder/-aufloeser gleich nutzbar
                return self.easynews_lesen("/api/easynews", {})
            if pfad == "/api/easynews/abspielen":
                url = str(daten.get("stream") or "")
                if not easynews.erlaubt(url):
                    raise ValueError("Nur Easynews-Adressen")
                benutzer, passwort = self._easynews_zugang()
                k = easynews.kopf(benutzer, passwort)
                return 200, "application/json", {"url": "api/wiedergabe/" + self._wiedergabe_merken(
                    url, {"Authorization": k["Authorization"]}, ["easynews.com"])}
        except (ValueError, UnicodeDecodeError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        return 404, "application/json", {"fehler": "nicht gefunden"}

    # --- Startseite ------------------------------------------------------------
    def start_lesen(self, kopf):
        """Kurzstand fuer die Startseite, ohne Abrufe bei Diensten (schnell)."""
        app = self.app
        host = (kopf.get("Host") if kopf is not None else "") or "127.0.0.1"
        basis = "http://%s/%s" % (host, app.token + "/" if app.token else "")
        waechter = app.waechter.zustand()
        laufend = sum(1 for a in app.xdcc.zustand()["auftraege"] if a.get("laeuft")) + \
            sum(1 for a in app.youtube_speichern.zustand()["auftraege"] if a.get("laeuft"))
        t = app.telegram.zustand()
        daten = app.verwaltung.daten() if app.verwaltung else {}
        https = ""
        if app.https_port:
            name = host.split("]")[0] + "]" if host.startswith("[") else (host.rsplit(":", 1)[0] if host.count(":") == 1 else host)
            https = "https://%s:%d/%s" % (name, app.https_port, app.token + "/" if app.token else "")
        return {"version": __version__, "addon": basis + "manifest.json", "m3u": basis + "tv.m3u", "epg": basis + "epg.xml.gz",
                "https": https, "https_fingerabdruck": app.https_fingerabdruck,
                "heimnetz": bool(app.token), "anbieter": len(daten.get("anbieter") or {}) + len(getattr(app.kette, "module", [])),
                "eigene_anbieter": len(daten.get("anbieter") or {}),
                "waechter": {"anzahl": len(waechter["anbieter"]), "gestoert": waechter["gestoert"]}, "downloads": laufend,
                "telegram": {"laeuft": t["laeuft"], "bot": t["bot"]},
                "ftp": {"laeuft": app.ftp_server.laeuft, "adresse": app.ftp_server.zustand(self._ftp_adresse())["adresse"]},
                "pihole": any(getattr(c, "typ", "") == "pihole" for c in (app.dienste or {}).values()),
                "update": app.aktualisierung.letzte or {}}

    # --- Filter -------------------------------------------------------------
    def _finder_anbieter(self):
        gesehen, liste = set(), []
        for m in self.app.kette.rolle("finder"):
            if m.konto not in gesehen:
                gesehen.add(m.konto)
                liste.append({"id": m.konto, "name": self.app.anbieter_namen.get(m.konto, m.name)})
        return liste

    def filter_lesen(self):
        return {
            "filter": self.app.filter,
            "aktiv": filtern.aktiv(self.app.filter),
            "optionen": {
                "anbieter": self._finder_anbieter(),
                "sprachen": [{"id": k, "name": n} for k, n in SPRACHNAMEN.items()],
                "qualitaeten": list(filtern.QUALITAETEN),
                "sortierungen": [{"id": k, "name": n} for k, n in filtern.SORTIERUNGEN.items()],
                "bilder": any("metadaten" in m.gibt for m in self.app.kette.rolle("anreicherer")),
            },
        }

    def filter_speichern(self, koerper):
        try:
            neu = filtern.pruefe(json.loads(koerper.decode("utf-8") or "{}"))
        except (ValueError, UnicodeDecodeError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        if self.app.filter_speichern:
            self.app.filter_speichern(neu)
        self.app.filter = neu
        log.info("Filter gespeichert%s", " (aktiv)" if filtern.aktiv(neu) else "")
        return 200, "application/json", self.filter_lesen()

    # --- Heim-Links ------------------------------------------------------------
    def links_lesen(self):
        return {"links": self.app.links, "gruppen": heimlinks.gruppiert(self.app.links),
                "vorschlaege": heimlinks.VORSCHLAEGE}

    def links_speichern(self, koerper):
        try:
            self.app.setze_links(json.loads(koerper.decode("utf-8") or "[]"))
        except (ValueError, UnicodeDecodeError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        log.info("Heim-Links gespeichert (%d)", len(self.app.links))
        return 200, "application/json", self.links_lesen()


    # --- Suche und Streams ----------------------------------------------------
    def suche(self, text, art):
        text = " ".join(str(text).split())[:200]
        if len(text) < 2:
            return {"treffer": [], "facetten": filtern.facetten([]), "gesamt": 0,
                    "aktiv": filtern.aktiv(self.app.filter)}
        art = "serie" if art == "serie" else "film"
        gefunden = self.app.kette.suche({"text": text, "titel": text, "art": art})
        liste = filtern.treffer_anwenden(gefunden, self.app.filter)[:MAX_TREFFER]
        return {"treffer": [self._karte(t) for t in liste], "facetten": filtern.facetten(gefunden),
                "gesamt": len(gefunden), "aktiv": filtern.aktiv(self.app.filter)}

    def _karte(self, t):
        anbieter_id = t.get("_anbieter", "")
        return {
            "id": stremio.treffer_zu_id(t),
            "titel": str(t.get("titel", "")),
            "such_titel": such_titel(t.get("titel")),
            "anbieter": anbieter_id,
            "anbieter_name": self.app.anbieter_namen.get(anbieter_id, t.get("quelle", "")),
            "bild": str(t.get("poster") or ""),
            "jahr": filtern.jahr_von(t) or "",
            "datum": _datum(t),
            "sprachen": [sprachen.anzeige([c]) or c for c in sprachen.audio_von(t)],
            "genres": filtern.genres_von(t),
            "qualitaet": filtern.qualitaet(t.get("aufloesung")) or "",
            "aufloesung": str(t.get("aufloesung") or ""),
            "groesse": stremio._groesse(t),
        }

    def streams(self, stremio_id):
        treffer = stremio.id_zu_treffer(stremio_id) if stremio_id.startswith(stremio.ID_PRAEFIX) else None
        if not treffer:
            return {"streams": []}
        paare = filtern.streams_anwenden([(treffer, s) for s in self.app.kette.aufloesen(treffer)],
                                         self.app.filter)
        domains = self.app.debrid.hoster()
        liste = [self._torrent_debrid(self._debrid_markieren(self._stream_eintrag(t, s), s, domains),
                                      t.get("staffel"), t.get("folge"), t.get("titel")) for t, s in paare]
        return {"streams": self._badges(self._ausschliessen(liste)), "downloader": self._downloader(liste)}
