"""Routen fuer Release-Infos (xREL, predb.net, OFDb-Link) und Musik (SoundCloud, Mixcloud).

  GET  /api/szene                      {xrel, predb, ofdb}  Einstellung (ab Werk beide aus)
  POST /api/szene/einstellung          {xrel?, predb?}
  GET  /api/szene/releases             ?titel=&jahr=&folge=&deutsch=1  nur eingeschaltete Quellen, mit Bremse und Zwischenspeicher
  GET  /api/szene/nfo                  ?release=  Adressen der NFO bei predb.net (H0rSt laedt sie nicht selbst)
  GET  /api/ofdb                       ?id=tt…&titel=  Adresse der OFDb-Suche (nur ein Link)
  GET  /api/wiedergabe-check           Quellenzugang aus den eigenen Anbietern (Formatpruefung macht der Browser)
  GET  /api/musik                      {reihen, soundcloud: Schluessel gesetzt?}
  GET  /api/musik/suche                ?quelle=mixcloud|soundcloud&q=&art=cloudcast|user
  GET  /api/musik/widget               ?url=  -> {src} (Mixcloud-/SoundCloud-Widget; sonst 400)
  GET  /api/musik/reihe                ?id=  Eintraege einer eigenen Reihe
  POST /api/musik/reihe                {aktion: neu|loeschen, name?, url?|id?}
  POST /api/musik/schluessel           {client_id, client_secret}  (leer entfernt); Antwort nennt nur, ob gesetzt
Kinderprofile kommen an keinen dieser Pfade (kinder.py: Positivliste); Release-Infos brauchen das Recht "downloads"."""

import json

from . import musik_dienste as md, szene_infos as si


class _SzeneMusikMixin:
    def _daten(self):
        return self.app.verwaltung.daten() if self.app.verwaltung else {}

    def wiedergabe_check_lesen(self):
        from . import wiedergabe_check
        return 200, "application/json", wiedergabe_check.quellen(self._daten())

    def szene_lesen(self, pfad, werte):
        try:
            if pfad == "/api/szene":
                return 200, "application/json", dict(si.einstellung(self._daten()), ofdb=True)
            if pfad == "/api/szene/releases":
                einst = si.einstellung(self._daten())
                if not (einst["xrel"] or einst["predb"]):
                    return 200, "application/json", {"treffer": [], "fehler": {}, "aktiv": einst, "suche": ""}
                return 200, "application/json", self.app.szene.releases(einst, werte.get("titel", ""), werte.get("jahr", ""), werte.get("folge", ""),
                                                                         werte.get("deutsch") in ("1", "true"))
            if pfad == "/api/szene/nfo":
                if not si.einstellung(self._daten())["predb"]:
                    return 400, "application/json", {"fehler": "predb.net ist ausgeschaltet"}
                return 200, "application/json", self.app.szene.predb_nfo(werte.get("release", ""))
            if pfad == "/api/ofdb":
                return 200, "application/json", {"url": si.ofdb_link(werte.get("id", ""), werte.get("titel", ""))}
        except si.SzeneFehler as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        return 404, "application/json", {"fehler": "nicht gefunden"}

    def szene_post(self, pfad, koerper):
        if pfad != "/api/szene/einstellung" or not self.app.verwaltung:
            return 404, "application/json", {"fehler": "nicht gefunden"}
        try:
            w = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(w, dict):
                raise si.SzeneFehler("JSON-Objekt erwartet")
            return 200, "application/json", self.app.verwaltung.bearbeiten(lambda d: si.einstellung_aendern(d, w))
        except (ValueError, UnicodeDecodeError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}

    def musik_lesen(self, pfad, werte):
        daten = self._daten()
        profil = self._sehen_profil()
        m = self.app.musik
        try:
            if pfad == "/api/musik":
                return 200, "application/json", {"reihen": md.reihen_lesen(daten, profil), "soundcloud": bool(md.zugang(daten)[0])}
            if pfad == "/api/musik/suche":
                q = werte.get("q", "")
                if werte.get("quelle") == "soundcloud":
                    return 200, "application/json", {"treffer": m.soundcloud_suche(daten, q)}
                return 200, "application/json", {"treffer": m.mixcloud_suche(q, werte.get("art", "cloudcast"))}
            if pfad == "/api/musik/widget":
                url = werte.get("url", "")
                try:
                    art, key = md.mixcloud_pfad(url)
                    return 200, "application/json", {"src": md.mixcloud_widget(key), "quelle": "mixcloud", "art": art}
                except md.MusikFehler:
                    art, _ = md.soundcloud_adresse(url)
                    return 200, "application/json", {"src": md.soundcloud_widget(url), "quelle": "soundcloud", "art": art}
            if pfad == "/api/musik/reihe":
                r = next((x for x in md.reihen_lesen(daten, profil) if x.get("id") == werte.get("id")), None)
                if not r:
                    return 404, "application/json", {"fehler": "Reihe nicht gefunden"}
                if r["quelle"] == "mixcloud":
                    eintraege = m.mixcloud_reihe(r["art"], r["url"].replace("https://www.mixcloud.com", ""))
                else:
                    eintraege = m.soundcloud_reihe(daten, r["art"], r["url"])
                return 200, "application/json", {"reihe": r, "treffer": eintraege}
        except md.MusikFehler as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        return 404, "application/json", {"fehler": "nicht gefunden"}

    def musik_post(self, pfad, koerper):
        if not self.app.verwaltung:
            return 503, "application/json", {"fehler": "Nutzerdaten nicht verfügbar"}
        profil = self._sehen_profil()
        try:
            w = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(w, dict):
                raise md.MusikFehler("JSON-Objekt erwartet")
            if pfad == "/api/musik/schluessel":
                return 200, "application/json", self.app.verwaltung.bearbeiten(lambda d: md.zugang_einstellen(d, w.get("client_id"), w.get("client_secret")))
            if pfad == "/api/musik/reihe":
                if w.get("aktion") == "neu":
                    return 200, "application/json", self.app.verwaltung.bearbeiten(lambda d: md.reihe_anlegen(d, profil, w.get("name"), w.get("url")))
                if w.get("aktion") == "loeschen":
                    return 200, "application/json", self.app.verwaltung.bearbeiten(lambda d: md.reihe_loeschen(d, profil, str(w.get("id") or "")))
        except (ValueError, UnicodeDecodeError) as fehler:  # MusikFehler ist ein ValueError
            return 400, "application/json", {"fehler": str(fehler)}
        return 404, "application/json", {"fehler": "nicht gefunden"}
