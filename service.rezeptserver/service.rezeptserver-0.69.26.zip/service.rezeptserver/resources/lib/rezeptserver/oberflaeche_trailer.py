"""Trailer fuers Netflix-Banner: GET /api/trailer?typ=movie|series&id=tt…  ->  {id: YouTube-Kennung oder "", quelle: tmdb|cinemeta|""}

TMDb-Videos haben Vorrang (mit eingetragenem Schluessel), Cinemeta ist der Rueckfall. Ergebnisse (auch "keiner") bleiben im Speicher,
damit das Banner beim Blaettern nicht jedes Mal fragt. Fehler sind nie ein Fehler fuer die Seite: dann gibt es einfach keinen Trailer.
"""

import logging
import re

from . import tmdb

log = logging.getLogger("rezeptserver")
_MAX = 500


class TrailerMixin:

    def trailer_lesen(self, werte):
        typ, sid = werte.get("typ", "movie"), str(werte.get("id", ""))
        if typ not in ("movie", "series") or not re.fullmatch(r"tt\d{1,10}", sid):
            return 400, "application/json", {"fehler": "typ (movie oder series) und IMDb-Kennung (tt…) angeben"}
        speicher = self.__dict__.setdefault("_trailer_speicher", {})
        if (typ, sid) in speicher:
            return 200, "application/json", speicher[(typ, sid)]
        antwort = {"id": "", "quelle": ""}
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        schluessel = tmdb.schluessel(daten)
        endgueltig = True
        if schluessel:
            try:
                kennung = self.app.tmdb.trailer(typ, sid, schluessel)
                if kennung:
                    antwort = {"id": kennung, "quelle": "tmdb"}
            except Exception as fehler:  # noqa: BLE001
                log.info("Trailer (TMDb) %s: %s", sid, fehler)
                endgueltig = False
        if not antwort["id"]:
            try:
                kennung = str(self.app.entdecken.details(typ, sid).get("trailer") or "")
                if kennung:
                    antwort = {"id": kennung, "quelle": "cinemeta"}
            except Exception as fehler:  # noqa: BLE001
                log.info("Trailer (Cinemeta) %s: %s", sid, fehler)
                endgueltig = False
        if endgueltig:
            if len(speicher) >= _MAX:
                speicher.clear()
            speicher[(typ, sid)] = antwort
        return 200, "application/json", antwort
