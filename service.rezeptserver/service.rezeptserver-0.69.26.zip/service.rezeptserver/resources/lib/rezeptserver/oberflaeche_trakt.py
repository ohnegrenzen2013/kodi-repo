"""Trakt.tv (trakt.py): verbinden per Geraete-Code und Merkliste, Verlauf und Weiterschauen abgleichen.

  GET  /api/trakt        Stand fuer das Profil der Anfrage {eingerichtet, verbunden, benutzer, zuletzt, fehler, geraet?}
  POST /api/trakt        {aktion: verbinden}  -> {code, url, bis, intervall}
                         {aktion: pruefen}    -> {fertig, warten, fehler?}  (bis der Code auf trakt.tv eingegeben ist)
                         {aktion: abgleichen} -> {herein, hinaus}
                         {aktion: trennen}
                         {aktion: listen}     -> {listen: [{id, name, anzahl}]}  eigene Trakt-Listen (ARVIO 2.3)
                         {aktion: zur_liste, liste, titel: [{typ, id}]} -> {ergebnis: [{id, typ, ergebnis, ok}]}
  POST /api/trakt/app    {client_id, client_secret}  Trakt-App des Servers (Recht "einstellungen"); leere client_id loescht
"""

from . import trakt
from .oberflaeche_grund import json


class TraktMixin:

    def _trakt_profil(self):
        ich = self.aktuelles_profil()
        return ich["id"] if ich else ""

    def trakt_lesen(self):
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        return 200, "application/json", self.app.trakt.stand(daten, self._trakt_profil())

    def trakt_post(self, pfad, koerper):
        if not self.app.verwaltung:
            return 503, "application/json", {"fehler": "Nutzerdaten nicht verfügbar"}
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(wunsch, dict):
                raise ValueError("JSON-Objekt erwartet")
            if pfad == "/api/trakt/app":
                return 200, "application/json", self.app.verwaltung.bearbeiten(lambda d: trakt.Trakt.app_setzen(d, wunsch))
            profil, t = self._trakt_profil(), self.app.trakt
            aktion = wunsch.get("aktion")
            if aktion == "verbinden":
                return 200, "application/json", t.verbinden_start(profil)
            if aktion == "pruefen":
                return 200, "application/json", t.verbinden_pruefen(profil)
            if aktion == "abgleichen":
                return 200, "application/json", t.abgleichen(profil)
            if aktion == "trennen":
                return 200, "application/json", t.trennen(profil)
            if aktion == "listen":
                return 200, "application/json", {"listen": t.eigene_listen(profil)}
            if aktion == "zur_liste":
                return 200, "application/json", {"ergebnis": t.zur_liste(profil, wunsch.get("liste"), wunsch.get("titel"))}
            raise ValueError("aktion: verbinden, pruefen, abgleichen, trennen, listen oder zur_liste")
        except (ValueError, UnicodeDecodeError) as fehler:  # TraktFehler ist ein ValueError
            return 400, "application/json", {"fehler": str(fehler)}

    def trakt_bei_bedarf(self, daten, profil):
        """Beim Oeffnen von Merkliste, Verlauf oder Weiterschauen: alle 15 Minuten im Hintergrund abgleichen."""
        t = getattr(self.app, "trakt", None)
        if t is not None and t.faellig(daten, profil):
            t.im_hintergrund(profil)
