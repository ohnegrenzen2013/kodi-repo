"""LocalDream (traum.py): Prompt Studio, Bilder erzeugen ueber Local Dream oder einen Bildserver, Galerie, Quellen.

  GET  /api/traum                 Server, aktiver Server, Quellen (eingebaut und eigene), KI-Chat (ohne Schluessel), Auftraege
  GET  /api/traum/studio          Begriffe, Szenen, Stimmungen, Figuren (mit eingetragenen Paketen)
  GET  /api/traum/empfehlung?chip=&abi=&gpu=   passende Local-Dream-Variante fuer diesen Prozessor
  GET  /api/traum/pruefen?id=     laeuft der Server? (Sampler, Modelle, Hochskalierer)
  GET  /api/traum/app             neueste Local-Dream-APKs (GitHub)
  GET  /api/traum/auftrag?id=&seit=   Fortschritt, Zwischenbild, fertige Bilder
  GET  /api/traum/galerie         alle Bilder mit Rezept; GET /api/traum/bild/<name> das Bild
  POST /api/traum/einrichten      {aktion: server_dazu|server_weg|aktiv|quelle_weg|chat|hochskalierer, …}
  POST /api/traum/quelle          {url} – erkennen und eintragen (GitHub, Paket, Bildserver, Seite)
  POST /api/traum/erzeugen        {server?, prompt, negativ, schritte, cfg, seed, sampler, breite, hoehe, vorgabe, anzahl, bild, maske, staerke}
  POST /api/traum/abbrechen       {id}; /hochskalieren {name, server?}; /hochskalierer {server?} (Pfad suchen)
  POST /api/traum/galerie_weg     {namen: [...]}; /modell {server, modell} (AUTOMATIC1111 & Co.); /chat {nachrichten}
  POST /api/traum/apk             {mit_filter, quelle?} – APK laden, die App installiert sie
"""

from . import magicwx
from .oberflaeche_grund import json, traum

_BILD = {".png": "image/png", ".jpg": "image/jpeg"}


class TraumMixin:

    def _traum_werte(self):
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        return traum.pruefe(daten.get(traum.SCHLUESSEL))

    def _traum_server(self, werte, kennung=None):
        kennung = kennung or werte["aktiv"]
        for s in werte["server"]:
            if s["id"] == kennung:
                return s
        raise traum.TraumFehler("Unbekannter Server")

    def traum_lesen(self, pfad, werte):
        t = self.app.traum
        try:
            e = self._traum_werte()
            if pfad == "/api/traum":
                return 200, "application/json", dict(traum.fuer_oberflaeche(e), auftraege=t.auftraege())
            if pfad == "/api/traum/studio":
                return 200, "application/json", traum.studio(e)
            if pfad == "/api/traum/empfehlung":
                return 200, "application/json", traum.empfehlung(werte.get("chip"), werte.get("abi"), werte.get("gpu"))
            if pfad == "/api/traum/pruefen":
                return 200, "application/json", traum.server_client(self._traum_server(e, werte.get("id"))).pruefen()
            if pfad == "/api/traum/modelle":
                client = traum.server_client(self._traum_server(e, werte.get("id")))
                if not hasattr(client, "modelle"):
                    raise traum.TraumFehler("Modellliste gibt es nur beim Local Dream Host")
                return 200, "application/json", client.modelle()
            if pfad == "/api/traum/tokenize":
                client = traum.server_client(self._traum_server(e, werte.get("id")))
                if not hasattr(client, "tokenize"):
                    raise traum.TraumFehler("Token-Zählung gibt es nur bei Local Dream")
                return 200, "application/json", client.tokenize(str(werte.get("prompt") or "")[:4000])
            if pfad == "/api/traum/app":
                if werte.get("quelle") == "promptstudio":
                    return 200, "application/json", {"apks": t.promptstudio_neueste(), "paket": traum.PS_PAKET}
                if werte.get("quelle") == "magicwx":
                    return 200, "application/json", {"apks": t.magicwx_neueste(), "paket": magicwx.PAKET}
                return 200, "application/json", {"apks": t.localdream_neueste(), "paket": traum.LD_PAKET}
            if pfad == "/api/traum/auftrag":
                return 200, "application/json", t.auftrag(werte.get("id"), werte.get("seit") or 0)
            if pfad == "/api/traum/galerie":
                return 200, "application/json", {"bilder": t.galerie()}
            if pfad.startswith("/api/traum/bild/"):
                return "lokal", t.pfad(pfad.rsplit("/", 1)[1])
        except traum.TraumFehler as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        except (traum.NetzFehler, ValueError) as fehler:
            return 502, "application/json", {"fehler": str(fehler)}
        return 404, "application/json", {"fehler": "nicht gefunden"}

    def traum_post(self, pfad, koerper):
        if not self.app.verwaltung:
            return 503, "application/json", {"fehler": "Nutzerdaten nicht verfügbar"}
        t = self.app.traum
        try:
            w = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(w, dict):
                raise traum.TraumFehler("JSON-Objekt erwartet")
            if pfad == "/api/traum/einrichten":
                e = self.app.verwaltung.bearbeiten(lambda d: traum.aendern(d, w))
                return 200, "application/json", traum.fuer_oberflaeche(e)
            if pfad == "/api/traum/quelle":
                quelle = t.erkennen(w.get("url"))
                e = self.app.verwaltung.bearbeiten(lambda d: traum.quelle_eintragen(d, quelle))
                return 200, "application/json", dict(traum.fuer_oberflaeche(e), erkannt={k: v for k, v in quelle.items() if k != "paket"})
            e = self._traum_werte()
            if pfad == "/api/traum/erzeugen":
                server = self._traum_server(e, w.get("server"))
                return 200, "application/json", {"id": t.auftrag_neu(server, traum.wunsch_pruefen(w))}
            if pfad == "/api/traum/abbrechen":
                t.abbrechen(str(w.get("id") or ""))
                return 200, "application/json", {"ok": True}
            if pfad == "/api/traum/hochskalieren":
                server = self._traum_server(e, w.get("server"))
                t.pfad(w.get("name"))
                hoch = e["hochskalierer"] if server["art"] == "localdream" else str(w.get("hochskalierer") or "")
                return 200, "application/json", {"id": t.auftrag_neu(server, {"opencl": w.get("opencl") is True}, "hochskalieren",
                                                                      quelle=w["name"], pfad=hoch)}
            if pfad == "/api/traum/hochskalierer":
                server = self._traum_server(e, w.get("server"))
                if server["art"] != "localdream":
                    raise traum.TraumFehler("Den Pfad braucht nur Local Dream")
                d = t.hochskalierer_suchen(server, w.get("opencl") is True)
                if d["pfade"]:
                    self.app.verwaltung.bearbeiten(lambda daten: traum.aendern(daten, {"aktion": "hochskalierer", "pfad": d["pfade"][0]}))
                return 200, "application/json", d
            if pfad == "/api/traum/galerie_weg":
                for name in (w.get("namen") or [])[:500]:
                    t.weg(str(name))
                return 200, "application/json", {"bilder": t.galerie()}
            if pfad == "/api/traum/modell":
                server = self._traum_server(e, w.get("server"))
                client = traum.server_client(server)
                if server["art"] == "a1111":
                    client.modell(str(w.get("modell") or ""))
                elif server.get("host"):
                    client.waehlen(str(w.get("modell") or ""), int(w.get("breite") or 1024), int(w.get("hoehe") or 1024))
                else:
                    raise traum.TraumFehler("Modelle wählt Local Dream in der App – im Host-Modus hier")
                return 200, "application/json", {"ok": True}
            if pfad == "/api/traum/host":
                server = self._traum_server(e, w.get("server"))
                if not server.get("host"):
                    raise traum.TraumFehler("Kein Local Dream Host")
                client = traum.server_client(server)
                aktion = str(w.get("aktion") or "status")
                if aktion == "status":
                    return 200, "application/json", client.status()
                if aktion == "stop":
                    return 200, "application/json", client.stoppen(str(w.get("modell") or ""))
                if aktion == "select":
                    return 200, "application/json", client.waehlen(str(w.get("modell") or ""),
                                                                   int(w.get("breite") or 1024), int(w.get("hoehe") or 1024))
                raise traum.TraumFehler("aktion: status, stop oder select")
            if pfad == "/api/traum/chat":
                return 200, "application/json", t.chat(e["chat"], w.get("nachrichten"))
            if pfad == "/api/traum/apk":
                if w.get("quelle") == "promptstudio":
                    apk = t.promptstudio_neueste()[0]
                    return 200, "application/json", {"pfad": t.apk_laden(apk, self.app.datenordner), "name": apk["name"],
                                                      "paket": traum.PS_PAKET}
                if w.get("quelle") == "magicwx":
                    apk = t.apk_waehlen(t.magicwx_neueste(), w.get("mit_filter") is not False)
                    if not apk:
                        raise traum.TraumFehler("Keine passende MagicWX-APK")
                    return 200, "application/json", {"pfad": t.apk_laden(apk, self.app.datenordner), "name": apk["name"],
                                                      "paket": magicwx.PAKET}
                apks = None
                for q in e["quellen"]:
                    if q["id"] == w.get("quelle") and q.get("apks"):
                        apks = q["apks"]
                apk = t.apk_waehlen(apks or t.localdream_neueste(), w.get("mit_filter") is not False)
                if not apk:
                    raise traum.TraumFehler("Keine passende APK")
                return 200, "application/json", {"pfad": t.apk_laden(apk, self.app.datenordner), "name": apk["name"],
                                                  "paket": traum.LD_PAKET if not w.get("quelle") else ""}
        except (ValueError, UnicodeDecodeError) as fehler:  # TraumFehler ist ein ValueError
            return 400, "application/json", {"fehler": str(fehler)}
        except traum.NetzFehler as fehler:
            return 502, "application/json", {"fehler": str(fehler)}
        return 404, "application/json", {"fehler": "nicht gefunden"}
