"""Understand-Anything (understand_anything.py): KI-Coding-Skills fuer externe KI-Werkzeuge auf diesem
Rechner installieren/aktualisieren/entfernen. Installieren/aktualisieren/entfernen brauchen zusaetzlich
zum Recht "einstellungen" den Schalter understand_anything_erlaubt (Nutzerdaten) - gleiche
zwei-Stufen-Pruefung wie ki_automatisierung_erlaubt, da diese Aktion Fremdcode vom offiziellen
Installationsskript auf dem Host ausfuehrt. Schalter + Plattform werden wie ki_automatisierung_erlaubt
(oberflaeche_vorschlaege.py) ueber eine eigene Aktion gesetzt, nicht ueber das generische
Einstellungen-Schema (die Kategorie "ki" ist "eigen": True, rein eigenstaendig gerendert).

  GET  /api/understand_anything   Zustand (laeuft/fertig/ok/aktion/ausgabe, erlaubt, plattform) + Plattformliste
  POST /api/understand_anything   {aktion: "einstellungen", an, plattform}
                                   {aktion: "installieren"|"aktualisieren"|"entfernen", plattform?}
"""

from . import understand_anything
from .oberflaeche_grund import json


class UnderstandAnythingMixin:

    def _understand_anything(self):
        if getattr(self.app, "understand_anything", None) is None:
            self.app.understand_anything = understand_anything.Installation()
        return self.app.understand_anything

    def _understand_anything_zustand(self):
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        zustand = self._understand_anything().zustand()
        zustand["plattformen"] = list(understand_anything.PLATTFORMEN)
        zustand["erlaubt"] = bool(daten.get("understand_anything_erlaubt"))
        zustand["plattform"] = daten.get("understand_anything_plattform") or "codex"
        return zustand

    def understand_anything_lesen(self):
        return 200, "application/json", self._understand_anything_zustand()

    def understand_anything_post(self, koerper):
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
        except ValueError:
            return 400, "application/json", {"fehler": "Ungültiges JSON"}
        aktion = wunsch.get("aktion")
        if aktion == "einstellungen":
            def setzen(d):
                d["understand_anything_erlaubt"] = wunsch.get("an") is True
                plattform = str(wunsch.get("plattform") or "")
                if plattform in understand_anything.PLATTFORMEN:
                    d["understand_anything_plattform"] = plattform
            self.app.verwaltung.bearbeiten(setzen)
            return 200, "application/json", self._understand_anything_zustand()
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        if not daten.get("understand_anything_erlaubt"):
            return 403, "application/json", {"fehler": "Understand-Anything ist in den Einstellungen nicht erlaubt."}
        plattform = str(wunsch.get("plattform") or "")
        auftrag = self._understand_anything()
        try:
            if aktion == "installieren":
                auftrag.installieren(plattform)
            elif aktion == "aktualisieren":
                auftrag.aktualisieren()
            elif aktion == "entfernen":
                auftrag.entfernen(plattform)
            else:
                return 400, "application/json", {"fehler": "Unbekannte Aktion"}
        except understand_anything.UnderstandAnythingFehler as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        return 200, "application/json", self._understand_anything_zustand()
