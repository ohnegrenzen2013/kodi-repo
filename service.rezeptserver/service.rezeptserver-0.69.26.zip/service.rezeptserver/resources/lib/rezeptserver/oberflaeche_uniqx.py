"""UNiQuanteX-Assistent: Analyse, KI-Generierung (optional) und Anwenden neuer Styles.

  GET  /api/uniqx/analyse?url=<url>          Design-Tokens aus einer App-URL extrahieren
  POST /api/uniqx/generieren                 KI-generierten CSS/JS-Diff anfordern (braucht claude_api_key)
  POST /api/uniqx/anwenden                   CSS-Block + STILE-Eintrag in die CSS-/JS-Teile schreiben
  GET/POST /api/uniqx/ollama_installieren    Ollama auf dem Server installieren (ollama_setup.py)
  GET/POST /api/uniqx/ollama_modell_holen    Modell per Ollama-Pull ziehen (Standard: QWEN_CODER_VORSCHLAG)
  GET      /api/uniqx/ollama_empfehlung?ram_mb=   Groessen-Vorschlag anhand RAM (ollama_setup.empfehlung)

Alle Endpunkte brauchen das Recht "einstellungen".
"""
import json as _json
import os
import re

from . import ki_anbieter as _ki
from . import ollama_setup
from . import seite as _seite
from . import uniqx_analyse


_STIL_NAMEN_EINTRAG = re.compile(r'\s*([a-z0-9]{1,16})\s*:\s*"([^"\\<>\n]{1,80})"\s*,?\s*')


def _stil_in_css(key, css):
    return re.search(rf"body\.stil-{re.escape(key)}(?![\w-])", css) is not None


def _stil_in_liste(key, liste):
    return re.search(rf'"{re.escape(key)}"', liste) is not None


def _stil_in_namen(key, namen):
    return re.search(rf"(?:^|[\s,{{]){re.escape(key)}\s*:", namen) is not None


class UniqxMixin:

    # --- Analyse ---------------------------------------------------------------

    def uniqx_lesen(self, werte):
        url = (werte.get("url") or "").strip()
        if not url:
            return 400, "application/json", {"fehler": "Parameter url fehlt."}
        name = (werte.get("name") or "").strip()
        try:
            ergebnis = uniqx_analyse.analysiere(url, name=name)
        except uniqx_analyse.AnaliseFehler as e:
            return 400, "application/json", {"fehler": str(e)}
        except OSError as e:
            return 502, "application/json", {"fehler": f"Netzwerkfehler: {e}"}
        konfig = self.app.verwaltung.daten() if self.app.verwaltung else {}
        ergebnis["ki_verfuegbar"] = self._ki_verfuegbar(konfig)
        return 200, "application/json", ergebnis

    # --- KI-Generierung (optional) --------------------------------------------

    def uniqx_generieren(self, koerper):
        try:
            daten = _json.loads(koerper.decode("utf-8") or "{}")
        except (ValueError, UnicodeDecodeError):
            return 400, "application/json", {"fehler": "JSON-Fehler"}
        if not isinstance(daten, dict):
            return 400, "application/json", {"fehler": "JSON-Objekt erwartet"}

        konfig = self.app.verwaltung.daten() if self.app.verwaltung else {}
        if not self._ki_verfuegbar(konfig):
            return 503, "application/json", {
                "fehler": "Kein KI-Anbieter konfiguriert.",
                "hinweis": "Konfiguriere einen KI-Anbieter unter Einstellungen → KI & Werkzeuge.",
            }

        beispiel_key = "arvio"
        css_beispiel = self._uniqx_stil_beispiel(beispiel_key)

        key = daten.get('key', 'neu')
        prompt = (
            "Du bist ein CSS-Experte für das Projekt H0rSt (UNiQuanteX).\n\n"
            "Aufgabe: Erzeuge einen vollständigen UNiQuanteX-Stil basierend auf diesen Design-Tokens:\n\n"
            f"Key: {key}\n"
            f"Farben (häufigste zuerst): {', '.join(daten.get('farben', []))}\n"
            f"Fonts: {', '.join(daten.get('fonts', []))}\n"
            f"CSS-Custom-Properties aus :root: {_json.dumps(daten.get('props', {}), ensure_ascii=False)}\n\n"
            "Erzeuge:\n"
            "1. Den vollständigen CSS-Block `body.stil-<key> { ... }` mit allen nötigen CSS-Variablen "
            "(--grund, --flaeche, --akzent, --akzent-text, --text, --leise, --linie, --schatten, --bild-rund, "
            "--rl-rund, background, font-family). Orientiere dich am folgenden Beispiel:\n\n"
            f"```css\n{css_beispiel}\n```\n\n"
            "2. Den JavaScript-Eintrag für STILE (Array-Element) und STIL_NAMEN (Objekt-Eintrag).\n\n"
            "3. Einen minimalen Python-Stub als Hinweis für den Entwickler (kein vollständiges Modul), "
            "der zeigt, welche Felder in einem neuen `rezeptserver/<key>.py`-Mixin angelegt werden müssten. "
            "Nur Klassen- und Methoden-Gerüst, keine Implementierung.\n\n"
            "Antworte ausschließlich mit JSON:\n"
            '{"css": "...", "stile_eintrag": "...", "stil_name": "...", "python_stub": "..."}'
        )

        try:
            text = _ki.anfrage(prompt, konfig)
            m = re.search(r'\{.*\}', text, re.DOTALL)
            if not m:
                return 502, "application/json", {"fehler": "KI-Antwort enthält kein JSON.", "roh": text[:500]}
            diff = _json.loads(m.group(0))
            diff["analyse"] = daten
            return 200, "application/json", diff
        except _ki.KiAnbieterFehler as e:
            return 502, "application/json", {"fehler": str(e)}
        except (OSError, _json.JSONDecodeError, KeyError) as e:
            return 502, "application/json", {"fehler": f"KI-Fehler: {e}"}

    # --- Anwenden (CSS + JS schreiben) ----------------------------------------

    def uniqx_anwenden(self, koerper):
        try:
            daten = _json.loads(koerper.decode("utf-8") or "{}")
        except (ValueError, UnicodeDecodeError):
            return 400, "application/json", {"fehler": "JSON-Fehler"}
        if not isinstance(daten, dict):
            return 400, "application/json", {"fehler": "JSON-Objekt erwartet"}

        key = re.sub(r"[^a-z0-9]", "", str(daten.get("key", "")).lower())[:16]
        css_block = str(daten.get("css", "")).strip()
        stile_eintrag = str(daten.get("stile_eintrag", "")).strip()
        stil_name = str(daten.get("stil_name", "")).strip()

        if not key or not css_block:
            return 400, "application/json", {"fehler": "key und css sind Pflichtfelder."}
        namen = _STIL_NAMEN_EINTRAG.fullmatch(stil_name) if stil_name else None
        if "<" in css_block or (stil_name and (namen is None or namen.group(1) != key)):
            return 400, "application/json", {"fehler": "CSS oder STIL_NAMEN-Eintrag enthält nicht erlaubte Zeichen oder passt nicht zum Key."}

        basis = os.path.join(os.path.dirname(__file__), "statisch")
        css_pfad = os.path.join(basis, _seite.CSS_STIL_DATEI)
        js_pfad = os.path.join(basis, _seite.JS_STIL_DATEI)

        # Doppelter Eintrag? (ueber alle CSS-Teile, nicht nur den letzten)
        if _stil_in_css(key, _seite.css_lesen()):
            return 409, "application/json", {"fehler": f"Stil 'stil-{key}' existiert bereits in seite.css."}

        # CSS an den letzten Teil anhaengen (vor dem letzten Kommentar-Block oder ans Ende)
        with open(css_pfad, encoding="utf-8") as f:
            ziel_inhalt = f.read()
        marker = "/* ================= Ende UNiQuanteX"
        if marker in ziel_inhalt:
            ziel_inhalt = ziel_inhalt.replace(marker, f"{css_block}\n\n{marker}")
        else:
            ziel_inhalt += f"\n\n/* Stil {key} (UNiQuanteX) */\n{css_block}\n"
        with open(css_pfad, "w", encoding="utf-8") as f:
            f.write(ziel_inhalt)

        # JS: STILE und STIL_NAMEN erweitern (wenn Einträge mitgeliefert)
        js_geaendert = False
        if stile_eintrag and stil_name:
            with open(js_pfad, encoding="utf-8") as f:
                js_inhalt = f.read()
            stile_re = re.compile(r'(const STILE\s*=\s*\[)([^\]]+)(\])', re.DOTALL)
            namen_re = re.compile(r'(const STIL_NAMEN\s*=\s*\{)([^}]+)(\})', re.DOTALL)
            m_stile = stile_re.search(js_inhalt)
            m_namen = namen_re.search(js_inhalt)
            if m_stile and not _stil_in_liste(key, m_stile.group(2)):
                js_inhalt = stile_re.sub(
                    lambda m: m.group(1) + m.group(2).rstrip() + f',\n  "{key}"' + m.group(3),
                    js_inhalt, count=1
                )
                js_geaendert = True
            if m_namen and not _stil_in_namen(key, m_namen.group(2)):
                js_inhalt = namen_re.sub(
                    lambda m: m.group(1) + m.group(2).rstrip() + f',\n  {key}: {_json.dumps(namen.group(2), ensure_ascii=False)}' + m.group(3),
                    js_inhalt, count=1
                )
                js_geaendert = True
            if js_geaendert:
                with open(js_pfad, "w", encoding="utf-8") as f:
                    f.write(js_inhalt)

        return 200, "application/json", {
            "ok": True,
            "key": key,
            "css_geschrieben": True,
            "js_geschrieben": js_geaendert,
            "hinweis": "Tests ausführen: python -m unittest tests/test_ansichten.py -v",
        }

    # --- KI-Status ------------------------------------------------------------

    def uniqx_ki_status(self):
        konfig = self.app.verwaltung.daten() if self.app.verwaltung else {}
        return 200, "application/json", _ki.status(konfig)

    # --- KI-Konfiguration speichern ------------------------------------------

    def uniqx_ki_config(self, koerper):
        try:
            daten = _json.loads(koerper.decode("utf-8") or "{}")
        except (ValueError, UnicodeDecodeError):
            return 400, "application/json", {"fehler": "JSON-Fehler"}
        if not isinstance(daten, dict):
            return 400, "application/json", {"fehler": "JSON-Objekt erwartet"}

        _ERLAUBTE = {
            "ki_modus", "ki_cloud_backend", "ki_cloud_url", "ki_cloud_key",
            "ki_cloud_modell", "ki_lokal_backend", "ki_lokal_url", "ki_lokal_modell",
            "ki_remote_url", "ki_remote_key", "ki_remote_modell",
        }
        unbekannt = set(daten) - _ERLAUBTE - {"claude_api_key"}
        if unbekannt:
            return 400, "application/json", {"fehler": f"Unbekannte Felder: {', '.join(sorted(unbekannt))}"}

        def _aktualisieren(konfig):
            konfig.update(daten)

        try:
            self.app.verwaltung.bearbeiten(_aktualisieren)
        except Exception as e:
            return 500, "application/json", {"fehler": f"Speichern fehlgeschlagen: {e}"}
        return 200, "application/json", {"ok": True}

    # --- Ollama: Server-Installation + Modell-Download ------------------------

    def _ollama_install(self):
        if getattr(self.app, "ollama_install", None) is None:
            self.app.ollama_install = ollama_setup.ServerInstallation()
        return self.app.ollama_install

    def _ollama_pull(self):
        if getattr(self.app, "ollama_pull", None) is None:
            self.app.ollama_pull = ollama_setup.ModellPull()
        return self.app.ollama_pull

    def uniqx_ollama_installieren_lesen(self):
        return 200, "application/json", self._ollama_install().zustand()

    def uniqx_ollama_installieren_post(self):
        try:
            self._ollama_install().starten()
        except ollama_setup.OllamaSetupFehler as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        return 200, "application/json", self._ollama_install().zustand()

    def uniqx_ollama_modell_lesen(self):
        return 200, "application/json", self._ollama_pull().zustand()

    def uniqx_ollama_empfehlung_lesen(self, werte):
        return 200, "application/json", ollama_setup.empfehlung(werte.get("ram_mb"))

    def uniqx_ollama_modell_post(self, koerper):
        try:
            daten = _json.loads(koerper.decode("utf-8") or "{}")
        except (ValueError, UnicodeDecodeError):
            return 400, "application/json", {"fehler": "JSON-Fehler"}
        konfig = self.app.verwaltung.daten() if self.app.verwaltung else {}
        url = konfig.get("ki_lokal_url") or _ki.OLLAMA_STANDARD
        try:
            self._ollama_pull().starten(url, daten.get("modell") if isinstance(daten, dict) else None)
        except ollama_setup.OllamaSetupFehler as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        return 200, "application/json", self._ollama_pull().zustand()

    # --- Hilfsmethoden --------------------------------------------------------

    def _ki_verfuegbar(self, konfig: dict) -> bool:
        modus = konfig.get("ki_modus", "cloud")
        if modus == "cloud":
            backend = konfig.get("ki_cloud_backend", "claude")
            if backend == "claude":
                return bool(konfig.get("claude_api_key"))
            return bool(konfig.get("ki_cloud_url"))
        elif modus == "lokal":
            return True
        elif modus == "remote":
            return bool(konfig.get("ki_remote_url"))
        return False

    def _uniqx_stil_beispiel(self, key: str) -> str:
        """Liest den CSS-Block für einen bestehenden Stil als Beispiel."""
        try:
            inhalt = _seite.css_lesen()
            m = re.search(
                rf'(body\.stil-{re.escape(key)}\s*\{{[^}}]+\}})',
                inhalt, re.DOTALL
            )
            return m.group(1)[:1500] if m else ""
        except OSError:
            return ""
