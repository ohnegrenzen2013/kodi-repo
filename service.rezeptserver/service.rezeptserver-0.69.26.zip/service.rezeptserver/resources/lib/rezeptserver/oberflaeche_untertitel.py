"""Zusaetzliche Untertitelquellen: Auslieferung der entpackten Dateien und Einstellungen."""

from .untertitel_quellen import UntertitelFehler


class UntertitelMixin:
    def untertitel_datei(self, name):
        quellen = getattr(self.app, "untertitel_quellen", None)
        if quellen is None:
            return 404, "text/plain", b""
        try:
            daten = quellen.datei(name)
        except UntertitelFehler:
            return 404, "text/plain", b""
        typ = "text/vtt; charset=utf-8" if name.endswith(".vtt") else "text/plain; charset=utf-8"
        return 200, typ, daten
