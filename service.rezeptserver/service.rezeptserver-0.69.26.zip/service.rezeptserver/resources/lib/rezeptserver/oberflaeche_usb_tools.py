"""USB-Tools: verschlüsselte Datenträger und VeraCrypt-Hilfen für USB Magic."""

from . import usb_tools


class UsbToolsMixin:

    def usb_tools_lesen(self):
        return 200, "application/json", usb_tools.zustand()
