"""UsenetStreamMixin: der Reiter "Usenet-Stream" (Usenet-Streaming-Modus, Logik in usenet_stream.py).

  GET  /api/usenet-stream           Pruefliste (was fehlt zum Streamen?), Werte des Modus, Stremio-Adresse
  GET  /api/usenet-stream/suche     Vorschau wie in Stremio: q, art=film|serie, staffel, folge -> geordnete Treffer
                                    mit Merkmalen, Sofort-Markierung und Abspiel-Adressen
  POST /api/usenet-stream/pruefen   Verbindungstest: NzbDAV/AltMount (API und WebDAV) und Newznab-Indexer
Zugangsdaten stehen in keiner Antwort. Das Pruefen braucht das Recht "downloads".
"""

from . import deutsch_wertung, filtern, usenet_stream


class UsenetStreamMixin:

    MAX_VORSCHAU = 40

    def _usenet_daten(self):
        return self.app.verwaltung.daten() if self.app.verwaltung else {}

    def usenet_stream_lesen(self, pfad, werte, kopf=None):
        app = self.app
        if pfad == "/api/usenet-stream":
            st = usenet_stream.status(self._usenet_daten(), app.dienste, app.ui, bool(app.rustnzb))
            st["werte"] = {k: v for k, v in (app.ui or {}).items() if k.startswith("usenet_") and "healthcheck" not in k}
            basis = app.eigene_basis(kopf or {}) if kopf else None
            st["manifest"] = (basis + "manifest.json") if basis else ""
            return 200, "application/json", st
        if pfad == "/api/usenet-stream/suche":
            return self._usenet_vorschau(werte)
        return 404, "application/json", {"fehler": "nicht gefunden"}

    def _usenet_vorschau(self, werte):
        app = self.app
        q = " ".join(str(werte.get("q") or "").split())[:120]
        if len(q) < 2:
            return 400, "application/json", {"fehler": "Suchbegriff zu kurz"}
        serie = werte.get("art") == "serie"
        anfrage = {"text": q, "titel": q, "art": "serie" if serie else "film", "ersatzsuche": True}
        try:
            staffel, folge = int(werte.get("staffel") or ""), int(werte.get("folge") or "")
        except ValueError:
            staffel = folge = None
        if serie and staffel is not None:
            anfrage.update(staffel=staffel, folge=folge, text="%s S%02dE%02d" % (q, staffel, folge))
        try:
            gefunden = app.kette.suche(anfrage)
            paare = app.kette.aufloesen_alle(filtern.treffer_anwenden(gefunden, app.filter))
            paare = filtern.streams_anwenden(paare, app.filter)
        except Exception as fehler:  # ein kaputter Anbieter soll die Vorschau nicht kippen
            return 502, "application/json", {"fehler": "Suche fehlgeschlagen: %s" % fehler}
        nzb = [p for p in paare if p[1].get("nzb") and p[1].get("url")]
        streamer = [(aid, c) for aid, c in sorted(app.dienste.items()) if getattr(c, "typ", "") in ("nzbdav", "altmount")]
        aktiv = usenet_stream.konfig(app.ui)
        cfg = aktiv or usenet_stream.konfig(dict(app.ui or {}, usenet_modus_an=True))
        sofort = usenet_stream.sofort_namen(streamer) if cfg["sofort"] and streamer else set()
        geordnet = usenet_stream.ordnen(nzb, cfg, sofort)
        geordnet = app.usenet_paare_pruefen(geordnet)
        kategorie = "TV" if serie else "Movies"
        ziele = ([("", "rustnzb")] if app.rustnzb else []) + [(aid, c.typ_name) for aid, c in streamer]
        zeilen = []
        for t, s in geordnet[:self.MAX_VORSCHAU]:
            m = t.get("usenet_stream") or usenet_stream.merkmale(t.get("titel"), t)
            dw = deutsch_wertung.wertung(t.get("titel"))
            zeilen.append({"deutsch": dw["labels"], "deutsch_punkte": dw["punkte"],
                           "titel": t.get("titel", ""), "groesse": int(filtern.groesse_bytes(t) or 0),
                           "aufloesung": m.get("aufloesung", 0), "quelle": m.get("quelle", ""), "codec": m.get("codec", ""),
                           "gruppe": m.get("gruppe", ""), "sofort": bool(m.get("sofort")), "indexer": t.get("quelle", ""),
                           "usenet": s.get("usenet"), "usenet_ref": s.get("usenet_ref"),
                           "streams": [{"name": name, "url": app.usenet_adresse(s["url"], t.get("titel"), "", aid, kategorie)}
                                       for aid, name in ziele]})
        auto = None
        kandidaten = usenet_stream.kandidaten_paket(geordnet, cfg["auto_anzahl"])
        if ziele and len(kandidaten) >= 2:
            aid = streamer[0][0] if streamer else ""
            auto = {"name": "Usenet Auto · " + (streamer[0][1].typ_name if streamer else "rustnzb"), "anzahl": len(kandidaten),
                    "url": app.usenet_adresse(kandidaten[0][0], kandidaten[0][1], "", aid, kategorie, weitere=kandidaten[1:])}
        return 200, "application/json", {"treffer": zeilen, "gesamt": len(nzb), "ohne_nzb": len(paare) - len(nzb),
                                         "modus_an": bool(aktiv), "deutsch_modus": cfg["deutsch"], "auto": auto, "ziele": [n for _a, n in ziele]}

    def usenet_stream_post(self, pfad, koerper):
        if pfad != "/api/usenet-stream/pruefen":
            return 404, "application/json", {"fehler": "nicht gefunden"}
        from . import anbindungen, anbindungen_pruefen, dienste
        app = self.app
        ergebnisse = []
        for _aid, c in sorted(app.dienste.items()):
            if getattr(c, "typ", "") in ("nzbdav", "altmount"):
                try:
                    ergebnisse.append({"name": c.name or c.typ_name, "ok": True, "text": c.pruefen()})
                except dienste.DienstFehler as fehler:
                    ergebnisse.append({"name": c.name or c.typ_name, "ok": False, "text": str(fehler)})
        for aid, eintrag, werte in anbindungen.eigene(self._usenet_daten(), "newznab"):
            ok, text = anbindungen_pruefen.pruefen(eintrag, werte)
            ergebnisse.append({"name": eintrag.get("name") or aid, "ok": bool(ok), "text": str(text)[:200]})
        if not ergebnisse:
            ergebnisse.append({"name": "Einrichtung", "ok": False,
                               "text": "Weder NzbDAV/AltMount noch ein Newznab-Indexer eingerichtet (Anbieter & Addons)."})
        usenet_stream.cache_leeren()
        return 200, "application/json", {"ergebnisse": ergebnisse, "ok": all(e["ok"] for e in ergebnisse)}


class UsenetMixin:

    def usenet_urteile_lesen(self, werte):
        schluessel_liste = [s for s in str(werte.get("schluessel") or "").split(",") if s]
        if not schluessel_liste:
            return 200, "application/json", {"urteile": {}}
        nzb_url_je_schluessel = {}
        for schluessel in schluessel_liste:
            ziel = self.wiedergabe_ziel(schluessel)
            if ziel:
                nzb_url_je_schluessel[schluessel] = ziel[0]
        urteile_je_url = self.app.usenet_triage.urteile_aus_cache(nzb_url_je_schluessel.values())
        urteile = {schluessel: urteile_je_url[url] for schluessel, url in nzb_url_je_schluessel.items()
                   if url in urteile_je_url}
        return 200, "application/json", {"urteile": urteile}
