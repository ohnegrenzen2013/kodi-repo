"""Videowerkstatt: ComfyUI-Status, Modelle, Auftraege, Galerie und Dateien."""

import json

from . import videowerkstatt as videowerkstatt_modul
from .netz import NetzFehler
from .videowerkstatt import VwFehler


class VideowerkstattMixin:
    def _videowerkstatt(self):
        return getattr(self.app, "videowerkstatt", None)

    def videowerkstatt_lesen(self, werte):
        if not self.darf("einstellungen"):
            return 403, "application/json", {"fehler": "Kein Recht auf Einstellungen", "recht": True}
        v = self._videowerkstatt()
        if v is None:
            return 503, "application/json", {"fehler": "Videowerkstatt nicht verfuegbar"}
        w = self._einstellungen_lesen().get("werte") or {}
        aktion = str(werte.get("aktion") or "")
        try:
            if aktion == "doctor":
                return 200, "application/json", v.doctor(w)
            if aktion == "modelle":
                return 200, "application/json", {"modelle": v.modelle(w)}
            if aktion == "job":
                job = v.job(werte.get("id"))
                if job is None:
                    raise VwFehler("Unbekannter Auftrag")
                return 200, "application/json", job
            if aktion == "galerie":
                return 200, "application/json", {"galerie": v.galerie()}
            return 200, "application/json", dict(videowerkstatt_modul.zustand(w), galerie=v.galerie(),
                                                 jobs=[j for j in v.liste() if j["status"] in ("wartet", "laeuft")])
        except VwFehler as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        except NetzFehler as fehler:
            return 502, "application/json", {"fehler": str(fehler)}

    def videowerkstatt_datei(self, name):
        if not self.darf("einstellungen"):
            return 403, "application/json", {"fehler": "Kein Recht auf Einstellungen", "recht": True}
        v = self._videowerkstatt()
        if v is None:
            return 404, "application/json", {"fehler": "nicht gefunden"}
        try:
            return "lokal", v.datei(name)
        except VwFehler as fehler:
            return 404, "application/json", {"fehler": str(fehler)}

    def videowerkstatt_post(self, koerper):
        if not self.darf("einstellungen"):
            return 403, "application/json", {"fehler": "Kein Recht auf Einstellungen", "recht": True}
        v = self._videowerkstatt()
        if v is None:
            return 503, "application/json", {"fehler": "Videowerkstatt nicht verfuegbar"}
        try:
            daten = json.loads(koerper.decode("utf-8") or "{}")
        except (ValueError, UnicodeDecodeError):
            return 400, "application/json", {"fehler": "JSON-Fehler"}
        if not isinstance(daten, dict):
            return 400, "application/json", {"fehler": "JSON-Objekt erwartet"}
        werte = self._einstellungen_lesen().get("werte") or {}
        try:
            aktion = str(daten.get("aktion") or "start")
            if aktion == "abbrechen":
                return 200, "application/json", v.abbrechen(daten.get("id"))
            if aktion == "weg":
                v.weg(daten.get("name"))
                return 200, "application/json", {"ok": True, "galerie": v.galerie()}
            if aktion != "start":
                raise VwFehler("aktion: start, abbrechen oder weg")
            return 200, "application/json", v.start(werte, daten)
        except VwFehler as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        except NetzFehler as fehler:
            return 502, "application/json", {"fehler": str(fehler)}
