"""Vorschlaege: KI-generierte Datei-Aenderungen mit Freigabe-Pflicht (vorschlaege.py, fix_vorlagen.py).

  GET  /api/vorschlaege   Offene Vorschlaege (mit Diff-Vorschau), Verlauf, Vorlagen, Automatisierungs-Schalter
  POST /api/vorschlaege   {aktion: entscheiden|vorlage_hinzufuegen|vorlage_entfernen|automatisierung, ...}
"""

import json

from . import fix_vorlagen, ki_anbieter, vorschlaege


class VorschlaegeMixin:

    def _ki_vorschlaege_verfuegbar(self, daten):
        modus = daten.get("ki_modus", "cloud")
        if modus == "cloud":
            backend = daten.get("ki_cloud_backend", "claude")
            if backend == "claude":
                return bool(daten.get("claude_api_key"))
            return bool(daten.get("ki_cloud_url"))
        elif modus == "lokal":
            return True
        elif modus == "remote":
            return bool(daten.get("ki_remote_url"))
        return False

    def _vorschlaege_zustand(self, daten):
        z = vorschlaege.zustand(daten)
        z["liste"] = [dict(e, vorschau=vorschlaege.diff_vorschau(e)) for e in z["liste"]]
        z["vorlagen"] = fix_vorlagen.alle(daten)
        z["automatisierung_erlaubt"] = bool(daten.get("ki_automatisierung_erlaubt"))
        return z

    def vorschlaege_lesen(self):
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        return 200, "application/json", self._vorschlaege_zustand(daten)

    def vorschlaege_post(self, koerper):
        if not self.app.verwaltung:
            return 503, "application/json", {"fehler": "Nutzerdaten nicht verfügbar"}
        try:
            w = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(w, dict):
                raise ValueError("JSON-Objekt erwartet")
            a = w.get("aktion")
            ergebnis = {}
            if a == "ki_vorschlagen" and not self._ki_vorschlaege_verfuegbar(self.app.verwaltung.daten()):
                return 503, "application/json", {"fehler": "Kein KI-Anbieter konfiguriert.",
                                                   "hinweis": "Konfiguriere einen KI-Anbieter unter "
                                                               "Einstellungen → KI & Werkzeuge."}

            def tun(d):
                wer = self.aktuelles_profil()
                if a == "ki_vorschlagen":
                    vorschlag = vorschlaege.ki_vorschlagen(d, w.get("vorlage_id"), w.get("werte"),
                                                             w.get("fehler_kontext") or "")
                    ergebnis["eingereicht"] = vorschlaege.einreichen(
                        d, wer, w.get("vorlage_id"), vorschlag["dateien"], vorschlag.get("begruendung", ""))
                elif a == "entscheiden":
                    ergebnis["entschieden"] = vorschlaege.entscheiden(d, wer, w.get("id"), w.get("ja") is True)
                elif a == "vorlage_hinzufuegen":
                    ergebnis["vorlage"] = fix_vorlagen.hinzufuegen(
                        d, w.get("name"), w.get("kategorie"), w.get("prompt"), w.get("werte"), w.get("hinweis") or "",
                        mcp_erlaubt=w.get("mcp_erlaubt") is True)
                elif a == "vorlage_entfernen":
                    fix_vorlagen.entfernen(d, w.get("id"))
                elif a == "automatisierung":
                    d["ki_automatisierung_erlaubt"] = w.get("an") is True
                else:
                    raise vorschlaege.VorschlagFehler("Unbekannte Aktion")

            self.app.verwaltung.bearbeiten(tun)
            daten = self.app.verwaltung.daten()
            return 200, "application/json", dict(self._vorschlaege_zustand(daten), **ergebnis)
        except vorschlaege.KeinRecht as fehler:
            return 403, "application/json", {"fehler": str(fehler)}
        except ki_anbieter.KiAnbieterFehler as fehler:
            return 502, "application/json", {"fehler": str(fehler)}
        except (vorschlaege.VorschlagFehler, fix_vorlagen.VorlageFehler, ValueError, UnicodeDecodeError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
