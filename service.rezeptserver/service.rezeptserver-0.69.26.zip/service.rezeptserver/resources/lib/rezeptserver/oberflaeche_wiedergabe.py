"""WiedergabeMixin-Mixin
"""

from .oberflaeche_grund import (
    HLS_JS,
    MAX_WIEDERGABEN,
    NetzFehler,
    USER_AGENT,
    WIEDERGABE_DAUER,
    _HLS_URI,
    ab18,
    anbieter,
    base64,
    dienste,
    json,
    kodi_player,
    log,
    secrets,
    time,
    urljoin,
    urllib,
    urlsplit,
)

class WiedergabeMixin:

    # --- Kodi: Player (TMDb Helper) und Fernsteuerung -------------------------------------------
    def _kodi(self, funktion):
        try:
            return 200, "application/json", funktion()
        except (kodi_player.PlayerFehler, dienste.DienstFehler, NetzFehler, ValueError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}

    def _kodi_geraet(self, geraet):
        kodis = {i: c for i, c in self.app.dienste.items() if c.typ == "kodi"}
        if not kodis:
            raise ValueError("Kein Kodi eingerichtet (Anbieter → Vorlage „Kodi“)")
        if geraet and geraet not in kodis:
            raise ValueError("Unbekanntes Kodi: %s" % geraet)
        return kodis[geraet] if geraet else next(iter(kodis.values()))

    def kodi_lesen(self, geraet=""):
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        installiert, fehler = None, ""
        if geraet:
            try:
                installiert = self._kodi_geraet(geraet).addons()
            except (dienste.DienstFehler, NetzFehler) as f:
                fehler = str(f)
        return {"geraete": [{"id": i, "name": c.name} for i, c in self.app.dienste.items() if c.typ == "kodi"],
                "player": kodi_player.liste(daten, installiert), "fehler": fehler,
                "tmdbhelper": None if installiert is None else kodi_player.TMDBHELPER in installiert,
                "zip_pfad": "tmdbhelper/players.zip"}

    def _fuer_kodi(self, url):
        """Adressen dieses Servers (127.0.0.1) so umschreiben, dass Kodi sie im Heimnetz erreicht."""
        teile = urlsplit(url)
        if (teile.hostname or "") not in ("127.0.0.1", "localhost", "::1"):
            return url
        if not self.app.token:
            raise ValueError("Dieser Stream läuft über H0rSt. Damit Kodi ihn erreicht, H0rSt im Heimnetz freigeben.")
        from .dienst import eigene_adresse
        return teile._replace(netloc="%s:%d" % (eigene_adresse(), teile.port or 80)).geturl()

    def kodi_post(self, pfad, koerper):
        try:
            daten = json.loads(koerper.decode("utf-8") or "{}")
        except (ValueError, UnicodeDecodeError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        if not isinstance(daten, dict):
            return 400, "application/json", {"fehler": "JSON-Objekt erwartet"}
        was = pfad[len("/api/kodi/"):]

        def ausfuehren():
            if was == "abspielen":
                staffel, folge = daten.get("staffel"), daten.get("folge")
                staffel = None if staffel in (None, "") else int(staffel)
                folge = None if folge in (None, "") else int(folge)
                info = self.app.entdecken.details(str(daten.get("typ", "")), str(daten.get("id", "")))
                url, name = kodi_player.adresse(self.app.verwaltung.daten() if self.app.verwaltung else {},
                                                str(daten.get("player", "")), info, staffel, folge)
                geraet = self._kodi_geraet(str(daten.get("geraet", "")))
                geraet.oeffnen(url)
                log.info("Kodi %s: %s über %s", geraet.name, info.get("titel"), name)
                return {"meldung": "Läuft auf %s über %s" % (geraet.name, name), "url": url}
            if was == "senden":
                geraet = self._kodi_geraet(str(daten.get("geraet", "")))
                geraet.oeffnen(self._fuer_kodi(str(daten.get("url", ""))))
                return {"meldung": "Läuft auf %s" % geraet.name}
            if was == "steuern":
                self._kodi_geraet(str(daten.get("geraet", ""))).steuern(str(daten.get("was", "")))
                return {"meldung": "ok"}
            if was == "import":
                if daten.get("inhalt"):
                    neu = kodi_player.aus_upload(str(daten.get("name", "")), kodi_player.b64(str(daten["inhalt"])))
                elif daten.get("json"):
                    neu = kodi_player.import_text(str(daten["json"]))
                elif daten.get("url"):
                    url = str(daten["url"]).strip()
                    if not url.lower().startswith(("http://", "https://")):
                        raise ValueError("Adresse muss mit http(s):// beginnen")
                    anfrage = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
                    with urllib.request.urlopen(anfrage, timeout=30) as a:
                        neu = kodi_player.aus_upload(url.split("?")[0], a.read(kodi_player.MAX_ZIP + 1))
                else:
                    raise ValueError("inhalt, json oder url fehlt")

                def setzen(d):
                    e = kodi_player.pruefe(d.get(kodi_player.SCHLUESSEL))
                    e["player"].update(neu)
                    d[kodi_player.SCHLUESSEL] = kodi_player.pruefe(e)
                self.app.verwaltung.aendern(setzen)
                return dict(self.kodi_lesen(), neu=sorted(neu))
            if was == "entfernen":
                datei = str(daten.get("datei", ""))

                def weg(d):
                    e = kodi_player.pruefe(d.get(kodi_player.SCHLUESSEL))
                    if datei not in e["player"]:
                        raise ValueError("%s ist kein eigener Player" % datei)
                    del e["player"][datei]
                    d[kodi_player.SCHLUESSEL] = e
                self.app.verwaltung.aendern(weg)
                return self.kodi_lesen()
            raise ValueError("unbekannt: %s" % was)
        try:
            return self._kodi(ausfuehren)
        except urllib.error.URLError as fehler:
            return 400, "application/json", {"fehler": "Nicht ladbar: %s" % getattr(fehler, "reason", fehler)}

    # --- Ab 18 ------------------------------------------------------------------
    def ab18_lesen(self, pfad, werte, kopf):
        bereich = self.app.ab18
        schluessel = kopf.get("X-Ab18") if kopf else None
        if pfad == "/api/ab18":
            return 200, "application/json", bereich.zustand(schluessel)
        try:
            bereich.pruefen(schluessel)
            was = pfad[len("/api/ab18/"):]
            if was == "menue":
                return 200, "application/json", bereich.menue(werte.get("seite"))
            if was == "kategorien":
                return 200, "application/json", bereich.kategorien(werte.get("seite"))
            if was == "videos":
                return 200, "application/json", bereich.videos(
                    werte.get("seite"), werte.get("reihenfolge"), werte.get("suche"), werte.get("kategorie"),
                    werte.get("nummer", 1))
            if was == "suche":
                seiten = [s for s in werte.get("seiten", "").split(",") if s]
                return 200, "application/json", bereich.suche(werte.get("q", ""), seiten)
            if was == "start":
                return 200, "application/json", bereich.start()
            if was == "genres":
                return 200, "application/json", bereich.genres()
            if was == "genre":
                return 200, "application/json", bereich.genre(werte.get("name"), werte.get("nummer", 1))
            if was == "aehnlich":
                return 200, "application/json", bereich.aehnlich(werte.get("seite"), werte.get("titel"), werte.get("id", ""))
        except ab18.Gesperrt as fehler:
            return 403, "application/json", {"fehler": str(fehler), "gesperrt": True}
        except ab18.Ab18Fehler as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        return 404, "application/json", {"fehler": "nicht gefunden"}

    def ab18_post(self, pfad, koerper, kopf):
        try:
            daten = json.loads(koerper.decode("utf-8") or "{}")
        except (ValueError, UnicodeDecodeError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        if not isinstance(daten, dict):
            return 400, "application/json", {"fehler": "JSON-Objekt erwartet"}
        bereich = self.app.ab18
        schluessel = kopf.get("X-Ab18") if kopf else None
        was = pfad[len("/api/ab18/"):]
        try:
            if was == "freigabe":
                return self.ab18_freigabe(daten)
            if was == "entsperren":
                neu = bereich.entsperren(daten.get("pin", ""))
                return 200, "application/json", dict(bereich.zustand(neu), schluessel=neu)
            if was == "sperren":
                bereich.sperren()
                return 200, "application/json", bereich.zustand(None)
            bereich.pruefen(schluessel)
            if was == "einstellungen":
                bereich.einstellen(daten)
                if "pin_neu" in daten:  # neue PIN: alte Sitzungen enden, diese bekommt eine neue
                    neu = bereich.entsperren(daten.get("pin_neu", ""))
                    return 200, "application/json", dict(bereich.zustand(neu), schluessel=neu)
                return 200, "application/json", bereich.zustand(schluessel)
            if was == "merken":
                return 200, "application/json", {"merkliste": bereich.merken(daten.get("video"), bool(daten.get("weg")))}
            if was == "leeren":
                bereich.leeren(str(daten.get("was", "")))
                return 200, "application/json", bereich.zustand(schluessel)
            if was == "abspielen":
                ergebnis = bereich.aufloesen(daten.get("seite"), str(daten.get("id") or ""), str(daten.get("url") or ""))
                try:
                    bereich.gesehen(daten)
                except ab18.Ab18Fehler:
                    pass  # Verlauf ist Beiwerk
                return 200, "application/json", self._ab18_wiedergabe(ergebnis)
            if was == "link":
                return 200, "application/json", self._ab18_wiedergabe(bereich.link(daten.get("url")))
            if was == "erkennen":  # neue Seite nur per Adresse: H0rSt erkennt Liste, Seitenzahl, Suche oder API
                from .ab18.seiten import eigene as ab18_eigene
                from .ab18 import http as ab18_http
                try:
                    return 200, "application/json", ab18_eigene.erkennen(daten.get("url"))
                except (ValueError, ab18_http.HttpError) as fehler:
                    return 400, "application/json", {"fehler": str(fehler)}
        except ab18.Gesperrt as fehler:
            return 403, "application/json", {"fehler": str(fehler), "gesperrt": True}
        except ab18.Ab18Fehler as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        return 404, "application/json", {"fehler": "nicht gefunden"}

    def ab18_freigabe(self, daten):
        an = daten.get("an") is True
        if an and daten.get("volljaehrig") is not True:
            raise ab18.Ab18Fehler("Freigabe nur mit Bestätigung, dass du mindestens 18 Jahre alt bist")
        verwaltung = self.app.verwaltung
        if not verwaltung:
            return 503, "application/json", {"fehler": "Nutzerdaten nicht verfügbar"}

        def setzen(d):
            d[anbieter.AB18] = an
        verwaltung.aendern(setzen)  # laedt auch Rezepte der Kategorie ab18 nach bzw. blendet sie aus
        self.app.ab18.freigegeben = an
        self.app.ab18.sperren()
        log.info("Ab 18 %s", "freigegeben" if an else "gesperrt")
        return 200, "application/json", self.app.ab18.zustand(None)

    def _ab18_wiedergabe(self, ergebnis):
        """Einzelne Dateien gehen ueber den Server (mit Referer o. a. der Seite, Springen per Range);
        HLS-Listen direkt, weil ihre Teile relativ zur Liste geladen werden."""
        antwort = {"hls": ergebnis.is_hls, "quelle": ergebnis.url, "hoehe": ergebnis.height,
                   "mime": ergebnis.mime or ("application/vnd.apple.mpegurl" if ergebnis.is_hls else "")}
        if ergebnis.is_hls:
            antwort["url"] = self.hls_merken(ergebnis.url, ergebnis.headers)  # Browser: ueber den Server
            antwort["extern"] = ergebnis.url  # externe Player: direkt
        else:
            host = urlsplit(ergebnis.url).hostname or ""
            antwort["url"] = "api/wiedergabe/" + self._wiedergabe_merken(ergebnis.url, ergebnis.headers, [host])
        return antwort

    # --- Wiedergabe ueber den Server ------------------------------------------
    def _wiedergabe_merken(self, url, header, netz, eigenes=False, oeffentlich=False):
        """eigenes: selbst signiertes Zertifikat annehmen (Router, NAS im Heimnetz). ftp://-Adressen laufen ueber ftp.py.
        oeffentlich: jede Weiterleitung beim Abspielen erneut gegen private/interne Adressen pruefen (netz.
        ip_oeffentlich_pruefen) - fuer Quellen, die schon beim Eintragen so geprueft wurden (z. B. dateisuche/
        abspielen); sonst koennte eine Weiterleitung die SSRF-Sperre umgehen."""
        schluessel = secrets.token_urlsafe(18)
        with self._sperre:
            self._wiedergaben[schluessel] = (url, dict(header), list(netz), time.time(), bool(eigenes), bool(oeffentlich))
            while len(self._wiedergaben) > MAX_WIEDERGABEN:
                self._wiedergaben.popitem(last=False)
        return schluessel

    # --- HLS ueber den Server -------------------------------------------------------
    # Die CDNs erlauben Browsern meist keinen Zugriff von fremden Seiten (CORS). Deshalb laufen Listen
    # und Teile ueber H0rSt: Listen werden umgeschrieben, Teile samt Range durchgereicht. Nur Hosts, die
    # in einer Liste dieses Streams standen, sind erreichbar.
    def hls_js(self):
        if self._hls_js is None:
            with open(HLS_JS, encoding="utf-8") as f:
                self._hls_js = f.read()
        return self._hls_js

    def hls_merken(self, url, kopf):
        schluessel = secrets.token_urlsafe(18)
        with self._sperre:
            self._hls[schluessel] = (dict(kopf or {}), {urlsplit(url).hostname or ""}, time.time())
            while len(self._hls) > MAX_WIEDERGABEN:
                self._hls.popitem(last=False)
        return "api/hls/%s/%s" % (schluessel, self._hls_teil(schluessel, url, "l"))

    def _hls_teil(self, schluessel, url, art):
        with self._sperre:
            eintrag = self._hls.get(schluessel)
            if eintrag:
                eintrag[1].add(urlsplit(url).hostname or "")
        kodiert = base64.urlsafe_b64encode(url.encode("utf-8")).decode("ascii").rstrip("=")
        return art + kodiert + (".m3u8" if art == "l" else "")

    def hls_umschreiben(self, schluessel, text, basis):
        """URIs einer Liste auf /api/hls/<schluessel>/... (relativ, gleicher Ordner) umbiegen."""
        def ziel(uri, art):
            absolut = urljoin(basis, uri.strip())
            if not absolut.lower().startswith(("http://", "https://")):
                return uri
            return self._hls_teil(schluessel, absolut, art)
        aus, liste_folgt = [], False
        for zeile in text.splitlines():
            rein = zeile.strip()
            if rein.startswith("#"):
                if rein.startswith("#EXT-X-STREAM-INF"):
                    liste_folgt = True
                art = "l" if rein.startswith(("#EXT-X-MEDIA:", "#EXT-X-I-FRAME-STREAM-INF")) else "t"
                zeile = _HLS_URI.sub(lambda m: 'URI="%s"' % ziel(m.group(1), art), zeile)
            elif rein:
                zeile = ziel(rein, "l" if liste_folgt else "t")
                liste_folgt = False
            aus.append(zeile)
        return "\n".join(aus) + "\n"

    def hls_abruf(self, rest):
        schluessel, _, teil = rest.partition("/")
        with self._sperre:
            eintrag = self._hls.get(schluessel)
        if not eintrag or time.time() - eintrag[2] > WIEDERGABE_DAUER or teil[:1] not in ("l", "t"):
            return 404, "application/json", {"fehler": "Wiedergabe abgelaufen, Video neu wählen"}
        kopf, hosts, _ = eintrag
        roh = teil[1:].split(".", 1)[0]
        try:
            url = base64.urlsafe_b64decode(roh + "=" * (-len(roh) % 4)).decode("utf-8")
        except (ValueError, UnicodeDecodeError):
            return 400, "application/json", {"fehler": "Teil unlesbar"}
        if (urlsplit(url).hostname or "") not in hosts or ab18.http.is_ad_host(url):
            return 403, "application/json", {"fehler": "Host gehört nicht zu diesem Video"}
        if teil[0] == "t":
            return "wiedergabe", (url, kopf, sorted(hosts))
        try:
            antwort = ab18.http.get(url, headers=kopf)
        except ab18.http.HttpError as fehler:
            return 502, "application/json", {"fehler": str(fehler)}
        return 200, "application/vnd.apple.mpegurl", self.hls_umschreiben(schluessel, antwort.text, antwort.url)

    def wiedergabe_ziel(self, schluessel):
        with self._sperre:
            eintrag = self._wiedergaben.get(schluessel)
        if not eintrag or time.time() - eintrag[3] > WIEDERGABE_DAUER:
            return None
        return eintrag[0], eintrag[1], eintrag[2], eintrag[4], eintrag[5]
