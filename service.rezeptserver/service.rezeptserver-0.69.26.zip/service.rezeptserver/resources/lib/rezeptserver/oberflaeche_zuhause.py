"""ZuhauseMixin-Mixin
"""


from .oberflaeche_grund import (
    NetzFehler,
    anbieter,
    assistent,
    base64,
    cast,
    dienste,
    fernseher,
    hue,
    json,
    kameras,
    log,
    os,
    re,
    rustnzb,
    secrets,
    sprachbefehl,
    unquote,
    urlsplit,
    verweise,
    videochat,
    webhosting,
)

from .oberflaeche_zuhause_bild import BildMixin as _BildMixin
from .oberflaeche_zuhause_kamera import KameraMixin as _KameraMixin
from .oberflaeche_zuhause_hue import HueMixin as _HueMixin
from .oberflaeche_zuhause_web import WebMixin as _WebMixin
from .oberflaeche_zuhause_assistent import AssistentMixin as _AssistentMixin
from .oberflaeche_zuhause_chat import ChatMixin as _ChatMixin
from .oberflaeche_zuhause_cast import CastMixin as _CastMixin
from .oberflaeche_zuhause_sprache import SpracheMixin as _SpracheMixin


class ZuhauseMixin(_BildMixin, _KameraMixin, _HueMixin, _WebMixin, _AssistentMixin, _ChatMixin, _CastMixin, _SpracheMixin):
    """Zuhause: Hintergrund, Kameras, Hue, Webhosting, Assistent, Videochat, Geraete und Sprachbefehle."""
