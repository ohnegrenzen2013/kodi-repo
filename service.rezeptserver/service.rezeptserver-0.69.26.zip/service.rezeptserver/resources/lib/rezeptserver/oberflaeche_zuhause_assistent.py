"""Hinzufuegen-Assistent: Verknuepfungen, Vorlagen und Aufraeumen."""

from .oberflaeche_grund import (
    NetzFehler,
    anbieter,
    assistent,
    dienste,
    json,
    rustnzb,
    verweise,
)

class AssistentMixin:

    # --- Hinzufuegen-Assistent und Verweise ------------------------------------------
    def assistent_post(self, pfad, koerper):
        try:
            daten = json.loads(koerper.decode("utf-8") or "{}")
            if not self.app.verwaltung:
                raise ValueError("Nutzerdaten nicht verfügbar")
            nutzer = self.app.verwaltung.daten()
            if pfad == "/api/verweise/aufraeumen":
                if not self.darf("anbieter"):
                    return self.recht_verboten("anbieter")
                anzahl = self.app.verwaltung.aendern(lambda d: verweise.aufraeumen(d, self._eingebaut(d)))
                return 200, "application/json", {"aufgeraeumt": anzahl, "probleme": verweise.pruefen(self.app.verwaltung.daten(),
                                                                                                    self._eingebaut(nutzer))}
            aid = str(daten.get("id") or "")
            eintrag = (nutzer.get("anbieter") or {}).get(aid)
            if pfad == "/api/assistent/verknuepfungen":
                return 200, "application/json", {"vorschlaege": assistent.verknuepfungen((eintrag or {}).get("typ", ""), nutzer)}
            was = str(daten.get("was") or "")
            # jede Verknuepfung braucht dasselbe Recht wie ihr Normalweg (RustNZB-Downloads, Anbieter, Sicherheit)
            recht = {"rustnzb_server": "downloads", "binsearch": "anbieter", "livetv": "anbieter", "netzweg": "sicherheit"}.get(was)
            if recht and not self.darf(recht):
                return self.recht_verboten(recht)
            if not eintrag:
                raise ValueError("Anbieter gibt es nicht (mehr)")
            if was == "rustnzb_server":
                r = self.rustnzb_server({})
                return 200, "application/json", {"meldung": "rustnzb: " + ", ".join("%s %s" % (x["name"], x["aktion"]) for x in r["server"])}
            if was == "binsearch":
                if any(e.get("typ") == "binsearch" for e in (nutzer.get("anbieter") or {}).values()):
                    return 200, "application/json", {"meldung": "binsearch ist schon eingerichtet."}
                self.aus_vorlage({"vorlage": "binsearch"})
                return 200, "application/json", {"meldung": "binsearch sucht jetzt mit – Treffer erscheinen als NZB-Streams."}
            if was == "livetv":
                self.als_livetv({"id": aid})
                return 200, "application/json", {"meldung": "Als Live-TV-Senderliste aufgenommen."}
            if was == "netzweg":
                schluessel = {"tor": "onion", "i2p": "i2p"}.get(eintrag.get("typ"), "weg")
                self.sicherheit_speichern({schluessel: aid})
                return 200, "application/json", {"meldung": "%s ist jetzt %s." % (eintrag.get("name", aid),
                                                                                    {"weg": "der Netzweg", "onion": "der Weg für .onion", "i2p": "der Weg für .i2p"}[schluessel])}
            raise ValueError("Unbekannte Verknüpfung")
        except (ValueError, UnicodeDecodeError, anbieter.AnbieterFehler, NetzFehler, dienste.DienstFehler, rustnzb.RustnzbFehler) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
