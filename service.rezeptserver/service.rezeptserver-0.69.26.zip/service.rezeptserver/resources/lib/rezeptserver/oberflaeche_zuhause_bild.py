"""Hintergrund und Avatar: Bilddatei ablegen, entfernen oder Kamera-Snap uebernehmen."""

from .oberflaeche_grund import (
    base64,
    json,
    kameras,
    os,
)

class BildMixin:

    def _hintergrund_datei(self, name="hintergrund"):
        for endung in (".jpg", ".png", ".webp", ".gif"):
            pfad = os.path.join(self.app.datenordner, name + endung)
            if os.path.isfile(pfad):
                return pfad
        return None

    def hintergrund_speichern(self, koerper, name="hintergrund"):
        """{bild: base64} speichern (JPEG, PNG, WebP, GIF, bis 8 MB), {kamera: id} (Snap einer IP-Kamera)
        oder {weg: true} entfernen. Fuer Hintergrund und Avatar."""
        try:
            daten = json.loads(koerper.decode("utf-8") or "{}")
            alt = self._hintergrund_datei(name)
            if daten.get("weg"):
                if alt:
                    os.remove(alt)
                return 200, "application/json", {"bild": False}
            if daten.get("kamera"):
                k = next((x for x in self.app.kameras if x["id"] == str(daten["kamera"])), None)
                if not k:
                    raise ValueError("Kamera gibt es nicht")
                roh = kameras.bild(k)
            else:
                roh = base64.b64decode(str(daten.get("bild") or "").split(",", 1)[-1], validate=True)
            if len(roh) > 8 * 1024 * 1024:
                raise ValueError("Bild zu groß (höchstens 8 MB)")
            endung = next((e for k, e in self.HINTERGRUND_TYPEN.items() if roh.startswith(k)), None)
            if not endung or (endung == ".webp" and roh[8:12] != b"WEBP"):
                raise ValueError("Nur JPEG, PNG, WebP oder GIF")
            if alt:
                os.remove(alt)
            with open(os.path.join(self.app.datenordner, name + endung), "wb") as f:
                f.write(roh)
            return 200, "application/json", {"bild": True}
        except (ValueError, UnicodeDecodeError, OSError, kameras.KameraFehler) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
