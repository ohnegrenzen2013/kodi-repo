"""Fernseher und Geraete: Chromecast, DLNA, Roku, Enigma2 - suchen, abspielen, steuern."""

from .oberflaeche_grund import (
    cast,
    fernseher,
    json,
    re,
    urlsplit,
)

class CastMixin:

    # --- Fernseher & Geraete: Chromecast, DLNA-Fernseher, Roku, Enigma2 (fernseher.py) ------
    def _gespeicherte_geraete(self):
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        ergebnis = []
        for g in daten.get("cast_geraete") or []:
            if isinstance(g, dict) and g.get("ip"):
                art = g.get("art") or "cast"  # aeltere Eintraege: nur Chromecast per IP
                ergebnis.append(dict({"port": {"cast": 8009, "roku": 8060, "enigma2": 80}.get(art, 8009), "modell": "",
                                      "name": g["ip"]}, **dict(g, art=art, id=g.get("id") or "%s:%s" % (art, g["ip"]),
                                                                gespeichert=True)))
        return ergebnis, daten.get("cast_standard") or ""

    def _geraete_mischen(self, gefunden):
        eigene, _ = self._gespeicherte_geraete()
        liste = list(gefunden)
        for g in eigene:
            treffer = next((x for x in liste if x["id"] == g["id"]), None)
            if treffer:
                treffer.update({k: v for k, v in g.items() if k in ("benutzer", "passwort")})
            else:
                liste.append(g)
        return liste

    def _cast_geraet(self, kennung):
        kennung = str(kennung or "")
        g = next((x for x in self.app.cast_geraete if kennung in (x.get("id"), x.get("ip"))), None)
        if g is None:
            g = next((x for x in self._gespeicherte_geraete()[0] if kennung in (x["id"], x["ip"])), None)
        if g is None:
            if not re.match(r"^\d{1,3}(\.\d{1,3}){3}$", kennung):
                raise fernseher.GeraetFehler("Gerät unbekannt – erst suchen oder IP eintragen")
            g = {"id": "cast:" + kennung, "art": "cast", "name": kennung, "ip": kennung, "port": 8009, "modell": ""}
        return g

    def _cast_antwort(self):
        _, standard = self._gespeicherte_geraete()
        if not self.app.cast_geraete:
            self.app.cast_geraete = self._geraete_mischen([])
        return {"geraete": [fernseher.oeffentlich(g) for g in self.app.cast_geraete], "standard": standard,
                "arten": fernseher.ARTEN}

    def cast_lesen(self, pfad, werte):
        try:
            if pfad == "/api/cast/suchen":
                self.app.cast_geraete = self._geraete_mischen(fernseher.suchen())
            if pfad == "/api/cast" and werte.get("stand"):
                g = self._cast_geraet(werte.get("stand"))
                return 200, "application/json", {"stand": fernseher.steuern(g, "stand", cast_oeffnen=getattr(self.app, "cast_oeffnen", None))}
            return 200, "application/json", self._cast_antwort()
        except (fernseher.GeraetFehler, cast.CastFehler, OSError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}

    def _geraete_speichern(self, aendern):
        def bearbeiten(d):
            liste = [g for g in (d.get("cast_geraete") or []) if isinstance(g, dict)]
            d["cast_geraete"] = aendern(liste, d)
        self.app.verwaltung.bearbeiten(bearbeiten)

    def cast_post(self, pfad, koerper):
        try:
            daten = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(daten, dict):
                raise ValueError("JSON-Objekt erwartet")
            if pfad == "/api/cast/hinzufuegen":  # per IP merken (Chromecast, Roku, Enigma2)
                eintrag = fernseher.pruefe_eintrag(daten)
                if eintrag["art"] == "enigma2":
                    info = fernseher.enigma2_info(eintrag["ip"], eintrag["port"], eintrag["benutzer"], eintrag["passwort"])
                    if eintrag["name"] == eintrag["ip"]:
                        eintrag["name"] = info["name"]
                    eintrag["modell"] = info["modell"]
                elif eintrag["art"] == "roku":
                    info = fernseher.roku_info(eintrag["ip"])
                    eintrag.update(name=info["name"] if eintrag["name"] == eintrag["ip"] else eintrag["name"], modell=info["modell"])
                self._geraete_speichern(lambda liste, d: [g for g in liste if (g.get("id") or "cast:" + g.get("ip", "")) != eintrag["id"]] + [eintrag])
                self.app.cast_geraete = [g for g in self.app.cast_geraete if g.get("id") != eintrag["id"]] + [dict(eintrag, gespeichert=True)]
                return 200, "application/json", self._cast_antwort()
            if pfad == "/api/cast/entfernen":
                kennung = str(daten.get("id") or "")
                self._geraete_speichern(lambda liste, d: [g for g in liste if (g.get("id") or "cast:" + g.get("ip", "")) != kennung])
                self.app.cast_geraete = [g for g in self.app.cast_geraete if g.get("id") != kennung]
                return 200, "application/json", self._cast_antwort()
            if pfad == "/api/cast/standard":  # wohin "Senden" ohne Auswahl geht
                kennung = str(daten.get("id") or "")
                self.app.verwaltung.bearbeiten(lambda d: d.__setitem__("cast_standard", kennung[:120]))
                return 200, "application/json", self._cast_antwort()
            g = self._cast_geraet(daten.get("id") or daten.get("ip"))
            oeffnen = getattr(self.app, "cast_oeffnen", None)
            if pfad == "/api/cast/abspielen":
                url = str(daten.get("url") or "")
                if url.startswith(("api/", "/")):
                    raise ValueError("Volle Adresse erwartet")
                if urlsplit(url).scheme not in ("http", "https"):
                    raise ValueError("Adresse mit http(s)://")
                url = self._fuer_kodi(url)  # Adressen dieses Servers -> Heimnetz-Adresse
                mime = str(daten.get("mime") or "")
                if mime and not re.match(r"^(audio|video|application)/[\w.+-]{1,60}$", mime):
                    raise ValueError("Inhaltstyp wie audio/mpeg")
                return 200, "application/json", fernseher.abspielen(g, url, str(daten.get("titel") or ""), str(daten.get("bild") or ""),
                                                                    bool(daten.get("live")), cast_oeffnen=oeffnen, mime=mime or None)
            if pfad == "/api/cast/steuern":
                return 200, "application/json", {"stand": fernseher.steuern(g, str(daten.get("was") or ""), daten.get("wert"),
                                                                            cast_oeffnen=oeffnen)}
            if pfad == "/api/cast/livetv":  # Enigma2: TV- oder Radio-Favoriten als Live-TV-Listen
                if g.get("art") != "enigma2":
                    raise ValueError("Nur für Receiver mit Enigma2")
                vorhanden = {l["name"] for l in self.app.livetv["listen"]}
                neu = [l for l in fernseher.enigma2_bouquets(g, str(daten.get("art") or "tv")) if l["name"] not in vorhanden]
                if neu:
                    self.app.setze_livetv(dict(self.app.livetv, listen=self.app.livetv["listen"] + neu))
                return 200, "application/json", {"neu": [l["name"] for l in neu]}
        except (ValueError, UnicodeDecodeError, fernseher.GeraetFehler, cast.CastFehler, OSError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        return 404, "application/json", {"fehler": "nicht gefunden"}
