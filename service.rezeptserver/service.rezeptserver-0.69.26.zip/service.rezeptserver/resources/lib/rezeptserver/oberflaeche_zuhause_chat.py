"""Videochat: Raeume und WebRTC-Vermittlung."""

from .oberflaeche_grund import (
    json,
    videochat,
)

class ChatMixin:

    # --- Videochat (WebRTC-Vermittlung) ---------------------------------------------
    def chat_lesen(self, pfad, werte):
        try:
            if pfad == "/api/chat/raeume":
                return 200, "application/json", {"raeume": self.app.videochat.raeume()}
            return 200, "application/json", self.app.videochat.abholen(werte.get("raum", ""), werte.get("ich", ""))
        except videochat.ChatFehler as fehler:
            return 400, "application/json", {"fehler": str(fehler)}

    def chat_post(self, pfad, koerper):
        try:
            daten = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(daten, dict):
                raise ValueError("JSON-Objekt erwartet")
            vc = self.app.videochat
            if pfad == "/api/chat/beitreten":
                return 200, "application/json", vc.beitreten(daten.get("raum"), daten.get("name"))
            if pfad == "/api/chat/senden":
                vc.senden(daten.get("raum"), str(daten.get("von") or ""), str(daten.get("an") or ""),
                          str(daten.get("art") or ""), daten.get("daten"))
                return 200, "application/json", {"ok": True}
        except (ValueError, UnicodeDecodeError, videochat.ChatFehler) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        return 404, "application/json", {"fehler": "nicht gefunden"}
