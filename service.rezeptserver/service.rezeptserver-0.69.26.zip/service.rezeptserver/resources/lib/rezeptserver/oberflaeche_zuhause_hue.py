"""Philips Hue: Bridge suchen, koppeln und Lampen/Raeume schalten."""

from .oberflaeche_grund import (
    hue,
    json,
)

class HueMixin:

    # --- Licht (Philips Hue) -----------------------------------------------------
    def _hue(self):
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        try:
            return hue.Hue(daten.get(hue.SCHLUESSEL), getattr(self.app, "hue_holen", None))
        except hue.HueFehler:
            return hue.Hue({}, getattr(self.app, "hue_holen", None))

    def hue_lesen(self, pfad):
        try:
            if pfad == "/api/hue/suchen":
                return 200, "application/json", {"bridges": hue.suchen(getattr(self.app, "hue_holen", None))}
            h = self._hue()
            antwort = {"bereit": h.bereit, "bridge": h.e["bridge"]}
            if h.bereit:
                antwort.update(h.zustand())
            return 200, "application/json", antwort
        except hue.HueFehler as fehler:
            return 200, "application/json", {"bereit": False, "bridge": self._hue().e["bridge"], "fehler": str(fehler)}

    def hue_post(self, pfad, koerper):
        try:
            daten = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(daten, dict):
                raise ValueError("JSON-Objekt erwartet")
            if pfad == "/api/hue/koppeln":
                bridge = str(daten.get("bridge") or "").strip()
                hue.pruefe({"bridge": bridge})
                benutzer = hue.koppeln(bridge, getattr(self.app, "hue_holen", None))
                if not self.app.verwaltung:
                    raise ValueError("Nutzerdaten nicht verfügbar")
                self.app.verwaltung.abschnitt(hue.SCHLUESSEL, {"bridge": bridge, "benutzer": benutzer})
                return self.hue_lesen("/api/hue")
            if pfad == "/api/hue/trennen":
                self.app.verwaltung.abschnitt(hue.SCHLUESSEL, {"bridge": "", "benutzer": ""})
                return self.hue_lesen("/api/hue")
            h = self._hue()
            if pfad == "/api/hue/alle":
                h.alle(bool(daten.get("an")))
            elif pfad == "/api/hue/schalten":
                h.schalten(str(daten.get("art")), str(daten.get("id")), daten.get("an"), daten.get("hell"),
                           daten.get("farbtemp"), daten.get("szene"))
            else:
                return 404, "application/json", {"fehler": "nicht gefunden"}
            return self.hue_lesen("/api/hue")
        except (ValueError, UnicodeDecodeError, hue.HueFehler) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
