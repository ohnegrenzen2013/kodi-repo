"""IP-Kameras: Zustand, Live-Bild, Snaps und HLS-Adressen."""

from .oberflaeche_grund import (
    base64,
    json,
    kameras,
    unquote,
)

class KameraMixin:

    # --- Kameras (IP-Webcams): live, Snaps, Ueberwachung ------------------------
    def _kamera(self, kid):
        k = next((x for x in self.app.kameras if x["id"] == str(kid or "")), None)
        if not k:
            raise kameras.KameraFehler("Kamera gibt es nicht (mehr)")
        return k

    def _kameras_zustand(self):
        return {"kameras": kameras.oeffentlich(self.app.kameras), "arten": kameras.ARTEN, "intervalle": list(kameras.INTERVALLE),
                "vorschlaege": kameras.VORSCHLAEGE, "fehler": self.app.snaps.fehler}

    def kameras_lesen(self, pfad, werte):
        try:
            if pfad == "/api/kameras":
                return 200, "application/json", self._kameras_zustand()
            if pfad.startswith("/api/kameras/bild/"):
                return 200, "image/jpeg", kameras.bild(self._kamera(pfad.rsplit("/", 1)[1]))
            if pfad.startswith("/api/kameras/live/"):
                k = self._kamera(pfad.rsplit("/", 1)[1])
                if k["art"] != "mjpeg":
                    raise kameras.KameraFehler("Live-Strom nur bei MJPEG")
                return "kamera", k
            if pfad == "/api/kameras/snaps":
                return 200, "application/json", {"snaps": self.app.snaps.liste(werte.get("id", ""))}
            if pfad.startswith("/api/kameras/snap/"):
                kid, _, name = pfad[len("/api/kameras/snap/"):].partition("/")
                return "lokal", self.app.snaps.pfad(kid, unquote(name))
        except (kameras.KameraFehler, OSError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        return 404, "application/json", {"fehler": "nicht gefunden"}

    def kameras_post(self, pfad, koerper):
        try:
            daten = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(daten, dict):
                raise ValueError("JSON-Objekt erwartet")
            if pfad == "/api/kameras":
                if not self.app.verwaltung:
                    raise ValueError("Nutzerdaten nicht verfügbar")
                neu = kameras.pruefe(daten.get("kameras"), self.app.kameras)
                self.app.verwaltung.abschnitt(kameras.SCHLUESSEL, neu)
                self.app.kameras = neu
                return 200, "application/json", self._kameras_zustand()
            k = self._kamera(daten.get("id"))
            if pfad == "/api/kameras/snap":
                return 200, "application/json", {"name": self.app.snaps.speichern(k), "snaps": self.app.snaps.liste(k["id"])}
            if pfad == "/api/kameras/snap_weg":
                self.app.snaps.loeschen(k["id"], None if daten.get("alle") else str(daten.get("name") or ""))
                return 200, "application/json", {"snaps": self.app.snaps.liste(k["id"])}
            if pfad == "/api/kameras/hls":
                if k["art"] != "hls":
                    raise kameras.KameraFehler("Keine HLS-Kamera")
                kopf = {}
                if k.get("benutzer") or k.get("passwort"):
                    kopf["Authorization"] = "Basic " + base64.b64encode(("%s:%s" % (k["benutzer"], k["passwort"])).encode()).decode()
                return 200, "application/json", {"url": self.hls_merken(k["url"], kopf)}
        except (ValueError, UnicodeDecodeError, kameras.KameraFehler, OSError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        return 404, "application/json", {"fehler": "nicht gefunden"}
