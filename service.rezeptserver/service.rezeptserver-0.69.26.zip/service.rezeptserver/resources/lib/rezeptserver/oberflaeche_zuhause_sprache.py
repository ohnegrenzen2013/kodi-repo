"""Sprachbefehle: Schluessel, Webhook und Befehlsausfuehrung wie in Telegram."""

from .oberflaeche_grund import (
    json,
    log,
    secrets,
    sprachbefehl,
)

class SpracheMixin:

    # --- Sprachbefehle (Webhook fuer Home Assistant / IFTTT, z. B. von Google Home) --------
    def _sprach_schluessel(self):
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        return str((daten.get("sprachsteuerung") or {}).get("schluessel") or "")

    def sprachsteuerung_post(self, koerper):
        """{neu: true} erzeugt einen neuen Schluessel, {aus: true} schaltet ab; Antwort: Schluessel und Beispiele."""
        try:
            daten = json.loads(koerper.decode("utf-8") or "{}")
            if not self.app.verwaltung:
                raise ValueError("Nutzerdaten nicht verfügbar")
            schluessel = secrets.token_urlsafe(24) if daten.get("neu") else ("" if daten.get("aus") else self._sprach_schluessel())
            self.app.verwaltung.abschnitt("sprachsteuerung", {"schluessel": schluessel})
            return 200, "application/json", {"schluessel": schluessel}
        except (ValueError, UnicodeDecodeError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}

    def befehl_ausfuehren(self, werte):
        """Befehl wie in Telegram ("licht aus", "/pihole aus 10", "status") – nur mit dem Schluessel."""
        schluessel = self._sprach_schluessel()
        if not isinstance(werte, dict) or not schluessel or not secrets.compare_digest(str(werte.get("schluessel") or "").encode("utf-8"), schluessel.encode("utf-8")):
            return 403, "application/json", {"fehler": "Sprachsteuerung aus oder Schlüssel falsch"}
        text = " ".join(str(werte.get("text") or "").split())[:300]
        if not text:
            return 400, "application/json", {"fehler": "text fehlt"}
        antwort = self.app.telegram.befehl(sprachbefehl(text))
        log.info("Sprachbefehl: %s", text)
        return 200, "application/json", {"antwort": antwort, "befehl": sprachbefehl(text)}
