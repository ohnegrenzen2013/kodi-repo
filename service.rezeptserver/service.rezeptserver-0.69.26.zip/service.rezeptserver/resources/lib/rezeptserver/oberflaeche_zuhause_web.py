"""Webhosting: Einstellungen und Installieren von phpMyAdmin, phpBB, WordPress, WoltLab, Adminer, ARVIO."""

from .oberflaeche_grund import (
    json,
    log,
    os,
    webhosting,
)

try:
    from . import arvio_web
except Exception:  # pragma: no cover
    arvio_web = None


class WebMixin:

    # --- Webhosting (phpMyAdmin, phpBB, WordPress, WoltLab, Adminer) -----------------
    def web_zustand(self):
        e = webhosting.einstellung(self.app.verwaltung.daten() if self.app.verwaltung else {})
        da = webhosting.installiert(e["ordner"])
        erg = {"einstellung": e, "web_erreichbar": webhosting.erreichbar(e["web"]), "pma_erreichbar": webhosting.erreichbar(e["phpmyadmin"]),
               "ordner_da": bool(e["ordner"] and os.path.isdir(e["ordner"])), "docker": bool(os.environ.get("H0RST_WEB_ORDNER"))}
        p = arvio_web.pruefe(e["ordner"]) if arvio_web is not None else {"vorhanden": False, "version": ""}
        ana = []
        for aid, a in webhosting.ANWENDUNGEN.items():
            inst = bool(p.get("vorhanden")) if aid == "arvio" else aid in da
            ana.append(dict(a, id=aid, installiert=inst))
        erg["anwendungen"] = ana
        webadresse = (e["web"] or "").rstrip("/")
        if arvio_web is not None:
            erg["arvio"] = dict(p, adresse=e["web"], erreichbar=arvio_web.erreichbar(webadresse + "/arvio/") if webadresse else None)
        else:
            erg["arvio"] = {"vorhanden": False, "version": "", "adresse": e["web"], "erreichbar": None}
        return erg

    def web_post(self, pfad, koerper):
        fehler_klassen = [ValueError, webhosting.WebFehler, OSError]  # UnicodeDecodeError ist eine ValueError
        if arvio_web is not None:
            fehler_klassen.append(arvio_web.ArvioFehler)
        try:
            daten = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(daten, dict):
                raise ValueError("JSON-Objekt erwartet")
            if pfad == "/api/web/einstellungen":
                if not self.app.verwaltung:
                    raise ValueError("Nutzerdaten nicht verfügbar")
                self.app.verwaltung.abschnitt(webhosting.SCHLUESSEL, webhosting.pruefe(daten))
                return 200, "application/json", self.web_zustand()
            if pfad == "/api/web/installieren":
                e = webhosting.einstellung(self.app.verwaltung.daten() if self.app.verwaltung else {})
                anwendung = str(daten.get("anwendung") or "")
                if anwendung == "arvio":
                    if arvio_web is None:
                        raise webhosting.WebFehler("ARVIO-Unterstützung nicht verfügbar")
                    tmdb = str(daten.get("tmdb") or "").strip() or None
                    r = arvio_web.installieren(e["ordner"], tmdb, getattr(self.app, "web_holen", None))
                    log.info("Webhosting: ARVIO installiert (%s)", r.get("version"))
                    return 200, "application/json", dict(self.web_zustand(), ergebnis=r)
                r = webhosting.installieren(anwendung, e["ordner"], getattr(self.app, "web_holen", None))
                log.info("Webhosting: %s installiert (%s)", anwendung, r.get("version"))
                return 200, "application/json", dict(self.web_zustand(), ergebnis=r)
            if pfad == "/api/web/arvio/bauen" and arvio_web is not None:
                e = webhosting.einstellung(self.app.verwaltung.daten() if self.app.verwaltung else {})
                r = arvio_web.bauen(e["ordner"])
                log.info("Webhosting: ARVIO gebaut (%s)", r.get("version"))
                return 200, "application/json", dict(self.web_zustand(), ergebnis=r)
        except tuple(fehler_klassen) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        return 404, "application/json", {"fehler": "nicht gefunden"}
