"""Ollama fuer den lokalen KI-Modus (ki_anbieter.py) einrichten: auf dem Server installieren (offizielles
Installationsskript, Muster xdcc_client.Auftrag - ein Hintergrund-Thread, Zustand per Dict abfragbar) und
ein Modell von Ollamas eigener HuggingFace-Anbindung ziehen (POST /api/pull, NDJSON-Fortschritt).

Die Termux-Installation laeuft separat ueber die Android-App (TermuxSteuerung.java, Aktion
"ollama_installieren") - hier nur der Server-seitige Weg, da der Python-Prozess dort selbst die Shell
erreicht."""

import json
import shutil
import subprocess
import threading
import urllib.request

from .ki_anbieter import QWEN_CODER_VORSCHLAG

INSTALL_SKRIPT_URL = "https://ollama.com/install.sh"
INSTALL_ZEITLIMIT = 600  # Sekunden fuer das Installationsskript
PULL_ZEITLIMIT = 1800  # Sekunden fuer einen Modell-Download (mehrere GB auf langsamer Leitung)

# RAM-Stufen fuer die Groessen-Empfehlung (empfehlung()). Belegt sind nur drei Punkte: Ollamas eigenes
# README (github.com/ollama/ollama) nennt "mindestens 8 GB RAM fuer 7B-, 16 GB fuer 13B- und 32 GB fuer
# 33B-Modelle". Die Stufen fuer 0.5B/1.5B/3B sind davon linear fortgeschrieben, nicht einzeln belegt; 14B
# uebernimmt den 13B-Wert (naechstgelegene Qwen-Groesse). Quantisierung Q3_K_M statt des sonst ueblichen
# Q4_K_M, weil Q4_K_M in diesen Repos zusaetzlich als sharded Datei-Paar vorliegt und Ollama den Tag dann
# auf die nicht unterstuetzte sharded Variante aufloest (siehe ki_anbieter.QWEN_CODER_VORSCHLAG). 32B
# bewusst NICHT in dieser Tabelle: dort liegt JEDE gepruefte Quantisierung (Q2_K bis Q8_0) ebenfalls
# sharded+zusammengefuehrt vor, kein einzeldatei-sicherer Tag gefunden - RAM ab 16 GB bleibt deshalb bei
# der verifiziert sicheren 14B-Empfehlung statt ein wissentlich kaputtes 32B-Modell vorzuschlagen.
# Dateigroessen (Q3_K_M) stammen aus den jeweiligen huggingface.co/Qwen/Qwen2.5-Coder-<N>-Instruct-GGUF-Repos.
_RAM_STUFEN = (
    (2 * 1024, "0.5B", 0.43),
    (4 * 1024, "1.5B", 0.92),
    (6 * 1024, "3B", 1.72),
    (8 * 1024, "7B", 3.81),
    (16 * 1024, "14B", 7.34),
)


class OllamaSetupFehler(Exception):
    pass


def _server_ram_mb():
    """Gesamter Arbeitsspeicher dieses Prozesses (MemTotal aus /proc/meminfo) in MB, 0 falls nicht lesbar
    (z. B. kein Linux) - fuer die Server-Installation ist das der relevante Rechner, kein Client-Wert noetig."""
    try:
        with open("/proc/meminfo", "r", encoding="utf-8") as datei:
            for zeile in datei:
                if zeile.startswith("MemTotal:"):
                    return int(zeile.split()[1]) // 1024
    except (OSError, ValueError, IndexError):
        pass
    return 0


def empfehlung(ram_mb=0):
    """Schlaegt eine Qwen2.5-Coder-Groesse anhand des Arbeitsspeichers vor. ram_mb kommt vom Aufrufer (z. B.
    dem Android-Geraet bei einer Termux-Installation); ist nichts angegeben, wird der RAM dieses
    Server-Prozesses selbst gelesen (fuer "Auf dem Server installieren"). Wirft nie."""
    try:
        ram_mb = int(ram_mb or 0)
    except (TypeError, ValueError):
        ram_mb = 0
    quelle = "angegeben"
    if ram_mb <= 0:
        ram_mb = _server_ram_mb()
        quelle = "server"
    if ram_mb <= 0:
        return {"modell": QWEN_CODER_VORSCHLAG, "groesse_gb": 3.81, "ram_mb": 0,
                "text": "RAM nicht ermittelbar – Standardvorschlag Qwen2.5-Coder-7B-Instruct (≈3,81 GB, Q3_K_M)."}
    name, groesse_gb = _RAM_STUFEN[0][1], _RAM_STUFEN[0][2]
    for grenze, n, g in _RAM_STUFEN:
        if ram_mb >= grenze:
            name, groesse_gb = n, g
    modell = "hf.co/Qwen/Qwen2.5-Coder-%s-Instruct-GGUF:Q3_K_M" % name
    text = ("Bei %.1f GB RAM (%s): Qwen2.5-Coder-%s-Instruct (≈%.1f GB, Q3_K_M). Ollama selbst nennt 8 GB "
            "RAM für 7B-, 16 GB für 13B- und 32 GB für 33B-Modelle als Richtwert (ab 16 GB bleibt es bei "
            "14B – für 32B liefert Ollamas HuggingFace-Anbindung bei diesem Repo aktuell keinen "
            "funktionierenden Tag)."
            % (ram_mb / 1024.0, "Gerät" if quelle == "angegeben" else "Server", name, groesse_gb))
    return {"modell": modell, "groesse_gb": groesse_gb, "ram_mb": ram_mb, "text": text}


class ServerInstallation:
    """Installiert Ollama auf dem Server (PC/Pi/Docker) ueber das offizielle Installationsskript.

    Laedt das Skript von ollama.com (feste Adresse, keine Nutzereingabe) und fuehrt es ueber stdin an
    "sh" aus - bewusst kein shell=True und keine Einbettung in einen Befehlsstring, damit nichts
    interpoliert wird. Laeuft mit genau den Rechten des H0rSt-Prozesses, keine Rechteausweitung."""

    def __init__(self, holen=None):
        self.holen = holen or (lambda url: urllib.request.urlopen(url, timeout=30))
        self._sperre = threading.Lock()
        self.laeuft = False
        self.fertig = False
        self.ok = None
        self.ausgabe = ""

    def zustand(self):
        return {"laeuft": self.laeuft, "fertig": self.fertig, "ok": self.ok, "ausgabe": self.ausgabe,
                "installiert": bool(shutil.which("ollama"))}

    def starten(self):
        with self._sperre:
            if self.laeuft:
                raise OllamaSetupFehler("Installation läuft bereits")
            self.laeuft = True
            self.fertig = False
            self.ok = None
            self.ausgabe = ""
        threading.Thread(target=self._lauf, name="ollama-install", daemon=True).start()

    def _lauf(self):
        try:
            with self.holen(INSTALL_SKRIPT_URL) as antwort:
                skript = antwort.read().decode("utf-8", "replace")
        except Exception as fehler:
            self._abschliessen(False, "Installationsskript nicht ladbar: %s" % fehler)
            return
        try:
            ergebnis = subprocess.run(["sh"], input=skript, capture_output=True, text=True,
                                      timeout=INSTALL_ZEITLIMIT)
            text = (ergebnis.stdout or "") + (ergebnis.stderr or "")
        except subprocess.TimeoutExpired:
            self._abschliessen(False, "Zeitlimit überschritten (%d s)" % INSTALL_ZEITLIMIT)
            return
        except Exception as fehler:
            self._abschliessen(False, str(fehler))
            return
        self._abschliessen(bool(shutil.which("ollama")), text[-4000:])

    def _abschliessen(self, ok, ausgabe):
        with self._sperre:
            self.laeuft = False
            self.fertig = True
            self.ok = ok
            self.ausgabe = ausgabe


class ModellPull:
    """Zieht ein Modell in eine laufende Ollama-Instanz (POST /api/pull, NDJSON-Fortschritt).

    Unterstuetzt auch Ollamas eigene HuggingFace-Anbindung (Modellname "hf.co/<repo>:<quantisierung>",
    siehe huggingface.co/docs/hub/en/ollama) - das ist Ollamas Mechanik, kein eigener Download."""

    def __init__(self, holen=None):
        self.holen = holen
        self._sperre = threading.Lock()
        self.laeuft = False
        self.fertig = False
        self.ok = None
        self.modell = ""
        self.status = ""
        self.total = 0
        self.completed = 0
        self.fehler = ""

    def zustand(self):
        with self._sperre:
            prozent = round(100.0 * self.completed / self.total, 1) if self.total else 0.0
            return {"laeuft": self.laeuft, "fertig": self.fertig, "ok": self.ok, "modell": self.modell,
                    "status": self.status, "total": self.total, "completed": self.completed,
                    "prozent": prozent, "fehler": self.fehler}

    def starten(self, ollama_url, modell=None):
        modell = (modell or QWEN_CODER_VORSCHLAG).strip()
        if not modell:
            raise OllamaSetupFehler("Modellname fehlt")
        with self._sperre:
            if self.laeuft:
                raise OllamaSetupFehler("Es läuft bereits ein Modell-Download")
            self.laeuft = True
            self.fertig = False
            self.ok = None
            self.modell = modell
            self.status = "wird gestartet …"
            self.total = self.completed = 0
            self.fehler = ""
        threading.Thread(target=self._lauf, args=(ollama_url, modell), name="ollama-pull", daemon=True).start()

    def _lauf(self, ollama_url, modell):
        url = ollama_url.rstrip("/") + "/api/pull"
        koerper = json.dumps({"name": modell, "stream": True}).encode("utf-8")
        oeffnen = self.holen or (lambda req: urllib.request.urlopen(req, timeout=PULL_ZEITLIMIT))
        try:
            anfrage = urllib.request.Request(url, data=koerper, headers={"Content-Type": "application/json"})
            with oeffnen(anfrage) as antwort:
                for zeile in antwort:
                    zeile = zeile.strip()
                    if not zeile:
                        continue
                    try:
                        teil = json.loads(zeile)
                    except ValueError:
                        continue
                    self._fortschritt(teil)
                    if teil.get("error"):
                        self._abschliessen(False, str(teil["error"]))
                        return
                    if teil.get("status") == "success":
                        self._abschliessen(True, "")
                        return
        except Exception as fehler:
            self._abschliessen(False, str(fehler))
            return
        self._abschliessen(False, "Verbindung endete ohne Erfolgsmeldung")

    def _fortschritt(self, teil):
        with self._sperre:
            if teil.get("status"):
                self.status = str(teil["status"])
            if teil.get("total"):
                self.total = int(teil["total"])
            if teil.get("completed"):
                self.completed = int(teil["completed"])

    def _abschliessen(self, ok, fehler):
        with self._sperre:
            self.laeuft = False
            self.fertig = True
            self.ok = ok
            self.fehler = fehler
            if ok:
                self.status = "fertig"
