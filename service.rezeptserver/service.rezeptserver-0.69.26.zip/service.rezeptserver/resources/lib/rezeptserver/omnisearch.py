"""OmniSearch-Funktionen fuer H0rSts freigegebene lokale Datei-Orte.

Eul45/omni-search (MIT) ist das Vorbild fuer Suche, Filter und Duplikatgruppen.
Der Windows-Scanner mit NTFS USN/MFT wird nicht kopiert: H0rSt laeuft auf
verschiedenen Systemen und durchsucht hier nur die Orte aus dateien.py. Symbolische
Links werden nicht verfolgt. Jeder Lauf ist begrenzt; ein abgeschnittener Lauf ist
in der Antwort ausdruecklich als unvollstaendig markiert.
"""

import hashlib
import os
import re

from .heimspeicher import art_von

REPO = "Eul45/omni-search"
REPO_URL = "https://github.com/" + REPO
APP_ID = "github:" + REPO
PAKET = "com.omnisearch.app"
MAX_SCAN = 50000
MAX_TREFFER = 5000
MAX_SEITE = 200
MAX_HASH_DATEIEN = 1000
MAX_HASH_BYTES = 2 * 1024 ** 3
MAX_GRUPPEN = 100
_DOKUMENTE = (".pdf", ".txt", ".md", ".doc", ".docx", ".odt", ".rtf", ".csv", ".xls", ".xlsx", ".ppt", ".pptx")
_ARCHIVE = (".zip", ".7z", ".rar", ".tar", ".gz", ".bz2", ".xz")
_EXT = re.compile(r"(?:^|\s)ext:([^\s]+)", re.I)


class OmniFehler(ValueError):
    pass


def _zahl(wert, standard, minimum, maximum):
    try:
        return max(minimum, min(maximum, int(str(wert or standard))))
    except (TypeError, ValueError):
        return standard


def _art(name, ordner=False):
    if ordner:
        return "ordner"
    n = name.lower()
    if n.endswith(".apk"):
        return "apk"
    if n.endswith(_DOKUMENTE):
        return "dokument"
    if n.endswith(_ARCHIVE):
        return "archiv"
    return art_von(name)


def _eintrag(ort, rel, name, daten, ordner=False):
    return {"ort": ort["id"], "ort_name": ort["name"], "pfad": rel, "name": name,
            "ordner": ordner, "groesse": 0 if ordner else int(daten.st_size), "zeit": int(daten.st_mtime),
            "art": _art(name, ordner), "endung": "" if ordner else os.path.splitext(name)[1].lower().lstrip(".")}


def _orte(dateien, auswahl):
    verfuegbar = [o for o in dateien.orte() if o.get("da")]
    if not auswahl:
        return verfuegbar
    treffer = [o for o in verfuegbar if o["id"] == auswahl]
    if not treffer:
        raise OmniFehler("Ort nicht gefunden oder nicht eingehängt")
    return treffer


def _lauf(dateien, auswahl, besucher, grenze=MAX_SCAN):
    """Ruft besucher(oeffentlicher_eintrag, absoluter_pfad) auf; keine Symlinks."""
    gelesen, abgebrochen = 0, False
    fehler = []
    for ort in _orte(dateien, auswahl):
        try:
            wurzel = dateien.pfad(ort["id"], "")
        except (ValueError, OSError) as fehler_text:
            fehler.append(str(fehler_text)[:200])
            continue
        stapel = [(wurzel, "")]
        while stapel and not abgebrochen:
            aktuell, rel = stapel.pop()
            try:
                with os.scandir(aktuell) as eintraege:
                    namen = sorted(eintraege, key=lambda e: e.name.casefold())
            except OSError as fehler_text:
                fehler.append((rel or ort["name"]) + ": " + str(fehler_text.strerror or fehler_text)[:160])
                continue
            for eintrag in namen:
                if gelesen >= grenze:
                    abgebrochen = True
                    break
                try:
                    if eintrag.is_symlink():
                        continue
                    daten = eintrag.stat(follow_symlinks=False)
                    ordner = eintrag.is_dir(follow_symlinks=False)
                except OSError as fehler_text:
                    fehler.append(eintrag.name + ": " + str(fehler_text.strerror or fehler_text)[:160])
                    continue
                gelesen += 1
                kind_rel = (rel + "/" if rel else "") + eintrag.name
                oeffentlich = _eintrag(ort, kind_rel, eintrag.name, daten, ordner)
                besucher(oeffentlich, eintrag.path)
                if ordner:
                    stapel.append((eintrag.path, kind_rel))
    return {"gelesen": gelesen, "vollstaendig": not abgebrochen, "fehler": fehler[:20]}


def _suchbegriffe(text, extra_ext=""):
    endungen = [e.lower().lstrip(".")[:32] for e in _EXT.findall(text or "")]
    if extra_ext.strip():
        endungen.extend(e.lower().lstrip(".")[:32] for e in extra_ext.split(",") if e.strip())
    frei = _EXT.sub(" ", text or "")
    woerter = [w.casefold() for w in frei.split() if w][:20]
    return woerter, sorted(set(endungen))[:10]


def suchen(dateien, werte):
    """Datei-/Ordnernamen suchen; ext:pdf und Filter wie beim OmniSearch-Vorbild."""
    text = str(werte.get("q") or "")[:200]
    woerter, endungen = _suchbegriffe(text, str(werte.get("ext") or "")[:100])
    if not woerter and not endungen:
        raise OmniFehler("Suchtext oder ext:-Endung angeben")
    art = str(werte.get("art") or "")
    if art and art not in ("video", "audio", "bild", "datei", "dokument", "archiv", "apk", "ordner"):
        raise OmniFehler("Unbekannte Dateiart")
    mit_ordnern = str(werte.get("ordner") or "") == "1"
    min_groesse = _zahl(werte.get("min"), 0, 0, 1 << 50)
    max_groesse = _zahl(werte.get("max"), 1 << 50, 0, 1 << 50)
    von = _zahl(werte.get("von"), 0, 0, 1 << 50)
    bis = _zahl(werte.get("bis"), 1 << 50, 0, 1 << 50)
    treffer, gesamt, zu_viele = [], 0, False

    def pruefen(e, _voll):
        nonlocal gesamt, zu_viele
        if e["ordner"] and not mit_ordnern:
            return
        if art and e["art"] != art or e["groesse"] < min_groesse or e["groesse"] > max_groesse:
            return
        if e["zeit"] < von or e["zeit"] > bis or endungen and e["endung"] not in endungen:
            return
        heu = e["pfad"].casefold()
        if not all(w in heu for w in woerter):
            return
        gesamt += 1
        if len(treffer) < MAX_TREFFER:
            treffer.append(e)
        else:
            zu_viele = True

    lauf = _lauf(dateien, str(werte.get("ort") or ""), pruefen)
    sortierung = str(werte.get("sort") or "name")
    schluessel = {"name": lambda e: (not e["ordner"], e["name"].casefold(), e["pfad"].casefold()),
                  "neu": lambda e: (-e["zeit"], e["name"].casefold()),
                  "groesse": lambda e: (-e["groesse"], e["name"].casefold())}.get(sortierung)
    if schluessel is None:
        raise OmniFehler("Sortierung: name, neu oder groesse")
    treffer.sort(key=schluessel)
    offset = _zahl(werte.get("offset"), 0, 0, MAX_TREFFER)
    limit = _zahl(werte.get("limit"), 100, 1, MAX_SEITE)
    return dict(lauf, treffer=treffer[offset:offset + limit], gesamt=gesamt, offset=offset,
                weiter=offset + limit < min(gesamt, len(treffer)), begrenzt=zu_viele or not lauf["vollstaendig"])


def _sha256(pfad, erwartete_groesse):
    if os.path.getsize(pfad) != erwartete_groesse:
        raise OSError("Datei wurde während des Lesens geändert")
    h = hashlib.sha256()
    with open(pfad, "rb") as f:
        while True:
            stueck = f.read(1024 * 1024)
            if not stueck:
                break
            h.update(stueck)
    return h.hexdigest()


def duplikate(dateien, werte):
    """Echte Duplikate: zuerst Groesse, dann SHA-256; niemals nur Dateinamen."""
    min_groesse = _zahl(werte.get("min"), 1, 1, 1 << 50)
    nach_groesse = {}

    def sammeln(e, voll):
        if not e["ordner"] and e["groesse"] >= min_groesse:
            nach_groesse.setdefault(e["groesse"], []).append((e, voll))

    lauf = _lauf(dateien, str(werte.get("ort") or ""), sammeln)
    kandidaten = [gruppe for gruppe in nach_groesse.values() if len(gruppe) > 1]
    kandidaten.sort(key=lambda g: (-(len(g) - 1) * g[0][0]["groesse"], g[0][0]["pfad"].casefold()))
    gruppen, gehasht, gelesene_bytes, abgebrochen = [], 0, 0, False
    fehler = list(lauf["fehler"])
    for kandidat in kandidaten:
        if len(gruppen) >= MAX_GRUPPEN or gehasht >= MAX_HASH_DATEIEN:
            abgebrochen = True
            break
        nach_hash = {}
        for e, voll in sorted(kandidat, key=lambda x: x[0]["pfad"].casefold()):
            if gehasht >= MAX_HASH_DATEIEN or gelesene_bytes + e["groesse"] > MAX_HASH_BYTES:
                abgebrochen = True
                break
            try:
                digest = _sha256(voll, e["groesse"])
                gehasht += 1
                gelesene_bytes += e["groesse"]
                nach_hash.setdefault(digest, []).append(e)
            except OSError as fehler_text:
                fehler.append(e["pfad"] + ": " + str(fehler_text)[:160])
        for digest, dateien_gruppe in nach_hash.items():
            if len(dateien_gruppe) > 1 and len(gruppen) < MAX_GRUPPEN:
                groesse = dateien_gruppe[0]["groesse"]
                gruppen.append({"id": digest[:20], "groesse": groesse, "frei": groesse * (len(dateien_gruppe) - 1),
                                "dateien": dateien_gruppe})
        if abgebrochen:
            break
    gruppen.sort(key=lambda g: (-g["frei"], g["id"]))
    return dict(lauf, fehler=fehler[:20], gruppen=gruppen, gehasht=gehasht, gelesene_bytes=gelesene_bytes,
                ersparnis=sum(g["frei"] for g in gruppen), vollstaendig=lauf["vollstaendig"] and not abgebrochen,
                begrenzt=abgebrochen or not lauf["vollstaendig"])


def zustand(dateien):
    return {"name": "OmniSearch", "repo": REPO_URL, "app_id": APP_ID, "paket": PAKET,
            "orte": [{"id": o["id"], "name": o["name"]} for o in _orte(dateien, "")],
            "grenzen": {"scan": MAX_SCAN, "treffer": MAX_TREFFER, "hash_dateien": MAX_HASH_DATEIEN,
                        "hash_bytes": MAX_HASH_BYTES, "gruppen": MAX_GRUPPEN}}
