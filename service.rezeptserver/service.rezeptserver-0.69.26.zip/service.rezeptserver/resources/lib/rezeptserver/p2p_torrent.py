"""P2P-Torrent (NV4, Server-Pfad): Magnet-Link/infoHash über ein extern laufendes aria2c (JSON-RPC,
"--enable-rpc") lokal herunterladen, danach normal abspielen - kein echtes Streaming waehrend des Ladens.

Verifiziert gegen die aria2-Dokumentation (aria2.github.io/manual): "--stream-piece-selector=inorder"
gilt nur fuer HTTP/FTP-Downloads, nicht BitTorrent. Fuer BitTorrent gibt es nur
"--bt-prioritize-piece=head,tail" (bevorzugt nur Anfang/Ende jeder Datei, "useful for previewing files") -
kein zuverlaessiges sequenzielles Laden ueber die ganze Datei. Eine Wiedergabe, die schon waehrend des
Ladens startet, wuerde bei einem Seek in einen noch nicht geladenen Bereich haengen bleiben, ohne dass
aria2 das garantiert aufloest. Deshalb laedt H0rSt hier vollstaendig lokal herunter (mit Fortschritts-
anzeige wie bei XDCC) und spielt erst danach ab. Echtes Streaming-waehrend-des-Ladens gibt es nur im
internen Android-Player (libtorrent4j, eigener Sequential-Modus, eigenstaendiger Code-Pfad).

aria2c laeuft als eigener, vom Nutzer selbst gestarteter Dienst (gleiches Muster wie rustnzb/vxparser) -
H0rSt startet ihn nicht selbst, verbindet sich nur per JSON-RPC (http://host:port/jsonrpc)."""

import json
import logging
import os
import threading
import time

from .debrid_grund import DebridFehler, datei_waehlen, magnet_von
from .netz import NetzFehler, antwort_holen

log = logging.getLogger("rezeptserver")

STANDARD_ADRESSE = "http://127.0.0.1:6800/jsonrpc"
ORDNER = "p2p_torrent"
MAX_AUFTRAEGE = 3
MAX_VERLAUF = 30
METADATEN_FRIST = 60.0
POLL = 1.5


class P2pTorrentFehler(Exception):
    pass


def _rpc(adresse, geheim, methode, parameter, holen):
    args = (["token:" + geheim] if geheim else []) + list(parameter)
    koerper = json.dumps({"jsonrpc": "2.0", "id": "h0rst", "method": methode, "params": args})
    try:
        status, text = holen(adresse, "POST", {"Content-Type": "application/json"}, koerper, 10.0)
    except NetzFehler as fehler:
        raise P2pTorrentFehler("aria2c nicht erreichbar: %s" % fehler)
    try:
        antwort = json.loads(text)
    except ValueError:
        raise P2pTorrentFehler("aria2c: unerwartete Antwort (HTTP %d)" % status)
    if not isinstance(antwort, dict) or "result" not in antwort:
        fehlertext = (antwort.get("error") or {}).get("message") if isinstance(antwort, dict) else None
        raise P2pTorrentFehler("aria2c: %s" % (fehlertext or ("unerwartete Antwort (HTTP %d)" % status)))
    return antwort["result"]


class Auftrag:
    def __init__(self, nummer, name, magnet, staffel, folge, ordner):
        self.id = str(nummer)
        self.name = name or "Torrent"
        self.magnet = magnet
        self.staffel, self.folge = staffel, folge
        self.ordner = ordner
        self.status = "wartet"  # wartet -> metadaten -> laedt -> fertig | fehler | abgebrochen
        self.fehler = ""
        self.groesse = 0
        self.geladen = 0
        self.tempo = 0
        self.peers = 0
        self.seeds = 0
        self.dateiname = ""
        self.datei_pfad = ""
        self.gid = None
        self.start = time.time()
        self.ende = None
        self._halt = threading.Event()

    def als_dict(self):
        return {"id": self.id, "name": self.name, "status": self.status, "fehler": self.fehler,
                "groesse": self.groesse, "geladen": self.geladen,
                "prozent": round(100.0 * self.geladen / self.groesse, 1) if self.groesse else 0.0,
                "tempo": self.tempo, "peers": self.peers, "seeds": self.seeds,
                "dateiname": self.dateiname, "laeuft": self.ende is None}

    def abbrechen(self):
        self._halt.set()


class P2pTorrent:
    """Auftraege verwalten (je Auftrag ein eigener Faden); ladet ueber ein extern laufendes aria2c."""

    def __init__(self, datenordner, holen=None, fertig=None):
        self.ordner = os.path.join(datenordner or ".", ORDNER)
        self.holen = holen or antwort_holen
        self.fertig = fertig  # optional: fertig(auftrag) nach erfolgreichem Download
        self.auftraege = {}
        self._nummer = 0
        self._sperre = threading.Lock()

    @staticmethod
    def _werte(daten):
        daten = daten or {}
        adresse = str(daten.get("p2p_aria2_adresse") or STANDARD_ADRESSE).strip() or STANDARD_ADRESSE
        geheim = str(daten.get("p2p_aria2_geheim") or "").strip()
        return adresse, geheim

    def laden(self, daten, link, name="", staffel=None, folge=None):
        if not bool((daten or {}).get("p2p_torrent_an")):
            raise P2pTorrentFehler("P2P-Torrent ist in den Einstellungen ausgeschaltet")
        magnet, _ = magnet_von(link)
        adresse, geheim = self._werte(daten)
        os.makedirs(self.ordner, exist_ok=True)
        with self._sperre:
            if sum(1 for a in self.auftraege.values() if a.ende is None) >= MAX_AUFTRAEGE:
                raise P2pTorrentFehler("Höchstens %d Downloads gleichzeitig" % MAX_AUFTRAEGE)
            self._nummer += 1
            a = Auftrag(self._nummer, str(name or ""), magnet, staffel, folge, self.ordner)
            self.auftraege[a.id] = a
            for alt in sorted((x for x in self.auftraege.values() if x.ende), key=lambda x: x.ende)[:-MAX_VERLAUF]:
                del self.auftraege[alt.id]
        threading.Thread(target=self._lauf, args=(a, adresse, geheim), name="p2p-" + a.id, daemon=True).start()
        return a.als_dict()

    def _lauf(self, a, adresse, geheim):
        gid_meta = None
        try:
            a.status = "metadaten"
            gid_meta = a.gid = _rpc(adresse, geheim, "aria2.addUri",
                                    [[a.magnet], {"dir": self.ordner}], self.holen)
            gid = self._metadaten_abwarten(a, adresse, geheim, gid_meta)
            a.gid = gid

            dateien = _rpc(adresse, geheim, "aria2.getFiles", [gid], self.holen)
            kandidaten = [(str(d.get("index") or i), str(d.get("path") or ""), int(d.get("length") or 0))
                          for i, d in enumerate(dateien, 1)]
            index, pfad, groesse = datei_waehlen(kandidaten, a.staffel, a.folge)
            a.dateiname = os.path.basename(pfad)
            a.datei_pfad = pfad
            if len(dateien) > 1:
                _rpc(adresse, geheim, "aria2.changeOption", [gid, {"select-file": index}], self.holen)

            a.status, a.groesse = "laedt", groesse
            self._fortschritt_abwarten(a, adresse, geheim, gid)
            if a._halt.is_set():
                raise _Abgebrochen()
            a.status, a.tempo = "fertig", 0
            if self.fertig:
                try:
                    self.fertig(a)
                except Exception as fehler:
                    log.warning("P2P-Torrent-Fertig-Meldung fuer %s: %s", a.name, fehler)
        except _Abgebrochen:
            a.status, a.tempo = "abgebrochen", 0
            self._entfernen(adresse, geheim, a.gid or gid_meta)
        except (P2pTorrentFehler, DebridFehler, NetzFehler, OSError) as fehler:
            a.status, a.fehler, a.tempo = "fehler", str(fehler)[:300], 0
        finally:
            a.ende = time.time()

    def _metadaten_abwarten(self, a, adresse, geheim, gid_meta):
        frist = time.time() + METADATEN_FRIST
        while time.time() < frist:
            if a._halt.is_set():
                raise _Abgebrochen()
            status = _rpc(adresse, geheim, "aria2.tellStatus",
                          [gid_meta, ["status", "followedBy", "errorMessage"]], self.holen)
            if status.get("followedBy"):
                return status["followedBy"][0]
            if status.get("status") == "error":
                raise P2pTorrentFehler(status.get("errorMessage") or "Torrent-Metadaten nicht ladbar")
            time.sleep(POLL)
        raise P2pTorrentFehler("Torrent-Metadaten nicht innerhalb von %ds erhalten (keine Peers?)"
                               % int(METADATEN_FRIST))

    def _fortschritt_abwarten(self, a, adresse, geheim, gid):
        while True:
            if a._halt.is_set():
                return
            status = _rpc(adresse, geheim, "aria2.tellStatus", [gid, ["status", "completedLength", "totalLength",
                          "downloadSpeed", "numSeeders", "connections", "errorMessage"]], self.holen)
            a.geladen = int(status.get("completedLength") or 0)
            a.tempo = int(status.get("downloadSpeed") or 0)
            a.seeds = int(status.get("numSeeders") or 0)
            a.peers = int(status.get("connections") or 0)
            if status.get("status") == "error":
                raise P2pTorrentFehler(status.get("errorMessage") or "Download fehlgeschlagen")
            if status.get("status") == "complete":
                return
            time.sleep(POLL)

    def _entfernen(self, adresse, geheim, gid):
        if not gid:
            return
        try:
            _rpc(adresse, geheim, "aria2.forceRemove", [gid], self.holen)
        except P2pTorrentFehler:
            pass

    def abbrechen(self, auftrag_id):
        a = self.auftraege.get(str(auftrag_id))
        if not a:
            raise P2pTorrentFehler("Unbekannter Download")
        a.abbrechen()

    def pfad(self, auftrag_id):
        a = self.auftraege.get(str(auftrag_id))
        if not a or a.status != "fertig" or not a.datei_pfad:
            raise P2pTorrentFehler("Datei noch nicht fertig geladen")
        ziel = os.path.abspath(a.datei_pfad)
        if os.path.commonpath([ziel, os.path.abspath(self.ordner)]) != os.path.abspath(self.ordner):
            raise P2pTorrentFehler("Ungültiger Pfad")
        if not os.path.isfile(ziel):
            raise P2pTorrentFehler("Datei nicht gefunden")
        return ziel

    def zustand(self, daten):
        with self._sperre:
            auftraege = sorted(self.auftraege.values(), key=lambda a: -int(a.id))
        return {"an": bool((daten or {}).get("p2p_torrent_an")), "auftraege": [a.als_dict() for a in auftraege]}


class _Abgebrochen(Exception):
    pass
