"""Party-fun-k-ti0n: Raeume fuer Couch-Play-Karaoke und das Synchron-Spiel (Ab 18), daheim oder uebers Netz.

Ein Raum hat einen kurzen Code. Wer ihn kennt, tritt bei – im offenen Raum sofort, sonst laesst der Gastgeber zu.
Reihum ist jemand dran (eine Runde): beim Karaoke meldet sein Geraet die gemessene Punktzahl (Tontreffsicherheit und
Pegel, gemessen im Browser), beim Synchron-Spiel stimmen die anderen ab (1–5). Gute Runden bringen einen Aufgaben-Joker:
damit stellt man jemandem eine Aufgabe, die er im Videochat erfuellt; der Aufgabensteller bestaetigt, dann gibt es
Bonuspunkte. Alles im Speicher, nach 12 Stunden Ruhe ist ein Raum weg.

Spieler erkennen sich an einer zufaelligen Kennung (sid), die ihr Geraet sich merkt – kein Konto noetig. Die anderen sehen
davon nur eine oeffentliche Kennung (kennung.py), sonst koennte jeder im Namen eines anderen (auch des Gastgebers) handeln.
"""

import random
import re
import secrets
import threading
import time

from . import kennung

MODI = ("karaoke", "synchro")
MAX_RAEUME = 40
MAX_SPIELER = 12
MAX_AUFGABEN = 60
RUHE = 12 * 3600
JOKER_KARAOKE = 70     # ab so vielen Punkten gibt es einen Aufgaben-Joker
JOKER_SYNCHRO = 4.0    # ab dieser Durchschnittsnote
BONUS = 10
_SID = re.compile(r"^[A-Za-z0-9_-]{8,40}$")
_CODE = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789"
# Saetze fuer das Synchron-Spiel: harmlos-witzig, gesprochen wird "symbolisch"
SYNCHRO_TEXTE = [
    "Schatz, hast du den Herd ausgemacht?", "Ich glaube, die Pizza ist da.", "Das Finanzamt hat geschrieben!",
    "Moment, ich muss kurz meine Steuererklärung machen.", "Hast du die Katze gefüttert?",
    "Das WLAN-Passwort steht auf dem Router.", "Ich hätte gern noch einen Kaffee, schwarz.", "Mutti ruft an – geh du ran!",
    "Wo ist eigentlich die Fernbedienung?", "Ich hab vergessen, den Müll rauszubringen.",
    "Achtung, der Paketbote klingelt gleich!", "Dieses Sofa ist wirklich ausgesprochen bequem.",
    "Hörst du das? Die Nachbarn bohren schon wieder.", "Ich sag nur: Bausparvertrag.", "Ist das Bio?",
    "Wir müssen dringend über die Nebenkostenabrechnung reden.", "Ich liebe dich mehr als Fußball. Fast.",
    "Ist hier irgendwo ein Ladekabel?", "Kannst du mal das Fenster aufmachen?", "Das ist kein Bug, das ist ein Feature.",
    "Ich bin H0rSt, und ich hör dich!", "Erst das Update, dann das Vergnügen.", "Hat jemand meine Brille gesehen?",
    "Der Hausmeister kommt um drei.", "Ich glaub, ich hab das Bügeleisen angelassen.",
]
AUFGABEN_IDEEN = [
    "Sing den Refrain deines Lieblingslieds rückwärts.", "Mach 10 Hampelmänner vor der Kamera.",
    "Erzähl einen Witz – ohne zu lachen.", "Imitiere ein Tier, die anderen raten.", "Tanz 20 Sekunden ohne Musik.",
    "Sprich eine Minute lang wie ein Nachrichtensprecher.", "Zeig dein schönstes Grinsen in Zeitlupe.",
    "Mach ein Selfie mit dem merkwürdigsten Gegenstand im Raum.", "Sing ‚Alle meine Entchen‘ als Oper.",
    "Erkläre in 30 Sekunden, warum Socken immer verschwinden.",
]


class PartyFehler(ValueError):
    pass


def _name(roh, standard="Gast"):
    return " ".join(str(roh or "").split())[:24] or standard


class Party:
    def __init__(self, uhr=time.time, zufall=None):
        self.uhr = uhr
        self.zufall = zufall or random.Random()
        self._raeume = {}
        self._sperre = threading.Lock()

    # --- Hilfen -----------------------------------------------------------------------------------
    def _aufraeumen(self):
        jetzt = self.uhr()
        for code in [c for c, r in self._raeume.items() if jetzt - r["zeit"] > RUHE]:
            del self._raeume[code]

    def _raum(self, code):
        r = self._raeume.get(str(code or "").strip().upper())
        if not r:
            raise PartyFehler("Raum nicht gefunden – Code prüfen")
        return r

    @staticmethod
    def _sid(sid):
        if not _SID.match(str(sid or "")):
            raise PartyFehler("Geräte-Kennung fehlt")
        return sid

    def _spieler(self, r, sid):
        s = r["spieler"].get(sid)
        if not s:
            raise PartyFehler("Du bist (noch) nicht in diesem Raum")
        return s

    def ansicht(self, r, sid=""):
        """Was ein Geraet sieht; Wartende sieht nur der Gastgeber; fremde Kennungen nur oeffentlich."""
        gastgeber = sid == r["gastgeber"]
        runde = r["runde"]
        rang = sorted(r["spieler"].items(), key=lambda kv: -kv[1]["punkte"])
        sids = set(r["spieler"]) | set(r["wartend"]) | {r["gastgeber"]} | {x for a in r["aufgaben"] for x in (a["von"], a["an"])}
        if runde:
            sids.add(runde["sid"])
        return kennung.verbergen({"code": r["code"], "name": r["name"], "modus": r["modus"], "offen": r["offen"], "gruppe": r.get("gruppe", ""), "gastgeber": r["spieler"][r["gastgeber"]]["name"]
                if r["gastgeber"] in r["spieler"] else "", "ich": {"sid": kennung.oeffentlich(sid), "gastgeber": gastgeber, "drin": sid in r["spieler"],
                "wartet": sid in r["wartend"], "joker": r["spieler"].get(sid, {}).get("joker", 0)},
                "spieler": [{"sid": k, "name": s["name"], "punkte": round(s["punkte"], 1), "joker": s["joker"], "runden": s["runden"]} for k, s in rang],
                "wartend": [{"sid": k, "name": w["name"]} for k, w in r["wartend"].items()] if gastgeber else [],
                "runde": dict(runde, stimmen=len(runde["stimmen"]), meine_stimme=runde["stimmen"].get(sid)) if runde else None,
                "verlauf": r["verlauf"][-20:], "aufgaben": r["aufgaben"][-20:], "video": r["video"], "stand": r["stand"],
                "aufgaben_ideen": AUFGABEN_IDEEN}, sids)

    def _geaendert(self, r):
        r["zeit"] = self.uhr()
        r["stand"] += 1

    # --- Aktionen ---------------------------------------------------------------------------------
    def lesen(self, code, sid=""):
        with self._sperre:
            r = self._raum(code)
            if sid in r["spieler"]:
                r["spieler"][sid]["zuletzt"] = self.uhr()
            return self.ansicht(r, sid)

    def aktion(self, w):
        if not isinstance(w, dict):
            raise PartyFehler("JSON-Objekt erwartet")
        a = w.get("aktion")
        sid = self._sid(w.get("sid"))
        with self._sperre:
            self._aufraeumen()
            if a == "neu":
                return self._neu(w, sid)
            r = self._raum(w.get("raum"))
            tun = {"beitreten": self._beitreten, "zulassen": self._zulassen, "runde": self._runde, "ergebnis": self._ergebnis,
                   "stimme": self._stimme, "ende": self._ende, "aufgabe": self._aufgabe, "aufgabe_erledigt": self._aufgabe_erledigt,
                   "video": self._video, "offen": self._offen, "verlassen": self._verlassen}.get(a)
            if not tun:
                raise PartyFehler("Unbekannte Aktion")
            tun(r, sid, w)
            self._geaendert(r)
            return self.ansicht(r, sid)

    def _neu(self, w, sid):
        if len(self._raeume) >= MAX_RAEUME:
            raise PartyFehler("Gerade zu viele Party-Räume")
        modus = w.get("modus") if w.get("modus") in MODI else "karaoke"
        code = "".join(self.zufall.choice(_CODE) for _ in range(5))
        while code in self._raeume:
            code = "".join(self.zufall.choice(_CODE) for _ in range(5))
        gruppe = str(w.get("gruppe") or "")[:20]
        if gruppe and w.get("_gruppen") is not None and gruppe not in w["_gruppen"]:
            raise PartyFehler("Eine Party nur für eine Gruppe eröffnet, wer selbst darin ist")
        r = {"code": code, "name": _name(w.get("name"), "Party"), "modus": modus, "offen": w.get("offen") is not False, "gruppe": gruppe,
             "gastgeber": sid, "spieler": {}, "wartend": {}, "runde": None, "verlauf": [], "aufgaben": [], "video": None,
             "zeit": self.uhr(), "stand": 0}
        r["spieler"][sid] = self._neuer_spieler(w.get("spielername"))
        self._raeume[code] = r
        return self.ansicht(r, sid)

    def _neuer_spieler(self, name):
        return {"name": _name(name), "punkte": 0.0, "joker": 0, "runden": 0, "zuletzt": self.uhr()}

    def _beitreten(self, r, sid, w):
        if sid in r["spieler"]:
            r["spieler"][sid]["name"] = _name(w.get("spielername"), r["spieler"][sid]["name"])
            return
        if r.get("gruppe") and w.get("_gruppen") is not None and r["gruppe"] not in w["_gruppen"]:
            raise PartyFehler("Diese Party ist nur für die Gruppe „%s“" % r["gruppe"])
        if len(r["spieler"]) >= MAX_SPIELER:
            raise PartyFehler("Der Raum ist voll")
        if r["offen"]:
            r["spieler"][sid] = self._neuer_spieler(w.get("spielername"))
        else:
            r["wartend"][sid] = {"name": _name(w.get("spielername"))}

    def _nur_gastgeber(self, r, sid):
        if sid != r["gastgeber"]:
            raise PartyFehler("Das darf nur der Gastgeber")

    def _zulassen(self, r, sid, w):
        self._nur_gastgeber(r, sid)
        wen = kennung.finden(w.get("wen"), list(r["wartend"]))
        wer = r["wartend"].pop(wen, None)
        if wer and w.get("ja") is not False:
            r["spieler"][wen] = self._neuer_spieler(wer["name"])

    def _offen(self, r, sid, w):
        self._nur_gastgeber(r, sid)
        r["offen"] = w.get("offen") is not False

    def _runde(self, r, sid, w):
        s = self._spieler(r, sid)
        if r["runde"] and self.uhr() - r["runde"]["beginn"] < 15 * 60:
            raise PartyFehler("%s ist gerade dran" % r["runde"]["name"])
        text = " ".join(str(w.get("text") or "").split())[:200]
        if r["modus"] == "synchro" and not text:
            text = self.zufall.choice(SYNCHRO_TEXTE)
        r["runde"] = {"sid": sid, "name": s["name"], "titel": " ".join(str(w.get("titel") or "").split())[:120], "text": text,
                      "beginn": self.uhr(), "stimmen": {}}

    def _abschliessen(self, r, punkte, note=None):
        runde = r["runde"]
        s = r["spieler"].get(runde["sid"])
        joker = False
        if s:
            s["punkte"] += punkte
            s["runden"] += 1
            joker = punkte >= JOKER_KARAOKE if note is None else note >= JOKER_SYNCHRO
            if joker:
                s["joker"] += 1
        r["verlauf"].append({"name": runde["name"], "titel": runde["titel"], "text": runde["text"], "punkte": round(punkte, 1),
                             "note": note, "joker": joker, "zeit": int(self.uhr())})
        r["runde"] = None

    def _ergebnis(self, r, sid, w):
        runde = r["runde"]
        if r["modus"] != "karaoke" or not runde or runde["sid"] != sid:
            raise PartyFehler("Keine eigene Karaoke-Runde offen")
        try:
            punkte = max(0.0, min(100.0, float(w.get("punkte"))))
        except (TypeError, ValueError):
            raise PartyFehler("Punkte 0–100")
        self._abschliessen(r, punkte)

    def _stimme(self, r, sid, w):
        runde = r["runde"]
        self._spieler(r, sid)
        if r["modus"] != "synchro" or not runde:
            raise PartyFehler("Gerade gibt es nichts zu bewerten")
        if runde["sid"] == sid:
            raise PartyFehler("Sich selbst bewerten gilt nicht")
        try:
            wert = int(w.get("wert"))
        except (TypeError, ValueError):
            raise PartyFehler("Note 1–5")
        if not 1 <= wert <= 5:
            raise PartyFehler("Note 1–5")
        runde["stimmen"][sid] = wert
        if len(runde["stimmen"]) >= len(r["spieler"]) - 1:  # alle anderen haben abgestimmt
            self._synchro_ende(r)

    def _synchro_ende(self, r):
        stimmen = list(r["runde"]["stimmen"].values())
        note = sum(stimmen) / len(stimmen) if stimmen else 0.0
        self._abschliessen(r, note * 20, round(note, 2))

    def _ende(self, r, sid, w):
        runde = r["runde"]
        if not runde:
            return
        if sid not in (runde["sid"], r["gastgeber"]):
            raise PartyFehler("Beenden darf, wer dran ist, oder der Gastgeber")
        if r["modus"] == "synchro" and runde["stimmen"]:
            self._synchro_ende(r)
        else:
            r["verlauf"].append({"name": runde["name"], "titel": runde["titel"], "text": runde["text"], "punkte": 0,
                                 "note": None, "joker": False, "zeit": int(self.uhr()), "abgebrochen": True})
            r["runde"] = None

    def _aufgabe(self, r, sid, w):
        s = self._spieler(r, sid)
        an = kennung.finden(w.get("an"), list(r["spieler"]))
        if not an or an == sid:
            raise PartyFehler("Wem soll die Aufgabe gelten?")
        if s["joker"] < 1:
            raise PartyFehler("Aufgaben stellt, wer einen Joker hat – den gibt es für eine starke Runde")
        text = " ".join(str(w.get("text") or "").split())[:200]
        if not text:
            raise PartyFehler("Aufgabe fehlt")
        if len(r["aufgaben"]) >= MAX_AUFGABEN:
            r["aufgaben"] = r["aufgaben"][-MAX_AUFGABEN // 2:]
        s["joker"] -= 1
        r["aufgaben"].append({"id": secrets.token_hex(4), "von": sid, "von_name": s["name"], "an": an,
                              "an_name": r["spieler"][an]["name"], "text": text, "status": "offen"})

    def _aufgabe_erledigt(self, r, sid, w):
        a = next((x for x in r["aufgaben"] if x["id"] == w.get("aufgabe")), None)
        if not a or a["status"] != "offen":
            raise PartyFehler("Aufgabe nicht (mehr) offen")
        if sid != a["von"]:
            raise PartyFehler("Bestätigen darf, wer die Aufgabe gestellt hat")
        a["status"] = "erledigt" if w.get("ok") is not False else "nicht geschafft"
        if a["status"] == "erledigt" and a["an"] in r["spieler"]:
            r["spieler"][a["an"]]["punkte"] += BONUS

    def _video(self, r, sid, w):
        """Was gerade laeuft (Song/Video), damit alle Geraete dasselbe sehen koennen."""
        self._spieler(r, sid)
        v = w.get("video") if isinstance(w.get("video"), dict) else None
        r["video"] = {"id": str(v.get("id") or "")[:40], "titel": str(v.get("titel") or "")[:160], "von": r["spieler"][sid]["name"]} if v else None

    def _verlassen(self, r, sid, w):
        r["wartend"].pop(sid, None)
        r["spieler"].pop(sid, None)
        if r["runde"] and r["runde"]["sid"] == sid:
            r["runde"] = None
        if sid == r["gastgeber"] and r["spieler"]:
            r["gastgeber"] = next(iter(r["spieler"]))
        if not r["spieler"]:
            self._raeume.pop(r["code"], None)
