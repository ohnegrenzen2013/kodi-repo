"""Passwort-Tresor: pass-kompatible Eintraege, OpenPGP, Git und TOTP.

Die Funktionen sind bewusst schlank und ohne neue Abhaengigkeit: GnuPG und Git werden
als Programme aufgerufen, die Eintraege bleiben im Standardformat von ``pass``. Damit
kann derselbe Tresor in Password Store (Android), auf dem PC und in H0rSt liegen.
Passkeys aus Password Store werden erkannt und geschuetzt, aber nicht vorgetaeuscht:
WebAuthn braucht den Android-Credential-Manager, den nur die App liefert.
"""

import os

from . import pass_tresor_eintrag as eintrag
from .pass_tresor_grund import (SCHLUESSEL, TresorFehler, datei_pfad, einstellungen, empfaenger,
                                 entschluesseln, gpg_verfuegbar, git_commit, git_ist_repo, git_lauf,
                                 git_pull, git_push, pfad, pruefe, sicherer_name,
                                 verschluesseln)

__all__ = ["SCHLUESSEL", "TresorFehler", "einstellungen", "pruefe", "zustand", "liste", "lesen",
           "schreiben", "loeschen", "umbenennen", "ordner_anlegen", "generieren", "otp", "git",
           "passkeys", "verknuepfung", "vorschau"]


def _wurzel(daten, datenordner):
    return pfad(daten, datenordner)


def _zahlen(wurzel, cfg):
    anzahl = passkeys_anzahl = 0
    try:
        for ordner, unter, dateien in os.walk(wurzel):
            unter[:] = [u for u in unter if u != ".git"]
            for name in dateien:
                if not name.endswith(".gpg"):
                    continue
                if os.path.basename(ordner) == "fido2" or "/fido2/" in (ordner + "/"):
                    passkeys_anzahl += 1
                else:
                    anzahl += 1
    except OSError:
        pass
    return anzahl, passkeys_anzahl


def zustand(daten, datenordner):
    cfg = einstellungen(daten)
    try:
        wurzel = _wurzel(daten, datenordner)
        fehler = ""
    except TresorFehler as problem:
        wurzel, fehler = "", str(problem)
    vorhanden = bool(wurzel and os.path.isdir(wurzel))
    anzahl = passkeys = 0
    if vorhanden:
        anzahl, passkeys = _zahlen(wurzel, cfg)
    return {"einstellungen": cfg, "pfad": wurzel, "vorhanden": vorhanden, "gpg": gpg_verfuegbar(cfg),
            "git": bool(vorhanden and git_ist_repo(wurzel)), "eintraege": anzahl, "passkeys": passkeys,
            "fehler": fehler, "quelle": "intern" if cfg["ort"] == "intern" else "extern"}


def _sichtbar(name, cfg):
    if name.startswith(".") and not cfg.get("ausblenden"):
        return False
    return True


def _treffer(name, pfad_rel, suche, modus, cfg, rekursiv=True):
    if not suche:
        return True
    text = (name + " " + pfad_rel).lower()
    if modus == "fuzzy":
        pos = 0
        for zeichen in suche.lower():
            pos = text.find(zeichen, pos)
            if pos < 0:
                return False
            pos += 1
        return True
    return suche.lower() in text


def liste(daten, datenordner, suche="", ordner="", sortierung=None):
    """Alle sichtbaren Eintraege (ohne Entschluesseln). Der Tresor kann dabei fehlen."""
    cfg = einstellungen(daten)
    wurzel = _wurzel(daten, datenordner)
    if not os.path.isdir(wurzel):
        return {"pfad": wurzel, "ordner": ordner, "eintraege": [], "ordnerliste": [], "gesucht": suche}
    sortierung = sortierung or cfg["sortierung"]
    suche = " ".join(str(suche or "").split())[:100]
    modus = cfg["suche_modus"]
    basis = os.path.realpath(os.path.join(wurzel, str(ordner or "").strip("/")))
    if os.path.commonpath([os.path.realpath(wurzel), basis]) != os.path.realpath(wurzel):
        basis = os.path.realpath(wurzel)
    eintraege, unterordner = [], set()
    for lauf_ordner, unter, dateien in os.walk(basis):
        unter[:] = [u for u in unter if u != ".git" and _sichtbar(u, cfg)]
        if not cfg.get("rekursiv") and os.path.abspath(lauf_ordner) != os.path.abspath(basis):
            unter[:] = []
        for name in dateien:
            if not name.endswith(".gpg") or name == ".gpg-id":
                continue
            voll = os.path.join(lauf_ordner, name)
            rel = os.path.relpath(voll, wurzel).replace(os.sep, "/")
            if rel.startswith("fido2/"):
                continue
            ohne = rel[:-4]
            ordner_rel = os.path.dirname(ohne)
            if ordner_rel and ordner_rel != ordner.strip("/"):
                unterordner.add(ordner_rel)
            if not _treffer(ohne.rsplit("/", 1)[-1], ohne, suche, modus, cfg, cfg.get("rekursiv")):
                continue
            try:
                stat = os.stat(voll)
                geaendert, groesse = int(stat.st_mtime), stat.st_size
            except OSError:
                geaendert, groesse = 0, 0
            eintraege.append({"id": rel, "name": ohne.rsplit("/", 1)[-1], "pfad": ohne,
                              "ordner": ordner_rel, "geaendert": geaendert, "groesse": groesse})
    if sortierung == "zuletzt":
        eintraege.sort(key=lambda x: (-x["geaendert"], x["pfad"].casefold()))
    elif sortierung == "datei":
        eintraege.sort(key=lambda x: (x["name"].casefold(), x["pfad"].casefold()))
    elif sortierung == "unabhaengig":
        eintraege.sort(key=lambda x: (x["name"].casefold(), x["pfad"].casefold()))
    else:
        eintraege.sort(key=lambda x: (0 if x["ordner"] else 1, x["ordner"].casefold(), x["name"].casefold()))
    return {"pfad": wurzel, "ordner": ordner, "eintraege": eintraege[:5000],
            "ordnerliste": sorted(unterordner, key=str.casefold)[:1000], "gesucht": suche}


def lesen(daten, datenordner, eintrag_id, passphrase=""):
    cfg = einstellungen(daten)
    wurzel = _wurzel(daten, datenordner)
    voll, rel = datei_pfad(wurzel, eintrag_id)
    if not os.path.isfile(voll):
        raise TresorFehler("Eintrag nicht gefunden")
    roh = entschluesseln(voll, passphrase, cfg)
    try:
        text = roh.decode("utf-8")
    except UnicodeDecodeError:
        raise TresorFehler("Eintrag ist kein Text (Passkey-Datei?)")
    daten_eintrag = eintrag.lesen(text)
    daten_eintrag.update({"id": rel, "pfad": rel[:-4], "name": rel[:-4].rsplit("/", 1)[-1],
                          "ordner": os.path.dirname(rel[:-4])})
    daten_eintrag["otp_code"] = eintrag.otp_code(daten_eintrag.get("otp", ""))
    if not cfg.get("zusatz_zeigen"):
        daten_eintrag["zusatz"] = ""
    return daten_eintrag


def _neu_pfad(wurzel, ordner, name, vorhandene_id=""):
    if vorhandene_id:
        voll, rel = datei_pfad(wurzel, vorhandene_id)
        return voll, rel
    ordner = str(ordner or "").strip().strip("/")
    name = sicherer_name(name).lower().replace(" ", "-")
    rel = (ordner + "/" if ordner else "") + name
    return datei_pfad(wurzel, rel)


def schreiben(daten, datenordner, werte, passphrase="", ueberschreiben=False):
    """Neuen Eintrag anlegen oder vorhandenen ersetzen; immer OpenPGP-verschluesselt."""
    cfg = einstellungen(daten)
    wurzel = _wurzel(daten, datenordner)
    os.makedirs(wurzel, exist_ok=True)
    voll, rel = _neu_pfad(wurzel, werte.get("ordner"), werte.get("name") or werte.get("pfad"),
                          str(werte.get("id") or ""))
    if os.path.exists(voll) and not (ueberschreiben or werte.get("id")):
        raise TresorFehler("Diesen Eintrag gibt es schon")
    ziele = empfaenger(wurzel, rel, cfg)
    inhalt = eintrag.bauen(werte)
    geheim = verschluesseln(inhalt.encode("utf-8"), ziele, cfg)
    os.makedirs(os.path.dirname(voll), exist_ok=True)
    tmp = voll + ".tmp"
    with open(tmp, "wb") as f:
        f.write(geheim)
    os.replace(tmp, voll)
    try:
        git_commit(wurzel, cfg, "H0rSt: %s %s" % ("ändern" if werte.get("id") else "anlegen", rel[:-4]))
    except TresorFehler:
        pass  # der Eintrag ist gespeichert; ein Git-Fehler darf ihn nicht verschlucken
    return {"id": rel, "pfad": rel[:-4], "empfaenger": ziele, "geschrieben": True}


def loeschen(daten, datenordner, eintrag_id):
    cfg = einstellungen(daten)
    wurzel = _wurzel(daten, datenordner)
    voll, rel = datei_pfad(wurzel, eintrag_id)
    if not os.path.isfile(voll):
        raise TresorFehler("Eintrag nicht gefunden")
    os.remove(voll)
    git_commit(wurzel, cfg, "H0rSt: löschen " + rel[:-4])
    return {"geloescht": True, "id": rel}


def umbenennen(daten, datenordner, eintrag_id, neuer_name, neuer_ordner=""):
    cfg = einstellungen(daten)
    wurzel = _wurzel(daten, datenordner)
    alt, rel = datei_pfad(wurzel, eintrag_id)
    if not os.path.isfile(alt):
        raise TresorFehler("Eintrag nicht gefunden")
    ordner = str(neuer_ordner if neuer_ordner is not None else os.path.dirname(rel[:-4])).strip("/")
    ziel_rel = (ordner + "/" if ordner else "") + sicherer_name(neuer_name)
    ziel, ziel_rel = datei_pfad(wurzel, ziel_rel)
    if os.path.exists(ziel) and os.path.abspath(ziel) != os.path.abspath(alt):
        raise TresorFehler("Ziel existiert schon")
    os.makedirs(os.path.dirname(ziel), exist_ok=True)
    os.replace(alt, ziel)
    git_commit(wurzel, cfg, "H0rSt: umbenennen " + rel[:-4])
    return {"id": ziel_rel, "pfad": ziel_rel[:-4]}


def ordner_anlegen(daten, datenordner, ordner):
    wurzel = _wurzel(daten, datenordner)
    ordner = str(ordner or "").strip("/")
    ziel = os.path.abspath(os.path.join(wurzel, ordner))
    if not ziel.startswith(os.path.abspath(wurzel)):
        raise TresorFehler("Ordner liegt ausserhalb des Tresors")
    os.makedirs(ziel, exist_ok=True)
    return {"ordner": ordner}


def generieren(daten, wunsch):
    cfg = einstellungen(daten)
    return {"passwort": eintrag.passwort(
        laenge=wunsch.get("laenge", 16), art=wunsch.get("art", "klassisch"),
        gross=wunsch.get("gross", True), klein=wunsch.get("klein", True),
        zahlen=wunsch.get("zahlen", True), symbole=wunsch.get("symbole", False),
        eindeutig=wunsch.get("eindeutig", True), wortliste=wunsch.get("wortliste") or cfg.get("wortliste"),
        woerter=wunsch.get("woerter", 6), trenner=str(wunsch.get("trenner") or "-")[:1],
        zahl_an=wunsch.get("zahl_an", True), gross_start=wunsch.get("gross_start", True))}


def otp(daten, datenordner, eintrag_id, passphrase=""):
    gelesen = lesen(daten, datenordner, eintrag_id, passphrase)
    return {"otp": gelesen.get("otp_code")}


def passkeys(daten, datenordner):
    """Nur zaehlen und anzeigen: Passkey-Dateien werden nie als Passwort entschluesselt."""
    cfg = einstellungen(daten)
    wurzel = _wurzel(daten, datenordner)
    basis = os.path.join(wurzel, "fido2")
    if not cfg.get("passkeys_anzeigen") or not os.path.isdir(basis):
        return []
    liste_ = []
    for ordner, unter, dateien in os.walk(basis):
        unter[:] = [u for u in unter if not u.startswith(".")]
        for name in dateien:
            if name.endswith(".gpg") and not name.startswith("."):
                rel = os.path.relpath(os.path.join(ordner, name), wurzel).replace(os.sep, "/")
                liste_.append({"pfad": rel, "name": name[:-4]})
    return sorted(liste_, key=lambda x: x["pfad"].casefold())[:200]


def git(daten, datenordner, aktion="status"):
    cfg = einstellungen(daten)
    wurzel = _wurzel(daten, datenordner)
    if not git_ist_repo(wurzel):
        raise TresorFehler("Der Tresor ist kein Git-Repository")
    if aktion == "pull":
        return {"meldung": git_pull(wurzel, cfg).strip() or "Aktualisiert."}
    if aktion == "push":
        return {"meldung": git_push(wurzel, cfg).strip() or "Hochgeladen."}
    if aktion == "log":
        text = git_lauf(wurzel, ["log", "-n", "20", "--pretty=%h|%ad|%s", "--date=short"], cfg)
        return {"log": [z for z in text.splitlines() if z.strip()]}
    text = git_lauf(wurzel, ["status", "--porcelain=v1", "--branch"], cfg)
    return {"status": [z for z in text.splitlines() if z.strip()]}


def verknuepfung():
    """Angaben fuer die optionale Verknuepfung mit der Android-App."""
    return {"paket": "app.passwordstore.pando85", "name": "Password Store (Passkey Edition)",
            "seite": "https://f-droid.org/packages/app.passwordstore.pando85/",
            "doku": "https://docs.passwordstore.app", "passkeys": True}


def vorschau(daten, datenordner, eintrag_id, passphrase=""):
    """Fuer die Stammbaum-/Menue-Vorschau: nur Felder, keine Geheimnisse."""
    gelesen = lesen(daten, datenordner, eintrag_id, passphrase)
    return {"id": gelesen.get("id"), "name": gelesen.get("name"), "ordner": gelesen.get("ordner"),
            "benutzer": gelesen.get("benutzer"), "url": gelesen.get("url"),
            "hat_otp": bool(gelesen.get("otp")), "felder": sorted((gelesen.get("felder") or {}).keys())}
