"""pass-Eintraege lesen/schreiben, TOTP berechnen und Passwoerter erzeugen.

Ein pass-Eintrag ist Text: erste Zeile das Passwort, danach Felder wie
``username:``, ``url:`` oder ``otp:``. Alles nach einer Leerzeile ist freier Zusatz.
Die Regeln folgen Password Store (GPL-3.0), sind hier aber eigenstaendig umgesetzt.
"""

import base64
import hashlib
import hmac
import secrets
import string
import struct
import time
from urllib.parse import parse_qs, unquote, urlsplit

PASSWORT_FELDER = ("password:", "secret:", "pass:")
BENUTZER_FELDER = ("login:", "username:", "user:", "account:", "email:", "mail:", "name:", "handle:", "id:", "identity:")
TOTP_FELDER = ("otpauth://totp", "totp:", "otp:")
UNSAFE = "unsafe-keys:"
AMBIGUOUS = "B8G6I1l0OQDS5Z2"
BUCHSTABEN = string.ascii_lowercase + string.ascii_uppercase
ZIFFERN = string.digits
SYMBOLE = "!\"#$%&'()*+,-./:;<=>?@[\\]^_`{|}~"
STEAM = "23456789BCDFGHJKMNPQRTVWXY"


class EintragFehler(ValueError):
    pass


def _feldzeile(zeile):
    if ":" not in zeile:
        return None, None
    key, wert = zeile.split(":", 1)
    if not key or key != key.strip() or key.startswith(" "):
        return None, None
    return key.strip(), wert.strip()


def lesen(inhalt):
    """pass-Text -> {passwort, benutzer, url, otp, felder, zusatz, unsicher}."""
    text = str(inhalt or "").replace("\r\n", "\n")
    zeilen = text.split("\n")
    passwort = None
    erste = zeilen[0] if zeilen else ""
    if erste.strip() and not any(erste.lower().startswith(p) for p in PASSWORT_FELDER + BENUTZER_FELDER + TOTP_FELDER):
        passwort = erste.strip()
        zeilen = zeilen[1:]
    elif erste.strip() == "":
        zeilen = zeilen[1:]
    benutzer = url = otp = ""
    unsicher = set()
    felder = {}
    zusatz = []
    zusatz_an = False
    for zeile in zeilen:
        if not zeile.strip():
            zusatz_an = True
            continue
        if not zusatz_an:
            low = zeile.lower()
            if passwort is None and any(low.startswith(p) for p in PASSWORT_FELDER):
                passwort = zeile.split(":", 1)[1].strip()
                continue
            if not benutzer and any(low.startswith(p) for p in BENUTZER_FELDER):
                benutzer = zeile.split(":", 1)[1].strip()
                continue
            if any(low.startswith(p) for p in TOTP_FELDER) or low.startswith("otpauth://"):
                wert = zeile.split(":", 1)[1].strip() if low.startswith("otp:") else zeile.strip()
                if wert and not wert.lower().startswith(("otpauth://", "totp:")):
                    wert = "totp:" + wert
                otp = wert
                continue
            if low.startswith(UNSAFE):
                unsicher.update(x.strip().lower() for x in zeile.split(":", 1)[1].split(",") if x.strip())
                continue
            key, wert = _feldzeile(zeile)
            if key and not key.startswith(" "):
                if key.lower() in ("url", "website", "site"):
                    url = wert
                felder[key] = (felder[key] + "\n" + wert) if key in felder else wert
                continue
        zusatz.append(zeile)
    return {"passwort": passwort or "", "benutzer": benutzer, "url": url, "otp": otp,
            "felder": felder, "zusatz": "\n".join(zusatz).rstrip(), "unsicher": sorted(unsicher)}


def bauen(daten):
    """Felder -> pass-Text. Leere Felder werden weggelassen; Doppelpunkte bleiben erhalten."""
    daten = daten or {}
    zeilen = [str(daten.get("passwort") or "").replace("\r", " ").replace("\n", " ")]
    benutzer = str(daten.get("benutzer") or "").strip()
    if benutzer:
        zeilen.append("username: " + benutzer.replace("\n", " "))
    url = str(daten.get("url") or "").strip()
    if url:
        zeilen.append("url: " + url.replace("\n", " "))
    otp = str(daten.get("otp") or "").strip()
    if otp:
        zeilen.append(otp.replace("\n", " "))
    felder = daten.get("felder") or {}
    if isinstance(felder, dict):
        for key, wert in felder.items():
            key = str(key or "").strip()
            if not key or key.lower() in ("url", "website", "site", "username", "user", "login", "password", "secret", "pass"):
                continue
            for teil in str(wert or "").split("\n"):
                if teil.strip():
                    zeilen.append("%s: %s" % (key, teil.strip()))
    zusatz = str(daten.get("zusatz") or "").strip("\n")
    if zusatz:
        zeilen.extend(["", zusatz])
    return "\n".join(zeilen).rstrip() + "\n"


def _b32(secret):
    roh = "".join(str(secret or "").split()).upper()
    roh += "=" * ((8 - len(roh) % 8) % 8)
    try:
        return base64.b32decode(roh, casefold=True)
    except (ValueError, TypeError) as fehler:
        raise EintragFehler("TOTP-Geheimnis ist kein gueltiges Base32: %s" % fehler)


def otp_teile(uri):
    """otpauth://totp/... oder totp:GEHEIMNIS -> Angaben fuer die Code-Berechnung."""
    text = str(uri or "").strip()
    if not text:
        return None
    if text.lower().startswith("totp:"):
        return {"secret": text.split(":", 1)[1].strip(), "digits": 6, "period": 30,
                "algorithm": "SHA1", "issuer": "", "account": ""}
    teile = urlsplit(text)
    if teile.scheme.lower() != "otpauth" or teile.netloc.lower() != "totp":
        return None
    q = parse_qs(teile.query)
    secret = (q.get("secret") or [""])[0].strip()
    if not secret:
        return None
    roh_digits = (q.get("digits") or ["6"])[0]
    try:
        digits = "s" if str(roh_digits).lower() == "s" else max(6, min(10, int(roh_digits)))
        period = max(10, min(120, int((q.get("period") or ["30"])[0])))
    except ValueError:
        digits, period = 6, 30
    algorithm = ((q.get("algorithm") or ["SHA1"])[0] or "SHA1").upper()
    if algorithm not in ("SHA1", "SHA256", "SHA512", "MD5"):
        algorithm = "SHA1"
    label = unquote(teile.path.lstrip("/"))
    issuer = (q.get("issuer") or [label.split(":", 1)[0] if ":" in label else ""])[0]
    account = label.split(":", 1)[1] if ":" in label else label
    return {"secret": secret, "digits": digits, "period": period,
            "algorithm": algorithm, "issuer": issuer, "account": account}


def otp_code(uri, jetzt=None):
    """Aktueller TOTP-Code samt Restzeit; None, wenn kein gueltiges OTP vorliegt."""
    angaben = otp_teile(uri)
    if not angaben:
        return None
    try:
        schluessel = _b32(angaben["secret"])
    except EintragFehler:
        return None
    jetzt = time.time() if jetzt is None else float(jetzt)
    zaehler = int(jetzt // angaben["period"])
    nachricht = struct.pack(">Q", zaehler)
    verfahren = {"SHA1": hashlib.sha1, "SHA256": hashlib.sha256, "SHA512": hashlib.sha512,
                 "MD5": hashlib.md5}[angaben["algorithm"]]
    digest = hmac.new(schluessel, nachricht, verfahren).digest()
    stelle = digest[-1] & 0x0F
    zahl = struct.unpack(">I", digest[stelle:stelle + 4])[0] & 0x7FFFFFFF
    if angaben.get("digits") == "s" or angaben.get("issuer", "").lower() == "steam":
        rest, code = zahl, ""
        for _ in range(5):
            code += STEAM[rest % len(STEAM)]
            rest //= len(STEAM)
        return {"code": code, "rest": angaben["period"] - jetzt % angaben["period"],
                "period": angaben["period"], "art": "steam", "issuer": angaben["issuer"]}
    code = str(zahl).zfill(10)[-angaben["digits"]:]
    return {"code": code, "rest": int(angaben["period"] - jetzt % angaben["period"]),
            "period": angaben["period"], "art": "totp", "issuer": angaben["issuer"],
            "account": angaben.get("account", "")}


def passwort(laenge=16, art="klassisch", gross=True, klein=True, zahlen=True, symbole=False,
             eindeutig=True, wortliste=None, woerter=6, trenner="-", zahl_an=True, gross_start=True):
    """Klassisches Passwort oder Diceware-Passphrase. Immer mit secrets (kryptografisch sicher)."""
    laenge = max(6, min(256, int(laenge or 16)))
    woerter = max(3, min(12, int(woerter or 6)))
    if art == "diceware":
        liste = []
        if wortliste:
            try:
                with open(wortliste, encoding="utf-8", errors="replace") as f:
                    liste = [z.strip() for z in f if z.strip() and not z.startswith("#")]
            except OSError:
                liste = []
        if len(liste) < 64:
            raise EintragFehler("Diceware braucht eine Wortliste (Pfad in den Tresor-Einstellungen, mind. 64 Woerter)")
        gewaehlt = [secrets.choice(liste) for _ in range(woerter)]
        if gross_start:
            gewaehlt = [w[:1].upper() + w[1:] for w in gewaehlt]
        text = trenner.join(gewaehlt)
        if zahl_an:
            stelle = secrets.randbelow(len(gewaehlt))
            teile = text.split(trenner)
            teile[stelle] += str(secrets.randbelow(10))
            text = trenner.join(teile)
        return text
    gruppen = []
    if klein:
        gruppen.append(string.ascii_lowercase)
    if gross:
        gruppen.append(string.ascii_uppercase)
    if zahlen:
        gruppen.append(string.digits)
    if symbole:
        gruppen.append(SYMBOLE)
    if not gruppen:
        raise EintragFehler("Mindestens eine Zeichenart waehlen")
    erlaubt = "".join(gruppen)
    if eindeutig:
        erlaubt = "".join(z for z in erlaubt if z not in AMBIGUOUS)
    if len(erlaubt) < 2:
        raise EintragFehler("Zu wenige Zeichen nach dem Entfernen mehrdeutiger Zeichen")
    if laenge < len(gruppen):
        raise EintragFehler("Laenge ist fuer die gewaehlten Zeichenarten zu kurz")
    while True:
        code = [secrets.choice(erlaubt) for _ in range(laenge)]
        if all(any(z in g for z in code) for g in gruppen):
            secrets.SystemRandom().shuffle(code)
            return "".join(code)
