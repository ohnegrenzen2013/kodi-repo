"""Passwort-Tresor: Grundlagen, Konfiguration und sichere Pfade.

Vorbild ist der freie Passwort-Manager Password Store (pando85/Android-Password-Store,
GPL-3.0): ein Verzeichnis mit pass-kompatiblen, mit OpenPGP verschluesselten Eintraegen,
optional als Git-Repository. H0rSt baut die Funktionen in eigenem Code nach und nutzt
zum Ver- und Entschluesseln das auf dem System vorhandene GnuPG. Ohne gpg bleibt der
Tresor sichtbar, aber gesperrt; Geheimnisse werden nie im Klartext gespeichert.
"""

import os
import re
import shutil
import subprocess

SCHLUESSEL = "pass_tresor"
INTERN = "passwort-tresor"
MAX_TEXT = 400
MAX_EINTRAEGE = 5000
STANDARD = {
    "ort": "intern",              # intern = im H0rSt-Datenordner, extern = vorhandener pass-Store
    "pfad": "",                   # nur bei ort = extern
    "darstellung": "tab",         # tab | verknuepfung | seitenmenue
    "sortierung": "ordner",       # ordner | datei | unabhaengig | zuletzt
    "verzeichnisstruktur": "encrypted_username",  # encrypted_username | file | directory
    "ausblenden": False,          # versteckte Eintraege (Punktdateien) anzeigen
    "suche_start": False,
    "suche_modus": "exakt",       # exakt | fuzzy
    "rekursiv": True,
    "kopieren": False,
    "passwort_zeigen": False,
    "zwischenablage_sek": 45,
    "zwischenablage_leeren": False,
    "zusatz_zeigen": True,
    "ascii": False,
    "gpg": "",
    "gpg_home": "",
    "schluessel": "",
    "wortliste": "",
    "git_an": False,
    "git_auto_pull": False,
    "git_auto_push": False,
    "git_rebase": True,
    "git_name": "H0rSt",
    "git_email": "h0rst@localhost",
    "passkeys_anzeigen": True,
}
WAHL = {
    "ort": ("intern", "extern"),
    "darstellung": ("tab", "verknuepfung", "seitenmenue"),
    "sortierung": ("ordner", "datei", "unabhaengig", "zuletzt"),
    "verzeichnisstruktur": ("encrypted_username", "file", "directory"),
    "suche_modus": ("exakt", "fuzzy"),
}
ZAHLEN = {"zwischenablage_sek": (5, 600)}
SCHALTER = {k for k, w in STANDARD.items() if isinstance(w, bool)}
TEXTE = {k for k, w in STANDARD.items() if isinstance(w, str)} - set(WAHL)
_VERBOTEN = re.compile(r"(^|/)\.\.(/|$)|[\x00\r\n]")


class TresorFehler(ValueError):
    pass


def pruefe(roh):
    """Gespeicherte Werte einlesen: unbekannte und kaputte Angaben fallen auf den Standard zurueck."""
    e = dict(STANDARD)
    if not isinstance(roh, dict):
        return e
    for k, w in roh.items():
        if k not in STANDARD:
            continue
        if k in SCHALTER:
            if isinstance(w, bool):
                e[k] = w
        elif k in WAHL:
            if str(w) in WAHL[k]:
                e[k] = str(w)
        elif k in ZAHLEN:
            try:
                n = int(w)
            except (TypeError, ValueError):
                continue
            unten, oben = ZAHLEN[k]
            if unten <= n <= oben:
                e[k] = n
        elif k in TEXTE:
            e[k] = " ".join(str(w or "").split())[:MAX_TEXT]
    return e


def einstellungen(daten):
    return pruefe((daten or {}).get(SCHLUESSEL))


def pfad(daten, datenordner):
    """Wurzel des Tresors. Intern liegt er im H0rSt-Datenordner, extern muss der Pfad absolut sein."""
    e = einstellungen(daten)
    if e["ort"] == "intern":
        return os.path.join(os.path.abspath(datenordner or "."), INTERN)
    p = os.path.expanduser(e["pfad"].strip())
    if not p:
        raise TresorFehler("Externer Tresor: bitte den Pfad angeben")
    if not os.path.isabs(p):
        raise TresorFehler("Externer Tresor: Pfad muss absolut sein")
    return os.path.abspath(p)


def gpg_pfad(cfg=None):
    cfg = cfg or STANDARD
    roh = str((cfg or {}).get("gpg") or "").strip()
    if roh:
        return roh if os.path.isfile(roh) and os.access(roh, os.X_OK) else ""
    return shutil.which("gpg") or shutil.which("gpg2") or ""


def gpg_verfuegbar(cfg=None):
    return bool(gpg_pfad(cfg))


def _umgebung(cfg):
    env = dict(os.environ)
    env.setdefault("LC_ALL", "C")
    haus = str((cfg or {}).get("gpg_home") or "").strip()
    if haus:
        env["GNUPGHOME"] = os.path.expanduser(haus)
    env["GIT_TERMINAL_PROMPT"] = "0"
    return env


def _fehlertext(roh):
    text = " ".join((roh or b"").decode("utf-8", "replace").split())
    return text[:500] or "unbekannter Fehler"


def gpg(args, eingabe=None, cfg=None, timeout=45):
    """GnuPG aufrufen. Passphrasen gehen ausschliesslich ueber stdin, nie ueber die Kommandozeile."""
    prog = gpg_pfad(cfg)
    if not prog:
        raise TresorFehler("GnuPG fehlt (gpg installieren oder den Pfad in den Tresor-Einstellungen setzen)")
    try:
        lauf = subprocess.run([prog] + list(args), input=eingabe, stdout=subprocess.PIPE,
                              stderr=subprocess.PIPE, timeout=timeout, env=_umgebung(cfg))
    except (OSError, subprocess.TimeoutExpired) as fehler:
        raise TresorFehler("GnuPG: %s" % fehler)
    if lauf.returncode:
        raise TresorFehler("GnuPG: %s" % _fehlertext(lauf.stderr))
    return lauf.stdout


def entschluesseln(datei, passphrase="", cfg=None):
    args = ["--batch", "--yes", "--no-tty", "--pinentry-mode", "loopback", "--passphrase-fd", "0",
            "--decrypt", datei]
    return gpg(args, (str(passphrase or "") + "\n").encode("utf-8"), cfg)


def verschluesseln(inhalt, empfaenger, cfg=None):
    if not empfaenger:
        raise TresorFehler("Kein Empfaenger: eine .gpg-id im Tresor anlegen oder einen Schluessel eintragen")
    args = ["--batch", "--yes", "--no-tty", "--trust-model", "always"]
    if (cfg or {}).get("ascii"):
        args.append("--armor")
    for kennung in empfaenger:
        args.extend(["--recipient", kennung])
    args.extend(["--encrypt", "--output", "-"])
    return gpg(args, inhalt, cfg)


def sicherer_name(text):
    """Name fuer einen Eintrag/Ordner: keine Pfadtrenner, keine Steuerzeichen, nicht leer."""
    name = " ".join(str(text or "").replace("\\", "/").split())
    name = name.replace("/", "-").strip(" .")
    name = re.sub(r"[\x00-\x1f<>:\"|?*]", "", name)
    return name[:80] or "eintrag"


def relativ_sicher(rel):
    """Relativer Eintragspfad ohne Ausbruch aus dem Tresor; ohne .gpg wird die Endung ergaenzt."""
    rel = str(rel or "").strip().replace("\\", "/")
    if not rel or rel.startswith("/") or _VERBOTEN.search(rel):
        raise TresorFehler("Ungueltiger Eintrag")
    while rel.startswith("./"):
        rel = rel[2:]
    if not rel or rel.startswith("/") or _VERBOTEN.search(rel):
        raise TresorFehler("Ungueltiger Eintrag")
    if not rel.lower().endswith(".gpg"):
        rel += ".gpg"
    return rel


def datei_pfad(wurzel, rel):
    """Sicherer Dateipfad im Tresor (auch gegen Symlinks)."""
    rel = relativ_sicher(rel)
    basis = os.path.realpath(wurzel)
    ziel = os.path.realpath(os.path.join(basis, rel))
    if ziel != basis and not ziel.startswith(basis + os.sep):
        raise TresorFehler("Eintrag liegt ausserhalb des Tresors")
    return ziel, rel


def eintrag_id(wurzel, datei):
    return os.path.relpath(datei, wurzel).replace(os.sep, "/")[:-4]


def empfaenger(wurzel, rel, cfg=None):
    """Empfaenger aus Einstellungen oder der naechsten .gpg-id (pass-Standard)."""
    fest = [k.strip() for k in str((cfg or {}).get("schluessel") or "").split(",") if k.strip()]
    if fest:
        return fest
    ordner = os.path.dirname(os.path.join(wurzel, relativ_sicher(rel)))
    basis = os.path.realpath(wurzel)
    while True:
        datei = os.path.join(ordner, ".gpg-id")
        if os.path.isfile(datei):
            try:
                with open(datei, encoding="utf-8") as f:
                    werte = [z.strip() for z in f if z.strip() and not z.lstrip().startswith("#")]
                if werte:
                    return werte
            except OSError as fehler:
                raise TresorFehler(".gpg-id nicht lesbar: %s" % fehler)
        if os.path.realpath(ordner) == basis or not ordner.startswith(basis):
            break
        ordner = os.path.dirname(ordner)
    return []


def git_lauf(wurzel, args, cfg=None, timeout=90):
    try:
        lauf = subprocess.run(["git", "-C", wurzel] + list(args), stdout=subprocess.PIPE,
                              stderr=subprocess.PIPE, timeout=timeout, env=_umgebung(cfg))
    except (OSError, subprocess.TimeoutExpired) as fehler:
        raise TresorFehler("Git: %s" % fehler)
    if lauf.returncode:
        raise TresorFehler("Git: %s" % _fehlertext(lauf.stderr))
    return lauf.stdout.decode("utf-8", "replace")


def git_ist_repo(wurzel):
    return os.path.isdir(os.path.join(wurzel, ".git"))


def git_commit(wurzel, cfg, nachricht):
    if not git_ist_repo(wurzel) or not (cfg or {}).get("git_an"):
        return
    git_lauf(wurzel, ["add", "-A"], cfg)
    env = _umgebung(cfg)
    umgebung = dict(env, GIT_AUTHOR_NAME=cfg.get("git_name") or "H0rSt",
                    GIT_AUTHOR_EMAIL=cfg.get("git_email") or "h0rst@localhost",
                    GIT_COMMITTER_NAME=cfg.get("git_name") or "H0rSt",
                    GIT_COMMITTER_EMAIL=cfg.get("git_email") or "h0rst@localhost")
    try:
        lauf = subprocess.run(["git", "-C", wurzel, "commit", "-m", str(nachricht)[:200]],
                              stdout=subprocess.PIPE, stderr=subprocess.PIPE, timeout=60, env=umgebung)
    except (OSError, subprocess.TimeoutExpired) as fehler:
        raise TresorFehler("Git: %s" % fehler)
    if lauf.returncode and b"nothing to commit" not in lauf.stderr:
        raise TresorFehler("Git: %s" % _fehlertext(lauf.stderr))
    if cfg.get("git_auto_push"):
        git_lauf(wurzel, ["push"], cfg)


def git_pull(wurzel, cfg):
    args = ["pull"]
    if (cfg or {}).get("git_rebase", True):
        args.append("--rebase")
    return git_lauf(wurzel, args, cfg)


def git_push(wurzel, cfg):
    return git_lauf(wurzel, ["push"], cfg)
