"""("_• )—* – Portal: Adressen, IPs, Rechnernamen und MAC-Adressen als eigene Reiter.

Ein Tipp auf den Reiter ("_• )—* oeffnet ein Fenster: Adresse eingeben, H0rSt prueft sie (portal_pruefen.py) und
erzeugt daraus einen neuen Reiter mit dem Inhalt. Ein Reiter bleibt, bis man ihn ausdruecklich schliesst; verankerte
(📌) stehen vorn und ueberstehen "Alle schliessen". Mehrere Reiter lassen sich zu einem zusammenfuehren (bis zu vier
Teile nebeneinander, untereinander oder im Raster) und wieder trennen.

Ein Teil zeigt seine Adresse auf eine von drei Arten (modus):
  rahmen  direkt eingebettet (der Browser laedt die Seite selbst)
  durch   ueber H0rSt durchgereicht (portal_durch.py) – fuer Seiten, die sich nicht einbetten lassen, und fuer das
          Heimnetz von unterwegs; braucht das Recht "einstellungen"
  fenster nur als Knopf "In neuem Fenster oeffnen"

Nutzerdaten "portal": {"<profil-id oder ''>": {"reiter": [...], "verlauf": [...], "favoriten": [...], "einstellungen": {...}}}
"""

import time
from urllib.parse import urlsplit

from .portal_grund import *
from .portal_grund import _alle, _eintrag, _finde, _merken, _reiter, _teil, _text, _url


def aendern(daten, profil_id, wunsch, darf_durch=True, jetzt=time.time):
    """Eine Aenderung uebernehmen und die neuen Werte zurueckgeben. Aktionen:
      oeffnen {url, eingabe, mac, titel, symbol, modus}   neuer Reiter (gleiche Adresse: der vorhandene)
      schliessen {id, trotzdem}   alle_schliessen   anker {id, an}   verschieben {id, richtung}
      aendern {id, titel, symbol, zoom, ansicht, neu_laden, dunkel, anordnung, modus, teil, ausblenden, css, js, vertrauen}
      zusammen {ids}   trennen {id}   favorit {url, titel, an}   verlauf_weg {url}   verlauf_leeren
      einstellungen {…}   einspielen {reiter, favoriten}"""
    if not isinstance(wunsch, dict):
        raise PortalFehler("JSON-Objekt erwartet")
    alle = dict(_alle(daten))
    pid = profil_id or ""
    e = pruefe(alle.get(pid), darf_durch)
    st = e["einstellungen"]
    aktion = wunsch.get("aktion")
    ergebnis = {}
    if aktion == "oeffnen" and wunsch.get("usb") is True:  # USB Magic: ein Reiter, der den USB-Verwalter zeigt
        alt = next((r for r in e["reiter"] if r.get("art") == "usb"), None)
        if alt:
            ergebnis["id"], ergebnis["schon"] = alt["id"], True
        else:
            if len(e["reiter"]) >= MAX_REITER:
                raise PortalFehler("Höchstens %d Reiter – schließe erst einen" % MAX_REITER)
            r = _reiter({"art": "usb", "titel": wunsch.get("titel") or "USB Magic", "symbol": wunsch.get("symbol"),
                         "teile": [], "erstellt": int(jetzt())}, {x["id"] for x in e["reiter"]}, darf_durch)
            e["reiter"].insert(sum(1 for x in e["reiter"] if x["anker"]) if st["neue"] == "vorne" else len(e["reiter"]), r)
            ergebnis["id"] = r["id"]
    elif aktion == "oeffnen":
        teil = {"url": wunsch.get("url"), "eingabe": wunsch.get("eingabe"), "mac": wunsch.get("mac"),
                "modus": wunsch.get("modus"), "titel": wunsch.get("titel")}
        if wunsch.get("modus") == "durch" and not darf_durch:
            raise PortalFehler("Durchreichen über H0rSt braucht das Recht „Einstellungen“ – wähle „Direkt einbetten“")
        teil = _teil(teil, darf_durch)
        alt = next((r for r in e["reiter"] if len(r["teile"]) == 1 and r["teile"][0]["url"] == teil["url"]), None)
        if alt:
            alt["teile"][0].update(modus=teil["modus"], schluessel=alt["teile"][0]["schluessel"] or teil["schluessel"])
            ergebnis["id"], ergebnis["schon"] = alt["id"], True
        else:
            if len(e["reiter"]) >= MAX_REITER:
                raise PortalFehler("Höchstens %d Reiter – schließe erst einen" % MAX_REITER)
            r = _reiter({"titel": wunsch.get("titel"), "symbol": wunsch.get("symbol"), "teile": [teil], "zoom": st["zoom"],
                         "ansicht": st["ansicht"], "neu_laden": st["neu_laden"], "dunkel": st["dunkel"],
                         "erstellt": int(jetzt())}, {x["id"] for x in e["reiter"]}, darf_durch)
            if st["neue"] == "vorne":
                stelle = sum(1 for x in e["reiter"] if x["anker"])
                e["reiter"].insert(stelle, r)
            else:
                e["reiter"].append(r)
            ergebnis["id"] = r["id"]
        _merken(e["verlauf"], _eintrag({"url": teil["url"], "titel": wunsch.get("titel"), "eingabe": teil["eingabe"],
                                        "mac": teil["mac"], "zeit": int(jetzt())}), st["verlauf_max"])
    elif aktion == "schliessen":
        r = _finde(e, wunsch.get("id"))
        if r["anker"] and wunsch.get("trotzdem") is not True:
            raise PortalFehler("„%s“ ist verankert – erst den Anker lösen (📌)" % r["titel"])
        e["reiter"].remove(r)
    elif aktion == "alle_schliessen":
        e["reiter"] = [r for r in e["reiter"] if r["anker"]]
    elif aktion == "anker":
        _finde(e, wunsch.get("id"))["anker"] = wunsch.get("an") is True
    elif aktion == "verschieben":
        r = _finde(e, wunsch.get("id"))
        n = e["reiter"].index(r)
        m = n + (1 if wunsch.get("richtung") == 1 else -1)
        if 0 <= m < len(e["reiter"]):
            e["reiter"][n], e["reiter"][m] = e["reiter"][m], e["reiter"][n]
    elif aktion == "aendern":
        r = _finde(e, wunsch.get("id"))
        neu = dict(r)
        for k in ("titel", "symbol", "zoom", "ansicht", "neu_laden", "dunkel", "anordnung", "ausblenden", "css", "js", "vertrauen"):
            if k in wunsch:
                neu[k] = wunsch[k]
        if "modus" in wunsch:
            if wunsch["modus"] == "durch" and not darf_durch:
                raise PortalFehler("Durchreichen über H0rSt braucht das Recht „Einstellungen“")
            nummern = range(len(r["teile"])) if wunsch.get("teil") is None else [wunsch.get("teil")]
            neu["teile"] = [dict(t, modus=wunsch["modus"]) if i in nummern else t for i, t in enumerate(r["teile"])]
        neu = _reiter(neu, {x["id"] for x in e["reiter"] if x is not r}, darf_durch)
        e["reiter"][e["reiter"].index(r)] = neu
    elif aktion == "zusammen":
        ids = [str(i) for i in wunsch.get("ids") or [] if isinstance(i, str)]
        gruppe = [_finde(e, i) for i in dict.fromkeys(ids)]
        if len(gruppe) < 2:
            raise PortalFehler("Mindestens zwei Reiter wählen")
        teile = [t for r in gruppe for t in r["teile"]]
        if len(teile) > MAX_TEILE:
            raise PortalFehler("Höchstens %d Seiten in einem Reiter" % MAX_TEILE)
        haupt = gruppe[0]
        for r in gruppe:
            for t in r["teile"]:
                t["titel"] = t["titel"] or r["titel"]
        haupt["teile"] = teile
        haupt["titel"] = _text(wunsch.get("titel"), 40) or " + ".join(r["titel"] for r in gruppe)[:40]
        haupt["anker"] = any(r["anker"] for r in gruppe)
        e["reiter"] = [r for r in e["reiter"] if r is haupt or r not in gruppe]
        ergebnis["id"] = haupt["id"]
    elif aktion == "trennen":
        r = _finde(e, wunsch.get("id"))
        if len(r["teile"]) < 2:
            raise PortalFehler("Dieser Reiter zeigt nur eine Seite")
        n = e["reiter"].index(r)
        if len(e["reiter"]) - 1 + len(r["teile"]) > MAX_REITER:
            raise PortalFehler("Höchstens %d Reiter" % MAX_REITER)
        ids = {x["id"] for x in e["reiter"] if x is not r}
        neue = [_reiter(dict(r, id=r["id"] if i == 0 else "", teile=[t], titel=t["titel"] or urlsplit(t["url"]).hostname),
                        ids, darf_durch) for i, t in enumerate(r["teile"])]
        e["reiter"][n:n + 1] = neue
    elif aktion == "favorit":
        url = _url(wunsch.get("url"))
        e["favoriten"] = [x for x in e["favoriten"] if x["url"] != url]
        if wunsch.get("an") is not False:
            if len(e["favoriten"]) >= MAX_FAVORITEN:
                raise PortalFehler("Höchstens %d Favoriten" % MAX_FAVORITEN)
            e["favoriten"].insert(0, _eintrag(dict(wunsch, zeit=int(jetzt()))))
    elif aktion == "verlauf_weg":
        e["verlauf"] = [x for x in e["verlauf"] if x["url"] != str(wunsch.get("url") or "")]
    elif aktion == "verlauf_leeren":
        e["verlauf"] = []
    elif aktion == "einstellungen":
        neu = dict(st)
        for k in EINSTELLUNGEN:
            if k in wunsch:
                neu[k] = wunsch[k]
        e["einstellungen"] = einstellungen_pruefe(neu)
        if any(neu[k] != e["einstellungen"][k] for k in neu if k != "zoom"):
            raise PortalFehler("Unbekannter Wert in den Einstellungen")
    elif aktion == "einspielen":  # Export einer anderen Sitzung oder eines anderen Geraets dazunehmen
        fremd = pruefe({"reiter": wunsch.get("reiter"), "favoriten": wunsch.get("favoriten")}, darf_durch)
        vorhanden = {t["url"] for r in e["reiter"] for t in r["teile"]}
        ids = {x["id"] for x in e["reiter"]}
        for r in fremd["reiter"]:
            if any(t["url"] in vorhanden for t in r["teile"]) or len(e["reiter"]) >= MAX_REITER:
                continue
            e["reiter"].append(_reiter(dict(r, id="", teile=[dict(t, schluessel="") for t in r["teile"]]), ids, darf_durch))
        bekannt = {x["url"] for x in e["favoriten"]}
        e["favoriten"] += [x for x in fremd["favoriten"] if x["url"] not in bekannt][:MAX_FAVORITEN - len(e["favoriten"])]
    else:
        raise PortalFehler("Unbekannte Aktion")
    e["reiter"].sort(key=lambda r: not r["anker"])
    alle[pid] = e
    daten[SCHLUESSEL] = alle
    return dict(e, **ergebnis)
