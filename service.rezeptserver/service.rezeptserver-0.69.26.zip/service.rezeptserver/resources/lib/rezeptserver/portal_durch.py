"""("_• )—* – Portal: Seiten ueber H0rSt durchreichen (/portal/<schluessel>/<pfad>).

Fuer Seiten, die sich nicht einbetten lassen (X-Frame-Options, CSP), fuer Geraete im Heimnetz von unterwegs und fuer
https-Oberflaechen, die sonst http-Geraete nicht zeigen duerfen. H0rSt holt jede Anfrage beim Ziel ab und gibt sie weiter:

  * Der Schluessel gehoert zu genau einem Reiter-Teil und fuehrt nur zu dessen Ursprung (scheme://host:port).
    Er steht ausserhalb des H0rSt-Tokens im Pfad, damit die durchgereichte Seite das Token nie zu sehen bekommt.
  * Cookies der Seite (Anmeldung am Router …) bleiben in einer Keksdose bei H0rSt, nie im Browser.
  * Kopfzeilen, die das Einbetten verbieten, fallen weg; Adressen in HTML und CSS zeigen wieder auf /portal/<schluessel>/,
    ein kleines Skript lenkt fetch/XHR/Formulare der Seite ebenso um.
  * Auf Wunsch kommen Nachtfilter, ausgeblendete Elemente, eigenes CSS und JavaScript dazu (Reiter-Einstellungen).
Die Oberflaeche zeigt solche Teile in einem abgeschotteten Rahmen (sandbox ohne allow-same-origin), ausser der Reiter
ist als "vertraut" markiert.
"""

import collections
import gzip
import html
import http.cookiejar
import json
import re
import threading
import time
import urllib.error
import urllib.request
import zlib
from urllib.parse import urlsplit

from .netz import USER_AGENT, _NichtFolgen
from .portal import durchreich_ziele, ist_lokal, ursprung
from .portal_pruefen import _kontext

MAX_UMSCHREIBEN = 10 * 1024 * 1024
MAX_DOSEN = 64
_WEITER_ANFRAGE = ("accept", "accept-language", "content-type", "range", "if-none-match", "if-modified-since", "authorization",
                   "x-requested-with", "user-agent", "cache-control")
_WEITER_ANTWORT = ("content-type", "cache-control", "etag", "last-modified", "expires", "content-disposition", "content-range",
                   "accept-ranges", "www-authenticate", "content-language", "vary")
_TEXT = ("text/html", "application/xhtml+xml", "text/css")
_NACHT = ("html{filter:invert(.9) hue-rotate(180deg)!important;background:#fff}"
          "img,video,picture,canvas,iframe,svg image,[style*='background-image']{filter:invert(1) hue-rotate(180deg)!important}")


def _js(wert):
    return json.dumps(wert).replace("</", "<\\/")


def umschreiben(text, praefix, basis, css=False):
    """Adressen der Zielseite auf /portal/<schluessel>/ lenken: wurzelrelative (/x) und absolute (http://ziel/x)."""
    t = urlsplit(basis)
    standard = 443 if t.scheme == "https" else 80
    hosts = {t.netloc, t.hostname if t.port in (None, standard) else t.netloc, "%s:%d" % (t.hostname, t.port or standard)}
    if not css:
        text = re.sub(r"""(\s(?:href|src|action|formaction|poster|data|background|cite)\s*=\s*["']?)/(?!/)""", r"\1" + praefix + "/", text, flags=re.I)
        text = re.sub(r"""(\ssrcset\s*=\s*)(["'])(.*?)\2""", lambda m: m.group(1) + m.group(2) + re.sub(
            r"(^|,\s*)/(?!/)", r"\1" + praefix + "/", m.group(3)) + m.group(2), text, flags=re.I | re.S)
        text = re.sub(r"""(<meta[^>]+content\s*=\s*["']?\s*\d+\s*;\s*url\s*=\s*)/(?!/)""", r"\1" + praefix + "/", text, flags=re.I)
    text = re.sub(r"""(url\(\s*["']?)/(?!/)""", r"\1" + praefix + "/", text, flags=re.I)
    text = re.sub(r"""(@import\s+["'])/(?!/)""", r"\1" + praefix + "/", text, flags=re.I)
    muster = "|".join(re.escape(h) for h in sorted(hosts, key=len, reverse=True))
    return re.sub(r"(?:https?:)?//(?:%s)(?=[/\"'?#\s)<]|$)" % muster, praefix, text, flags=re.I)


def kopfskript(praefix, basis, kekse=""):
    """Skript fuer den Anfang der Seite: fetch, XHR, Formulare, Links, window.open und history auf den Durchreicher lenken;
    localStorage, sessionStorage und document.cookie ersetzen, wenn der Rahmen abgeschottet ist."""
    return ("<script>(function(){var P=%s,O=%s;function f(u){if(typeof u!=='string')return u;"
            "if(u.indexOf(O)===0)return P+u.slice(O.length);"
            "if(u.charAt(0)==='/'&&u.charAt(1)!=='/'&&u.indexOf(P+'/')!==0&&u!==P)return P+u;return u}"
            "var F=window.fetch;if(F)window.fetch=function(i,o){if(typeof i==='string')i=f(i);"
            "else if(i&&i.url&&window.Request){try{var n=f(i.url);if(n!==i.url)i=new Request(n,i)}catch(e){}}return F.call(this,i,o)};"
            "var X=XMLHttpRequest.prototype.open;XMLHttpRequest.prototype.open=function(m,u){arguments[1]=f(String(u));return X.apply(this,arguments)};"
            "var W=window.open;window.open=function(u){if(u!=null)arguments[0]=f(String(u));return W.apply(this,arguments)};"
            "['pushState','replaceState'].forEach(function(k){var h=history[k];history[k]=function(s,t,u){try{return h.call(this,s,t,u==null?u:f(String(u)))}catch(e){}}});"
            "document.addEventListener('click',function(e){var a=e.target&&e.target.closest&&e.target.closest('a[href]');"
            "if(a){var h=a.getAttribute('href'),n=f(h);if(n!==h)a.setAttribute('href',n)}},true);"
            "document.addEventListener('submit',function(e){var x=e.target,h=x&&x.getAttribute&&x.getAttribute('action');"
            "if(h){var n=f(h);if(n!==h)x.setAttribute('action',n)}},true);"
            "function S(){var d={};return{getItem:function(k){return k in d?d[k]:null},setItem:function(k,v){d[k]=String(v)},"
            "removeItem:function(k){delete d[k]},clear:function(){d={}},key:function(i){return Object.keys(d)[i]||null},"
            "get length(){return Object.keys(d).length}}}"
            "['localStorage','sessionStorage'].forEach(function(k){try{window[k].length}catch(e){try{Object.defineProperty(window,k,{value:S()})}catch(e2){}}});"
            "try{document.cookie}catch(e){var K=%s;try{Object.defineProperty(document,'cookie',{get:function(){return K},"
            "set:function(v){var n=String(v).split(';')[0],a=K?K.split('; '):[],z=n.split('=')[0];"
            "a=a.filter(function(x){return x.split('=')[0]!==z});a.push(n);K=a.join('; ')}})}catch(e2){}}"
            "})();</script>") % (_js(praefix), _js(basis), _js(kekse))


def _einschleusen(reiter):
    css = ""
    if reiter.get("dunkel"):
        css += _NACHT
    auswahl = [s.strip() for s in re.split(r"[\n,]", reiter.get("ausblenden") or "") if s.strip()]
    if auswahl:
        css += ",".join(auswahl) + "{display:none!important}"
    css += reiter.get("css") or ""
    teile = []
    if css:
        teile.append("<style data-h0rst-portal>%s</style>" % css.replace("</", "<\\/"))
    if reiter.get("js"):
        teile.append("<script data-h0rst-portal>try{%s}catch(e){console.warn('H0rSt-Portal:',e)}</script>"
                     % reiter["js"].replace("</script", "<\\/script"))
    return "".join(teile)


def _kekse_fuer_skript(dose, ziel):
    """Cookies, die die Seite per document.cookie lesen duerfte (ohne HttpOnly) – fuer den Ersatz im abgeschotteten Rahmen."""
    anfrage = urllib.request.Request(ziel)
    dose.add_cookie_header(anfrage)
    verborgen = {c.name for c in dose if c.has_nonstandard_attr("HttpOnly") or c.has_nonstandard_attr("httponly")}
    paare = [p for p in (anfrage.get_header("Cookie") or "").split("; ") if p and p.split("=", 1)[0] not in verborgen]
    return "; ".join(paare)


def _fehlerseite(titel, text):
    return ("<!doctype html><meta charset=utf-8><title>%s</title><body style=\"font:16px system-ui;background:#111;color:#ddd;"
            "display:grid;place-items:center;min-height:90vh;margin:0\"><div style=\"max-width:32em;padding:1em\">"
            "<p style=\"font-size:2em;margin:0\">(\"_• )—*</p><h1 style=\"font-size:1.2em\">%s</h1><p>%s</p></div>"
            % (html.escape(titel), html.escape(titel), html.escape(text))).encode("utf-8")


class Durchreicher:
    def __init__(self, daten_holen, unsicher_lokal=True):
        self._daten = daten_holen
        self.unsicher_lokal = unsicher_lokal
        self._ziele, self._zeit = {}, 0.0
        self._dosen = collections.OrderedDict()
        self._sperre = threading.Lock()

    def vergessen(self):
        """Reiter haben sich geaendert: beim naechsten Abruf neu nachsehen (geschlossene Schluessel gelten nicht mehr)."""
        with self._sperre:
            self._zeit = 0.0
            self._ziele = {}

    def _ziel(self, schluessel):
        with self._sperre:
            jetzt = time.monotonic()
            if jetzt - self._zeit > 30 or (schluessel not in self._ziele and jetzt - self._zeit > 2):
                self._ziele, self._zeit = durchreich_ziele(self._daten()), jetzt
                for alt in [k for k in self._dosen if k not in self._ziele]:
                    del self._dosen[alt]
            return self._ziele.get(schluessel)

    def _dose(self, schluessel):
        with self._sperre:
            dose = self._dosen.pop(schluessel, None) or http.cookiejar.CookieJar()
            self._dosen[schluessel] = dose
            while len(self._dosen) > MAX_DOSEN:
                self._dosen.popitem(last=False)
            return dose

    def kekse_leeren(self, schluessel=None):
        with self._sperre:
            if schluessel:
                self._dosen.pop(schluessel, None)
            else:
                self._dosen.clear()

    def anfrage(self, schluessel, rest, abfrage, methode, koerper, kopf):
        """Antwort fuer /portal/<schluessel>/<rest>: ("portal", (status, [(kopf, wert)], bytes oder offene Antwort))."""
        z = self._ziel(schluessel)
        if not z:
            return "portal", (404, [("Content-Type", "text/html; charset=utf-8")],
                              _fehlerseite("Reiter geschlossen", "Dieser Portal-Reiter wurde geschlossen oder gehört nicht mehr hierher."))
        teil, reiter = z
        basis = ursprung(teil["url"])
        praefix = "/portal/" + schluessel
        ziel = basis + "/" + rest + ("?" + abfrage if abfrage else "")
        header = {"User-Agent": USER_AGENT, "Accept-Encoding": "gzip, deflate"}
        for k in _WEITER_ANFRAGE:
            if kopf.get(k):
                header[k.title()] = kopf.get(k)
        for k in ("Referer", "Origin"):
            wert = kopf.get(k)
            if wert:
                pfad = urlsplit(wert).path
                header[k] = basis + (pfad[len(praefix):] if pfad.startswith(praefix) and k == "Referer" else "")
        dose = self._dose(schluessel)
        host = urlsplit(basis).hostname
        oeffner = urllib.request.build_opener(_NichtFolgen, urllib.request.HTTPCookieProcessor(dose),
                                              urllib.request.HTTPSHandler(context=_kontext(self.unsicher_lokal and ist_lokal(host))))
        daten = koerper if methode == "POST" else None
        try:
            antwort = oeffner.open(urllib.request.Request(ziel, data=daten, headers=header, method=methode), timeout=25)
        except urllib.error.HTTPError as f:
            antwort = f
        except (urllib.error.URLError, OSError, ValueError) as f:
            grund = getattr(f, "reason", f)
            return "portal", (502, [("Content-Type", "text/html; charset=utf-8")],
                              _fehlerseite("Nicht erreichbar", "%s antwortet nicht (%s)." % (basis, grund)))
        return "portal", self._antwort(antwort, praefix, basis, reiter, dose, ziel)

    def _antwort(self, antwort, praefix, basis, reiter, dose, ziel):
        status = getattr(antwort, "status", None) or antwort.code
        k = antwort.headers
        aus = [(name, k[name]) for name in (x.title() for x in _WEITER_ANTWORT) if k.get(name)]
        aus.append(("X-Frame-Options", "SAMEORIGIN"))  # nur H0rSt selbst darf den Durchreicher einbetten
        ort = k.get("Location")
        if ort:
            if ort.startswith(basis + "/") or ort == basis:
                ort = praefix + ort[len(basis):]
            elif ort.startswith("/") and not ort.startswith("//"):
                ort = praefix + ort
            aus.append(("Location", ort or praefix + "/"))
        typ = (k.get("Content-Type") or "").split(";")[0].strip().lower()
        kodierung = (k.get("Content-Encoding") or "").lower()
        laenge = k.get("Content-Length")
        try:
            laenge_nr = int(laenge) if laenge else 0
        except (TypeError, ValueError):
            laenge_nr = 0  # kaputter Kopf: ausprobieren statt scheitern
        if typ in _TEXT and kodierung in ("", "identity", "gzip", "deflate") and laenge_nr <= MAX_UMSCHREIBEN:
            try:
                roh = antwort.read(MAX_UMSCHREIBEN + 1)
            finally:
                antwort.close()
            if kodierung == "gzip":
                roh = gzip.decompress(roh)
            elif kodierung == "deflate":
                roh = zlib.decompress(roh, -zlib.MAX_WBITS) if roh[:1] != b"\x78" else zlib.decompress(roh)
            zs = re.search(r"charset=([\w-]+)", k.get("Content-Type") or "", re.I)
            zeichensatz = zs.group(1) if zs else "utf-8"
            try:
                text = roh.decode(zeichensatz, "replace")
            except LookupError:
                zeichensatz, text = "utf-8", roh.decode("utf-8", "replace")
            if typ == "text/css":
                text = umschreiben(text, praefix, basis, css=True)
            else:
                text = umschreiben(text, praefix, basis)
                kopf = kopfskript(praefix, basis, _kekse_fuer_skript(dose, ziel)) + _einschleusen(reiter)
                m = re.search(r"<head\b[^>]*>", text, re.I) or re.search(r"<html\b[^>]*>", text, re.I)
                stelle = m.end() if m else 0
                text = text[:stelle] + kopf + text[stelle:]
            kopfzeilen = [x for x in aus if x[0] != "Content-Type"] + [("Content-Type", "%s; charset=%s" % (typ, zeichensatz))]
            if typ in ("text/html", "application/xhtml+xml"):
                # eigene Sandbox, ohne allow-same-origin: die Seite teilt nicht den Ursprung von H0rSt
                kopfzeilen.append(("Content-Security-Policy",
                                   "sandbox allow-scripts allow-forms allow-popups allow-downloads allow-modals"))
            return status, kopfzeilen, text.encode(zeichensatz, "replace")
        if kodierung:
            aus.append(("Content-Encoding", kodierung))
        if laenge:
            aus.append(("Content-Length", laenge))
        return status, aus, antwort


def senden(handler, antwort):
    """Antwort des Durchreichers schreiben; offene Antworten in Stuecken (Bilder, Downloads, Videos)."""
    status, kopf, koerper = antwort
    handler.send_response(status)
    for name, wert in kopf:
        handler.send_header(name, wert)
    if isinstance(koerper, bytes):
        handler.send_header("Content-Length", str(len(koerper)))
        handler.end_headers()
        if handler.command != "HEAD":
            handler.wfile.write(koerper)
        return
    handler.close_connection = True
    handler.end_headers()
    try:
        while handler.command != "HEAD":
            stueck = koerper.read(65536)
            if not stueck:
                break
            handler.wfile.write(stueck)
    except (BrokenPipeError, ConnectionResetError, OSError):
        pass
    finally:
        koerper.close()
