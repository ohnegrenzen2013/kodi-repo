"""Portal: Konstanten und Hilfen fuer Reiter, Einstellungen und Eingaben."""

import ipaddress
import re
import secrets
from urllib.parse import urlsplit

SCHLUESSEL = "portal"
NAME = '("_• )—*'
MAX_REITER = 40
MAX_TEILE = 4
MAX_FAVORITEN = 200
MODI = ("rahmen", "durch", "fenster")
ANORDNUNGEN = ("auto", "spalten", "zeilen", "raster")
ANSICHTEN = ("voll", "handy", "tablet", "desktop")
NEU_LADEN = (0, 30, 60, 300, 900, 3600)
EINSTELLUNGEN = {
    "modus": ("auto",) + MODI,       # auto: einbetten, wenn die Seite es erlaubt, sonst durchreichen (oder Fenster)
    "zoom": 100,                     # 50 … 200 %
    "ansicht": ANSICHTEN,            # Breite des Rahmens: voll, Handy (412 px), Tablet (820 px), Desktop (1280 px, verkleinert)
    "neu_laden": NEU_LADEN,          # Sekunden, 0 = nie
    "leiste": ("leiste", "popup"),   # erzeugte Reiter oben in der Leiste zeigen oder nur im Fenster
    "neue": ("hinten", "vorne"),     # wo neue Reiter erscheinen
    "kopf": ("normal", "kompakt", "aus"),
    "verlauf_max": (30, 10, 50, 100),
    "waechter": True,                # Erreichbarkeit der Reiter regelmaessig pruefen (Punkt in der Leiste)
    "dunkel": False,                 # Nachtfilter fuer neue Reiter
    "anstossen": True,               # MAC-Suche: das Heimnetz kurz anstossen, damit sich Geraete melden
    "ports": True,                   # IP ohne Port: gaengige Web-Ports abklopfen, wenn Port 80 schweigt
    "zertifikat": True,              # selbst signierte Zertifikate im Heimnetz annehmen
}
_MAC = re.compile(r"^(?:[0-9a-f]{2}([:-]))(?:[0-9a-f]{2}\1){4}[0-9a-f]{2}$|^[0-9a-f]{12}$|^(?:[0-9a-f]{4}\.){2}[0-9a-f]{4}$", re.I)
_HOST = re.compile(r"^(?=.{1,253}$)[a-z0-9_](?:[a-z0-9_-]{0,62})(?:\.[a-z0-9_](?:[a-z0-9_-]{0,62}))*\.?$", re.I)
_LOKALE_ENDUNGEN = (".local", ".lan", ".home", ".box", ".internal", ".intranet", ".fritz.box", ".hole", ".localdomain", ".arpa")


class PortalFehler(ValueError):
    pass


def _text(wert, laenge):
    return " ".join(str(wert or "").split())[:laenge]


def mac_normal(wert):
    """MAC in Kleinbuchstaben mit Doppelpunkten oder '' (aa:bb:…, AA-BB-…, aabb.ccdd.eeff, aabbccddeeff)."""
    wert = str(wert or "").strip()
    if not _MAC.match(wert):
        return ""
    roh = re.sub(r"[^0-9a-f]", "", wert.lower())
    return ":".join(roh[i:i + 2] for i in range(0, 12, 2))


def ist_lokal(host):
    """Geraet im Heimnetz? (private/lokale IP, localhost, Name ohne Punkt, .local, .lan, fritz.box …)"""
    host = str(host or "").strip("[]").lower().rstrip(".")
    if not host:
        return False
    try:
        ip = ipaddress.ip_address(host)
        return ip.is_private or ip.is_loopback or ip.is_link_local
    except ValueError:
        pass
    return host == "localhost" or "." not in host or host.endswith(_LOKALE_ENDUNGEN)


def erkenne(eingabe):
    """Was wurde eingegeben? {"art": url|ip|host|mac, "url", "host", "mac"}; PortalFehler bei Unsinn.

    Ohne Schema bekommen Heimnetz-Ziele http://, alles andere https:// (wie die Adresszeile der Brause)."""
    roh = str(eingabe or "").strip()
    if not roh or len(roh) > 2000:
        raise PortalFehler("Bitte eine Adresse, IP oder MAC eingeben")
    mac = mac_normal(roh)
    if mac:
        return {"art": "mac", "url": "", "host": "", "mac": mac}
    try:
        if ipaddress.ip_address(roh).version == 6:  # fe80::1 -> [fe80::1]
            roh = "[%s]" % roh
    except ValueError:
        pass
    if re.match(r"^[a-z][a-z0-9+.-]*://", roh, re.I):
        if not re.match(r"^https?://", roh, re.I):
            raise PortalFehler("Nur http:// und https:// – andere Arten öffnet H0rSt hier nicht")
        url = roh
    elif re.match(r"^[a-z][a-z0-9+.-]*:(?!\d)", roh, re.I) and not roh.startswith("["):
        raise PortalFehler("Nur http:// und https:// – andere Arten öffnet H0rSt hier nicht")
    else:
        url = "//" + roh
    teile = urlsplit(url)
    try:
        host, port = teile.hostname, teile.port
    except ValueError:
        raise PortalFehler("Ungültiger Port")
    if not host:
        raise PortalFehler("Keine Adresse erkannt")
    art = "host"
    try:
        ipaddress.ip_address(host)
        art = "ip"
    except ValueError:
        if not _HOST.match(host):
            raise PortalFehler("„%s“ ist keine gültige Adresse" % host[:80])
    if url.startswith("//"):
        url = ("http:" if ist_lokal(host) or port in (80, 8080, 8000, 8123, 8096, 32400, 5000, 9000) else "https:") + url
    if not teile.path:
        url += "/"
    if "@" in (teile.netloc or ""):
        raise PortalFehler("Zugangsdaten bitte nicht in die Adresse schreiben – die Seite fragt selbst danach")
    return {"art": "url" if "://" in roh else art, "url": url[:2000], "host": host, "mac": "", "port": port}


def ursprung(url):
    """scheme://host[:port] einer Adresse."""
    t = urlsplit(url)
    return "%s://%s" % (t.scheme, t.netloc)


def _url(wert):
    url = str(wert or "").strip()[:2000]
    t = urlsplit(url)
    if t.scheme not in ("http", "https") or not t.hostname:
        raise PortalFehler("Adresse mit http(s)://")
    return url


# --- Werte pruefen ---------------------------------------------------------------------------------------------------
def einstellungen_pruefe(roh):
    roh = roh if isinstance(roh, dict) else {}
    e = {}
    for k, art in EINSTELLUNGEN.items():
        w = roh.get(k)
        if isinstance(art, tuple):
            e[k] = w if w in art else art[0]
        elif isinstance(art, bool):
            e[k] = w if isinstance(w, bool) else art
        else:  # zoom
            e[k] = _zoom(w, art)
    return e


def _zoom(w, standard=100):
    try:
        z = int(w)
    except (TypeError, ValueError):
        return standard
    return min(200, max(50, z))


def _teil(roh, darf_durch=True):
    if not isinstance(roh, dict):
        raise PortalFehler("Teil als Objekt")
    modus = roh.get("modus") if roh.get("modus") in MODI else "rahmen"
    if modus == "durch" and not darf_durch:
        modus = "fenster"
    schluessel = str(roh.get("schluessel") or "")
    if modus == "durch" and not re.match(r"^[A-Za-z0-9_-]{24,64}$", schluessel):
        schluessel = secrets.token_urlsafe(24)
    return {"url": _url(roh.get("url")), "eingabe": _text(roh.get("eingabe"), 200), "mac": mac_normal(roh.get("mac")),
            "modus": modus, "schluessel": schluessel if modus == "durch" else "",
            "titel": _text(roh.get("titel"), 80)}


def _reiter(roh, ids, darf_durch=True):
    if not isinstance(roh, dict):
        raise PortalFehler("Reiter als Objekt")
    art = roh.get("art") if roh.get("art") in ("web", "usb") else "web"
    teile = [_teil(t, darf_durch) for t in (roh.get("teile") or [])[:MAX_TEILE]]
    if not teile and art != "usb":  # ein "usb"-Reiter (USB Magic) zeigt den USB-Verwalter, keine Adresse
        raise PortalFehler("Reiter ohne Adresse")
    rid = re.sub(r"[^a-z0-9]", "", str(roh.get("id") or "").lower())[:16] or secrets.token_hex(4)
    while rid in ids:
        rid = secrets.token_hex(4)
    ids.add(rid)
    neu_laden = roh.get("neu_laden") if roh.get("neu_laden") in NEU_LADEN else 0
    return {"id": rid, "art": art,
            "titel": _text(roh.get("titel"), 40) or (urlsplit(teile[0]["url"]).hostname if teile else "USB Magic"),
            "symbol": _text(roh.get("symbol"), 4) or ("🔌" if art == "usb" else ""), "anker": roh.get("anker") is True, "teile": teile,
            "anordnung": roh.get("anordnung") if roh.get("anordnung") in ANORDNUNGEN else "auto",
            "zoom": _zoom(roh.get("zoom")), "ansicht": roh.get("ansicht") if roh.get("ansicht") in ANSICHTEN else "voll",
            "neu_laden": neu_laden, "dunkel": roh.get("dunkel") is True,
            # nur beim Durchreichen: Elemente ausblenden (CSS-Selektoren), eigenes CSS und JavaScript einschleusen
            "ausblenden": str(roh.get("ausblenden") or "")[:2000], "css": str(roh.get("css") or "")[:20000],
            "js": str(roh.get("js") or "")[:20000],
            # durchgereichte Teile ohne Abschottung (localStorage, Cookies im Browser) – nur fuer eigene Geraete
            "vertrauen": roh.get("vertrauen") is True,
            "erstellt": int(roh.get("erstellt") or 0) if str(roh.get("erstellt") or "0").isdigit() else 0}


def _eintrag(roh):
    """Verlauf- und Favoriten-Eintrag {url, titel, eingabe, mac, zeit}."""
    if not isinstance(roh, dict):
        raise PortalFehler("Eintrag als Objekt")
    url = _url(roh.get("url"))
    return {"url": url, "titel": _text(roh.get("titel"), 80) or urlsplit(url).hostname,
            "eingabe": _text(roh.get("eingabe"), 200), "mac": mac_normal(roh.get("mac")),
            "zeit": int(roh.get("zeit") or 0) if str(roh.get("zeit") or "0").isdigit() else 0}


def pruefe(roh, darf_durch=True):
    """Gespeicherte Werte eines Profils; kaputte Eintraege fallen weg."""
    roh = roh if isinstance(roh, dict) else {}
    e = {"einstellungen": einstellungen_pruefe(roh.get("einstellungen")), "reiter": [], "verlauf": [], "favoriten": []}
    ids = set()
    for r in (roh.get("reiter") or [])[:MAX_REITER] if isinstance(roh.get("reiter"), list) else []:
        try:
            e["reiter"].append(_reiter(r, ids, darf_durch))
        except PortalFehler:
            continue
    for name, grenze in (("verlauf", e["einstellungen"]["verlauf_max"]), ("favoriten", MAX_FAVORITEN)):
        gesehen = set()
        for x in (roh.get(name) or [])[:grenze] if isinstance(roh.get(name), list) else []:
            try:
                x = _eintrag(x)
            except PortalFehler:
                continue
            if x["url"] not in gesehen:
                gesehen.add(x["url"])
                e[name].append(x)
    e["reiter"].sort(key=lambda r: not r["anker"])  # verankerte vorn
    return e


def _alle(daten):
    alle = daten.get(SCHLUESSEL)
    return alle if isinstance(alle, dict) else {}


def lesen(daten, profil_id):
    return pruefe(_alle(daten).get(profil_id or ""))


def durchreich_ziele(daten):
    """{schluessel: (teil, reiter)} ueber alle Profile – fuer /portal/<schluessel>/ (portal_durch.py)."""
    ziele = {}
    for wert in _alle(daten).values():
        for r in pruefe(wert)["reiter"]:
            for t in r["teile"]:
                if t["modus"] == "durch" and t["schluessel"]:
                    ziele[t["schluessel"]] = (t, r)
    return ziele


def _finde(e, rid):
    r = next((x for x in e["reiter"] if x["id"] == str(rid or "")), None)
    if not r:
        raise PortalFehler("Diesen Reiter gibt es nicht mehr")
    return r


def _merken(liste, eintrag, grenze):
    liste[:] = [eintrag] + [x for x in liste if x["url"] != eintrag["url"]]
    del liste[grenze:]
