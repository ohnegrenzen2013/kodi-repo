"""("_• )—* – Programme und Apps des Systems als Reiter-Vorschlaege.

Je nach System findet H0rSt, was sich als Reiter einbinden laesst:
  * Programme mit Weboberflaeche auf diesem Rechner oder einem Geraet im Heimnetz (Jellyfin, Pi-hole, qBittorrent,
    Home Assistant, Sonarr …): H0rSt klopft die bekannten Ports ab und erkennt das Programm an seiner Startseite.
    Daraus wird ein eingebetteter Reiter (portal.py, Aktion "oeffnen").
  * Desktop-Programme (Linux, Raspberry Pi): die Starter (.desktop) aus den ueblichen Ordnern. Ein Reiter dafuer
    startet das Programm auf dem Rechner, auf dem H0rSt laeuft (startbefehl) – nur mit Recht "einstellungen".
  * Android-Apps liefert die H0rSt-App selbst (app.apps() in der Oberflaeche), dafuer gibt es hier nichts zu tun.
"""

import os
import platform
import re
import shlex
import socket
import threading

# id, Name, Symbol, Ports, Pfad, Erkennung (regulaerer Ausdruck auf Titel, Server-Kopf und Seitenanfang)
PROGRAMME = [
    ("jellyfin", "Jellyfin", "🎞", (8096, 8920), "/", r"jellyfin"),
    ("emby", "Emby", "🎞", (8096,), "/", r"\bemby\b"),
    ("plex", "Plex", "🎞", (32400,), "/web/index.html", r"\bplex\b"),
    ("homeassistant", "Home Assistant", "🏠", (8123,), "/", r"home assistant"),
    ("pihole", "Pi-hole", "🛡", (80, 8081), "/admin/", r"pi-hole"),
    ("adguard", "AdGuard Home", "🛡", (3000, 80), "/", r"adguard"),
    ("qbittorrent", "qBittorrent", "⬇", (8080, 8090), "/", r"qbittorrent"),
    ("transmission", "Transmission", "⬇", (9091,), "/transmission/web/", r"transmission"),
    ("deluge", "Deluge", "⬇", (8112,), "/", r"deluge"),
    ("sabnzbd", "SABnzbd", "⬇", (8080, 8085), "/", r"sabnzbd"),
    ("nzbget", "NZBGet", "⬇", (6789,), "/", r"nzbget"),
    ("sonarr", "Sonarr", "📺", (8989,), "/", r"sonarr"),
    ("radarr", "Radarr", "🎬", (7878,), "/", r"radarr"),
    ("lidarr", "Lidarr", "🎵", (8686,), "/", r"lidarr"),
    ("prowlarr", "Prowlarr", "🔎", (9696,), "/", r"prowlarr"),
    ("bazarr", "Bazarr", "💬", (6767,), "/", r"bazarr"),
    ("seerr", "Jellyseerr / Overseerr", "🍿", (5055,), "/", r"jellyseerr|overseerr"),
    ("tautulli", "Tautulli", "📊", (8181,), "/", r"tautulli"),
    ("kodi", "Kodi (Chorus)", "📺", (8080,), "/", r"\bkodi\b|chorus"),
    ("emuleese", "eMule eSE LiveTV", "🐴", (8080,), "/live", r"emule|\bese\b|eSE"),
    ("comfyui", "ComfyUI", "🎨", (8188,), "/", r"comfyui"),
    ("wan2gp", "Wan2GP", "🎬", (7860,), "/", r"wan2gp|wan ?gp|wan 2gp"),
    ("locallyuncensored", "Locally Uncensored", "🔓", (11435,), "/", r"locally uncensored|locally-uncensored|\blu\b"),
    ("syncthing", "Syncthing", "🔄", (8384,), "/", r"syncthing"),
    ("nextcloud", "Nextcloud", "☁", (80, 443, 8443), "/", r"nextcloud"),
    ("portainer", "Portainer", "🐳", (9000, 9443), "/", r"portainer"),
    ("cockpit", "Cockpit", "🖥", (9090,), "/", r"cockpit"),
    ("webmin", "Webmin", "🖥", (10000,), "/", r"webmin"),
    ("proxmox", "Proxmox VE", "🖥", (8006,), "/", r"proxmox"),
    ("grafana", "Grafana", "📈", (3000,), "/login", r"grafana"),
    ("uptimekuma", "Uptime Kuma", "📈", (3001,), "/", r"uptime kuma"),
    ("nodered", "Node-RED", "🔧", (1880,), "/", r"node-red"),
    ("octoprint", "OctoPrint", "🖨", (5000, 80), "/", r"octoprint"),
    ("navidrome", "Navidrome", "🎵", (4533,), "/", r"navidrome"),
    ("audiobookshelf", "Audiobookshelf", "🎧", (13378,), "/", r"audiobookshelf"),
    ("immich", "Immich", "🖼", (2283,), "/", r"immich"),
    ("paperless", "Paperless-ngx", "📄", (8000,), "/", r"paperless"),
    ("calibreweb", "Calibre-Web", "📚", (8083,), "/", r"calibre"),
    ("homarr", "Homarr", "🧭", (7575,), "/", r"homarr"),
    ("synology", "Synology DSM", "💾", (5000, 5001), "/", r"synology|diskstation"),
]
MAX_LESEN = 64 * 1024
_TITEL = re.compile(r"<title[^>]*>([^<]{1,200})</title>", re.I)
DESKTOP_ORDNER = ("/usr/share/applications", "/usr/local/share/applications", "/var/lib/flatpak/exports/share/applications",
                  "~/.local/share/applications", "~/.local/share/flatpak/exports/share/applications")
MAX_DESKTOP = 300


def system():
    """Auf welchem System laeuft H0rSt? {"art": android|pi|linux|windows|mac|anderes, "name"}"""
    if os.environ.get("ANDROID_ROOT") or os.path.exists("/system/build.prop"):
        return {"art": "android", "name": "Android"}
    sys_name = platform.system()
    if sys_name == "Linux":
        try:
            with open("/proc/device-tree/model", "rb") as f:
                modell = f.read(200).decode("utf-8", "replace").strip("\x00 \n")
            if "raspberry" in modell.lower():
                return {"art": "pi", "name": modell}
        except OSError:
            pass
        return {"art": "linux", "name": "Linux"}
    if sys_name == "Windows":
        return {"art": "windows", "name": "Windows"}
    if sys_name == "Darwin":
        return {"art": "mac", "name": "macOS"}
    return {"art": "anderes", "name": sys_name or "?"}


def offene_ports(host, ports, zeitgrenze=0.6, verbinden=socket.create_connection):
    """Welche TCP-Ports antworten? (parallel, je Port hoechstens zeitgrenze Sekunden)"""
    offen, sperre = set(), threading.Lock()

    def klopfen(port):
        try:
            verbinden((host, port), zeitgrenze).close()
        except OSError:
            return
        with sperre:
            offen.add(port)

    faeden = [threading.Thread(target=klopfen, args=(p,), daemon=True) for p in sorted(set(ports))]
    for f in faeden:
        f.start()
    for f in faeden:
        f.join(zeitgrenze + 1.0)
    return offen


def _seite(url, holen, zeitgrenze):
    """(titel, text) der Startseite oder None; holen(url, zeitgrenze) -> (status, kopf-dict, bytes)."""
    try:
        status, kopf, inhalt = holen(url, zeitgrenze)
    except Exception:  # nicht erreichbar, kein HTTP, Zertifikat …: dann eben kein Programm
        return None
    text = (inhalt or b"")[:MAX_LESEN].decode("utf-8", "replace")
    titel = _TITEL.search(text)
    server = " ".join(str(v) for k, v in (kopf or {}).items() if k.lower() in ("server", "x-powered-by", "www-authenticate"))
    return (" ".join(titel.group(1).split()) if titel else ""), server + " " + text, status


def finden(host="127.0.0.1", holen=None, verbinden=socket.create_connection, programme=PROGRAMME, zeitgrenze=2.0):
    """Programme mit Weboberflaeche auf host: [{id, name, symbol, url, port, titel}].

    Unbekannte Weboberflaechen auf einem der Ports erscheinen als "Weboberfläche (Port N)" mit ihrem Seitentitel."""
    holen = holen or _holen
    ports = {p for _, _, _, pp, _, _ in programme for p in pp}
    offen = offene_ports(host, ports, verbinden=verbinden)
    name_host = "[%s]" % host if ":" in host else host
    gefunden, belegt, seiten = [], set(), {}
    for pid, name, symbol, pp, pfad, muster in programme:
        for port in pp:
            if port not in offen or port in belegt:
                continue
            schema = "https" if port in (443, 5001, 8006, 8443, 8920, 9443) else "http"
            url = "%s://%s:%d%s" % (schema, name_host, port, pfad)
            if url not in seiten:
                seiten[url] = _seite(url, holen, zeitgrenze)
            s = seiten[url]
            if s and re.search(muster, s[0] + " " + s[1], re.I):
                gefunden.append({"id": pid, "name": name, "symbol": symbol, "url": url, "port": port, "titel": s[0]})
                belegt.add(port)
                break
    for port in sorted(offen - belegt):  # offene Ports ohne bekanntes Programm: trotzdem anbieten, wenn HTTP antwortet
        for schema in ("http", "https"):
            url = "%s://%s:%d/" % (schema, name_host, port)
            s = seiten.get(url) or _seite(url, holen, zeitgrenze)
            if s and s[2] and int(s[2]) < 500:
                gefunden.append({"id": "port%d" % port, "name": s[0] or "Weboberfläche (Port %d)" % port, "symbol": "🌐",
                                 "url": url, "port": port, "titel": s[0]})
                break
    return gefunden


def _holen(url, zeitgrenze):
    """Startseite holen, auch bei 401 (Programme mit Anmeldung verraten sich trotzdem); selbst signiert ist ok."""
    import ssl
    import urllib.error
    import urllib.request
    kontext = ssl.create_default_context()
    kontext.check_hostname = False
    kontext.verify_mode = ssl.CERT_NONE  # nur fuer Geraete, die H0rSt selbst abklopft (lokal), nie fuer Inhalte
    anfrage = urllib.request.Request(url, headers={"User-Agent": "H0rSt-Portal", "Accept": "text/html"})
    try:
        with urllib.request.urlopen(anfrage, timeout=zeitgrenze, context=kontext) as a:
            return a.status, dict(a.headers), a.read(MAX_LESEN)
    except urllib.error.HTTPError as f:
        try:
            return f.code, dict(f.headers or {}), f.read(MAX_LESEN)
        finally:
            f.close()


# --- Desktop-Programme (Linux, Raspberry Pi) -------------------------------------------------------------------------
def _desktop_lesen(pfad):
    werte, abschnitt = {}, ""
    try:
        with open(pfad, encoding="utf-8", errors="replace") as f:
            for zeile in f:
                zeile = zeile.strip()
                if zeile.startswith("["):
                    abschnitt = zeile
                elif abschnitt == "[Desktop Entry]" and "=" in zeile and not zeile.startswith("#"):
                    k, w = zeile.split("=", 1)
                    werte.setdefault(k.strip(), w.strip())
    except OSError:
        return None
    if werte.get("Type") != "Application" or werte.get("NoDisplay") == "true" or werte.get("Hidden") == "true":
        return None
    if not werte.get("Name") or not werte.get("Exec") or werte.get("Terminal") == "true":
        return None
    return {"id": os.path.basename(pfad)[:-8][:80], "name": werte["Name"][:80], "text": werte.get("Comment", "")[:200],
            "symbol": werte.get("Icon", "")[:200], "kategorien": [k for k in werte.get("Categories", "").split(";") if k][:6]}


def desktop_programme(ordner=DESKTOP_ORDNER):
    """Installierte Desktop-Programme [{id, name, text, symbol, kategorien}], nach Namen sortiert, ohne Doppelte."""
    gefunden = {}
    for o in ordner:
        o = os.path.expanduser(o)
        try:
            namen = sorted(n for n in os.listdir(o) if n.endswith(".desktop"))
        except OSError:
            continue
        for n in namen:
            if len(gefunden) >= MAX_DESKTOP:
                break
            e = _desktop_lesen(os.path.join(o, n))
            if e and e["id"] not in gefunden:
                e["datei"] = os.path.join(o, n)
                gefunden[e["id"]] = e
    return sorted(gefunden.values(), key=lambda e: e["name"].lower())


def startbefehl(programm_id, ordner=DESKTOP_ORDNER):
    """Befehlszeile (Liste fuer subprocess, ohne Shell) eines gefundenen Desktop-Programms; ValueError, wenn unbekannt.

    Nur Programme aus desktop_programme(), nie eine frei eingegebene Befehlszeile."""
    e = next((x for x in desktop_programme(ordner) if x["id"] == programm_id), None)
    if not e:
        raise ValueError("Programm nicht gefunden")
    werte = {}
    with open(e["datei"], encoding="utf-8", errors="replace") as f:
        abschnitt = ""
        for zeile in f:
            zeile = zeile.strip()
            if zeile.startswith("["):
                abschnitt = zeile
            elif abschnitt == "[Desktop Entry]" and zeile.startswith("Exec="):
                werte.setdefault("Exec", zeile[5:])
    teile = [t for t in shlex.split(werte.get("Exec", "")) if not re.match(r"^%[a-zA-Z]$", t)]
    teile = [t.replace("%%", "%") for t in teile]
    if not teile:
        raise ValueError("Programm ohne Befehl")
    return teile
