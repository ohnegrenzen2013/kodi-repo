"""("_• )—* – Portal: Adressen pruefen, Geraete erkennen, MAC-Adressen finden und wecken.

  pruefen(url)           erreichbar? Status, Weiterleitungen, Titel, Symbol, Server, Zertifikat, Antwortzeit, Geraet –
                         und ob sich die Seite einbetten laesst (X-Frame-Options, CSP frame-ancestors)
  ports_abklopfen(host)  gaengige Web-Ports, wenn auf Port 80 niemand antwortet
  mac_zu_ip(mac)         IP zu einer MAC aus der ARP-Tabelle (vorher auf Wunsch das Heimnetz kurz anstossen)
  wecken(mac)            Wake-on-LAN (Magic Packet)
  erreichbar(urls)       schnelle Pruefung vieler Ziele (TCP-Verbindung), fuer den Waechter-Punkt in der Leiste
"""

import html
import ipaddress
import re
import shutil
import socket
import ssl
import subprocess
import threading
import time
import urllib.error
import urllib.request
from urllib.parse import urljoin, urlsplit

from .netz import USER_AGENT, _NichtFolgen
from .portal import PortalFehler, ist_lokal, mac_normal

from .portal_pruefen_web import *
from .portal_pruefen_web import _aufloesen, _kontext, _symbol, _titel, _zeichensatz, _zertifikat_fehler

WEB_PORTS = (80, 443, 8080, 8443, 8123, 8096, 8000, 8081, 8888, 5000, 5001, 3000, 9000, 9090, 32400, 8006, 7878, 8989,
             7860, 8188, 11435)
_SICHER = (443, 8443, 5001, 8006)
def ports_abklopfen(host, ports=None, zeitgrenze=0.8):
    """Offene TCP-Ports (gleichzeitig angefragt), in der Reihenfolge von ports (Standard: WEB_PORTS)."""
    ports = ports or WEB_PORTS
    offen = set()

    def klopfen(p):
        try:
            socket.create_connection((host, p), timeout=zeitgrenze).close()
            offen.add(p)
        except OSError:
            pass
    faeden = [threading.Thread(target=klopfen, args=(p,), daemon=True) for p in ports]
    for f in faeden:
        f.start()
    for f in faeden:
        f.join(zeitgrenze + 0.5)
    return [p for p in ports if p in offen]


def pruefen(url, unsicher_lokal=True, abklopfen=False, holen=abrufen):
    """Bericht zu einer Adresse. abklopfen: andere Web-Ports versuchen, wenn die Adresse schweigt (nur ohne festen Port)."""
    start = time.monotonic()
    b = {"ok": False, "eingang": url, "url": url, "kette": [], "status": 0, "titel": "", "symbol": "", "typ": "", "server": "",
         "einbettbar": False, "grund": "", "ms": 0, "tls": "", "geraet": None, "ip": "", "ports": [], "hinweise": [], "fehler": ""}
    host = urlsplit(url).hostname or ""
    lokal = ist_lokal(host)
    b["ip"] = _aufloesen(host)
    if b["ip"] and not lokal and ist_lokal(b["ip"]):
        b["hinweise"].append("Der Name zeigt ins Heimnetz (%s)" % b["ip"])
    status = kopf = inhalt = None
    for _ in range(7):
        unsicher = False
        try:
            try:
                status, kopf, inhalt = holen(url)
            except (urllib.error.URLError, OSError) as f:
                if not (url.startswith("https:") and _zertifikat_fehler(f)):
                    raise
                if not (lokal and unsicher_lokal):
                    b["fehler"] = "Das Zertifikat der Seite ist nicht vertrauenswürdig"
                    b["tls"] = "ungültig"
                    break
                status, kopf, inhalt = holen(url, unsicher=True)
                unsicher = True
        except (urllib.error.URLError, OSError, ValueError) as f:
            grund = getattr(f, "reason", f)
            b["fehler"] = "Keine Antwort (%s)" % (grund if isinstance(grund, str) else type(grund).__name__ + ": " + str(grund))[:200]
            break
        if url.startswith("https:"):
            b["tls"] = "selbst signiert" if unsicher else "gültig"
        ziel = kopf.get("location")
        if status in (301, 302, 303, 307, 308) and ziel:
            b["kette"].append({"status": status, "url": url})
            url = urljoin(url, ziel)
            if not url.startswith(("http://", "https://")):
                b["fehler"] = "Weiterleitung auf eine ungültige Adresse"
                break
            continue
        break
    else:
        b["fehler"] = "Zu viele Weiterleitungen"
    b["ms"] = int((time.monotonic() - start) * 1000)
    if status is None or b["fehler"]:
        if abklopfen and status is None and host:
            b["ports"] = ports_abklopfen(host)
            if b["ports"]:
                p = b["ports"][0]
                neu = "%s://%s%s/" % ("https" if p in _SICHER else "http", "[%s]" % host if ":" in host else host, "" if p in (80, 443) else ":%d" % p)
                if neu != b["eingang"]:
                    weiter = pruefen(neu, unsicher_lokal, False, holen)
                    weiter["ports"] = b["ports"]
                    weiter["hinweise"].insert(0, "Unter %s antwortet niemand – gefunden auf Port %d" % (b["eingang"], p))
                    weiter["eingang"] = b["eingang"]
                    return weiter
        return b
    text = inhalt.decode(_zeichensatz(kopf, inhalt), "replace")
    b["url"], b["status"] = url, status
    b["typ"] = (kopf.get("content-type") or "").split(";")[0].strip()[:80]
    b["server"] = (kopf.get("server") or kopf.get("x-powered-by") or "")[:80]
    b["einbettbar"], b["grund"] = einbettbar(kopf)
    if b["typ"] in ("text/html", "application/xhtml+xml", ""):
        b["titel"] = _titel(text)
        b["symbol"] = _symbol(text, url)
    b["geraet"] = geraet(b["titel"], b["server"], text if b["typ"].startswith("text/") else "")
    b["ok"] = status < 400 or status in (401, 403)
    if status == 401:
        b["hinweise"].append("Die Seite verlangt eine Anmeldung")
    elif status >= 400:
        b["hinweise"].append("Die Seite antwortet mit Fehler %d" % status)
    if b["tls"] == "selbst signiert":
        b["hinweise"].append("Selbst signiertes Zertifikat (im Heimnetz üblich) – der Browser fragt evtl. einmal nach")
    if url.startswith("http:") and not lokal:
        b["hinweise"].append("Unverschlüsselt (http) im Internet")
    if b["kette"]:
        b["hinweise"].append("%d× weitergeleitet" % len(b["kette"]))
    return b

# --- MAC-Adressen ----------------------------------------------------------------------------------------------------
def arp_tabelle(pfad="/proc/net/arp"):
    """{mac: ip} aus der ARP-Tabelle (Linux), sonst aus "ip neigh"; leer, wenn das System sie nicht zeigt (Android 10+)."""
    tabelle = {}
    try:
        with open(pfad, encoding="utf-8", errors="replace") as f:
            for zeile in f.read().splitlines()[1:]:
                teile = zeile.split()
                if len(teile) >= 4 and teile[2] != "0x0" and mac_normal(teile[3]) and teile[3] != "00:00:00:00:00:00":
                    tabelle[mac_normal(teile[3])] = teile[0]
    except OSError:
        pass
    if not tabelle and shutil.which("ip"):
        try:
            aus = subprocess.run(["ip", "neigh", "show"], capture_output=True, text=True, timeout=3).stdout
        except (OSError, subprocess.SubprocessError):
            aus = ""
        for m in re.finditer(r"^(\S+)\s.*?lladdr\s+([0-9a-f:]{17})", aus, re.I | re.M):
            tabelle.setdefault(mac_normal(m.group(2)), m.group(1))
    return tabelle


def eigene_ip():
    """IPv4 dieses Rechners im Heimnetz (ohne ein Paket zu senden) oder ''."""
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.connect(("192.0.2.1", 9))
            return s.getsockname()[0]
        finally:
            s.close()
    except OSError:
        return ""


def heimnetz_anstossen(warten=1.2):
    """Ein kleines UDP-Paket an jede Adresse des eigenen /24-Netzes: Geraete melden sich dabei in der ARP-Tabelle."""
    ip = eigene_ip()
    try:
        netz = ipaddress.ip_network(ip + "/24", strict=False)
    except ValueError:
        return 0
    if not netz.is_private:
        return 0
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    gesendet = 0
    try:
        for ziel in netz.hosts():
            try:
                s.sendto(b"", (str(ziel), 9))
                gesendet += 1
            except OSError:
                pass
    finally:
        s.close()
    time.sleep(warten)
    return gesendet


def mac_zu_ip(mac, anstossen=True, tabelle=arp_tabelle, stossen=heimnetz_anstossen):
    """IP zu einer MAC: (ip, hinweis). ip ist '', wenn das Geraet nicht zu finden ist."""
    mac = mac_normal(mac)
    if not mac:
        raise PortalFehler("Keine gültige MAC-Adresse")
    ip = tabelle().get(mac, "")
    if ip:
        return ip, "In der ARP-Tabelle gefunden"
    if anstossen and stossen():
        ip = tabelle().get(mac, "")
        if ip:
            return ip, "Nach dem Anstoßen des Heimnetzes gefunden"
    if not tabelle():
        return "", "Dieses System zeigt seine ARP-Tabelle nicht (z. B. Android ab Version 10) – gib die IP direkt ein"
    return "", "Kein Gerät mit dieser MAC im Heimnetz gefunden – ist es an? „Wecken“ schickt ein Wake-on-LAN-Paket"


def wecken(mac, ziele=("255.255.255.255",), port=9):
    """Wake-on-LAN: Magic Packet (6× FF, 16× MAC) an die Broadcast-Adressen; zusaetzlich ans eigene /24-Netz."""
    mac = mac_normal(mac)
    if not mac:
        raise PortalFehler("Keine gültige MAC-Adresse")
    paket = b"\xff" * 6 + bytes.fromhex(mac.replace(":", "")) * 16
    ziele = list(ziele)
    ip = eigene_ip()
    if ip:
        ziele.append(str(ipaddress.ip_network(ip + "/24", strict=False).broadcast_address))
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    gesendet = 0
    try:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_BROADCAST, 1)
        for ziel in dict.fromkeys(ziele):
            try:
                s.sendto(paket, (ziel, port))
                gesendet += 1
            except OSError:
                pass
    finally:
        s.close()
    if not gesendet:
        raise PortalFehler("Das Weck-Paket ließ sich nicht senden")
    return gesendet


def erreichbar(urls, zeitgrenze=1.5):
    """{url: True/False}: nimmt der Rechner hinter der Adresse eine TCP-Verbindung an?"""
    ergebnis = {}

    def probe(url):
        t = urlsplit(url)
        try:
            port = t.port or (443 if t.scheme == "https" else 80)
            socket.create_connection((t.hostname, port), timeout=zeitgrenze).close()
            ergebnis[url] = True
        except (OSError, ValueError, TypeError):
            ergebnis[url] = False
    faeden = [threading.Thread(target=probe, args=(u,), daemon=True) for u in dict.fromkeys(urls)]
    for f in faeden:
        f.start()
    for f in faeden:
        f.join(zeitgrenze + 0.5)
    return {u: ergebnis.get(u, False) for u in urls}
