"""Web-Erkennung des Portal-Pruefers: Abruf, Titel, Symbol, Einbettbarkeit und Geraetename."""

import html
import re
import socket
import ssl
import urllib.error
import urllib.request
from urllib.parse import urljoin

from .netz import USER_AGENT, _NichtFolgen

MAX_LESEN = 512 * 1024

# Titel, Server-Kopf oder Seite -> Geraet (Name, Symbol); die erste passende Zeile gewinnt
GERAETE = [
    (r"FRITZ!Box|fritz\.box|AVM", "FRITZ!Box", "📶"), (r"Home Assistant", "Home Assistant", "🏠"),
    (r"Jellyfin", "Jellyfin", "🎬"), (r"\bEmby\b", "Emby", "🎬"), (r"\bPlex\b", "Plex", "🎬"),
    (r"Pi-hole", "Pi-hole", "🕳"), (r"AdGuard Home", "AdGuard Home", "🛡"), (r"Synology|DiskStation|DSM", "Synology NAS", "🗄"),
    (r"QNAP|QTS", "QNAP NAS", "🗄"), (r"OpenWrt|LuCI", "OpenWrt", "📶"), (r"ASUSWRT|ASUS Wireless Router|router\.asus", "ASUS-Router", "📶"),
    (r"TP-?LINK|Archer", "TP-Link", "📶"), (r"UniFi|Ubiquiti", "UniFi", "📶"), (r"Speedport", "Speedport", "📶"),
    (r"Vodafone Station|EasyBox", "Vodafone-Router", "📶"), (r"Proxmox", "Proxmox", "🖥"), (r"Portainer", "Portainer", "🐳"),
    (r"Nextcloud", "Nextcloud", "☁"), (r"ownCloud", "ownCloud", "☁"), (r"OctoPrint", "OctoPrint", "🖨"),
    (r"Grafana", "Grafana", "📈"), (r"Node-RED", "Node-RED", "🔀"), (r"Tasmota", "Tasmota", "🔌"), (r"Shelly", "Shelly", "🔌"),
    (r"ESPHome", "ESPHome", "🔌"), (r"OpenWebif|Enigma2|Dreambox", "Enigma2-Receiver", "📺"), (r"\bKodi\b", "Kodi", "📺"),
    (r"Sonarr", "Sonarr", "📺"), (r"Radarr", "Radarr", "🎬"), (r"Prowlarr", "Prowlarr", "🔎"), (r"qBittorrent", "qBittorrent", "⬇"),
    (r"Transmission", "Transmission", "⬇"), (r"SABnzbd", "SABnzbd", "⬇"), (r"NZBGet", "NZBGet", "⬇"),
    (r"Philips hue|hue personal wireless", "Philips Hue", "💡"), (r"Hikvision|Dahua|IP ?Camera|webcam", "IP-Kamera", "📷"),
    (r"CUPS|Printer|Drucker|EPSON|Brother|HP LaserJet|OfficeJet", "Drucker", "🖨"), (r"Vaultwarden|Bitwarden", "Vaultwarden", "🔑"),
    (r"Uptime Kuma", "Uptime Kuma", "⏱"), (r"Paperless", "Paperless", "📄"), (r"Immich", "Immich", "🖼"), (r"Gitea|Forgejo", "Gitea", "🌿"),
    (r"H0rSt|m0dulh0st|Rezeptserver", "H0rSt", "𓂀"), (r"nginx", "nginx", "⚙"), (r"Apache", "Apache", "⚙"),
]


def _kontext(unsicher):
    if not unsicher:
        return ssl.create_default_context()
    k = ssl.create_default_context()
    k.check_hostname = False
    k.verify_mode = ssl.CERT_NONE
    return k


def abrufen(url, unsicher=False, zeitgrenze=8.0, methode="GET"):
    """Eine Anfrage ohne Weiterleitungen zu folgen: (status, kopf {klein: wert}, inhalt bis MAX_LESEN)."""
    oeffner = urllib.request.build_opener(_NichtFolgen, urllib.request.HTTPSHandler(context=_kontext(unsicher)))
    anfrage = urllib.request.Request(url, method=methode, headers={
        "User-Agent": USER_AGENT + " (Portal)", "Accept": "text/html,application/xhtml+xml,*/*;q=0.8", "Accept-Encoding": "identity"})
    try:
        with oeffner.open(anfrage, timeout=zeitgrenze) as a:
            return a.status, {k.lower(): v for k, v in a.headers.items()}, a.read(MAX_LESEN)
    except urllib.error.HTTPError as f:
        try:
            return f.code, {k.lower(): v for k, v in (f.headers or {}).items()}, f.read(MAX_LESEN)
        finally:
            f.close()


def _zertifikat_fehler(f):
    grund = getattr(f, "reason", f)
    return isinstance(grund, ssl.SSLCertVerificationError) or isinstance(f, ssl.SSLCertVerificationError) or \
        "CERTIFICATE_VERIFY_FAILED" in str(f)


def einbettbar(kopf):
    """(True/False, Grund) nach X-Frame-Options und CSP frame-ancestors."""
    xfo = (kopf.get("x-frame-options") or "").strip().lower()
    if xfo in ("deny", "sameorigin") or xfo.startswith("allow-from"):
        return False, "Die Seite verbietet das Einbetten (X-Frame-Options: %s)" % xfo.upper()
    csp = kopf.get("content-security-policy") or ""
    m = re.search(r"frame-ancestors\s+([^;]*)", csp, re.I)
    if m and "*" not in m.group(1).split():
        return False, "Die Seite erlaubt das Einbetten nur bei sich selbst (frame-ancestors %s)" % m.group(1).strip()[:80]
    return True, ""


def geraet(titel, server, text):
    probe = " ".join((titel or "", server or "", (text or "")[:20000]))
    for muster, name, symbol in GERAETE:
        if re.search(muster, probe, re.I):
            return {"name": name, "symbol": symbol}
    return None


def _titel(text):
    m = re.search(r"<title[^>]*>(.*?)</title>", text, re.I | re.S)
    return " ".join(html.unescape(m.group(1)).split())[:120] if m else ""


def _symbol(text, url):
    for m in re.finditer(r"<link\b[^>]*>", text[:200000], re.I):
        tag = m.group(0)
        rel = re.search(r"rel\s*=\s*[\"']?([^\"'>]+)", tag, re.I)
        href = re.search(r"href\s*=\s*[\"']([^\"']+)", tag, re.I)
        if rel and href and "icon" in rel.group(1).lower():
            ziel = urljoin(url, html.unescape(href.group(1).strip()))
            if ziel.startswith(("http://", "https://")):
                return ziel[:1000]
    return urljoin(url, "/favicon.ico")


def _aufloesen(host):
    try:
        return socket.getaddrinfo(host, None)[0][4][0]
    except (OSError, UnicodeError, IndexError):
        return ""


def _zeichensatz(kopf, inhalt):
    m = re.search(r"charset=([\w-]+)", kopf.get("content-type") or "", re.I) or \
        re.search(rb"<meta[^>]+charset=[\"']?([\w-]+)", inhalt[:4096], re.I)
    name = m.group(1) if m else "utf-8"
    name = name.decode("ascii", "replace") if isinstance(name, bytes) else name
    try:
        "".encode(name)
        return name
    except LookupError:
        return "utf-8"

