"""Eigene Poster je Titel und Profil (Idee aus Nuvios „Custom Posters“, selbst gebaut, kein Code uebernommen).

Statt des Posters aus Cinemeta/TMDb zeigt H0rSt fuer einen Titel ein Bild, dessen Adresse der Nutzer selbst eintraegt
(z. B. ein Poster von einer Poster-Seite oder aus dem eigenen Netz). Der Server speichert nur die Adresse - er laedt das
Bild nie selbst (kein Zugriff aufs Heimnetz durch Fremde), der Browser holt es wie jedes andere Bild.

Erlaubt sind http(s)-Adressen ohne Leerraum und Steuerzeichen, hoechstens MAX_URL Zeichen lang, ohne Zugangsdaten in der Adresse.
Titel-Kennungen: IMDb (tt123), tmdb:123, kitsu:1 usw. - Buchstaben, Ziffern und : _ . - (hoechstens 60 Zeichen).
Nutzerdaten "eigene_poster": {profil-id oder "": {titel-id: adresse}}; mehr als MAX_POSTER je Profil: aelteste fallen weg.
"""

import re
from urllib.parse import urlsplit

SCHLUESSEL = "eigene_poster"
MAX_POSTER = 500
MAX_URL = 500
_KENNUNG = re.compile(r"^[A-Za-z0-9:_.-]{1,60}$")


class PosterFehler(ValueError):
    pass


def adresse_pruefen(text):
    """Die Adresse, wenn sie ein brauchbarer http(s)-Link ist, sonst PosterFehler."""
    roh = str(text or "").strip()
    if not roh:
        raise PosterFehler("Adresse fehlt")
    if len(roh) > MAX_URL:
        raise PosterFehler("Adresse zu lang (höchstens %d Zeichen)" % MAX_URL)
    if re.search(r"[\s\x00-\x1f\x7f]", roh):
        raise PosterFehler("Adresse darf keinen Leerraum enthalten")
    try:
        u = urlsplit(roh)
        host = u.hostname
        u.port  # noqa: B018 - wirft bei kaputtem Port
    except ValueError:
        raise PosterFehler("Das ist keine gültige Adresse") from None
    if u.scheme not in ("http", "https") or not host:
        raise PosterFehler("Nur http(s)-Adressen sind erlaubt")
    if u.username or u.password:
        raise PosterFehler("Adressen mit Benutzer und Passwort sind nicht erlaubt")
    return roh


def kennung_pruefen(titel_id):
    t = str(titel_id or "")
    if not _KENNUNG.match(t):
        raise PosterFehler("Ungültige Titel-Kennung")
    return t


def lesen(daten, profil_id=""):
    """{titel-id: adresse} dieses Profils; kaputte Eintraege fallen weg."""
    alle = daten.get(SCHLUESSEL) if isinstance(daten, dict) and isinstance(daten.get(SCHLUESSEL), dict) else {}
    roh = alle.get(profil_id or "") if isinstance(alle.get(profil_id or ""), dict) else {}
    ergebnis = {}
    for k, v in roh.items():
        try:
            ergebnis[kennung_pruefen(k)] = adresse_pruefen(v)
        except PosterFehler:
            continue
    return ergebnis


def _speichern(daten, profil_id, eintraege):
    alle = daten.get(SCHLUESSEL) if isinstance(daten.get(SCHLUESSEL), dict) else {}
    alle[profil_id or ""] = eintraege
    daten[SCHLUESSEL] = alle
    return eintraege


def setzen(daten, profil_id, titel_id, adresse):
    tid, url = kennung_pruefen(titel_id), adresse_pruefen(adresse)
    e = lesen(daten, profil_id)
    e.pop(tid, None)  # neu eingetragen = jetzt der juengste
    e[tid] = url
    while len(e) > MAX_POSTER:
        e.pop(next(iter(e)))
    return _speichern(daten, profil_id, e)


def weg(daten, profil_id, titel_id):
    e = lesen(daten, profil_id)
    e.pop(kennung_pruefen(titel_id), None)
    return _speichern(daten, profil_id, e)
