"""Profile mit Rechten: mehrere Menschen in einem H0rSt – jeder mit eigener Ansicht, die Rechte vergibt der Admin.

  * Profil: Name, Farbe, optional PIN, Rolle (Admin, Mitglied, Gast), dazu einzelne Rechte mehr oder weniger,
    Gruppen und – wenn gewuenscht – nur bestimmte Bereiche (Reiter). Die Oberflaechen-Einstellungen (Darstellung,
    Ansichten, Anzahl je Reiter, Tasten, Brett …) gelten je Profil.
  * Das erste Profil wird Admin. Solange es keine Profile gibt, darf jeder alles (wie bisher).
  * Neue Mitglieder: per Einladung (Code oder Link, Rolle und Gruppen vorgegeben, befristet, begrenzte Nutzungen) oder
    per Beitrittsanfrage, die ein Admin zulaesst oder ablehnt. Der Admin legt fest, ob Anfragen erlaubt sind.
  * Anmelden: Profil waehlen (mit PIN, wenn gesetzt) -> Sitzungsschluessel (Header X-Profil). Gespeichert wird nur
    ein Hash des Schluessels, 60 Tage gueltig.
  * Grenzen je Profil (Admin-Panel, nutzung.py): sperren, Traffic pro Tag/Monat, Anfragen pro Minute, Verbindungen,
    Online-Zeit, Upload-Groesse. Fuer Admins gelten keine Grenzen.

Nutzerdaten "profile": {"liste": [...], "gruppen": [...], "einladungen": [...], "anfragen": [...], "beitritt": "einladung",
"sitzungen": {hash: {"profil", "bis"}}}
"""

import hashlib
import hmac
import secrets
import time

from .altersfreigabe import GRENZEN_WAHL
from .profile_grund import *
from .profile_grund import (_ID, _admins, _gruppen, _name, _neue_id, _oeffentlich, _pin_hash, _pin_ok,
                            _pin_pruefen, _profil)


# --- Sitzungen -------------------------------------------------------------------------------------
def _schluessel_hash(token):
    return hashlib.sha256(str(token or "").encode()).hexdigest()


def sitzung_neu(p, pid, uhr):
    token = secrets.token_urlsafe(24)
    jetzt = uhr()
    p["sitzungen"] = {h: s for h, s in p["sitzungen"].items() if s.get("bis", 0) > jetzt}
    if len(p["sitzungen"]) >= MAX_SITZUNGEN:
        aelteste = sorted(p["sitzungen"].items(), key=lambda kv: kv[1].get("bis", 0))[:len(p["sitzungen"]) - MAX_SITZUNGEN + 1]
        for h, _ in aelteste:
            del p["sitzungen"][h]
    p["sitzungen"][_schluessel_hash(token)] = {"profil": pid, "bis": int(jetzt + SITZUNG_TAGE * 86400)}
    return token


def profil_zu(daten, token, uhr=time.time):
    """Sitzungsschluessel -> Profil (oder None)."""
    if not token or not aktiv(daten):
        return None
    p = daten[SCHLUESSEL]
    s = (p.get("sitzungen") or {}).get(_schluessel_hash(token))
    if not s or s.get("bis", 0) < uhr():
        return None
    return next((x for x in p["liste"] if x["id"] == s.get("profil")), None)


# --- Eltern-PIN und Kinderprofile -------------------------------------------------------------------
def eltern_pin_ok(daten, pin):
    """Stimmt die Eltern-PIN? Ohne gesetzte Eltern-PIN ist nichts freigegeben (nie 'leer = erlaubt')."""
    gespeichert = ((daten or {}).get(SCHLUESSEL) or {}).get("eltern_pin")
    return bool(gespeichert) and bool(str(pin or "").strip()) and _pin_ok(gespeichert, str(pin).strip())


def eltern_pin_setzen(daten, wer, neu, alt=None):
    """Eltern-PIN festlegen oder aendern (nur Profile mit dem Recht "profile"; eine vorhandene PIN braucht die alte)."""
    p = daten_von(daten)
    if not darf(daten, wer, "profile"):
        raise KeinRecht("Die Eltern-PIN legt ein Admin fest")
    neu = _pin_pruefen(neu)
    if not neu:
        raise ProfilFehler("PIN: 4 bis 12 Ziffern")
    if p.get("eltern_pin") and not eltern_pin_ok(daten, alt):
        raise KeinRecht("Die bisherige Eltern-PIN fehlt oder stimmt nicht")
    p["eltern_pin"] = _pin_hash(neu)


def _eltern_pin_verlangen(daten, w):
    if not eltern_pin_ok(daten, (w or {}).get("eltern_pin")):
        raise KeinRecht("Dafür ist die Eltern-PIN nötig – sie fehlt oder stimmt nicht")


def _kind_alter(roh):
    if isinstance(roh, bool) or roh not in GRENZEN_WAHL:
        raise ProfilFehler("Altersgrenze: %s" % ", ".join(str(g) for g in GRENZEN_WAHL))
    return int(roh)


def _kind_pruefen(p, rolle, kind):
    if kind and rolle == "admin":
        raise ProfilFehler("Ein Admin kann kein Kinderprofil sein – erst die Rolle ändern")
    if kind and not p.get("eltern_pin"):
        raise ProfilFehler("Erst eine Eltern-PIN festlegen")


# --- Ansicht ---------------------------------------------------------------------------------------
def zustand(daten, profil):
    p = (daten or {}).get(SCHLUESSEL) or {}
    liste = p.get("liste") or []
    antwort = {"aktiv": bool(liste), "profile": [_oeffentlich(x) for x in liste], "beitritt": p.get("beitritt", "einladung"),
               "ich": dict(_oeffentlich(profil), bereiche=list(KIND_BEREICHE) if profil.get("kind") else list(profil.get("bereiche") or [])) if profil else None,
               "eltern_pin": bool(p.get("eltern_pin")),
               "rechte": sorted(rechte(profil)) if liste else sorted(RECHTE), "rollen": ROLLEN, "rechte_namen": RECHTE,
               "beitritt_arten": BEITRITT, "gruppen": [dict(g) for g in p.get("gruppen") or []]}
    if not liste or "profile" in rechte(profil):
        antwort["verwaltung"] = {
            "profile": [dict(_oeffentlich(x), rechte_dazu=x.get("rechte_dazu") or [], rechte_weg=x.get("rechte_weg") or [],
                             bereiche=x.get("bereiche") or [], rechte=sorted(rechte(x)), grenzen=x.get("grenzen") or {}) for x in liste],
            "einladungen": [dict(e) for e in p.get("einladungen") or []],
            "anfragen": [dict(a) for a in p.get("anfragen") or []]}
    return antwort


# --- Aenderungen (jede bekommt daten, das handelnde Profil und die Wuensche) ------------------------------
def anlegen(daten, wer, w, uhr=time.time):
    """Neues Profil. Das erste darf jeder anlegen (wird Admin), weitere nur mit Recht "profile"."""
    p = daten_von(daten)
    erstes = not p["liste"]
    if not erstes and not darf(daten, wer, "profile"):
        raise KeinRecht("Neue Profile legt ein Admin an – oder per Einladung")
    if len(p["liste"]) >= MAX_PROFILE:
        raise ProfilFehler("Höchstens %d Profile" % MAX_PROFILE)
    name = _name(w.get("name"))
    if any(x["name"].lower() == name.lower() for x in p["liste"]):
        raise ProfilFehler("Den Namen gibt es schon")
    pin = _pin_pruefen(w.get("pin"))
    rolle = "admin" if erstes else (w.get("rolle") if w.get("rolle") in ROLLEN else "mitglied")
    kind = w.get("kind") is True
    _kind_pruefen(p, rolle, kind)
    kind_alter = _kind_alter(w.get("kind_alter", 12)) if kind else None
    x = {"id": _neue_id(p, name), "name": name, "rolle": rolle, "farbe": FARBEN[len(p["liste"]) % len(FARBEN)],
         "pin": _pin_hash(pin) if pin else "", "gruppen": _gruppen(p, w.get("gruppen")), "bereiche": [], "rechte_dazu": [],
         "rechte_weg": [], "einstellungen": {}, "erstellt": int(uhr()), "geaendert": int(uhr())}
    if kind:
        x["kind"], x["kind_alter"] = True, kind_alter
    p["liste"].append(x)
    return x


class PinFalsch(KeinRecht):
    pass


def anmelden(daten, pid, pin, uhr=time.time):
    p = daten_von(daten)
    x = _profil(p, pid)
    if (x.get("grenzen") or {}).get("gesperrt") and x["rolle"] != "admin":
        raise KeinRecht("%s ist gesperrt – frag deinen Admin" % x["name"])
    if not _pin_ok(x.get("pin"), str(pin or "")):
        raise PinFalsch("PIN stimmt nicht")
    return x, sitzung_neu(p, x["id"], uhr)


def abmelden(daten, token):
    p = daten_von(daten)
    p["sitzungen"].pop(_schluessel_hash(token), None)


def aendern(daten, wer, pid, w, uhr=time.time):
    """Eigenes Profil: Name, Farbe, PIN. Mit Recht "profile" auch Rolle, Rechte, Gruppen und Bereiche anderer."""
    p = daten_von(daten)
    x = _profil(p, pid)
    admin = darf(daten, wer, "profile")
    selbst = wer is not None and wer["id"] == pid
    if not (admin or selbst):
        raise KeinRecht("Fremde Profile ändert nur ein Admin")
    if x.get("kind") and KIND_GESICHERT & set(w):
        if not admin:  # ein Kind aendert an sich nichts Gesichertes - auch nicht mit PIN
            raise KeinRecht("Das ändert ein Elternteil")
        _eltern_pin_verlangen(daten, w)
    if "name" in w:
        name = _name(w["name"])
        if any(y["name"].lower() == name.lower() and y["id"] != pid for y in p["liste"]):
            raise ProfilFehler("Den Namen gibt es schon")
        x["name"] = name
    if "farbe" in w and w["farbe"] in FARBEN:
        x["farbe"] = w["farbe"]
    if "pin" in w:
        if selbst and x.get("pin") and not _pin_ok(x["pin"], str(w.get("pin_alt") or "")) and not admin:
            raise KeinRecht("Bisherige PIN stimmt nicht")
        pin = _pin_pruefen(w["pin"])
        x["pin"] = _pin_hash(pin) if pin else ""
    verwaltend = {"rolle", "rechte_dazu", "rechte_weg", "gruppen", "bereiche", "grenzen", "kind", "kind_alter"} & set(w)
    if verwaltend and not admin:
        raise KeinRecht("Rollen und Rechte vergibt ein Admin")
    if "rolle" in w:
        if w["rolle"] not in ROLLEN:
            raise ProfilFehler("Unbekannte Rolle")
        if x["rolle"] == "admin" and w["rolle"] != "admin" and len(_admins(p)) == 1:
            raise ProfilFehler("Der letzte Admin bleibt Admin")
        x["rolle"] = w["rolle"]
    if "kind" in w or "kind_alter" in w or (x.get("kind") and "rolle" in w):
        kind = (w["kind"] is True) if "kind" in w else bool(x.get("kind"))
        _kind_pruefen(p, x["rolle"], kind)
        if kind:
            x["kind"], x["kind_alter"] = True, _kind_alter(w.get("kind_alter", x.get("kind_alter", 12)))
        else:
            x.pop("kind", None)
            x.pop("kind_alter", None)
    for feld in ("rechte_dazu", "rechte_weg"):
        if feld in w:
            x[feld] = [r for r in (w[feld] or []) if r in RECHTE] if isinstance(w[feld], list) else []
    if "gruppen" in w:
        x["gruppen"] = _gruppen(p, w["gruppen"])
    if "bereiche" in w:
        x["bereiche"] = [str(b)[:40] for b in (w["bereiche"] or [])][:60] if isinstance(w["bereiche"], list) else []
    if "grenzen" in w:
        from .nutzung import pruefe_grenzen
        try:
            x["grenzen"] = pruefe_grenzen(dict(x.get("grenzen") or {}, **(w["grenzen"] if isinstance(w["grenzen"], dict) else {})))
        except ValueError as fehler:
            raise ProfilFehler(str(fehler))
        if x["grenzen"]["gesperrt"] and x["rolle"] == "admin":
            raise ProfilFehler("Admins lassen sich nicht sperren – erst die Rolle ändern")
        if x["grenzen"]["gesperrt"]:  # sofort abmelden
            p["sitzungen"] = {h: s for h, s in p["sitzungen"].items() if s.get("profil") != pid}
    x["geaendert"] = int(uhr())
    return x


def loeschen(daten, wer, pid, eltern_pin=None):
    p = daten_von(daten)
    x = _profil(p, pid)
    if not darf(daten, wer, "profile") and not (wer and wer["id"] == pid):
        raise KeinRecht("Profile löscht ein Admin")
    if x.get("kind"):
        _eltern_pin_verlangen(daten, {"eltern_pin": eltern_pin})
    if x["rolle"] == "admin" and len(_admins(p)) == 1 and len(p["liste"]) > 1:
        raise ProfilFehler("Erst einen anderen Admin bestimmen")
    p["liste"].remove(x)
    p["sitzungen"] = {h: s for h, s in p["sitzungen"].items() if s.get("profil") != pid}


def gruppen_aendern(daten, wer, w):
    if not darf(daten, wer, "profile"):
        raise KeinRecht("Gruppen verwaltet ein Admin")
    p = daten_von(daten)
    if w.get("gruppe_dazu"):
        if len(p["gruppen"]) >= MAX_GRUPPEN:
            raise ProfilFehler("Höchstens %d Gruppen" % MAX_GRUPPEN)
        name = _name(w["gruppe_dazu"], "Gruppenname")
        gid = _ID.sub("", name.lower())[:16] or "gruppe"
        while any(g["id"] == gid for g in p["gruppen"]):
            gid += "x"
        p["gruppen"].append({"id": gid, "name": name})
    if w.get("gruppe_weg"):
        p["gruppen"] = [g for g in p["gruppen"] if g["id"] != w["gruppe_weg"]]
        for x in p["liste"]:
            x["gruppen"] = [g for g in x.get("gruppen") or [] if g != w["gruppe_weg"]]
    if w.get("beitritt") in BEITRITT:
        p["beitritt"] = w["beitritt"]


# --- Einladungen und Anfragen ------------------------------------------------------------------------
def einladung_neu(daten, wer, w, uhr=time.time):
    if not darf(daten, wer, "profile"):
        raise KeinRecht("Einladungen verschickt ein Admin")
    p = daten_von(daten)
    p["einladungen"] = [e for e in p["einladungen"] if e["bis"] > uhr() and e["benutzt"] < e["max"]]
    if len(p["einladungen"]) >= MAX_EINLADUNGEN:
        raise ProfilFehler("Zu viele offene Einladungen")
    try:
        tage, anzahl = max(1, min(90, int(w.get("tage") or 7))), max(1, min(20, int(w.get("max") or 1)))
    except (TypeError, ValueError):
        raise ProfilFehler("Tage und Anzahl als Zahl")
    rolle = w.get("rolle") if w.get("rolle") in ("mitglied", "gast") or (w.get("rolle") == "admin" and wer and wer.get("rolle") == "admin") else "mitglied"
    e = {"code": secrets.token_urlsafe(8).replace("-", "x").replace("_", "y")[:10].upper(), "rolle": rolle,
         "gruppen": _gruppen(p, w.get("gruppen")), "bis": int(uhr() + tage * 86400), "max": anzahl, "benutzt": 0,
         "von": wer["name"] if wer else "", "notiz": " ".join(str(w.get("notiz") or "").split())[:60]}
    p["einladungen"].append(e)
    return e


def einladung_weg(daten, wer, code):
    if not darf(daten, wer, "profile"):
        raise KeinRecht("Einladungen verwaltet ein Admin")
    p = daten_von(daten)
    p["einladungen"] = [e for e in p["einladungen"] if e["code"] != code]


def einladung_einloesen(daten, code, w, uhr=time.time):
    p = daten_von(daten)
    e = next((e for e in p["einladungen"] if hmac.compare_digest(e["code"].encode("utf-8"), str(code or "").strip().upper().encode("utf-8"))), None)
    if not e or e["bis"] < uhr() or e["benutzt"] >= e["max"]:
        raise KeinRecht("Einladung ungültig oder abgelaufen")
    admin = next(iter(_admins(p)), None)
    x = anlegen(daten, admin, {"name": w.get("name"), "pin": w.get("pin"), "rolle": e["rolle"], "gruppen": e["gruppen"]}, uhr)
    e["benutzt"] += 1
    return x, sitzung_neu(p, x["id"], uhr)


def anfrage(daten, w, uhr=time.time):
    p = daten_von(daten)
    if p["beitritt"] != "anfrage":
        raise KeinRecht("Neue Mitglieder nur mit Einladung")
    if len(p["anfragen"]) >= MAX_ANFRAGEN:
        raise ProfilFehler("Gerade zu viele offene Anfragen")
    name = _name(w.get("name"))
    pin = _pin_pruefen(w.get("pin"))
    a = {"id": secrets.token_hex(4), "name": name, "nachricht": " ".join(str(w.get("nachricht") or "").split())[:200],
         "zeit": int(uhr()), "pin": _pin_hash(pin) if pin else ""}
    p["anfragen"].append(a)
    return {"id": a["id"], "name": name}


def anfrage_entscheiden(daten, wer, aid, ja, rolle="mitglied", gruppen=None, uhr=time.time):
    if not darf(daten, wer, "profile"):
        raise KeinRecht("Anfragen entscheidet ein Admin")
    p = daten_von(daten)
    a = next((a for a in p["anfragen"] if a["id"] == aid), None)
    if not a:
        raise ProfilFehler("Anfrage nicht (mehr) da")
    p["anfragen"].remove(a)
    if not ja:
        return None
    x = anlegen(daten, wer, {"name": a["name"], "rolle": rolle if rolle in ("mitglied", "gast", "admin") else "mitglied", "gruppen": gruppen}, uhr)
    x["pin"] = a.get("pin", "")
    return x


# --- Einstellungen je Profil -----------------------------------------------------------------------------
def eigene_einstellungen(profil):
    return dict((profil or {}).get("einstellungen") or {})
