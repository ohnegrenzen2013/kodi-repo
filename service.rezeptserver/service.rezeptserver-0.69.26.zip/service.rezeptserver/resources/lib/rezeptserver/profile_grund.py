"""Profile: Konstanten, Rechte und gemeinsame Pruefungen."""

import hashlib
import hmac
import re
import secrets

SCHLUESSEL = "profile"
ROLLEN = {"admin": "Admin", "mitglied": "Mitglied", "gast": "Gast"}
RECHTE = {
    "profile": "Profile, Rechte und Einladungen verwalten",
    "einstellungen": "Gemeinsame Einstellungen (Sprachen, Medienserver, Telegram, Kataloge …)",
    "anbieter": "Anbieter, Addons und Zugänge verwalten",
    "sicherheit": "Sicherheit: VPN, Netzweg, IP-Filter, afwall, Tor & I2P",
    "downloads": "Downloader, Ember und P2P-Listen steuern",
    "dateien": "Dateien ansehen, verschieben und löschen",
    "speicher": "Ablage und externe Speicher wählen",
    "ab18": "Ab 18 nutzen",
    "party": "Party-Spiele mitmachen (Karaoke, Synchron)",
    "aktualisierung": "Aktualisieren, Sichern und Wiederherstellen",
}
ROLLEN_RECHTE = {"admin": set(RECHTE), "mitglied": {"downloads", "dateien", "party"}, "gast": {"party"}}
BEITRITT = {"einladung": "Nur mit Einladung", "anfrage": "Anfragen erlaubt (Admin lässt zu)", "zu": "Niemand Neues"}
FARBEN = ("#00d588", "#3d9bff", "#a77bff", "#ff5fa8", "#ff9d3d", "#ffd23d", "#ff5a5a", "#2fd2d2")
MAX_PROFILE, MAX_GRUPPEN, MAX_EINLADUNGEN, MAX_ANFRAGEN, MAX_SITZUNGEN = 30, 20, 30, 30, 200
SITZUNG_TAGE = 60
# Kinderprofile (ARVIO 2.3): kein einziges Recht, nur diese Reiter; Aenderungen an Kind-Markierung, PIN, Rolle und Rechten
# eines Kinderprofils (und sein Loeschen) verlangen die Eltern-PIN
KIND_BEREICHE = ("filme", "serien")
KIND_GESICHERT = {"kind", "kind_alter", "pin", "rolle", "rechte_dazu", "rechte_weg", "bereiche", "grenzen"}
_ID = re.compile(r"[^a-z0-9]")


class ProfilFehler(ValueError):
    pass


class KeinRecht(ProfilFehler):
    pass


# --- Grundlagen ---------------------------------------------------------------------------------
def _name(roh, art="Name"):
    name = " ".join(str(roh or "").split())[:30]
    if not name:
        raise ProfilFehler("%s fehlt" % art)
    return name


def _pin_hash(pin, salz=None):
    salz = salz or secrets.token_hex(8)
    return "pbkdf2$%s$%s" % (salz, hashlib.pbkdf2_hmac("sha256", str(pin).encode(), salz.encode(), 120000).hex())


def _pin_ok(gespeichert, pin):
    if not gespeichert:
        return True
    try:
        _, salz, _ = gespeichert.split("$")
    except ValueError:
        return False
    return hmac.compare_digest(_pin_hash(pin, salz), gespeichert)


def _pin_pruefen(pin):
    pin = str(pin or "").strip()
    if pin and not re.match(r"^\d{4,12}$", pin):
        raise ProfilFehler("PIN: 4 bis 12 Ziffern")
    return pin


def daten_von(daten):
    p = daten.get(SCHLUESSEL) if isinstance(daten.get(SCHLUESSEL), dict) else {}
    p.setdefault("liste", [])
    p.setdefault("gruppen", [])
    p.setdefault("einladungen", [])
    p.setdefault("anfragen", [])
    p.setdefault("sitzungen", {})
    if p.get("beitritt") not in BEITRITT:
        p["beitritt"] = "einladung"
    daten[SCHLUESSEL] = p
    return p


def aktiv(daten):
    """Gibt es Profile? Ohne Profile gilt alles wie bisher (jeder darf alles)."""
    return bool(((daten or {}).get(SCHLUESSEL) or {}).get("liste"))


def rechte(profil):
    """Wirksame Rechte eines Profils (Rolle plus/minus einzelne Rechte)."""
    if profil is None:
        return set(ROLLEN_RECHTE["gast"])
    if profil.get("kind"):
        return set()
    r = set(ROLLEN_RECHTE.get(profil.get("rolle"), set()))
    r |= set(profil.get("rechte_dazu") or [])
    if profil.get("rolle") != "admin":
        r -= set(profil.get("rechte_weg") or [])
    return r & set(RECHTE)


def darf(daten, profil, recht):
    return not aktiv(daten) or recht in rechte(profil)


def _neue_id(p, name):
    basis = _ID.sub("", name.lower())[:12] or "profil"
    pid, n = basis, 2
    while any(x["id"] == pid for x in p["liste"]):
        pid, n = "%s%d" % (basis, n), n + 1
    return pid


def _profil(p, pid):
    x = next((x for x in p["liste"] if x["id"] == pid), None)
    if not x:
        raise ProfilFehler("Profil nicht gefunden")
    return x


def _oeffentlich(x):
    return {"id": x["id"], "name": x["name"], "rolle": x["rolle"], "rolle_name": ROLLEN[x["rolle"]], "farbe": x.get("farbe", FARBEN[0]),
            "pin": bool(x.get("pin")), "gruppen": list(x.get("gruppen") or []), "gesperrt": bool((x.get("grenzen") or {}).get("gesperrt")),
            "kind": bool(x.get("kind")), "kind_alter": x.get("kind_alter") if x.get("kind") else None}


def _admins(p):
    return [x for x in p["liste"] if x["rolle"] == "admin"]


def _gruppen(p, roh):
    ids = {g["id"] for g in p["gruppen"]}
    return [g for g in (roh or []) if g in ids] if isinstance(roh, list) else []
