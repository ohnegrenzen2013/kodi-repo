"""Pruefungen: ruff, JavaScript-Syntax und die Testsuite als Gate vor jedem automatischen Commit.

Dieselben drei Schritte wie in CLAUDE.md und .github/workflows/tests.yml fuer Menschen/CI beschrieben,
hier aber programmatisch per subprocess aufrufbar und strukturiert auswertbar (fuer vorschlag_anwenden.py).
Kein Schritt bricht die anderen ab - alle Ergebnisse zaehlen, damit ein Fehlschlag in der Oberflaeche
vollstaendig erklaert werden kann statt nur "etwas ist schiefgegangen".
"""

import subprocess
import sys

MAX_AUSGABE = 8000  # wie fehlerliste.MAX_DETAILS: eine riesige ruff-Ausgabe soll nicht alles sprengen

# sys.executable statt "python": auf Alpine (H0rSt-OS, Docker-Alternative) gibt es nur python3.
SCHRITTE = (
    ("ruff", ["ruff", "check", "."]),
    ("javascript", [sys.executable, "tools/js_pruefen.py"]),
    ("tests", [sys.executable, "-m", "unittest", "discover", "-s", "tests", "-t", "."]),
)


def _schritt(name, befehl, wurzel, zeitlimit):
    try:
        ergebnis = subprocess.run(befehl, cwd=wurzel, capture_output=True, text=True, timeout=zeitlimit)
        ausgabe = (ergebnis.stdout or "") + (ergebnis.stderr or "")
        return {"name": name, "ok": ergebnis.returncode == 0, "befehl": " ".join(befehl),
                "ausgabe": ausgabe[:MAX_AUSGABE]}
    except subprocess.TimeoutExpired:
        return {"name": name, "ok": False, "befehl": " ".join(befehl),
                "ausgabe": "Zeitlimit (%ds) ueberschritten" % zeitlimit}
    except (OSError, FileNotFoundError) as fehler:
        return {"name": name, "ok": False, "befehl": " ".join(befehl), "ausgabe": str(fehler)}


def pruefen(wurzel=None, zeitlimit=300):
    """Fuehrt alle SCHRITTE aus, egal ob einer fehlschlaegt. Gibt {"ok": bool, "schritte": [...]} zurueck,
    "ok" ist True nur wenn jeder Schritt erfolgreich war."""
    schritte = [_schritt(name, befehl, wurzel, zeitlimit) for name, befehl in SCHRITTE]
    return {"ok": all(s["ok"] for s in schritte), "schritte": schritte}
