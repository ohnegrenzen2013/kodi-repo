"""Qwen-Image 2.1 Pose Studio: ComfyUI-Auftraege mit optionalem NSFW-LoRA.

Die Regeln (Einstellungen, Wunsch, Workflow) stehen in qwen_pose_grund.py, der
ComfyUI-Client und die Warteschlange hier. Vorbild ist Arekejoker/qwen21-nsfw-pose-skill
(Apache-2.0); Modelle, LoRAs, Beispielbilder und explizite Prompts bleiben extern.
"""

import json
import os
import re
import threading
import time
import uuid
from urllib.parse import urlencode

from .netz import antwort_holen, antwort_holen_roh
from .qwen_pose_grund import (MAX_BILD, MAX_JOBS, MAX_LAUF, STUFEN, QwenFehler, STANDARD,
                              _graph, _wahl, pruefe, wunsch_pruefen, zustand)

__all__ = ["MAX_BILD", "MAX_JOBS", "MAX_LAUF", "QwenFehler", "QwenPose", "STANDARD", "STUFEN",
           "_graph", "pruefe", "zustand"]


class QwenPose:
    def __init__(self, datenordner, holen=None, roh=None):
        self.ordner = os.path.join(datenordner or ".", "qwen_pose")
        self.holen = holen or antwort_holen
        self.roh = roh or antwort_holen_roh
        self.jobs = {}
        self._sperre = threading.Lock()

    def _json(self, werte, pfad, daten=None, zeit=30):
        url = werte["qwen_url"] + pfad
        kopf = {"Content-Type": "application/json"} if daten is not None else {}
        try:
            status, text = self.holen(url, "POST" if daten is not None else "GET", kopf,
                                      json.dumps(daten) if daten is not None else None, zeitgrenze=zeit)
        except Exception as fehler:  # noqa: BLE001
            raise QwenFehler("ComfyUI nicht erreichbar: %s" % fehler)
        if status != 200:
            raise QwenFehler("ComfyUI: HTTP %s %s" % (status, str(text or "")[:200]))
        try:
            return json.loads(text) if text else {}
        except ValueError:
            raise QwenFehler("ComfyUI: keine JSON-Antwort")

    def doctor(self, werte):
        w = pruefe(werte)
        if not w["qwen_an"]:
            raise QwenFehler("Qwen Pose Studio ist ausgeschaltet")
        stats = self._json(w, "/system_stats", zeit=10)
        queue = self._json(w, "/queue", zeit=10)
        modelle = {}
        for name, schluessel in (("UNETLoader", "unet_name"), ("CLIPLoader", "clip_name"), ("VAELoader", "vae_name")):
            try:
                info = self._json(w, "/object_info/" + name, zeit=10)
                felder = ((info.get(name) or {}).get("input") or {}).get("required") or {}
                werte_liste = (felder.get(schluessel) or [[]])[0]
                modelle[schluessel] = [str(x) for x in werte_liste] if isinstance(werte_liste, list) else []
            except QwenFehler:
                modelle[schluessel] = []
        return {"ok": True, "stats": stats, "queue": queue, "modelle": modelle,
                "comfyui": bool(stats), "hinweis": "LoRAs stehen in ComfyUI unter models/loras."}

    def posen(self, werte, stufe="L0"):
        w = pruefe(werte)
        try:
            d = self._json(w, "/vnccs/pose_library/list", zeit=10)
            roh = d.get("poses") if isinstance(d, dict) else d
            liste = []
            for eintrag in roh or []:
                if isinstance(eintrag, dict):
                    liste.append({"name": str(eintrag.get("name") or eintrag.get("id") or eintrag.get("file") or ""),
                                  "gruppe": str(eintrag.get("category") or eintrag.get("group") or "")})
                elif isinstance(eintrag, str):
                    liste.append({"name": eintrag, "gruppe": ""})
            if liste:
                return {"quelle": "vnccs", "posen": liste[:500]}
        except QwenFehler:
            pass
        stufe = _wahl(stufe, tuple(STUFEN), "L0")
        return {"quelle": "eingebaut", "posen": [{"name": p, "gruppe": STUFEN[stufe][0]} for p in STUFEN[stufe][1]]}

    def _upload(self, werte, bild):
        boundary = "----H0rSt" + uuid.uuid4().hex
        kopf = {"Content-Type": "multipart/form-data; boundary=" + boundary}
        dateiname, mime = ("h0rst.jpg", "image/jpeg") if bild[:3] == b"\xff\xd8\xff" else ("h0rst.png", "image/png")
        body = (("--%s\r\nContent-Disposition: form-data; name=\"image\"; filename=\"%s\"\r\n"
                 "Content-Type: %s\r\n\r\n" % (boundary, dateiname, mime)).encode("ascii") + bild +
                ("\r\n--%s--\r\n" % boundary).encode("ascii"))
        try:
            status, text = self.roh(werte["qwen_url"] + "/upload/image", "POST", kopf, body,
                                    zeitgrenze=120, grenze=MAX_BILD + 1024)
        except Exception as fehler:  # noqa: BLE001
            raise QwenFehler("Bild-Upload: %s" % fehler)
        if status != 200:
            raise QwenFehler("Bild-Upload: HTTP %s" % status)
        try:
            d = json.loads(text)
        except (TypeError, ValueError):
            raise QwenFehler("Bild-Upload: keine JSON-Antwort")
        name = str(d.get("name") or "")
        if not name:
            raise QwenFehler("Bild-Upload: kein Dateiname")
        sub = str(d.get("subfolder") or "")
        return (sub + "/" if sub else "") + name

    def _ansehen(self, werte, bild):
        if not isinstance(bild, dict):
            raise QwenFehler("ComfyUI liefert kein Bild")
        query = urlencode({"filename": str(bild.get("filename") or ""), "subfolder": str(bild.get("subfolder") or ""),
                           "type": str(bild.get("type") or "output")})
        try:
            status, daten = self.roh(werte["qwen_url"] + "/view?" + query, "GET", {}, None,
                                     zeitgrenze=120, grenze=MAX_BILD)
        except Exception as fehler:  # noqa: BLE001
            raise QwenFehler("Bild holen: %s" % fehler)
        if status != 200 or not daten:
            raise QwenFehler("Bild holen: HTTP %s" % status)
        return daten

    def _speichern(self, daten, speichern=None):
        if callable(speichern):
            return speichern(daten)
        os.makedirs(self.ordner, exist_ok=True)
        name = time.strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:6] + ".png"
        with open(os.path.join(self.ordner, name), "wb") as f:
            f.write(daten)
        bilder = sorted(n for n in os.listdir(self.ordner) if re.match(r"^[\w.-]+\.png$", n))
        for alt in bilder[:-500]:
            try:
                os.remove(os.path.join(self.ordner, alt))
            except OSError:
                pass
        return name

    def _lauf(self, job, werte, wunsch, speichern):
        try:
            bild_name = self._upload(werte, wunsch["bild"]) if wunsch["modus"] == "edit" else None
            for nummer in range(wunsch["anzahl"]):
                seed = wunsch["seed"] if wunsch["seed"] >= 0 else int(time.time() * 1000) % (2 ** 32)
                seed = (seed + nummer * 7919) % (2 ** 32)
                d = self._json(werte, "/prompt", {"prompt": _graph(werte, wunsch, seed, bild_name), "client_id": job["id"]})
                pid = str(d.get("prompt_id") or "")
                if not pid:
                    raise QwenFehler("ComfyUI: keine prompt_id")
                job["prompt_id"] = pid
                for _ in range(MAX_LAUF):
                    if job.get("abbrechen"):
                        raise QwenFehler("abgebrochen")
                    h = self._json(werte, "/history/" + pid, zeit=10)
                    eintrag = h.get(pid) if isinstance(h, dict) else None
                    if eintrag:
                        if str((eintrag.get("status") or {}).get("status_str") or "").lower() == "error":
                            raise QwenFehler("ComfyUI: Auftrag fehlgeschlagen")
                        bilder = []
                        for ausgabe in (eintrag.get("outputs") or {}).values():
                            if isinstance(ausgabe, dict):
                                bilder.extend(ausgabe.get("images") or [])
                        if bilder:
                            daten = self._ansehen(werte, bilder[0])
                            job["bilder"].append(self._speichern(daten, speichern))
                            job["fortschritt"] = int((nummer + 1) * 100 / wunsch["anzahl"])
                            break
                    time.sleep(1)
                else:
                    raise QwenFehler("ComfyUI: Zeitüberschreitung")
            job["status"] = "fertig"
        except Exception as fehler:  # noqa: BLE001 – ein Auftrag darf den Server nicht reissen
            job["status"] = "fehler"
            job["fehler"] = str(fehler)[:300]
        finally:
            job["ende"] = int(time.time())

    def start(self, werte, wunsch, speichern=None):
        w = pruefe(werte)
        if not w["qwen_an"]:
            raise QwenFehler("Qwen Pose Studio ist ausgeschaltet")
        p = wunsch_pruefen(wunsch, w)
        with self._sperre:
            laufend = [j for j in self.jobs.values() if j["status"] in ("wartet", "laeuft")]
            if len(laufend) >= 2:
                raise QwenFehler("Es laufen schon zwei Auftraege")
            job = {"id": uuid.uuid4().hex[:12], "status": "wartet", "fortschritt": 0, "bilder": [],
                   "fehler": "", "prompt_id": "", "zeit": int(time.time()), "ende": 0,
                   "modus": p["modus"], "nsfw": p["nsfw"], "prompt": p["prompt"][:200],
                   "seed": p["seed"], "stufe": p["stufe"], "pose": p["pose"]}
            self.jobs[job["id"]] = job
            for alt in sorted(self.jobs.values(), key=lambda j: j["zeit"])[:-MAX_JOBS]:
                self.jobs.pop(alt["id"], None)
        job["status"] = "laeuft"
        threading.Thread(target=self._lauf, args=(job, w, p, speichern), name="qwen-" + job["id"], daemon=True).start()
        return self.job(job["id"])

    def job(self, job_id):
        with self._sperre:
            job = self.jobs.get(str(job_id))
            return dict(job) if job else None

    def liste(self):
        with self._sperre:
            return [dict(j) for j in sorted(self.jobs.values(), key=lambda j: j["zeit"], reverse=True)]

    def abbrechen(self, job_id):
        with self._sperre:
            job = self.jobs.get(str(job_id))
        if not job:
            raise QwenFehler("Unbekannter Auftrag")
        job["abbrechen"] = True
        return dict(job)

    def bild(self, name):
        if not re.match(r"^[\w.-]+\.(png|jpg)$", str(name or "")):
            raise QwenFehler("Unbekanntes Bild")
        pfad = os.path.join(self.ordner, name)
        if not os.path.isfile(pfad):
            raise QwenFehler("Bild nicht da")
        return pfad
