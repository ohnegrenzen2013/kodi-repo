"""Qwen-Image 2.1 Pose Studio: ComfyUI-Auftraege mit optionalem NSFW-LoRA.

Vorbild ist Arekejoker/qwen21-nsfw-pose-skill (Apache-2.0): T2I/Edit-Workflows fuer
Qwen-Image 2.1, Pose-Stufen L0-L3 und die VNCCS-Pose-Bibliothek. H0rSt uebernimmt
nur die Workflow-Struktur und die Bedienung; Modelle, LoRAs, Beispielbilder und
explizite Prompts bleiben im ComfyUI bzw. beim Nutzer. Ohne Freigabe ab 18 und
ohne eingeschalteten Schalter wird kein NSFW-LoRA verwendet.
"""

import base64
import re
from urllib.parse import urlsplit

SCHLUESSEL = "qwen_pose"
MAX_JOBS = 30
MAX_BILD = 30 * 1024 * 1024
MAX_LAUF = 900
STANDARD = {
    "qwen_an": False, "qwen_url": "http://127.0.0.1:8188",
    "qwen_unet": "qwen_image_2.1_int8_convrot.safetensors",
    "qwen_clip": "qwen3vl_8b_int8_convrot.safetensors",
    "qwen_vae": "qwen_image_2.1_vae_bf16.safetensors",
    "qwen_lora": "", "qwen_lora_staerke": "1.0", "qwen_schritte": "40", "qwen_cfg": "2.5",
    "qwen_sampler": "euler", "qwen_scheduler": "simple", "qwen_breite": "1152", "qwen_hoehe": "1728",
    "qwen_seed": "-1", "qwen_negativ": "worst quality, low quality, blurry, watermark, text",
    "qwen_stufe": "L0", "qwen_pose": "", "qwen_nsfw_an": False, "qwen_anzahl": "1",
}
SAMPLER = ("euler", "er_sde", "dpmpp_2m", "dpmpp_2m_sde", "euler_ancestral", "lcm")
SCHEDULER = ("simple", "beta", "normal", "karras", "sgm_uniform")
GROESSEN = ("1024x1024", "1152x1728", "832x1216", "1216x832", "1344x768")
STUFEN = {
    "L0": ("Geschlossen", ["standing, weight on one leg, hand in pocket", "seated, legs crossed at the ankles",
                           "leaning on a railing, looking back", "walking, natural stride"]),
    "L1": ("Offen", ["crouching with knees apart, hands on the floor", "sitting on the floor, knees to one side",
                     "lying on the side, propped on an elbow", "kneeling, hands behind the back"]),
    "L2": ("Kuehn", ["standing with legs apart, low angle", "lying prone, hips lifted toward the camera",
                     "sitting wide, leaning forward on the elbows", "kneeling on one knee, other leg extended"]),
    "L3": ("Extrem/Crop", ["extreme low angle looking up", "overhead shot lying flat",
                           "cropped framing, waist-up", "cropped framing, mid-thigh"]),
}


class QwenFehler(ValueError):
    pass


def _text(wert, laenge):
    return " ".join(str(wert or "").split())[:laenge]


def _zahl(wert, standard, klein, gross):
    try:
        zahl = int(float(str(wert).replace(",", ".")))
        if zahl < 0 and standard < 0:
            return standard
        return max(klein, min(gross, zahl))
    except (TypeError, ValueError, OverflowError):
        return standard


def _wahl(wert, erlaubt, standard):
    wert = str(wert or "").strip().lower()
    return wert if wert in erlaubt else standard


def _adresse(wert):
    url = str(wert or "").strip().rstrip("/")
    if re.match(r"^[A-Za-z][A-Za-z0-9+.-]*://", url) and not re.match(r"^https?://", url, re.I):
        raise QwenFehler("ComfyUI-Adresse muss http:// oder https:// sein")
    if not re.match(r"^https?://", url, re.I):
        url = "http://" + url
    try:
        teile = urlsplit(url)
    except ValueError:
        raise QwenFehler("ComfyUI-Adresse ungueltig")
    if teile.scheme not in ("http", "https") or not teile.hostname:
        raise QwenFehler("ComfyUI-Adresse wie http://127.0.0.1:8188 erwartet")
    return url[:300]


def pruefe(roh):
    roh = roh if isinstance(roh, dict) else {}
    breite = _zahl(roh.get("qwen_breite"), 1152, 512, 2048)
    hoehe = _zahl(roh.get("qwen_hoehe"), 1728, 512, 2048)
    return {
        "qwen_an": roh.get("qwen_an") is True,
        "qwen_url": _adresse(roh.get("qwen_url") or STANDARD["qwen_url"]),
        "qwen_unet": _text(roh.get("qwen_unet") or STANDARD["qwen_unet"], 200),
        "qwen_clip": _text(roh.get("qwen_clip") or STANDARD["qwen_clip"], 200),
        "qwen_vae": _text(roh.get("qwen_vae") or STANDARD["qwen_vae"], 200),
        "qwen_lora": _text(roh.get("qwen_lora"), 200),
        "qwen_lora_staerke": _wahl(roh.get("qwen_lora_staerke"), ("0.6", "0.8", "1.0"), "1.0"),
        "qwen_schritte": str(_zahl(roh.get("qwen_schritte"), 40, 1, 150)),
        "qwen_cfg": _wahl(roh.get("qwen_cfg"), ("1.0", "2.5", "4.0"), "2.5"),
        "qwen_sampler": _wahl(roh.get("qwen_sampler"), SAMPLER, "euler"),
        "qwen_scheduler": _wahl(roh.get("qwen_scheduler"), SCHEDULER, "simple"),
        "qwen_breite": str(breite),
        "qwen_hoehe": str(hoehe),
        "qwen_seed": str(_zahl(roh.get("qwen_seed"), -1, -1, 2 ** 32 - 1)),
        "qwen_negativ": _text(roh.get("qwen_negativ") or STANDARD["qwen_negativ"], 1000),
        "qwen_stufe": _wahl(roh.get("qwen_stufe"), tuple(STUFEN), "L0"),
        "qwen_pose": _text(roh.get("qwen_pose"), 500),
        "qwen_nsfw_an": roh.get("qwen_nsfw_an") is True,
        "qwen_anzahl": str(_zahl(roh.get("qwen_anzahl"), 1, 1, 4)),
    }


def zustand(werte):
    w = pruefe(werte)
    return {"an": w["qwen_an"], "url": w["qwen_url"], "unet": w["qwen_unet"], "clip": w["qwen_clip"],
            "vae": w["qwen_vae"], "lora": w["qwen_lora"], "lora_staerke": w["qwen_lora_staerke"],
            "schritte": w["qwen_schritte"], "cfg": w["qwen_cfg"], "sampler": w["qwen_sampler"],
            "scheduler": w["qwen_scheduler"], "breite": w["qwen_breite"], "hoehe": w["qwen_hoehe"],
            "seed": w["qwen_seed"], "negativ": w["qwen_negativ"], "stufe": w["qwen_stufe"],
            "pose": w["qwen_pose"], "nsfw_an": w["qwen_nsfw_an"], "anzahl": w["qwen_anzahl"],
            "sampler_liste": list(SAMPLER), "scheduler_liste": list(SCHEDULER), "groessen": list(GROESSEN),
            "stufen": [{"id": k, "name": v[0], "posen": v[1]} for k, v in STUFEN.items()],
            "hinweis": "Modelle, LoRAs und die VNCCS-Pose-Bibliothek bleiben in ComfyUI. "
                       "NSFW-LoRAs nur nach Freigabe ab 18; H0rSt liefert keine Beispielbilder mit."}


def _bild_b64(wert):
    text = str(wert or "")
    if not text:
        return b""
    text = text.split(",", 1)[-1] if text.startswith("data:") else text
    if len(text) > MAX_BILD or not re.match(r"^[A-Za-z0-9+/=\s]+$", text[:200]):
        raise QwenFehler("Bild als Base64 (PNG/JPEG) erwartet")
    try:
        return base64.b64decode(text)
    except (ValueError, TypeError):
        raise QwenFehler("Bild-Base64 ist kaputt")


def wunsch_pruefen(roh, werte):
    if not isinstance(roh, dict):
        raise QwenFehler("JSON-Objekt erwartet")
    w = pruefe(werte)
    prompt = str(roh.get("prompt") or "").strip()[:4000]
    if not prompt:
        raise QwenFehler("Prompt fehlt")
    modus = "edit" if roh.get("modus") == "edit" else "t2i"
    bild = _bild_b64(roh.get("bild")) if modus == "edit" else b""
    if modus == "edit" and not bild:
        raise QwenFehler("Edit braucht ein Bild")
    nsfw = roh.get("nsfw") is True
    if nsfw and not w["qwen_nsfw_an"]:
        raise QwenFehler("NSFW ist in den Qwen-Einstellungen nicht freigegeben")
    return {"prompt": prompt, "negativ": _text(roh.get("negativ") or w["qwen_negativ"], 1000),
            "modus": modus, "bild": bild, "nsfw": nsfw, "seed": _zahl(roh.get("seed"), int(w["qwen_seed"]), -1, 2 ** 32 - 1),
            "pose": _text(roh.get("pose"), 500), "stufe": _wahl(roh.get("stufe"), tuple(STUFEN), w["qwen_stufe"]),
            "anzahl": _zahl(roh.get("anzahl"), int(w["qwen_anzahl"]), 1, 4)}


def _graph(werte, wunsch, seed, bild_name=None):
    lora = werte["qwen_lora"] if (wunsch["nsfw"] and werte["qwen_lora"]) else ""
    g = {
        "1": {"class_type": "UNETLoader", "inputs": {"unet_name": werte["qwen_unet"], "weight_dtype": "default"}},
        "2": {"class_type": "CLIPLoader", "inputs": {"clip_name": werte["qwen_clip"], "type": "qwen_image"}},
        "3": {"class_type": "VAELoader", "inputs": {"vae_name": werte["qwen_vae"]}},
        "8": {"class_type": "SaveImage", "inputs": {"images": ["7", 0], "filename_prefix": "h0rst-qwen21"}},
    }
    if lora:
        g["99"] = {"class_type": "LoraLoaderModelOnly", "inputs": {
            "model": ["1", 0], "lora_name": lora, "strength_model": float(werte["qwen_lora_staerke"])}}
        modell = ["99", 0]
    else:
        modell = ["1", 0]
    if bild_name:
        g["4"] = {"class_type": "LoadImage", "inputs": {"image": bild_name}}
        g["5"] = {"class_type": "TextEncodeQwenImage21", "inputs": {
            "clip": ["2", 0], "prompt": wunsch["prompt"], "negative_prompt": wunsch["negativ"],
            "resolution": 1024, "images.image_1": ["4", 0], "vae": ["3", 0]}}
        pos, neg, latent = ["5", 0], ["5", 1], ["5", 2]
    else:
        g["4"] = {"class_type": "TextEncodeQwenImage21", "inputs": {
            "clip": ["2", 0], "prompt": wunsch["prompt"], "negative_prompt": wunsch["negativ"],
            "resolution": 1024, "vae": ["3", 0]}}
        g["5"] = {"class_type": "EmptyLatentImage", "inputs": {
            "width": int(werte["qwen_breite"]), "height": int(werte["qwen_hoehe"]), "batch_size": 1}}
        pos, neg, latent = ["4", 0], ["4", 1], ["5", 0]
    g["6"] = {"class_type": "KSampler", "inputs": {
        "model": modell, "positive": pos, "negative": neg, "latent_image": latent, "seed": seed,
        "steps": int(werte["qwen_schritte"]), "cfg": float(werte["qwen_cfg"]),
        "sampler_name": werte["qwen_sampler"], "scheduler": werte["qwen_scheduler"], "denoise": 1.0}}
    g["7"] = {"class_type": "VAEDecode", "inputs": {"samples": ["6", 0], "vae": ["3", 0]}}
    return g

