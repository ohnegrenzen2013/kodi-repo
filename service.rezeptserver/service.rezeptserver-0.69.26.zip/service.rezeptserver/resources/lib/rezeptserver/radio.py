"""Radio: Internetradio aus dem freien Verzeichnis radio-browser.info (ueber 50.000 Sender, ohne Konto).

  * Suchen nach Name, Genre (Tag) und Land; "Beliebt" nach Klicks oder Stimmen; nur Sender, die zuletzt liefen
  * Favoriten in den Nutzerdaten ("radio": {"favoriten": [...]}), als Senderliste /radio.m3u fuer Kodi und
    IPTV-Apps, ueber Fernseher & Geraete (Chromecast, DLNA, Roku, Dreambox) und per Telegram/Sprache (/radio swr3)
  * Abspielen im Browser direkt; auf einer HTTPS-Seite laufen http://-Sender ueber H0rSt (/api/radio/strom), aber
    nur Sender, die H0rSt selbst geliefert hat – kein offener Proxy

Die API verteilt sich auf mehrere Server; die Liste kommt von all.api.radio-browser.info, mit Ersatz.
"""

import json
import random
import threading
import time
import urllib.error
import urllib.request
from urllib.parse import urlencode, urlsplit

from . import __version__

SCHLUESSEL = "radio"
SERVER_LISTE = "https://all.api.radio-browser.info/json/servers"
ERSATZ = ["de1.api.radio-browser.info", "de2.api.radio-browser.info", "fi1.api.radio-browser.info"]
MAX_FAVORITEN = 200
MAX_TREFFER = 100
MERKEN = 300  # Sekunden: gleiche Abfrage aus dem Zwischenspeicher
GENRES = [("pop", "Pop"), ("rock", "Rock"), ("news", "Nachrichten"), ("classical", "Klassik"), ("jazz", "Jazz"),
          ("electronic", "Elektro"), ("schlager", "Schlager"), ("hip hop", "Hip-Hop"), ("chillout", "Chillout"),
          ("80s", "80er"), ("oldies", "Oldies"), ("metal", "Metal"), ("country", "Country"), ("kids", "Kinder")]


class RadioFehler(ValueError):
    pass


def _holen_json(url, zeit=10):
    anfrage = urllib.request.Request(url, headers={"User-Agent": "H0rSt/%s" % __version__})
    try:
        with urllib.request.urlopen(anfrage, timeout=zeit) as a:
            return json.loads(a.read(4 * 1024 * 1024).decode("utf-8"))
    except urllib.error.HTTPError as fehler:
        fehler.close()
        raise RadioFehler("Radio-Verzeichnis: HTTP %d" % fehler.code)
    except (urllib.error.URLError, OSError, ValueError) as fehler:
        raise RadioFehler("Radio-Verzeichnis nicht erreichbar: %s" % getattr(fehler, "reason", fehler))


def _web(url):
    url = str(url or "").strip()
    return url if urlsplit(url).scheme in ("http", "https") and urlsplit(url).hostname else ""


def sender(roh):
    """Eintrag des Verzeichnisses -> {"id", "name", "url", "bild", "tags", "land", "codec", "bitrate", "hls", "seite"}."""
    if not isinstance(roh, dict):
        return None
    url = _web(roh.get("url_resolved")) or _web(roh.get("url"))
    sid = str(roh.get("stationuuid") or roh.get("id") or "")[:64]
    name = " ".join(str(roh.get("name") or "").split())[:80]
    if not (url and sid and name):
        return None
    tags = roh.get("tags") or []
    if isinstance(tags, str):
        tags = [t.strip() for t in tags.split(",")]
    try:
        bitrate = int(roh.get("bitrate") or 0)
    except (TypeError, ValueError):
        bitrate = 0
    return {"id": sid, "name": name, "url": url, "bild": _web(roh.get("favicon") or roh.get("bild")),
            "tags": [str(t)[:24] for t in tags if t][:5], "land": str(roh.get("countrycode") or roh.get("land") or "")[:2].upper(),
            "codec": str(roh.get("codec") or "")[:12], "bitrate": bitrate, "hls": bool(roh.get("hls")),
            "seite": _web(roh.get("homepage") or roh.get("seite"))}


# Codec des Senders -> Inhaltstyp. radio-browser schreibt Codecs sehr verschieden ("AAC+", "aacp", "HE-AAC",
# "MP3,H.264" bei Sendern mit Bild); gezaehlt wird der Ton-Codec vor dem Komma. Unbekannt bleibt MP3, das kann jeder.
CODEC_MIME = {"MP3": "audio/mpeg", "MPEG": "audio/mpeg", "MP2": "audio/mpeg", "MPA": "audio/mpeg",
              "AAC": "audio/aac", "AAC+": "audio/aac", "AACP": "audio/aac", "HE-AAC": "audio/aac", "HEAAC": "audio/aac",
              "AAC-LC": "audio/aac", "XHE-AAC": "audio/aac", "M4A": "audio/mp4", "MP4": "audio/mp4", "ALAC": "audio/mp4",
              "OGG": "audio/ogg", "VORBIS": "audio/ogg", "OPUS": "audio/ogg", "FLAC": "audio/flac",
              "WMA": "audio/x-ms-wma", "WAV": "audio/wav", "PCM": "audio/wav", "WEBM": "audio/webm",
              "AC3": "audio/ac3", "EAC3": "audio/eac3", "E-AC3": "audio/eac3"}


def mime(s):
    """Inhaltstyp fuer Cast/DLNA aus dem Codec des Senders."""
    if s.get("hls") or str(s.get("codec") or "").upper().strip() == "HLS":
        return "application/x-mpegURL"
    codec = str(s.get("codec") or "").upper().split(",")[0].replace(" ", "")
    return CODEC_MIME.get(codec, "audio/mpeg")


def pruefe_favoriten(roh):
    roh = roh or []
    if not isinstance(roh, list):
        raise RadioFehler("Favoriten als Liste")
    ergebnis, ids = [], set()
    for eintrag in roh[:MAX_FAVORITEN]:
        s = sender(eintrag)
        if s and s["id"] not in ids:
            ids.add(s["id"])
            ergebnis.append(s)
    return ergebnis


def m3u(favoriten):
    zeilen = ["#EXTM3U"]
    for s in favoriten:
        logo = ' tvg-logo="%s"' % s["bild"].replace('"', "") if s.get("bild") else ""
        zeilen += ['#EXTINF:-1 radio="true"%s group-title="Radio",%s' % (logo, s["name"].replace(",", " ")), s["url"]]
    return "\n".join(zeilen) + "\n"


class Radio:
    def __init__(self, holen=None, uhr=time.time):
        self.holen = holen or _holen_json
        self.uhr = uhr
        self._server = None
        self._kaputt = set()  # Server, die zuletzt nicht antworteten
        self._merker = {}
        self._bekannt = {}  # id -> Sender (aus Suchen und Favoriten), fuer /api/radio/strom
        self._sperre = threading.Lock()

    def _server_waehlen(self, neu=False):
        if self._server and not neu:
            return self._server
        if neu and self._server:
            self._kaputt.add(self._server)
        try:
            namen = sorted({str(s.get("name")) for s in self.holen(SERVER_LISTE, 5) if s.get("name")})
        except (RadioFehler, AttributeError, TypeError):
            namen = []
        heile = [n for n in namen if n not in self._kaputt] or [n for n in ERSATZ if n not in self._kaputt] or ERSATZ
        self._server = random.choice(heile)
        return self._server

    def _abfrage(self, pfad, werte):
        schluessel = pfad + "?" + urlencode(sorted(werte.items()))
        with self._sperre:
            treffer = self._merker.get(schluessel)
            if treffer and self.uhr() - treffer[0] < MERKEN:
                return treffer[1]
        fehler = None
        for versuch in range(3):
            server = self._server_waehlen(neu=versuch > 0)
            try:
                daten = self.holen("https://%s/json/%s?%s" % (server, pfad, urlencode(werte)), 10)
                break
            except RadioFehler as f:
                fehler = f
        else:
            raise fehler
        with self._sperre:
            if len(self._merker) > 200:
                self._merker.clear()
            self._merker[schluessel] = (self.uhr(), daten)
        return daten

    def merken(self, liste):
        with self._sperre:
            for s in liste:
                self._bekannt[s["id"]] = s
            if len(self._bekannt) > 5000:
                self._bekannt = {s["id"]: s for s in liste}
        return liste

    def bekannt(self, sid):
        return self._bekannt.get(str(sid or ""))

    def suchen(self, text="", tag="", land="", sortierung="clickcount", anzahl=60, versatz=0):
        werte = {"hidebroken": "true", "order": sortierung if sortierung in ("clickcount", "votes", "name", "bitrate") else "clickcount",
                 "reverse": "false" if sortierung == "name" else "true", "limit": max(1, min(MAX_TREFFER, int(anzahl))),
                 "offset": max(0, int(versatz))}
        text, tag, land = " ".join(str(text or "").split())[:80], str(tag or "").strip().lower()[:40], str(land or "").strip().upper()[:2]
        if text:
            werte["name"] = text
        if tag:
            werte["tag"] = tag
            werte["tagExact"] = "false"
        if land:
            werte["countrycode"] = land
        roh = self._abfrage("stations/search", werte)
        return self.merken([s for s in (sender(x) for x in roh or []) if s])
