"""Release-Kalender der eigenen Bibliothek.

Merkliste, Weiterschauen und Verlauf eines Profils werden ueber die IMDb-Kennung
gegen TMDb aufgeloest. Serien liefern die naechste ausstrahlende Folge
(next_episode_to_air), Filme die deutschen Kinostart-/Digital-/Disc-Termine
(release_dates). Es werden keine Termine erfunden: ohne TMDb-Schluessel bleibt
der Kalender leer und nennt den Grund.
"""

from datetime import date, timedelta

from . import sehen, tmdb

MAX_TITEL = 40
ARTEN = {1: "Premiere", 2: "Kino", 3: "Kino", 4: "Digital", 5: "Disc", 6: "TV"}


def _tag(wert):
    text = str(wert or "")[:10]
    try:
        return date(int(text[:4]), int(text[5:7]), int(text[8:10]))
    except (ValueError, TypeError):
        return None


def _titel(daten, profil_id):
    listen = sehen.lesen(daten, profil_id)
    gefunden, gesehen = [], set()
    for name in ("weiterschauen", "merkliste", "verlauf"):
        for k in listen.get(name) or []:
            schluessel = (k["typ"], k["id"])
            if schluessel in gesehen:
                continue
            gesehen.add(schluessel)
            gefunden.append(k)
    return gefunden[:MAX_TITEL]


def eintraege(daten, profil_id, klient, tage=30):
    try:
        tage = max(1, min(90, int(tage or 30)))
    except (TypeError, ValueError):
        tage = 30
    heute = date.today()
    bis = heute + timedelta(days=tage)
    schluessel = tmdb.schluessel(daten)
    if not schluessel or klient is None:
        return {"eintraege": [], "tage": tage,
                "hinweis": "Fuer den Kalender erst den TMDb-Schluessel eintragen (Einstellungen -> Konten)."}
    ergebnis, gesehen = [], set()
    for k in _titel(daten, profil_id):
        if not str(k["id"]).startswith("tt"):
            continue
        tmdb_id = klient.find_by_imdb(k["id"], k["typ"], schluessel)
        if not tmdb_id:
            continue
        if k["typ"] == "series":
            folge = klient.naechste_folge(tmdb_id, schluessel)
            tag = _tag((folge or {}).get("air_date"))
            if not folge or not tag or not (heute <= tag <= bis):
                continue
            eintrag = {"id": k["id"], "typ": "series", "titel": k["titel"], "datum": tag.isoformat(),
                       "art": "Folge", "staffel": folge.get("season_number"), "folge": folge.get("episode_number"),
                       "folgentitel": str(folge.get("name") or ""), "beschreibung": str(folge.get("overview") or "")[:400],
                       "poster": k.get("poster", ""), "hintergrund": k.get("hintergrund", ""), "quelle": "TMDb"}
            schluessel_e = (eintrag["id"], eintrag["datum"], eintrag["art"], eintrag["staffel"], eintrag["folge"])
            if schluessel_e not in gesehen:
                gesehen.add(schluessel_e)
                ergebnis.append(eintrag)
        else:
            for termin in klient.film_termine(tmdb_id, schluessel):
                tag = _tag(termin.get("release_date"))
                if not tag or not (heute <= tag <= bis):
                    continue
                art = ARTEN.get(termin.get("type"), "Release")
                schluessel_e = (k["id"], tag.isoformat(), art, None, None)
                if schluessel_e in gesehen:
                    continue
                gesehen.add(schluessel_e)
                ergebnis.append({"id": k["id"], "typ": "movie", "titel": k["titel"], "datum": tag.isoformat(),
                                 "art": art, "staffel": None, "folge": None, "folgentitel": "",
                                 "beschreibung": "", "poster": k.get("poster", ""),
                                 "hintergrund": k.get("hintergrund", ""), "quelle": "TMDb"})
    ergebnis.sort(key=lambda e: (e["datum"], e["titel"].lower()))
    return {"eintraege": ergebnis, "tage": tage, "hinweis": ""}
