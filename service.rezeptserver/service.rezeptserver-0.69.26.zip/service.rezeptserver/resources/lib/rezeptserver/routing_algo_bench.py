"""Vergleich: Dict-Lookup vs. Trie."""

import time
from .routing_hilfe import finde_route_schnell
from .routing_trie import RouteTrie, finde_route_trie

# Viele Routen
n = 200
routes = {f"/api/r{i}": lambda: "x" for i in range(n)}
prefix = [(f"/api/p{i}/", lambda: "p") for i in range(50)]
prefix_sorted = sorted(prefix, key=lambda x: -len(x[0]))

trie = RouteTrie()
for p, h in routes.items():
    trie.add(p, h)
for p, h in prefix:
    trie.add(p.rstrip("/"), h)

def bench_dict(iters=10000):
    start = time.perf_counter()
    for i in range(iters):
        finde_route_schnell(f"/api/r{i % n}", routes, prefix_sorted)
        finde_route_schnell(f"/api/p{i % 50}/x", routes, prefix_sorted)
    return time.perf_counter() - start

def bench_trie(iters=10000):
    start = time.perf_counter()
    for i in range(iters):
        finde_route_trie(f"/api/r{i % n}", trie)
        finde_route_trie(f"/api/p{i % 50}/x", trie)
    return time.perf_counter() - start

t1 = bench_dict()
t2 = bench_trie()
print(f"Dict (schnell): {t1:.3f}s ({20000/t1:.0f}/s)")
print(f"Trie:           {t2:.3f}s ({20000/t2:.0f}/s)")
print(f"Trie ist {'schneller' if t2 < t1 else 'langsamer'} bei {n} Exact + 50 Präfix")
