"""Benchmark für finde_route vs. finde_route_schnell."""

import time
from .routing_hilfe import finde_route, finde_route_schnell

routes = {f"/api/r{i}": lambda: "x" for i in range(100)}
prefix = [(f"/api/p{i}/", lambda: "p") for i in range(20)]
prefix_sorted = sorted(prefix, key=lambda x: -len(x[0]))

def bench(fn, n=20000):
    start = time.perf_counter()
    for i in range(n):
        fn(f"/api/r{i % 100}", routes, prefix_sorted if fn is finde_route_schnell else prefix)
        fn(f"/api/p{i % 20}/x", routes, prefix_sorted if fn is finde_route_schnell else prefix)
        fn("/unknown", routes, prefix_sorted if fn is finde_route_schnell else prefix)
    return time.perf_counter() - start

t1 = bench(finde_route)
t2 = bench(finde_route_schnell)
print(f"finde_route:         {t1:.3f}s ({60000/t1:.0f}/s)")
print(f"finde_route_schnell: {t2:.3f}s ({60000/t2:.0f}/s)")
print(f"Speedup:             {t1/t2:.2f}x")
