"""Einfaches Fuzz-Testing für finde_route."""

import random
import string
from .routing_hilfe import finde_route


def random_path(length=None):
    if length is None:
        length = random.randint(0, 40)
    chars = string.ascii_letters + string.digits + "/-_."
    return "/" + "".join(random.choice(chars) for _ in range(length))


def fuzz_routes(n=500):
    routes = {
        "/api/a": lambda: "a",
        "/api/test": lambda: "test",
        "/": lambda: "root",
    }
    prefix = [
        ("/api/v1/", lambda: "v1"),
        ("/api/", lambda: "api"),
        ("/static/", lambda: "static"),
    ]
    for _ in range(n):
        pfad = random_path()
        # Darf nicht crashen
        result = finde_route(pfad, routes, prefix)
        assert result is None or callable(result)
    print(f"Fuzz: {n} zufällige Pfade ohne Crash")


def fuzz_edge(n=100):
    edges = ["", "/", "//", "/../", "/./", "/api/", "/api", "api", "/api/v1", "/api/v1/"]
    routes = {"/api": lambda: "api"}
    prefix = [("/api/", lambda: "prefix")]
    for _ in range(n):
        pfad = random.choice(edges) + random_path(5)
        result = finde_route(pfad, routes, prefix)
        assert result is None or callable(result)
    print(f"Fuzz-Edge: {n} Kantenfälle ohne Crash")


if __name__ == "__main__":
    random.seed(42)
    fuzz_routes()
    fuzz_edge()
    print("Fuzz-Tests bestanden")
