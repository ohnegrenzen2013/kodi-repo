# Routing-Helfer

`routing_hilfe.finde_route()` ersetzt lange if-Ketten durch Dictionary-Lookup.

## Verwendung

```python
from .routing_hilfe import finde_route

routes = {"/api/profile": self.profile_post}
prefix = [("/api/fehler/", self.fehler_post)]

handler = finde_route(pfad, routes, prefix)
if handler:
    return handler(koerper)
```

## Regeln

- Exakte Matches haben Vorrang
- Bei Präfixen gewinnt der längste Match
- Nicht gematchte Pfade → `None`

## Migrationsstatus

- POST: exakte und Präfix-Routen über Maps
- GET: exakte und Präfix-Routen über Maps
- Spezialfälle mit abweichender Signatur bleiben als Fallback

## Tests

```bash
python3 -m rezeptserver.routing_test
```

## Algorithmus-Wahl

| Route-Set | Empfehlung |
|-----------|------------|
| < 50 Präfixe | `finde_route_schnell` |
| > 100 Präfixe | `RouteTrie` |

Benchmark (Lookups/s):
- 50 Exact + 10 Präfix: Dict schneller
- 1000 Exact + 200 Präfix: Trie ~3.8× schneller

## Alle drei Varianten

```python
from .routing_hilfe import alle_router

dict_router, trie_router, adaptiv = alle_router(routes, prefix)
```

- **Dict**: `finde_route_schnell` – schnell bei kleinen Sets
- **Trie**: `RouteTrie` – skaliert bei vielen Präfixen
- **Adaptiv**: wählt automatisch nach Größe
