"""Routing-Helfer: ersetzt lange if-Ketten durch eine Route-Map.

Verwendung:
    routes = {"/api/profile": self.profile_post}
    prefix = [("/api/fehler/", self.fehler_post)]
    handler = finde_route(pfad, routes, prefix)
    if handler:
        return handler(koerper)
"""


def _normalisiere(pfad):
    """Schnelle Pfad-Normalisierung."""
    if not pfad:
        return "/"
    # Query und Fragment abschneiden
    q = pfad.find("?")
    if q != -1:
        pfad = pfad[:q]
    h = pfad.find("#")
    if h != -1:
        pfad = pfad[:h]
    # Schnelle Bereinigung
    if "//" in pfad or "/./" in pfad or "/../" in pfad or pfad.endswith(("/.", "/..")):
        parts = []
        for p in pfad.split("/"):
            if p == "..":
                if parts:
                    parts.pop()
            elif p and p != ".":
                parts.append(p)
        pfad = "/" + "/".join(parts)
    elif pfad != "/" and pfad.endswith("/"):
        pfad = pfad.rstrip("/")
    return pfad or "/"


def finde_route(pfad, routes, prefix_routes=None):
    """Exakte oder Präfix-Route finden.

    Args:
        pfad: Der angeforderte Pfad.
        routes: Dict mit exakten Pfaden → Handler.
        prefix_routes: Liste von (Präfix, Handler). Längster Match gewinnt.

    Returns:
        Handler oder None.
    """
    pfad = _normalisiere(pfad)
    # Exakt zuerst (O(1))
    handler = routes.get(pfad)
    if handler is not None:
        return handler
    # Präfixe (nur wenn nötig)
    if prefix_routes:
        # Längster zuerst – einmal sortieren wäre besser, aber für kleine Listen ok
        for prefix, h in sorted(prefix_routes, key=lambda x: -len(x[0])):
            norm = _normalisiere(prefix.rstrip("/"))
            if pfad == norm or pfad.startswith(norm + "/"):
                return h
    return None


def _prefix_trifft(pfad, prefix):
    """Präfix nur an einer Pfadgrenze, nicht mitten im Segment."""
    if not prefix or not pfad.startswith(prefix):
        return False
    if prefix.endswith("/") or len(pfad) == len(prefix):
        return True
    return pfad[len(prefix)] == "/"


def finde_route_schnell(pfad, routes, prefix_sorted=None):
    """Schnelle Variante: prefix_sorted muss bereits nach Länge absteigend sortiert sein."""
    pfad = _normalisiere(pfad)
    handler = routes.get(pfad)
    if handler is not None:
        return handler
    if prefix_sorted:
        for prefix, h in prefix_sorted:
            if _prefix_trifft(pfad, prefix):
                return h
    return None


def baue_router(routes, prefix_routes=None, schwelle=100):
    """Wählt automatisch Dict oder Trie je nach Größe.

    Args:
        routes: Dict mit exakten Pfaden.
        prefix_routes: Liste von (Präfix, Handler).
        schwelle: Ab dieser Anzahl Präfixe wird der Trie genutzt.

    Returns:
        Callable(pfad) -> Handler oder None.
    """
    prefix_routes = prefix_routes or []
    if len(prefix_routes) >= schwelle:
        from .routing_trie import RouteTrie
        trie = RouteTrie()
        for p, h in routes.items():
            trie.add(p, h)
        for p, h in prefix_routes:
            trie.add(p.rstrip("/"), h)
        return lambda pfad: trie.find(pfad)
    else:
        prefix_sorted = sorted(prefix_routes, key=lambda x: -len(x[0]))
        return lambda pfad: finde_route_schnell(pfad, routes, prefix_sorted)


def alle_router(routes, prefix_routes=None):
    """Gibt alle drei Varianten zurück: (dict, trie, adaptiv)."""
    from .routing_trie import RouteTrie
    prefix_routes = prefix_routes or []
    prefix_sorted = sorted(prefix_routes, key=lambda x: -len(x[0]))
    dict_router = lambda pfad: finde_route_schnell(pfad, routes, prefix_sorted)

    trie = RouteTrie()
    for p, h in routes.items():
        trie.add(p, h)
    for p, h in prefix_routes:
        trie.add(p.rstrip("/"), h)
    trie_router = lambda pfad: trie.find(pfad)

    adaptiv = baue_router(routes, prefix_routes)
    return dict_router, trie_router, adaptiv
