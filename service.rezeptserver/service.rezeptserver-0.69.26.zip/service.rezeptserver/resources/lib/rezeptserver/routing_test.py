"""Tests für den Routing-Helfer inkl. Edge Cases."""

from .routing_hilfe import finde_route, finde_route_schnell, _normalisiere


def test_exact():
    routes = {"/api/a": lambda: "a", "/api/b": lambda: "b"}
    assert finde_route("/api/a", routes)() == "a"
    assert finde_route("/api/c", routes) is None


def test_prefix_longest():
    prefix = [("/api/long/", lambda: "long"), ("/api/", lambda: "short")]
    assert finde_route("/api/long/x", {}, prefix)() == "long"
    assert finde_route("/api/other", {}, prefix)() == "short"


def test_exact_over_prefix():
    routes = {"/api/exact": lambda: "exact"}
    prefix = [("/api/", lambda: "prefix")]
    assert finde_route("/api/exact", routes, prefix)() == "exact"


def test_no_match():
    assert finde_route("/unknown", {}, []) is None


def test_empty_path():
    assert finde_route("", {"/": lambda: "root"})() == "root"
    assert finde_route("/", {"/": lambda: "root"})() == "root"


def test_empty_routes():
    assert finde_route("/api/x", {}, None) is None
    assert finde_route("/api/x", {}) is None


def test_prefix_only():
    prefix = [("/api/v1/", lambda: "v1")]
    assert finde_route("/api/v1/users", {}, prefix)() == "v1"
    assert finde_route("/api/v2/users", {}, prefix) is None


def test_same_length_prefix():
    prefix = [("/api/a/", lambda: "a"), ("/api/b/", lambda: "b")]
    assert finde_route("/api/a/x", {}, prefix)() == "a"
    assert finde_route("/api/b/x", {}, prefix)() == "b"


def test_query_stripped():
    routes = {"/api/test": lambda: "ok"}
    assert finde_route("/api/test?foo=1", routes)() == "ok"
    assert finde_route("/api/test#frag", routes)() == "ok"


def test_trailing_slash():
    routes = {"/api/test": lambda: "ok"}
    assert finde_route("/api/test/", routes)() == "ok"


def test_double_slash():
    routes = {"/api/test": lambda: "ok"}
    assert finde_route("//api//test", routes)() == "ok"


def test_relative_segments():
    routes = {"/api/test": lambda: "ok"}
    assert finde_route("/api/./test", routes)() == "ok"
    assert finde_route("/api/foo/../test", routes)() == "ok"


def test_normalize():
    assert _normalisiere("") == "/"
    assert _normalisiere("//api//x/") == "/api/x"
    assert _normalisiere("/api/./x") == "/api/x"
    assert _normalisiere("/api/foo/../x") == "/api/x"
    assert _normalisiere("/api/x?y=1") == "/api/x"


def test_prefix_boundary():
    prefix = [("/api/long", lambda: "long")]
    assert finde_route("/api/long/x", {}, prefix)() == "long"
    assert finde_route("/api/longer", {}, prefix) is None
    assert finde_route_schnell("/api/long/x", {}, prefix)() == "long"
    assert finde_route_schnell("/api/longer", {}, prefix) is None


if __name__ == "__main__":
    test_exact()
    test_prefix_longest()
    test_exact_over_prefix()
    test_no_match()
    test_empty_path()
    test_empty_routes()
    test_prefix_only()
    test_same_length_prefix()
    test_query_stripped()
    test_trailing_slash()
    test_double_slash()
    test_relative_segments()
    test_normalize()
    test_prefix_boundary()
    print("Routing-Tests (inkl. Pfad-Edge-Cases) bestanden")
