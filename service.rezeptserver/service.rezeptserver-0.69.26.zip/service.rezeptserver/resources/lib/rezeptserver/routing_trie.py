"""Trie-basiertes Routing für viele Präfix-Routen.

Für kleine Route-Sets ist finde_route_schnell ausreichend.
Für große Mengen an Präfixen bietet ein Trie bessere Skalierung.
"""

from .routing_hilfe import _normalisiere


class RouteTrie:
    """Optimierter Pfad-Trie."""

    __slots__ = ("root", "handlers")

    def __init__(self):
        self.root = {}
        self.handlers = {}

    def add(self, path, handler):
        path = _normalisiere(path)
        node = self.root
        for part in path.strip("/").split("/"):
            if not part:
                continue
            nxt = node.get(part)
            if nxt is None:
                nxt = {}
                node[part] = nxt
            node = nxt
        node["__h__"] = handler
        self.handlers[path] = handler

    def find(self, path):
        path = _normalisiere(path)
        # Exact O(1)
        h = self.handlers.get(path)
        if h is not None:
            return h
        # Trie walk – nur so weit wie nötig
        node = self.root
        last = None
        for part in path.strip("/").split("/"):
            node = node.get(part)
            if node is None:
                break
            h = node.get("__h__")
            if h is not None:
                last = h
        return last


def finde_route_trie(pfad, trie):
    """Lookup über einen vorgebauten RouteTrie."""
    return trie.find(pfad)
