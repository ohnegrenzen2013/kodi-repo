"""rustnzb anbinden (https://github.com/TheDancingDeveloper-org/rustnzb, getestet gegen v1.5.0).

rustnzb ist ein Usenet-Downloader mit REST-API und einer WebDAV-Mediathek, die Dateien direkt aus dem Usenet
streamt. Er laeuft als eigener Dienst (PC, NAS, Docker, Raspberry Pi); H0rSt spricht ihn an:

  - Downloads: NZB an rustnzb schicken. H0rSt laedt die NZB selbst (der API-Schluessel des Indexers bleibt
    hier, und rustnzbs add-url lehnt Adressen im Heimnetz ab) und laedt sie hoch (POST /api/queue/add).
  - Warteschlange, Verlauf, Status, Pausieren/Fortsetzen/Loeschen (/api/queue, /api/history, /api/status).
  - Usenet-Provider: die NNTP-Anbieter aus H0rSt in rustnzb anlegen bzw. aktualisieren und testen
    (/api/config/servers).
  - Streamen: Die Mediathek uebernimmt eine NZB beim Hinzufuegen zur Warteschlange, wenn deren Kategorie in
    [dav] category_rules steht (ein PUT nach /dav/nzbs/ legt in v1.5.0 nur die Datei ab). H0rSt traegt dafuer
    die Kategorie "h0rst-stream" ein, fuegt die NZB damit hinzu und loescht den Warteschlangen-Eintrag sofort
    wieder (sonst laedt rustnzb den ganzen Film). Nach wenigen Sekunden liegen die Dateien unter
    /dav/content/<job>/ und lassen sich mit Range-Anfragen abspielen. H0rSt reicht den Stream durch (mit den
    Zugangsdaten der Mediathek), so laeuft er in jedem Player.

Die Mediathek ist in rustnzb ein Zusatz: Docker-Abbild (mit "webdav" gebaut) und [dav] enabled = true bzw.
RUSTNZB_DAV_ENABLED=1.
"""

import base64
import json
import re
import secrets
import time
import urllib.error
import urllib.request
import xml.etree.ElementTree as ET
from urllib.parse import quote, unquote, urlencode, urlsplit

from .netz import USER_AGENT, NetzFehler, antwort_holen

STANDARD_ADRESSE = "http://127.0.0.1:9090"
VIDEO_ENDUNGEN = (".mkv", ".mp4", ".avi", ".m4v", ".ts", ".m2ts", ".mov", ".wmv", ".webm", ".mpg", ".mpeg")
MEDIATHEK_WARTEN = 90.0
STREAM_KATEGORIE = "h0rst-stream"
MAX_NZB = 50 * 1024 * 1024
STATUS_NAMEN = {"queued": "wartet", "downloading": "lädt", "paused": "pausiert", "verifying": "prüft",
                "repairing": "repariert", "extracting": "entpackt", "post_processing": "nachbearbeitet",
                "completed": "fertig", "failed": "fehlgeschlagen"}
_DAV = "{DAV:}"


class RustnzbFehler(Exception):
    pass


_PASSWORT_ENDE = re.compile(r"\{\{([^{}]{1,100})\}\}\s*$")


def passwort_bereinigen(passwort):
    """Passwort fuer den Namenszusatz {{passwort}}: ohne Steuer- und Pfadzeichen und ohne Klammern (hoechstens 100 Zeichen)."""
    return re.sub(r"[\x00-\x1f\x7f/\\{}]+", "", str(passwort or "")).strip()[:100]


def job_name(name, passwort=""):
    """Name fuer Warteschlange und Mediathek: keine Pfadzeichen, hoechstens 150 Zeichen.

    Ein Passwort im Namen (NZB-Datei "Film{{geheim}}.nzb") bleibt als {{geheim}} am Ende erhalten: NZBGet und SABnzbd
    lesen es dort und reichen es an das Entpackprogramm weiter. Ein ausdruecklich uebergebenes passwort ersetzt es."""
    name = re.sub(r"\.nzb$", "", str(name or ""), flags=re.I)
    gefunden = _PASSWORT_ENDE.search(name)
    if gefunden:
        name = name[:gefunden.start()]
    pw = passwort_bereinigen(passwort or (gefunden.group(1) if gefunden else ""))
    name = re.sub(r"[^\w.\-()\[\] ]+", "_", name).strip(" ._")[:150]
    name = name or "h0rst-%d" % int(time.time())
    return name + ("{{%s}}" % pw if pw else "")


def nzb_laden(url, oeffnen=None):
    """NZB-Datei von einem Indexer laden (folgt Weiterleitungen, hoechstens 50 MB)."""
    if not str(url or "").lower().startswith(("http://", "https://")):
        raise RustnzbFehler("Keine NZB-Adresse")
    anfrage = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    try:
        with (oeffnen or urllib.request.urlopen)(anfrage, timeout=30) as antwort:
            daten = antwort.read(MAX_NZB + 1)
    except urllib.error.HTTPError as fehler:
        fehler.close()
        raise RustnzbFehler("NZB nicht ladbar: HTTP %d" % fehler.code)
    except (urllib.error.URLError, OSError, ValueError) as fehler:
        raise RustnzbFehler("NZB nicht ladbar: %s" % fehler)
    if len(daten) > MAX_NZB:
        raise RustnzbFehler("NZB größer als 50 MB")
    if b"<nzb" not in daten[:4096] and not daten[:2] == b"\x1f\x8b":
        raise RustnzbFehler("Antwort des Indexers ist keine NZB (API-Limit erreicht?)")
    return daten


class Client:
    def __init__(self, werte, holen=None):
        url = str(werte.get("url") or STANDARD_ADRESSE).strip().rstrip("/")
        if "://" not in url:
            url = "http://" + url
        teile = urlsplit(url)
        if teile.scheme not in ("http", "https") or not teile.hostname:
            raise RustnzbFehler("rustnzb-Adresse muss http://host:port sein")
        self.url = "%s://%s" % (teile.scheme, teile.netloc)
        self.api_key = str(werte.get("api_key") or "").strip()
        self.kategorie = str(werte.get("kategorie") or "").strip()
        self.holen = holen or antwort_holen
        dav_key = str(werte.get("dav_key") or "").strip()
        dav_user, dav_pass = str(werte.get("dav_user") or ""), str(werte.get("dav_pass") or "")
        if dav_key:
            self.dav_kopf = {"X-Api-Key": dav_key}
        elif dav_user or dav_pass:
            paar = ("%s:%s" % (dav_user, dav_pass)).encode("utf-8")
            self.dav_kopf = {"Authorization": "Basic " + base64.b64encode(paar).decode("ascii")}
        else:
            self.dav_kopf = {}

    # --- REST-API ---------------------------------------------------------------------
    def _api(self, methode, pfad, json_daten=None, roh=None, kopf=None, zeitgrenze=20.0):
        header = {"X-Api-Key": self.api_key, "Accept": "application/json"}
        header.update(kopf or {})
        daten = roh
        if json_daten is not None:
            header["Content-Type"] = "application/json"
            daten = json.dumps(json_daten)
        status, text = self.holen(self.url + pfad, methode, header, daten, zeitgrenze)
        if status == 401:
            raise RustnzbFehler("rustnzb lehnt den API-Schlüssel ab (general.api_key in der config.toml)")
        try:
            antwort = json.loads(text) if text.strip() else {}
        except ValueError:
            raise RustnzbFehler("rustnzb antwortet nicht mit JSON (HTTP %d) – Adresse richtig?" % status)
        if status >= 400:
            grund = antwort.get("error") or antwort.get("message") if isinstance(antwort, dict) else ""
            raise RustnzbFehler("rustnzb: %s" % (grund or "HTTP %d" % status))
        return antwort

    def status(self):
        return self._api("GET", "/api/status")

    def warteschlange(self):
        d = self._api("GET", "/api/queue?limit=100")
        jobs = []
        for j in d.get("jobs") or []:
            gesamt = int(j.get("total_bytes") or 0)
            jobs.append({"id": j.get("id"), "name": j.get("name"), "kategorie": j.get("category") or "",
                         "status": j.get("status"), "status_name": STATUS_NAMEN.get(j.get("status"), j.get("status")),
                         "gesamt": gesamt, "geladen": int(j.get("downloaded_bytes") or 0),
                         "prozent": round(100.0 * int(j.get("downloaded_bytes") or 0) / gesamt, 1) if gesamt else 0,
                         "geschwindigkeit": int(j.get("speed_bps") or 0), "fehler": j.get("error_message") or ""})
        return {"jobs": jobs, "geschwindigkeit": int(d.get("speed_bps") or 0), "pausiert": bool(d.get("paused"))}

    def verlauf(self, anzahl=30):
        d = self._api("GET", "/api/history?limit=%d" % anzahl)
        return [{"id": e.get("id"), "name": e.get("name"), "kategorie": e.get("category") or "",
                 "status": e.get("status"), "status_name": STATUS_NAMEN.get(e.get("status"), e.get("status")),
                 "gesamt": int(e.get("total_bytes") or 0), "fertig": str(e.get("completed_at") or "")[:16].replace("T", " "),
                 "fehler": e.get("error_message") or ""} for e in d.get("entries") or []]

    def nzb_hinzufuegen(self, name, daten, kategorie=None):
        """NZB-Datei in die Warteschlange (Multipart wie der Upload der rustnzb-Oberflaeche)."""
        grenze = "h0rst" + secrets.token_hex(12)
        datei = job_name(name) + ".nzb"
        koerper = (("--%s\r\nContent-Disposition: form-data; name=\"file\"; filename=\"%s\"\r\n"
                    "Content-Type: application/x-nzb\r\n\r\n" % (grenze, datei)).encode("utf-8") + daten +
                   ("\r\n--%s--\r\n" % grenze).encode("utf-8"))
        parameter = {"name": job_name(name)}
        kategorie = self.kategorie if kategorie is None else kategorie
        if kategorie:
            parameter["category"] = kategorie
        antwort = self._api("POST", "/api/queue/add?" + urlencode(parameter), roh=koerper,
                            kopf={"Content-Type": "multipart/form-data; boundary=" + grenze}, zeitgrenze=60.0)
        if not antwort.get("status"):
            raise RustnzbFehler("rustnzb hat die NZB nicht angenommen")
        return antwort.get("nzo_ids") or []

    def aktion(self, was, job_id=None):
        if was in ("pause", "resume") and not job_id:
            return self._api("POST", "/api/queue/%s" % was)
        if not re.match(r"^[\w\-]{1,80}$", str(job_id or "")):
            raise RustnzbFehler("ungueltige Job-ID")
        if was == "loeschen":
            return self._api("DELETE", "/api/queue/%s" % job_id)
        if was in ("pause", "resume"):
            return self._api("POST", "/api/queue/%s/%s" % (job_id, was))
        if was == "wiederholen":
            return self._api("POST", "/api/history/%s/retry" % job_id)
        raise RustnzbFehler("unbekannte Aktion")

    # --- Usenet-Provider ------------------------------------------------------------------
    def server_uebernehmen(self, provider):
        """H0rSt-NNTP-Anbieter in rustnzb anlegen oder aktualisieren (gleich = gleicher Host und Benutzer).
        provider: [(id, name, werte)]. Gibt [(name, "angelegt"|"aktualisiert", test)] zurueck."""
        vorhanden = self._api("GET", "/api/config/servers")
        ergebnis = []
        for prioritaet, (anbieter_id, name, w) in enumerate(provider):
            host = w.get("host", "").strip()
            if not host:
                continue
            ssl = w.get("ssl", "1") == "1"
            port = int(w["port"]) if str(w.get("port", "")).isdigit() else (563 if ssl else 119)
            verbindungen = int(w["verbindungen"]) if str(w.get("verbindungen", "")).isdigit() else 8
            alt = next((s for s in vorhanden if isinstance(s, dict) and s.get("host") == host
                        and (s.get("username") or "") == w.get("user", "")), None)
            konfig = dict(alt or {}, id=(alt or {}).get("id") or "h0rst-" + anbieter_id, name=name, host=host,
                          port=port, ssl=ssl, ssl_verify=True, username=w.get("user") or None,
                          password=w.get("pass") or None, connections=verbindungen,
                          priority=(alt or {}).get("priority", prioritaet), enabled=True,
                          retention=(alt or {}).get("retention", 0), optional=(alt or {}).get("optional", False))
            if alt:
                self._api("PUT", "/api/config/servers/%s" % quote(alt["id"], safe=""), json_daten=konfig)
                aktion = "aktualisiert"
            else:
                self._api("POST", "/api/config/servers", json_daten=konfig)
                aktion = "angelegt"
            try:
                test = self._api("POST", "/api/config/servers/%s/test" % quote(konfig["id"], safe=""), zeitgrenze=25.0)
                test = ("OK: " if test.get("success") else "Fehler: ") + str(test.get("message") or "")
            except (RustnzbFehler, NetzFehler) as fehler:
                test = "Test nicht möglich: %s" % fehler
            ergebnis.append((name, aktion, test))
        return ergebnis

    # --- Mediathek (WebDAV) ---------------------------------------------------------------
    def mediathek_status(self):
        return self._api("GET", "/api/dav/status")

    def kategorie_einrichten(self):
        """Mediathek-Regel fuer STREAM_KATEGORIE anlegen (einmal je Client), Fehler, wenn es keine Mediathek gibt."""
        if getattr(self, "_regel", False):
            return
        try:
            dav = self._api("GET", "/api/config/dav")
        except RustnzbFehler as fehler:
            if "404" in str(fehler) or "not found" in str(fehler).lower():
                raise RustnzbFehler("Dieses rustnzb hat keine Mediathek (mit WebDAV gebaut, z. B. Docker-Abbild)")
            raise
        if not dav.get("enabled"):
            raise RustnzbFehler("Mediathek in rustnzb ausgeschaltet: [dav] enabled = true setzen und neu starten")
        if not dav.get("auto_send_all") and STREAM_KATEGORIE not in (dav.get("category_rules") or []):
            neu = dict(dav, category_rules=list(dav.get("category_rules") or []) + [STREAM_KATEGORIE])
            self._api("PUT", "/api/config/dav", json_daten=neu)
        self._regel = True

    def _dav(self, methode, pfad, daten=None, kopf=None):
        header = dict(self.dav_kopf)
        header.update(kopf or {})
        status, text = self.holen(self.url + "/dav" + pfad, methode, header, daten, 60.0)
        if status == 401:
            raise RustnzbFehler("Mediathek lehnt die Anmeldung ab ([dav] username/password oder api_key)")
        return status, text

    def dateien(self, job):
        """Dateien unter /content/<job>/ (eine Ebene Unterordner), [(pfad, groesse)]; None, solange es den
        Ordner nicht gibt."""
        def liste(pfad):
            status, text = self._dav("PROPFIND", pfad, kopf={"Depth": "1"})
            if status == 404:
                return None
            if status != 207:
                raise RustnzbFehler("Mediathek antwortet mit HTTP %d" % status)
            try:
                wurzel = ET.fromstring(text.encode("utf-8"))
            except ET.ParseError as fehler:
                raise RustnzbFehler("Mediathek-Antwort unlesbar: %s" % fehler)
            eintraege = []
            for antwort in wurzel.iter(_DAV + "response"):
                href = unquote(antwort.findtext(_DAV + "href") or "")
                ordner = antwort.find(".//" + _DAV + "collection") is not None
                groesse = antwort.findtext(".//" + _DAV + "getcontentlength") or "0"
                eintraege.append((href, ordner, int(groesse) if groesse.isdigit() else 0))
            return eintraege
        start = "/content/%s/" % quote(job)
        oben = liste(start)
        if oben is None:
            return None
        dateien = []
        for href, ordner, groesse in oben[1:]:
            pfad = href[href.index("/dav/") + 4:] if "/dav/" in href else href
            if ordner:
                for h, o, g in (liste(quote(pfad, safe="/")) or [])[1:]:
                    if not o:
                        dateien.append((h[h.index("/dav/") + 4:] if "/dav/" in h else h, g))
            else:
                dateien.append((pfad, groesse))
        return dateien

    def _fehlgeschlagen(self, job):
        try:
            for h in self.mediathek_status().get("history") or []:
                if h.get("job_name") == job and h.get("status") == "failed":
                    return h.get("fail_message") or "Verarbeitung fehlgeschlagen"
        except (RustnzbFehler, NetzFehler):
            pass
        return None

    def streamen(self, name, nzb, warten=MEDIATHEK_WARTEN):
        """NZB in die Mediathek legen (falls noch nicht da) und auf die Videodatei warten.
        nzb: Bytes oder eine Funktion, die sie liefert. Gibt (adresse, kopf, dateiname, groesse) zurueck."""
        job = job_name(name)
        dateien = self.dateien(job)
        if dateien is None:
            self.kategorie_einrichten()
            daten = nzb() if callable(nzb) else nzb
            # die Mediathek uebernimmt die NZB beim Hinzufuegen; den Download selbst brauchen wir nicht
            for job_id in self.nzb_hinzufuegen(job, daten, STREAM_KATEGORIE):
                try:
                    self.aktion("loeschen", job_id)
                except (RustnzbFehler, NetzFehler):
                    pass
        ende = time.time() + warten
        while True:
            dateien = self.dateien(job) or []
            videos = [d for d in dateien if d[0].lower().endswith(VIDEO_ENDUNGEN)]
            if videos:
                pfad, groesse = max(videos, key=lambda d: d[1])
                return self.url + "/dav" + quote(pfad, safe="/"), dict(self.dav_kopf), pfad.rsplit("/", 1)[-1], groesse
            if dateien:
                raise RustnzbFehler("Keine Videodatei in der NZB (%s)" % ", ".join(d[0].rsplit("/", 1)[-1]
                                                                                  for d in dateien[:5]))
            fehler = self._fehlgeschlagen(job)
            if fehler:
                raise RustnzbFehler("rustnzb: %s" % fehler)
            if time.time() >= ende:
                raise RustnzbFehler("rustnzb verarbeitet die NZB noch, gleich noch einmal versuchen")
            time.sleep(2)
