"""Sammlungen (Collections) nach ARVIO 2.2: Konstanten, Pruefung und gemeinsame Helfer.

Eine Sammlung ist eine Reihe mit Ordnern ("folders"); jeder Ordner buendelt eine oder mehrere Quellen
(TMDb Discover/Collection/Liste/Person, Trakt- oder MDBList-Liste, Katalog eines Stremio-Addons oder eine
der eingebauten H0rSt-Quellen). Importiert wird das Nuvio-/ARVIO-Format als JSON oder per Adresse.
"""

import hashlib
import json
import re
from urllib.parse import urlsplit

from . import tmdb
from .kataloge_grund import STREAMING, THEMEN, _mdblist_key, _trakt_id

SCHLUESSEL = "sammlungen"
STANDARD = "standard"
MAX_JSON = 2_000_000
MAX_PACKS = 20
MAX_SAMMLUNGEN = 100
MAX_ORDNER = 500
MAX_QUELLEN = 12
MAX_NAME = 80
LAND = "DE"


class SammlungenFehler(ValueError):
    pass


SORTIERUNGEN = frozenset({
    "popularity.asc", "popularity.desc", "vote_average.asc", "vote_average.desc", "vote_count.asc",
    "vote_count.desc", "primary_release_date.asc", "primary_release_date.desc", "first_air_date.asc",
    "first_air_date.desc", "revenue.asc", "revenue.desc", "original_title.asc", "original_title.desc"})

_FILTER = {
    "withGenres": "with_genres", "withoutGenres": "without_genres",
    "voteAverageGte": "vote_average.gte", "voteAverageLte": "vote_average.lte",
    "voteCountGte": "vote_count.gte", "voteCountLte": "vote_count.lte",
    "withOriginalLanguage": "with_original_language", "withOriginCountry": "with_origin_country",
    "withKeywords": "with_keywords", "withoutKeywords": "without_keywords",
    "withCompanies": "with_companies", "withoutCompanies": "without_companies",
    "watchRegion": "watch_region", "withWatchProviders": "with_watch_providers",
    "withoutWatchProviders": "without_watch_providers", "withNetworks": "with_networks",
    "withPeople": "with_people", "withCast": "with_cast", "withCrew": "with_crew",
    "runtimeGte": "with_runtime.gte", "runtimeLte": "with_runtime.lte",
}


def _s(wert, laenge=200):
    return " ".join(str(wert or "").split())[:laenge]


def _bild(wert):
    url = str(wert or "").strip()
    teile = urlsplit(url)
    return url[:1000] if teile.scheme in ("http", "https") and teile.hostname else ""


def _an(wert, standard=False):
    if wert is None:
        return standard
    if isinstance(wert, bool):
        return wert
    return str(wert).strip().lower() in ("1", "true", "ja", "an", "yes", "on")


def _typ(wert):
    text = _s(wert, 20).lower()
    if text in ("series", "tv", "show", "serie", "serien"):
        return "series"
    if text in ("movie", "film", "filme"):
        return "movie"
    return ""


def _slug(wert, ersatz="x"):
    text = re.sub(r"[^a-z0-9]+", "-", _s(wert, 80).lower()).strip("-")
    return (text or ersatz)[:60]


def _zahl(wert, gross=10 ** 9):
    try:
        zahl = int(wert)
    except (TypeError, ValueError):
        return 0
    return zahl if 0 < zahl <= gross else 0


def _wert(roh):
    if isinstance(roh, list):
        return ",".join(w for w in (_s(x, 40) for x in roh) if w)
    if isinstance(roh, (str, int, float)) and not isinstance(roh, bool):
        return _s(roh, 200)
    return ""


def _filter(roh, serien):
    if not isinstance(roh, dict):
        return {}
    ergebnis = {}
    for schluessel, ziel in _FILTER.items():
        wert = _wert(roh.get(schluessel))
        if wert:
            ergebnis[ziel] = wert
    for schluessel, ziel in (("releaseDateGte", "first_air_date.gte" if serien else "primary_release_date.gte"),
                             ("releaseDateLte", "first_air_date.lte" if serien else "primary_release_date.lte"),
                             ("year", "first_air_date_year" if serien else "primary_release_year")):
        wert = _wert(roh.get(schluessel))
        if wert:
            ergebnis[ziel] = wert
    return ergebnis


def quelle(roh):
    """Eine Quellenangabe pruefen und in die interne Form bringen; None = nicht unterstuetzt."""
    if not isinstance(roh, dict):
        return None
    anbieter = _s(roh.get("provider") or "addon", 20).lower()
    if anbieter == "addon":
        typ = _typ(roh.get("type") or roh.get("mediaType") or roh.get("typ"))
        katalog = _s(roh.get("catalogId") or roh.get("katalog") or roh.get("catalog"), 100)
        if not (typ and katalog):
            return None
        return {"art": "addon", "typ": typ, "katalog": katalog, "genre": _s(roh.get("genre"), 60),
                "addon": _s(roh.get("addonId") or roh.get("addon"), 80)}
    if anbieter == "trakt":
        wert = _s(roh.get("traktListId") or roh.get("listId") or roh.get("id") or roh.get("url"), 200)
        treffer = re.search(r"(?:trakt\.tv/lists/)?(\d{1,12})", wert)
        return {"art": "trakt", "id": treffer.group(1)} if treffer and treffer.group(1) != "0" else None
    if anbieter == "mdblist":
        wert = _s(roh.get("slug") or roh.get("mdblistSlug") or roh.get("id") or roh.get("url"), 200)
        treffer = re.search(r"(?:mdblist\.com/lists/)?([\w.-]+)/([\w.-]+)", wert)
        return {"art": "mdblist", "slug": "%s/%s" % (treffer.group(1), treffer.group(2))} if treffer else None
    if anbieter == "tmdb":
        return _tmdb(roh)
    if anbieter in ("entdecken", "cinemeta"):
        typ = _typ(roh.get("typ") or roh.get("mediaType")) or "movie"
        genre = _s(roh.get("genre"), 40)
        return {"art": "entdecken", "typ": typ, "sortierung": _s(roh.get("sortierung"), 20) or "top",
                "genre": genre, "jahr": _s(roh.get("jahr"), 4), "bewertung": _s(roh.get("bewertung"), 2)}
    if anbieter == "streaming":
        kennung = _s(roh.get("id"), 20)
        typ = _typ(roh.get("typ")) or "movie"
        return {"art": "streaming", "id": kennung, "typ": typ} if kennung in dict(STREAMING) else None
    if anbieter == "thema":
        kennung = _s(roh.get("id"), 20)
        return {"art": "thema", "id": kennung} if kennung in THEMEN else None
    return None


def _tmdb(roh):
    art = _s(roh.get("tmdbSourceType") or roh.get("sourceType") or "discover", 20).upper()
    typ = _typ(roh.get("mediaType") or roh.get("typ") or roh.get("type")) or "movie"
    kennung = _zahl(roh.get("tmdbId") or roh.get("id") or roh.get("tmdb_id"))
    if art in ("COLLECTION", "LIST"):
        if not kennung:
            return None
        return {"art": "tmdb", "typ": typ, "quelle": art.lower(), "id": kennung}
    if art in ("PERSON", "DIRECTOR"):
        if not kennung:
            return None
        if isinstance(roh.get("filters"), dict) and any(_wert(w) for w in roh["filters"].values()):
            raise SammlungenFehler("Zusatzfilter bei Personen-/Regie-Sammlungen werden nicht unterstuetzt")
        return {"art": "tmdb", "typ": typ, "quelle": "person", "id": kennung,
                "rolle": "director" if art == "DIRECTOR" else "cast"}
    parameter = _filter(roh.get("filters"), typ == "series")
    if art == "COMPANY" and kennung:
        parameter["with_companies"] = str(kennung)
    elif art == "NETWORK" and kennung:
        parameter["with_networks"] = str(kennung)
    elif art == "GENRE" and kennung:
        parameter["with_genres"] = str(kennung)
    elif art == "KEYWORD" and kennung:
        parameter["with_keywords"] = str(kennung)
    elif art == "WATCH_PROVIDER" and kennung:
        parameter["with_watch_providers"] = str(kennung)
        parameter.setdefault("watch_region", _s(roh.get("watchRegion"), 2) or LAND)
    elif art != "DISCOVER":
        return None
    sortierung = _s(roh.get("sortBy"), 60)
    if sortierung in SORTIERUNGEN:
        parameter["sort_by"] = sortierung
    return {"art": "tmdb", "typ": typ, "quelle": "discover", "params": parameter}


def ordner(roh, nummer):
    """Einen Ordner pruefen; None, wenn Titel, Quellen oder Format fehlen."""
    if not isinstance(roh, dict):
        return None
    titel = _s(roh.get("title") or roh.get("titel") or roh.get("name"), MAX_NAME)
    if not titel:
        return None
    roh_quellen = roh.get("sources") if isinstance(roh.get("sources"), list) else roh.get("catalogSources")
    if not isinstance(roh_quellen, list):
        return None
    quellen, gesehen = [], set()
    for eintrag in roh_quellen[:MAX_QUELLEN]:
        try:
            q = quelle(eintrag)
        except SammlungenFehler:
            raise
        if not q:
            continue
        schluessel = json.dumps(q, sort_keys=True, ensure_ascii=False)
        if schluessel not in gesehen:
            gesehen.add(schluessel)
            quellen.append(q)
    if not quellen:
        return None
    form = "poster" if _s(roh.get("tileShape"), 20).upper() == "POSTER" else "quer"
    return {"id": _slug(roh.get("id") or "o%d" % nummer),
            "titel": titel,
            "beschreibung": _s(roh.get("description") or roh.get("beschreibung"), 300),
            "bild": _bild(roh.get("coverImageUrl") or roh.get("bild")),
            "hero": _bild(roh.get("heroBackdropUrl") or roh.get("heroImageUrl") or roh.get("hero")),
            "logo": _bild(roh.get("titleLogoUrl")),
            "emoji": _s(roh.get("coverEmoji"), 8),
            "titel_aus": _an(roh.get("hideTitle")),
            "fokus_gif": _bild(roh.get("focusGifUrl")),
            "fokus_gif_an": _an(roh.get("focusGifEnabled"), True),
            "fokus_video": _bild(roh.get("focusVideoUrl")),
            "fokus_video_webm": _bild(roh.get("focusVideoWebmUrl")),
            "hero_video": _bild(roh.get("heroVideoUrl")),
            "form": form, "quellen": quellen}


def _sammlungen(root):
    if isinstance(root, list):
        return root
    if isinstance(root, dict) and isinstance(root.get("collections"), list):
        return root["collections"]
    if isinstance(root, dict) and isinstance(root.get("folders"), list):
        return [root]
    return []


def pack_lesen(text, url="", jetzt=0, name=""):
    """JSON-Text (Nuvio-/ARVIO-Format) -> Pack mit normalisierten Reihen und Ordnern."""
    if len(text) > MAX_JSON:
        raise SammlungenFehler("Sammlung ist zu gross (hoechstens 2 MB)")
    try:
        root = json.loads(text)
    except ValueError:
        raise SammlungenFehler("Keine gueltige JSON-Datei")
    sammlungen = _sammlungen(root)
    if not sammlungen or len(sammlungen) > MAX_SAMMLUNGEN:
        raise SammlungenFehler("Keine Sammlungen gefunden (hoechstens %d)" % MAX_SAMMLUNGEN)
    pack_id = "eigene_" + hashlib.sha256((url or text).encode("utf-8")).hexdigest()[:12]
    pack_name = name or (_s(root.get("name"), MAX_NAME) if isinstance(root, dict) else "")
    if not pack_name and len(sammlungen) == 1 and isinstance(sammlungen[0], dict):
        pack_name = _s(sammlungen[0].get("title"), MAX_NAME)
    if not pack_name and url:
        pack_name = _s(urlsplit(url).hostname, MAX_NAME)
    pack_name = pack_name or "Importierte Sammlungen"
    reihen, ordner_gesamt, gesehen = [], 0, set()
    for nr, roh in enumerate(sammlungen):
        if not isinstance(roh, dict) or not isinstance(roh.get("folders"), list):
            continue
        titel = _s(roh.get("title") or roh.get("titel"), MAX_NAME)
        if not titel:
            continue
        reihen_id = _slug(roh.get("id") or "s%d" % nr)
        if reihen_id in gesehen:
            raise SammlungenFehler("Doppelte Sammlungs-Kennung: %s" % reihen_id)
        gesehen.add(reihen_id)
        ordner_liste, ordner_ids = [], set()
        for nummer, o in enumerate(roh["folders"]):
            sauber = ordner(o, nummer)
            if not sauber:
                continue
            if sauber["id"] in ordner_ids:
                raise SammlungenFehler("Doppelter Ordner in %s: %s" % (titel, sauber["id"]))
            ordner_ids.add(sauber["id"])
            ordner_liste.append(sauber)
        if ordner_liste:
            ordner_gesamt += len(ordner_liste)
            reihen.append({"id": reihen_id, "titel": titel,
                           "beschreibung": _s(roh.get("description") or roh.get("beschreibung"), 300),
                           "bild": _bild(roh.get("coverImageUrl") or roh.get("image")),
                           "ordner": ordner_liste})
    if not reihen:
        raise SammlungenFehler("Keine unterstuetzten Ordner gefunden")
    if ordner_gesamt > MAX_ORDNER:
        raise SammlungenFehler("Zu viele Ordner (hoechstens %d)" % MAX_ORDNER)
    return {"id": pack_id, "name": pack_name, "url": _s(url, 500), "importiert": int(jetzt),
            "rails": reihen}


def einstellung(daten):
    roh = (daten or {}).get(SCHLUESSEL)
    roh = roh if isinstance(roh, dict) else {}
    packs = [p for p in roh.get("packs") or [] if isinstance(p, dict) and p.get("id") and isinstance(p.get("rails"), list)]
    return {"packs": packs[:MAX_PACKS], "aus": [x for x in roh.get("aus") or [] if isinstance(x, str)][:400],
            "standard": roh.get("standard") is not False}


def rail_key(rail):
    return "%s/%s" % (rail.get("pack") or STANDARD, rail.get("id"))


def ordner_key(rail, o):
    return "%s/%s" % (rail_key(rail), o.get("id"))


def braucht(o):
    """Welche Zugänge ein Ordner braucht (tmdb/trakt/mdblist); leer = ohne Schluessel nutzbar."""
    ergebnis = set()
    for q in o.get("quellen") or []:
        if q.get("art") == "tmdb":
            ergebnis.add("tmdb")
        elif q.get("art") == "trakt":
            ergebnis.add("trakt")
        elif q.get("art") == "mdblist":
            ergebnis.add("mdblist")
    return sorted(ergebnis)


def braucht_reihe(rail):
    ergebnis = set()
    for o in rail.get("ordner") or []:
        ergebnis.update(braucht(o))
    return sorted(ergebnis)


def zugang(daten):
    return {"tmdb": bool(tmdb.schluessel(daten)), "trakt": bool(_trakt_id(daten)),
            "mdblist": bool(_mdblist_key(daten))}
