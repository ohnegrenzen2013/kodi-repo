"""Sammlungen: die eingebauten Reihen (eigene Abfragen, keine fremde Sammlung uebernommen).

Die eingebauten Sammlungen kommen ohne Zugangsdaten aus, solange ihre Quellen Cinemeta, die
Streaming-Kataloge und die Themen nutzen. Franchises und Jahrzehnte brauchen den optionalen
TMDb-Schluessel und sagen das in der Uebersicht (braucht: tmdb).
"""

from .kataloge_grund import STREAMING, THEMEN

GENRES = [
    ("action", "Action", "Action"), ("abenteuer", "Adventure", "Abenteuer"), ("animation", "Animation", "Animation"),
    ("komoedie", "Comedy", "Komödie"), ("krimi", "Crime", "Krimi"), ("dokumentation", "Documentary", "Dokumentation"),
    ("drama", "Drama", "Drama"), ("familie", "Family", "Familie"), ("fantasy", "Fantasy", "Fantasy"),
    ("horror", "Horror", "Horror"), ("science-fiction", "Sci-Fi", "Science-Fiction"), ("thriller", "Thriller", "Thriller"),
    ("liebe", "Romance", "Liebe"), ("krieg", "War", "Krieg"), ("western", "Western", "Western"), ("sport", "Sport", "Sport"),
]
FRANCHISES = [
    ("star-wars", "Star Wars", 10), ("herr-der-ringe", "Herr der Ringe", 119),
    ("harry-potter", "Harry Potter", 1241), ("matrix", "Matrix", 2344),
    ("jurassic-park", "Jurassic Park", 328), ("fast-and-furious", "Fast & Furious", 9485),
    ("dark-knight", "Dark Knight", 263), ("pirates", "Pirates of the Caribbean", 295),
    ("hunger-games", "Die Tribute von Panem", 131635), ("terminator", "Terminator", 528),
]
JAHRZEHNTE = [("1970er", 1970), ("1980er", 1980), ("1990er", 1990), ("2000er", 2000),
              ("2010er", 2010), ("2020er", 2020)]


def _entdecken(typ, genre="", sortierung="top"):
    return {"art": "entdecken", "typ": typ, "sortierung": sortierung, "genre": genre, "jahr": "", "bewertung": ""}


def _ordner(kennung, titel, quellen, bild="", beschreibung="", form="quer"):
    return {"id": kennung, "titel": titel, "beschreibung": beschreibung, "bild": bild, "hero": "", "logo": "",
            "form": form, "quellen": quellen}


def _entdecken_reihe():
    return {"id": "entdecken", "titel": "Entdecken", "bild": "",
            "beschreibung": "Beliebte, top bewertete und neue Filme und Serien – ohne eigenen Schluessel.",
            "ordner": [
                _ordner("filme", "Beliebte Filme", [_entdecken("movie")]),
                _ordner("serien", "Beliebte Serien", [_entdecken("series")]),
                _ordner("top", "Top bewertet", [_entdecken("movie", "", "imdbRating"),
                                                _entdecken("series", "", "imdbRating")]),
                _ordner("neu", "Neu", [_entdecken("movie", "", "year"), _entdecken("series", "", "year")]),
            ]}


def _genre_reihe():
    return {"id": "genres", "titel": "Genres", "bild": "",
            "beschreibung": "Filme und Serien nach Genre – direkt aus Cinemeta.",
            "ordner": [_ordner(kennung, name, [_entdecken("movie", genre), _entdecken("series", genre)])
                       for kennung, genre, name in GENRES]}


def _streaming_reihe():
    return {"id": "streaming", "titel": "Streaming", "bild": "",
            "beschreibung": "Was bei den eingebauten Streaming-Anbietern gerade laeuft (Deutschland).",
            "ordner": [_ordner(kennung, name, [{"art": "streaming", "id": kennung, "typ": "movie"},
                                              {"art": "streaming", "id": kennung, "typ": "series"}])
                       for kennung, name in STREAMING]}


def _themen_reihe():
    return {"id": "themen", "titel": "Themen", "bild": "",
            "beschreibung": "Reality, Talkshows, Spielshows, Dokus und Konzerte.",
            "ordner": [_ordner(kennung, werte[0], [{"art": "thema", "id": kennung}])
                       for kennung, werte in THEMEN.items()]}


def _franchise_reihe():
    return {"id": "franchises", "titel": "Franchises", "bild": "", "braucht": "tmdb",
            "beschreibung": "Filmreihen in TMDb-Reihenfolge. Braucht den TMDb-Schluessel.",
            "ordner": [_ordner(kennung, name, [{"art": "tmdb", "typ": "movie", "quelle": "collection", "id": nummer}])
                       for kennung, name, nummer in FRANCHISES]}


def _jahrzehnt_reihe():
    return {"id": "jahrzehnte", "titel": "Jahrzehnte", "bild": "", "braucht": "tmdb",
            "beschreibung": "Die besten Filme je Jahrzehnt. Braucht den TMDb-Schluessel.",
            "ordner": [_ordner("%der" % jahr, name, [{"art": "tmdb", "typ": "movie", "quelle": "discover", "params": {
                "primary_release_date.gte": "%d-01-01" % jahr, "primary_release_date.lte": "%d-12-31" % (jahr + 9),
                "vote_count.gte": "300", "sort_by": "vote_average.desc"}}])
                for name, jahr in JAHRZEHNTE]}


def standard_rails():
    """Alle eingebauten Reihen; jede Fuge ist ein eigenes Dictionary (pack wird erst in der Uebersicht gesetzt)."""
    return [_entdecken_reihe(), _genre_reihe(), _streaming_reihe(), _themen_reihe(),
            _franchise_reihe(), _jahrzehnt_reihe()]
