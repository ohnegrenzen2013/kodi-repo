"""Fuehrt die deklarativen Schritte eines Moduls aus.

Daten fliessen als Liste von Eintraegen (dicts) durch die Schritte. Am Anfang
gibt es einen leeren Eintrag. Felder, die mit _ beginnen, sind intern
(z. B. _body, die letzte Antwort) und landen nicht im Ergebnis.
"""

import json
import re
from urllib.parse import quote

from .html_auswahl import AuswahlFehler, lese, waehle, wert as html_wert
from .jsonpath import finde

_PLATZHALTER = re.compile(r"\{([^{}]+)\}")
# Zeichen, die in einer fertigen URL stehen bleiben duerfen
_URL_SICHER = ":/?&=%[]+@,;!$'()*#~"


class SchrittFehler(Exception):
    pass


class Kontext:
    def __init__(self, eingabe, einstellung, abrufer, protokoll=None):
        self.eingabe = eingabe or {}
        self.einstellung = einstellung or {}
        self.abrufer = abrufer
        # Liste fuer den Selbsttest: was jeder Schritt getan hat (None = nicht mitschreiben)
        self.protokoll = protokoll


def _wert(name, eintrag, ktx):
    if name.startswith("eingabe."):
        quelle, schluessel = ktx.eingabe, name[len("eingabe."):]
    elif name.startswith("einstellung."):
        quelle, schluessel = ktx.einstellung, name[len("einstellung."):]
    else:
        quelle, schluessel = eintrag, name
    wert = quelle
    for teil in schluessel.split("."):
        if not isinstance(wert, dict) or teil not in wert:
            return ""
        wert = wert[teil]
    return "" if wert is None else wert


def fuelle(text, eintrag, ktx, url=False):
    if not isinstance(text, str):
        return text

    def ersetze(treffer):
        name, _, wandel = treffer.group(1).strip().partition("|")
        wert = _wert(name.strip(), eintrag, ktx)
        wert = wert if isinstance(wert, str) else json.dumps(wert) if isinstance(wert, (dict, list)) else str(wert)
        wandel = wandel.strip()
        # {feld|pfad} kodiert fuer einen Adresspfad und laesst / stehen
        if wandel == "pfad":
            return quote(wert, safe="/")
        # {feld|url} kodiert den Wert fuer eine Adresse, auch ausserhalb von abruf
        return quote(wert, safe="") if url or wandel == "url" else wert

    ergebnis = _PLATZHALTER.sub(ersetze, text)
    return quote(ergebnis, safe=_URL_SICHER) if url else ergebnis


def _fuelle_tief(wert, eintrag, ktx):
    if isinstance(wert, dict):
        return {k: _fuelle_tief(v, eintrag, ktx) for k, v in wert.items()}
    if isinstance(wert, list):
        return [_fuelle_tief(v, eintrag, ktx) for v in wert]
    return fuelle(wert, eintrag, ktx)


def _abruf(eintraege, param, ktx):
    neu = []
    for eintrag in eintraege:
        url = fuelle(param["url"], eintrag, ktx, url=True)
        header = {k: fuelle(v, eintrag, ktx) for k, v in (param.get("header") or {}).items()}
        daten = param.get("daten")
        if isinstance(daten, (dict, list)):
            # JSON-Koerper: Platzhalter nur in Textwerten, Anfuehrungszeichen im Titel bleiben gueltiges JSON
            daten = json.dumps(_fuelle_tief(daten, eintrag, ktx), ensure_ascii=False)
            if not any(k.lower() == "content-type" for k in header):
                header["Content-Type"] = "application/json"
        elif daten:
            daten = fuelle(daten, eintrag, ktx)
        else:
            daten = None
        basic = None
        if param.get("auth") == "basic":
            basic = (str(ktx.einstellung.get("user", "")), str(ktx.einstellung.get("pass", "")))
        text = ktx.abrufer.abruf(url, methode=param.get("methode", "GET").upper(),
                                 header=header, daten=daten, basic=basic)
        kopie = dict(eintrag)
        kopie["_body"] = text
        neu.append(kopie)
    return neu


def _begrenzt(liste, param):
    """Optionales max: nur die ersten n Knoten."""
    if param.get("max") is None:
        return liste
    return liste[:max(0, int(param["max"]))]


def _ohne_body(eintrag):
    return {k: v for k, v in eintrag.items() if k != "_body"}


def _json(eintraege, param, ktx):
    neu = []
    for eintrag in eintraege:
        body = eintrag.get("_body", "")
        if not body.strip():
            raise SchrittFehler("Antwort ist leer – Zugang abgelaufen, Konto gesperrt oder Dienst gestört?")
        try:
            # BOM am Anfang und rohe Steuerzeichen in Strings kommen in echten Antworten vor
            daten = json.loads(body.lstrip("\ufeff"), strict=False)
        except ValueError as fehler:
            anfang = " ".join(body.split())[:120]
            raise SchrittFehler("Antwort ist kein JSON (%s), Anfang: %r" % (fehler, anfang))
        knoten_liste = finde(param["liste"], daten) if param.get("liste") else [daten]
        for knoten in _begrenzt(knoten_liste, param):
            kopie = _ohne_body(eintrag)
            for feld, pfad in (param.get("felder") or {}).items():
                # $$ = Wurzel des ganzen Dokuments, $ = aktueller Listeneintrag
                gefunden = finde(pfad[1:], daten) if pfad.startswith("$$") else finde(pfad, knoten)
                if gefunden:
                    kopie[feld] = gefunden[0]
            neu.append(kopie)
    return neu


def _regex(eintraege, param, ktx):
    muster = re.compile(param["muster"], re.DOTALL if param.get("mehrzeilig") else 0)
    quelle = param.get("quelle", "_body")
    felder = param.get("felder") or {}
    neu = []
    for eintrag in eintraege:
        text = str(eintrag.get(quelle, ""))
        gefunden = False
        for treffer in muster.finditer(text):
            gefunden = True
            kopie = _ohne_body(eintrag)
            for feld, gruppe in felder.items():
                try:
                    kopie[feld] = treffer.group(gruppe)
                except (IndexError, re.error):
                    raise SchrittFehler("Gruppe %r gibt es im Muster nicht" % (gruppe,))
            neu.append(kopie)
            if not param.get("alle", True):
                break
        if not gefunden and param.get("optional"):
            # optional: Eintrag bleibt ohne die neuen Felder erhalten
            neu.append(_ohne_body(eintrag))
    return neu


def _alle_leer(text, eintrag, ktx):
    namen = _PLATZHALTER.findall(text) if isinstance(text, str) else []
    return bool(namen) and all(_wert(n.partition("|")[0].strip(), eintrag, ktx) in ("", None) for n in namen)


def _vorlage(eintraege, param, ktx):
    """Setzt Felder. Sind alle Platzhalter einer Vorlage leer, bleibt das Feld leer."""
    neu = []
    for eintrag in eintraege:
        kopie = dict(eintrag)
        for feld, text in param.items():
            kopie[feld] = "" if _alle_leer(text, eintrag, ktx) else fuelle(text, eintrag, ktx)
        neu.append(kopie)
    return neu


def _leer(wert):
    return wert is None or wert is False or str(wert).strip().lower() in ("", "0", "false", "none")


def _woerter(text):
    return [w for w in re.split(r"[^0-9a-zäöüß]+", str(text).lower()) if w]


def _woerter_im_feld(text):
    """Wie _woerter, zerlegt zusaetzlich zusammengeschriebene Namen: BigBuckBunny -> big, buck, bunny."""
    zerlegt = re.sub(r"(?<=[a-zäöüß])(?=[A-ZÄÖÜ])", " ", str(text))
    return set(_woerter(text)) | set(_woerter(zerlegt))


def _enthaelt_woerter(text, soll):
    """Alle Woerter des Sollwerts im Feld (Reihenfolge egal) oder alle zusammengeschrieben als ein Wort."""
    soll_woerter = _woerter(soll)
    feld = _woerter_im_feld(text)
    return set(soll_woerter) <= feld or "".join(soll_woerter) in feld


_JAHR = re.compile(r"(?<!\d)(19\d\d|20\d\d)(?!\d)")


def _jahr_passt(text, soll, ausser=""):
    """Kein Sollwert oder kein Jahr im Text: passt. Sonst muss ein Jahr hoechstens 1 abweichen.

    Jahreszahlen, die auch in `ausser` stehen (z. B. im Filmtitel "2012"), zaehlen nicht.
    """
    try:
        soll = int(str(soll).strip()[:4])
    except ValueError:
        return True
    titel_jahre = set(_JAHR.findall(ausser or ""))
    jahre = [int(j) for j in _JAHR.findall(text) if j not in titel_jahre]
    return not jahre or any(abs(j - soll) <= 1 for j in jahre)


def _passt(eintrag, wenn, ktx):
    # nur_wenn: Bedingung gilt nur, wenn diese Vorbedingung zutrifft (sonst gilt sie als erfuellt)
    if isinstance(wenn.get("nur_wenn"), dict) and not _passt(eintrag, wenn["nur_wenn"], ktx):
        return True
    feld = wenn.get("feld", "")
    # Felder koennen auch eingabe.x oder einstellung.x sein
    wert = _wert(feld, eintrag, ktx) if feld.startswith(("eingabe.", "einstellung.")) else eintrag.get(feld)
    text = "" if wert is None else str(wert)

    def soll_text(soll):
        return fuelle(soll, eintrag, ktx) if isinstance(soll, str) else str(soll)

    pruefungen = {
        "gleich": lambda soll: text == soll_text(soll),
        "ungleich": lambda soll: text != soll_text(soll),
        "enthaelt": lambda soll: soll_text(soll).lower() in text.lower(),
        "endet_mit": lambda soll: text.lower().endswith(soll_text(soll).lower()),
        "beginnt_mit": lambda soll: text.lower().startswith(soll_text(soll).lower()),
        "nicht_leer": lambda soll: (not _leer(wert)) == bool(soll),
        "enthaelt_woerter": lambda soll: _enthaelt_woerter(text, soll_text(soll)),
        "muster": lambda soll: re.search(soll, text) is not None,
        "nicht_muster": lambda soll: re.search(soll, text) is None,
        # Jahr im Feld weicht hoechstens 1 Jahr ab; Felder ohne Jahr passen immer
        "jahr_passt": lambda soll: _jahr_passt(text, soll_text(soll), soll_text(wenn.get("ohne_jahre_aus", ""))),
    }
    for name, pruefung in pruefungen.items():
        if name in wenn and not pruefung(wenn[name]):
            return False
    return True


_PRUEFUNGEN = ("gleich", "ungleich", "enthaelt", "endet_mit", "beginnt_mit", "nicht_leer",
               "enthaelt_woerter", "muster", "nicht_muster", "jahr_passt")


def beschreibe(bedingung, eintrag, ktx):
    """Lesbare Form einer Bedingung, Platzhalter eingesetzt."""
    teile = [str(bedingung.get("feld", ""))]
    for name in _PRUEFUNGEN:
        if name in bedingung:
            soll = bedingung[name]
            teile.append("%s %s" % (name, fuelle(soll, eintrag, ktx) if isinstance(soll, str) else soll))
    return " ".join(teile)


def _filter(eintraege, param, ktx):
    """wenn: eine Bedingung oder eine Liste, dann muessen alle zutreffen."""
    bedingungen = param["wenn"] if isinstance(param["wenn"], list) else [param["wenn"]]
    behalten = []
    for eintrag in eintraege:
        verletzt = next((b for b in bedingungen if not _passt(eintrag, b, ktx)), None)
        if verletzt is None:
            behalten.append(eintrag)
        elif ktx.protokoll is not None:
            name = eintrag.get("titel") or eintrag.get("datei") or eintrag.get("ref") or "(ohne Titel)"
            ktx.protokoll.append({"aussortiert": str(name), "grund": beschreibe(verletzt, eintrag, ktx)})
    return behalten


def _html(eintraege, param, ktx):
    """Wie json, aber mit CSS-Selektoren; Feldangabe 'selektor', 'selektor@attr' oder '@attr'."""
    neu = []
    for eintrag in eintraege:
        wurzel = lese(eintrag.get("_body", ""))
        try:
            knoten_liste = waehle(wurzel, param["liste"]) if param.get("liste") else [wurzel]
            for knoten in _begrenzt(knoten_liste, param):
                kopie = _ohne_body(eintrag)
                for feld, angabe in (param.get("felder") or {}).items():
                    gefunden = html_wert(knoten, angabe)
                    if gefunden not in (None, ""):
                        kopie[feld] = gefunden
                neu.append(kopie)
        except AuswahlFehler as fehler:
            raise SchrittFehler(str(fehler))
    return neu


BAUSTEINE = {
    "abruf": _abruf,
    "json": _json,
    "regex": _regex,
    "vorlage": _vorlage,
    "filter": _filter,
    "html": _html,
}


def fuehre_aus(schritte, ktx):
    eintraege = [{}]
    for nummer, schritt in enumerate(schritte, 1):
        (name, param), = schritt.items()
        vorher = len(eintraege)
        eintraege = BAUSTEINE[name](eintraege, param, ktx)
        if ktx.protokoll is not None:
            ktx.protokoll.append({"schritt": nummer, "baustein": name, "vorher": vorher, "nachher": len(eintraege)})
        if not eintraege:
            break
    return [{k: v for k, v in e.items() if not k.startswith("_")} for e in eintraege]
