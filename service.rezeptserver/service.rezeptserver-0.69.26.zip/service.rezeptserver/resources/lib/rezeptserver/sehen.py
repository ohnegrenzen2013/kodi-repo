"""Filme und Serien: Merkliste und Verlauf wie in "Ab 18" – auf dem Server, damit sie auf allen Geraeten gleich sind.

Je Profil eine eigene Liste (wie bei Netflix); ohne Profile gibt es eine gemeinsame. Gemerkt wird die Karte, wie die
Oberflaeche sie zeigt (Titel, Bilder, Jahr, Bewertung, Genres, Laufzeit), damit Merkliste und Verlauf ohne Nachladen
erscheinen.

Weiterschauen: Die Player (Browser und App) melden, wie weit ein Video lief. Je Titel bleibt die zuletzt gesehene Stelle
stehen (bei Serien die der zuletzt gesehenen Folge), damit jedes Geraet dort weitermacht. Kurz vor dem Ende gilt der Titel
als gesehen: er verlaesst "weiterschauen" und kommt in den Verlauf.

Nutzerdaten "sehen": {"<profil-id oder ''>": {"merkliste": [karte, ...], "verlauf": [karte, ...],
                                             "weiterschauen": [karte + {video, position, dauer, zeit}, ...]}}
"""

import math
import re
import time
from urllib.parse import urlsplit

SCHLUESSEL = "sehen"
MAX_MERKLISTE = 500
MAX_VERLAUF = 200
MAX_WEITERSCHAUEN = 100
LISTEN = ("merkliste", "verlauf")
MIN_DAUER = 120        # kuerzere Videos (Trailer, Clips) merken sich keine Stelle
MIN_POSITION = 30      # davor: noch nicht angefangen, nichts zum Weiterschauen
FERTIG_ANTEIL = 0.92   # ab hier (oder in den letzten FERTIG_REST Sekunden) gilt der Titel als gesehen
FERTIG_REST = 120


class SehenFehler(ValueError):
    pass


def _text(wert, laenge):
    return " ".join(str(wert or "").split())[:laenge]


def _bild(wert):
    url = str(wert or "").strip()
    teile = urlsplit(url)
    return url[:1000] if teile.scheme in ("http", "https") and teile.hostname else ""


def _zeit(wert):
    return int(wert) if isinstance(wert, (int, float)) and not isinstance(wert, bool) else 0


def karte(roh):
    """Karte aus der Oberflaeche pruefen und auf das Noetige kuerzen; SehenFehler, wenn Kennung oder Typ fehlen.
    "geaendert" ist nur ein Zeitstempel fuers Geraete-Abgleichen (NuvioMobile-Plan NV6) – wird beim Neuanlegen
    (siehe aendern()) auf "jetzt" gesetzt, beim Zurueckparsen eines gespeicherten Eintrags unveraendert uebernommen."""
    if not isinstance(roh, dict):
        raise SehenFehler("Titel als Objekt")
    kennung = _text(roh.get("id"), 120)
    if not kennung or not re.match(r"^[\w.:%/@+=-]+$", kennung):
        raise SehenFehler("Titel ohne gültige Kennung")
    typ = roh.get("typ")
    if typ not in ("movie", "series"):
        raise SehenFehler("Typ: movie oder series")
    genres = roh.get("genres") if isinstance(roh.get("genres"), list) else []
    return {"id": kennung, "typ": typ, "titel": _text(roh.get("titel"), 200) or kennung,
            "jahr": _text(roh.get("jahr"), 20), "bewertung": _text(roh.get("bewertung"), 10),
            "poster": _bild(roh.get("poster")), "hintergrund": _bild(roh.get("hintergrund")), "logo": _bild(roh.get("logo")),
            "genres": [_text(g, 40) for g in genres if isinstance(g, str)][:4],
            "laufzeit": _text(roh.get("laufzeit"), 20), "beschreibung": _text(roh.get("beschreibung"), 400),
            "geaendert": _zeit(roh.get("geaendert"))}


def _gleich(a, b):
    return a["id"] == b["id"] and a["typ"] == b["typ"]


def _sekunden(wert):
    """Sekunden als Zahl (0 bis eine Woche); SehenFehler sonst."""
    try:
        s = float(wert)
    except (TypeError, ValueError):
        raise SehenFehler("Sekunden als Zahl")
    if not math.isfinite(s) or not 0 <= s <= 7 * 24 * 3600:
        raise SehenFehler("Sekunden ausserhalb des Bereichs")
    return round(s, 1)


def _video(roh, titel_id):
    """Kennung des Videos: der Titel selbst (Film) oder eine Folge davon (tt123:1:2)."""
    video = _text(roh, 160)
    if not re.match(r"^[\w.:%/@+=-]+$", video) or not (video == titel_id or video.startswith(titel_id + ":")):
        raise SehenFehler("Video gehört nicht zum Titel")
    return video


def _anteil(wert):
    """Anteil 0..1 (wie weit ein Video lief); SehenFehler sonst."""
    try:
        a = float(wert)
    except (TypeError, ValueError):
        raise SehenFehler("Anteil als Zahl")
    if not math.isfinite(a) or not 0 <= a <= 1:
        raise SehenFehler("Anteil zwischen 0 und 1")
    return round(a, 3)


def weiter_eintrag(roh):
    """Eintrag in weiterschauen: Karte des Titels plus Video, Stelle, Dauer, Anteil, Zeitpunkt. SehenFehler bei Unsinn.
    Aus fremden Apps (mHub) kommt nur der Anteil: dann sind Stelle und Dauer 0, der Player rechnet beim Start."""
    k = karte(roh)
    position, dauer = _sekunden(roh.get("position")), _sekunden(roh.get("dauer"))
    naechste = roh.get("naechste") is True and k["typ"] == "series" and dauer == 0 and position == 0
    if naechste:  # nach einer fertigen Folge vorgemerkt: noch nicht angefangen
        anteil = 0
    elif dauer == 0 and position == 0 and roh.get("anteil") is not None:
        anteil = _anteil(roh["anteil"])
        if not 0 < anteil < 1:
            raise SehenFehler("Anteil passt nicht")
    elif dauer < MIN_DAUER or position > dauer:
        raise SehenFehler("Stelle oder Dauer passt nicht")
    else:
        anteil = round(position / dauer, 3)
    zeit = roh.get("zeit")
    e = dict(k, video=_video(roh.get("video") or k["id"], k["id"]), position=position, dauer=dauer, anteil=anteil,
             zeit=int(zeit) if isinstance(zeit, (int, float)) and not isinstance(zeit, bool) else 0)
    if naechste:
        e["naechste"] = True
    return e


def fertig(position, dauer):
    return position >= dauer * FERTIG_ANTEIL or dauer - position <= FERTIG_REST


def _listen(daten, profil_id):
    alle = daten.get(SCHLUESSEL) if isinstance(daten.get(SCHLUESSEL), dict) else {}
    eigen = alle.get(profil_id or "") if isinstance(alle.get(profil_id or ""), dict) else {}
    ergebnis = {"weiterschauen": []}
    titel = set()
    for roh in eigen.get("weiterschauen") or []:
        try:
            e = weiter_eintrag(roh)
        except SehenFehler:
            continue
        if (e["typ"], e["id"]) not in titel and len(ergebnis["weiterschauen"]) < MAX_WEITERSCHAUEN:
            titel.add((e["typ"], e["id"]))
            ergebnis["weiterschauen"].append(e)
    for name in LISTEN:
        gesehen, liste = set(), []
        for roh in eigen.get(name) or []:
            try:
                k = karte(roh)
            except SehenFehler:
                continue
            if (k["typ"], k["id"]) not in gesehen:
                gesehen.add((k["typ"], k["id"]))
                liste.append(k)
        ergebnis[name] = liste[:MAX_MERKLISTE if name == "merkliste" else MAX_VERLAUF]
    return ergebnis


def lesen(daten, profil_id=""):
    """Merkliste, Verlauf und Weiterschauen dieses Profils; kaputte Eintraege fallen weg."""
    return _listen(daten if isinstance(daten, dict) else {}, profil_id)


def _fortschritt(listen, wunsch, jetzt):
    """Stelle eines Videos merken. Kurz vor dem Ende: gesehen (raus aus weiterschauen, rein in den Verlauf)."""
    k = karte(wunsch.get("titel"))
    video = _video(wunsch.get("video") or k["id"], k["id"])
    if wunsch.get("dauer") is None and wunsch.get("anteil") is not None:
        # nur der Anteil (mHub-Apps melden ganze Prozent): Stelle und Dauer bleiben 0
        position = dauer = 0.0
        anteil = _anteil(wunsch["anteil"])
        ist_fertig, zu_frueh = anteil >= FERTIG_ANTEIL, anteil < 0.01
    else:
        position, dauer = _sekunden(wunsch.get("position")), _sekunden(wunsch.get("dauer"))
        if dauer < MIN_DAUER:
            return  # Clip oder Trailer: nichts zu merken
        position = min(position, dauer)
        anteil = round(position / dauer, 3)
        ist_fertig, zu_frueh = fertig(position, dauer), position < MIN_POSITION
    rest = [x for x in listen["weiterschauen"] if not _gleich(x, k)]
    if ist_fertig:
        naechste = wunsch.get("naechste")
        if naechste and k["typ"] == "series":
            # ARVIO 2.3: nach einer fertigen Folge rueckt die naechste unter Weiterschauen nach (noch nicht angefangen)
            naechste = _video(naechste, k["id"])
            if naechste != video:
                e = dict(k, video=naechste, position=0.0, dauer=0.0, anteil=0, zeit=int(jetzt), naechste=True)
                rest = [e] + rest
        listen["weiterschauen"] = rest[:MAX_WEITERSCHAUEN]
        k = dict(k, geaendert=int(jetzt))
        listen["verlauf"] = ([k] + [x for x in listen["verlauf"] if not _gleich(x, k)])[:MAX_VERLAUF]
    elif zu_frueh:
        if any(_gleich(x, k) and x.get("naechste") and x["video"] == video for x in listen["weiterschauen"]):
            return  # der Anfang der vorgemerkten Folge (unter 30 s) nimmt den Eintrag nicht weg
        listen["weiterschauen"] = rest
    else:
        e = dict(k, video=video, position=position, dauer=dauer, anteil=anteil, zeit=int(jetzt))
        listen["weiterschauen"] = ([e] + rest)[:MAX_WEITERSCHAUEN]


def aendern(daten, profil_id, wunsch, jetzt=None):
    """{"aktion": merken|weg|gesehen|verlauf_weg|weiterschauen_weg|leeren, "titel": karte,
        "was": merkliste|verlauf|weiterschauen}
    | {"aktion": "fortschritt", "titel": karte, "video": "tt123:1:2", "position": s, "dauer": s}.
    merken und gesehen setzen den Titel nach vorn. Gibt die neuen Listen zurueck."""
    if not isinstance(wunsch, dict):
        raise SehenFehler("JSON-Objekt erwartet")
    jetzt = time.time() if jetzt is None else jetzt
    listen = _listen(daten, profil_id)
    aktion = wunsch.get("aktion")
    if aktion == "fortschritt":
        _fortschritt(listen, wunsch, jetzt)
    elif aktion == "weiterschauen_weg":
        k = karte(wunsch.get("titel"))
        listen["weiterschauen"] = [x for x in listen["weiterschauen"] if not _gleich(x, k)]
    elif aktion in ("merken", "weg", "gesehen", "verlauf_weg"):
        k = karte(wunsch.get("titel"))
        name = "merkliste" if aktion in ("merken", "weg") else "verlauf"
        rest = [x for x in listen[name] if not _gleich(x, k)]
        if aktion in ("merken", "gesehen"):
            k = dict(k, geaendert=int(jetzt))
            listen[name] = ([k] + rest)[:MAX_MERKLISTE if name == "merkliste" else MAX_VERLAUF]
        else:
            listen[name] = rest[:MAX_MERKLISTE if name == "merkliste" else MAX_VERLAUF]
    elif aktion == "leeren":
        if wunsch.get("was") not in LISTEN + ("weiterschauen",):
            raise SehenFehler("leeren: merkliste, verlauf oder weiterschauen")
        listen[wunsch["was"]] = []
    else:
        raise SehenFehler("Unbekannte Aktion")
    alle = daten.get(SCHLUESSEL) if isinstance(daten.get(SCHLUESSEL), dict) else {}
    alle[profil_id or ""] = listen
    daten[SCHLUESSEL] = alle
    return listen
