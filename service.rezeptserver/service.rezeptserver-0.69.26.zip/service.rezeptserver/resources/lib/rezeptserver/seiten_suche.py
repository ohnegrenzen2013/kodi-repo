"""Suchfunktion einer Webseite erkennen (Formular, OpenSearch, häufige Muster).

  Nutzer gibt eine Adresse ein; H0rSt liest die Seite und erkennt, wie ihre Suche aufgebaut ist.
  Das Ergebnis ist eine Suchvorlage mit ``{titel}``, die als eigene Quelle gespeichert und in der
  H0rSt-Suche mit durchsucht wird. Es wird kein fremder Bot umgangen und nichts automatisch
  abgespielt; H0rSt ruft nur die Suchseite ab, die der Nutzer selbst freigegeben hat.
"""

import html
import re
from urllib.parse import parse_qsl, quote, urlencode, urljoin, urlsplit, urlunsplit

from . import netz
from .eigene_quelle import _ssrf_pruefen_host
from .netz import urllib_holen

FORM = re.compile(r"<form\b([^>]*)>(.*?)</form>", re.I | re.S)
INPUT = re.compile(r"<input\b([^>]*?)/?>", re.I | re.S)
LINK = re.compile(r"<link\b([^>]*?)/?>", re.I | re.S)
ATTR = re.compile(r"([A-Za-z_:][-A-Za-z0-9_:.]*)\s*=\s*(?:\"([^\"]*)\"|'([^']*)'|([^\s/>]+))")
TITEL = re.compile(r"<title[^>]*>(.*?)</title>", re.I | re.S)
SITE = re.compile(r"<meta\b[^>]*(?:property|name)\s*=\s*[\"']og:site_name[\"'][^>]*content\s*=\s*[\"']([^\"']+)", re.I)
SUCHNAMEN = ("q", "s", "search", "query", "suche", "suchbegriff", "term", "keywords", "keyword", "k", "text")


class SeitenSucheFehler(ValueError):
    pass


def _attr(roh):
    werte = {}
    for m in ATTR.finditer(roh or ""):
        key = m.group(1).lower()
        werte[key] = html.unescape(m.group(2) if m.group(2) is not None else m.group(3) if m.group(3) is not None else m.group(4) or "")
    return werte


def _titel(text, basis):
    for muster in (SITE, TITEL):
        m = muster.search(text or "")
        if m:
            wert = " ".join(html.unescape(re.sub(r"<[^>]+>", " ", m.group(1))).split())
            if wert:
                return wert[:60]
    return (urlsplit(basis).hostname or "Webseite").replace("www.", "").split(".")[0].capitalize()


def _mit_params(url, paare):
    teile = urlsplit(url)
    vorhanden = parse_qsl(teile.query, keep_blank_values=True)
    neu = vorhanden + [p for p in paare if p[0] not in {k for k, _ in vorhanden}]
    return urlunsplit(teile._replace(query=urlencode(neu), fragment=""))


def _formulare(text, basis):
    """GET-Formulare mit Suchfeld -> Kandidaten. POST-Formulare werden als Hinweis gemeldet, nicht
    als Vorlage gespeichert (H0rSts eigene Quellen rufen Suchadressen per GET ab)."""
    treffer, hinweise = [], []
    for form in FORM.finditer(text or ""):
        attrs = _attr(form.group(1))
        innen = form.group(2)
        felder = [_attr(m.group(1)) for m in INPUT.finditer(innen)]
        suchfeld = None
        for feld in felder:
            typ = (feld.get("type") or "text").lower()
            name = (feld.get("name") or "").strip()
            if name and (typ == "search" or (typ in ("text", "") and name.lower() in SUCHNAMEN)):
                suchfeld = feld
                if typ == "search" or name.lower() in ("q", "search", "query", "suche", "s"):
                    break
        if not suchfeld:
            continue
        if not suchfeld.get("name"):
            continue
        methode = (attrs.get("method") or "get").lower()
        aktion = urljoin(basis, attrs.get("action") or basis)
        if not aktion.startswith(("http://", "https://")):
            continue
        if methode != "get":
            hinweise.append("POST-Suchformular erkannt; H0rSt nutzt dafür die URL-Suche, nicht das Formular.")
            continue
        paare = [(f["name"], f.get("value", "")) for f in felder
                 if f.get("name") and (f.get("type") or "text").lower() == "hidden"]
        paare.append((suchfeld["name"], "__H0RST_SUCHE__"))
        suche = _mit_params(aktion, paare).replace("__H0RST_SUCHE__", "{titel}")
        treffer.append({"name": _titel(text, basis), "seite": basis, "suche": suche, "methode": "GET",
                        "feld": suchfeld["name"], "quelle": "Formular"})
    return treffer, hinweise


def _opensearch(text, basis, holen):
    treffer = []
    for m in LINK.finditer(text or ""):
        attrs = _attr(m.group(1))
        if "search" not in (attrs.get("rel") or "").lower() or not attrs.get("href"):
            continue
        ziel = urljoin(basis, attrs["href"])
        if not ziel.startswith(("http://", "https://")):
            continue
        try:
            _ssrf_pruefen_host(ziel)
            xml = holen(ziel)
        except Exception:
            continue
        for u in re.finditer(r"<Url\b([^>]*?)/?>", xml or "", re.I | re.S):
            a = _attr(u.group(1))
            if (a.get("type") or "text/html").lower() not in ("text/html", "application/xhtml+xml", ""):
                continue
            if (a.get("method") or "get").lower() != "get":
                continue
            vorlage = (a.get("template") or "").replace("{searchTerms}", "{titel}")
            if "{titel}" not in vorlage:
                continue
            treffer.append({"name": _titel(text, basis), "seite": basis, "suche": vorlage[:800],
                            "methode": "GET", "feld": "", "quelle": "OpenSearch"})
    return treffer


def _muster(basis):
    t = urlsplit(basis)
    if t.scheme not in ("http", "https") or not t.hostname:
        return []
    pfad = t.path.rstrip("/")
    kandidaten = []
    for name in ("q", "s", "search", "query"):
        kandidaten.append({"name": "", "seite": basis, "suche": urlunsplit(t._replace(query=name + "={titel}", fragment="")),
                           "methode": "GET", "feld": name, "quelle": "Muster (" + name + " an der Adresse)"})
    for pfad_neu, feld in (("/search", "q"), ("/suche", "q"), ("/search", "query"), ("/suche", "suchbegriff")):
        if not pfad or pfad != pfad_neu:
            kandidaten.append({"name": "", "seite": basis,
                               "suche": urlunsplit(t._replace(path=pfad_neu, query=feld + "={titel}", fragment="")),
                               "methode": "GET", "feld": feld,
                               "quelle": "Muster (" + pfad_neu.strip("/") + " mit " + feld + ")"})
    return [k for k in kandidaten if "{titel}" in k["suche"]]


class SeitenSuche:
    def __init__(self, holen=urllib_holen, probe=False):
        self.holen = holen
        self.probe = probe

    def _holen(self, url):
        _ssrf_pruefen_host(url)
        host = urlsplit(url).hostname or ""
        abrufer = netz.Abrufer([".".join(host.split(".")[-2:])], holen=netz.oeffentlich_holen(self.holen), zeitgrenze=15.0)
        return abrufer.abruf(url)

    def _probe(self, kandidat):
        if not self.probe:
            return kandidat
        url = kandidat["suche"].replace("{titel}", quote("h0rst-suchtest"))
        try:
            text = self._holen(url)
            kandidat["probe"] = {"ok": True, "laenge": len(text or ""), "titel": _titel(text or "", url)}
        except Exception as fehler:
            kandidat["probe"] = {"ok": False, "fehler": str(fehler)[:200]}
        return kandidat

    def erkennen(self, url):
        url = str(url or "").strip()
        if not url.lower().startswith(("http://", "https://")):
            raise SeitenSucheFehler("Adresse mit http(s):// eingeben")
        _ssrf_pruefen_host(url)
        try:
            text = self._holen(url)
        except netz.NetzFehler as fehler:
            raise SeitenSucheFehler(str(fehler))
        formen, hinweise = _formulare(text, url)
        kandidaten = formen + _opensearch(text, url, self._holen)
        if not kandidaten:
            kandidaten = _muster(url)
            if kandidaten:
                hinweise.append("Kein Suchformular gefunden – H0rSt schlägt die üblichen URL-Muster vor.")
        gesehen, sauber = set(), []
        for k in kandidaten:
            if k["suche"] not in gesehen:
                gesehen.add(k["suche"])
                sauber.append(k)
        if not sauber:
            hinweise.append("Auf dieser Seite fand H0rSt keine Suchfunktion. Eine Suchseite direkt öffnen oder eine Adresse mit {titel} eintragen.")
        for k in sauber[:3]:
            self._probe(k)
        return {"name": _titel(text, url), "seite": url, "kandidaten": sauber[:12],
                "hinweise": hinweise, "probe": self.probe}
