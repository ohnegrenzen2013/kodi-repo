"""Selbsttest ohne Kodi: python3 -m rezeptserver --test "Big Buck Bunny"

Fuehrt jedes Rezept einzeln aus und zeigt, was gefunden, was aussortiert und welche
Stream-Adresse gebaut wurde. Passwoerter und API-Schluessel werden durch *** ersetzt,
damit die Ausgabe gefahrlos geteilt werden kann.
"""

import os
import time

from .kette import FehlendeEinstellung
from .stremio import App

ZEIGE_MAX = 10


class Schwaerzer:
    """Ersetzt alle Einstellungswerte (Benutzernamen, Passwoerter, Schluessel) in Texten durch ***."""

    def __init__(self, module, einstellungen):
        self.geheim = set()
        for werte in (einstellungen or {}).values():
            for wert in (werte or {}).values():
                if isinstance(wert, str) and wert.strip():
                    self.geheim.add(wert)

    def __call__(self, text):
        text = str(text)
        for wert in sorted(self.geheim, key=len, reverse=True):
            if len(wert) >= 3:
                text = text.replace(wert, "***")
        return text


def _zeit(start):
    return "%.1f s" % (time.time() - start)


def _zeile(treffer, sprachen_von):
    teile = [str(treffer.get("titel", ""))]
    for feld in ("aufloesung", "groesse", "groesse_mb", "jahr"):
        if treffer.get(feld) not in (None, ""):
            teile.append("%s=%s" % (feld, treffer[feld]))
    audio = sprachen_von(treffer)
    if audio:
        teile.append("audio=" + "+".join(audio))
    return " | ".join(teile)


def _protokoll_ausgeben(protokoll, aus, einrueckung="    "):
    aussortiert = [p for p in protokoll if "aussortiert" in p]
    for p in protokoll:
        if "schritt" in p:
            aus("%sSchritt %d %-8s %3d -> %3d" % (einrueckung, p["schritt"], p["baustein"], p["vorher"], p["nachher"]))
    if aussortiert:
        aus("%sAussortiert: %d" % (einrueckung, len(aussortiert)))
        for p in aussortiert[:ZEIGE_MAX]:
            aus("%s  - %s  [%s]" % (einrueckung, p["aussortiert"], p["grund"]))
        if len(aussortiert) > ZEIGE_MAX:
            aus("%s  ... und %d weitere" % (einrueckung, len(aussortiert) - ZEIGE_MAX))


def _konfig_ausgeben(kette, konfig_pfad, aus):
    if konfig_pfad:
        if os.path.isfile(konfig_pfad):
            aus("Nutzerdaten: %s (gefunden)" % os.path.abspath(konfig_pfad))
        else:
            aus("Nutzerdaten: %s NICHT GEFUNDEN - liegt nutzerdaten.db (oder konfig.json) im aktuellen Ordner?"
                % os.path.abspath(konfig_pfad))
    konten = {}
    for modul in kette.module:
        if modul.einstellungen:
            konten.setdefault(modul.konto, set()).update(f["key"] for f in modul.einstellungen)
    for konto in sorted(konten):
        werte = (kette.einstellungen or {}).get(konto, {})
        teile = ["%s=%s" % (k, "***" if str(werte.get(k, "")).strip() else "FEHLT") for k in sorted(konten[konto])]
        aus("  einstellungen.%s: %s" % (konto, ", ".join(teile)))


def lauf(kette, text=None, imdb=None, typ="movie", jahr=None, ausgabe=print, holen=None, konfig_pfad=None):
    """Gibt die Zahl der gefundenen Streams zurueck."""
    from . import sprachen

    schwarz = Schwaerzer(kette.module, kette.einstellungen)

    def aus(zeile=""):
        ausgabe(schwarz(zeile))

    _konfig_ausgeben(kette, konfig_pfad, aus)

    if imdb:
        app = App(kette, holen=holen) if holen else App(kette)
        anfrage = app.anfrage_aus_id(typ, imdb)
    else:
        anfrage = {"text": text, "titel": text, "art": "serie" if typ == "series" else "film"}
        if jahr:
            anfrage["jahr"] = int(jahr)
    aus("Anfrage: %s" % anfrage)
    if not kette.module:
        aus("Keine Rezepte geladen. Stimmt der Ordner (--rezepte)?")
        return 0

    alle_treffer = []
    for finder in kette.rolle("finder"):
        aus()
        aus("== Finder %s (%s) ==" % (finder.name, finder.id))
        protokoll = []
        start = time.time()
        try:
            treffer = kette.fuehre_modul_aus(finder, anfrage, protokoll)
        except FehlendeEinstellung as fehler:
            aus("    uebersprungen: %s" % fehler)
            continue
        except Exception as fehler:
            _protokoll_ausgeben(protokoll, aus)
            aus("    FEHLER nach %s: %s" % (_zeit(start), fehler))
            continue
        _protokoll_ausgeben(protokoll, aus)
        treffer = [t for t in treffer if t.get("titel") and t.get("ref")]
        for t in treffer:
            t.setdefault("quelle", finder.id)
        aus("    Treffer: %d (%s)" % (len(treffer), _zeit(start)))
        for t in treffer[:ZEIGE_MAX]:
            aus("    * " + _zeile(t, sprachen.audio_von))
        if len(treffer) > ZEIGE_MAX:
            aus("    ... und %d weitere" % (len(treffer) - ZEIGE_MAX))
        alle_treffer.extend(treffer[:3])

    streams = 0
    for t in alle_treffer:
        aus()
        aus("== Aufloesen: %s ==" % t["titel"])
        passende = [m for m in kette.rolle("aufloeser") if m.passt(t)]
        if not passende:
            aus("    Kein Aufloeser passt (quelle=%s)" % t.get("quelle"))
            continue
        for modul in passende:
            protokoll = []
            start = time.time()
            try:
                ergebnis = kette.fuehre_modul_aus(modul, t, protokoll)
            except FehlendeEinstellung as fehler:
                aus("    %s: uebersprungen: %s" % (modul.id, fehler))
                continue
            except Exception as fehler:
                _protokoll_ausgeben(protokoll, aus)
                aus("    %s: FEHLER nach %s: %s" % (modul.id, _zeit(start), fehler))
                continue
            _protokoll_ausgeben(protokoll, aus)
            fertig = [s for s in (kette.mit_zugang(modul, s) for s in ergebnis if s.get("url")) if s]
            aus("    %s: %d Stream(s) (%s)" % (modul.id, len(fertig), _zeit(start)))
            for s in fertig[:3]:
                aus("    -> %s" % s["url"])
                for name in (s.get("header") or {}):
                    aus("       Header %s: ***" % name)
            streams += len(fertig)
            if fertig:
                break

    if alle_treffer:
        for anreicherer in kette.rolle("anreicherer"):
            aus()
            aus("== Anreicherer %s (%s) ==" % (anreicherer.name, anreicherer.id))
            eingabe = dict(alle_treffer[0])
            eingabe.update(anfrage)
            if "untertitel" in anreicherer.gibt:
                eingabe["sprachen"] = "de,en"
            if not anreicherer.passt(eingabe):
                aus("    passt nicht zu dieser Anfrage, uebersprungen")
                continue
            protokoll = []
            start = time.time()
            try:
                ergebnis = kette.fuehre_modul_aus(anreicherer, eingabe, protokoll)
            except FehlendeEinstellung as fehler:
                aus("    uebersprungen: %s" % fehler)
                continue
            except Exception as fehler:
                _protokoll_ausgeben(protokoll, aus)
                aus("    FEHLER nach %s: %s" % (_zeit(start), fehler))
                continue
            _protokoll_ausgeben(protokoll, aus)
            if not ergebnis:
                aus("    kein Ergebnis")
            for eintrag in ergebnis[:3]:
                aus("    * " + ", ".join("%s=%s" % (k, str(v)[:60]) for k, v in eintrag.items()))

    aus()
    aus("Ergebnis: %d Treffer geprueft, %d Stream(s) gebaut" % (len(alle_treffer), streams))
    return streams
