"""Shizuku 13.6.0-R4 (Fork yangFenTuoZi, Apache-2.0): ADB- und Root-Rechte fuer normale Apps.

Shizuku startet einen Dienst per ADB oder Root. Apps erhalten einen Binder und
duerfen System-APIs mit erhoehten Rechten aufrufen. Der Fork ergaenzt unter
anderem einen zufaelligen Ablageordner unter /data/local/tmp, das Aufraeumen von
shizuku_starter, ADB-Root auf userdebug-ROMs, einen eigenen TCP/IP-Port und den
Selbststart ueber Wireless Debugging. H0rSt uebernimmt keinen fremden Code und
liefert keine APK mit; es merkt sich die Einrichtung und baut rish-Befehle fuer
seine eigenen Werkzeuge.
"""

import re
import shlex

NAME = "Shizuku"
STAND = "13.6.0-R4 (Fork yangFenTuoZi)"
PAKET = "moe.shizuku.privileged.api"
LIZENZ = "Apache-2.0"
URL = "https://github.com/yangFenTuoZi/Shizuku"
OFFIZIELL = "https://github.com/RikkaApps/Shizuku"
ANLEITUNG = "https://shizuku.rikka.app/guide/setup/"
RELEASES = "https://github.com/yangFenTuoZi/Shizuku/releases/latest"
APK_SEITE = "https://github.com/yangFenTuoZi/Shizuku/releases/latest"
PERMISSION = "moe.shizuku.manager.permission.API_V23"
RISH = "rish"
PORT = ""
FARBEN = {"original": ("#b1b8df", "#1c1b1f"), "indigo": ("#3f51b5", "#ffffff"),
          "flieder": ("#d0bcff", "#381e72")}
WERKZEUGE = [
    ("System-APIs", "Apps rufen versteckte System-Schnittstellen auf, ohne selbst Root zu brauchen."),
    ("ADB-Start", "Start per Computer oder Wireless Debugging (Android 11+); nach jedem Neustart zu wiederholen."),
    ("Root-Start", "Auf gerooteten Geraeten startet Shizuku selbst und kann den Start uebernehmen."),
    ("rish", "Shell-Werkzeug: Befehle wie pm, settings und cmd appops laufen mit Shizuku-Rechten."),
    ("Berechtigungen", "Jede App fragt einmal; die Freigabe laesst sich in Shizuku jederzeit entziehen."),
]
BEFEHLE = [
    {"id": "installieren", "name": "APK installieren", "vorlage": "pm install -r {pfad}",
     "gate": "sh_installieren", "felder": ["pfad"]},
    {"id": "deinstallieren", "name": "App deinstallieren", "vorlage": "pm uninstall {paket}",
     "gate": "sh_deinstallieren", "felder": ["paket"]},
    {"id": "rechte_geben", "name": "Berechtigung erteilen", "vorlage": "pm grant {paket} {recht}",
     "gate": "sh_rechte", "felder": ["paket", "recht"]},
    {"id": "rechte_nehmen", "name": "Berechtigung entziehen", "vorlage": "pm revoke {paket} {recht}",
     "gate": "sh_rechte", "felder": ["paket", "recht"]},
    {"id": "einstellung", "name": "Systemeinstellung setzen", "vorlage": "settings put {bereich} {schluessel} {wert}",
     "gate": "sh_einstellungen", "felder": ["bereich", "schluessel", "wert"]},
    {"id": "appops", "name": "App-Op setzen", "vorlage": "cmd appops set {paket} {op} {modus}",
     "gate": "sh_einstellungen", "felder": ["paket", "op", "modus"]},
    {"id": "deaktivieren", "name": "App deaktivieren", "vorlage": "pm disable-user --user 0 {paket}",
     "gate": "sh_gefaehrlich", "felder": ["paket"]},
    {"id": "aktivieren", "name": "App aktivieren", "vorlage": "pm enable {paket}",
     "gate": "sh_gefaehrlich", "felder": ["paket"]},
    {"id": "daten_loeschen", "name": "App-Daten loeschen", "vorlage": "pm clear {paket}",
     "gate": "sh_gefaehrlich", "felder": ["paket"]},
]
_PAKET = re.compile(r"^[A-Za-z0-9_]+(?:\.[A-Za-z0-9_]+)*$")
_RECHT = re.compile(r"^[A-Za-z0-9_]+(?:\.[A-Za-z0-9_]+)*$")
_SCHLUESSEL = re.compile(r"^[A-Za-z0-9_.-]+$")
_WORT = re.compile(r"^[A-Za-z]+$")
_RISH = re.compile(r"^[A-Za-z0-9_./-]+$")
_BEREICHE = {"system", "secure", "global"}


def _sauber(wert, laenge=200):
    if not isinstance(wert, str):
        raise ValueError("Wert fehlt.")
    text = wert.strip()
    if not text or len(text) > laenge or any(z in text for z in ("\n", "\r", "\0")) or text.startswith("-"):
        raise ValueError("Wert ist leer, zu lang oder unzulaessig.")
    return text


def _pruefe(feld, wert):
    text = _sauber(wert, 400 if feld == "pfad" else 200)
    if feld == "paket" and not _PAKET.fullmatch(text):
        raise ValueError("Paketname ungueltig (Beispiel: com.example.app).")
    if feld == "recht" and not _RECHT.fullmatch(text):
        raise ValueError("Berechtigung ungueltig (Beispiel: android.permission.WRITE_SECURE_SETTINGS).")
    if feld == "bereich" and text not in _BEREICHE:
        raise ValueError("Bereich muss system, secure oder global sein.")
    if feld in ("schluessel", "op") and not _SCHLUESSEL.fullmatch(text):
        raise ValueError("Name ungueltig (nur Buchstaben, Ziffern, Punkt, Strich).")
    if feld == "modus" and not _WORT.fullmatch(text):
        raise ValueError("Modus ungueltig (Beispiel: allow, deny, ignore).")
    if feld == "pfad" and not text.startswith(("/", "content://", "file://")):
        raise ValueError("Pfad muss mit /, content:// oder file:// beginnen.")
    return text


def rish_befehl(werte=None):
    w = werte if isinstance(werte, dict) else {}
    name = str(w.get("sh_rish") or RISH).strip() or RISH
    return name if _RISH.fullmatch(name) and not name.startswith("-") else RISH


def befehl_bauen(werte=None, op=None, felder=None):
    """Einen freigegebenen rish-Befehl bauen; ohne Freigabe bleibt er gesperrt."""
    w = werte if isinstance(werte, dict) else {}
    f = felder if isinstance(felder, dict) else {}
    eintrag = next((b for b in BEFEHLE if b["id"] == op), None)
    if eintrag is None:
        return {"erlaubt": False, "befehl": "", "text": "", "hinweis": "Unbekannter Befehl."}
    if w.get("sh_an") is not True:
        return {"erlaubt": False, "befehl": "", "text": "", "hinweis": "Shizuku ist in den Einstellungen ausgeschaltet."}
    if w.get(eintrag["gate"]) is not True:
        return {"erlaubt": False, "befehl": "", "text": "",
                "hinweis": "In den Einstellungen nicht freigegeben (%s einschalten)." % eintrag["gate"]}
    ersetzt = {}
    for name in eintrag["felder"]:
        try:
            ersetzt[name] = shlex.quote(_pruefe(name, f.get(name)))
        except ValueError as fehler:
            return {"erlaubt": False, "befehl": "", "text": "", "hinweis": str(fehler)}
    text = eintrag["vorlage"].format(**ersetzt)
    return {"erlaubt": True, "befehl": "%s -c %s" % (rish_befehl(w), shlex.quote(text)), "text": text,
            "hinweis": "Im Terminal der Shizuku-App oder in Termux ausfuehren; rish braucht die Freigabe der "
                       "aufrufenden App."}


def zustand(werte=None):
    w = werte if isinstance(werte, dict) else {}
    befehle = [{"id": b["id"], "name": b["name"], "felder": list(b["felder"]),
                "an": w.get(b["gate"]) is True} for b in BEFEHLE]
    return {"name": NAME, "stand": STAND, "paket": str(w.get("sh_paket") or PAKET), "lizenz": LIZENZ,
            "url": URL, "offiziell": OFFIZIELL, "anleitung": ANLEITUNG,
            "releases": str(w.get("sh_apk_url") or APK_SEITE), "permission": PERMISSION,
            "rish": rish_befehl(w), "modus": str(w.get("sh_modus") or "auto"),
            "port": str(w.get("sh_tcpip_port") or PORT), "an": w.get("sh_an") is True,
            "werte": {k: w.get(k) for k in ("sh_start_on_boot", "sh_start_on_boot_wireless", "sh_adb_root",
                                            "sh_nachtmodus", "sh_schwarz", "sh_systemfarbe",
                                            "sh_zufallsordner", "sh_starter_entfernen")},
            "befehle": befehle, "farben": {k: list(v) for k, v in FARBEN.items()},
            "werkzeuge": [{"name": n, "text": t} for n, t in WERKZEUGE]}
