"""Bereich "Sicherheit": Netzweg (Proxy, Tor, I2P), Notbremse, VPN-Erkennung und Sicherheits-Check.

H0rSt selbst geht ins Internet, um Anbieter abzufragen (Indexer, Hoster, Addons, Ab-18-Seiten, Debrid).
Ist ein Netzweg gewaehlt, laufen alle diese Verbindungen darueber:

  * SOCKS5 (Tor ueber Orbot/tor, I2P ueber i2pd, SOCKS5 von VPN-Anbietern, SSH -D) oder HTTP-Proxy (CONNECT).
    Den Namen loest der Proxy auf (keine DNS-Anfragen am Netzweg vorbei), TLS bleibt Ende-zu-Ende.
  * .onion-Adressen gehen ueber den Tor-Weg, .i2p-Adressen ueber den I2P-Weg, auch ohne allgemeinen Netzweg.
  * Das Heimnetz bleibt direkt: localhost, private IP-Adressen, .local/.lan/.home/.fritz.box/.home.arpa und
    Namen ohne Punkt. So erreicht H0rSt Sonarr, NZBGet oder die FRITZ!Box weiter, ohne sie an einen Proxy zu geben.
  * Faellt der Netzweg aus, geht nichts direkt raus (kein stilles Zurueckfallen).
  * Notbremse: H0rSt geht nur ins Internet, wenn ein VPN laeuft oder ein Netzweg gesetzt ist.

Umgesetzt wird das an der Stelle, an der jede Verbindung entsteht (socket.create_connection), damit es
fuer urllib, http.client und NNTP gleichermassen gilt. yt-dlp bekommt den Weg als Proxy-Option.
Videos, die ein Player direkt laedt, schuetzt nur ein VPN (in der App: WireGuard, siehe Tab Sicherheit).
Die Einstellungen liegen in den Nutzerdaten unter "sicherheit".
"""

from .sicherheit_grund import *
from .sicherheit_grund import _ORIGINAL, _SOCKS_FEHLER
from .sicherheit_wege import NETZWEG, Netzweg, Weg, anbieter_pruefen, anwenden, installieren, vpn_schnittstelle, weg_aus_anbieter, wireguard_pruefen, _freundlich, _verbinden
from .sicherheit_pruefung import zustand


def _holen(url, zeit=15):
    import urllib.request
    anfrage = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 H0rSt", "Accept": "application/json"})
    with urllib.request.urlopen(anfrage, timeout=zeit) as antwort:
        return json.loads(antwort.read(65536).decode("utf-8", "replace"))


def pruefen(holen=None):
    """Was sehen Anbieter von H0rSt? IP, Ort, Betreiber, Tor ja/nein (ueber den eingestellten Weg)."""
    holen = holen or _holen
    start = time.time()

    def ip():
        try:
            d = holen(PRUEF_IP)
            return {"ip": d.get("ip", ""), "land": d.get("country", ""), "stadt": d.get("city", ""),
                    "betreiber": d.get("organization", ""), "mullvad": bool(d.get("mullvad_exit_ip")),
                    "quelle": "am.i.mullvad.net"}
        except Exception:
            d = holen(PRUEF_IP_ERSATZ)
            return {"ip": d.get("ip", ""), "land": d.get("country", ""), "stadt": d.get("city", ""),
                    "betreiber": d.get("org", ""), "mullvad": False, "quelle": "ipinfo.io"}

    def tor():
        return bool(holen(PRUEF_TOR).get("IsTor"))

    ergebnis = {"fehler": ""}
    with ThreadPoolExecutor(max_workers=2) as pool:
        a, b = pool.submit(ip), pool.submit(tor)
        try:
            ergebnis.update(a.result())
        except Exception as f:
            ergebnis["fehler"] = _freundlich(f)
        try:
            ergebnis["tor"] = b.result()
        except Exception:
            ergebnis["tor"] = None
    ergebnis["dauer"] = round(time.time() - start, 1)
    return ergebnis
