"""Grundlage von Sicherheit: Importe, Logger, Konstanten, Fehler und die Lan-Erkennung.
Alles hier wird samt Importen wieder exportiert (rezeptserver.sicherheit.*)."""


import base64
import ipaddress
import json
import logging
import os
import socket
import struct
import threading
import time
from concurrent.futures import ThreadPoolExecutor

log = logging.getLogger("rezeptserver")

SCHLUESSEL = "sicherheit"
STANDARD = {"weg": "", "onion": "", "i2p": "", "notbremse": False, "wireguard": "", "wg_umfang": "geraet"}
UMFAENGE = {"geraet": "ganzes Gerät", "h0rst": "nur H0rSt (Server und interner Player)"}
# Anbieter-Typen, die als Netzweg taugen
WEG_TYPEN = ("socks5", "http-proxy", "tor", "i2p")
LAN_ENDUNGEN = (".local", ".lan", ".home", ".internal", ".intranet", ".fritz.box", ".home.arpa", ".localdomain")
VPN_SCHNITTSTELLEN = ("tun", "wg", "ppp", "utun", "ipsec", "tap", "nordlynx", "proton", "mullvad", "tailscale")
# Private DNS (DNS-over-TLS) fuer Android 9+: Hostname zum Eintragen
PRIVATE_DNS = [
    {"name": "Mullvad – Werbung & Tracker blocken", "host": "adblock.dns.mullvad.net",
     "info": "ohne Protokolle, blockt Werbung und Tracker"},
    {"name": "Mullvad – Basis", "host": "base.dns.mullvad.net", "info": "blockt Werbung, Tracker und Schadseiten"},
    {"name": "Mullvad – ohne Filter", "host": "dns.mullvad.net", "info": "ohne Protokolle, filtert nichts"},
    {"name": "Quad9", "host": "dns.quad9.net", "info": "blockt Schadseiten, Sitz in der Schweiz"},
    {"name": "AdGuard", "host": "dns.adguard-dns.com", "info": "blockt Werbung und Tracker"},
    {"name": "Cloudflare", "host": "one.one.one.one", "info": "schnell, filtert nichts"},
]
PRUEF_IP = "https://am.i.mullvad.net/json"
PRUEF_IP_ERSATZ = "https://ipinfo.io/json"
PRUEF_TOR = "https://check.torproject.org/api/ip"

_ORIGINAL = socket.create_connection
_SOCKS_FEHLER = {1: "allgemeiner Fehler", 2: "nicht erlaubt", 3: "Netz nicht erreichbar", 4: "Host nicht erreichbar",
                 5: "Verbindung abgelehnt", 6: "Zeit abgelaufen", 7: "Befehl nicht unterstützt",
                 8: "Adressart nicht unterstützt"}


class SicherheitsFehler(ValueError):
    pass


class Gesperrt(OSError):
    """Verbindung bewusst nicht aufgebaut (Notbremse, fehlender Weg). OSError, damit Aufrufer sie wie
    jeden Netzfehler behandeln."""


def pruefe(einstellungen):
    e = dict(STANDARD)
    if isinstance(einstellungen, dict):
        e.update({k: einstellungen[k] for k in STANDARD if k in einstellungen})
    for k in ("weg", "onion", "i2p", "wireguard"):
        e[k] = str(e[k] or "")[:64]
    e["notbremse"] = e["notbremse"] is True
    if e["wg_umfang"] not in UMFAENGE:
        raise SicherheitsFehler("wg_umfang muss %s sein" % " oder ".join(UMFAENGE))
    return e


def ist_lan(host):
    """Heimnetz ohne DNS-Abfrage erkennen (eine Abfrage wuerde am Netzweg vorbei gehen)."""
    host = str(host or "").strip("[]").lower().rstrip(".")
    if not host or host == "localhost" or "." not in host and ":" not in host:
        return True
    if host.endswith(LAN_ENDUNGEN) or host.endswith(".localhost"):
        return True
    try:
        ip = ipaddress.ip_address(host.split("%")[0])
    except ValueError:
        return False
    return ip.is_private or ip.is_loopback or ip.is_link_local
