"""Sicherheits-Check: Was sehen Anbieter von H0rSt (IP, Ort, Betreiber, Tor) und der Status."""

from .sicherheit_grund import (
    PRIVATE_DNS,
    SCHLUESSEL,
    UMFAENGE,
    WEG_TYPEN,
    ist_lan,
    pruefe,
)

from .sicherheit_wege import NETZWEG, vpn_schnittstelle

def zustand(daten, token=False, ab18_pin=None):
    """Einstellungen, Wahlmoeglichkeiten und die Liste "Sicher unterwegs" (ohne Netzabfrage)."""
    e = pruefe(daten.get(SCHLUESSEL))
    eigene = daten.get("anbieter") or {}
    werte = daten.get("einstellungen") or {}
    wege = [{"id": aid, "name": a["name"], "typ": a.get("typ", "")} for aid, a in eigene.items()
            if a.get("typ") in WEG_TYPEN]
    wireguard = [{"id": aid, "name": a["name"]} for aid, a in eigene.items() if a.get("typ") == "wireguard"]
    vpn = NETZWEG.vpn_laeuft()
    schnittstellen = vpn_schnittstelle() if NETZWEG.android_vpn is None else []
    unsicher = []
    for aid, a in eigene.items():
        w = werte.get(aid) or {}
        url = str(w.get("url", ""))
        if url.lower().startswith("http://"):
            from urllib.parse import urlsplit
            if not ist_lan(urlsplit(url).hostname or ""):
                unsicher.append("%s (http:// ohne Verschlüsselung)" % a["name"])
        if a.get("typ") == "nntp" and w.get("host") and not ist_lan(w.get("host")) and str(w.get("ssl", "")) != "1":
            unsicher.append("%s (Usenet ohne SSL)" % a["name"])
    geschuetzt = vpn or bool(e["weg"])
    liste = [
        {"ok": geschuetzt, "text": "Verbindungen von H0rSt laufen über " + (
            "VPN" if vpn else "den Netzweg") if geschuetzt else "Kein VPN und kein Netzweg: Anbieter sehen deine echte IP"},
        {"ok": e["notbremse"] or bool(e["weg"]), "text": "Notbremse an: ohne Schutz geht nichts raus" if e["notbremse"]
            else ("Netzweg fällt nie still auf direkt zurück" if e["weg"] else "Notbremse aus")},
        {"ok": not unsicher, "text": "Alle Anbieter verschlüsselt" if not unsicher
            else "Unverschlüsselt: " + ", ".join(unsicher[:6])},
        {"ok": not token or vpn, "text": "Im Heimnetz freigegeben: unterwegs nur mit VPN nutzen (Token schützt den Zugriff)"
            if token else "Nicht im Netz freigegeben, nur auf diesem Gerät erreichbar"},
    ]
    if ab18_pin is not None:
        liste.append({"ok": ab18_pin, "text": "Ab 18 mit PIN geschützt" if ab18_pin else "Ab 18 ohne PIN"})
    if NETZWEG.android_privat_dns is not None:
        liste.append({"ok": NETZWEG.android_privat_dns, "text": "Privates DNS (DNS-over-TLS) aktiv"
                      if NETZWEG.android_privat_dns else "Privates DNS aus: DNS-Anfragen laufen unverschlüsselt"})
    return {"einstellungen": e, "wege": wege, "wireguard": wireguard, "umfaenge": UMFAENGE,
            "vpn": vpn, "vpn_quelle": "App" if NETZWEG.android_vpn is not None else ", ".join(schnittstellen),
            "aktiv": NETZWEG.aktiv(), "gesperrt": NETZWEG.gesperrt, "liste": liste, "private_dns": PRIVATE_DNS,
            "weg_name": NETZWEG.weg.name if NETZWEG.weg else ""}


