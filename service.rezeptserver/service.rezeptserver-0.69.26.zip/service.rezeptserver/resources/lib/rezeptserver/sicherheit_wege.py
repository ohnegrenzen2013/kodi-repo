"""Netzweg: Proxy/Klassen Weg und Netzweg, die Umleitung von socket.create_connection
und das Anwenden der Einstellungen."""

from .sicherheit_grund import (
    Gesperrt,
    SCHLUESSEL,
    SicherheitsFehler,
    VPN_SCHNITTSTELLEN,
    WEG_TYPEN,
    _ORIGINAL,
    _SOCKS_FEHLER,
    base64,
    ipaddress,
    ist_lan,
    log,
    os,
    pruefe,
    socket,
    struct,
    threading,
    time,
)

def wireguard_pruefen(text):
    """WireGuard-Konfiguration grob pruefen (ohne Verbindung): (ok, meldung)."""
    abschnitt, interface, peers, fehlt = "", {}, [], []
    for zeile in str(text or "").splitlines():
        zeile = zeile.split("#", 1)[0].strip()
        if not zeile:
            continue
        if zeile.startswith("["):
            abschnitt = zeile.strip("[]").strip().lower()
            if abschnitt == "peer":
                peers.append({})
            continue
        schluessel, _, wert = zeile.partition("=")
        ziel = interface if abschnitt == "interface" else (peers[-1] if abschnitt == "peer" and peers else None)
        if ziel is not None:
            ziel[schluessel.strip().lower()] = wert.strip()
    if "privatekey" not in interface:
        fehlt.append("[Interface] PrivateKey")
    if "address" not in interface:
        fehlt.append("[Interface] Address")
    if not peers:
        fehlt.append("[Peer]")
    for p in peers:
        if "publickey" not in p:
            fehlt.append("[Peer] PublicKey")
        if "endpoint" not in p:
            fehlt.append("[Peer] Endpoint")
    if fehlt:
        return False, "Konfiguration unvollständig: " + ", ".join(sorted(set(fehlt)))
    if len(base64.b64decode(interface["privatekey"] + "==")[:33]) != 32:
        return False, "PrivateKey ist kein WireGuard-Schlüssel"
    erlaubt = ", ".join(p.get("allowedips", "") for p in peers)
    voll = "0.0.0.0/0" in erlaubt
    return True, "Gültig: %d Server (%s), %s" % (len(peers), ", ".join(p["endpoint"] for p in peers),
                                                 "ganzer Verkehr" if voll else "nur " + erlaubt)


def weg_aus_anbieter(eintrag, werte):
    """Weg aus einem eigenen Anbieter (Typ socks5/tor/i2p -> SOCKS5, http-proxy -> HTTP).
    I2P auf Port 4444 ist der HTTP-Proxy (Java-I2P und i2pd), SOCKS hat nur i2pd (4447)."""
    typ = eintrag.get("typ", "")
    if typ not in WEG_TYPEN:
        raise SicherheitsFehler("%s ist kein Netzweg (Typ %s)" % (eintrag.get("name"), typ or "-"))
    i2p_http = typ == "i2p" and (str(werte.get("art", "")) == "http" or str(werte.get("port", "")).strip() == "4444")
    art = "http" if typ == "http-proxy" or i2p_http else "socks5"
    return Weg(art, werte.get("host"), werte.get("port"), werte.get("user", ""), werte.get("pass", ""),
               eintrag.get("name", ""), typ)


def vpn_schnittstelle():
    """Laeuft ein VPN? Auf Linux/Pi/PC an den Netzschnittstellen erkannt (wg0, tun0, ppp0 ...)."""
    try:
        namen = [n for _, n in socket.if_nameindex()]
    except (OSError, AttributeError):
        namen = []
    if not namen and os.path.isdir("/sys/class/net"):
        try:
            namen = os.listdir("/sys/class/net")
        except OSError:
            namen = []
    return [n for n in namen if n.lower().startswith(VPN_SCHNITTSTELLEN)]


class Weg:
    """Ein Proxy: SOCKS5 (mit Namensaufloesung beim Proxy) oder HTTP CONNECT."""

    def __init__(self, art, host, port, benutzer="", passwort="", name="", typ=""):
        if art not in ("socks5", "http"):
            raise SicherheitsFehler("Unbekannte Proxy-Art: %s" % art)
        self.art, self.host, self.port = art, str(host or "").strip(), int(port or 0)
        self.benutzer, self.passwort, self.name = benutzer or "", passwort or "", name or host
        self.typ = typ or art
        if not self.host or not 0 < self.port < 65536:
            raise SicherheitsFehler("%s: Server und Port fehlen" % (name or "Proxy"))

    def __repr__(self):
        return "Weg(%s %s:%d)" % (self.art, self.host, self.port)

    def ytdlp(self):
        """Proxy-Adresse fuer yt-dlp (socks5h: Namen loest der Proxy auf)."""
        from urllib.parse import quote
        zugang = "%s:%s@" % (quote(self.benutzer, safe=""), quote(self.passwort, safe="")) if self.benutzer else ""
        return "%s://%s%s:%d" % ("socks5h" if self.art == "socks5" else "http", zugang, self.host, self.port)

    def verbinden(self, host, port, zeit=None):
        roh = _ORIGINAL((self.host, self.port), zeit if isinstance(zeit, (int, float)) else 20)
        try:
            if self.art == "socks5":
                self._socks5(roh, host, port)
            else:
                self._connect(roh, host, port)
        except Exception:
            roh.close()
            raise
        return roh

    @staticmethod
    def _lesen(s, n):
        daten = b""
        while len(daten) < n:
            teil = s.recv(n - len(daten))
            if not teil:
                raise OSError("Proxy hat die Verbindung geschlossen")
            daten += teil
        return daten

    def _socks5(self, s, host, port):
        methoden = b"\x00\x02" if self.benutzer else b"\x00"
        s.sendall(b"\x05" + bytes([len(methoden)]) + methoden)
        version, methode = self._lesen(s, 2)
        if version != 5 or methode == 0xFF:
            raise OSError("SOCKS5: keine passende Anmeldung (%s)" % self.name)
        if methode == 2:
            b, p = self.benutzer.encode("utf-8")[:255], self.passwort.encode("utf-8")[:255]
            s.sendall(b"\x01" + bytes([len(b)]) + b + bytes([len(p)]) + p)
            if self._lesen(s, 2)[1] != 0:
                raise OSError("SOCKS5: Benutzer oder Passwort falsch (%s)" % self.name)
        try:
            ip = ipaddress.ip_address(host)
            ziel = (b"\x01" if ip.version == 4 else b"\x04") + ip.packed
        except ValueError:
            name = host.encode("idna")
            ziel = b"\x03" + bytes([len(name)]) + name  # Name geht an den Proxy (kein DNS-Leck)
        s.sendall(b"\x05\x01\x00" + ziel + struct.pack(">H", int(port)))
        version, antwort, _, art = self._lesen(s, 4)
        if antwort != 0:
            raise OSError("SOCKS5 (%s): %s" % (self.name, _SOCKS_FEHLER.get(antwort, "Fehler %d" % antwort)))
        laenge = {1: 4, 4: 16}.get(art)
        self._lesen(s, (laenge if laenge else self._lesen(s, 1)[0]) + 2)

    def _connect(self, s, host, port):
        ziel = "[%s]:%d" % (host, port) if ":" in host else "%s:%d" % (host, port)
        anfrage = "CONNECT %s HTTP/1.1\r\nHost: %s\r\n" % (ziel, ziel)
        if self.benutzer:
            zugang = base64.b64encode(("%s:%s" % (self.benutzer, self.passwort)).encode("utf-8")).decode("ascii")
            anfrage += "Proxy-Authorization: Basic %s\r\n" % zugang
        s.sendall((anfrage + "\r\n").encode("utf-8"))
        kopf = b""
        while b"\r\n\r\n" not in kopf:
            teil = s.recv(1)
            if not teil:
                raise OSError("HTTP-Proxy hat die Verbindung geschlossen")
            kopf += teil
            if len(kopf) > 16384:
                raise OSError("HTTP-Proxy: Antwort zu lang")
        zeile = kopf.split(b"\r\n", 1)[0].decode("latin-1")
        teile = zeile.split()
        if len(teile) < 2 or not teile[1].startswith("2"):
            raise OSError("HTTP-Proxy (%s): %s" % (self.name, zeile))


class Netzweg:
    """Haelt die aktuelle Wahl und entscheidet je Verbindung."""

    def __init__(self):
        self._sperre = threading.Lock()
        self.weg = self.onion = self.i2p = None
        self.notbremse = False
        self.android_vpn = None  # von der App gemeldet (None = unbekannt)
        self.android_privat_dns = None
        self.gesperrt = 0  # Zaehler fuer den Status

    def setzen(self, weg=None, onion=None, i2p=None, notbremse=False):
        with self._sperre:
            self.weg, self.onion, self.i2p, self.notbremse = weg, onion, i2p, bool(notbremse)
        installieren(self.aktiv())

    def aktiv(self):
        return bool(self.weg or self.onion or self.i2p or self.notbremse)

    def vpn_laeuft(self):
        if self.android_vpn is not None:
            return bool(self.android_vpn)
        return bool(vpn_schnittstelle())

    def weg_fuer(self, host):
        """None = direkt, sonst Weg; Gesperrt, wenn die Verbindung nicht raus darf."""
        host = str(host or "").strip("[]").lower().rstrip(".")
        if host.endswith(".onion"):
            weg = self.onion or (self.weg if self.weg is not None and self.weg.typ == "tor" else None)
            if weg is None:
                raise Gesperrt("Für .onion-Adressen unter Sicherheit einen Tor-Weg einrichten")
            return weg
        if host.endswith(".i2p"):
            if self.i2p is None and self.weg is not None and self.weg.typ == "i2p":
                return self.weg
            if self.i2p is None:
                raise Gesperrt("Für .i2p-Adressen unter Sicherheit einen I2P-Weg einrichten")
            return self.i2p
        if ist_lan(host):
            return None
        if self.weg is not None:
            return self.weg
        if self.notbremse and not self.vpn_laeuft():
            self.gesperrt += 1
            raise Gesperrt("Notbremse: kein VPN und kein Netzweg aktiv, %s wird nicht abgefragt" % host)
        return None

    def ytdlp_proxy(self):
        """Proxy fuer yt-dlp oder None; wirft Gesperrt wie weg_fuer."""
        if self.weg is not None:
            return self.weg.ytdlp()
        if self.notbremse and not self.vpn_laeuft():
            raise Gesperrt("Notbremse: kein VPN und kein Netzweg aktiv")
        return None


NETZWEG = Netzweg()


def _verbinden(adresse, timeout=socket._GLOBAL_DEFAULT_TIMEOUT, source_address=None, *rest, **kw):
    weg = NETZWEG.weg_fuer(adresse[0])
    if weg is None:
        return _ORIGINAL(adresse, timeout, source_address, *rest, **kw)
    return weg.verbinden(adresse[0], adresse[1], timeout)


def installieren(an):
    """Leitet socket.create_connection um (nur wenn etwas eingestellt ist)."""
    socket.create_connection = _verbinden if an else _ORIGINAL


def anwenden(daten):
    """Einstellungen aus den Nutzerdaten wirksam machen. Gibt die Fehlermeldung zurueck oder ''."""
    e = pruefe(daten.get(SCHLUESSEL))
    eigene = daten.get("anbieter") or {}
    werte = daten.get("einstellungen") or {}
    wege, fehler = {}, ""
    for schluessel in ("weg", "onion", "i2p"):
        aid = e[schluessel]
        if not aid:
            continue
        try:
            if aid not in eigene:
                raise SicherheitsFehler("Netzweg %s gibt es nicht mehr" % aid)
            wege[schluessel] = weg_aus_anbieter(eigene[aid], werte.get(aid) or {})
        except SicherheitsFehler as f:
            fehler = str(f)
            # ein kaputter Weg darf nicht still zu "direkt" werden: Notbremse greift
            e["notbremse"] = True
    NETZWEG.setzen(wege.get("weg"), wege.get("onion"), wege.get("i2p"), e["notbremse"])
    if fehler:
        log.warning("Sicherheit: %s (Notbremse greift)", fehler)
    return fehler


def _freundlich(fehler):
    """Fehler beim Pruefen so, dass man weiss, was zu tun ist."""
    text = str(getattr(fehler, "reason", "") or fehler)
    weg = NETZWEG.weg
    if weg is not None and ("refused" in text.lower() or "abgelehnt" in text.lower() or "111" in text):
        hilfe = " Läuft Orbot bzw. der Dienst tor?" if weg.typ == "tor" else (
            " Läuft i2pd?" if weg.typ == "i2p" else " Stimmen Server und Port?")
        return "Netzweg %s (%s:%d) nicht erreichbar.%s" % (weg.name, weg.host, weg.port, hilfe)
    if isinstance(fehler, Gesperrt) or isinstance(getattr(fehler, "reason", None), Gesperrt):
        return text
    return text[:300]


def anbieter_pruefen(eintrag, werte):
    """Verbindungstest fuer Sicherheits-Anbieter: (ok, meldung)."""
    if eintrag.get("typ") == "wireguard":
        return wireguard_pruefen(werte.get("konfig"))
    weg = weg_aus_anbieter(eintrag, werte)
    ziel = ("check.torproject.org", 443)
    start = time.time()
    s = weg.verbinden(ziel[0], ziel[1], 20)
    s.close()
    return True, "%s erreichbar, Verbindung durch den Proxy in %.1f s" % (weg.name, time.time() - start)


