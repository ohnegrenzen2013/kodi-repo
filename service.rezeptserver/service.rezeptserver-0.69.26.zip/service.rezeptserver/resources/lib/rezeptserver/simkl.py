"""SIMKL: Watchlist, Verlauf und Weiterschauen mit SIMKL abgleichen (Idee aus NuvioTV, eigener Code).

Anmelden per PIN: H0rSt zeigt einen Code, den gibst du auf simkl.com/pin ein. Dafuer braucht H0rSt eine eigene
SIMKL-App (simkl.com/oauth/request); deren Client ID traegt der Admin einmal ein, verbinden kann sich dann jedes
Profil selbst. SIMKL liefert Watchlist, Verlauf und Wiedergabestellen; H0rSt schickt neue Merkliste-Eintraege,
gesehene Filme und die aktuelle Stelle zurueck. Serien kommen als ganzer Verlauf nur von SIMKL herein.

Nutzerdaten "simkl": {"app": {"client_id"},
                      "konten": {"<profil-id oder ''>": {"access_token", "benutzer", "zuletzt", "fehler",
                                                         "basis": {...}}}}
"""

import threading

from . import sehen
from .simkl_grund import (ABSTAND, MAX_SCROBBLE, SCROBBLE_STOP, SCHLUESSEL, SimklFehler, _liste, _listen,
                          _merk_eintrag, _schluessel, _stelle, _verlauf_eintrag, _wiedergabe, log)
from .simkl_konto import KontoMixin


class Simkl(KontoMixin):
    def __init__(self, verwaltung, holen=None, uhr=None):
        KontoMixin.__init__(self, verwaltung, holen=holen, uhr=uhr)
        self._mal = {}  # imdb -> MAL-Kennung, aus den Anime-Eintraegen des letzten Abgleichs

    def mal_fuer_imdb(self, imdb):
        """MAL-Kennung zu einer IMDb-Nummer, soweit SIMKL sie kennt (fuer AniSkip)."""
        return self._mal.get(str(imdb or ""))

    # --- Abgleich -------------------------------------------------------------------
    def faellig(self, daten, profil):
        konten = ((daten.get(SCHLUESSEL) or {}).get("konten") or {}) if isinstance(daten.get(SCHLUESSEL), dict) else {}
        konto = konten.get(profil) or {}
        return bool(konto.get("access_token")) and self.uhr() - float(konto.get("zuletzt") or 0) > ABSTAND \
            and profil not in self._laeuft

    def im_hintergrund(self, profil):
        threading.Thread(target=self._sicher_abgleichen, args=(profil,), name="simkl", daemon=True).start()

    def _sicher_abgleichen(self, profil):
        try:
            self.abgleichen(profil)
        except SimklFehler as fehler:
            log.info("SIMKL-Abgleich (%s): %s", profil or "ohne Profil", fehler)
        except Exception as fehler:  # noqa: BLE001 – ein Hintergrund-Abgleich darf nie unsichtbar scheitern
            self._konto_setzen(profil, lambda k, text=str(fehler): k.update(fehler=text[:300]))
            log.warning("SIMKL-Abgleich (%s): %s", profil or "ohne Profil", fehler)

    def abgleichen(self, profil):
        with self._sperre:
            if profil in self._laeuft:
                return {"herein": 0, "hinaus": 0, "laeuft": True}
            self._laeuft.add(profil)
        try:
            app, daten, konto = self._token(profil)
            token = konto["access_token"]
            antworten = {}
            for name in ("movies", "shows", "anime"):
                antworten[name] = self._pflicht("GET", "/sync/all-items/" + name, app, token,
                                                werte={"extended": "full", "language": "de"})
            playback = self._pflicht("GET", "/sync/playback", app, token)
            self._mal_lernen(antworten["anime"])
            simkl = _listen(antworten["movies"], antworten["shows"], antworten["anime"])
            stellen = {_schluessel(k["typ"], k["id"]): (zeit, k, video, anteil)
                       for zeit, k, video, anteil in _wiedergabe(playback)}
            basis = konto.get("basis") if isinstance(konto.get("basis"), dict) else {}
            wuensche, senden = self._plan(sehen.lesen(daten, profil), simkl, stellen, basis)

            if wuensche:
                self._daten().bearbeiten(lambda d: [sehen.aendern(d, profil, w) for _, w in wuensche])

            hinaus = 0
            try:
                hinaus += self._senden(app, token, senden)
            except SimklFehler as fehler:
                log.info("SIMKL-Schreiben (%s): %s", profil or "ohne Profil", fehler)

            neu_basis = {"merkliste": sorted(_schluessel(k["typ"], k["id"]) for _, k in simkl["merkliste"]),
                         "verlauf": sorted(_schluessel(k["typ"], k["id"]) for _, k in simkl["verlauf"]),
                         "weiterschauen": {s: z[0] for s, z in stellen.items()}}
            self._konto_setzen(profil, lambda k: k.update(zuletzt=int(self.uhr()), fehler="", basis=neu_basis))
            return {"herein": len(wuensche), "hinaus": hinaus, "laeuft": False}
        except SimklFehler as fehler:
            self._konto_setzen(profil, lambda k, text=str(fehler): k.update(fehler=text[:300]))
            raise
        finally:
            with self._sperre:
                self._laeuft.discard(profil)

    def _mal_lernen(self, anime):
        """IMDb -> MAL aus den Anime-Eintraegen; so findet AniSkip auch bei IMDb-Kennungen."""
        for eintrag in _liste(anime):
            if not isinstance(eintrag, dict):
                continue
            media = eintrag.get("anime") or eintrag.get("show") or {}
            ids = media.get("ids") if isinstance(media, dict) else None
            if not isinstance(ids, dict):
                continue
            imdb, mal = str(ids.get("imdb") or ""), ids.get("mal")
            if imdb.startswith("tt") and mal:
                self._mal[imdb] = str(mal)

    def _plan(self, hier, simkl, stellen, basis):
        """Was hereinkommt und was an SIMKL geht; vergleicht wie Trakt mit dem Stand des letzten Abgleichs."""
        hier_m = {_schluessel(k["typ"], k["id"]): k for k in hier["merkliste"]}
        hier_v = {_schluessel(k["typ"], k["id"]): k for k in hier["verlauf"]}
        hier_w = {_schluessel(w["typ"], w["id"]): w for w in hier["weiterschauen"]}
        drueben_m = {_schluessel(k["typ"], k["id"]): k for _, k in simkl["merkliste"]}
        drueben_v = {_schluessel(k["typ"], k["id"]): k for _, k in simkl["verlauf"]}
        alt_m = set(basis.get("merkliste") or [])
        alt_v = set(basis.get("verlauf") or [])
        alt_w = basis.get("weiterschauen") if isinstance(basis.get("weiterschauen"), dict) else {}
        voll_m = len(alt_m) < 200 and len(drueben_m) < 200
        wuensche = [(_zeit, {"aktion": "merken", "titel": k}) for _zeit, k in simkl["merkliste"]
                    if _schluessel(k["typ"], k["id"]) not in hier_m and _schluessel(k["typ"], k["id"]) not in alt_m]
        wuensche += [(0, {"aktion": "weg", "titel": k}) for s, k in hier_m.items()
                     if voll_m and s not in drueben_m and s in alt_m]  # auf SIMKL entfernt -> hier entfernen
        wuensche += [(_zeit, {"aktion": "gesehen", "titel": k}) for _zeit, k in simkl["verlauf"]
                     if _schluessel(k["typ"], k["id"]) not in hier_v and _schluessel(k["typ"], k["id"]) not in alt_v]
        for s, (zeit, k, video, anteil) in stellen.items():
            w = hier_w.get(s)
            neuer = zeit > float((w or {}).get("zeit") or 0) + 1
            if (w and neuer) or (not w and zeit > float(alt_w.get(s) or 0) + 1):
                wuensche.append((zeit, {"aktion": "fortschritt", "titel": k, "video": video, "anteil": anteil}))
        wuensche.sort(key=lambda z: z[0])
        senden = {"merkliste": [k for s, k in hier_m.items() if s not in drueben_m and s not in alt_m],
                  "verlauf": [k for s, k in hier_v.items() if s not in drueben_v and s not in alt_v
                              and k["typ"] == "movie" and k["id"].startswith("tt")],
                  "stellen": [w for s, w in hier_w.items() if w["id"].startswith("tt") and not w.get("naechste")
                              and float(w.get("zeit") or 0) > (stellen[s][0] if s in stellen else
                                                               float(alt_w.get(s) or 0)) + 1]}
        senden["stellen"].sort(key=lambda w: float(w.get("zeit") or 0), reverse=True)
        return wuensche, senden

    def _senden(self, app, token, senden):
        """Push an SIMKL; einzelne Fehler brechen den Abgleich nicht ab."""
        anzahl = 0
        if senden["merkliste"]:
            inhalt = {"movies": [_merk_eintrag(k) for k in senden["merkliste"] if k["typ"] == "movie"],
                      "shows": [_merk_eintrag(k) for k in senden["merkliste"] if k["typ"] == "series"]}
            self._pflicht("POST", "/sync/add-to-list", app, token, inhalt)
            anzahl += len(senden["merkliste"])
        if senden["verlauf"]:
            self._pflicht("POST", "/sync/history", app, token,
                          {"movies": [_verlauf_eintrag(k, None) for k in senden["verlauf"]]})
            anzahl += len(senden["verlauf"])
        for w in senden["stellen"][:MAX_SCROBBLE]:
            inhalt = _stelle(w)
            if not inhalt:
                continue
            ziel = "/scrobble/stop" if float(w.get("anteil") or 0) >= SCROBBLE_STOP / 100.0 else "/scrobble/pause"
            try:
                self._pflicht("POST", ziel, app, token, inhalt)
                anzahl += 1
            except SimklFehler as fehler:
                if fehler.status != 409:  # 409: SIMKL hat die Stelle schon
                    log.info("SIMKL-Scrobble: %s", fehler)
        return anzahl

