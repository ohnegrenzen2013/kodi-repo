"""SIMKL: Konstanten, Fehler und Parser fuer Watchlist, Verlauf und Wiedergabestellen.

Vorbild ist Nuvios SIMKL-Anbindung (NuvioTV, GPL-3.0); der Code hier ist eigen geschrieben und nutzt nur die
oeffentliche SIMKL-API. Titel werden ueber die IMDb-Kennung zugeordnet, weil H0rSt seine Karten so speichert.
"""

import logging
import re
from datetime import datetime

log = logging.getLogger("rezeptserver")

API = "https://api.simkl.com"
SCHLUESSEL = "simkl"
ABSTAND = 15 * 60          # so oft gleicht H0rSt von selbst ab
MAX_SCROBBLE = 10          # Wiedergabestellen je Abgleich
SCROBBLE_STOP = 90.0       # ab hier /scrobble/stop statt pause
POSTER = "https://images.metahub.space/poster/medium/%s/img"


class SimklFehler(ValueError):
    def __init__(self, text="", status=None):
        super().__init__(text)
        self.status = status


def _lesbar(fehler):
    status = getattr(fehler, "status", None)
    if status == 429:
        return "SIMKL: zu viele Anfragen – in ein paar Minuten noch einmal versuchen"
    if status and status >= 500:
        return "SIMKL meldet eine Störung (HTTP %d) – später noch einmal versuchen" % status
    if status:
        return "SIMKL antwortet mit HTTP %d" % status
    return "SIMKL nicht erreichbar – Internetverbindung prüfen und noch einmal versuchen"


def _zeit(text):
    """ISO-Zeit von SIMKL ("2026-10-17T12:00:00Z") als Sekunden; 0 bei Unsinn."""
    try:
        return datetime.fromisoformat(str(text).replace("Z", "+00:00")).timestamp()
    except (TypeError, ValueError):
        return 0.0


def _id(ids):
    """IMDb-Kennung aus einem SIMKL-ids-Objekt, sonst ''."""
    imdb = str((ids or {}).get("imdb") or "") if isinstance(ids, dict) else ""
    return imdb if re.match(r"^tt\d{1,12}$", imdb) else ""


def _karte(media, typ):
    """Karte fuer sehen.py aus einem SIMKL-Film oder einer SIMKL-Serie; None ohne IMDb-Nummer."""
    if not isinstance(media, dict):
        return None
    imdb = _id(media.get("ids"))
    if not imdb:
        return None
    return {"id": imdb, "typ": typ, "titel": str(media.get("title") or imdb), "jahr": str(media.get("year") or ""),
            "poster": POSTER % imdb}


def _schluessel(typ, kennung):
    return "%s:%s" % (typ, kennung)


def _liste(antwort):
    """SIMKL liefert je nach Aufruf eine Liste oder {movies|shows|anime: [...]}."""
    if isinstance(antwort, list):
        return antwort
    if not isinstance(antwort, dict):
        return []
    for name in ("movies", "shows", "anime"):
        if isinstance(antwort.get(name), list):
            return antwort[name]
    return []


def _art(eintrag):
    """(typ, media) eines all-items-Eintrags: movie oder series."""
    media = eintrag.get("movie") if isinstance(eintrag.get("movie"), dict) else None
    if media:
        return "movie", media
    media = eintrag.get("show") if isinstance(eintrag.get("show"), dict) else None
    if media:
        return "series", media
    media = eintrag.get("anime") if isinstance(eintrag.get("anime"), dict) else None
    if media:
        return ("movie" if str(eintrag.get("anime_type") or "").lower() == "movie" else "series"), media
    return None, None


def _listen(movies, shows, anime):
    """all-items-Antworten als {merkliste, verlauf} – Karten mit Zeitpunkt, neueste zuerst."""
    merkliste, verlauf = [], []
    for roh in list(_liste(movies)) + list(_liste(shows)) + list(_liste(anime)):
        if not isinstance(roh, dict):
            continue
        typ, media = _art(roh)
        k = _karte(media, typ) if typ else None
        if not k:
            continue
        if roh.get("added_to_watchlist_at") or str(roh.get("status") or "") in ("plantowatch", "watching"):
            merkliste.append((_zeit(roh.get("added_to_watchlist_at")), k))
        if roh.get("last_watched_at"):
            verlauf.append((_zeit(roh.get("last_watched_at")), k))
    merkliste.sort(key=lambda z: z[0], reverse=True)
    verlauf.sort(key=lambda z: z[0], reverse=True)
    return {"merkliste": merkliste[:200], "verlauf": verlauf[:200]}


def _wiedergabe(antwort):
    """playback-Antwort als [(zeit, karte, video, anteil)] fuer das Weiterschauen."""
    ergebnis = []
    for eintrag in _liste(antwort):
        if not isinstance(eintrag, dict):
            continue
        media = eintrag.get("movie") if isinstance(eintrag.get("movie"), dict) else \
            eintrag.get("show") if isinstance(eintrag.get("show"), dict) else \
            eintrag.get("anime") if isinstance(eintrag.get("anime"), dict) else None
        if media is None:
            continue
        typ = "movie" if isinstance(eintrag.get("movie"), dict) else "series"
        k = _karte(media, typ)
        if not k:
            continue
        folge = eintrag.get("episode") if isinstance(eintrag.get("episode"), dict) else {}
        staffel, nummer = folge.get("season"), folge.get("number")
        video = k["id"]
        if typ == "series":
            if not isinstance(staffel, int) or not isinstance(nummer, int) or nummer <= 0:
                continue
            video = "%s:%d:%d" % (k["id"], staffel, nummer)
        try:
            anteil = max(0.0, min(1.0, float(eintrag.get("progress") or 0) / 100.0))
        except (TypeError, ValueError):
            continue
        if not 0 < anteil < 1:
            continue
        ergebnis.append((_zeit(eintrag.get("paused_at")), k, video, anteil))
    ergebnis.sort(key=lambda z: z[0], reverse=True)
    return ergebnis


def _stelle(w):
    """Inhalt fuer /scrobble/pause oder /scrobble/stop aus einem Weiterschauen-Eintrag."""
    fortschritt = round(max(0.0, min(100.0, float(w.get("anteil") or 0) * 100)), 2)
    kennung = {"ids": {"imdb": w["id"]}, "title": w.get("titel") or w["id"]}
    if w.get("jahr") and str(w["jahr"]).isdigit():
        kennung["year"] = int(w["jahr"])
    if w["typ"] == "series":
        teile = str(w.get("video") or "").split(":")
        if len(teile) < 3 or not teile[-1].isdigit() or not teile[-2].isdigit():
            return None
        return {"progress": fortschritt, "show": kennung,
                "episode": {"season": int(teile[-2]), "number": int(teile[-1])}}
    return {"progress": fortschritt, "movie": kennung}


def _merk_eintrag(k):
    """Eintrag fuer /sync/add-to-list (Watchlist)."""
    e = {"to": "plantowatch", "ids": {"imdb": k["id"]}, "title": k.get("titel") or k["id"]}
    if str(k.get("jahr") or "").isdigit():
        e["year"] = int(k["jahr"])
    return e


def _verlauf_eintrag(k, zeit):
    """Eintrag fuer /sync/history (gesehener Film)."""
    e = {"ids": {"imdb": k["id"]}, "title": k.get("titel") or k["id"]}
    if str(k.get("jahr") or "").isdigit():
        e["year"] = int(k["jahr"])
    if zeit:
        e["watched_at"] = datetime.utcfromtimestamp(float(zeit)).strftime("%Y-%m-%dT%H:%M:%SZ")
    return e
