"""SIMKL: Nutzerdaten, PIN-Anmeldung und API-Aufrufe."""

import json
import logging
import threading
import time
from urllib.parse import urlencode

from . import __version__
from .netz import NetzFehler, antwort_holen
from .simkl_grund import API, SCHLUESSEL, SimklFehler

log = logging.getLogger("rezeptserver")


class KontoMixin:
    """Nutzerdaten, PIN-Code und Anmeldung."""

    def __init__(self, verwaltung, holen=None, uhr=None):
        self._verwaltung = verwaltung
        self.holen = holen or antwort_holen
        self.uhr = uhr or time.time
        self._pins = {}            # profil -> laufende Anmeldung
        self._sperre = threading.Lock()
        self._laeuft = set()

    # --- Nutzerdaten ---------------------------------------------------------------
    @staticmethod
    def _abschnitt(daten):
        s = daten.get(SCHLUESSEL) if isinstance(daten.get(SCHLUESSEL), dict) else {}
        s.setdefault("app", {})
        s.setdefault("konten", {})
        daten[SCHLUESSEL] = s
        return s

    def _daten(self):
        v = self._verwaltung()
        if v is None:
            raise SimklFehler("Nutzerdaten nicht verfügbar")
        return v

    def _konto_setzen(self, profil, aenderung):
        def tun(d):
            konten = self._abschnitt(d)["konten"]
            konto = dict(konten.get(profil) or {})
            aenderung(konto)
            if konto:
                konten[profil] = konto
            else:
                konten.pop(profil, None)
        self._daten().bearbeiten(tun)

    def stand(self, daten, profil):
        s = daten.get(SCHLUESSEL) if isinstance(daten.get(SCHLUESSEL), dict) else {}
        app = s.get("app") or {}
        konto = (s.get("konten") or {}).get(profil) or {}
        pin = self._pins.get(profil)
        ergebnis = {"eingerichtet": bool(str(app.get("client_id") or "").strip()),
                    "client_id": str(app.get("client_id") or ""), "verbunden": bool(konto.get("access_token")),
                    "benutzer": konto.get("benutzer", ""), "zuletzt": konto.get("zuletzt", 0),
                    "fehler": konto.get("fehler", ""), "laeuft": profil in self._laeuft}
        if pin and pin["bis"] > self.uhr():
            ergebnis["geraet"] = {"code": pin["code"], "url": pin["url"], "bis": pin["bis"]}
        return ergebnis

    @staticmethod
    def app_setzen(daten, wunsch):
        app = KontoMixin._abschnitt(daten)["app"]
        cid = str(wunsch.get("client_id") or "").strip()
        if not cid:
            daten[SCHLUESSEL]["app"] = {}
            return {"eingerichtet": False}
        if len(cid) > 200:
            raise SimklFehler("Client ID zu lang")
        app["client_id"] = cid
        return {"eingerichtet": True}

    # --- API -----------------------------------------------------------------------
    def _app(self, daten):
        app = ((daten.get(SCHLUESSEL) or {}).get("app") or {}) if isinstance(daten.get(SCHLUESSEL), dict) else {}
        if not str(app.get("client_id") or "").strip():
            raise SimklFehler("SIMKL ist noch nicht eingerichtet: Client ID der SIMKL-App eintragen")
        return app

    def _rufen(self, methode, pfad, app, token=None, inhalt=None, werte=None):
        abfrage = dict(werte or {})
        abfrage.update({"client_id": app["client_id"], "app-name": "H0rSt", "app-version": __version__})
        kopf = {"Accept": "application/json", "User-Agent": "Rezeptserver/" + __version__}
        if inhalt is not None:
            kopf["Content-Type"] = "application/json"
        if token:
            kopf["Authorization"] = "Bearer " + token
        try:
            status, text = self.holen(API + pfad + "?" + urlencode(abfrage), methode, kopf,
                                      json.dumps(inhalt) if inhalt is not None else None)
        except NetzFehler as fehler:
            raise SimklFehler("SIMKL nicht erreichbar: %s" % fehler)
        try:
            daten = json.loads(text) if text and text.strip() else None
        except ValueError:
            daten = None
        return status, daten

    def _pflicht(self, methode, pfad, app, token=None, inhalt=None, werte=None):
        status, daten = self._rufen(methode, pfad, app, token, inhalt, werte)
        if status == 401:
            raise SimklFehler("Die Anmeldung bei SIMKL ist abgelaufen – neu verbinden", 401)
        if status >= 400:
            raise SimklFehler("SIMKL antwortet mit HTTP %d bei %s" % (status, pfad.split("?")[0]), status)
        return daten

    # --- Anmeldung per PIN ---------------------------------------------------------
    def verbinden_start(self, profil):
        app = self._app(self._daten().daten())
        status, d = self._rufen("GET", "/oauth/pin", app)
        if status != 200 or not isinstance(d, dict) or str(d.get("result") or "") != "OK" or not d.get("user_code"):
            raise SimklFehler("SIMKL gibt keinen PIN (HTTP %d) – stimmt die Client ID?" % status)
        pin = {"code": str(d["user_code"]), "url": str(d.get("verification_uri") or d.get("verification_url") or "https://simkl.com/pin"),
               "intervall": max(1, int(d.get("interval") or 5)), "bis": self.uhr() + int(d.get("expires_in") or 900)}
        self._pins[profil] = pin
        return {"code": pin["code"], "url": pin["url"], "bis": pin["bis"], "intervall": pin["intervall"]}

    def verbinden_pruefen(self, profil):
        """Hat der Nutzer den PIN eingegeben? {fertig: bool, warten: bool, fehler?}"""
        pin = self._pins.get(profil)
        if not pin or pin["bis"] <= self.uhr():
            self._pins.pop(profil, None)
            return {"fertig": False, "warten": False, "fehler": "Der PIN ist abgelaufen – neu verbinden"}
        app = self._app(self._daten().daten())
        status, d = self._rufen("GET", "/oauth/pin/" + pin["code"], app)
        if status in (400, 404, 429):
            return {"fertig": False, "warten": True}
        if status != 200 or not isinstance(d, dict):
            self._pins.pop(profil, None)
            return {"fertig": False, "warten": False, "fehler": "SIMKL antwortet mit HTTP %d" % status}
        if str(d.get("result") or "") == "KO":
            return {"fertig": False, "warten": True}
        token = str(d.get("access_token") or "").strip()
        if not token:
            self._pins.pop(profil, None)
            return {"fertig": False, "warten": False, "fehler": "SIMKL hat keinen Zugang geliefert"}
        self._pins.pop(profil, None)
        benutzer = ""
        try:
            ich = self._pflicht("POST", "/users/settings", app, token)
            benutzer = str(((ich or {}).get("user") or {}).get("name") or "")
        except SimklFehler:
            pass
        self._konto_setzen(profil, lambda k: (k.clear(), k.update(access_token=token, benutzer=benutzer, zuletzt=0, fehler="")))
        return {"fertig": True, "warten": False, "benutzer": benutzer}

    def trennen(self, profil):
        self._pins.pop(profil, None)
        self._konto_setzen(profil, lambda k: k.clear())
        return {"verbunden": False}

    def _token(self, profil):
        daten = self._daten().daten()
        app = self._app(daten)
        konto = ((daten.get(SCHLUESSEL) or {}).get("konten") or {}).get(profil) or {}
        if not konto.get("access_token"):
            raise SimklFehler("Dieses Profil ist nicht mit SIMKL verbunden")
        return app, daten, konto
