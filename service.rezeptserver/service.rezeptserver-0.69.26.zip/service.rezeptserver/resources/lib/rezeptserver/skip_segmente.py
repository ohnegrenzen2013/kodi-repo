"""IntroDB und AniSkip: automatische Vorschlaege fuer Intro und Abspann (wie NuvioTV, eigener Code).

IntroDB liefert Oeffentlichkeit-Segmente zu IMDb-Kennungen (intro, recap, outro, post_credits); AniSkip
liefert op/ed zu MAL-Kennungen. H0rSt fragt nur, wenn der Titel noch keine Marke und keinen Vorschlag hat,
und schreibt das Ergebnis als "erkannt" in marken.py - uebernommen wird es erst, wenn der Nutzer es bestaetigt.
Die MAL-Kennung zu einer IMDb-Nummer kommt aus dem letzten SIMKL-Abgleich, wenn SIMKL verbunden ist.
"""

import json
import re
import threading
import time
from urllib.parse import urlencode

from . import marken
from .netz import NetzFehler, antwort_holen

INTRODB = "https://api.introdb.app/segments"
THEINTRODB = "https://api.theintrodb.org/v4/media"
ANISKIP = "https://api.aniskip.com/v2/skip-times"
AGENT = "Rezeptserver-SkipSegmente"
NEGATIV_DAUER = 6 * 3600
MAX_SEGMENTE = 8  # so lange nach einem vergeblichen Versuch nicht erneut fragen


def _segment(roh):
    """IntroDB-Segment {start_sec, end_sec, ...} als [start, ende] oder None."""
    if not isinstance(roh, dict):
        return None
    try:
        start = float(roh.get("start_sec") if roh.get("start_sec") is not None else float(roh.get("start_ms") or 0) / 1000.0)
        ende = float(roh.get("end_sec") if roh.get("end_sec") is not None else float(roh.get("end_ms") or 0) / 1000.0)
    except (TypeError, ValueError):
        return None
    if start < 0 or ende <= start:
        return None
    return [round(start, 2), round(ende, 2)]


def _konfidenz(wert):
    try:
        return "sicher" if float(wert) >= 0.8 else "unsicher"
    except (TypeError, ValueError):
        return "unsicher"


def zerlegen(ref):
    """tt123[:S:E] oder mal:123[:S:E] -> {imdb, mal, staffel, folge}."""
    teile = str(ref or "").split(":")
    ergebnis = {"imdb": "", "mal": "", "staffel": None, "folge": None}
    if teile and re.match(r"^tt\d{1,12}$", teile[0]):
        ergebnis["imdb"] = teile[0]
        rest = teile[1:]
    elif len(teile) >= 2 and teile[0] == "mal" and teile[1].isdigit():
        ergebnis["mal"] = teile[1]
        rest = teile[2:]
    elif teile and teile[0].isdigit():
        ergebnis["mal"] = teile[0]
        rest = teile[1:]
    else:
        return ergebnis
    if len(rest) >= 2 and rest[0].isdigit() and rest[1].isdigit():
        ergebnis["staffel"], ergebnis["folge"] = int(rest[0]), int(rest[1])
    return ergebnis


class Segmente:
    def __init__(self, holen=None, simkl=None, uhr=None):
        self.holen = holen or antwort_holen
        self.simkl = simkl
        self.uhr = uhr or time.time
        self._laeuft = set()
        self._negativ = {}
        self._sperre = threading.Lock()

    def anfragen(self, verwaltung, daten, ref):
        """Startet im Hintergrund eine Abfrage, wenn der Titel noch keinen Vorschlag hat. True, wenn gestartet."""
        try:
            schluessel = marken.ref_grund(ref)
        except marken.MarkenFehler:
            return False
        if not (daten.get("marken_introdb", False) or daten.get("marken_aniskip", False)
                or daten.get("marken_theintrodb", False)):
            return False
        voll = str(ref or "").strip()
        with self._sperre:
            if schluessel in self._laeuft or self._negativ.get(schluessel, 0) > self.uhr():
                return False
            self._laeuft.add(schluessel)
        threading.Thread(target=self._lauf, args=(verwaltung, schluessel, voll, daten), name="skip-segmente",
                         daemon=True).start()
        return True

    def _lauf(self, verwaltung, schluessel, ref, daten):
        try:
            vorschlag = self.vorschlag(ref, daten)
            if vorschlag:
                if verwaltung is not None:
                    verwaltung.bearbeiten(
                        lambda d: marken.aendern(d, "", dict(vorschlag, ref=schluessel, aktion="vorschlag")))
            else:
                self._negativ[schluessel] = self.uhr() + NEGATIV_DAUER
        except Exception:  # noqa: BLE001 – ein fremder Dienst darf den Player nie stoeren
            self._negativ[schluessel] = self.uhr() + NEGATIV_DAUER
        finally:
            with self._sperre:
                self._laeuft.discard(schluessel)

    def vorschlag(self, ref, daten=None):
        """Segmente zu einem Titel holen: {intro, outro, konfidenz, quelle} oder None."""
        daten = daten or {}
        teile = zerlegen(ref)
        intro = outro = None
        konfidenz, quellen, segmente = "unsicher", [], []
        if daten.get("marken_introdb", False) and teile["imdb"]:
            try:
                treffer = self._introdb(teile)
            except (NetzFehler, ValueError, OSError):
                treffer = None
            if treffer:
                intro, outro = treffer.get("intro"), treffer.get("outro")
                konfidenz = treffer.get("konfidenz") or konfidenz
                quellen.append("introdb")
                if intro:
                    segmente.append({"art": "intro", "start": intro[0], "ende": intro[1]})
                if outro is not None:
                    segmente.append({"art": "outro", "start": outro, "ende": None})
        if daten.get("marken_theintrodb", False) and teile["imdb"]:
            try:
                treffer = self._theintrodb(teile)
            except (NetzFehler, ValueError, OSError):
                treffer = None
            if treffer:
                for eintrag in treffer:
                    if eintrag["art"] == "intro" and intro is None:
                        intro = [eintrag["start"], eintrag["ende"]]
                    if eintrag["art"] in ("outro", "credits") and outro is None:
                        outro = eintrag["start"]
                    segmente.append(eintrag)
                quellen.append("theintrodb")
        if daten.get("marken_aniskip", False) and teile["folge"] is not None:
            try:
                treffer = self._aniskip(teile, intro, outro)
            except (NetzFehler, ValueError, OSError):
                treffer = None
            if treffer:
                if treffer.get("intro"):
                    intro = intro or treffer["intro"]
                    segmente.append({"art": "intro", "start": treffer["intro"][0], "ende": treffer["intro"][1]})
                if treffer.get("outro") is not None and outro is None:
                    outro = treffer["outro"]
                    segmente.append({"art": "outro", "start": treffer["outro"], "ende": None})
                quellen.append("aniskip")
        if intro is None and outro is None:
            return None
        ergebnis = {"konfidenz": konfidenz, "quelle": quellen[-1] if quellen else "introdb"}
        if intro:
            ergebnis["intro"] = intro
        if outro is not None:
            ergebnis["outro"] = outro
        if segmente:
            ergebnis["segmente"] = segmente[:MAX_SEGMENTE]
        return ergebnis

    def _rufen(self, url):
        status, text = self.holen(url, "GET", {"User-Agent": AGENT, "Accept": "application/json"}, None)
        if status == 404:
            return None
        if status >= 400:
            raise NetzFehler("HTTP %d" % status)
        try:
            return json.loads(text) if text and text.strip() else None
        except ValueError:
            raise ValueError("unerwartete Antwort")

    def _introdb(self, teile):
        werte = {"imdb_id": teile["imdb"]} if teile["imdb"] else {"mal_id": teile["mal"]}
        if teile["staffel"] is not None and teile["folge"] is not None:
            werte["season"], werte["episode"] = teile["staffel"], teile["folge"]
        else:
            werte["is_movie"] = "true"
        d = self._rufen(INTRODB + "?" + urlencode(werte))
        if not isinstance(d, dict):
            return None
        intro = _segment(d.get("intro")) or _segment(d.get("recap"))
        outro = _segment(d.get("outro"))
        if intro is None and outro is None:
            return None
        konfidenz = "unsicher"
        for name in ("intro", "recap", "outro"):
            roh = d.get(name)
            if isinstance(roh, dict):
                konfidenz = _konfidenz(roh.get("confidence"))
                if konfidenz == "sicher":
                    break
        return {"intro": intro, "outro": outro[0] if outro else None, "konfidenz": konfidenz}

    def _theintrodb(self, teile):
        if not teile["imdb"]:
            return None
        werte = {"imdb_id": teile["imdb"]}
        if teile["staffel"] is not None and teile["folge"] is not None:
            werte["season"], werte["episode"] = teile["staffel"], teile["folge"]
        d = self._rufen(THEINTRODB + "?" + urlencode(werte))
        if not isinstance(d, dict):
            return None
        ergebnis = []
        for feld, art in (("intro", "intro"), ("recap", "recap"), ("credits", "outro"), ("preview", "preview")):
            for roh in d.get(feld) or []:
                if not isinstance(roh, dict):
                    continue
                start = roh.get("start_ms")
                ende = roh.get("end_ms")
                if not isinstance(start, (int, float)):
                    continue
                if isinstance(ende, (int, float)) and ende > start:
                    eintrag = {"art": art, "start": round(start / 1000.0, 2), "ende": round(ende / 1000.0, 2)}
                else:
                    eintrag = {"art": art, "start": round(start / 1000.0, 2), "ende": None}
                if eintrag["art"] != "outro" or eintrag["ende"] is not None:
                    ergebnis.append(eintrag)
        return ergebnis or None

    def _aniskip(self, teile, intro, outro):
        mal = teile["mal"]
        if not mal and teile["imdb"] and self.simkl is not None:
            mal = self.simkl.mal_fuer_imdb(teile["imdb"]) or ""
        if not mal or teile["folge"] is None:
            return None
        url = "%s/%s/%d?types=op&types=ed&episodeLength=0" % (ANISKIP, mal, teile["folge"])
        d = self._rufen(url)
        if not isinstance(d, dict) or not d.get("found"):
            return None
        op = ed = None
        for treffer in d.get("results") or []:
            if not isinstance(treffer, dict):
                continue
            interval = treffer.get("interval") or {}
            if treffer.get("skipType") == "op":
                op = _segment({"start_sec": interval.get("startTime"), "end_sec": interval.get("endTime")})
            elif treffer.get("skipType") == "ed":
                ed = _segment({"start_sec": interval.get("startTime"), "end_sec": interval.get("endTime")})
        if op is None and ed is None:
            return None
        return {"intro": None if intro else op, "outro": None if outro is not None else (ed[0] if ed else None)}
