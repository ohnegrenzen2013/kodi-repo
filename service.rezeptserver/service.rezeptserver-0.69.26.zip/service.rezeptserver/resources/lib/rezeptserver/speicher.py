"""Speicher & Aufraeumen: was H0rSt im Datenordner belegt, wie oft die Module genutzt werden, und was weg kann.

  Belegung   je Bereich (Kodi-Addons, YouTube, XDCC, Kameras, Daumenkino, Live-TV, Sicherungen …) mit Groesse,
             Nutzungsdauer, Besuchen und zuletzt genutzt (nutzung.py); dazu der freie Platz des Laufwerks.
  Vorschlaege – vorgewaehlt nur, was gefahrlos weg kann: Kodi-Zwischenspeicher, Reste abgebrochener Installationen,
             Daten deinstallierter Addons; nicht vorgewaehlt: Module, die kein Addon als Abhaengigkeit nennt, lange
             unbenutzte Kodi-Addons und Skins, die App-Update-Datei (vorgewaehlt erst nach einer Woche), aeltere Sicherungen. Eigene Dateien (Downloads, Fotos, Projekte) loescht H0rSt hier nie – die stehen mit
             Groesse da und werden im jeweiligen Reiter verwaltet.
  aktuell/ (Code aus der GitHub-Aktualisierung) und nutzerdaten.db gehoeren nie zum Aufraeumen.
"""

import os
import shutil
import time

TAGE_STANDARD = 60
TAGE_WAHL = (14, 30, 60, 90, 180, 365)
TEMP_ALTER = 24 * 3600  # Kodi-Zwischenspeicher: was laenger als einen Tag liegt
SICHERUNGEN_BEHALTEN = 2
# id, Name, Bereich der Oberflaeche (Nutzung und "Oeffnen"), Pfade im Datenordner ("name*" = alle, die so beginnen), Art
BEREICHE = [
    ("kodi", "Kodi-Addons und Skins", "kodiaddons", ["kodi"], "addons"),
    ("youtube", "YouTube: Downloads und Aufnahmen", "youtube", ["youtube"], "dateien"),
    ("xdcc", "XDCC-Downloads", "xdcc", ["xdcc"], "dateien"),
    ("kameras", "Kameras: Fotos und Überwachung", "kameras", ["kameras"], "dateien"),
    ("daumenkino", "Daumenkino-Projekte", "daumenkino", ["daumenkino"], "dateien"),
    ("livetv", "Live-TV: EPG, Listen, Adressen", "livetv", ["epg.xml.gz", "listen", "sender-adressen.json"], "zwischenspeicher"),
    ("ipfilter", "IP-Filter-Listen", "sicherheit", ["ipfilter"], "zwischenspeicher"),
    ("sicherungen", "Sicherungen", "einstellungen", ["sicherungen"], "sicherung"),
    ("aktualisierung", "Aktualisierung (Code aus GitHub, App-Update)", "einstellungen", ["aktuell", "h0rst-app.apk"], "system"),
    ("bilder", "Hintergrund, Startanimation, Profilbilder", "einstellungen", ["hintergrund.*", "avatar*", "startanimation.*"], "dateien"),
    ("system", "Einstellungen, Statistik, Fehlerliste", "einstellungen",
     ["nutzerdaten.db", "nutzerdaten.db-wal", "nutzerdaten.db-shm", "nutzung.json", "fehler.json", "waechter.json", "beobachtungen.json", "gutscheine.json", "speicher-filter.json"], "system"),
]


def groesse(pfad):
    """(Bytes, Dateien) einer Datei oder eines Ordners; Verknuepfungen zaehlen nicht."""
    if os.path.islink(pfad):
        return 0, 0
    if os.path.isfile(pfad):
        try:
            return os.path.getsize(pfad), 1
        except OSError:
            return 0, 0
    summe = anzahl = 0
    for wurzel, _, dateien in os.walk(pfad):
        for d in dateien:
            try:
                p = os.path.join(wurzel, d)
                if not os.path.islink(p):
                    summe += os.path.getsize(p)
                    anzahl += 1
            except OSError:
                pass
    return summe, anzahl


def _alter(pfad, jetzt):
    try:
        return jetzt - os.path.getmtime(pfad)
    except OSError:
        return 0


def _weg(pfad):
    """Datei oder Ordner loeschen; gibt die freigewordenen Bytes zurueck."""
    b, _ = groesse(pfad)
    if os.path.isdir(pfad) and not os.path.islink(pfad):
        shutil.rmtree(pfad, ignore_errors=True)
    elif os.path.lexists(pfad):
        try:
            os.remove(pfad)
        except OSError:
            return 0
    return b if not os.path.lexists(pfad) else 0


class Speicher:
    """datenordner; kodi: KodiAddons oder None; nutzung: Nutzung oder None; kodi_reiter: Addon-IDs mit eigenem Reiter;
    skin_aktiv: Skin-IDs, die ein Profil als Heim-Style nutzt; sicherungen: Aktualisierung (sicherungen(), Ordner)."""

    def __init__(self, datenordner, kodi=None, nutzung=None, kodi_reiter=(), skin_aktiv=(), uhr=time.time):
        self.ordner = os.path.abspath(datenordner or ".")
        self.kodi, self.nutzung, self.uhr = kodi, nutzung, uhr
        self.kodi_reiter, self.skin_aktiv = set(kodi_reiter), set(skin_aktiv)
        self._mass = None  # {pfad: (bytes, dateien)} aus einem Durchgang, gilt fuer eine Uebersicht

    def _messen(self):
        """Ein Durchgang durch den Datenordner (os.scandir: ein lstat je Datei) – Groesse und Dateizahl je Ordner und Datei."""
        if self._mass is not None:
            return self._mass
        mass = {}

        def ordner(pfad):
            summe = anzahl = 0
            try:
                eintraege = os.scandir(pfad)
            except OSError:
                mass[pfad] = (0, 0)
                return 0, 0
            with eintraege:
                for e in eintraege:
                    try:
                        if e.is_symlink():
                            continue
                        if e.is_dir(follow_symlinks=False):
                            b, n = ordner(e.path)
                        else:
                            b, n = e.stat(follow_symlinks=False).st_size, 1
                            mass[e.path] = (b, 1)
                    except OSError:
                        continue
                    summe, anzahl = summe + b, anzahl + n
            mass[pfad] = (summe, anzahl)
            return summe, anzahl
        ordner(self.ordner)
        self._mass = mass
        return mass

    def _groesse(self, pfad):
        """(Bytes, Dateien) aus der Messung; was nicht im Datenordner liegt, wird einzeln gemessen."""
        p = os.path.abspath(pfad)
        if p == self.ordner or p.startswith(self.ordner + os.sep):
            return self._messen().get(p, (0, 0))
        return groesse(p)

    # --- Belegung --------------------------------------------------------------------------------------
    def bereiche(self, stat):
        bekannt, liste = set(), []
        namen = os.listdir(self.ordner) if os.path.isdir(self.ordner) else []
        for bid, name, bereich, pfade, art in BEREICHE:
            summe = anzahl = 0
            for rel in [n for muster in pfade for n in ([x for x in namen if x.startswith(muster[:-1])] if muster.endswith("*") else [muster])]:
                bekannt.add(rel)
                b, n = self._groesse(os.path.join(self.ordner, rel))
                summe, anzahl = summe + b, anzahl + n
            z = stat["bereiche"].get(bereich) or {}
            liste.append({"id": bid, "name": name, "bereich": bereich, "art": art, "groesse": summe, "dateien": anzahl,
                          "besuche": z.get("besuche", 0), "zeit": int(z.get("zeit", 0)), "zuletzt": z.get("zuletzt", 0)})
        rest = summe = anzahl = 0
        for name in namen:
            if name not in bekannt and not name.startswith("."):
                b, n = self._groesse(os.path.join(self.ordner, name))
                summe, anzahl, rest = summe + b, anzahl + n, rest + 1
        if rest:
            liste.append({"id": "sonstiges", "name": "Sonstiges (%d Einträge)" % rest, "bereich": "", "art": "system",
                          "groesse": summe, "dateien": anzahl, "besuche": 0, "zeit": 0, "zuletzt": 0})
        return sorted(liste, key=lambda x: -x["groesse"])

    # --- Kodi ---------------------------------------------------------------------------------------------
    def _kodi_addons(self, stat):
        if not self.kodi:
            return []
        liste = []
        for i in self.kodi.installiert():
            if i["id"] == "script.module.kodi-six":  # Ersatz von H0rSt
                continue
            b, _ = self._groesse(i["pfad"])
            d, _ = self._groesse(os.path.join(self.kodi.userdata, "addon_data", i["id"]))
            z = stat["kodi"].get(i["id"]) or {}
            try:  # addon.xml entsteht beim Entpacken und aendert sich danach nicht
                installiert = int(os.path.getmtime(os.path.join(i["pfad"], "addon.xml")))
            except OSError:
                installiert = 0
            liste.append({"id": i["id"], "name": i["name"], "art": i["art"], "version": i["version"], "groesse": b, "daten": d,
                          "aufrufe": z.get("aufrufe", 0), "dauer": int(z.get("dauer", 0)), "fehler": z.get("fehler", 0),
                          "zuletzt": z.get("zuletzt", 0), "installiert": installiert,
                          "reiter": i["id"] in self.kodi_reiter, "heim_style": i["id"] in self.skin_aktiv,
                          "abhaengig": [a["id"] for a in i["abhaengig"]]})  # auch optionale: ist das Modul da, wird es genutzt
        return liste

    def _rest(self, name):
        """Zwischenordner einer abgebrochenen Installation: ".<id>.neu/.alt", oder alter Art "<id>.neu/.alt", dessen
        addon.xml eine andere ID nennt – nie ein Addon, das wirklich so heisst (plugin.video.neu gibt es)."""
        if not name.endswith((".alt", ".neu")) or not os.path.isdir(os.path.join(self.kodi.addons, name)):
            return False
        if name.startswith("."):
            return True
        return self.kodi.info(name) is None and os.path.isfile(os.path.join(self.kodi.addons, name, "addon.xml")) \
            and self.kodi.info(name[:-4]) is not None

    def _benoetigt(self, addons):
        """IDs, die ein installiertes Nicht-Modul (rekursiv) braucht."""
        nach_id = {a["id"]: a for a in addons}
        gebraucht, offen = set(), [a["id"] for a in addons if a["art"] != "modul"]
        while offen:
            for dep in nach_id.get(offen.pop(), {}).get("abhaengig", []):
                if dep not in gebraucht:
                    gebraucht.add(dep)
                    offen.append(dep)
        return gebraucht

    def _kodi_vorschlaege(self, addons, tage):
        if not self.kodi:
            return []
        v = []
        temp = os.path.join(self.kodi.basis, "temp")
        alt = [os.path.join(temp, n) for n in (os.listdir(temp) if os.path.isdir(temp) else [])
               if _alter(os.path.join(temp, n), self.uhr()) > TEMP_ALTER]
        if alt:
            v.append({"id": "kodi_temp", "titel": "Kodi-Zwischenspeicher", "text": "Temporäre Dateien der Addons, älter als ein Tag.",
                      "groesse": sum(self._groesse(p)[0] for p in alt), "vorgewaehlt": True, "pfade": alt})
        reste = [os.path.join(self.kodi.addons, n) for n in sorted(os.listdir(self.kodi.addons)) if self._rest(n)]
        if reste:
            v.append({"id": "kodi_reste", "titel": "Reste abgebrochener Installationen", "text": ", ".join(os.path.basename(p) for p in reste),
                      "groesse": sum(self._groesse(p)[0] for p in reste), "vorgewaehlt": True, "pfade": reste})
        ids = {a["id"] for a in addons} | {"script.module.kodi-six"}
        daten_ordner = os.path.join(self.kodi.userdata, "addon_data")
        verwaist = [os.path.join(daten_ordner, n) for n in sorted(os.listdir(daten_ordner) if os.path.isdir(daten_ordner) else []) if n not in ids]
        if verwaist:
            v.append({"id": "kodi_daten", "titel": "Daten deinstallierter Addons", "text": ", ".join(os.path.basename(p) for p in verwaist[:12]),
                      "groesse": sum(self._groesse(p)[0] for p in verwaist), "vorgewaehlt": True, "pfade": verwaist})
        gebraucht = self._benoetigt(addons)
        module = [a for a in addons if a["art"] == "modul" and a["id"] not in gebraucht]
        if module:  # nicht vorgewaehlt: manche Addons nutzen Module, ohne sie anzugeben (H0rSt laesst das zu)
            v.append({"id": "kodi_module", "titel": "Module, die kein Addon als Abhängigkeit nennt",
                      "text": ", ".join(a["id"] for a in module[:12]) + (" …" if len(module) > 12 else "")
                      + " – ein Addon, das ein Modul nutzt, ohne es anzugeben, läuft danach nicht mehr (dann neu installieren).",
                      "groesse": sum(a["groesse"] + a["daten"] for a in module), "vorgewaehlt": False, "addons": [a["id"] for a in module]})
        grenze = self.uhr() - tage * 86400
        for a in addons:
            # was ein anderes Addon braucht (Skript, Plugin wie YouTube), laeuft ueber dieses – zaehlt nie als eigener Aufruf
            if a["art"] not in ("plugin", "skin", "skript") or a["heim_style"] or a["id"] in gebraucht:
                continue
            zuletzt = a["zuletzt"] or a["installiert"]
            if zuletzt and zuletzt < grenze:
                v.append({"id": "kodi_addon:" + a["id"], "titel": "%s (%s) – %s" % (a["name"], a["art"], "nie genutzt" if not a["zuletzt"] else "lange nicht genutzt"),
                          "text": ("Hat einen eigenen Reiter – der verschwindet nicht von selbst. " if a["reiter"] else "")
                          + "Zuletzt: %s" % (time.strftime("%d.%m.%Y", time.localtime(zuletzt)) + ("" if a["zuletzt"] else " (installiert)")),
                          "groesse": a["groesse"] + a["daten"], "vorgewaehlt": False, "addons": [a["id"]], "zuletzt": zuletzt})
        return v

    # --- Uebrige Vorschlaege --------------------------------------------------------------------------
    def _sonstige_vorschlaege(self):
        v = []
        apk = os.path.join(self.ordner, "h0rst-app.apk")
        if os.path.isfile(apk):
            v.append({"id": "app_apk", "titel": "Heruntergeladenes App-Update", "text": "Wird bei der nächsten Aktualisierung neu geladen.",
                      "groesse": os.path.getsize(apk), "vorgewaehlt": _alter(apk, self.uhr()) > 7 * 86400, "pfade": [apk]})
        ordner = os.path.join(self.ordner, "sicherungen")
        if os.path.isdir(ordner):
            namen = sorted((n for n in os.listdir(ordner) if n.startswith("h0rst-sicherung-") and n.endswith(".json")), reverse=True)
            alt = [os.path.join(ordner, n) for n in namen[SICHERUNGEN_BEHALTEN:]]
            if alt:
                v.append({"id": "sicherungen_alt", "titel": "Ältere Sicherungen",
                          "text": "%d Stück – die %d neuesten bleiben." % (len(alt), SICHERUNGEN_BEHALTEN),
                          "groesse": sum(os.path.getsize(p) for p in alt), "vorgewaehlt": False, "pfade": alt})
        return v

    # --- Uebersicht und Aufraeumen ------------------------------------------------------------------------
    def uebersicht(self, tage=TAGE_STANDARD):
        stat = self.nutzung.module_nutzung() if self.nutzung else {"seit": 0, "bereiche": {}, "kodi": {}}
        addons = self._kodi_addons(stat)
        vorschlaege = self._kodi_vorschlaege(addons, tage) + self._sonstige_vorschlaege()
        try:
            platte = shutil.disk_usage(self.ordner)
            laufwerk = {"gesamt": platte.total, "frei": platte.free}
        except OSError:
            laufwerk = {"gesamt": 0, "frei": 0}
        return {"ordner": self.ordner, "laufwerk": laufwerk, "statistik_seit": stat["seit"], "tage": tage, "tage_wahl": list(TAGE_WAHL),
                "bereiche": self.bereiche(stat),
                "module": sorted(({"bereich": k, **v} for k, v in stat["bereiche"].items()), key=lambda z: -z["zeit"]),
                "kodi": sorted(addons, key=lambda a: -(a["groesse"] + a["daten"])),
                "vorschlaege": [{k: x[k] for k in x if k not in ("pfade", "addons")} for x in vorschlaege],
                "frei_moeglich": sum(x["groesse"] for x in vorschlaege)}

    def aufraeumen(self, ids, tage=TAGE_STANDARD):
        """Gewaehlte Vorschlaege ausfuehren (neu ermittelt – nur was jetzt noch vorgeschlagen wird). -> {frei, erledigt, fehler}."""
        stat = self.nutzung.module_nutzung() if self.nutzung else {"seit": 0, "bereiche": {}, "kodi": {}}
        addons = self._kodi_addons(stat)
        jetzt = {x["id"]: x for x in self._kodi_vorschlaege(addons, tage) + self._sonstige_vorschlaege()}
        frei, erledigt, fehler = 0, [], []
        for vid in [str(i) for i in (ids or [])][:500]:
            x = jetzt.get(vid)
            if not x:
                fehler.append({"id": vid, "fehler": "nicht mehr vorgeschlagen"})
                continue
            for p in x.get("pfade", []):
                if os.path.abspath(p).startswith(self.ordner + os.sep):  # nie ausserhalb des Datenordners
                    frei += _weg(p)
            for aid in x.get("addons", []):
                try:
                    vorher = self._groesse(os.path.join(self.kodi.addons, aid))[0]
                    self.kodi.entfernen(aid)
                    frei += vorher + _weg(os.path.join(self.kodi.userdata, "addon_data", aid))
                except (ValueError, OSError) as f:
                    fehler.append({"id": vid, "fehler": str(f)})
            erledigt.append(vid)
        self._mass = None  # danach neu messen
        return {"frei": frei, "erledigt": erledigt, "fehler": fehler}
