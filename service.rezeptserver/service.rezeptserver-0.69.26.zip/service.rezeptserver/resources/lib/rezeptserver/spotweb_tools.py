"""SpotWeb-Tools: Kompatibilitätsfassade auf usenet_tools (gemeinsame Usenet-Liste)."""

from .usenet_tools import GRUPPEN, STAND, TOOLS, zustand

__all__ = ["GRUPPEN", "STAND", "TOOLS", "zustand"]
