"""Sprachen: Audio aus Release-Namen erkennen, nach Wunsch sortieren, Codes umwandeln.

Intern gelten zweistellige Codes nach ISO 639-1 (de, en, ...). "mul" steht fuer mehrsprachig.
"""

import re

# Woerter in Release-Namen -> Audiosprachen. "DL" (Dual Language) zaehlt nur nach "German":
# "German.DL" = deutsche und originale Tonspur (meist Englisch). "WEB-DL" ist dagegen die Quelle.
_WOERTER = {
    "german": ["de"], "deutsch": ["de"], "ger": ["de"],
    "english": ["en"], "eng": ["en"],
    "french": ["fr"], "truefrench": ["fr"], "vff": ["fr"], "vf": ["fr"],
    "spanish": ["es"], "castellano": ["es"], "esp": ["es"],
    "italian": ["it"], "ita": ["it"],
    "dutch": ["nl"], "polish": ["pl"], "pl": ["pl"], "turkish": ["tr"], "russian": ["ru"], "rus": ["ru"],
    "japanese": ["ja"], "jap": ["ja"], "korean": ["ko"],
    "multi": ["mul"],
}
# ISO 639-1 -> ISO 639-2/B, wie Stremio und Kodi es bei Untertiteln erwarten
_DREI = {"de": "ger", "en": "eng", "fr": "fre", "es": "spa", "it": "ita", "nl": "dut", "pl": "pol",
         "pt": "por", "tr": "tur", "ru": "rus", "ja": "jpn", "ko": "kor", "sv": "swe", "da": "dan",
         "fi": "fin", "no": "nor", "cs": "cze", "hu": "hun", "el": "gre", "ar": "ara", "zh": "chi"}
_ZWEI = {v: k for k, v in _DREI.items()}
_ZWEI.update({"deu": "de", "fra": "fr", "nld": "nl", "ces": "cs", "ell": "el", "zho": "zh"})
_NAMEN = {"de": "DE", "en": "EN", "mul": "MULTI"}


def normalisiere(code):
    code = str(code or "").strip().lower()
    return _ZWEI.get(code, code)


def als_liste(wert):
    if not wert:
        return []
    if isinstance(wert, str):
        wert = re.split(r"[,\s/+]+", wert)
    return [normalisiere(c) for c in wert if str(c).strip()]


def erkenne(titel):
    """Audiosprachen aus einem Release-Namen, in Reihenfolge des Auftretens, ohne Doppelte."""
    gefunden = []
    woerter = re.split(r"[^a-z0-9]+", str(titel or "").lower())
    for stelle, wort in enumerate(woerter):
        codes = _WOERTER.get(wort, [])
        if wort == "dl" and stelle > 0 and woerter[stelle - 1] in ("german", "deutsch", "ger"):
            codes = ["en"]
        for code in codes:
            if code not in gefunden:
                gefunden.append(code)
    return gefunden


def audio_von(treffer, stream=None):
    """Ausdrueckliche Angabe des Rezepts zuerst, sonst aus dem Titel erkannt."""
    for quelle in (stream or {}, treffer):
        if quelle.get("audio"):
            return als_liste(quelle["audio"])
    return erkenne(treffer.get("titel", ""))


def rang(sprachen, wunsch):
    """Kleiner = besser. Mehrsprachig zaehlt als Treffer fuer jede Wunschsprache, nach echten Treffern."""
    for stelle, code in enumerate(wunsch):
        if code in sprachen:
            return stelle * 2
        if "mul" in sprachen:
            return stelle * 2 + 1
    return len(wunsch) * 2 + (0 if sprachen else 1)


def anzeige(sprachen):
    return "+".join(_NAMEN.get(c, c.upper()) for c in sprachen)


def drei(code):
    code = normalisiere(code)
    return _DREI.get(code, code)
