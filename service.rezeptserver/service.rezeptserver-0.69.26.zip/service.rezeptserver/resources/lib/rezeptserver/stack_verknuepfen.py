"""Stack-Assistent: Prowlarr, Sonarr, Radarr und den Downloader verknuepfen – mit Vorschau, nur auf ausdruecklichen Klick.

Vorbild: link-apps.sh aus dem Usenet-Kompass (MIT-Lizenz, Copyright (c) 2025 KAiSER; siehe docker/KOMPASS-LIZENZ.txt).
Das Skript liest die API-Schluessel aus den config.xml der Container. H0rSt tut das nicht: es nimmt die Zugaenge der
bereits eingerichteten Dienste (Adresse und Schluessel stehen schon in der geschuetzten Konfiguration) und schreibt
nichts in Dateien. Die Namensschemata und Custom-Format-Ausdruecke sind die TRaSH-Guides-Werte des Kompass.

Ablauf:  plan(optionen, dienste)      liest nur und beschreibt jeden Schritt (neu / aendern / schon da / Fehler)
         anwenden(optionen, dienste, plan_id)   fuehrt aus, aber nur, wenn plan_id zum frisch berechneten Plan passt –
                                      wer etwas anderes ausfuehrt als gezeigt, bekommt einen Fehler statt einer Aenderung.
Schluessel und Passwoerter kommen in keiner Antwort und keinem Log vor (sie gehen nur an Sonarr/Radarr/Prowlarr selbst).
"""

import hashlib
import json
from urllib.parse import urlsplit

from .stack_verknuepfen_grund import *  # noqa: F403
from .stack_verknuepfen_grund import _Schritt, _felder_setzen, _lesen, _schema  # noqa: F401

# TRaSH-Guides-Benennung (Werte aus dem Usenet-Kompass, link-apps.sh)
_ANHANG = "[{Custom Formats }{Quality Full}]{[MediaInfo VideoDynamicRangeType]}[{MediaInfo VideoBitDepth}bit]{[MediaInfo VideoCodec]}[{MediaInfo AudioCodec} { MediaInfo AudioChannels}]{-Release Group}"
BENENNUNG = {
    "sonarr": {
        "renameEpisodes": True, "replaceIllegalCharacters": True,
        "standardEpisodeFormat": "{Series TitleYear} - S{season:00}E{episode:00} - {Episode CleanTitle} " + _ANHANG,
        "dailyEpisodeFormat": "{Series TitleYear} - {Air-Date} - {Episode CleanTitle} " + _ANHANG,
        "animeEpisodeFormat": "{Series TitleYear} - S{season:00}E{episode:00} - {Episode CleanTitle} " + _ANHANG,
        "seriesFolderFormat": "{Series TitleYear} [tvdb-{TvdbId}]", "seasonFolderFormat": "Season {season:00}"},
    "radarr": {
        "renameMovies": True, "replaceIllegalCharacters": True,
        "standardMovieFormat": "{Movie CleanTitle} {(Release Year)} [imdb-{ImdbId}] - {[Custom Formats ]}{[Quality Full]}{[MediaInfo 3D]}{[MediaInfo VideoDynamicRangeType]}[{MediaInfo AudioCodec} { MediaInfo AudioChannels}][{MediaInfo VideoCodec}][-Release Group]",
        "movieFolderFormat": "{Movie CleanTitle} ({Release Year}) [imdb-{ImdbId}]"},
}
# Custom Formats und Punkte (Kompass, Kapitel 6.4); "Minderwertig" ist unser Zusatz fuer Kinomitschnitte (-10000)
CUSTOM_FORMATE = [
    {"name": "German DL", "punkte": 1500, "spec": ("ReleaseTitleSpecification", r"\b(German\b.*\b(DL|Dual)|(DL|Dual)\b.*\bGerman)\b")},
    {"name": "German", "punkte": 1000, "spec": ("LanguageSpecification", 4)},
    {"name": "German Forced", "punkte": 200, "spec": ("ReleaseTitleSpecification", r"\bGerman\b.*\b(Forced|Subbed)\b")},
    {"name": "Kinomitschnitt", "punkte": -10000, "spec": ("ReleaseTitleSpecification", r"\b(CAM|HDCAM|TS|HDTS|TELESYNC|TELECINE|LINE[. ]?DUBBED|MIC[. ]?DUBBED)\b")},
]
DEUTSCH_ABBRUCH = 1500
KATEGORIE = {"sonarr": ("tvCategory", "tv"), "radarr": ("movieCategory", "movies")}
SYNC_KATEGORIEN = {"sonarr": [5000, 5010, 5020, 5030, 5040, 5045, 5050], "radarr": [2000, 2010, 2020, 2030, 2040, 2045, 2050, 2060, 2070, 2080, 2090]}



def plan(opt, dienste, holen_clients=None):
    """Liste der Schritte (lesend). holen_clients: nur fuer Tests (Downloader-Werte)."""
    sch, ids = opt["schritte"], opt["ids"]
    pro = dienste.get(ids["prowlarr"])
    schritte = []
    arrs = {t: dienste.get(ids[t]) for t in ("sonarr", "radarr") if ids[t]}

    # 1. Prowlarr <-> Sonarr/Radarr
    if sch["prowlarr"] and pro and arrs:
        apps, fehler = _lesen(pro, "applications")
        if fehler:
            schritte.append(_Schritt("prowlarr:lesen", "Prowlarr", "Anwendungen lesen", "fehler", [fehler]))
        for t, c in arrs.items():
            vorhanden = next((a for a in apps or [] if isinstance(a, dict) and str(a.get("implementation") or "").lower() == t), None)
            sid = "prowlarr:" + t
            if fehler:
                continue
            ziel = "Prowlarr erreicht %s unter %s, %s erreicht Prowlarr unter %s" % (c.typ_name, opt["intern"][t], c.typ_name, opt["intern"]["prowlarr"])
            if vorhanden and vorhanden.get("syncLevel") == "fullSync":
                schritte.append(_Schritt(sid, "Prowlarr ↔ " + c.typ_name, "%s ist schon mit Voll-Sync eingetragen" % c.typ_name, "ok"))
            elif vorhanden:
                schritte.append(_Schritt(sid, "Prowlarr ↔ " + c.typ_name, "Sync-Stufe auf „Voll-Sync“ stellen (jetzt: %s)" % vorhanden.get("syncLevel"), "aendern", [ziel],
                                         lambda pro=pro, c=c, t=t, v=vorhanden: _prowlarr_app_aendern(pro, v)))
            else:
                schritte.append(_Schritt(sid, "Prowlarr ↔ " + c.typ_name, "%s in Prowlarr eintragen (Voll-Sync: alle Indexer gehen automatisch an %s)" % (c.typ_name, c.typ_name), "neu", [ziel],
                                         lambda pro=pro, c=c, t=t: _prowlarr_app_neu(pro, c, t, opt)))

    # 2. Root-Ordner
    if sch["wurzel"]:
        for t, c in arrs.items():
            ordner, fehler = _lesen(c, "rootfolder")
            sid = "wurzel:" + t
            if fehler:
                schritte.append(_Schritt(sid, c.typ_name, "Root-Ordner lesen", "fehler", [fehler]))
            elif any(str(o.get("path", "")).rstrip("/") == opt["wurzel"][t].rstrip("/") for o in ordner or [] if isinstance(o, dict)):
                schritte.append(_Schritt(sid, c.typ_name, "Root-Ordner %s ist schon da" % opt["wurzel"][t], "ok"))
            else:
                schritte.append(_Schritt(sid, c.typ_name, "Root-Ordner %s anlegen" % opt["wurzel"][t], "neu",
                                         ["Der Ordner muss für %s beschreibbar sein (im Docker-Stack: Volume /data)." % c.typ_name],
                                         lambda c=c, p=opt["wurzel"][t]: c.api("rootfolder", {"path": p})))

    # 3. Downloader in Sonarr/Radarr
    dl = dienste.get(ids["downloader"])
    if sch["downloader"] and dl and arrs:
        impl = {"nzbget": "Nzbget", "sabnzbd": "Sabnzbd"}[dl.typ]
        for t, c in arrs.items():
            clients, fehler = _lesen(c, "downloadclient")
            sid = "downloader:" + t
            if fehler:
                schritte.append(_Schritt(sid, c.typ_name, "Download-Clients lesen", "fehler", [fehler]))
            elif any(str(x.get("implementation")) == impl for x in clients or [] if isinstance(x, dict)):
                schritte.append(_Schritt(sid, c.typ_name, "%s ist schon als Download-Client eingetragen" % dl.typ_name, "ok"))
            else:
                kat = KATEGORIE[t][1]
                schritte.append(_Schritt(sid, c.typ_name, "%s als Download-Client eintragen (Kategorie „%s“)" % (dl.typ_name, kat), "neu",
                                         ["%s erreicht %s unter %s. Zugang (Benutzer/Passwort bzw. API-Schlüssel) nimmt H0rSt aus dem eingerichteten Dienst." % (c.typ_name, dl.typ_name, opt["intern"]["downloader"]),
                                          "Wichtig: Downloader und %s müssen denselben Pfad für denselben Ort verwenden (gemeinsamer Stamm, z. B. /data)." % c.typ_name],
                                         lambda c=c, t=t, dl=dl, impl=impl: _downloader_neu(c, t, dl, impl, opt)))

    # 4. Benennung und Propers
    for t, c in arrs.items():
        if sch["benennung"]:
            ist, fehler = _lesen(c, "config/naming")
            sid = "benennung:" + t
            if fehler:
                schritte.append(_Schritt(sid, c.typ_name, "Benennung lesen", "fehler", [fehler]))
            else:
                unterschiede = [k for k, v in BENENNUNG[t].items() if (ist or {}).get(k) != v]
                if not unterschiede:
                    schritte.append(_Schritt(sid, c.typ_name, "Benennung entspricht schon TRaSH", "ok"))
                else:
                    details = ["%s: %s → %s" % (k, _kurz(ist.get(k)), _kurz(BENENNUNG[t][k])) for k in unterschiede]
                    schritte.append(_Schritt(sid, c.typ_name, "TRaSH-Benennung setzen (%d Feld%s ändern sich)" % (len(unterschiede), "" if len(unterschiede) == 1 else "er"),
                                             "aendern", details, lambda c=c, t=t: _benennung(c, t)))
        if sch["propers"]:
            mm, fehler = _lesen(c, "config/mediamanagement")
            sid = "propers:" + t
            if fehler:
                schritte.append(_Schritt(sid, c.typ_name, "Medien-Verwaltung lesen", "fehler", [fehler]))
            elif isinstance(mm, dict) and "downloadPropersAndRepacks" in mm:
                if mm["downloadPropersAndRepacks"] == "doNotPrefer":
                    schritte.append(_Schritt(sid, c.typ_name, "Propers/Repacks stehen schon auf „Nicht bevorzugen“", "ok"))
                else:
                    schritte.append(_Schritt(sid, c.typ_name, "Propers/Repacks auf „Nicht bevorzugen“ stellen (jetzt: %s)" % mm["downloadPropersAndRepacks"], "aendern",
                                             ["Der Kompass steuert das lieber über Custom Formats."], lambda c=c, t=t: _propers(c)))

    # 5. Deutsche Custom Formats und Punkte
    if sch["deutsch"]:
        for t, c in arrs.items():
            cfs, fehler = _lesen(c, "customformat")
            if fehler:
                schritte.append(_Schritt("cf:" + t, c.typ_name, "Custom Formats lesen", "fehler", [fehler]))
                continue
            namen = {x.get("name") for x in cfs or [] if isinstance(x, dict)}
            fehlend = [f["name"] for f in CUSTOM_FORMATE if f["name"] not in namen]
            if fehlend:
                schritte.append(_Schritt("cf:" + t, c.typ_name, "Custom Formats anlegen: " + ", ".join(fehlend), "neu",
                                         ["%s: %+d Punkte" % (f["name"], f["punkte"]) for f in CUSTOM_FORMATE if f["name"] in fehlend],
                                         lambda c=c: _formate_anlegen(c)))
            else:
                schritte.append(_Schritt("cf:" + t, c.typ_name, "Die deutschen Custom Formats gibt es schon", "ok"))
            profile, fehler = _lesen(c, "qualityprofile")
            if fehler:
                schritte.append(_Schritt("punkte:" + t, c.typ_name, "Qualitätsprofile lesen", "fehler", [fehler]))
                continue
            gewaehlt = opt["profile"][t]
            if not gewaehlt:
                schritte.append(_Schritt("punkte:" + t, c.typ_name, "Punkte vergeben: kein Qualitätsprofil gewählt", "ok",
                                         ["Profile zum Bewerten ankreuzen: %s" % ", ".join("%s" % p.get("name") for p in profile or [] if isinstance(p, dict))]))
                continue
            for p in profile or []:
                if not isinstance(p, dict) or p.get("id") not in gewaehlt:
                    continue
                details = ["%s: %+d" % (f["name"], f["punkte"]) for f in CUSTOM_FORMATE] + \
                    ["Upgrades erlaubt, bis Punktestand %d" % DEUTSCH_ABBRUCH] + \
                    (["Mindestpunktzahl %d (nur Deutsch)" % 1000] if sch["nur_deutsch"] else [])
                schritte.append(_Schritt("punkte:%s:%s" % (t, p["id"]), c.typ_name, "Profil „%s“ nach dem DACH-Punkteschema bewerten" % p.get("name"), "aendern", details,
                                         lambda c=c, pid=p["id"]: _punkte(c, pid, sch["nur_deutsch"]), abhaengig=("cf:" + t,)))
    return schritte


def _kurz(wert):
    text = " ".join(str(wert if wert is not None else "–").split())
    return text if len(text) <= 70 else text[:67] + "…"


def _prowlarr_app_neu(pro, c, t, opt):
    schema = _schema(pro, "applications/schema", "Sonarr" if t == "sonarr" else "Radarr")
    neu, _ = _felder_setzen(schema, {"prowlarrUrl": opt["intern"]["prowlarr"], "baseUrl": opt["intern"][t], "apiKey": c.werte.get("api_key", ""),
                                     "syncCategories": SYNC_KATEGORIEN[t]})
    neu.update(name=c.typ_name, syncLevel="fullSync", enable=True)
    pro.api("applications", neu)


def _prowlarr_app_aendern(pro, vorhanden):
    pro.api("applications/%d" % int(vorhanden["id"]), dict(vorhanden, syncLevel="fullSync"), methode="PUT")


def _downloader_neu(c, t, dl, impl, opt):
    schema = _schema(c, "downloadclient/schema", impl)
    u = urlsplit(opt["intern"]["downloader"])
    werte = {"host": u.hostname, "port": u.port or (443 if u.scheme == "https" else 80), "useSsl": u.scheme == "https",
             KATEGORIE[t][0]: KATEGORIE[t][1]}
    if dl.typ == "nzbget":
        werte.update(username=dl.werte.get("user", ""), password=dl.werte.get("pass", ""))
    else:
        werte.update(apiKey=dl.werte.get("api_key", ""))
    neu, _ = _felder_setzen(schema, werte)
    neu.update(name=dl.typ_name, enable=True, protocol="usenet", priority=1)
    c.api("downloadclient", neu)


def _benennung(c, t):
    ist = c.api("config/naming")
    c.api("config/naming", dict(ist, **BENENNUNG[t]), methode="PUT")


def _propers(c):
    mm = c.api("config/mediamanagement")
    c.api("config/mediamanagement", dict(mm, downloadPropersAndRepacks="doNotPrefer"), methode="PUT")


def _formate_anlegen(c):
    vorhanden = {x.get("name") for x in c.api("customformat") or []}
    for f in CUSTOM_FORMATE:
        if f["name"] in vorhanden:
            continue
        art, wert = f["spec"]
        c.api("customformat", {"name": f["name"], "includeCustomFormatWhenRenaming": True, "specifications": [
            {"name": f["name"], "implementation": art, "negate": False, "required": False, "fields": [{"name": "value", "value": wert}]}]})


def _punkte(c, pid, nur_deutsch):
    p = c.api("qualityprofile/%d" % int(pid))
    punkte = {f["name"]: f["punkte"] for f in CUSTOM_FORMATE}
    for fi in p.get("formatItems") or []:
        if fi.get("name") in punkte:
            fi["score"] = punkte[fi["name"]]
    p["upgradeAllowed"] = True
    p["cutoffFormatScore"] = DEUTSCH_ABBRUCH
    if nur_deutsch:
        p["minFormatScore"] = 1000
    c.api("qualityprofile/%d" % int(pid), p, methode="PUT")


def plan_id(schritte):
    roh = json.dumps([[s.sid, s.aktion, s.titel, s.details] for s in schritte], ensure_ascii=False, sort_keys=True)
    return hashlib.sha256(roh.encode("utf-8")).hexdigest()[:20]


def vorschau(opt, dienste):
    schritte = plan(opt, dienste)
    return {"plan_id": plan_id(schritte), "schritte": [s.oeffentlich() for s in schritte],
            "aenderungen": sum(1 for s in schritte if s.aktion in ("neu", "aendern")),
            "fehler": sum(1 for s in schritte if s.aktion == "fehler")}


def anwenden(opt, dienste, erwartet):
    """Fuehrt den frisch berechneten Plan aus, wenn er dem gezeigten (plan_id) entspricht."""
    schritte = plan(opt, dienste)
    if not erwartet or plan_id(schritte) != str(erwartet):
        raise PlanFehler("Der Stand hat sich seit der Vorschau geändert – bitte die Vorschau neu laden und noch einmal prüfen.")
    ergebnis, fertig = [], {}
    for s in schritte:
        if s.aktion not in ("neu", "aendern") or not s.tun:
            continue
        if any(fertig.get(a) is False for a in s.abhaengig):
            ergebnis.append({"id": s.sid, "titel": s.titel, "ok": False, "text": "übersprungen, weil ein Schritt davor fehlschlug"})
            fertig[s.sid] = False
            continue
        try:
            s.tun()
            ergebnis.append({"id": s.sid, "titel": s.titel, "ok": True, "text": "erledigt"})
            fertig[s.sid] = True
        except Exception as fehler:
            ergebnis.append({"id": s.sid, "titel": s.titel, "ok": False, "text": _bereinigt(fehler, dienste)})
            fertig[s.sid] = False
    return {"ergebnis": ergebnis, "ok": all(e["ok"] for e in ergebnis)}


def _bereinigt(fehler, dienste):
    text = str(fehler)
    for c in dienste.values():
        for k in ("api_key", "pass", "password"):
            geheim = str(c.werte.get(k) or "")
            if len(geheim) >= 4:
                text = text.replace(geheim, "<geheim>")
    return text[:200]
