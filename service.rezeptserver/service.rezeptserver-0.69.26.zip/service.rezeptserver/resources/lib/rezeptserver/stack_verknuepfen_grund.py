"""Stack-Assistent, Grundlage: Optionen pruefen und Hilfen fuer die API-Aufrufe.

PlanFehler, Adress- und Schalterpruefung, optionen_lesen() sowie die kleinen Helfer fuer Schema und
API-Lesen/Schreiben. Der Plan und seine Ausfuehrung stehen in stack_verknuepfen.py.
"""

import re
from urllib.parse import urlsplit

from .dienste_grund import DienstFehler

WURZEL = {"sonarr": "/data/media/tv", "radarr": "/data/media/movies"}
UNTERSTUETZTE_DOWNLOADER = ("nzbget", "sabnzbd")


class PlanFehler(ValueError):
    pass


def _bool(x, standard=False):
    return standard if x is None else bool(x)


def _adresse(text, standard=""):
    text = str(text or "").strip().rstrip("/") or standard
    if not text:
        return ""
    if "://" not in text:
        text = "http://" + text
    t = urlsplit(text)
    if t.scheme not in ("http", "https") or not t.hostname or t.username or t.password:
        raise PlanFehler("Ungültige Adresse: %s" % text[:80])
    return text


def optionen_lesen(roh, dienste):
    """Eingabe der Oberflaeche pruefen und mit Standardwerten fuellen. Nur eingerichtete Dienste sind erlaubt."""
    roh = roh if isinstance(roh, dict) else {}
    opt = {"ids": {}, "schritte": {}, "intern": {}}

    def finden(feld, typen):
        wahl = str(roh.get(feld) or "")
        passend = [i for i, c in sorted(dienste.items()) if c.typ in typen]
        if wahl == "-":
            return ""
        if wahl:
            if wahl not in passend:
                raise PlanFehler("Dienst %s gibt es nicht (%s)" % (feld, wahl[:40]))
            return wahl
        return passend[0] if len(passend) == 1 else ""

    opt["ids"] = {"prowlarr": finden("prowlarr", ("prowlarr",)), "sonarr": finden("sonarr", ("sonarr",)),
                  "radarr": finden("radarr", ("radarr",)), "downloader": finden("downloader", UNTERSTUETZTE_DOWNLOADER)}
    s = roh.get("schritte") if isinstance(roh.get("schritte"), dict) else {}
    opt["schritte"] = {"prowlarr": _bool(s.get("prowlarr"), True), "wurzel": _bool(s.get("wurzel"), True),
                       "downloader": _bool(s.get("downloader"), True), "benennung": _bool(s.get("benennung"), True),
                       "propers": _bool(s.get("propers"), True), "deutsch": _bool(s.get("deutsch"), False),
                       "nur_deutsch": _bool(s.get("nur_deutsch"), False)}
    i = roh.get("intern") if isinstance(roh.get("intern"), dict) else {}
    for typ in ("prowlarr", "sonarr", "radarr", "downloader"):
        c = dienste.get(opt["ids"][typ])
        opt["intern"][typ] = _adresse(i.get(typ), c.url if c else "")
    opt["wurzel"] = {t: str(((roh.get("wurzel") or {}) if isinstance(roh.get("wurzel"), dict) else {}).get(t) or WURZEL[t]).strip()[:200]
                     for t in WURZEL}
    for pfad in opt["wurzel"].values():
        if not pfad.startswith("/") and not re.match(r"^[A-Za-z]:[\\/]", pfad):
            raise PlanFehler("Ordner müssen vollständige Pfade sein: %s" % pfad[:60])
    profile = roh.get("profile") if isinstance(roh.get("profile"), dict) else {}
    opt["profile"] = {t: sorted({int(x) for x in (profile.get(t) or []) if str(x).isdigit()})[:50] for t in ("sonarr", "radarr")}
    return opt


class _Schritt:
    def __init__(self, sid, gruppe, titel, aktion, details=(), tun=None, abhaengig=()):
        self.sid, self.gruppe, self.titel, self.aktion = sid, gruppe, titel, aktion
        self.details, self.tun, self.abhaengig = [str(d)[:220] for d in details], tun, tuple(abhaengig)

    def oeffentlich(self):
        return {"id": self.sid, "gruppe": self.gruppe, "titel": self.titel, "aktion": self.aktion, "details": self.details}


def _lesen(c, pfad):
    try:
        return c.api(pfad), None
    except Exception as fehler:
        return None, str(fehler)[:160]


def _felder_setzen(vorlage, werte):
    """Schema-Vorlage von Sonarr/Radarr/Prowlarr: Felder nach Namen fuellen, der Rest bleibt Standard."""
    ergebnis = dict(vorlage)
    ergebnis["fields"] = [dict(f, value=werte[f["name"]]) if f.get("name") in werte else dict(f) for f in vorlage.get("fields") or []]
    unbekannt = [n for n in werte if n not in {f.get("name") for f in vorlage.get("fields") or []}]
    return ergebnis, unbekannt


def _schema(c, pfad, implementierung):
    liste, fehler = _lesen(c, pfad)
    if fehler:
        raise DienstFehler(fehler)
    for v in liste or []:
        if isinstance(v, dict) and str(v.get("implementation")) == implementierung:
            return v
    raise DienstFehler("%s kennt „%s“ nicht" % (c.typ_name, implementierung))
