"""Stack-Zustand: Gesundheit, Verzeichnis-Layout, Tuning-Hinweise und Datenverbrauch der eingerichteten Dienste.

Nur lesend. Die Ideen stammen aus dem Usenet-Kompass (MIT-Lizenz: Stack-Aufbau nach TRaSH-Guides mit gemeinsamem
/data-Stamm, Verbindungszahl und Cache der Downloader) und aus nzbfast (GPL-3.0-oder-neuer; hier ist nur das
Verhalten nachgebaut, kein Code uebernommen: gemeinsame Wurzel von Downloads und Bibliothek, Datenverbrauch je
Usenet-Server). Zugangsdaten werden gelesen, wenn ein Dienst sie braucht, aber nie ausgegeben. Alles laeuft ueber die
vorhandenen Clients und ist deshalb mit Attrappen ohne Netz testbar.
"""

import re
import time
from datetime import date, timedelta
from pathlib import PurePosixPath

from .dienste_grund import ARR_TYPEN, DienstFehler, _bytes, http as _http, json

STUFEN = ("fehler", "warnung", "hinweis")
_GESUND = {"error": "fehler", "warning": "warnung", "notice": "hinweis"}
MAX_HINWEIS = 200


def _kurz(text):
    return " ".join(str(text or "").split())[:MAX_HINWEIS]


def _hinweis(stufe, von, text, tipp=""):
    return {"stufe": stufe, "von": str(von), "text": _kurz(text), "tipp": _kurz(tipp)}


# --- Gesundheit ----------------------------------------------------------------------------------------------

def einzeln(c):
    """Ein Dienst: erreichbar?, Version/Text, Antwortzeit und die Gesundheitsmeldungen von Sonarr/Radarr/Prowlarr."""
    erg = {"name": c.name, "typ": c.typ, "typ_name": c.typ_name, "ok": False, "text": "", "ms": None, "meldungen": []}
    t0 = time.monotonic()
    try:
        erg["text"] = _kurz(c.pruefen())
        erg["ok"] = True
    except Exception as fehler:  # ein Dienst darf die Uebersicht nie abbrechen
        erg["text"] = _kurz(fehler) or fehler.__class__.__name__
    erg["ms"] = int((time.monotonic() - t0) * 1000)
    if erg["ok"] and (c.typ in ARR_TYPEN or c.typ == "prowlarr"):
        try:
            for m in c.api("health") or []:
                stufe = _GESUND.get(str(m.get("type") or "").lower())
                if stufe:  # "ok" ist keine Meldung
                    erg["meldungen"].append({"stufe": stufe, "text": _kurz(m.get("message")), "quelle": _kurz(m.get("source"))})
        except Exception:
            pass
    return erg


def jellyfin(name, url, token="", holen=None):
    """Jellyfin: erreichbar (oeffentliche Info), Version und - mit API-Schluessel - ob Hardware-Transcoding eingestellt ist."""
    holen = holen or _http
    url = str(url or "").strip().rstrip("/")
    erg = {"name": name, "typ": "jellyfin", "typ_name": "Jellyfin", "ok": False, "text": "", "ms": None, "meldungen": []}
    t0 = time.monotonic()
    try:
        status, _, text = holen(url + "/System/Info/Public", "GET", {"Accept": "application/json"}, None, 10.0)
        d = json.loads(text) if text.strip() else {}
        if status >= 400 or not isinstance(d, dict):
            raise DienstFehler("HTTP %d" % status)
        erg["ok"] = True
        erg["text"] = _kurz("Jellyfin %s (%s)" % (d.get("Version", ""), d.get("ServerName", "")))
    except Exception as fehler:
        erg["text"] = _kurz(fehler) or fehler.__class__.__name__
    erg["ms"] = int((time.monotonic() - t0) * 1000)
    if erg["ok"] and token:
        try:
            from .anbindungen_heimserver import jellyfin_kopf
            status, _, text = holen(url + "/System/Configuration/encoding", "GET", dict(jellyfin_kopf(token), Accept="application/json"), None, 10.0)
            if status == 200:
                art = str(json.loads(text).get("HardwareAccelerationType") or "none").lower()
                erg["hardware"] = art
                if art in ("", "none"):
                    erg["meldungen"].append({"stufe": "hinweis", "quelle": "Transcoding", "text":
                                             "Hardware-Transcoding ist aus. Mit Intel QuickSync/VAAPI (/dev/dri) entlastet es den Prozessor deutlich."})
        except Exception:
            pass
    return erg


# --- Pfade: gemeinsame Wurzel ----------------------------------------------------------------------------------

def pfad_teile(pfad):
    """('/data/media/tv' | 'C:\\Medien\\tv') -> ('laufwerk-oder-leer', ['data', 'media', 'tv']); None bei relativem Pfad."""
    p = str(pfad or "").strip().replace("\\", "/")
    m = re.match(r"^([A-Za-z]):/(.*)$", p)
    laufwerk = ""
    if m:
        laufwerk, p = m.group(1).lower() + ":", "/" + m.group(2)
    if not p.startswith("/"):
        return None
    teile = [t for t in PurePosixPath(p).parts if t != "/"]
    return laufwerk, [t.lower() for t in teile]


def wurzel(pfad):
    """Oberster Ordner eines absoluten Pfads, z. B. '/data' (leer bei Wurzel oder relativem Pfad)."""
    t = pfad_teile(pfad)
    return (t[0] + "/" + t[1][0]) if t and t[1] else ""


def pfad_abgleich(arr_ordner, downloader_pfade):
    """Liegen Downloads und Bibliothek unter einer gemeinsamen Wurzel? Vorbild: nzbfast (Docker-Abschnitt) und TRaSH.

    arr_ordner: {name: [pfad]} der Root-Folder; downloader_pfade: {name: [pfad]} der Zielordner fertiger Downloads.
    Rueckgabe: Liste Hinweise. Unter einer Wurzel ist der Import ein Umbenennen (sofort, ohne zweite Kopie); sonst wird
    kopiert, oder die *arr brauchen einen Remote-Pfad, damit sie die Dateien ueberhaupt finden."""
    hinweise = []
    for dname, dpfade in downloader_pfade.items():
        for dp in dpfade:
            dw = wurzel(dp)
            if not dw:
                hinweise.append(_hinweis("hinweis", dname, "Der Zielordner „%s“ ist relativ oder die Wurzel selbst; ein Vergleich mit der Bibliothek ist nicht möglich." % dp))
                continue
            for aname, apfade in arr_ordner.items():
                for ap in apfade:
                    aw = wurzel(ap)
                    if aw and aw != dw:
                        hinweise.append(_hinweis(
                            "warnung", "%s ↔ %s" % (dname, aname),
                            "Downloads (%s) und Bibliothek (%s) haben keine gemeinsame Wurzel (%s ≠ %s)." % (dp, ap, dw, aw),
                            "Ein gemeinsamer Stamm wie /data (Downloads unter /data/usenet, Bibliothek unter /data/media) macht den Import zum "
                            "sofortigen Umbenennen. Sonst wird jede Datei kopiert, und beide Programme müssen denselben Pfad für denselben Ort verwenden."))
    return hinweise


# --- Layout-Hinweise je *arr ------------------------------------------------------------------------------------

def arr_hinweise(c):
    """Lesende Pruefung eines Sonarr/Radarr: Ordner, Hardlinks, Remote-Pfade, Download-Client, Benennung. -> (hinweise, ordner)."""
    h, ordner = [], []
    try:
        ordner = [o.get("path", "") for o in c.api("rootfolder") or [] if isinstance(o, dict)]
    except Exception as fehler:
        return [_hinweis("fehler", c.name, "Root-Ordner nicht lesbar: %s" % fehler)], []
    if not ordner:
        h.append(_hinweis("warnung", c.name, "Kein Root-Ordner eingerichtet.", "Im Assistenten „Verknüpfen“ anlegen lassen (/data/media/tv bzw. /data/media/movies)."))
    for p in ordner:
        t = pfad_teile(p)
        if t and t[1] and t[1][0] != "data":
            h.append(_hinweis("hinweis", c.name, "Root-Ordner %s liegt nicht unter /data." % p,
                              "Nach TRaSH-Guides liegt alles unter einem Stamm: /data/media/… und /data/usenet/…"))
    try:
        mm = c.api("config/mediamanagement")
        if isinstance(mm, dict):
            if mm.get("copyUsingHardlinks") is False:
                h.append(_hinweis("hinweis", c.name, "Hardlinks sind aus: Importe kopieren die Datei.", "Unter Medien-Verwaltung „Hardlinks statt Kopieren“ einschalten."))
            if mm.get("downloadPropersAndRepacks") not in (None, "doNotPrefer"):
                h.append(_hinweis("hinweis", c.name, "Propers/Repacks werden bevorzugt.", "Der Usenet-Kompass setzt „Nicht bevorzugen“ und steuert das über Custom Formats."))
    except Exception:
        pass
    try:
        zuordnung = c.api("remotepathmapping")
        if isinstance(zuordnung, list) and zuordnung:
            h.append(_hinweis("hinweis", c.name, "%d Remote-Pfad-Zuordnung(en) eingetragen." % len(zuordnung),
                              "Ein gemeinsamer Stamm macht sie überflüssig (gleicher Pfad in allen Containern)."))
    except Exception:
        pass
    try:
        clients = c.api("downloadclient")
        if isinstance(clients, list) and not [x for x in clients if x.get("enable")]:
            h.append(_hinweis("warnung", c.name, "Kein aktiver Download-Client.", "Im Assistenten „Verknüpfen“ NZBGet oder SABnzbd eintragen lassen."))
    except Exception:
        pass
    try:
        naming = c.api("config/naming")
        if isinstance(naming, dict) and naming.get("renameEpisodes", naming.get("renameMovies")) is False:
            h.append(_hinweis("hinweis", c.name, "Umbenennen ist aus: Dateinamen bleiben, wie die Release-Gruppe sie vergibt."))
    except Exception:
        pass
    return h, ordner


def prowlarr_hinweise(c, arrs):
    h = []
    try:
        indexer = c.api("indexer")
        if isinstance(indexer, list) and not indexer:
            h.append(_hinweis("warnung", c.name, "Noch kein Indexer in Prowlarr.", "Indexer in Prowlarr eintragen; er wird dann an Sonarr/Radarr weitergegeben."))
    except Exception:
        pass
    try:
        apps = c.api("applications")
        gefunden = {str(a.get("implementation") or "").lower() for a in apps or [] if isinstance(a, dict)}
        for a in arrs:
            if a.typ in ("sonarr", "radarr") and a.typ not in gefunden:
                h.append(_hinweis("warnung", c.name, "%s ist in Prowlarr nicht als Anwendung eingetragen." % a.typ_name,
                                  "Im Assistenten „Verknüpfen“ mit Voll-Sync eintragen lassen."))
    except Exception:
        pass
    return h


# --- Downloader: Zielordner, Tuning, Datenverbrauch -------------------------------------------------------------

def _gross(text):
    """'1G', '512M', '1024' (Byte) -> Bytes; None wenn unlesbar."""
    m = re.match(r"^\s*([\d.,]+)\s*([KMGT]?)B?\s*$", str(text or ""), re.I)
    if not m:
        return None
    try:
        zahl = float(m.group(1).replace(",", "."))
    except ValueError:
        return None
    return int(zahl * {"": 1, "K": 1 << 10, "M": 1 << 20, "G": 1 << 30, "T": 1 << 40}[m.group(2).upper()])


def downloader_lesen(c):
    """-> {"pfade": [fertig-Ordner], "hinweise": [..]} aus den Einstellungen von NZBGet/SABnzbd (nur lesend)."""
    from . import dienste_einstellungen
    pfade, h = [], []
    try:
        roh = dienste_einstellungen._rohwerte(c)
    except Exception:
        return {"pfade": [], "hinweise": []}
    if c.typ == "nzbget":
        if roh.get("DestDir"):
            pfade.append(str(roh["DestDir"]))
        n = 1
        while "Server%d.Host" % n in roh or "Server%d.Connections" % n in roh:
            try:
                verb = int(float(roh.get("Server%d.Connections" % n) or 0))
            except ValueError:
                verb = 0
            if verb > 20:
                h.append(_hinweis("hinweis", c.name, "Server %d: %d Verbindungen." % (n, verb),
                                  "Mehr als 15–20 bremsen kleine Systeme eher (Kompass-Messung: 27 % Einbruch bei 30 Verbindungen auf 2 vCPU); an Gigabit reichen 15–20."))
            n += 1
        try:
            if int(float(roh.get("ArticleCache") or 0)) == 0:
                h.append(_hinweis("hinweis", c.name, "Artikel-Zwischenspeicher ist aus.", "Ein Puffer (z. B. 200 MB) bündelt die Schreibzugriffe auf der Platte."))
        except ValueError:
            pass
    elif c.typ == "sabnzbd":
        misc = roh.get("misc") if isinstance(roh.get("misc"), dict) else {}
        if misc.get("complete_dir"):
            pfade.append(str(misc["complete_dir"]))
        cache = _gross(misc.get("cache_limit"))
        if cache is not None and cache < (512 << 20):
            h.append(_hinweis("hinweis", c.name, "Artikel-Zwischenspeicher ist klein (%s)." % (misc.get("cache_limit") or "aus"),
                              "Der Kompass empfiehlt 512M bis 1G: SABnzbd schreibt dann in großen Blöcken statt tausender Fragmente."))
        for s in roh.get("servers") if isinstance(roh.get("servers"), list) else []:
            try:
                verb = int(float((s or {}).get("connections") or 0))
            except (TypeError, ValueError):
                verb = 0
            if verb > 20:
                h.append(_hinweis("hinweis", c.name, "Server „%s“: %d Verbindungen." % ((s or {}).get("name") or (s or {}).get("host") or "?", verb),
                                  "Mehr als 15–20 bremsen kleine Systeme eher; an Gigabit reichen 15–20."))
    return {"pfade": pfade, "hinweise": h}


def _tag(n):
    return (date(1970, 1, 1) + timedelta(days=int(n))).isoformat()


def verbrauch(c, heute=None):
    """Datenverbrauch je Usenet-Server aus SABnzbd (server_stats) oder NZBGet (servervolumes): Rangliste nach Gesamtmenge.

    -> [{"name", "gesamt", "monat", "woche", "tag", "tage": [{"tag", "bytes"}] (letzte 7 Tage)}]"""
    heute = heute or date.today()
    ergebnis = []
    if c.typ == "sabnzbd":
        d = c.api(mode="server_stats")
        for name, s in (d.get("servers") or {}).items() if isinstance(d, dict) else []:
            if not isinstance(s, dict):
                continue
            taeglich = s.get("daily") if isinstance(s.get("daily"), dict) else {}
            tage = [{"tag": (heute - timedelta(days=i)).isoformat()} for i in range(6, -1, -1)]
            for t in tage:
                t["bytes"] = int(taeglich.get(t["tag"]) or 0)
            ergebnis.append({"name": str(name), "gesamt": int(s.get("total") or 0), "monat": int(s.get("month") or 0),
                             "woche": int(s.get("week") or 0), "tag": int(s.get("day") or 0), "tage": tage})
    elif c.typ == "nzbget":
        namen = {}
        for o in c.rpc("config") or []:
            m = re.match(r"^Server(\d+)\.Name$", str(o.get("Name") or ""))
            if m:
                namen[int(m.group(1))] = str(o.get("Value") or "")
        for v in c.rpc("servervolumes") or []:
            if not isinstance(v, dict) or int(v.get("ServerID") or 0) == 0:
                continue  # ServerID 0 ist die Summe ueber alle Server
            nr = int(v["ServerID"])
            pro_tag = v.get("BytesPerDays") if isinstance(v.get("BytesPerDays"), list) else []
            erster = v.get("FirstDay")
            tage = []
            for i, e in enumerate(pro_tag):
                if isinstance(e, dict) and erster is not None:
                    tage.append({"tag": _tag(int(erster) + i), "bytes": _bytes(e, "Size")})
            tage = tage[-7:]
            letzte = lambda n: sum(t["bytes"] for t in tage[-n:])  # noqa: E731
            ergebnis.append({"name": namen.get(nr) or "Server %d" % nr, "gesamt": _bytes(v, "TotalSize"),
                             "monat": 0, "woche": letzte(7), "tag": letzte(1), "tage": tage})
    else:
        raise DienstFehler("%s liefert keine Verbrauchszahlen" % c.typ_name)
    ergebnis.sort(key=lambda e: -e["gesamt"])
    return ergebnis


# --- Zusammenfassen ------------------------------------------------------------------------------------------------

def zusammenstellen(zustaende, hinweise):
    """Eine Zeile Fazit: wie viele erreichbar, wie viele Meldungen."""
    ok = sum(1 for z in zustaende if z["ok"])
    meldungen = sum(len(z["meldungen"]) for z in zustaende) + len(hinweise)
    schlimm = [h for h in hinweise if h["stufe"] in ("fehler", "warnung")]
    return {"erreichbar": ok, "gesamt": len(zustaende), "meldungen": meldungen, "warnungen": len(schlimm)}
