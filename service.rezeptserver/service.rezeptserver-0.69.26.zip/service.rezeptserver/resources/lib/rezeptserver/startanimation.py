"""Startanimation der App: eigenes Bild oder Video, das beim Oeffnen von H0rSt laeuft.

Die Dateiendung ist egal – das Format wird am Inhalt erkannt (die ersten Bytes). Abgespielt wird in der App mit
Media3/ExoPlayer samt FFmpeg-Decodern (Videos) bzw. Androids ImageDecoder (Bilder, auch animiertes GIF, WebP,
AVIF und HEIF). Die App holt sich die Datei vom Server und legt sie bei sich ab, damit sie schon vor dem
Serverstart da ist.

Datei: <Datenordner>/startanimation.<endung>, dazu startanimation.json {"art", "mime", "groesse", "zeit"}.
Einstellungen (Einstellungen -> Start & Baukasten): startanimation (standard|eigene|aus), startanimation_laenge,
startanimation_ton.
"""

import json
import os
import time

NAME = "startanimation"
MAX_GROESSE = 64 * 1024 * 1024

# mime -> Endung (fuer den Datei-Typ beim Ausliefern)
ENDUNGEN = {"image/jpeg": ".jpg", "image/png": ".png", "image/gif": ".gif", "image/webp": ".webp", "image/avif": ".avif",
            "image/heif": ".heic", "image/bmp": ".bmp", "video/mp4": ".mp4", "video/quicktime": ".mov",
            "video/3gpp": ".3gp", "video/webm": ".webm", "video/x-matroska": ".mkv", "video/mp2t": ".ts",
            "video/ogg": ".ogv", "video/x-msvideo": ".avi", "video/x-flv": ".flv"}
_BILD_MARKEN = {b"avif": "image/avif", b"avis": "image/avif", b"heic": "image/heif", b"heix": "image/heif",
                b"heim": "image/heif", b"heis": "image/heif", b"hevc": "image/heif", b"mif1": "image/heif",
                b"msf1": "image/heif"}


class AnimationsFehler(ValueError):
    pass


def erkennen(kopf):
    """(art, mime) aus den ersten Bytes, art "bild" oder "video"; None, wenn es weder Bild noch Video ist."""
    k = bytes(kopf[:512])
    if k.startswith(b"\xff\xd8\xff"):
        return "bild", "image/jpeg"
    if k.startswith(b"\x89PNG\r\n\x1a\n"):
        return "bild", "image/png"  # auch APNG (animiert)
    if k[:6] in (b"GIF87a", b"GIF89a"):
        return "bild", "image/gif"
    if k[:4] == b"RIFF" and k[8:12] == b"WEBP":
        return "bild", "image/webp"
    if k[:4] == b"RIFF" and k[8:12] == b"AVI ":
        return "video", "video/x-msvideo"
    if k[:2] == b"BM" and len(k) > 14:
        return "bild", "image/bmp"
    if k[4:8] == b"ftyp":  # ISO-BMFF: MP4, MOV, 3GP, AVIF, HEIF
        marke = k[8:12]
        if marke in _BILD_MARKEN:
            return "bild", _BILD_MARKEN[marke]
        if marke == b"qt  ":
            return "video", "video/quicktime"
        if marke.startswith(b"3g"):
            return "video", "video/3gpp"
        return "video", "video/mp4"
    if k.startswith(b"\x1a\x45\xdf\xa3"):  # EBML: WebM oder Matroska
        return "video", "video/webm" if b"webm" in k[:64] else "video/x-matroska"
    if k[:1] == b"\x47" and len(k) > 188 and k[188:189] == b"\x47":
        return "video", "video/mp2t"
    if k.startswith(b"OggS"):
        return "video", "video/ogg"
    if k.startswith(b"FLV\x01"):
        return "video", "video/x-flv"
    return None


def _meta_pfad(ordner):
    return os.path.join(ordner, NAME + ".json")


def info(ordner):
    """{"art", "mime", "groesse", "zeit", "pfad"} der eigenen Startanimation oder None."""
    try:
        with open(_meta_pfad(ordner), encoding="utf-8") as f:
            meta = json.load(f)
        pfad = os.path.join(ordner, NAME + ENDUNGEN[meta["mime"]])
    except (OSError, ValueError, KeyError, TypeError):
        return None
    if not os.path.isfile(pfad):
        return None
    return dict(meta, pfad=pfad)


def entfernen(ordner):
    for endung in set(ENDUNGEN.values()) | {".json"}:
        try:
            os.remove(os.path.join(ordner, NAME + endung))
        except OSError:
            pass


def speichern(ordner, roh):
    """Bild oder Video speichern (ersetzt die bisherige Datei). Gibt die Info ohne Pfad zurueck."""
    if not roh:
        raise AnimationsFehler("Keine Datei")
    if len(roh) > MAX_GROESSE:
        raise AnimationsFehler("Zu groß (höchstens %d MB)" % (MAX_GROESSE // (1024 * 1024)))
    erkannt = erkennen(roh)
    if not erkannt:
        raise AnimationsFehler("Kein Bild oder Video erkannt. Geht: JPEG, PNG, GIF, WebP, AVIF, HEIF, BMP, "
                               "MP4, MOV, 3GP, MKV, WebM, TS, OGG, AVI, FLV – die Endung ist egal.")
    art, mime = erkannt
    entfernen(ordner)
    with open(os.path.join(ordner, NAME + ENDUNGEN[mime]), "wb") as f:
        f.write(roh)
    meta = {"art": art, "mime": mime, "groesse": len(roh), "zeit": int(time.time())}
    with open(_meta_pfad(ordner), "w", encoding="utf-8") as f:
        json.dump(meta, f)
    return meta
