"""Streaming-, Musik- und Mediathek-Dienste in Deutschland: Start- und Suchseiten.

H0rSt spielt keine DRM-Streams ab und umgeht keine Anmeldeschranken. Dieses Verzeichnis sammelt nur die
oeffentlichen Startseiten (auf Android oeffnet das System damit die installierte App) und - wo belegbar -
die oeffentliche Suchseite. Wer einen Katalog im freien Stremio-Addon "Streaming Catalogs" hat, bekommt
zusaetzlich die Reihen "gerade beliebt in Deutschland" (kataloge.py).

Eigene Dienste stehen in den Nutzerdaten unter kataloge.dienste; sie werden hier mit den eingebauten
zusammengefuehrt. Ein eigener Dienst braucht Name und Startseite, optional eine Suchadresse mit {titel}.
"""
import re

MAX_DIENSTE = 50
ARTEN = {"video": "Streaming & Video", "musik": "Musik", "frei": "Mediatheken"}

# id, Name, Art, Startseite, Suchadresse (mit {titel}, leer = keine belegte Suche), Katalog-id im Addon,
# Kuerzel fuer die Kachel, Farbe. Keine geratenen Tiefenlinks: Suchadressen nur, wo die oeffentliche Suche
# getestet wurde; sonst bleibt es bei der Startseite.
DIENSTE = [
    {"id": "netflix", "name": "Netflix", "art": "video", "seite": "https://www.netflix.com/de/",
     "suche": "https://www.netflix.com/search?q={titel}", "katalog": "nfx", "symbol": "N", "farbe": "#e50914"},
    {"id": "prime", "name": "Prime Video", "art": "video", "seite": "https://www.primevideo.com/",
     "suche": "https://www.primevideo.com/search/?phrase={titel}", "katalog": "amp", "symbol": "P", "farbe": "#00a8e1"},
    {"id": "disney", "name": "Disney+", "art": "video", "seite": "https://www.disneyplus.com/de-de",
     "suche": "", "katalog": "dnp", "symbol": "D+", "farbe": "#113ccf"},
    {"id": "joyn", "name": "Joyn", "art": "video", "seite": "https://www.joyn.de/",
     "suche": "", "katalog": "", "symbol": "J", "farbe": "#ff4e00"},
    {"id": "rtlplus", "name": "RTL+", "art": "video", "seite": "https://plus.rtl.de/",
     "suche": "", "katalog": "", "symbol": "R+", "farbe": "#e6007e"},
    {"id": "sky", "name": "Sky", "art": "video", "seite": "https://www.sky.de/",
     "suche": "", "katalog": "sgo", "symbol": "S", "farbe": "#0072c6"},
    {"id": "wow", "name": "WoW", "art": "video", "seite": "https://www.wowtv.de/",
     "suche": "", "katalog": "", "symbol": "W", "farbe": "#00c2a8"},
    {"id": "hbo", "name": "HBO Max", "art": "video", "seite": "https://www.hbomax.com/de/de",
     "suche": "", "katalog": "hbm", "symbol": "H", "farbe": "#5b0ee6"},
    {"id": "paramount", "name": "Paramount+", "art": "video", "seite": "https://www.paramountplus.com/de/",
     "suche": "", "katalog": "pmp", "symbol": "P+", "farbe": "#0064ff"},
    {"id": "youtube", "name": "YouTube", "art": "video", "seite": "https://www.youtube.com/",
     "suche": "https://www.youtube.com/results?search_query={titel}", "katalog": "", "symbol": "▶", "farbe": "#ff0000"},
    {"id": "waipu", "name": "waipu.tv", "art": "video", "seite": "https://www.waipu.tv/",
     "suche": "https://www.waipu.tv/suche/?q={titel}", "katalog": "", "symbol": "w", "farbe": "#00a878"},
    {"id": "pluto", "name": "Pluto TV", "art": "video", "seite": "https://pluto.tv/de",
     "suche": "https://pluto.tv/de/search?q={titel}", "katalog": "", "symbol": "PL", "farbe": "#ffcc00"},
    {"id": "crunchyroll", "name": "Crunchyroll", "art": "video", "seite": "https://www.crunchyroll.com/de",
     "suche": "https://www.crunchyroll.com/de/search?q={titel}", "katalog": "cru", "symbol": "CR", "farbe": "#f47521"},
    {"id": "appletv", "name": "Apple TV+", "art": "video", "seite": "https://tv.apple.com/de",
     "suche": "https://tv.apple.com/de/search?term={titel}", "katalog": "atp", "symbol": "tv+", "farbe": "#a6a6a6"},
    {"id": "magentatv", "name": "MagentaTV", "art": "video", "seite": "https://www.magentatv.de/",
     "suche": "", "katalog": "", "symbol": "M", "farbe": "#e20074"},
    {"id": "dazn", "name": "DAZN", "art": "video", "seite": "https://www.dazn.com/de-DE",
     "suche": "", "katalog": "", "symbol": "D", "farbe": "#00e676"},
    {"id": "mubi", "name": "Mubi", "art": "video", "seite": "https://mubi.com/de",
     "suche": "", "katalog": "mbi", "symbol": "M", "farbe": "#001489"},
    {"id": "rakuten", "name": "Rakuten TV", "art": "video", "seite": "https://rakuten.tv/de",
     "suche": "https://rakuten.tv/de/search?q={titel}", "katalog": "", "symbol": "R", "farbe": "#bf0000"},
    {"id": "skyshowtime", "name": "SkyShowtime", "art": "video", "seite": "https://www.skyshowtime.com/de",
     "suche": "", "katalog": "sst", "symbol": "SST", "farbe": "#ff0055"},
    {"id": "soundcloud", "name": "SoundCloud", "art": "musik", "seite": "https://soundcloud.com/",
     "suche": "https://soundcloud.com/search?q={titel}", "katalog": "", "symbol": "SC", "farbe": "#ff5500"},
    {"id": "mixcloud", "name": "Mixcloud", "art": "musik", "seite": "https://www.mixcloud.com/",
     "suche": "https://www.mixcloud.com/search/?q={titel}", "katalog": "", "symbol": "MC", "farbe": "#5000ff"},
    {"id": "ard", "name": "ARD Mediathek", "art": "frei", "seite": "https://www.ardmediathek.de/",
     "suche": "https://www.ardmediathek.de/suche/{titel}", "katalog": "", "symbol": "ARD", "farbe": "#003d7c"},
    {"id": "zdf", "name": "ZDFmediathek", "art": "frei", "seite": "https://www.zdf.de/",
     "suche": "https://www.zdf.de/suche?q={titel}", "katalog": "", "symbol": "ZDF", "farbe": "#fa7d19"},
    {"id": "arte", "name": "ARTE", "art": "frei", "seite": "https://www.arte.tv/de/",
     "suche": "", "katalog": "", "symbol": "ARTE", "farbe": "#ff6a00"},
]
_KATALOGE = {d["katalog"] for d in DIENSTE if d.get("katalog")}
# TMDb schreibt manche Anbieter anders ("Amazon Prime Video", "Disney Plus", "Apple TV Plus").
ALIASE = {"amazon prime video": "prime", "prime video": "prime", "disney plus": "disney", "disney+": "disney",
          "apple tv plus": "appletv", "apple tv+": "appletv", "hbo max": "hbo", "paramount plus": "paramount",
          "paramount+": "paramount", "rtl plus": "rtlplus", "rtl+": "rtlplus", "pluto tv": "pluto"}


_ZUSATZ = re.compile(r"(?i)\s+(?:basic\s+)?with\s+ads$|\s+amazon\s+channel$")


def _normal(text):
    return _ZUSATZ.sub("", " ".join(str(text or "").split())).lower()


def finde(name):
    """Eingebauten Dienst nach Name oder id finden (Schreibweise egal), sonst None."""
    n = _normal(name)
    n = ALIASE.get(n, n)
    return next((d for d in DIENSTE if d["id"] == n or _normal(d["name"]) == n), None)


def seite(name):
    d = finde(name)
    return d["seite"] if d else ""


def suche(name):
    d = finde(name)
    return d.get("suche", "") if d else ""


def mit_eigenen(eigene):
    """Eingebaute Dienste plus eigene aus kataloge.dienste, mit eigen=True/False."""
    sauber = []
    for d in eigene or []:
        if not isinstance(d, dict) or not d.get("name") or not str(d.get("seite") or "").startswith(("http://", "https://")):
            continue
        x = dict(d, eigen=True)
        if x.get("art") not in ARTEN:
            x["art"] = "video"
        sauber.append(x)
    return [dict(d, eigen=False) for d in DIENSTE] + sauber


def _id(name, vorhanden):
    basis = "eigen-" + (re.sub(r"[^a-z0-9]+", "-", _normal(name)).strip("-")[:30] or "dienst")
    kid, nr = basis, 2
    while kid in vorhanden:
        kid = basis + "-" + str(nr)
        nr += 1
    return kid


def aendern(eigene, wunsch):
    """Eigene Dienste aus {dienst_dazu: {...}} bzw. {dienst_weg: id} fortschreiben (nur die eigene Liste)."""
    liste = [dict(x) for x in (eigene or []) if isinstance(x, dict)]
    if "dienst_weg" in wunsch:
        kid = str(wunsch.get("dienst_weg") or "")
        return [x for x in liste if x.get("id") != kid]
    roh = wunsch.get("dienst_dazu")
    if not isinstance(roh, dict):
        return liste
    name = " ".join(str(roh.get("name") or "").split())[:60]
    seite = str(roh.get("seite") or "").strip()[:400]
    suche = str(roh.get("suche") or "").strip()[:400]
    if not name:
        raise ValueError("Name fehlt")
    if not re.match(r"^https?://[^\s]+$", seite):
        raise ValueError("Startseite mit http(s)://")
    if suche and (not re.match(r"^https?://[^\s]+$", suche) or "{titel}" not in suche):
        raise ValueError("Suchadresse mit http(s):// und {titel}")
    vorhandene_ids = {x.get("id") for x in liste} | {d["id"] for d in DIENSTE}
    kid = str(roh.get("id") or "")
    if kid and kid in {d["id"] for d in DIENSTE}:
        raise ValueError("Eingebaute Dienste lassen sich nicht ändern")
    if kid and not any(x.get("id") == kid for x in liste):
        raise ValueError("Eigener Dienst nicht gefunden")
    if any(_normal(x.get("name")) == _normal(name) and x.get("id") != kid for x in DIENSTE + liste):
        raise ValueError("Diesen Dienst gibt es schon")
    art = str(roh.get("art") or "video")
    if art not in ARTEN:
        art = "video"
    katalog = str(roh.get("katalog") or "")[:16]
    if katalog and katalog not in _KATALOGE:
        raise ValueError("Katalog unbekannt")
    farbe = str(roh.get("farbe") or "").strip()
    if farbe and not re.match(r"^#[0-9a-fA-F]{6}$", farbe):
        raise ValueError("Farbe als #RRGGBB")
    neu = {"id": kid or _id(name, vorhandene_ids), "name": name, "art": art, "seite": seite, "suche": suche,
           "katalog": katalog, "symbol": " ".join(str(roh.get("symbol") or "").split())[:3], "farbe": farbe}
    if kid:
        return [x for x in liste if x.get("id") != kid] + [neu]
    if len(liste) >= MAX_DIENSTE:
        raise ValueError("Höchstens %d eigene Dienste" % MAX_DIENSTE)
    return liste + [neu]
