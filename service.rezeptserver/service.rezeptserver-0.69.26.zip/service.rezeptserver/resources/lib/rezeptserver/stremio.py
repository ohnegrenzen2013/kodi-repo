"""Stellt die Rezepte als Stremio-Addon bereit (HTTP + JSON).

Aufgeteilt: Konstanten/Hilfen/HTTP-Server in stremio_grund.py, die Klasse App nach Fach
in stremio_<fach>.py. Nach aussen bleibt alles gleich (rezeptserver.stremio.*)."""

from .stremio_grund import *
from .stremio_grund import _DEBRID, _GEHEIM_IM_PFAD, _GEHEIM_IN_ABFRAGE, _LISTE, _LOGO, _ROUTE, _USENET, __version__, _groesse
from .stremio_kern import KernMixin as _KernMixin
from .stremio_addon import AddonMixin as _AddonMixin
from .stremio_debrid import DebridMixin as _DebridMixin
from .stremio_pflege import PflegeMixin as _PflegeMixin
from .stremio_dlna import DlnaMixin as _DlnaMixin
from .mhub_addon import MhubMixin as _MhubMixin


class App(_KernMixin, _AddonMixin, _DebridMixin, _PflegeMixin, _DlnaMixin, _MhubMixin):
    """Stremio-Addon (und mHub-Addon): Manifest, Kataloge, Meta, Streams, Untertitel und Routing."""
