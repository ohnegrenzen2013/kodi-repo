"""AddonMixin-Mixin
"""

from urllib.parse import parse_qs

from . import einstellungen, usenet_stream

from .stremio_grund import (
    CINEMETA,
    ID_PRAEFIX,
    KATALOG_ID,
    KATALOG_PRAEFIX,
    NetzFehler,
    __version__,
    _groesse,
    filtern,
    id_zu_treffer,
    json,
    log,
    sprachen,
    stremio_stream,
    treffer_zu_id,
)


class AddonMixin:

    # --- Manifest -------------------------------------------------------
    def manifest(self):
        k = self.kette
        typen = ["movie", "series"]
        ressourcen = []
        katalog = []
        finder = k.rolle("finder")
        if finder:
            suche = [{"name": "search", "isRequired": True}]
            # je ein Such-Katalog fuer Filme und Serien (Stremio/ARVIO fuehren die Suche je Typ);
            # ein Tab fuer alle Quellen, bei mehreren Findern zusaetzlich einer je Quelle
            for typ in typen:
                katalog.append({"type": typ, "id": KATALOG_ID, "name": "Alle Quellen", "extra": suche})
                if len(finder) > 1:
                    for m in finder:
                        katalog.append({"type": typ, "id": KATALOG_PRAEFIX + m.id, "name": m.name, "extra": suche})
            ressourcen.append({"name": "catalog", "types": typen})
            ressourcen.append({"name": "meta", "types": typen, "idPrefixes": [ID_PRAEFIX.rstrip(":")]})
        if k.rolle("aufloeser"):
            ressourcen.append({"name": "stream", "types": typen, "idPrefixes": ["tt", ID_PRAEFIX.rstrip(":")]})
        if any("untertitel" in m.gibt for m in k.rolle("anreicherer")) or (self.addons and self.addons.addons):
            ressourcen.append({"name": "subtitles", "types": typen, "idPrefixes": ["tt"]})
        if self.addons and self.addons.addons and not k.rolle("aufloeser"):
            ressourcen.append({"name": "stream", "types": typen, "idPrefixes": ["tt"]})
        return {
            "id": "org.rezeptserver",
            "version": __version__,
            "name": "m0dulh0st - H0rSt",
            # eine Quelle besteht oft aus mehreren Modulen gleichen Namens (Suchen, Aufloesen): jeden Namen nur einmal
            "description": "Module aus JSON-Rezepten: " + ", ".join(dict.fromkeys(m.name for m in k.module)),
            "types": typen,
            "catalogs": katalog,
            "resources": ressourcen,
            "idPrefixes": ["tt", ID_PRAEFIX.rstrip(":")],
            "behaviorHints": {"configurable": False, "adult": self._adult},
        }

    # --- Anfrage aus Stremio-ID ----------------------------------------
    def anfrage_aus_id(self, typ, stremio_id):
        teile = stremio_id.split(":")
        imdb = teile[0]
        staffel = int(teile[1]) if len(teile) > 2 and teile[1].isdigit() else None
        folge = int(teile[2]) if len(teile) > 2 and teile[2].isdigit() else None
        meta = self.cinemeta(typ, imdb)
        name = meta.get("name") or imdb
        jahr = meta.get("year") or str(meta.get("releaseInfo") or "")[:4]
        anfrage = {"text": name, "titel": name, "art": "serie" if typ == "series" else "film",
                   "ids": {"imdb": imdb}}
        if jahr and str(jahr)[:4].isdigit():
            anfrage["jahr"] = int(str(jahr)[:4])
        modus = usenet_stream.konfig(self.ui)
        if modus and modus["ersatzsuche"]:
            anfrage["ersatzsuche"] = True  # Newznab: Ersatzstufen, wenn die Kennungssuche nichts findet
        if staffel is not None and folge is not None:
            anfrage.update(staffel=staffel, folge=folge, text="%s S%02dE%02d" % (name, staffel, folge))
        return anfrage

    def cinemeta(self, typ, imdb):
        schluessel = (typ, imdb)
        with self._sperre:
            if schluessel in self._cache:
                return self._cache[schluessel]
        try:
            text = self._cinemeta.abruf("%s/meta/%s/%s.json" % (CINEMETA, typ, imdb))
            meta = json.loads(text).get("meta") or {}
        except (NetzFehler, ValueError) as fehler:
            log.warning("Cinemeta fuer %s nicht erreichbar: %s", imdb, fehler)
            return {}
        with self._sperre:
            self._cache[schluessel] = meta
        return meta

    # --- binsearch als Newznab-Indexer (/binsearch/api) fuer NZBHydra2, Prowlarr, Sonarr, Radarr ---------------
    def binsearch_newznab(self, abfrage):
        from . import binsearch
        werte = {k: v[0] for k, v in parse_qs(abfrage).items()}
        art = werte.get("t", "search")
        if art == "caps":
            return 200, "application/xml", binsearch.CAPS
        if art not in ("search", "movie", "tvsearch"):
            return 200, "application/xml", binsearch.newznab_fehler(202, "Funktion nicht vorhanden")

        def titel_von_imdb(imdb):
            meta = self.cinemeta("movie", imdb)
            jahr = str(meta.get("year") or meta.get("releaseInfo") or "")[:4]
            return ("%s %s" % (meta.get("name"), jahr)).strip() if meta.get("name") else ""
        text = binsearch.newznab_suchtext(werte, titel_von_imdb)
        try:
            seite = int(werte.get("offset") or 0) // binsearch.PRO_SEITE + 1
        except ValueError:
            seite = 1
        try:
            treffer = binsearch.suchen(text, self._binsearch.abruf, seite) if text else []
        except NetzFehler as fehler:
            return 200, "application/xml", binsearch.newznab_fehler(900, "binsearch nicht erreichbar: %s" % fehler)
        kategorie = "5000" if art == "tvsearch" else "2000" if art == "movie" else (werte.get("cat") or "2000").split(",")[0]
        return 200, "application/xml", binsearch.newznab_xml(treffer, kategorie, (seite - 1) * binsearch.PRO_SEITE)

    # --- Ressourcen -----------------------------------------------------
    def katalog(self, typ, katalog_id, extra):
        if katalog_id == KATALOG_ID:
            nur = None
        elif katalog_id.startswith(KATALOG_PRAEFIX):
            nur = [katalog_id[len(KATALOG_PRAEFIX):]]
        else:
            return {"metas": []}
        suche = extra.get("search", "").strip()
        if not suche:
            return {"metas": []}
        art = "serie" if typ == "series" else "film"
        metas = []
        gefunden = self.kette.suche({"text": suche, "titel": suche, "art": art}, nur=nur)
        for treffer in filtern.treffer_anwenden(gefunden, self.filter):
            details = " · ".join(x for x in (treffer.get("aufloesung"), _groesse(treffer), treffer.get("quelle")) if x)
            meta = {"id": treffer_zu_id(treffer), "type": typ, "name": treffer["titel"]}
            if treffer.get("poster"):
                meta["poster"] = treffer["poster"]
                meta["posterShape"] = "poster"
            jahr = filtern.jahr_von(treffer)
            if jahr:
                meta["releaseInfo"] = str(jahr)
            genres = filtern.genres_von(treffer)
            if genres:
                meta["genres"] = genres[:5]
            if details:
                meta["description"] = details
            metas.append(meta)
        return {"metas": metas}

    def meta(self, typ, stremio_id):
        treffer = id_zu_treffer(stremio_id) if stremio_id.startswith(ID_PRAEFIX) else None
        if not treffer:
            return {"meta": None}
        info = self.kette.anreichern(treffer, "metadaten")
        meta = {"id": stremio_id, "type": typ, "name": info.get("titel") or treffer.get("titel")}
        if info.get("poster") or treffer.get("poster"):
            meta["poster"] = info.get("poster") or treffer.get("poster")
            meta["posterShape"] = "poster"
            meta["background"] = meta["poster"]
        genres = filtern.genres_von(treffer)
        if genres:
            meta["genres"] = genres[:5]
        if info.get("handlung"):
            meta["description"] = info["handlung"]
        if info.get("jahr"):
            meta["releaseInfo"] = str(info["jahr"])
        if info.get("bewertung"):
            meta["imdbRating"] = str(info["bewertung"])
        return {"meta": meta}

    def stream(self, typ, stremio_id, kopf=None):
        # fremde Addons laufen parallel zu den eigenen Rezepten
        fremd = self.kette.ketten_pool.submit(self.addons.streams, typ, stremio_id) \
            if self.addons and stremio_id.startswith("tt") else None
        # Nuvio-kompatible JS-Plugins (NV5-To-Do) laufen ebenfalls parallel, aber nur wenn eingeschaltet
        # (vermeidet unnoetige Pool-Nutzung, da das Feature ab Werk aus ist)
        from . import nuvio_plugin as nuvio_plugin_modul
        daten = self.verwaltung.daten() if self.verwaltung else {}
        nuvio = self.kette.ketten_pool.submit(self.nuvio_plugins.streams, typ, stremio_id, daten) \
            if (self.nuvio_plugins and stremio_id.startswith("tt") and nuvio_plugin_modul.eingeschaltet(daten)) \
            else None
        if stremio_id.startswith(ID_PRAEFIX):
            treffer = id_zu_treffer(stremio_id)
            paare = [(treffer, s) for s in self.kette.aufloesen(treffer)] if treffer else []
        elif stremio_id.startswith("tt"):
            gefunden = self.kette.suche(self.anfrage_aus_id(typ, stremio_id))
            paare = self.kette.aufloesen_alle(filtern.treffer_anwenden(gefunden, self.filter))
        else:
            paare = []
        paare = filtern.streams_anwenden(paare, self.filter)
        if self.audio_wunsch and self.filter["sortierung"] == "relevanz":
            # stabil sortieren: Reihenfolge der Rezepte bleibt innerhalb gleicher Sprache erhalten
            paare.sort(key=lambda p: sprachen.rang(sprachen.audio_von(p[0], p[1]), self.audio_wunsch))
        # NzbDAV/AltMount: NZBs ohne Herunterladen per WebDAV (eingerichtete Usenet-Streamer)
        streamer = [(aid, c) for aid, c in sorted(self.dienste.items()) if getattr(c, "typ", "") in ("nzbdav", "altmount")]
        # Usenet-Streaming-Modus (Einstellungen -> Usenet-Streaming): ordnen, filtern, Sofort erkennen
        modus = usenet_stream.konfig(self.ui)
        if modus:
            sofort = usenet_stream.sofort_namen(streamer) if modus["sofort"] and streamer else set()
            paare = usenet_stream.anwenden(paare, modus, sofort)
        paare = self.usenet_paare_pruefen(paare)
        basis = self.eigene_basis(kopf or {}) if (self.rustnzb or streamer) else None
        kategorie = "TV" if typ == "series" else "Movies"
        if basis:
            # Usenet-Gesundheitspruefung: nur blockierte NZB-Kandidaten raus, Reihenfolge der uebrigen
            # paare sonst unveraendert (kein Umsortieren gegenueber den Addon-Streams in dieser Liste)
            kandidaten = [(s["url"], t.get("titel") or "") for t, s in paare if s.get("nzb")]
            erlaubt = {u for u, _ in self.usenet_kandidaten_pruefen(kandidaten)}
            paare = [(t, s) for t, s in paare if not s.get("nzb") or s["url"] in erlaubt]
        streams = []
        for t, s in paare:
            x = stremio_stream(t, s, self.usenet_server)
            if x:
                streams.append(x)
            if s.get("nzb") and basis:
                # dieselbe NZB als gewoehnlicher Stream (jeder Player, keine Usenet-Server im Player noetig)
                ziele = ([("", "rustnzb")] if self.rustnzb else []) + [(aid, c.typ_name) for aid, c in streamer]
                marke = usenet_stream.marke(t)
                sofort_da = bool((t.get("usenet_stream") or {}).get("sofort"))
                for ziel, name in ziele:
                    y = stremio_stream(t, dict(s, nzb=False, url=self.usenet_adresse(s["url"], t.get("titel"), basis, ziel, kategorie)))
                    schnell = sofort_da and bool(ziel)
                    y["name"] = "%s%s\n%s" % ("⚡ " if schnell else "", y["name"], name)
                    if marke:
                        y["description"] = y["title"] = "%s\n%s" % (y["title"], marke + (" · ⚡ sofort bereit" if schnell else ""))
                    streams.append(y)
        if modus and modus["auto"] and basis and (self.rustnzb or streamer):
            auto = self.usenet_auto_stream(paare, modus, basis, streamer, kategorie)
            if auto:
                streams.insert(0, auto)
        if fremd is not None:
            try:
                streams.extend(fremd.result(timeout=self.addons.zeitgrenze + 2))
            except Exception as fehler:
                log.warning("Stremio-Addons: %s", fehler)
        if nuvio is not None:
            try:
                streams.extend(nuvio.result(timeout=self.nuvio_plugins.zeitlimit_gesamt + 20))
            except Exception as fehler:
                log.warning("Nuvio-Plugins: %s", fehler)
        staffel, folge = self.staffel_folge(stremio_id)
        return {"streams": self.debrid_torrents(self.debrid_umleiten(streams, kopf), kopf, staffel, folge)}

    def usenet_auto_stream(self, paare, modus, basis, streamer, kategorie):
        """Ein Stream "Usenet Auto": probiert die besten Releases der Reihe nach, bis eines ins Streamen kommt
        (Auto-Weiter, bei UsenetStreamer "Smart Play"). Erst NzbDAV/AltMount, sonst rustnzb. None unter zwei Kandidaten."""
        kandidaten = usenet_stream.kandidaten_paket(paare, modus["auto_anzahl"])
        if len(kandidaten) < 2:
            return None
        ziel, anzeige = (streamer[0][0], streamer[0][1].typ_name) if streamer else ("", "rustnzb")
        (url, name), rest = kandidaten[0], kandidaten[1:]
        erstes = next(t for t, s in paare if s.get("url") == url)
        y = stremio_stream(erstes, {"url": self.usenet_adresse(url, name, basis, ziel, kategorie, weitere=rest)})
        zeile = "Probiert bis zu %d Releases nacheinander, bis eines startet." % len(kandidaten)
        y["name"] = "Usenet Auto\n%s" % anzeige
        y["title"] = y["description"] = "%s\n%s" % (zeile, name)
        y["behaviorHints"]["bingeGroup"] = "rezeptserver-usenet-auto"
        return y

    @staticmethod
    def staffel_folge(stremio_id):
        """tt0903747:1:2 -> (1, 2), sonst (None, None)."""
        teile = str(stremio_id).split(":")
        if len(teile) >= 3 and teile[-2].isdigit() and teile[-1].isdigit():
            return int(teile[-2]), int(teile[-1])
        return None, None

    def untertitel(self, typ, stremio_id, kopf=None):
        if not stremio_id.startswith("tt"):
            return {"subtitles": []}
        anfrage = self.anfrage_aus_id(typ, stremio_id)
        wunsch = self.untertitel_wunsch
        # Rezepte koennen {eingabe.sprachen} nutzen, z. B. "de,en"
        eingabe = dict(anfrage, ref=stremio_id, sprachen=",".join(wunsch))
        gefunden = []
        for u in self.kette.untertitel(eingabe):
            code = sprachen.normalisiere(u.get("sprache"))
            if wunsch and code not in wunsch:
                continue
            gefunden.append((wunsch.index(code) if code in wunsch else 0, code, u))
        gefunden.sort(key=lambda g: g[0])
        liste = [{"id": "rz-%d" % nummer, "url": u["url"], "lang": sprachen.drei(code) or "und"}
                 for nummer, (_, code, u) in enumerate(gefunden)]
        if self.addons:
            for u in self.addons.untertitel(typ, stremio_id):
                code = sprachen.normalisiere(u.get("lang"))
                if not wunsch or code in wunsch:
                    liste.append({"id": str(u["id"]), "url": u["url"], "lang": u.get("lang") or "und"})
        quellen = getattr(self, "untertitel_quellen", None)
        if quellen is not None:
            daten = einstellungen.werte(self.verwaltung.daten()) if self.verwaltung else {}
            basis = self.eigene_basis(kopf or {}) or ""
            try:
                for nummer, u in enumerate(quellen.suchen(anfrage, wunsch, daten)):
                    if u.get("url", "").startswith("api/"):
                        u = dict(u, url=basis + u["url"])
                    liste.append({"id": "ext-%d" % nummer, "url": u["url"], "lang": u.get("lang") or "und"})
            except Exception:  # noqa: BLE001 – eine fremde Quelle darf die Untertitel nicht kippen
                log.warning("Zusätzliche Untertitelquelle fehlgeschlagen", exc_info=True)
        return {"subtitles": liste}
