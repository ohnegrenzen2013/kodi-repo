"""DebridMixin-Mixin
"""

from .stremio_grund import (
    NetzFehler,
    USENET_MERKEN,
    _DEBRID,
    _USENET,
    debrid_dienst,
    json,
    log,
    re,
    time,
    unquote,
    urlsplit,
)


AUTO_MAX = 8      # Ersatz-Releases im Auto-Weiter-Link
AUTO_WARTEN = 45  # Sekunden je Versuch beim Auto-Weiter (einzeln: NzbDav.WARTEN)


class DebridMixin:

    def debrid_adresse(self, link, basis="", staffel=None, folge=None, name=None):
        """Adresse dieses Servers, die einen Hoster-Link oder Torrent beim Abspielen freischaltet.
        Bei Torrents waehlen staffel/folge die Datei in einem Staffelpaket."""
        if debrid_dienst.ist_torrent(link):
            if not name:
                dn = re.search(r"[?&]dn=([^&]+)", link)
                name = unquote(dn.group(1).replace("+", " ")) if dn else "video"
            text = link if staffel is None or folge is None else "%s\n%d\n%d" % (link, int(staffel), int(folge))
        else:
            name = name or link.rstrip("/").rsplit("/", 1)[-1]
            text = link
        name = re.sub(r"[^\w.\-]+", "_", str(name))[:80].strip("._") or "video"
        return "%sdebrid/%s/%s" % (basis, self.debrid.schluessel(text), name)

    def debrid_torrents(self, streams, kopf, staffel=None, folge=None):
        """Zu jedem Torrent-Stream (infoHash) einen gewoehnlichen Stream ueber Debrid dazu: laeuft in jedem
        Player, ohne P2P auf dem Geraet. Der Torrent-Stream bleibt fuer Stremios eigene Wiedergabe."""
        basis = self.eigene_basis(kopf or {})
        if not basis or not self.debrid.verfuegbar:
            return streams
        ergebnis = []
        for s in streams:
            ergebnis.append(s)
            kennung = str(s.get("infoHash") or "")
            if not re.match(r"^[0-9a-fA-F]{40}$", kennung) or s.get("url"):
                continue
            hinweise = s.get("behaviorHints") or {}
            name = hinweise.get("filename") or str(s.get("title") or s.get("description") or "").split("\n")[0]
            ergebnis.append({"name": "%s\nDebrid" % s.get("name", ""), "title": s.get("title", ""),
                             "description": s.get("description", s.get("title", "")),
                             "url": self.debrid_adresse(kennung.lower(), basis, staffel, folge, name or None),
                             "behaviorHints": {k: v for k, v in hinweise.items() if k in ("bingeGroup", "filename",
                                                                                           "videoSize")},
                             })
            ergebnis[-1]["behaviorHints"]["notWebReady"] = True
        return ergebnis

    def debrid_umleiten(self, streams, kopf):
        """Hoster-Links ueber Debrid: Stremio bekommt /debrid/... dieses Servers statt des Hoster-Links."""
        basis = self.eigene_basis(kopf or {})
        if not basis or not self.debrid.verfuegbar:
            return streams
        domains = self.debrid.hoster()
        ergebnis = []
        for s in streams:
            if s.get("url") and not (s.get("behaviorHints") or {}).get("proxyHeaders") \
                    and self.debrid.ist_hoster(s["url"], domains):
                hinweise = dict(s.get("behaviorHints") or {}, notWebReady=True)
                s = dict(s, url=self.debrid_adresse(s["url"], basis), behaviorHints=hinweise,
                         name="%s\nDebrid" % s.get("name", ""))
            ergebnis.append(s)
        return ergebnis

    def usenet_adresse(self, nzb_url, name, basis="", ziel="", kategorie="", weitere=None):
        """Adresse dieses Servers, die eine NZB streamt: ueber rustnzbs Mediathek oder (ziel = Anbieter-ID) ueber
        NzbDAV/AltMount; kategorie Movies oder TV. weitere = [[nzb_url, name], ...] sind Ersatz-Releases: scheitert
        das erste, probiert der Server der Reihe nach die naechsten (Auto-Weiter)."""
        name = re.sub(r"[^\w.\-]+", "_", str(name or "video"))[:100].strip("._") or "video"
        text = nzb_url + "\n" + name + ("\n%s\n%s" % (ziel, kategorie or "Movies") if ziel or weitere else "")
        if weitere:
            text += "\n" + json.dumps([[str(u), str(n)] for u, n in weitere[:AUTO_MAX]], ensure_ascii=False,
                                      separators=(",", ":"))
        return "%susenet/%s/%s" % (basis, self.debrid.verpacken(text), name)

    @staticmethod
    def _usenet_weitere(roh):
        """Ersatz-Releases aus dem fuenften Feld des Schluessels, nur gueltige [url, name]-Paare."""
        try:
            liste = json.loads(roh) if roh else []
        except ValueError:
            return []
        return [(str(p[0]), str(p[1])) for p in liste[:AUTO_MAX]
                if isinstance(p, list) and len(p) == 2 and p[0] and isinstance(p[0], str)] if isinstance(liste, list) else []

    def usenet_weiter(self, schluessel):
        """/usenet/<schluessel>: NZB in rustnzbs Mediathek oder NzbDAV/AltMount legen, auf die Videodatei warten,
        durchreichen. Mit Ersatz-Releases im Schluessel (Auto-Weiter) wird beim Scheitern das naechste versucht."""
        from . import dienste as dienste_modul, rustnzb as rustnzb_dienst
        text = self.debrid.auspacken(schluessel)
        if not text or "\n" not in text:
            return 404, "application/json", {"err": "unbekannter oder veralteter Link"}
        nzb_url, name, ziel, kategorie, weitere = (text.split("\n", 4) + ["", "", "", ""])[:5]
        streamer = self.dienste.get(ziel) if ziel else None
        if ziel and not (streamer and hasattr(streamer, "streamen")):
            return 503, "application/json", {"err": "Usenet-Streamer %s ist nicht (mehr) eingerichtet" % ziel}
        if not ziel and not self.rustnzb:
            return 503, "application/json", {"err": "rustnzb ist nicht eingerichtet (Anbieter -> Downloader)"}
        with self._sperre:
            alt = self._usenet.get(schluessel)
        if alt and time.time() - alt[0] < USENET_MERKEN:
            return "wiedergabe", alt[1]
        kandidaten = [(nzb_url, name)] + self._usenet_weitere(weitere)
        fehler_text = ""
        for nummer, (url, titel) in enumerate(kandidaten):
            try:
                if streamer:  # NzbDAV/AltMount: einbinden statt herunterladen, dann per WebDAV
                    zusatz = {"wartezeit": AUTO_WARTEN} if len(kandidaten) > 1 else {}
                    adresse, kopf, _, _ = streamer.streamen(url, titel, kategorie or "Movies", **zusatz)
                else:
                    adresse, kopf, _, _ = self.rustnzb.streamen(titel, lambda u=url: rustnzb_dienst.nzb_laden(u))
                break
            except (rustnzb_dienst.RustnzbFehler, dienste_modul.DienstFehler, NetzFehler) as fehler:
                fehler_text = str(fehler)
                log.warning("Usenet-Stream (%d/%d): %s", nummer + 1, len(kandidaten), fehler)
        else:
            if len(kandidaten) > 1:
                fehler_text = "%d Releases versucht, keines ließ sich einbinden – zuletzt: %s" % (len(kandidaten), fehler_text)
            return 502, "application/json", {"err": fehler_text}
        ziel = (adresse, kopf, [urlsplit(adresse).hostname])
        with self._sperre:
            self._usenet[schluessel] = (time.time(), ziel)
            if len(self._usenet) > 500:
                self._usenet.pop(next(iter(self._usenet)))
        return "wiedergabe", ziel

    def usenet_kandidaten_pruefen(self, kandidaten):
        """NZB-Kandidaten filtern, wenn die Gesundheitspruefung an ist. Sonst dieselbe Liste.

        Vorab: blockiert faellt weg, verifiziert vor unsicher. Hintergrund: Liste unveraendert,
        Pruefung im Hintergrund, bekannte Urteile und ein usenet_ref fuer das spaetere Abzeichen.
        Ohne Schalter oder ohne vollstaendigen NNTP-Zugang: genau die uebergebene Liste.
        """
        kandidaten = kandidaten or []
        war_tupel = bool(kandidaten) and not isinstance(kandidaten[0], dict)
        eintraege = [{"url": str(k[0] if isinstance(k, (tuple, list)) else k.get("url") or ""),
                      "name": str((k[1] if isinstance(k, (tuple, list)) and len(k) > 1 else k.get("name")) or "")
                      if isinstance(k, (tuple, list)) else str(k.get("name") or "")} for k in kandidaten]
        ui = self.ui or {}
        if not ui.get("usenet_healthcheck_an"):
            return kandidaten
        from . import usenet_triage
        werte = usenet_triage.nntp_werte(self.verwaltung.daten() if self.verwaltung else {})
        if not werte:
            return kandidaten
        try:
            stichproben = int(ui.get("usenet_healthcheck_stichproben") or 6)
        except (TypeError, ValueError):
            stichproben = 6
        stichproben = max(2, min(20, stichproben))
        paar = eintraege
        if ui.get("usenet_healthcheck_modus") == "hintergrund":
            usenet_triage.im_hintergrund(paar, werte, stichproben)
            if war_tupel:
                return kandidaten
            ergebnis = []
            for k, eintrag in zip(kandidaten, paar):
                extra = {}
                if eintrag["url"]:
                    extra["usenet_ref"] = self.debrid.verpacken(eintrag["url"])
                    bekannt = usenet_triage.gelesen(eintrag["url"])
                    if bekannt:
                        extra["usenet"] = {"urteil": bekannt["urteil"], "quote": bekannt["quote"]}
                ergebnis.append(dict(k, **extra) if extra else k)
            return ergebnis
        urteile = usenet_triage.mehrere(paar, werte, stichproben=stichproben)
        if war_tupel:
            behalten = [(e["url"], e["name"]) for e in eintraege
                        if (urteile.get(e["url"]) or {}).get("urteil") != "blockiert"]
            rang = {"verifiziert": 0, "unsicher": 1}
            behalten.sort(key=lambda k: rang.get((urteile.get(k[0]) or {}).get("urteil"), 2))
            return behalten
        ergebnis = []
        for k in kandidaten:
            u = urteile.get(str(k.get("url") or ""))
            if u and u.get("urteil") == "blockiert":
                continue
            if u and u.get("urteil") in ("verifiziert", "unsicher"):
                k = dict(k, usenet={"urteil": u["urteil"], "quote": u["quote"]})
            ergebnis.append(k)
        rang = {"verifiziert": 0, "unsicher": 1}
        ergebnis.sort(key=lambda k: rang.get((k.get("usenet") or {}).get("urteil"), 2))
        return ergebnis

    def usenet_paare_pruefen(self, paare):
        """[(treffer, stream)] – NZB-Paare durch usenet_kandidaten_pruefen, andere bleiben an ihrem Platz."""
        paare = list(paare or [])
        nzb_idx = [i for i, (_t, s) in enumerate(paare) if s.get("nzb") and s.get("url")]
        if not nzb_idx:
            return paare
        kandidaten = [{"url": paare[i][1]["url"], "name": str(paare[i][0].get("titel") or ""), "i": i} for i in nzb_idx]
        geprueft = self.usenet_kandidaten_pruefen(kandidaten)
        if geprueft is kandidaten or [k["i"] for k in geprueft] == nzb_idx:
            if geprueft is kandidaten and not any(k.get("usenet") or k.get("usenet_ref") for k in geprueft):
                return paare
            neu = list(paare)
            for k in geprueft:
                if not (k.get("usenet") or k.get("usenet_ref")):
                    continue
                t, s = neu[k["i"]]
                s = dict(s)
                if k.get("usenet"):
                    s["usenet"] = k["usenet"]
                if k.get("usenet_ref"):
                    s["usenet_ref"] = k["usenet_ref"]
                neu[k["i"]] = (t, s)
            return neu
        ergebnis, eingesetzt = [], False
        nzb = set(nzb_idx)
        for i, paar in enumerate(paare):
            if i not in nzb:
                ergebnis.append(paar)
                continue
            if not eingesetzt:
                for k in geprueft:
                    t, s = paare[k["i"]]
                    if k.get("usenet") or k.get("usenet_ref"):
                        s = dict(s)
                        if k.get("usenet"):
                            s["usenet"] = k["usenet"]
                        if k.get("usenet_ref"):
                            s["usenet_ref"] = k["usenet_ref"]
                    ergebnis.append((t, s))
                eingesetzt = True
        return ergebnis

    def usenet_urteile_lesen(self, werte):
        """Nur schon gespeicherte Urteile. urls= kommagetrennt, kein neuer Prueflauf."""
        from . import usenet_triage
        roh = str((werte or {}).get("urls") or "")
        bezuege = [t.strip() for t in roh.split(",") if t.strip()]
        return {"urteile": usenet_triage.urteile_zu(bezuege, self.debrid.auspacken)}

    def markenerkennung_ziel(self, url):
        """Stream-URL (wie ein Client sie aus der Stream-Liste bekommt) -> ziel-Tupel fuer
        markenerkennung_download.herunterladen() - entweder ueber den eigenen /debrid/- oder /usenet/-
        Pfad aufgeloest (derselbe Weg wie beim Abspielen, keine eigene SSRF-/Domain-Logik noetig), oder
        die externe Adresse unveraendert (Addon-URL ohne Debrid/Usenet-Umleitung). None, wenn nicht
        aufloesbar - wirft nie."""
        url = str(url or "")
        pfad = urlsplit(url).path
        treffer = _DEBRID.match(pfad)
        if treffer:
            ergebnis = self.debrid_weiter(treffer.group(1))
            return (ergebnis[1], {}, []) if ergebnis[0] == "weiter" else None
        treffer = _USENET.match(pfad)
        if treffer:
            ergebnis = self.usenet_weiter(treffer.group(1))
            return ergebnis[1] if ergebnis[0] == "wiedergabe" else None
        return (url, {}, []) if url.startswith(("http://", "https://")) else None

    def debrid_weiter(self, schluessel):
        """/debrid/<schluessel>: Hoster-Link freischalten und auf den direkten Link weiterleiten."""
        text = self.debrid.link_aus(schluessel)
        if not text:
            return 404, "application/json", {"err": "unbekannter oder veralteter Link"}
        link, staffel, folge = (text.split("\n") + [None, None])[:3]
        try:
            return "weiter", self.debrid.freischalten(link, staffel=int(staffel) if staffel else None,
                                                       folge=int(folge) if folge else None)["url"]
        except (debrid_dienst.DebridFehler, NetzFehler) as fehler:
            log.warning("Debrid: %s", fehler)
            return 502, "application/json", {"err": str(fehler)}
