"""DlnaMixin: H0rSt als DLNA-Medienserver (dlna_server.py) – Routen /dlna/… und An/Aus zur Laufzeit."""

import xml.etree.ElementTree as ET
from urllib.parse import parse_qs, quote, unquote, urlsplit

from . import dlna_server, heimspeicher, radio
from .stremio_grund import log


class DlnaMixin:

    def dlna_vorbereiten(self, ort, uuid, name="H0rSt"):
        """Vom Dienst gesetzt, wenn H0rSt im Heimnetz laeuft (Adresse der Beschreibung samt Token)."""
        self._dlna = {"ort": ort, "uuid": uuid, "name": name, "ankuendiger": None}

    def medienserver_setzen(self, an):
        """SSDP starten oder stoppen. Gibt zurueck, ob der Medienserver laeuft."""
        d = getattr(self, "_dlna", None)
        if not d:
            return False
        if an and not d["ankuendiger"]:
            a = dlna_server.Ankuendiger(d["uuid"], d["ort"])
            try:
                a.starten()
            except OSError as fehler:
                log.warning("Medienserver (DLNA): SSDP nicht moeglich: %s", fehler)
                return False
            d["ankuendiger"] = a
            log.info("Medienserver (DLNA) im Heimnetz: %s", d["ort"])
        elif not an and d["ankuendiger"]:
            d["ankuendiger"].stoppen()
            d["ankuendiger"] = None
        return d["ankuendiger"] is not None

    def _dlna_quellen(self, kopf):
        daten = self.verwaltung.daten() if self.verwaltung else {}
        favoriten = radio.pruefe_favoriten((daten.get(radio.SCHLUESSEL) or {}).get("favoriten"))
        # Live-TV wie in tv.m3u, mit der Adresse, unter der das Geraet H0rSt erreicht (Host-Kopf)
        pfad = "/%s/tv.m3u" % self.token if self.token else "/tv.m3u"
        try:
            status, _, text = self.bearbeite(pfad, kopf=kopf)
        except Exception as fehler:  # ohne Live-TV bleibt Radio sichtbar
            log.warning("Medienserver: Live-TV nicht lesbar: %s", fehler)
            status, text = 500, ""
        basis = self.eigene_basis(kopf) or "/"
        heim = {"speicher": [{"id": s["id"], "name": s["name"]} for s in self.heimspeicher],
                "liste": lambda sid, pfad: heimspeicher.liste(self._dlna_speicher(sid), pfad),
                "url": lambda sid, pfad: "%sdlna/datei/%s?pfad=%s" % (basis, quote(sid, safe=""), quote(pfad, safe="/"))}
        return {"radio": favoriten, "tv": dlna_server.m3u_eintraege(text) if status == 200 else [], "heim": heim}

    def _dlna_speicher(self, sid):
        s = next((x for x in self.heimspeicher if x["id"] == sid), None)
        if s is None:
            raise KeyError(sid)
        return s

    def _dlna_datei(self, sid, abfrage):
        """Datei eines eigenen Speichers durchreichen (Range zum Springen, Zugangsdaten bleiben hier)."""
        try:
            s = self._dlna_speicher(unquote(sid))
        except KeyError:
            return 404, "application/json", {"err": "Speicher unbekannt"}
        pfad = heimspeicher.pfad_sauber((parse_qs(abfrage).get("pfad") or ["/"])[0])
        eigenes = s.get("zertifikat") == "eigenes"
        if s["art"] == "ftp":
            from . import ftp
            return "wiedergabe", (ftp.datei_url(s, pfad), {}, [], eigenes)
        url = heimspeicher.adresse(s, pfad)
        return "wiedergabe", (url, heimspeicher.kopf(s), [urlsplit(url).hostname or ""], eigenes)

    def dlna_bearbeite(self, pfad, methode, koerper, kopf, abfrage=""):
        d = getattr(self, "_dlna", None)
        if not d or not d["ankuendiger"]:
            return 404, "application/json", {"err": "Medienserver aus"}
        xml = "text/xml; charset=utf-8"
        if methode == "GET":
            if pfad.startswith("/dlna/datei/"):
                return self._dlna_datei(pfad[len("/dlna/datei/"):], abfrage)
            if pfad == "/dlna/beschreibung.xml":
                return 200, xml, dlna_server.beschreibung(d["uuid"], d["name"])
            if pfad == "/dlna/cd.xml":
                return 200, xml, dlna_server.CD_SCPD
            if pfad == "/dlna/cm.xml":
                return 200, xml, dlna_server.CM_SCPD
            return 404, "application/json", {"err": "not found"}
        if methode == "SUBSCRIBE":
            return 404, "application/json", {"err": "keine Ereignisse"}
        if methode != "POST" or pfad not in ("/dlna/cd", "/dlna/cm"):
            return 405, "application/json", {"err": "method not allowed"}
        aktion = str((kopf or {}).get("SOAPACTION") or "").strip().strip('"').rsplit("#", 1)[-1]
        roh = koerper.decode("utf-8", "replace")
        if "<!DOCTYPE" in roh or "<!ENTITY" in roh:  # keine Entitaeten aus fremden Paketen
            return 400, xml, dlna_server.soap_fehler(402, "Invalid Args")
        try:
            wurzel = ET.fromstring(roh)
            knoten = next((k for k in wurzel.iter() if k.tag.rsplit("}", 1)[-1] == aktion), None)
            werte = {k.tag.rsplit("}", 1)[-1]: (k.text or "") for k in (knoten if knoten is not None else [])}
        except ET.ParseError:
            return 400, xml, dlna_server.soap_fehler(402, "Invalid Args")
        if pfad == "/dlna/cm":
            if aktion == "GetProtocolInfo":
                return 200, xml, dlna_server.soap_antwort(dlna_server.CM, aktion, [
                    ("Source", "http-get:*:audio/mpeg:*,http-get:*:audio/aac:*,http-get:*:video/mp2t:*,"
                               "http-get:*:application/x-mpegURL:*,http-get:*:video/mp4:*"), ("Sink", "")])
            if aktion == "GetCurrentConnectionIDs":
                return 200, xml, dlna_server.soap_antwort(dlna_server.CM, aktion, [("ConnectionIDs", "0")])
            return 500, xml, dlna_server.soap_fehler(401, "Invalid Action")
        if aktion == "Browse":
            try:
                ergebnis, anzahl, gesamt = dlna_server.browse(werte, self._dlna_quellen(kopf or {}), d["name"])
            except KeyError:
                return 500, xml, dlna_server.soap_fehler(701, "No such object")
            except heimspeicher.SpeicherFehler as fehler:  # Speicher gerade nicht erreichbar
                log.warning("Medienserver: Speicher nicht lesbar: %s", fehler)
                return 500, xml, dlna_server.soap_fehler(720, "Cannot process the request")
            except ValueError:
                return 500, xml, dlna_server.soap_fehler(402, "Invalid Args")
            return 200, xml, dlna_server.soap_antwort(dlna_server.CD, aktion, [
                ("Result", ergebnis), ("NumberReturned", anzahl), ("TotalMatches", gesamt), ("UpdateID", 1)])
        if aktion == "GetSystemUpdateID":
            return 200, xml, dlna_server.soap_antwort(dlna_server.CD, aktion, [("Id", 1)])
        if aktion in ("GetSearchCapabilities", "GetSortCapabilities"):
            return 200, xml, dlna_server.soap_antwort(dlna_server.CD, aktion, [("SearchCaps" if "Search" in aktion else "SortCaps", "")])
        return 500, xml, dlna_server.soap_fehler(401, "Invalid Action")
