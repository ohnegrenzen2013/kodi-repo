"""Stellt die Rezepte als Stremio-Addon bereit (HTTP + JSON)."""

import base64
import hmac
import json
import logging
import os
import re
import threading
import time
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from urllib.parse import unquote, urlsplit

from . import __version__, ipfilter, nutzung as nutzung_modul, ab18 as ab18_bereich, anbindungen, badges as badges_modul, einstellungen as einstellungen_modul, heimspeicher as heimspeicher_modul, telegram as telegram_modul, ed2k_suche as ed2k_suche_modul, ftp as ftp_modul, aktualisierung as aktualisierung_modul, kameras as kameras_modul, waechter as waechter_modul, xdcc as xdcc_modul, youtube as youtube_modul, ed2k as ed2k_modul, debrid as debrid_dienst, entdecken, filtern, links as heimlinks, livetv, markenerkennung_lauf, mcp_server, oberflaeche, p2p_torrent, portal_durch, sprachen, vxparser, xtream
from .netz import Abrufer, NetzFehler, oeffentlich_holen, urllib_holen

log = logging.getLogger("rezeptserver")

CINEMETA = "https://v3-cinemeta.strem.io"
ID_PRAEFIX = "rz:"
KATALOG_ID = "rezepte-suche"
KATALOG_PRAEFIX = "suche-"
_LOGO = re.compile(r"^/logos/([a-z0-9-]{1,40})\.png$")
_DEBRID = re.compile(r"^/debrid/([A-Za-z0-9_\-]{4,4000}\.[A-Za-z0-9_\-]{24})(?:/[^/]{0,200})?$")
_USENET = re.compile(r"^/usenet/([A-Za-z0-9_\-]{4,6000}\.[A-Za-z0-9_\-]{24})(?:/[^/]{0,200})?$")
USENET_MERKEN = 6 * 3600
_LISTE = re.compile(r"^/listen/([a-z0-9-]{1,64})\.m3u8?$")
_PORTAL = re.compile(r"^/portal/([A-Za-z0-9_\-]{24,64})(?:/(.*))?$", re.S)  # ("_• )—*: Durchreicher, siehe portal_durch.py
# Geheimnisse in Abfragen (Sprachbefehl-Schluessel, Xtream-Passwort) nie ins Log
_GEHEIM_IN_ABFRAGE = re.compile(r"((?:^|[?&])(?:schluessel|password|passwort|api_?key|apikey)=)[^&\s]*", re.I)
_GEHEIM_IM_PFAD = re.compile(r"(/live/[^/\s]+/)[^/\s]+(/\d)")  # Xtream: /live/<name>/<passwort>/<id>
_ROUTE = re.compile(r"^/(catalog|meta|stream|subtitles)/([^/]+)/([^/]+?)(?:/([^/]+))?\.json$")


def treffer_zu_id(treffer):
    sauber = {k: v for k, v in treffer.items() if not k.startswith("_")}
    roh = json.dumps(sauber, separators=(",", ":"), ensure_ascii=False).encode("utf-8")
    return ID_PRAEFIX + base64.urlsafe_b64encode(roh).decode("ascii").rstrip("=")


def id_zu_treffer(stremio_id):
    roh = stremio_id[len(ID_PRAEFIX):]
    roh += "=" * (-len(roh) % 4)
    try:
        daten = json.loads(base64.urlsafe_b64decode(roh.encode("ascii")).decode("utf-8"))
    except (ValueError, UnicodeDecodeError):
        return None
    return daten if isinstance(daten, dict) else None


def _groesse(treffer):
    """groesse_mb (Zahl) oder groesse (Bytes als Zahl, sonst Text wie '1.4 GB')."""
    mb = treffer.get("groesse_mb")
    if mb in (None, "") and treffer.get("groesse") not in (None, ""):
        roh = str(treffer["groesse"]).strip()
        if not roh.isdigit():
            return roh
        mb = int(roh) / 1048576.0
    try:
        mb = float(mb)
    except (TypeError, ValueError):
        return ""
    return "%.1f GB" % (mb / 1024) if mb >= 1024 else "%d MB" % mb


def stremio_stream(treffer, stream, usenet_server=None):
    """Stream fuer Stremio. NZB-Streams brauchen Usenet-Server (sonst None), Torrents gehen als infoHash."""
    if stream.get("nzb") and not usenet_server:
        return None
    aufloesung = stream.get("aufloesung") or treffer.get("aufloesung") or ""
    zeilen = [str(treffer.get("titel", ""))]
    audio = sprachen.anzeige(sprachen.audio_von(treffer, stream))
    details = " · ".join(x for x in (_groesse(treffer), "Audio " + audio if audio else "",
                                     treffer.get("quelle")) if x)
    if details:
        zeilen.append(details)
    ergebnis = {
        "name": "\n".join(x for x in (stream.get("_modul", "Rezept"), aufloesung) if x),
        "title": "\n".join(zeilen),
        "description": "\n".join(zeilen),
        "url": stream["url"],
        "behaviorHints": {"notWebReady": True, "bingeGroup": "rezeptserver-%s" % treffer.get("quelle", "")},
    }
    hints = ergebnis["behaviorHints"]
    if stream.get("infohash"):
        del ergebnis["url"]
        ergebnis["infoHash"] = stream["infohash"]
        hints.pop("notWebReady")
    elif stream.get("nzb"):
        del ergebnis["url"]
        ergebnis.update(nzbUrl=stream["url"], servers=list(usenet_server))
    if treffer.get("titel"):
        hints["filename"] = str(treffer["titel"])
    groesse = filtern.groesse_bytes(treffer)
    if groesse:
        hints["videoSize"] = int(groesse)
    if stream.get("header") and "url" in ergebnis:
        hints["proxyHeaders"] = {"request": stream["header"]}
    return ergebnis


class _Zaehler:
    """wfile einer Anfrage: zaehlt gesendete Bytes fuer die Nutzung je Profil (nutzung.py)."""

    def __init__(self, ziel, anfrage):
        self._ziel, self._anfrage = ziel, anfrage

    def write(self, daten):
        self._anfrage.gesendet(len(daten))
        return self._ziel.write(daten)

    def __getattr__(self, name):
        return getattr(self._ziel, name)


# ohne Grenzen erreichbar: die Seite selbst und die Profilwahl (damit man sieht, warum nichts geht, und wechseln kann);
# die Fernsteuerung schickt beim Wischen viele kleine Anfragen, die zaehlen nicht gegen "Anfragen pro Minute"
_FREI = ("/", "/hls.js", "/logo.svg", "/api/profile", "/api/fernsteuerung")


def erstelle_server(app, host="127.0.0.1", port=7000, tls_kontext=None):
    class Handler(BaseHTTPRequestHandler):
        server_version = "Rezeptserver/" + __version__
        _verbunden = False  # erste Anfrage dieser Verbindung zaehlt als neue Verbindung

        def _senden(self, status, typ, koerper):
            if isinstance(koerper, bytes):
                daten = koerper  # z. B. players.zip
            else:
                daten = koerper.encode("utf-8") if isinstance(koerper, str) else \
                    json.dumps(koerper, ensure_ascii=False).encode("utf-8")
            stremio = app.ist_stremio(self.path)
            self.send_response(status)
            self.send_header("Content-Type", typ if isinstance(koerper, bytes) else typ + "; charset=utf-8")
            self.send_header("Content-Length", str(len(daten)))
            if stremio:
                # nur das Addon ist fuer fremde Seiten lesbar; Oberflaeche und /api/ bleiben same-origin
                self.send_header("Access-Control-Allow-Origin", "*")
                self.send_header("Access-Control-Allow-Headers", "*")
            schrift = status == 200 and typ == "font/woff2"  # Schriften der Heim-Styles aendern sich nur mit H0rSt selbst
            kurz = status == 200 and stremio and not app.ist_privat(self.path)  # Stand eines Profils nie zwischenspeichern
            self.send_header("Cache-Control", "max-age=604800" if schrift else "max-age=60" if kurz else "no-store")
            self.end_headers()
            if self.command != "HEAD":
                self.wfile.write(daten)

        def do_OPTIONS(self):
            if app.ist_stremio(self.path):
                self._senden(204, "text/plain", "")
            else:
                self._senden(403, "text/plain", "")

        def _bearbeiten(self, methode, koerper=b"", nutzer=None):
            if ipfilter.eingehend_gesperrt(self.client_address[0]):  # IP-Filter: "auch Zugriffe von aussen pruefen"
                self._senden(403, "application/json", {"err": "blocked"})
                return
            nutzung = getattr(app, "nutzung", None)
            if nutzung is None:
                self._ausfuehren(methode, koerper)
                return
            pid, grenzen = nutzer or app.nutzer_von(self.headers, self.path)
            pfad = app.ohne_token(self.path) or ""
            if grenzen and pfad.split("?", 1)[0] not in _FREI and not pfad.startswith("/schriften/"):
                grund = nutzung.pruefen(pid, grenzen)
                if grund:
                    self._senden(403 if grenzen.get("gesperrt") else 429, "application/json", {"fehler": grund, "err": grund, "grenze": True})
                    return
            neu, self._verbunden = not self._verbunden, True
            ui = self.headers.get("X-Bereich")
            anfrage = nutzung.beginn(pid, nutzung_modul.bereich_von(pfad, ui), self.client_address[0], len(koerper or b""), neu, grenzen,
                                     (self.headers.get("X-Besuch") == "1") if ui else None)
            wfile, self.wfile = self.wfile, _Zaehler(self.wfile, anfrage)
            try:
                self._ausfuehren(methode, koerper)
            except (BrokenPipeError, ConnectionResetError):
                self.close_connection = True
            finally:
                self.wfile = wfile
                nutzung.ende(anfrage)

        def _ausfuehren(self, methode, koerper):
            try:
                ergebnis = app.bearbeite(self.path, methode, koerper, self.headers)
                if ergebnis[0] == "wiedergabe":
                    oberflaeche.weiterreichen(self, ergebnis[1])
                    return
                if ergebnis[0] == "datei":
                    livetv.senden(self, ergebnis[1], ergebnis[2])
                    return
                if ergebnis[0] == "kamera":  # MJPEG-Strom einer IP-Kamera, Zugangsdaten bleiben hier
                    oberflaeche.kamera_senden(self, ergebnis[1])
                    return
                if ergebnis[0] == "portal":  # ("_• )—*: durchgereichte Seite (Kopfzeilen, Cookies bleiben hier)
                    portal_durch.senden(self, ergebnis[1])
                    return
                if ergebnis[0] == "lokal":  # geladene Datei (XDCC) mit Range, damit Player springen koennen
                    oberflaeche.datei_senden(self, ergebnis[1])
                    return
                if ergebnis[0] == "logo":
                    livetv.logo_senden(self, ergebnis[1])
                    return
                if ergebnis[0] == "weiter":  # Xtream /live/...: auf die Stream-Adresse weiterleiten
                    self.send_response(302)
                    self.send_header("Location", ergebnis[1])
                    self.send_header("Content-Length", "0")
                    self.send_header("Cache-Control", "no-store")
                    self.end_headers()
                    return
                status, typ, inhalt = ergebnis
            except (BrokenPipeError, ConnectionResetError):  # Gegenseite weg oder Traffic-Grenze erreicht
                self.close_connection = True
                return
            except Exception:
                log.exception("Fehler bei %s %s", methode, app.ohne_token(self.path) or "?")
                status, typ, inhalt = 500, "application/json", {"err": "internal"}
            self._senden(status, typ, inhalt)

        def do_GET(self):
            self._bearbeiten("GET")

        def do_HEAD(self):
            # /debrid/, /usenet/ und Dateien des Medienservers: Player und Fernseher fragen vorab
            pfad = app.ohne_token(self.path) or ""
            if _DEBRID.match(pfad) or _USENET.match(pfad) or pfad.startswith("/dlna/datei/"):
                self._bearbeiten("GET")
            else:
                self.send_error(405)

        def do_POST(self):
            try:
                laenge = int(self.headers.get("Content-Length") or 0)
            except ValueError:
                laenge = -1
            if laenge < 0:  # sonst liest rfile.read(-1) bis der Absender die Verbindung schliesst
                self._senden(400, "application/json", {"err": "bad content-length"})
                return
            grenze = oberflaeche.MAX_NZB_KOERPER if self.path.split("?")[0].endswith(("/api/startanimation", "/api/rustnzb/nzb", "/api/dienste/hinzu", "/api/kodi/import",
                                                                                     "/api/sicherung/einspielen", "/api/hintergrund", "/api/avatar",
                                                                                     "/api/ed2k/hochladen", "/api/ipfilter/hochladen", "/api/kodiaddons/installieren",
                                                                                     "/api/traum/erzeugen", "/api/qwen-pose")) \
                else oberflaeche.MAX_KOERPER
            nutzer = app.nutzer_von(self.headers, self.path) if getattr(app, "nutzung", None) is not None else ("", None)
            if grenze == oberflaeche.MAX_NZB_KOERPER and nutzer[1] and nutzer[1].get("upload_mb"):
                grenze = min(grenze, nutzer[1]["upload_mb"] * 1024 * 1024)  # Upload-Grenze des Profils
            if laenge > grenze:
                # Den Rest abnehmen (bis 16 MB), sonst bricht der Absender mit "Broken pipe" ab und sieht die Meldung nie
                rest = laenge if laenge <= 16 << 20 else 0
                while rest > 0:
                    stueck = self.rfile.read(min(rest, 65536))
                    if not stueck:
                        break
                    rest -= len(stueck)
                self._senden(413, "application/json", {"err": "too large", "fehler": "Zu groß: höchstens %d MB – die Grenze stellt der Admin ein (Admin-Panel)." % max(1, grenze >> 20)})
                return
            self._bearbeiten("POST", self.rfile.read(laenge), nutzer)

        def log_message(self, format, *args):
            # Token nie ins Log schreiben
            nachricht = format % args
            if app.token:
                nachricht = nachricht.replace(app.token, "<token>")
            nachricht = _GEHEIM_IM_PFAD.sub(r"\1<geheim>\2", _GEHEIM_IN_ABFRAGE.sub(r"\1<geheim>", nachricht))
            log.debug("%s %s", self.address_string(), nachricht)

    if tls_kontext is not None:
        class TlsServer(ThreadingHTTPServer):
            def get_request(self):
                verbindung, adresse = self.socket.accept()
                verbindung.settimeout(30)
                # Handshake erst im Faden der Verbindung (beim ersten Lesen), nie im Annahme-Faden
                return tls_kontext.wrap_socket(verbindung, server_side=True, do_handshake_on_connect=False), adresse
        server = TlsServer((host, port), Handler)
    else:
        server = ThreadingHTTPServer((host, port), Handler)
    server.daemon_threads = True
    return server
