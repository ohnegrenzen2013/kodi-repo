"""Nebenaufgaben des Stremio-Kerns: XDCC-Marken, Profilgrenzen, Hintergrund und Feed-Abruf."""

import os

from .stremio_grund import Abrufer, log, markenerkennung_lauf, oeffentlich_holen


class AufgabenMixin:
    def _xdcc_fertig(self, auftrag):
        """Automatische Markenerkennung nach einem fertigen XDCC-Download: nur wenn eingeschaltet und der
        Dateiname Staffel/Folge erkennen laesst (markenerkennung_lauf.serie_aus_namen() gegen Cinemeta) -
        sonst stillschweigend nichts (kein Fehler, keine Rueckfrage)."""
        if not self.markenerkennung.erlaubt():
            return
        ref = markenerkennung_lauf.serie_aus_namen(auftrag.name, self.entdecken)
        if not ref:
            return
        try:
            self.markenerkennung.starten(ref, self.xdcc.pfad(auftrag.name))
        except Exception as fehler:
            log.warning("Markenerkennung nach XDCC-Download %s: %s", auftrag.name, fehler)



    def nutzer_von(self, kopf, pfad):
        """(Profil-ID, Grenzen) einer Anfrage aus X-Profil oder ?sitzung=; Admins und ohne Profile: keine Grenzen."""
        from . import nutzung as nutzung_modul, profile as profile_modul
        daten = self.oberflaeche._profile_daten()
        if not profile_modul.aktiv(daten):
            return "", None
        token = (kopf.get("X-Profil") if kopf else "") or ""
        if not token and "sitzung=" in pfad:
            from urllib.parse import parse_qs
            token = (parse_qs(pfad.split("?", 1)[-1]).get("sitzung") or [""])[0]
        x = profile_modul.profil_zu(daten, token)
        if not x:
            return "", None
        return x["id"], None if x.get("rolle") == "admin" else nutzung_modul.pruefe_grenzen(x.get("grenzen"))

    def _hintergrundaufgaben(self):
        """Wird von der Aktualisierungsschleife bei jedem Durchlauf aufgerufen: jede Aufgabe eigenstaendig
        fehlerisoliert, ein Fehler in einer darf die andere nicht verhindern."""
        try:
            self._gdrive_spiegeln()
        except Exception as fehler:
            log.warning("Hintergrundaufgabe (Google Drive spiegeln): %s", fehler)
        try:
            self._komplettbackup_tun()
        except Exception as fehler:
            log.warning("Hintergrundaufgabe (Komplett-Backup): %s", fehler)
        try:
            self._geraete_abgleich_tun()
        except Exception as fehler:
            log.warning("Hintergrundaufgabe (Geraete-Abgleich): %s", fehler)
        try:
            self._appstore_hintergrund_tun()
        except Exception as fehler:
            log.warning("Hintergrundaufgabe (App-Store Updates): %s", fehler)

    def _gdrive_spiegeln(self):
        """Taeglich: die gewaehlten Orte des Dateibrowsers nach Google Drive spiegeln (nur Neues und Geaendertes)."""
        if self.gdrive.spiegeln_faellig():
            gewaehlt = set(self.gdrive.stand(self.verwaltung.daten() if self.verwaltung else {})["spiegeln"])
            orte = [(o["id"], o["name"], o["pfad"]) for o in self.dateien.orte() if o["id"] in gewaehlt and o["da"]]
            if orte:
                self.gdrive.im_hintergrund("spiegeln", lambda: self.gdrive.spiegeln(orte))

    def _komplettbackup_tun(self):
        """Nach dem gewaehlten Intervall: das Komplett-Backup im Hintergrund starten."""
        if self.komplettbackup.faellig():
            self.komplettbackup.jetzt_starten()

    def _geraete_abgleich_tun(self):
        """Nach dem gewaehlten Intervall: den Geraete-Abgleich im Hintergrund starten."""
        if self.geraete_abgleich.faellig():
            self.geraete_abgleich.jetzt_starten()

    def _appstore_hintergrund_tun(self):
        """Fest alle paar Stunden: Updates fuer den zuletzt gemeldeten Installations-Schnappschuss und
        beobachtete Projekte pruefen (Muster komplettbackup_lauf.py::faellig()) - nur wenn der App-Store
        eingeschaltet ist."""
        from . import appstore as appstore_modul
        if appstore_modul.eingeschaltet(self.verwaltung.daten() if self.verwaltung else {}) and self.appstore.hintergrund_faellig():
            self.appstore.hintergrund_pruefen()

    def _datei_orte(self):
        """Feste Orte des Dateibrowsers: Downloads von H0rSt, FTP-Ordner, Embers Download-Ordner."""
        orte = [("xdcc", "XDCC-Downloads", self.xdcc.ordner), ("youtube", "YouTube-Downloads", self.youtube_speichern.ordner)]
        ftp_ordner = (getattr(self.ftp_server, "einstellung", None) or {}).get("ordner")
        if ftp_ordner:
            orte.append(("ftp", "FTP-Ordner", ftp_ordner))
        try:  # NZBGet in der App: fertige Downloads (DestDir = <Ablage>/dst) gleich im Dateibrowser, zum Abspielen und Senden
            nzb = ((self.verwaltung.daten() if getattr(self, "verwaltung", None) else {}).get("einstellungen") or {}).get("nzbget-app") or {}
            if nzb.get("ablage") and os.path.isabs(str(nzb["ablage"])):
                orte.append(("nzbget", "NZBGet (fertig)", os.path.join(str(nzb["ablage"]), "dst")))
        except Exception:  # Beiwerk
            pass
        try:
            from . import ember_steuerung
            daten = self.verwaltung.daten() if getattr(self, "verwaltung", None) else {}
            ordner = ember_steuerung.EmberSteuerung(ember_steuerung.pruefe(daten.get(ember_steuerung.SCHLUESSEL))).konfig().get("download_folder")
            if ordner:
                orte.append(("ember", "Ember-Downloads", ordner))
        except Exception:  # Ember ist Beiwerk
            pass
        return orte


class _FeedAbrufer:
    """Abrufer fuer die Kataloge: jede Adresse darf zu ihrem eigenen Host (Feeds traegt der Nutzer selbst ein).
    Private/interne Adressen sind gesperrt, ausser ein Feed hat ausdruecklich "heimnetz_erlaubt" gesetzt
    (mdblist.com/trakt.tv/xrel.to u.ae. sind feste, oeffentliche Hosts - die Sperre stoert dort nicht)."""

    def __init__(self, holen):
        self.holen = holen

    def abruf(self, url, kopf=None, heimnetz_erlaubt=False):
        from urllib.parse import urlsplit
        host = urlsplit(url).hostname or ""
        geholt = self.holen if heimnetz_erlaubt else oeffentlich_holen(self.holen)
        return Abrufer([".".join(host.split(".")[-2:])], holen=geholt, zeitgrenze=15.0).abruf(url, header=kopf)  # samt Weiterleitung in derselben Domain
