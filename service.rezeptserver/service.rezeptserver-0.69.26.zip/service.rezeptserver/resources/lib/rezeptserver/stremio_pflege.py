"""PflegeMixin-Mixin
"""

from . import usenet_stream
from .stremio_grund import (
    ab18_bereich,
    aktualisierung_modul,
    einstellungen_modul,
    filtern,
    ftp_modul,
    heimlinks,
    heimspeicher_modul,
    kameras_modul,
    livetv,
    log,
    os,
    telegram_modul,
    threading,
    youtube_modul,
)


class PflegeMixin:

    # --- Anbieter neu laden ---------------------------------------------
    def uebernehmen(self, kette, anbieter_namen, addons, usenet_server, debrid=None, rustnzb=None, dienste=None):
        """Neue Kette nach geaenderten Anbietern, ohne Neustart. Die alte schliesst etwas spaeter,
        damit laufende Anfragen fertig werden."""
        alt = (self.kette, self.addons)
        self.kette, self.anbieter_namen, self.addons = kette, anbieter_namen, addons
        for quelle in (kette, addons):  # Rangliste der Module und Addons zaehlt weiter
            if quelle is not None and hasattr(quelle, "zaehler") and getattr(self, "nutzung", None) is not None:
                quelle.zaehler = self.nutzung.zaehler
        self.usenet_server = list(usenet_server or [])
        if debrid is not None:
            self.debrid = self.debrid.uebernehmen(debrid)
        self.rustnzb = rustnzb
        self.dienste = dict(dienste or {})
        from . import anbieter
        self._adult = any(anbieter.kategorie_von(m) == anbieter.AB18 for m in getattr(kette, "module", []))
        zeit = threading.Timer(120, self._schliessen, alt)
        zeit.daemon = True
        zeit.start()

    @staticmethod
    def _schliessen(kette, addons):
        kette.schliessen()
        if addons:
            addons.schliessen()

    def schliessen(self):
        self.medienserver_setzen(False)
        self.waechter.stoppen()
        self.beobachtungen.stoppen()
        self.telegram.stoppen()
        self.ftp_server.stoppen()
        self.aktualisierung.stoppen()
        self.snaps.stoppen()
        self._schliessen(self.kette, self.addons)
        self.entdecken.schliessen()

    def nutzerdaten_neu(self):
        """Nach dem Einspielen einer Sicherung: alle Einstellungen aus den Nutzerdaten uebernehmen, ohne Neustart.
        Gibt das (evtl. neue) Token zurueck."""
        from . import badges as badges_mod, sprachen as sprachen_mod
        daten = self.verwaltung.daten()
        self.filter = filtern.pruefe(daten.get("filter"))
        self.links = heimlinks.pruefe(daten.get("links"))
        wunsch = daten.get("sprachen") or {}
        self.audio_wunsch = sprachen_mod.als_liste(wunsch.get("audio"))
        self.untertitel_wunsch = sprachen_mod.als_liste(wunsch.get("untertitel"))
        self.ui = einstellungen_modul.pruefe(daten.get(einstellungen_modul.SCHLUESSEL))
        try:
            self.kameras = kameras_modul.pruefe(daten.get(kameras_modul.SCHLUESSEL))
        except kameras_modul.KameraFehler:
            self.kameras = []
        try:
            self.heimspeicher = heimspeicher_modul.pruefe(daten.get(heimspeicher_modul.SCHLUESSEL))
        except heimspeicher_modul.SpeicherFehler:
            self.heimspeicher = []
        self.youtube.einstellung = youtube_modul.pruefe(daten.get(youtube_modul.SCHLUESSEL))
        try:
            self.ab18.einstellungen = ab18_bereich.pruefe(daten.get(ab18_bereich.SCHLUESSEL))
        except ab18_bereich.Ab18Fehler:
            pass
        self.ab18.freigegeben = daten.get("ab18") is True
        try:
            self.badges.setzen(badges_mod.pruefe(daten.get(badges_mod.SCHLUESSEL) or {}), laden=False)
        except badges_mod.BadgeFehler:
            pass
        alt = self.telegram
        alt.stoppen()
        try:
            self.telegram = telegram_modul.Telegram(daten.get(telegram_modul.SCHLUESSEL), alt._speichern)
        except telegram_modul.TelegramFehler:
            self.telegram = telegram_modul.Telegram({}, alt._speichern)
        self.telegram.kontext = self
        self.telegram.starten()
        self.ftp_server.stoppen()
        self.ftp_server.einstellung = self.ftp_server._sicher(daten.get(ftp_modul.SERVER_SCHLUESSEL) or {})
        self.ftp_server.starten()
        try:
            self.aktualisierung.einstellung = aktualisierung_modul.pruefe(daten.get(aktualisierung_modul.SCHLUESSEL))
        except aktualisierung_modul.UpdateFehler:
            pass
        try:
            self.setze_livetv(daten.get("livetv"))
        except Exception as fehler:
            log.warning("Live-TV aus der Sicherung: %s", fehler)
        if self.token and daten.get("token") and daten["token"] != self.token:
            self.token = daten["token"]  # Adressen von Stremio & Co. aus der Sicherung gelten wieder
        self.verwaltung.speichern(daten)  # Anbieter, Netzweg, Debrid, Dienste neu laden
        return self.token

    def setze_links(self, neu):
        neu = heimlinks.pruefe(neu)
        if self.links_speichern:
            self.links_speichern(neu)
        self.links = neu
        return neu

    def setze_livetv(self, neu):
        """Neue Live-TV-Einstellung uebernehmen und speichern; bei neuer EPG-Quelle neu laden."""
        neu = livetv.pruefe(neu)
        if self.livetv_speichern:
            self.livetv_speichern(neu)
        alt = {(l["name"], l["url"]) for l in self.livetv["listen"]}
        frei_vorher = self.livetv.get("frei") or []
        self.livetv = dict(self.livetv, listen=neu["listen"], frei=neu["frei"])
        self._listen_aufbauen(alt)
        if (neu["epg_quelle"], neu["epg_grabber"], neu["frei"]) != (self.livetv["epg_quelle"], self.livetv["epg_grabber"],
                                                                    frei_vorher):
            self.epg = livetv.epg_abholer(self.datenordner, neu, holen=self._epg_holen,
                                          grabber_sitzung=self._epg_sitzung, playlist_epg=self._playlist_epg)
            try:
                os.remove(self.epg.pfad)  # alte Quelle verwerfen
            except OSError:
                pass
            self.epg.bei_bedarf_erneuern()
        if neu["adressen_quelle"] != self.livetv["adressen_quelle"]:
            self.adressen = livetv.Adressen(self.datenordner, neu["adressen_quelle"], holen=self._epg_holen)
            try:
                os.remove(self.adressen.pfad)  # alte Liste verwerfen
            except OSError:
                pass
            self.adressen.bei_bedarf_erneuern()
        self.livetv = neu
        return neu

    def eigene_basis(self, kopf):
        """Adresse dieses Servers aus Sicht des Aufrufers ("http://host:port/[token/]"), None ohne Host."""
        host = (kopf.get("Host") or "").strip()
        if not host or any(z in host for z in ' "/\\<>'):
            return None
        pfad = self.token + "/" if self.token else ""
        ui = getattr(self, "ui", None) or {}
        fest = usenet_stream.basis_adresse(ui.get("usenet_basis_url")) if ui.get("usenet_modus_an") else ""
        if fest:  # eigene HTTPS-Adresse (Einstellungen -> Usenet-Streaming), z. B. hinter Caddy mit DuckDNS
            return fest + pfad
        # hinter einem HTTPS-Proxy (Caddy, nginx) steht im Kopf, dass aussen https gesprochen wird
        https = (kopf.get("X-Forwarded-Proto") or "").split(",")[0].strip().lower() == "https"
        return "%s://%s/%s" % ("https" if https else "http", host, pfad)

    def _playlist_epg(self):
        """EPG-Adressen aus den Kopfzeilen der eigenen Playlists (url-tvg); gilt nur ohne eigene EPG-Quelle."""
        return [u for liste in list(self.listen.values()) for u in getattr(liste, "epg_adressen", list)()]

    def _listen_aufbauen(self, alt=None):
        """Eigene Listen aus den Einstellungen; neue oder geaenderte werden (neu) geladen."""
        ordner = os.path.join(self.datenordner, livetv.LISTEN_ORDNER)
        neu = {}
        for eintrag in self.livetv["listen"]:
            if not eintrag["an"]:
                continue
            lid = livetv.liste_id(eintrag["name"])
            vorher = self.listen.get(lid)
            if vorher and vorher.quelle == eintrag["url"]:
                neu[lid] = vorher
                continue
            liste = livetv.Liste(self.datenordner, lid, eintrag["name"], eintrag["url"], holen=self._epg_holen)
            if alt is not None:  # Einstellung geaendert: alte Fassung verwerfen
                try:
                    os.remove(liste.pfad)
                except OSError:
                    pass
            neu[lid] = liste
        for frei in self.livetv.get("frei") or []:  # kostenlose Sender (Samsung TV Plus, Pluto TV)
            lid = "frei-" + frei
            neu[lid] = self.listen.get(lid) or livetv.FreiListe(self.datenordner, frei, holen=self._epg_holen)
        # Zwischenspeicher entfernter Listen aufraeumen
        if alt is not None and os.path.isdir(ordner):
            for datei in os.listdir(ordner):
                if datei.endswith((".m3u", ".json")) and datei.rsplit(".", 1)[0] not in neu:
                    try:
                        os.remove(os.path.join(ordner, datei))
                    except OSError:
                        pass
        self.listen = neu
        for liste in neu.values():
            liste.bei_bedarf_erneuern()

    def epg_adresse(self, kopf):
        """Absolute Adresse der EPG fuer url-tvg in der M3U (Host aus der Anfrage, Token im Pfad)."""
        basis = self.eigene_basis(kopf)
        if not (self.epg.quelle or self.epg.zusatz) or not basis:
            return None
        return basis + "epg.xml.gz"
