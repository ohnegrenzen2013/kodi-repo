"""Release-Infos aus oeffentlichen, dokumentierten Schnittstellen: xREL (api.xrel.to/v2) und predb.net (api.predb.net).

Beides ist ab Werk AUS (Nutzerdaten "szene": {"xrel": false, "predb": false}) und wird nur auf Anfrage abgefragt - es gibt
kein Hintergrund-Abfragen, kein Spiegeln und keinen Aufbau einer eigenen Datenbank (das verbieten beide Dienste ausdruecklich
bzw. bitten darum). H0rSt zeigt nur Namen, Gruppe, Zeit, Groesse und die Adresse der Seite beim Dienst.

  xREL    GET https://api.xrel.to/v2/search/releases.json?q=…&scene=true&p2p=false&limit=…   (ohne Anmeldung)
          Regeln: 900 Aufrufe/Stunde je IP, Suchaufrufe zusaetzlich 2 je 5 s (https://www.xrel.to/wiki/2727/api-rate-limiting.html).
          Die NFO-Abbildung (nfo/release) braucht OAuth mit dem Scope "viewnfo", den xREL nur auf Antrag vergibt - NICHT eingebaut;
          stattdessen die Adresse der Release-Seite bei xREL.
  predb   GET https://api.predb.net/?q=…&limit=…&tag=german   (JSON, ohne Anmeldung)
          Regeln: 30 Aufrufe je 60 s, "Treat this API respectfully", nicht zum Aufbau einer eigenen DB verwenden
          (https://predb.net/api-documentation/). type=nfo liefert die NFO-Adresse; H0rSt reicht nur die Adresse weiter.
Eigene Bremse: xREL hoechstens 1 Suche je 3 s und 400/Stunde, predb hoechstens 20 je 60 s; Antworten 10 Minuten im Speicher.
Inhalte fuer Erwachsene (predb-Sektion XXX*, ".XXX." im Namen) werden verworfen und nie angezeigt.
Es gibt keine Schluessel und keine Zugangsdaten; nichts davon kommt in ein Protokoll.
"""

import json
import re
import threading
import time
from collections import deque
from urllib.parse import quote, urlencode

from . import deutsch_wertung

SCHLUESSEL = "szene"
XREL = "https://api.xrel.to/v2/search/releases.json?"
PREDB = "https://api.predb.net/?"
OFDB_SUCHE = "https://www.ofdb.de/suchergebnis/?term="
CACHE_SEK, MAX_CACHE, MAX_TREFFER = 600, 100, 25
_ID = re.compile(r"^tt\d{1,10}$")
_NAME = re.compile(r"^[\w.()+&'!-]{3,200}$")


class SzeneFehler(ValueError):
    pass


def einstellung(daten):
    e = (daten or {}).get(SCHLUESSEL)
    e = e if isinstance(e, dict) else {}
    return {"xrel": e.get("xrel") is True, "predb": e.get("predb") is True}


def einstellung_aendern(daten, wunsch):
    neu = einstellung(daten)
    for k in ("xrel", "predb"):
        if k in wunsch:
            if not isinstance(wunsch[k], bool):
                raise SzeneFehler("%s: true oder false angeben" % k)
            neu[k] = wunsch[k]
    daten[SCHLUESSEL] = neu
    return neu


def ofdb_link(imdb_id="", titel=""):
    """Adresse der OFDb-Suche (IMDb-Nummer wird dort unterstuetzt). Kein Abruf durch H0rSt, nur ein Link."""
    if _ID.match(str(imdb_id or "")):
        return OFDB_SUCHE + imdb_id
    t = " ".join(str(titel or "").split())[:100]
    return OFDB_SUCHE + quote(t) if t else ""


def suchtext(titel, jahr="", folge=""):
    """'Big Buck Bunny', 2008 -> 'Big.Buck.Bunny.2008' (predb sucht ab dem Anfang des Release-Namens)."""
    wort = re.sub(r"[^\w]+", ".", " ".join(str(titel or "").split()), flags=re.U).strip(".")
    teile = [wort] if wort else []
    j = str(jahr or "").strip()
    if re.fullmatch(r"(19|20)\d\d", j):
        teile.append(j)
    f = str(folge or "").strip().upper()
    if re.fullmatch(r"S\d{1,2}(E\d{1,3})?", f):
        teile.append(f)
    return ".".join(teile)[:120]


def _zahl(wert):
    try:
        return int(float(wert))
    except (TypeError, ValueError):
        return 0


def _text(wert, grenze=200):
    return " ".join(str(wert or "").split())[:grenze]


def _erwachsen(name, sektion=""):
    return str(sektion or "").upper().startswith("XXX") or bool(re.search(r"(?i)(^|[._-])xxx([._-]|$)", str(name or "")))


def _mit_wertung(t):
    w = deutsch_wertung.wertung(t["name"])
    t["deutsch"] = w["labels"] and w["labels"][0] if w["labels"] and w["labels"][0].startswith("German") else ""
    t["kino"] = w["minderwertig"]
    return t


def xrel_lesen(text):
    """Antwort von search/releases.json -> Liste einheitlicher Treffer."""
    try:
        d = json.loads(text)
    except (ValueError, TypeError):
        raise SzeneFehler("Antwort von xREL ist kein JSON")
    if not isinstance(d, dict):
        raise SzeneFehler("Antwort von xREL unverstaendlich")
    if d.get("error"):
        raise SzeneFehler("xREL: %s" % _text(d.get("error_description") or d.get("error"), 80))
    roh = list(d.get("results") or []) + list(d.get("p2p_results") or [])
    liste = []
    for r in roh:
        if not isinstance(r, dict):
            continue
        name = _text(r.get("dirname") or r.get("title"))
        if not name or _erwachsen(name):
            continue
        groesse = r.get("size") if isinstance(r.get("size"), dict) else {}
        mb = _zahl(groesse.get("number")) * (1024 if str(groesse.get("unit") or "").upper().startswith("G") else 1)
        link = str(r.get("link_href") or "")
        flags = r.get("flags") if isinstance(r.get("flags"), dict) else {}
        liste.append(_mit_wertung({"quelle": "xrel", "name": name, "gruppe": _text(r.get("group_name"), 40), "zeit": _zahl(r.get("time")),
                                   "mb": mb, "sektion": _text((r.get("ext_info") or {}).get("type") if isinstance(r.get("ext_info"), dict) else "", 20),
                                   "video": _text(r.get("video_type"), 40), "audio": _text(r.get("audio_type"), 40),
                                   "url": link if link.startswith("https://www.xrel.to/") else "",
                                   "status": "nuked" if flags.get("nuked") or flags.get("fake") else ""}))
        if len(liste) >= MAX_TREFFER:
            break
    return liste


def predb_lesen(text):
    """Antwort von api.predb.net -> Liste einheitlicher Treffer (Erwachsenen-Sektionen entfernt)."""
    try:
        d = json.loads(text)
    except (ValueError, TypeError):
        raise SzeneFehler("Antwort von predb.net ist kein JSON")
    if not isinstance(d, dict):
        raise SzeneFehler("Antwort von predb.net unverstaendlich")
    if str(d.get("status") or "success").lower() not in ("success", "ok"):
        raise SzeneFehler("predb.net: %s" % _text(d.get("message"), 80))
    roh = d.get("data")
    roh = roh if isinstance(roh, list) else d.get("results") if isinstance(d.get("results"), list) else []
    liste = []
    for r in roh:
        if not isinstance(r, dict):
            continue
        name = _text(r.get("release") or r.get("name"))
        sektion = _text(r.get("section"), 30)
        if not name or _erwachsen(name, sektion):
            continue
        status = _text(r.get("status"), 12).lower()
        liste.append(_mit_wertung({"quelle": "predb", "name": name, "gruppe": _text(r.get("group"), 40),
                                   "zeit": _zahl(r.get("pretime") or r.get("added")), "mb": _zahl(r.get("size")),
                                   "sektion": sektion, "video": "", "audio": "", "genre": _text(r.get("genre"), 30),
                                   "url": "https://predb.net/?" + urlencode({"q": name}), "status": "nuked" if status == "nuked" else ""}))
        if len(liste) >= MAX_TREFFER:
            break
    return liste


class Bremse:
    """Mindestabstand und Obergrenzen je Fenster; arbeitet mit einer austauschbaren Uhr (Tests)."""

    def __init__(self, abstand, fenster, anzahl, uhr=time.time):
        self.abstand, self.fenster, self.anzahl, self.uhr = abstand, fenster, anzahl, uhr
        self._zeiten, self._sperre = deque(), threading.Lock()

    def nehmen(self):
        """True, wenn ein Aufruf jetzt erlaubt ist (und gezaehlt wird)."""
        with self._sperre:
            jetzt = self.uhr()
            while self._zeiten and jetzt - self._zeiten[0] > self.fenster:
                self._zeiten.popleft()
            if self._zeiten and jetzt - self._zeiten[-1] < self.abstand:
                return False
            if len(self._zeiten) >= self.anzahl:
                return False
            self._zeiten.append(jetzt)
            return True


class Szene:
    def __init__(self, holen=None, uhr=time.time):
        self._holen, self.uhr = holen, uhr
        self._cache, self._sperre = {}, threading.Lock()
        self.bremsen = {"xrel": [Bremse(3, 5, 2, uhr), Bremse(0, 3600, 400, uhr)], "predb": [Bremse(0, 60, 20, uhr)]}

    def _abruf(self, url, host):
        from .netz import Abrufer, NetzFehler, oeffentlich_holen, urllib_holen
        try:
            return Abrufer([host], holen=self._holen or oeffentlich_holen(urllib_holen), zeitgrenze=12.0).abruf(url)
        except NetzFehler as fehler:
            raise SzeneFehler("Nicht erreichbar: %s" % _text(str(fehler).split(" bei ")[0], 60))

    def _erlaubt(self, quelle):
        return all(b.nehmen() for b in self.bremsen[quelle])

    def _gecacht(self, schluessel, erzeuge):
        with self._sperre:
            e = self._cache.get(schluessel)
            if e and self.uhr() - e[0] < CACHE_SEK:
                return e[1]
        wert = erzeuge()
        with self._sperre:
            while len(self._cache) >= MAX_CACHE:
                self._cache.pop(next(iter(self._cache)))
            self._cache[schluessel] = (self.uhr(), wert)
        return wert

    def xrel_suche(self, text, anzahl=15):
        q = _text(text, 120)
        if len(q) < 3:
            raise SzeneFehler("Suchbegriff zu kurz")

        def holen():
            if not self._erlaubt("xrel"):
                raise SzeneFehler("xREL: Bremse – bitte einen Moment warten (2 Suchen je 5 s, 900 Aufrufe je Stunde)")
            url = XREL + urlencode({"q": q, "scene": "true", "p2p": "false", "limit": max(1, min(int(anzahl), 25))})
            return xrel_lesen(self._abruf(url, "api.xrel.to"))
        return self._gecacht(("xrel", q.lower(), anzahl), holen)

    def predb_suche(self, text, deutsch=False, anzahl=20):
        q = _text(text, 120)
        if len(q) < 3:
            raise SzeneFehler("Suchbegriff zu kurz")

        def holen():
            if not self._erlaubt("predb"):
                raise SzeneFehler("predb.net: Bremse – bitte einen Moment warten (30 Aufrufe je 60 s)")
            p = {"q": q, "limit": max(1, min(int(anzahl), 50))}
            if deutsch:
                p["tag"] = "german"
            return predb_lesen(self._abruf(PREDB + urlencode(p), "api.predb.net"))
        return self._gecacht(("predb", q.lower(), bool(deutsch), anzahl), holen)

    def predb_nfo(self, release):
        """type=nfo: Adressen der NFO beim Dienst (H0rSt laedt die Datei nicht selbst, es gibt nur die Verweise)."""
        name = str(release or "").strip()
        if not _NAME.match(name):
            raise SzeneFehler("Release-Name ungueltig")

        def holen():
            if not self._erlaubt("predb"):
                raise SzeneFehler("predb.net: Bremse – bitte einen Moment warten")
            try:
                d = json.loads(self._abruf(PREDB + urlencode({"type": "nfo", "release": name}), "api.predb.net"))
            except ValueError:
                raise SzeneFehler("Antwort von predb.net ist kein JSON")
            roh = d.get("data") if isinstance(d, dict) else None
            roh = roh[0] if isinstance(roh, list) and roh else roh if isinstance(roh, dict) else {}
            aus = {}
            for schluessel, feld in (("nfo", "nfo"), ("bild", "nfo_image")):
                for k in (feld, schluessel, "nfo_url" if schluessel == "nfo" else "image"):
                    v = str(roh.get(k) or "") if isinstance(roh, dict) else ""
                    if v.startswith("https://") and "predb.net" in v.split("/")[2]:
                        aus[schluessel] = v
                        break
            return aus
        return self._gecacht(("nfo", name.lower()), holen)

    def releases(self, einst, titel, jahr="", folge="", deutsch=False):
        """Beide Quellen, soweit eingeschaltet. -> {"treffer": [...], "fehler": {quelle: text}, "aktiv": {...}}"""
        text = suchtext(titel, jahr, folge)
        aus, fehler = [], {}
        for quelle in ("xrel", "predb"):
            if not einst.get(quelle):
                continue
            try:
                liste = self.xrel_suche(text.replace(".", " ")) if quelle == "xrel" else self.predb_suche(text, deutsch)
                aus.extend(liste)
            except SzeneFehler as f:
                fehler[quelle] = str(f)
        if deutsch:
            aus = [t for t in aus if t["deutsch"]]
        aus.sort(key=lambda t: (-t["zeit"], t["name"]))
        return {"treffer": aus[:MAX_TREFFER * 2], "fehler": fehler, "aktiv": dict(einst), "suche": text}
