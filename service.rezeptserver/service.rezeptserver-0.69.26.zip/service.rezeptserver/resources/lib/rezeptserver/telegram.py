"""Telegram als Kommunikationsmodul: H0rSt meldet sich per Bot und nimmt Befehle an.

  * Meldungen: Ausfaelle und Erholung aus dem Waechter, fertige und fehlgeschlagene Downloads (XDCC, YouTube).
    Die Module melden ueber ereignisse.py, der Bot hoert mit und schickt in einer eigenen Warteschlange
    (ein langsames Telegram haelt keinen Download auf).
  * Befehle aus gekoppelten Chats: /status, /downloads, /suche, /links, /dht, /stumm, /laut, /hilfe.
    ed2k-Links in einer Nachricht landen in der Ember-Sammlung, zu Magnet-Links zaehlt H0rSt die Quellen im DHT
    und gibt sie auf Wunsch (/torrent) an den ersten Torrent-Client.
  * Kopplung: Bot bei @BotFather anlegen, Token in H0rSt eintragen, "Koppeln" zeigt einen Code und einen Link
    (t.me/<bot>?start=<code>). Wer den Code innerhalb von 10 Minuten schickt, wird eingetragen. Andere Chats
    bekommen keine Antwort.
  * Es laeuft ueber die Bot-API (api.telegram.org, Long Polling), ohne offenen Port und ohne Zusatzpakete. Der
    Netzweg aus "Sicherheit" gilt auch hier.

Nutzerdaten "telegram": {"an", "token", "chats": [{"id", "name"}], "melden": ["waechter", "download"],
                         "nur_stoerungen", "befehle"}
"""

from .telegram_grund import *
from .telegram_grund import _MAGNET, _TOKEN, _holen
from .telegram_kern import KernMixin as _KernMixin
from .telegram_api import ApiMixin as _ApiMixin
from .telegram_meldung import MeldungMixin as _MeldungMixin
from .telegram_empfang import EmpfangMixin as _EmpfangMixin
from .telegram_befehle import BefehleMixin as _BefehleMixin
from .telegram_lauf import LaufMixin as _LaufMixin


class Telegram(_KernMixin, _ApiMixin, _MeldungMixin, _EmpfangMixin, _BefehleMixin, _LaufMixin):
    """Telegram-Bot: Kopplung, Befehle, Meldungen und der Hintergrundlauf."""
