"""ApiMixin-Mixin von Telegram."""

from .telegram_grund import (
    KOPPELN_MINUTEN,
    MAX_TEXT,
    NetzFehler,
    TelegramFehler,
    secrets,
)

class ApiMixin:

    # --- Bot-API ----------------------------------------------------------------------------------
    def _api(self, methode, daten, zeit=20):
        if not self.einstellung["token"]:
            raise TelegramFehler("Kein Bot-Token eingetragen")
        try:
            return self.holen(self.einstellung["token"], methode, daten, zeit)
        except NetzFehler as fehler:
            raise TelegramFehler(str(fehler))

    def ich(self):
        info = self._api("getMe", {})
        self.bot = str((info or {}).get("username") or "")
        return self.bot

    def koppeln(self):
        """Neuer Kopplungscode (10 Minuten gueltig); startet den Bot bei Bedarf, damit er die Antwort sieht."""
        self.ich()
        self._kopplung = ("%06d" % secrets.randbelow(10 ** 6), self.uhr() + KOPPELN_MINUTEN * 60)
        if not self.laeuft:
            self.starten(auch_aus=True)
        return self.zustand()

    def senden(self, chat, text):
        self._api("sendMessage", {"chat_id": chat, "text": str(text)[:MAX_TEXT], "disable_web_page_preview": True})

    def testen(self):
        if not self.einstellung["chats"]:
            raise TelegramFehler("Noch kein Chat gekoppelt")
        ergebnis = []
        for c in self.einstellung["chats"]:
            try:
                self.senden(c["id"], "✅ Test von H0rSt: Meldungen kommen an.")
                ergebnis.append("%s: angekommen" % c["name"])
            except TelegramFehler as fehler:
                ergebnis.append("%s: %s" % (c["name"], fehler))
        return "; ".join(ergebnis)
