"""BefehleMixin-Mixin von Telegram."""

from .telegram_grund import (
    _MAGNET,
    json,
)

class BefehleMixin:

    # --- Befehle ----------------------------------------------------------------------------------
    @staticmethod
    def _status(app):
        z = app.waechter.zustand()
        alle = z["anbieter"]
        if not alle:
            return "Der Wächter hat noch nichts geprüft (Dienste → Verfügbarkeit)."
        zeilen = ["%d von %d erreichbar" % (len(alle) - z["gestoert"], len(alle))]
        for a in alle:
            if not a.get("ok"):
                zeilen.append("⚠️ %s: %s" % (a.get("name", a["id"]), a.get("meldung", "")))
        return "\n".join(zeilen)

    @staticmethod
    def _downloads(app):
        zeilen = []
        for a in app.xdcc.zustand()["auftraege"]:
            if a["laeuft"]:
                zeilen.append("XDCC %s – %s %.0f %%" % (a["name"], a["status"], a["prozent"]))
        for a in app.youtube_speichern.zustand()["auftraege"]:
            if a.get("laeuft"):
                zeilen.append("YouTube %s – %.0f %%" % (a.get("titel") or a.get("video"), float(a.get("prozent") or 0)))
        return "\n".join(zeilen) or "Gerade läuft kein Download."

    @staticmethod
    def _suche(app, text):
        if len(text) < 2:
            return "Was suchen? /suche Titel"
        e = app.entdecken.suche(text)
        treffer = [("Film", k) for k in e["filme"][:5]] + [("Serie", k) for k in e["serien"][:5]]
        if not treffer:
            return "Nichts gefunden."
        return "\n".join("%s: %s%s · https://www.imdb.com/title/%s/" % (art, k["titel"], " (%s)" % k["jahr"] if k.get("jahr") else "",
                                                                         k["id"]) if str(k.get("id", "")).startswith("tt")
                         else "%s: %s" % (art, k["titel"]) for art, k in treffer)

    @staticmethod
    def _dht(text):
        from . import dht
        if not text:
            return "Magnet-Link oder infoHash angeben: /dht magnet:?xt=urn:btih:…"
        try:
            r = dht.peers_zaehlen(text, dauer=8.0)
        except dht.DhtFehler as fehler:
            return "DHT: %s" % fehler
        return "🧲 DHT: %d Peers gefunden (%d Knoten geantwortet, %.0f s)" % (r["peers"], r["knoten"], r["sekunden"])

    @staticmethod
    def _torrent(app, text):
        from . import dienste
        m = _MAGNET.search(text)
        if not m:
            return "Magnet-Link angeben: /torrent magnet:?xt=urn:btih:…"
        for aid, c in (app.dienste or {}).items():
            if getattr(c, "typ", "") in dienste.TORRENT_CLIENTS:
                return "Torrent: " + app.oberflaeche.dienst_hinzu({"id": aid, "magnet": m.group(0)})["meldung"]
        return "Kein Torrent-Client eingerichtet (Anbieter → Dienste: qBittorrent, Transmission, Deluge)."

    @staticmethod
    def _licht(app, rest):
        h = app.oberflaeche._hue()
        if not h.bereit:
            return "Keine Hue-Bridge gekoppelt (Zuhause → Licht)."
        teile = rest.split(None, 1)
        z = h.zustand()
        if teile and teile[0].lower() in ("an", "aus"):
            an = teile[0].lower() == "an"
            if len(teile) == 1:
                h.alle(an)
                return "💡 Alle Lampen %s." % ("an" if an else "aus")
            gesucht = teile[1].strip().lower()
            for art, liste in (("raum", z["raeume"]), ("lampe", z["lampen"])):
                treffer = next((x for x in liste if x["name"].lower() == gesucht), None) or \
                    next((x for x in liste if gesucht in x["name"].lower()), None)
                if treffer:
                    h.schalten(art, treffer["id"], an=an)
                    return "💡 %s %s." % (treffer["name"], "an" if an else "aus")
            return "„%s“ gibt es nicht. Räume: %s; Lampen: %s" % (teile[1], ", ".join(r["name"] for r in z["raeume"]),
                                                                ", ".join(l["name"] for l in z["lampen"]))
        return "\n".join("%s %s" % ("💡" if r["an"] else "⚫", r["name"]) for r in z["raeume"]) or "Keine Räume an der Bridge."

    @staticmethod
    def _cast(app, rest):
        from . import fernseher
        geraete = app.cast_geraete or []
        teile = rest.split()
        if not teile:
            if not geraete:
                geraete = app.cast_geraete = fernseher.suchen()
            return "\n".join("📺 %s (%s)" % (g["name"], fernseher.ARTEN.get(g.get("art", "cast"), "")) for g in geraete) or \
                "Kein Fernseher oder Lautsprecher gefunden (Zuhause → Smart Home → Suchen)."
        was = {"pause": "pause", "weiter": "weiter", "play": "weiter", "stopp": "stopp", "stop": "stopp",
               "lautstaerke": "lautstaerke", "lauter": "lauter", "leiser": "leiser", "leise": "stumm",
               "stumm": "stumm"}.get(teile[0].lower())
        if not was:
            return "Befehle: /cast pause|weiter|stopp|lauter|leiser|lautstaerke 40 [Gerät]"
        wert = None
        if was == "lautstaerke":
            if len(teile) < 2 or not teile[1].isdigit():
                return "Lautstärke 0–100 angeben: /cast lautstaerke 40"
            wert, teile = int(teile[1]), teile[1:]
        elif was == "stumm":
            wert = True
        name = " ".join(teile[1:]).lower()
        if not geraete:
            geraete = app.cast_geraete = fernseher.suchen()
        standard = ((app.verwaltung.daten() if getattr(app, "verwaltung", None) else {}) or {}).get("cast_standard")
        g = next((x for x in geraete if name and name in x["name"].lower()), None) or \
            next((x for x in geraete if x.get("id") == standard), None) or (geraete[0] if geraete else None)
        if not g:
            return "Kein Fernseher oder Lautsprecher gefunden."
        stand = fernseher.steuern(g, was, wert)
        lautst = stand.get("lautstaerke")
        return "📺 %s: %s%s" % (g["name"], stand.get("zustand") or was,
                               " · Lautstärke %d" % lautst if was in ("lautstaerke", "lauter", "leiser") and lautst is not None else "")

    @staticmethod
    def _radio(app, rest):
        """Sender suchen (Favoriten zuerst) und auf dem Standard-Geraet abspielen."""
        from . import fernseher, radio
        daten = (app.verwaltung.daten() if getattr(app, "verwaltung", None) else {}) or {}
        favoriten = radio.pruefe_favoriten((daten.get(radio.SCHLUESSEL) or {}).get("favoriten"))
        if not rest:
            return "\n".join("📻 %s" % s["name"] for s in favoriten) or "Noch keine Radio-Favoriten (Reiter Radio → ★)."
        name = rest.lower()
        s = next((x for x in favoriten if name in x["name"].lower()), None)
        if not s:
            treffer = app.radio.suchen(rest, sortierung="votes", anzahl=5)
            s = treffer[0] if treffer else None
        if not s:
            return "Keinen Sender „%s“ gefunden." % rest
        geraete = app.cast_geraete or []
        if not geraete:
            geraete = app.cast_geraete = fernseher.suchen()
        g = next((x for x in geraete if x.get("id") == daten.get("cast_standard")), None) or (geraete[0] if geraete else None)
        if not g:
            return "📻 %s: %s\n(Kein Fernseher oder Lautsprecher gefunden – den Link kannst du direkt öffnen.)" % (s["name"], s["url"])
        fernseher.abspielen(g, s["url"], s["name"], s.get("bild", ""), True, mime=radio.mime(s))
        return "📻 %s läuft auf %s." % (s["name"], g["name"])

    @staticmethod
    def _pihole(app, rest):
        teile = rest.lower().split()
        for c in (app.dienste or {}).values():
            if getattr(c, "typ", "") != "pihole":
                continue
            if teile and teile[0] in ("aus", "pause"):
                minuten = int(teile[1]) if len(teile) > 1 and teile[1].isdigit() else 5
                c.aktion("pause", wert=minuten * 60)
                return "🛑 Pi-hole blockiert %d Minuten lang nicht." % minuten
            if teile and teile[0] == "an":
                c.aktion("resume")
                return "🛡 Pi-hole blockiert wieder."
            z = c.zustand()
            return "🛡 Pi-hole %s: %s %% geblockt (%d von %d Anfragen), %d Geräte, %d Domains auf der Liste" % (
                "an" if z["aktiv"] else "PAUSIERT", str(z["prozent"]).replace(".", ","), z["blockiert"], z["anfragen"],
                z["clients"], z["domains"])
        return "Kein Pi-hole eingerichtet (Anbieter → Vorlage Pi-hole)."

    @staticmethod
    def _ed2k(app, text):
        status, _, antwort = app.oberflaeche.ed2k_post("/api/ed2k/hinzu", json.dumps({"text": text}).encode("utf-8"))
        if status != 200:
            return "Ember: %s" % antwort.get("fehler", "Fehler")
        return "📥 Ember-Sammlung: %d neu, %d insgesamt. Am PC unter Laden → Ember öffnen." % (antwort["neu"], len(antwort["links"]))
