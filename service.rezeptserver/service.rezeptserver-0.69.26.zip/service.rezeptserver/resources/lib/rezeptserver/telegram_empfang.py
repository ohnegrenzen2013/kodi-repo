"""EmpfangMixin-Mixin von Telegram."""

from .telegram_grund import (
    HILFE,
    TelegramFehler,
    _MAGNET,
    chat_name,
    log,
    pruefe,
    secrets,
)

class EmpfangMixin:

    # --- Empfang ----------------------------------------------------------------------------------
    def _horchen(self, halt):
        pause = 0
        while not halt.is_set():
            try:
                updates = self._api("getUpdates", {"offset": self._versatz, "timeout": 20,
                                                    "allowed_updates": ["message"]}, zeit=30) or []
                self.fehler, pause = "", 0
            except TelegramFehler as fehler:
                self.fehler = str(fehler)
                pause = min(300, (pause or 5) * 2)
                log.warning("Telegram: %s (neuer Versuch in %d s)", fehler, pause)
                if halt.wait(pause):
                    return
                continue
            if halt.is_set():
                return  # gestoppt waehrend des Wartens: Nachrichten bleiben fuer den Nachfolger liegen
            for u in updates:
                self._versatz = max(self._versatz, int(u.get("update_id", 0)) + 1)
                try:
                    self.bearbeiten(u)
                except Exception:
                    log.exception("Telegram: Nachricht nicht bearbeitet")

    def bearbeiten(self, update):
        """Eine Nachricht: Kopplung, Befehl oder Links. Gibt die Antwort zurueck (auch fuer Tests)."""
        nachricht = update.get("message") or {}
        chat = nachricht.get("chat") or {}
        text = str(nachricht.get("text") or "").strip()
        if "id" not in chat or not text:
            return ""
        cid = chat["id"]
        bekannt = any(c["id"] == cid for c in self.einstellung["chats"])
        if not bekannt:
            code = self._kopplung if self._kopplung and self._kopplung[1] > self.uhr() else None
            wort = text.split()[-1] if text.split() else ""
            if not code or not secrets.compare_digest(wort.encode("utf-8"), code[0].encode("utf-8")):
                return ""  # fremde Chats: keine Antwort
            self._kopplung = None
            self.einstellung = pruefe(dict(self.einstellung, chats=self.einstellung["chats"] +
                                           [{"id": cid, "name": chat_name(chat)}]))
            self._sichern()
            log.info("Telegram: Chat %s gekoppelt", chat_name(chat))
            antwort = "✅ Mit H0rSt verbunden. Hier kommen ab jetzt die Meldungen.\n\n" + HILFE
        elif not self.einstellung["befehle"]:
            return ""
        else:
            antwort = self.befehl(text)
        if antwort:
            self.senden(cid, antwort)
        return antwort

    def befehl(self, text):
        wort, _, rest = text.partition(" ")
        wort = wort.split("@", 1)[0].lower()
        rest = rest.strip()
        app = self.kontext
        try:
            if wort in ("/start", "/hilfe", "/help"):
                return HILFE
            if wort == "/stumm":
                stunden = max(1, min(168, int(rest))) if rest.isdigit() else 8
                self._stumm_bis = self.uhr() + stunden * 3600
                return "🔕 Meldungen pausiert für %d Stunden. /laut schaltet sie wieder ein." % stunden
            if wort == "/laut":
                self._stumm_bis = 0
                return "🔔 Meldungen wieder an."
            if wort == "/dht":
                return self._dht(rest)
            braucht_app = wort in ("/status", "/downloads", "/links", "/suche", "/torrent", "/pihole", "/licht", "/cast", "/radio") or "ed2k://" in text.lower()
            if app is None and braucht_app:
                return "H0rSt startet noch, gleich noch einmal versuchen."
            if wort.startswith("/") and wort not in ("/status", "/downloads", "/links", "/suche", "/torrent", "/pihole", "/licht", "/cast", "/radio"):
                return "Unbekannter Befehl.\n\n" + HILFE
            if wort == "/status":
                return self._status(app)
            if wort == "/downloads":
                return self._downloads(app)
            if wort == "/links":
                return "\n".join("%s – %s" % (l["name"], l["url"]) for l in app.links) or "Keine Heim-Links."
            if wort == "/suche":
                return self._suche(app, rest)
            if wort == "/torrent":
                return self._torrent(app, rest)
            if wort == "/pihole":
                return self._pihole(app, rest)
            if wort == "/licht":
                return self._licht(app, rest)
            if wort == "/cast":
                return self._cast(app, rest)
            if wort == "/radio":
                return self._radio(app, rest)
            if "ed2k://" in text.lower():
                return self._ed2k(app, text)
            if _MAGNET.search(text):
                return self._dht(_MAGNET.search(text).group(0)) + "\nMit /torrent <Magnet> an den Torrent-Client geben."
            return ""
        except Exception as fehler:  # eine Antwort ist besser als Schweigen
            log.warning("Telegram-Befehl %s: %s", wort, fehler)
            return "Fehler: %s" % str(fehler)[:300]
