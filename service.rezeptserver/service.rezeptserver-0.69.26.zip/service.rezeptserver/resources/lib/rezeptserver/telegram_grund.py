"""Grundlage von Telegram: Konstanten, Pruefung und die Telegramfehler.
Alles hier wird samt Importen wieder exportiert (rezeptserver.telegram.*)."""


import json
import logging
import queue
import re
import secrets
import threading
import time

from . import ereignisse
from .netz import NetzFehler, antwort_holen

log = logging.getLogger("rezeptserver")

SCHLUESSEL = "telegram"
STANDARD = {"an": False, "token": "", "chats": [], "melden": ["waechter", "download", "update"], "nur_stoerungen": False,
            "befehle": True}
ARTEN = {"waechter": "Verfügbarkeit (Wächter): Ausfall und wieder erreichbar",
         "download": "Downloads: XDCC und YouTube fertig oder fehlgeschlagen",
         "update": "Aktualisierung: neue Version im GitHub-Repo oder installiert"}
API = "https://api.telegram.org/bot%s/%s"
MAX_CHATS = 10
MAX_TEXT = 4000
KOPPELN_MINUTEN = 10
_TOKEN = re.compile(r"^\d{5,12}:[A-Za-z0-9_-]{30,50}$")
_MAGNET = re.compile(r"magnet:\?[^\s<>\"]+", re.I)
HILFE = ("H0rSt-Befehle:\n"
         "/status – Verfügbarkeit der Anbieter und Dienste\n"
         "/downloads – laufende XDCC- und YouTube-Downloads\n"
         "/suche <Titel> – Filme und Serien suchen\n"
         "/links – Heim-Links\n"
         "/dht <Magnet oder Hash> – Quellen im BitTorrent-DHT zählen\n"
         "/torrent <Magnet> – an den ersten Torrent-Client geben\n"
         "/pihole – Pi-hole-Stand, /pihole aus [Minuten], /pihole an\n"
         "/licht – Räume (Hue), /licht an|aus [Raum oder Lampe]\n"
         "/cast – Fernseher & Lautsprecher: /cast pause|weiter|stopp|lauter|leiser [Gerät], /cast lautstaerke 40 [Gerät]\n"
         "/radio <Sender> – Radio auf dem Standard-Gerät (z. B. /radio swr3), /radio – Favoriten\n"
         "/stumm [Stunden] – Meldungen pausieren (Standard 8), /laut – wieder melden\n"
         "ed2k-Links einfach schicken: sie landen in der Ember-Sammlung.")


class TelegramFehler(ValueError):
    pass


def pruefe(roh):
    e = json.loads(json.dumps(STANDARD))
    if isinstance(roh, dict):
        e.update({k: roh[k] for k in STANDARD if k in roh})
    for k in ("an", "nur_stoerungen"):
        e[k] = e[k] is True
    e["befehle"] = e["befehle"] is not False
    e["token"] = str(e["token"] or "").strip()
    if e["token"] and not _TOKEN.match(e["token"]):
        raise TelegramFehler("Bot-Token hat nicht die Form 123456789:ABC… (von @BotFather)")
    e["melden"] = [a for a in e["melden"] if a in ARTEN] if isinstance(e["melden"], list) else []
    chats, gesehen = [], set()
    for c in e["chats"] if isinstance(e["chats"], list) else []:
        try:
            cid = int(c.get("id")) if isinstance(c, dict) else int(c)
        except (TypeError, ValueError):
            continue
        if cid not in gesehen:
            gesehen.add(cid)
            chats.append({"id": cid, "name": str((c.get("name") if isinstance(c, dict) else "") or cid)[:80]})
    if len(chats) > MAX_CHATS:
        raise TelegramFehler("Höchstens %d Chats" % MAX_CHATS)
    e["chats"] = chats
    if e["an"] and not e["token"]:
        raise TelegramFehler("Zum Einschalten das Bot-Token eintragen")
    return e


def _holen(token, methode, daten, zeit=20):
    status, text = antwort_holen(API % (token, methode), "POST", {"Content-Type": "application/json"},
                                 json.dumps(daten), zeitgrenze=zeit)
    try:
        antwort = json.loads(text)
    except ValueError:
        raise TelegramFehler("Telegram antwortet nicht mit JSON (HTTP %d)" % status)
    if not antwort.get("ok"):
        raise TelegramFehler("Telegram: %s" % str(antwort.get("description") or "HTTP %d" % status)[:200])
    return antwort.get("result")


def chat_name(chat):
    return str(chat.get("title") or " ".join(filter(None, [chat.get("first_name"), chat.get("last_name")]))
               or chat.get("username") or chat.get("id"))[:80]
