"""KernMixin-Mixin von Telegram."""

from .telegram_grund import (
    ARTEN,
    STANDARD,
    TelegramFehler,
    _holen,
    pruefe,
    queue,
    threading,
    time,
)

class KernMixin:
    def __init__(self, einstellung=None, speichern=None, holen=None, uhr=time.time):
        self.einstellung = pruefe(einstellung)
        self._speichern = speichern
        self.holen = holen or _holen      # holen(token, methode, daten, zeit) -> result
        self.uhr = uhr
        self.kontext = None               # die App, fuer Befehle (Waechter, Downloads, Suche ...)
        self._sperre = threading.Lock()
        self._halt = threading.Event()
        self._faeden = []
        self._post = queue.Queue(maxsize=200)
        self._kopplung = None             # (code, ablauf)
        self._stumm_bis = 0
        self._versatz = 0
        self.bot = ""                     # @Name des Bots (nach getMe)
        self.fehler = ""

    # --- Einstellungen -------------------------------------------------------------------------
    def _sichern(self):
        if self._speichern:
            self._speichern(dict(self.einstellung))

    def zustand(self):
        e = self.einstellung
        code = self._kopplung if self._kopplung and self._kopplung[1] > self.uhr() else None
        return {"an": e["an"], "token_gesetzt": bool(e["token"]), "chats": e["chats"], "melden": e["melden"],
                "nur_stoerungen": e["nur_stoerungen"], "befehle": e["befehle"], "arten": ARTEN,
                "bot": self.bot, "laeuft": self.laeuft, "fehler": self.fehler,
                "stumm_bis": self._stumm_bis if self._stumm_bis > self.uhr() else 0,
                "code": code[0] if code else "", "link": ("https://t.me/%s?start=%s" % (self.bot, code[0]))
                if code and self.bot else ""}

    @property
    def laeuft(self):
        return any(f.is_alive() for f in self._faeden)

    def einstellen(self, neu):
        if not isinstance(neu, dict):
            raise TelegramFehler("JSON-Objekt erwartet")
        e = dict(self.einstellung)
        for k, w in neu.items():
            if k == "token_weg":
                if w:
                    e["token"], e["an"], e["chats"] = "", False, []
            elif k == "token":
                if str(w or "").strip():
                    e["token"] = str(w).strip()
                    self.bot = ""
            elif k in STANDARD and k != "chats":
                e[k] = w
            elif k != "chats":
                raise TelegramFehler("Unbekannte Einstellung: %s" % k)
        e = pruefe(e)
        token_neu = e["token"] != self.einstellung["token"]
        self.einstellung = e
        self._sichern()
        if token_neu or not e["an"]:
            self.stoppen()
        if e["an"] and not self.laeuft:
            self.starten()
        return self.zustand()

    def chat_entfernen(self, cid):
        self.einstellung = pruefe(dict(self.einstellung, chats=[c for c in self.einstellung["chats"]
                                                                 if str(c["id"]) != str(cid)]))
        self._sichern()
        return self.zustand()
