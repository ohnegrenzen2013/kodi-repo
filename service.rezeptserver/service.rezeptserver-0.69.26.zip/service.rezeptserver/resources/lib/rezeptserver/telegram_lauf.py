"""LaufMixin-Mixin von Telegram."""

from .telegram_grund import (
    TelegramFehler,
    ereignisse,
    threading,
)

class LaufMixin:

    # --- Lauf -------------------------------------------------------------------------------------
    def starten(self, auch_aus=False):
        with self._sperre:
            if self.laeuft or not self.einstellung["token"] or not (self.einstellung["an"] or auch_aus):
                return False
            self._halt = threading.Event()
            halt = self._halt
            self._faeden = [threading.Thread(target=self._horchen, args=(halt,), name="telegram-empfang", daemon=True),
                            threading.Thread(target=self._postbote, args=(halt,), name="telegram-post", daemon=True)]
            for f in self._faeden:
                f.start()
        ereignisse.anmelden(self.melden)
        if not self.bot:
            threading.Thread(target=self._name_holen, name="telegram-name", daemon=True).start()
        return True

    def _name_holen(self):
        try:
            self.ich()
        except TelegramFehler as fehler:
            self.fehler = str(fehler)

    def stoppen(self):
        ereignisse.abmelden(self.melden)
        with self._sperre:
            self._halt.set()
            self._faeden = []
