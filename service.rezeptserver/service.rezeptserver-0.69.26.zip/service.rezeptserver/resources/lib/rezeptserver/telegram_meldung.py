"""MeldungMixin-Mixin von Telegram."""

from .telegram_grund import (
    TelegramFehler,
    log,
    queue,
)

class MeldungMixin:

    # --- Meldungen --------------------------------------------------------------------------------
    def melden(self, art, text, ok=True):
        e = self.einstellung
        if not e["an"] or art not in e["melden"] or not e["chats"] or self._stumm_bis > self.uhr():
            return
        if ok and e["nur_stoerungen"]:
            return
        zeichen = "✅" if ok else "⚠️"
        for c in e["chats"]:
            try:
                self._post.put_nowait((c["id"], "%s %s" % (zeichen, text)))
            except queue.Full:
                log.warning("Telegram: Warteschlange voll, Meldung verworfen")
                return

    def _postbote(self, halt):
        while not halt.is_set():
            try:
                chat, text = self._post.get(timeout=1)
            except queue.Empty:
                continue
            for versuch in range(3):
                try:
                    self.senden(chat, text)
                    break
                except TelegramFehler as fehler:
                    self.fehler = str(fehler)
                    log.warning("Telegram senden: %s", fehler)
                    if halt.wait(5 * (versuch + 1)):
                        return
