"""HTTPS fuer H0rSt: eigenes Zertifikat erzeugen (nur Python-Standardbibliothek) und den TLS-Zugang einrichten.

Browser erlauben Kamera und Mikrofon (Videochat, Profilbild) nur in einer sicheren Umgebung: HTTPS oder das eigene
Geraet. Deshalb bietet H0rSt im Heimnetz zusaetzlich https://<ip>:7443/<token>/ an. Das Zertifikat erzeugt H0rSt
selbst (RSA 2048, SHA-256, gueltig fuer localhost, h0rst.local und die IP-Adressen des Servers); der Browser fragt
beim ersten Besuch einmal nach, weil es nicht von einer Zertifizierungsstelle stammt. Es liegt neben den Nutzerdaten
(h0rst-zertifikat.pem, h0rst-schluessel.pem, nur fuer den Besitzer lesbar) und wird nach Ablauf erneuert.

Kein Paket wie cryptography noetig, damit es auch in der App (Chaquopy), in Kodi und im Container laeuft.
"""

import datetime
import hashlib
import ipaddress
import logging
import os
import secrets
import socket
import ssl

log = logging.getLogger("rezeptserver")

ZERTIFIKAT = "h0rst-zertifikat.pem"
SCHLUESSEL = "h0rst-schluessel.pem"
GUELTIG_TAGE = 397
_KLEINE_PRIMZAHLEN = [p for p in range(3, 2000, 2) if all(p % t for t in range(3, int(p ** 0.5) + 1, 2))]


# --- RSA --------------------------------------------------------------------------------------
def _wahrscheinlich_prim(n, runden=40):
    if n < 2:
        return False
    for p in _KLEINE_PRIMZAHLEN:
        if n % p == 0:
            return n == p
    d, r = n - 1, 0
    while d % 2 == 0:
        d //= 2
        r += 1
    for _ in range(runden):
        a = secrets.randbelow(n - 3) + 2
        x = pow(a, d, n)
        if x in (1, n - 1):
            continue
        for _ in range(r - 1):
            x = pow(x, 2, n)
            if x == n - 1:
                break
        else:
            return False
    return True


def _primzahl(bits):
    while True:
        kandidat = secrets.randbits(bits) | (1 << (bits - 1)) | (1 << (bits - 2)) | 1
        if _wahrscheinlich_prim(kandidat):
            return kandidat


def rsa_schluessel(bits=2048, e=65537):
    while True:
        p, q = _primzahl(bits // 2), _primzahl(bits // 2)
        if p == q:
            continue
        phi = (p - 1) * (q - 1)
        try:
            d = pow(e, -1, phi)
        except ValueError:
            continue
        n = p * q
        if n.bit_length() == bits:
            return {"n": n, "e": e, "d": d, "p": p, "q": q}


# --- DER --------------------------------------------------------------------------------------
def _laenge(n):
    if n < 0x80:
        return bytes([n])
    roh = n.to_bytes((n.bit_length() + 7) // 8, "big")
    return bytes([0x80 | len(roh)]) + roh


def _tlv(tag, inhalt):
    return bytes([tag]) + _laenge(len(inhalt)) + inhalt


def _int(wert):
    roh = wert.to_bytes(max(1, (wert.bit_length() + 8) // 8), "big")  # fuehrende 0 bei gesetztem Bit
    return _tlv(0x02, roh)


def _seq(*teile):
    return _tlv(0x30, b"".join(teile))


def _oid(text):
    teile = [int(x) for x in text.split(".")]
    roh = bytes([40 * teile[0] + teile[1]])
    for t in teile[2:]:
        stueck = [t & 0x7F]
        t >>= 7
        while t:
            stueck.insert(0, 0x80 | (t & 0x7F))
            t >>= 7
        roh += bytes(stueck)
    return _tlv(0x06, roh)


def _name(cn):
    return _seq(_tlv(0x31, _seq(_oid("2.5.4.3"), _tlv(0x0C, cn.encode("utf-8")))),
                _tlv(0x31, _seq(_oid("2.5.4.10"), _tlv(0x0C, b"m0dulh0st - H0rSt"))))


def _zeit(t):
    if t.year < 2050:
        return _tlv(0x17, t.strftime("%y%m%d%H%M%SZ").encode("ascii"))
    return _tlv(0x18, t.strftime("%Y%m%d%H%M%SZ").encode("ascii"))


def _pem(art, der):
    import base64
    text = base64.encodebytes(der).decode("ascii").replace("\n", "")
    zeilen = [text[i:i + 64] for i in range(0, len(text), 64)]
    return "-----BEGIN %s-----\n%s\n-----END %s-----\n" % (art, "\n".join(zeilen), art)


def zertifikat_bauen(schluessel, namen, ips, jetzt=None):
    """Selbst signiertes X.509-v3-Zertifikat (DER) fuer namen (DNS) und ips."""
    jetzt = jetzt or datetime.datetime.now(datetime.timezone.utc).replace(tzinfo=None)
    n, e, d = schluessel["n"], schluessel["e"], schluessel["d"]
    alg = _seq(_oid("1.2.840.113549.1.1.11"), b"\x05\x00")
    oeffentlich = _seq(_seq(_oid("1.2.840.113549.1.1.1"), b"\x05\x00"), _tlv(0x03, b"\x00" + _seq(_int(n), _int(e))))
    san = b"".join(_tlv(0x82, x.encode("ascii")) for x in namen) + \
        b"".join(_tlv(0x87, ipaddress.ip_address(x).packed) for x in ips)
    erweiterungen = _tlv(0xA3, _seq(
        _seq(_oid("2.5.29.19"), _tlv(0x04, _seq())),                                   # basicConstraints: kein CA
        _seq(_oid("2.5.29.15"), b"\x01\x01\xff", _tlv(0x04, _tlv(0x03, b"\x05\xa0"))),  # keyUsage: Signatur, Schluessel
        _seq(_oid("2.5.29.37"), _tlv(0x04, _seq(_oid("1.3.6.1.5.5.7.3.1")))),        # extKeyUsage: serverAuth
        _seq(_oid("2.5.29.17"), _tlv(0x04, _tlv(0x30, san))),                          # subjectAltName
    ))
    tbs = _seq(_tlv(0xA0, _int(2)), _int(int.from_bytes(secrets.token_bytes(15), "big") | 1), alg,
               _name("H0rSt"), _seq(_zeit(jetzt - datetime.timedelta(days=1)), _zeit(jetzt + datetime.timedelta(days=GUELTIG_TAGE))),
               _name("H0rSt"), oeffentlich, erweiterungen)
    digest = bytes.fromhex("3031300d060960864801650304020105000420") + hashlib.sha256(tbs).digest()
    k = (n.bit_length() + 7) // 8
    em = b"\x00\x01" + b"\xff" * (k - len(digest) - 3) + b"\x00" + digest
    signatur = pow(int.from_bytes(em, "big"), d, n).to_bytes(k, "big")
    return _seq(tbs, alg, _tlv(0x03, b"\x00" + signatur))


def schluessel_der(s):
    p, q, d = s["p"], s["q"], s["d"]
    return _seq(_int(0), _int(s["n"]), _int(s["e"]), _int(d), _int(p), _int(q), _int(d % (p - 1)), _int(d % (q - 1)),
                _int(pow(q, -1, p)))


# --- Einrichten -------------------------------------------------------------------------------
def eigene_ips():
    ips = {"127.0.0.1"}
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        s.connect(("192.0.2.1", 9))  # schickt nichts, ermittelt nur die Heimnetz-IP
        ips.add(s.getsockname()[0])
        s.close()
    except OSError:
        pass
    try:
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            ips.add(info[4][0])
    except OSError:
        pass
    return sorted(ips)


def zertifikat(ordner, ips=None, neu=False):
    """Pfade (zertifikat, schluessel); erzeugt bzw. erneuert sie bei Bedarf (fehlende IP, bald abgelaufen)."""
    z, k = os.path.join(ordner, ZERTIFIKAT), os.path.join(ordner, SCHLUESSEL)
    ips = sorted(set(ips or eigene_ips()))
    merker = z + ".ips"
    if not neu and os.path.isfile(z) and os.path.isfile(k):
        try:
            with open(merker, encoding="utf-8") as f:
                bekannt = set(f.read().split())
            alt = (datetime.datetime.now().timestamp() - os.path.getmtime(z)) / 86400
            if set(ips) <= bekannt and alt < GUELTIG_TAGE - 30:
                return z, k
        except OSError:
            pass
    log.info("Erzeuge HTTPS-Zertifikat fuer %s ...", ", ".join(ips))
    s = rsa_schluessel()
    namen = []
    for n in ("localhost", "h0rst.local", socket.gethostname() or "h0rst"):
        if n and n not in namen and all(c.isalnum() or c in ".-" for c in n):
            namen.append(n)
    cert = zertifikat_bauen(s, namen, ips)
    os.makedirs(ordner, exist_ok=True)
    fd = os.open(k + ".neu", os.O_WRONLY | os.O_CREAT | os.O_TRUNC, 0o600)
    with os.fdopen(fd, "w", encoding="ascii") as f:
        f.write(_pem("RSA PRIVATE KEY", schluessel_der(s)))
    with open(z + ".neu", "w", encoding="ascii") as f:
        f.write(_pem("CERTIFICATE", cert))
    os.replace(k + ".neu", k)
    os.replace(z + ".neu", z)
    with open(merker, "w", encoding="utf-8") as f:
        f.write(" ".join(ips))
    return z, k


def kontext(ordner):
    z, k = zertifikat(ordner)
    ctx = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
    ctx.minimum_version = ssl.TLSVersion.TLSv1_2
    ctx.load_cert_chain(z, k)
    return ctx


def fingerabdruck(ordner):
    """SHA-256-Fingerabdruck des Zertifikats (zum Vergleichen bei der Browser-Warnung)."""
    import base64
    try:
        with open(os.path.join(ordner, ZERTIFIKAT), encoding="ascii") as f:
            pem = f.read()
    except OSError:
        return ""
    der = base64.b64decode("".join(l for l in pem.splitlines() if not l.startswith("-----")))
    h = hashlib.sha256(der).hexdigest().upper()
    return ":".join(h[i:i + 2] for i in range(0, len(h), 2))
