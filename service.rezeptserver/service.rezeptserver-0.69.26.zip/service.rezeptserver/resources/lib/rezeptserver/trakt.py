"""Trakt.tv: Merkliste, Verlauf und Weiterschauen je Profil mit Trakt abgleichen (Idee aus ARVIO, eigener Code).

Anmelden per Geraete-Code (wie auf dem Fernseher): H0rSt zeigt einen Code, den gibst du auf trakt.tv/activate ein.
Dafuer braucht H0rSt eine eigene Trakt-App (trakt.tv/oauth/applications, Redirect-URI urn:ietf:wg:oauth:2.0:oob);
deren Client ID und Client Secret traegt der Admin einmal ein, verbinden kann sich dann jedes Profil selbst.

Abgleich in beide Richtungen mit dem Stand vom letzten Mal ("basis"): Was seitdem auf einer Seite dazukam, kommt auf die
andere; was auf einer Seite geloescht wurde, verschwindet auf der anderen (Merkliste) bzw. kommt nicht zurueck (Verlauf,
Weiterschauen – den Trakt-Verlauf loescht H0rSt nie). Serien gelten in H0rSt als gesehen, sobald eine Folge fertig ist;
deshalb schickt H0rSt nur Filme in den Trakt-Verlauf. Die gerade laufende Stelle geht unter 90 % als Pause, ab 90 %
als Stop an Trakt (Trakt markiert einen Stop ab 80 % als gesehen) — dieselbe Schwelle wie ARVIO 2.2.
Serien kommen als ganzer Verlauf nur von Trakt herein.

Nutzerdaten "trakt": {"app": {"client_id", "client_secret"},
                      "konten": {"<profil-id oder ''>": {"access_token", "refresh_token", "ablauf", "benutzer",
                                                         "zuletzt", "fehler", "basis": {...}}}}
"""

import re
import threading
import time

from . import sehen
from .trakt_grund import *
from .trakt_grund import (_Abgelaufen, _ids, _kalender_eintraege, _karte, _lesbar, _schluessel,
                          _stelle, _trakt_listen, _zeit)
from .trakt_konto import KontoMixin


class Trakt(KontoMixin):
    # --- Eigene Listen (ARVIO 2.3: Titel zu den eigenen Trakt-Listen hinzufuegen) -----------------------------------------
    def _mit_konto(self, profil, tun):
        """tun(app, token) mit dem Zugang dieses Profils; ein abgelaufener Zugang wird einmal erneuert."""
        daten = self._daten().daten()
        app = self._app(daten)
        konto = ((daten.get(SCHLUESSEL) or {}).get("konten") or {}).get(profil) or {}
        if not konto.get("access_token"):
            raise TraktFehler("Dieses Profil ist nicht mit Trakt verbunden")
        token = konto["access_token"]
        if float(konto.get("ablauf") or 0) < self.uhr() + 60:
            token = self._erneuern(profil, app, konto)
        try:
            return tun(app, token)
        except _Abgelaufen:
            token = self._erneuern(profil, app, konto)
            try:
                return tun(app, token)
            except _Abgelaufen:
                raise TraktFehler("Trakt lehnt die Anmeldung ab – neu verbinden")

    def eigene_listen(self, profil):
        """Die eigenen Listen des verbundenen Kontos: [{id, name, anzahl}] (Listen ohne Trakt-ID fallen weg)."""
        def holen(app, token):
            return self._pflicht("GET", "/users/me/lists", app, token) or []
        roh = self._mit_konto(profil, holen)
        listen = []
        for x in roh if isinstance(roh, list) else []:
            kennung = ((x or {}).get("ids") or {}).get("trakt") if isinstance(x, dict) else None
            if isinstance(kennung, int) and not isinstance(kennung, bool):
                listen.append({"id": str(kennung), "name": str(x.get("name") or kennung)[:100], "anzahl": int(x.get("item_count") or 0)})
        return listen

    def zur_liste(self, profil, liste_id, titel):
        """Titel ([{typ: movie|series, id: tt...}], hoechstens 20) einzeln zu einer eigenen Liste hinzufuegen.
        Ergebnis je Titel: hinzugefügt, schon drin, nicht gefunden oder Trakt-Fehler (HTTP n) - ein Fehler stoppt die anderen nicht."""
        if not re.fullmatch(r"\d{1,12}", str(liste_id or "")):
            raise TraktFehler("Liste fehlt")
        if not isinstance(titel, list) or not 0 < len(titel) <= MAX_LISTEN_TITEL:
            raise TraktFehler("1 bis %d Titel angeben" % MAX_LISTEN_TITEL)
        for t in titel:
            if not isinstance(t, dict) or t.get("typ") not in ("movie", "series") or not re.fullmatch(r"tt\d{1,12}", str(t.get("id") or "")):
                raise TraktFehler("Titel brauchen typ (movie oder series) und eine IMDb-Kennung (tt…)")

        def hinzu(app, token):
            ergebnis = []
            for t in titel:
                art = "movies" if t["typ"] == "movie" else "shows"
                status, d = self._rufen("POST", "/users/me/lists/%s/items" % liste_id, app, token, {art: [{"ids": {"imdb": t["id"]}}]})
                if status == 401:
                    raise _Abgelaufen()
                d = d if isinstance(d, dict) else {}
                if status >= 400:
                    text = "Trakt-Fehler (HTTP %d)" % status
                elif (d.get("not_found") or {}).get(art):
                    text = "nicht gefunden"
                elif ((d.get("added") or {}).get(art) or 0) > 0:
                    text = "hinzugefügt"
                elif ((d.get("existing") or {}).get(art) or 0) > 0:
                    text = "schon drin"
                else:
                    text = "Trakt-Fehler (keine Antwort)"
                ergebnis.append({"id": t["id"], "typ": t["typ"], "ergebnis": text, "ok": text in ("hinzugefügt", "schon drin")})
            return ergebnis
        return self._mit_konto(profil, hinzu)

    # --- Abgleich ----------------------------------------------------------------------------------------------------
    def faellig(self, daten, profil):
        konto = ((daten.get(SCHLUESSEL) or {}).get("konten") or {}).get(profil) if isinstance(daten.get(SCHLUESSEL), dict) else None
        return bool(konto and konto.get("access_token")) and self.uhr() - float(konto.get("zuletzt") or 0) > ABSTAND \
            and profil not in self._laeuft

    def im_hintergrund(self, profil):
        threading.Thread(target=self._sicher_abgleichen, args=(profil,), name="trakt", daemon=True).start()

    def _sicher_abgleichen(self, profil):
        try:
            self.abgleichen(profil)
        except TraktFehler as fehler:
            log.info("Trakt-Abgleich (%s): %s", profil or "ohne Profil", fehler)
        except Exception as fehler:  # noqa: BLE001 - ein Hintergrund-Abgleich darf nie unsichtbar
            # verschwinden (nur stderr via Python-Standard-Thread-Hook) - ohne dieses Netz blieb
            # konto["fehler"] leer und "zuletzt" unaktualisiert, der fehlgeschlagene Versuch war fuer
            # Admin/UI unsichtbar.
            meldung = str(fehler) or type(fehler).__name__
            self._konto_setzen(profil, lambda k: k.update(fehler=meldung) if k else None)
            log.warning("Trakt-Abgleich (%s): %s", profil or "ohne Profil", fehler)

    def abgleichen(self, profil):
        with self._sperre:
            if profil in self._laeuft:
                return {"laeuft": True}
            self._laeuft.add(profil)
        try:
            return self._abgleichen(profil)
        except TraktFehler as fehler:
            meldung = str(fehler)
            self._konto_setzen(profil, lambda k: k.update(fehler=meldung) if k else None)
            raise
        finally:
            self._laeuft.discard(profil)

    def _abgleichen(self, profil):
        verwaltung = self._daten()
        daten = verwaltung.daten()
        app = self._app(daten)
        konto = ((daten.get(SCHLUESSEL) or {}).get("konten") or {}).get(profil) or {}
        if not konto.get("access_token"):
            raise TraktFehler("Dieses Profil ist nicht mit Trakt verbunden")
        token = konto["access_token"]
        if float(konto.get("ablauf") or 0) < self.uhr() + 60:
            token = self._erneuern(profil, app, konto)
        try:
            return self._durchgang(profil, app, token, verwaltung, konto)
        except _Abgelaufen:
            token = self._erneuern(profil, app, konto)
            try:
                return self._durchgang(profil, app, token, verwaltung, konto)
            except _Abgelaufen:
                raise TraktFehler("Trakt lehnt die Anmeldung ab – neu verbinden")

    def _durchgang(self, profil, app, token, verwaltung, konto):
        holen = lambda pfad: self._pflicht("GET", pfad, app, token) or []  # noqa: E731
        trakt = _trakt_listen(holen("/sync/watchlist/movies") + holen("/sync/watchlist/shows"),
                              holen("/sync/watched/movies") + holen("/sync/watched/shows?extended=noseasons"),
                              holen("/sync/playback"))
        listen = sehen.lesen(verwaltung.daten(), profil)
        wuensche, senden, basis = plan(listen, trakt, konto.get("basis"))
        if senden["dazu"]:
            self._pflicht("POST", "/sync/watchlist", app, token, {"movies": _ids(senden["dazu"], "movie"), "shows": _ids(senden["dazu"], "series")})
        if senden["weg"]:
            self._pflicht("POST", "/sync/watchlist/remove", app, token, {"movies": _ids(senden["weg"], "movie"),
                                                                         "shows": _ids(senden["weg"], "series")})
        if senden["verlauf"]:
            self._pflicht("POST", "/sync/history", app, token, {"movies": _ids(senden["verlauf"], "movie")})
        gesendet = 0
        for w in senden["stellen"][:MAX_SCROBBLE]:
            inhalt = _stelle(w)
            if not inhalt:
                continue
            ziel = "/scrobble/stop" if float(inhalt["progress"]) >= SCROBBLE_STOP else "/scrobble/pause"
            if self._rufen("POST", ziel, app, token, inhalt)[0] < 400:
                gesendet += 1
        # die Basis ist jetzt der gemeinsame Stand: was H0rSt geschickt hat, steht auch auf Trakt
        jetzt = self.uhr()
        for k in senden["dazu"]:
            basis["merkliste"].append(_schluessel(k["typ"], k["id"]))
        basis["merkliste"] = sorted(set(basis["merkliste"]) - {_schluessel(k["typ"], k["id"]) for k in senden["weg"]})
        basis["verlauf"] = sorted(set(basis["verlauf"]) | {_schluessel(k["typ"], k["id"]) for k in senden["verlauf"]})

        def tun(d):
            for zeit, wunsch in wuensche:
                try:
                    sehen.aendern(d, profil, wunsch, jetzt=zeit or jetzt)
                except sehen.SehenFehler as fehler:
                    log.info("Trakt-Eintrag uebergangen: %s", fehler)
            konten = self._abschnitt(d)["konten"]
            if profil in konten:
                konten[profil].update(basis=basis, zuletzt=jetzt, fehler="")
        verwaltung.bearbeiten(tun)
        return {"herein": len(wuensche), "hinaus": len(senden["dazu"]) + len(senden["weg"]) + len(senden["verlauf"]) + gesendet}

    def kalender(self, profil, tage=30):
        """Veroeffentlichungen aus Trakts eigenem Kalender (Merklist/Sammlung des Kontos). Ohne Verbindung leer."""
        try:
            tage = int(tage)
        except (TypeError, ValueError):
            tage = 30
        tage = max(1, min(31, tage))
        try:
            daten = self._daten().daten()
            app = self._app(daten)
        except TraktFehler:
            return {"verbunden": False, "eintraege": []}
        konto = ((daten.get(SCHLUESSEL) or {}).get("konten") or {}).get(profil) or {}
        if not konto.get("access_token"):
            return {"verbunden": False, "eintraege": []}
        token = konto["access_token"]
        if float(konto.get("ablauf") or 0) < self.uhr() + 60:
            try:
                token = self._erneuern(profil, app, konto)
            except TraktFehler:
                return {"verbunden": False, "eintraege": [], "fehler": ABGELAUFEN}
        start = time.strftime("%Y-%m-%d", time.gmtime(self.uhr()))

        def holen(art):
            return self._pflicht("GET", "/calendars/my/%s/%s/%d" % (art, start, tage), app, token) or []

        try:
            shows, movies = holen("shows"), holen("movies")
        except _Abgelaufen:
            try:
                token = self._erneuern(profil, app, konto)
                shows = self._pflicht("GET", "/calendars/my/shows/%s/%d" % (start, tage), app, token) or []
                movies = self._pflicht("GET", "/calendars/my/movies/%s/%d" % (start, tage), app, token) or []
            except _Abgelaufen:
                return {"verbunden": False, "eintraege": [], "fehler": ABGELAUFEN}
            except TraktFehler as fehler:
                return {"verbunden": True, "eintraege": [], "fehler": _lesbar(fehler)}
        except TraktFehler as fehler:
            return {"verbunden": True, "eintraege": [], "fehler": _lesbar(fehler)}
        if not isinstance(shows, list):
            shows = []
        if not isinstance(movies, list):
            movies = []
        return {"verbunden": True, "eintraege": _kalender_eintraege(shows, movies)}
