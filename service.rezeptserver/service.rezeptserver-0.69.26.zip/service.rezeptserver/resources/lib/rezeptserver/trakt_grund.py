"""Trakt.tv: Konstanten, Fehler und gemeinsame Helfer."""

import logging
from datetime import datetime

log = logging.getLogger("rezeptserver")

API = "https://api.trakt.tv"
SCHLUESSEL = "trakt"
REDIRECT = "urn:ietf:wg:oauth:2.0:oob"
ABSTAND = 15 * 60          # so oft gleicht H0rSt von selbst ab (beim Oeffnen von Merkliste/Verlauf)
MAX_SCROBBLE = 10          # Weiterschauen-Stellen je Abgleich an Trakt
MAX_LISTEN_TITEL = 20
SCROBBLE_STOP = 90.0       # ab hier /scrobble/stop statt Pause (ARVIO: 90 %; Trakt wertet Stop ab 80 % als gesehen)
POSTER = "https://images.metahub.space/poster/medium/%s/img"


class TraktFehler(ValueError):
    def __init__(self, text="", status=None):
        super().__init__(text)
        self.status = status


def _lesbar(fehler):
    """Was dem Nutzer bei einem Trakt-Fehler gesagt wird: die Ursache, nicht nur "gerade nicht erreichbar"."""
    status = getattr(fehler, "status", None)
    if status == 429:
        return "Trakt: zu viele Anfragen – in ein paar Minuten noch einmal versuchen"
    if status and status >= 500:
        return "Trakt meldet eine Störung (HTTP %d) – später noch einmal versuchen" % status
    if status:
        return "Trakt-Kalender nicht geladen (HTTP %d)" % status
    return "Trakt nicht erreichbar – Internetverbindung prüfen und noch einmal versuchen"


def _zeit(text):
    """ISO-Zeit von Trakt ("2026-10-17T12:00:00.000Z") als Sekunden; 0 bei Unsinn."""
    try:
        return datetime.fromisoformat(str(text).replace("Z", "+00:00")).timestamp()
    except (TypeError, ValueError):
        return 0.0


def _karte(eintrag, typ):
    """Karte fuer sehen.py aus einem Trakt-Film oder einer Trakt-Serie; None ohne IMDb-Nummer."""
    imdb = str(((eintrag or {}).get("ids") or {}).get("imdb") or "")
    if not imdb.startswith("tt"):
        return None
    return {"id": imdb, "typ": typ, "titel": str(eintrag.get("title") or imdb), "jahr": str(eintrag.get("year") or ""),
            "poster": POSTER % imdb}


def _schluessel(typ, kennung):
    return "%s:%s" % (typ, kennung)


def _trakt_listen(watchlist, watched, playback):
    """Trakt-Antworten als {merkliste: {schluessel: (zeit, karte)}, verlauf: {...}, weiterschauen: {schluessel: (zeit,
    karte, video, anteil)}}."""
    stand = {"merkliste": {}, "verlauf": {}, "weiterschauen": {}}
    for e in watchlist:
        typ = "movie" if e.get("type") == "movie" else "series" if e.get("type") == "show" else None
        k = _karte(e.get("movie" if typ == "movie" else "show"), typ) if typ else None
        if k:
            stand["merkliste"][_schluessel(typ, k["id"])] = (_zeit(e.get("listed_at")), k)
    for e in watched:
        typ = "movie" if "movie" in e else "series" if "show" in e else None
        k = _karte(e.get("movie" if typ == "movie" else "show"), typ) if typ else None
        if k:
            stand["verlauf"][_schluessel(typ, k["id"])] = (_zeit(e.get("last_watched_at")), k)
    for e in playback:
        if e.get("type") == "movie":
            k, video = _karte(e.get("movie"), "movie"), None
        elif e.get("type") == "episode":
            k, folge = _karte(e.get("show"), "series"), e.get("episode") or {}
            video = "%s:%s:%s" % (k["id"], folge.get("season"), folge.get("number")) if k else None
        else:
            continue
        try:
            anteil = max(0.0, min(1.0, float(e.get("progress") or 0) / 100.0))
        except (TypeError, ValueError):
            continue
        if k:
            stand["weiterschauen"][_schluessel(k["typ"], k["id"])] = (_zeit(e.get("paused_at")), k, video or k["id"], anteil)
    return stand


def plan(listen, trakt, basis):
    """Was zu tun ist: (wuensche fuer sehen.aendern als [(zeit, wunsch)], an Trakt {dazu, weg, verlauf, stellen}, neue
    basis). listen = sehen.lesen(...), trakt = _trakt_listen(...), basis = Stand vom letzten Abgleich."""
    basis = basis if isinstance(basis, dict) else {}
    hier = {name: {_schluessel(k["typ"], k["id"]): k for k in listen[name]} for name in ("merkliste", "verlauf")}
    wuensche, senden = [], {"dazu": [], "weg": [], "verlauf": [], "stellen": []}
    # Merkliste: beide Richtungen, auch Loeschen
    alt = set(basis.get("merkliste") or [])
    for s, (zeit, k) in trakt["merkliste"].items():
        if s not in hier["merkliste"]:
            if s in alt:
                senden["weg"].append(k)            # hier entfernt -> auf Trakt entfernen
            else:
                wuensche.append((zeit, {"aktion": "merken", "titel": k}))
    for s, k in hier["merkliste"].items():
        if s not in trakt["merkliste"]:
            if s in alt:
                wuensche.append((0, {"aktion": "weg", "titel": k}))  # auf Trakt entfernt -> hier entfernen
            elif k["id"].startswith("tt"):
                senden["dazu"].append(k)
    # Verlauf: Neues von Trakt herein (ausser hier bewusst entfernt), Filme von hier in den Trakt-Verlauf
    alt = set(basis.get("verlauf") or [])
    for s, (zeit, k) in trakt["verlauf"].items():
        if s not in hier["verlauf"] and s not in alt:
            wuensche.append((zeit, {"aktion": "gesehen", "titel": k}))
    for s, k in hier["verlauf"].items():
        if s not in trakt["verlauf"] and s not in alt and k["typ"] == "movie" and k["id"].startswith("tt"):
            senden["verlauf"].append(k)
    # Weiterschauen: die neuere Stelle gewinnt; was hier entfernt wurde, kommt nur mit einer neueren Stelle zurueck
    alt = basis.get("weiterschauen") if isinstance(basis.get("weiterschauen"), dict) else {}
    hier_w = {_schluessel(w["typ"], w["id"]): w for w in listen["weiterschauen"]}
    for s, (zeit, k, video, anteil) in trakt["weiterschauen"].items():
        w = hier_w.get(s)
        neuer = zeit > float((w or {}).get("zeit") or 0) + 1
        if (w and neuer) or (not w and zeit > float(alt.get(s) or 0) + 1):
            wuensche.append((zeit, {"aktion": "fortschritt", "titel": k, "video": video, "anteil": anteil}))
    for s, w in hier_w.items():
        drueben = trakt["weiterschauen"].get(s)
        if w["id"].startswith("tt") and not w.get("naechste") and float(w.get("zeit") or 0) > (drueben[0] if drueben else 0) + 1:
            senden["stellen"].append(w)
    wuensche.sort(key=lambda z: z[0])  # aelteste zuerst: das Neueste landet vorn
    # Verlauf: was schon einmal abgeglichen war und hier noch steht, bleibt in der Basis (auch wenn Trakt es noch nicht meldet)
    verlauf_alt = set(basis.get("verlauf") or []) & set(hier["verlauf"])
    neu_basis = {"merkliste": sorted(trakt["merkliste"]), "verlauf": sorted(set(trakt["verlauf"]) | verlauf_alt),
                 "weiterschauen": {s: z[0] for s, z in trakt["weiterschauen"].items()}}
    return wuensche, senden, neu_basis


def _kalender_eintraege(shows, movies):
    """Trakt-Kalender in der Form der Dienste-Zentrale. Folgen nur mit echter Uhrzeit (first_aired),
    Filme nur mit dem Datum (released) — keine erfundene Mitternacht."""
    eintraege = []
    for zeile in shows or []:
        if not isinstance(zeile, dict):
            continue
        folge, serie = zeile.get("episode") or {}, zeile.get("show") or {}
        luft = str(zeile.get("first_aired") or "")
        if "T" not in luft:
            continue
        staffel, nummer = folge.get("season"), folge.get("number")
        if not isinstance(staffel, int) or not isinstance(nummer, int) or staffel < 0 or nummer <= 0:
            continue
        titel = ("%s S%02dE%02d %s" % (serie.get("title") or "", staffel, nummer, folge.get("title") or "")).strip()
        eintraege.append({"dienst": "Trakt", "art": "Folge", "datum": luft[:16], "titel": titel,
                          "vorhanden": False, "beobachtet": True})
    for zeile in movies or []:
        if not isinstance(zeile, dict):
            continue
        film = zeile.get("movie") or {}
        datum = str(zeile.get("released") or "")[:10]
        if len(datum) != 10 or not film.get("title"):
            continue
        jahr = " (%s)" % film["year"] if film.get("year") else ""
        eintraege.append({"dienst": "Trakt", "art": "Film", "datum": datum, "titel": str(film["title"]) + jahr,
                          "vorhanden": False, "beobachtet": True})
    eintraege.sort(key=lambda e: (e["datum"], e["titel"].lower()))
    return eintraege


def _ids(karten, typ):
    return [{"ids": {"imdb": k["id"]}} for k in karten if k["typ"] == typ]


def _stelle(w):
    """Inhalt fuer /scrobble/pause aus einem Weiterschauen-Eintrag."""
    fortschritt = round(max(0.0, min(100.0, float(w.get("anteil") or 0) * 100)), 2)
    teile = str(w.get("video") or "").split(":")
    if w["typ"] == "series":
        if len(teile) < 3 or not teile[-1].isdigit() or not teile[-2].isdigit():
            return None
        return {"show": {"ids": {"imdb": w["id"]}}, "episode": {"season": int(teile[-2]), "number": int(teile[-1])},
                "progress": fortschritt}
    return {"movie": {"ids": {"imdb": w["id"]}}, "progress": fortschritt}


ABGELAUFEN = "Die Anmeldung bei Trakt ist abgelaufen – unter Einstellungen › Konten neu verbinden"


class _Abgelaufen(Exception):
    """Trakt antwortet 401: Zugang erneuern und noch einmal."""
