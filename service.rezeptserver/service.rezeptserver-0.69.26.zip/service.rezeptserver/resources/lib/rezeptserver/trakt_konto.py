"""Trakt.tv: Nutzerdaten, Geraete-Code und Anmeldung."""

import json
import threading
import time

from .netz import NetzFehler, antwort_holen
from .trakt_grund import API, REDIRECT, SCHLUESSEL, TraktFehler, _Abgelaufen, log


class KontoMixin:
    """Nutzerdaten, Geraete-Code und Anmeldung."""

    def __init__(self, verwaltung, holen=None, uhr=None):
        self._verwaltung = verwaltung  # Funktion: die Verwaltung der Nutzerdaten (oder None)
        self.holen = holen or antwort_holen
        self.uhr = uhr or time.time
        self._geraete = {}           # profil -> laufende Anmeldung per Geraete-Code
        self._sperre = threading.Lock()
        self._laeuft = set()

    # --- Nutzerdaten -------------------------------------------------------------------------------------------------
    @staticmethod
    def _abschnitt(daten):
        t = daten.get(SCHLUESSEL) if isinstance(daten.get(SCHLUESSEL), dict) else {}
        t.setdefault("app", {})
        t.setdefault("konten", {})
        daten[SCHLUESSEL] = t
        return t

    def _daten(self):
        v = self._verwaltung()
        if v is None:
            raise TraktFehler("Nutzerdaten nicht verfügbar")
        return v

    def _konto_setzen(self, profil, aenderung):
        def tun(d):
            konten = self._abschnitt(d)["konten"]
            konto = dict(konten.get(profil) or {})
            aenderung(konto)
            if konto:
                konten[profil] = konto
            else:
                konten.pop(profil, None)
        self._daten().bearbeiten(tun)

    def stand(self, daten, profil):
        t = daten.get(SCHLUESSEL) if isinstance(daten.get(SCHLUESSEL), dict) else {}
        app = t.get("app") or {}
        konto = (t.get("konten") or {}).get(profil) or {}
        g = self._geraete.get(profil)
        ergebnis = {"eingerichtet": bool(app.get("client_id") and app.get("client_secret")),
                    "client_id": str(app.get("client_id") or ""), "verbunden": bool(konto.get("access_token")),
                    "benutzer": konto.get("benutzer", ""), "zuletzt": konto.get("zuletzt", 0), "fehler": konto.get("fehler", ""),
                    "laeuft": profil in self._laeuft}
        if g and g["bis"] > self.uhr():
            ergebnis["geraet"] = {"code": g["code"], "url": g["url"], "bis": g["bis"]}
        return ergebnis

    @staticmethod
    def app_setzen(daten, wunsch):
        app = KontoMixin._abschnitt(daten)["app"]
        cid, geheim = str(wunsch.get("client_id") or "").strip(), str(wunsch.get("client_secret") or "").strip()
        if not cid:
            daten[SCHLUESSEL]["app"] = {}
            return {"eingerichtet": False}
        if len(cid) > 200 or len(geheim) > 200:
            raise TraktFehler("Client ID oder Secret zu lang")
        app["client_id"] = cid
        if geheim:  # leer = das gespeicherte behalten (die Oberflaeche zeigt es nie)
            app["client_secret"] = geheim
        if not app.get("client_secret"):
            raise TraktFehler("Client Secret fehlt")
        return {"eingerichtet": True}

    # --- Trakt-API ---------------------------------------------------------------------------------------------------
    def _app(self, daten):
        app = ((daten.get(SCHLUESSEL) or {}).get("app") or {}) if isinstance(daten.get(SCHLUESSEL), dict) else {}
        if not app.get("client_id") or not app.get("client_secret"):
            raise TraktFehler("Trakt ist noch nicht eingerichtet: Client ID und Secret der Trakt-App eintragen")
        return app

    def _rufen(self, methode, pfad, app, token=None, inhalt=None):
        kopf = {"Content-Type": "application/json", "trakt-api-version": "2", "trakt-api-key": app["client_id"]}
        if token:
            kopf["Authorization"] = "Bearer " + token
        try:
            status, text = self.holen(API + pfad, methode, kopf, json.dumps(inhalt) if inhalt is not None else None)
        except NetzFehler as fehler:
            raise TraktFehler("Trakt nicht erreichbar: %s" % fehler)
        try:
            daten = json.loads(text) if text and text.strip() else None
        except ValueError:
            daten = None
        return status, daten

    def _pflicht(self, methode, pfad, app, token=None, inhalt=None):
        status, daten = self._rufen(methode, pfad, app, token, inhalt)
        if status == 401:
            raise _Abgelaufen()
        if status >= 400:
            raise TraktFehler("Trakt antwortet mit HTTP %d bei %s" % (status, pfad.split("?")[0]), status)
        return daten

    # --- Verbinden per Geraete-Code ----------------------------------------------------------------------------------
    def verbinden_start(self, profil):
        app = self._app(self._daten().daten())
        status, d = self._rufen("POST", "/oauth/device/code", app, inhalt={"client_id": app["client_id"]})
        if status != 200 or not isinstance(d, dict) or not d.get("device_code"):
            raise TraktFehler("Trakt gibt keinen Code (HTTP %d) – stimmt die Client ID?" % status)
        g = {"geraet": d["device_code"], "code": str(d.get("user_code") or ""), "intervall": int(d.get("interval") or 5),
             "url": str(d.get("verification_url") or "https://trakt.tv/activate"), "bis": self.uhr() + int(d.get("expires_in") or 600)}
        self._geraete[profil] = g
        return {"code": g["code"], "url": g["url"], "bis": g["bis"], "intervall": g["intervall"]}

    def verbinden_pruefen(self, profil):
        """Hat der Nutzer den Code eingegeben? {fertig: bool, warten: bool, fehler?}"""
        g = self._geraete.get(profil)
        if not g or g["bis"] <= self.uhr():
            self._geraete.pop(profil, None)
            return {"fertig": False, "warten": False, "fehler": "Der Code ist abgelaufen – neu verbinden"}
        app = self._app(self._daten().daten())
        status, d = self._rufen("POST", "/oauth/device/token", app, inhalt={
            "code": g["geraet"], "client_id": app["client_id"], "client_secret": app["client_secret"]})
        if status in (400, 429):
            return {"fertig": False, "warten": True}
        if status != 200 or not isinstance(d, dict) or not d.get("access_token"):
            self._geraete.pop(profil, None)
            grund = {404: "Code unbekannt", 409: "Code schon benutzt", 410: "Code abgelaufen", 418: "auf Trakt abgelehnt"}
            return {"fertig": False, "warten": False, "fehler": grund.get(status, "Trakt antwortet mit HTTP %d" % status)}
        self._geraete.pop(profil, None)
        benutzer = ""
        try:
            ich = self._pflicht("GET", "/users/settings", app, d["access_token"])
            benutzer = str(((ich or {}).get("user") or {}).get("username") or "")
        except (TraktFehler, _Abgelaufen):
            pass
        self._konto_setzen(profil, lambda k: (k.clear(), k.update(self._tokens(d), benutzer=benutzer)))
        return {"fertig": True, "warten": False, "benutzer": benutzer}

    def _tokens(self, d):
        return {"access_token": str(d["access_token"]), "refresh_token": str(d.get("refresh_token") or ""),
                "ablauf": float(d.get("created_at") or self.uhr()) + float(d.get("expires_in") or 86400)}

    def _erneuern(self, profil, app, konto):
        status, d = self._rufen("POST", "/oauth/token", app, inhalt={
            "refresh_token": konto.get("refresh_token", ""), "client_id": app["client_id"],
            "client_secret": app["client_secret"], "redirect_uri": REDIRECT, "grant_type": "refresh_token"})
        if status != 200 or not isinstance(d, dict) or not d.get("access_token"):
            self._konto_setzen(profil, lambda k: k.update(access_token="", fehler="Anmeldung abgelaufen – neu verbinden"))
            raise TraktFehler("Anmeldung bei Trakt abgelaufen – neu verbinden")
        neu = self._tokens(d)
        self._konto_setzen(profil, lambda k: k.update(neu))
        return neu["access_token"]

    def trennen(self, profil):
        daten = self._daten().daten()
        konto = ((daten.get(SCHLUESSEL) or {}).get("konten") or {}).get(profil) or {}
        try:
            app = self._app(daten)
            if konto.get("access_token"):
                self._rufen("POST", "/oauth/revoke", app, inhalt={"token": konto["access_token"], "client_id": app["client_id"],
                                                                 "client_secret": app["client_secret"]})
        except TraktFehler as fehler:
            log.info("Trakt: Abmelden ohne Rueckmeldung: %s", fehler)
        self._geraete.pop(profil, None)
        self._konto_setzen(profil, lambda k: k.clear())
        return {"verbunden": False}
