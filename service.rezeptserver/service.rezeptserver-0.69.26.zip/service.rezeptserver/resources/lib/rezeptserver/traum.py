"""LocalDream: Bilder erzeugen mit Local Dream (Stable Diffusion auf dem Geraet) oder einem Bildserver im Netz.

  * Server: "Dieses Geraet" (Local Dream, http://127.0.0.1:8081) plus eigene Adressen – Local Dream auf einem anderen
    Geraet (z. B. LocalDreamHost mit --listen_all), AUTOMATIC1111, Forge oder SD.Next (/sdapi/v1).
  * Auftraege: eine Warteschlange, je Bild Fortschritt mit Zwischenbild, Abbrechen; fertige Bilder kommen in die
    Galerie (<Datenordner>/traum/galerie, PNG mit Rezept daneben). Hochskalieren (4x) ueber Local Dream oder den
    Hochskalierer des Bildservers.
  * Quellen: eingebaute (Apps, Modelle, Server-Arten, KI-Chat-Anbieter, Anleitungen) und eigene per Adresse; H0rSt
    erkennt selbst, was dahinter steckt (GitHub-Projekt mit APKs, Paket fuer das Prompt Studio, Bildserver, Seite).
  * Empfehlung: welche Local-Dream-Variante zum Prozessor passt (NPU ab Snapdragon mit Hexagon V68, SDXL ab
    Snapdragon 8 Gen 3, sonst CPU/GPU) und ob es eine fertige APK fuer die Prozessorart gibt.

Nutzerdaten "traum": {"server": [...], "aktiv": id, "quellen": [...], "chat": {...}, "hochskalierer": pfad}
"""

import collections
import os
import threading

from .netz import NetzFehler, urllib_holen
from .traum_auftraege import AuftraegeMixin
from .traum_bildserver import Automatic1111, LocalDream, server_client
from .traum_chat import ChatMixin, begriffe_aus
from .traum_galerie import GalerieMixin
from .traum_grund import *
from .traum_grund import _adresse, _anfrage, _bild_b64, _neue_id, _text, _zahl, _zugang
from .traum_quellen import QuellenMixin


class Traum(AuftraegeMixin, GalerieMixin, QuellenMixin, ChatMixin):
    """Warteschlange der Auftraege (ein Bild nach dem anderen) und die Galerie im Datenordner."""

    def __init__(self, datenordner, holen=None):
        self.ordner = os.path.join(datenordner or ".", "traum", "galerie")
        self.holen = holen or urllib_holen
        self._auftraege = collections.OrderedDict()
        self._warte = collections.deque()
        self._sperre = threading.Lock()
        self._weckruf = threading.Event()
        self._faden = None
