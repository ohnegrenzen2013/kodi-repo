"""LocalDream: Warteschlange und Ausfuehrung der Bildauftraege."""

import random
import threading
import time
import uuid

from . import traum_png
from .traum_bildserver import LocalDream, server_client
from .traum_grund import MAX_WARTEND, Abgebrochen, TraumFehler


class AuftraegeMixin:
    # Auftraege
    def auftrag_neu(self, server, wunsch, art="erzeugen", quelle="", pfad=""):
        with self._sperre:
            if len(self._warte) >= MAX_WARTEND:
                raise TraumFehler("Schon %d Aufträge in der Warteschlange" % MAX_WARTEND)
            kennung = uuid.uuid4().hex[:12]
            self._auftraege[kennung] = {"id": kennung, "art": art, "status": "wartet", "server": server, "wunsch": wunsch,
                                        "quelle": quelle, "pfad": pfad, "nr": 0, "anzahl": wunsch.get("anzahl", 1) if wunsch else 1,
                                        "schritt": 0, "schritte": wunsch.get("schritte", 0) if wunsch else 0, "vorschau": None,
                                        "vorschau_nr": 0, "bilder": [], "fehler": "", "abbrechen": False, "zeit": time.time()}
            while len(self._auftraege) > 60:  # alte, fertige vergessen
                alt = next(iter(self._auftraege))
                if self._auftraege[alt]["status"] in ("wartet", "laeuft"):
                    break
                self._auftraege.pop(alt)
            self._warte.append(kennung)
            if not self._faden or not self._faden.is_alive():
                self._faden = threading.Thread(target=self._arbeiten, name="traum", daemon=True)
                self._faden.start()
        self._weckruf.set()
        return kennung

    def auftrag(self, kennung, seit=0):
        with self._sperre:
            a = self._auftraege.get(kennung)
            if not a:
                raise TraumFehler("Auftrag unbekannt")
            platz = list(self._warte).index(kennung) + 1 if kennung in self._warte else 0
            d = {k: a[k] for k in ("id", "art", "status", "nr", "anzahl", "schritt", "schritte", "bilder", "fehler", "vorschau_nr")}
            d["platz"] = platz
            if a["vorschau"] and a["vorschau_nr"] > int(seit or 0):
                d["vorschau"] = a["vorschau"]
            return d

    def auftraege(self):
        with self._sperre:
            return [{k: a[k] for k in ("id", "art", "status", "nr", "anzahl", "schritt", "schritte", "fehler")}
                    for a in self._auftraege.values() if a["status"] in ("wartet", "laeuft")]

    def abbrechen(self, kennung):
        with self._sperre:
            a = self._auftraege.get(kennung)
            if a:
                a["abbrechen"] = True
                if a["status"] == "wartet":
                    a["status"] = "abgebrochen"
                    if kennung in self._warte:
                        self._warte.remove(kennung)

    def _arbeiten(self):
        while True:
            with self._sperre:
                kennung = self._warte.popleft() if self._warte else None
                a = self._auftraege.get(kennung) if kennung else None
                if a:
                    a["status"] = "laeuft"
            if not a:
                self._weckruf.clear()
                if not self._weckruf.wait(60):
                    with self._sperre:
                        if not self._warte:
                            self._faden = None
                            return
                continue
            try:
                if a["art"] == "hochskalieren":
                    self._hochskalieren(a)
                else:
                    self._erzeugen(a)
                a["status"] = "abgebrochen" if a["abbrechen"] else "fertig"
            except Abgebrochen:
                a["status"] = "abgebrochen"
            except (TraumFehler, traum_png.PngFehler, ValueError, KeyError, OSError) as f:
                a["status"], a["fehler"] = "fehler", str(f)

    def _erzeugen(self, a):
        w, client = a["wunsch"], server_client(a["server"])
        start = w["seed"] if w["seed"] >= 0 else random.randrange(2 ** 31)
        for i in range(w["anzahl"]):
            if a["abbrechen"]:
                raise Abgebrochen()
            a["nr"], a["schritt"] = i + 1, 0
            einzeln = dict(w, seed=(start + i * 7919) % (2 ** 32))  # wie im Vorbild: Seeds um 7919 versetzt

            def fortschritt(schritt, schritte, vorschau):
                a["schritt"], a["schritte"] = int(schritt or 0), int(schritte or 0)
                if vorschau:
                    a["vorschau"] = vorschau if str(vorschau).startswith("data:") else "data:image/jpeg;base64," + vorschau
                    a["vorschau_nr"] += 1
            for bild, info in client.erzeugen(einzeln, fortschritt, lambda: a["abbrechen"]):
                rezept = {k: einzeln[k] for k in ("prompt", "negativ", "schritte", "cfg", "sampler", "breite", "hoehe", "vorgabe", "staerke",
                                                  "ultrafix", "tile_size", "modell")}
                rezept.update(seed=info.get("seed", einzeln["seed"]), server=a["server"]["name"], art=a["server"]["art"],
                              img2img=bool(einzeln["bild"]), referenzen=len(einzeln.get("referenzen") or []),
                              dauer_ms=info.get("dauer_ms"), zeit=int(time.time()))
                a["bilder"].append(self.speichern(bild, ".jpg" if bild[:2] == b"\xff\xd8" else ".png", rezept))

    def _hochskalieren(self, a):
        quelle = self.pfad(a["quelle"])
        with open(quelle, "rb") as f:
            png = f.read()
        if not png.startswith(traum_png.KENNUNG):
            raise TraumFehler("Hochskalieren geht nur mit PNG-Bildern aus der Galerie")
        client = server_client(a["server"])
        a["nr"], a["anzahl"] = 1, 1
        if isinstance(client, LocalDream) and not a["pfad"]:
            raise TraumFehler("Pfad des Hochskalierers fehlt (Local Dream → „Hochskalierer suchen“)")
        bild, endung = client.hochskalieren(png, a["pfad"], a["wunsch"].get("opencl") if a["wunsch"] else False)
        rezept = self.rezept(a["quelle"])
        rezept.update(hochskaliert=True, quelle=a["quelle"], zeit=int(time.time()))
        a["bilder"].append(self.speichern(bild, endung, rezept))
