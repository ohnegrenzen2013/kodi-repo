"""LocalDream: Bildserver-Clients fuer Local Dream und AUTOMATIC1111/Forge/SD.Next."""

import base64
import json
import threading
import urllib.error
import urllib.request

from . import __version__, traum_png
from .traum_grund import SAMPLER_LD, Abgebrochen, TraumFehler, _anfrage, _zugang, _mit_port, vorgabe_groesse


# --- Bildserver -------------------------------------------------------------------------------------------------
class LocalDream:
    """Local Dream: POST /generate (Fortschritt als Server-Sent Events), POST /upscale, GET /health."""

    def __init__(self, server):
        self.basis = server["adresse"]
        self.kopf = _zugang(server)

    def tokenize(self, prompt):
        status, inhalt, _ = _anfrage(self.basis + "/tokenize", daten=json.dumps({"prompt": prompt}), kopf=self.kopf, zeit=10)
        if status >= 400:
            raise TraumFehler("Token-Zählung: HTTP %d" % status)
        try:
            return json.loads(inhalt.decode("utf-8") or "{}")
        except ValueError:
            raise TraumFehler("Token-Zählung: keine JSON-Antwort")

    def pruefen(self):
        status, _, _ = _anfrage(self.basis + "/health", kopf=self.kopf, zeit=5)
        if status != 200:
            raise TraumFehler("Local Dream antwortet nicht (HTTP %d). In der App ein Modell laden – dann läuft der Server." % status)
        return {"ok": True, "art": "localdream", "sampler": SAMPLER_LD, "text": "Local Dream läuft."}

    def erzeugen(self, w, fortschritt, abbruch):
        schritte, staerke = w["schritte"], w["staerke"]
        prompt, negativ = w["prompt"], w["negativ"]
        if w.get("ultrafix"):
            schritte = w.get("ultrafix_steps") or schritte
            staerke = max(0.0, min(1.0, (w.get("ultrafix_denoise_steps", 4) - 0.5) / max(1, schritte)))
            if w.get("ultrafix_quality_denoise", True):
                prompt, negativ = "masterpiece, best quality, 4k resolution", ""
        anfrage = {"prompt": prompt, "negative_prompt": negativ, "steps": schritte, "cfg": w["cfg"], "seed": w["seed"],
                   "scheduler": w["sampler"] or "dpm", "use_opencl": w["opencl"], "show_diffusion_process": w["zwischenbilder"],
                   "show_diffusion_stride": w.get("vorschau_stride") or 2, "preview_format": "jpeg",
                   "output_format": w.get("output_format") or "png"}
        if w.get("aspect_ratio"):
            anfrage["aspect_ratio"] = w["aspect_ratio"]
        if w.get("lowram"):
            anfrage["lowram"] = True
        if w.get("seq_dit"):
            anfrage["seq_dit"] = True
        if w.get("patch"):
            anfrage["patch"] = w["patch"]
        if w["vorgabe"]:
            anfrage["width"], anfrage["height"] = vorgabe_groesse(w["vorgabe"], w["breite"], w["hoehe"])
        else:
            anfrage["width"], anfrage["height"] = w["breite"], w["hoehe"]
        if w.get("ultrafix"):
            anfrage["ultrafix"] = True
            anfrage["tile_size"] = w.get("tile_size") or 512
        if w.get("referenzen"):
            anfrage["reference_images"] = w["referenzen"]
        if w["bild"]:
            anfrage["image"] = w["bild"]
            anfrage["denoise_strength"] = staerke
            if w["maske"]:
                anfrage["mask"] = w["maske"]
        k = dict(self.kopf, **{"Content-Type": "application/json", "Accept": "text/event-stream", "User-Agent": "H0rSt/" + __version__})
        try:
            antwort = urllib.request.urlopen(urllib.request.Request(self.basis + "/generate", data=json.dumps(anfrage).encode("utf-8"),
                                                                    headers=k), timeout=300)
        except urllib.error.HTTPError as fehler:
            text = fehler.read(4096).decode("utf-8", "replace")
            fehler.close()
            try:
                text = json.loads(text)["error"]["message"]
            except (ValueError, KeyError, TypeError):
                pass
            raise TraumFehler("Local Dream: %s" % text)
        except (urllib.error.URLError, OSError) as fehler:
            raise TraumFehler("Local Dream nicht erreichbar (%s). Läuft die App mit geladenem Modell?" % getattr(fehler, "reason", fehler))
        with antwort:
            ereignis, zeilen = "", []
            while True:
                if abbruch():
                    raise Abgebrochen()  # Verbindung zu: Local Dream bricht das Bild selbst ab
                zeile = antwort.readline()
                if not zeile:
                    raise TraumFehler("Local Dream hat die Verbindung beendet")
                zeile = zeile.decode("utf-8", "replace").rstrip("\r\n")
                if zeile.startswith("event:"):
                    ereignis = zeile[6:].strip()
                elif zeile.startswith("data:"):
                    zeilen.append(zeile[5:].strip())
                elif not zeile and zeilen:
                    try:
                        d = json.loads("".join(zeilen))
                    except ValueError:
                        d = {}
                    zeilen = []
                    art = d.get("type") or ereignis
                    if art == "progress":
                        fortschritt(d.get("step", 0), d.get("total_steps", w["schritte"]), d.get("image") if d.get("format") == "jpeg" else None)
                    elif art == "complete":
                        bild = base64.b64decode(d.get("image") or "")
                        if str(d.get("format") or "").lower() == "raw":
                            bild = traum_png.kodieren(int(d["width"]), int(d["height"]), bild[:int(d["width"]) * int(d["height"]) * 3])
                        return [(bild, {"seed": d.get("seed", w["seed"]), "dauer_ms": d.get("generation_time_ms")})]
                    elif art == "error":
                        raise TraumFehler("Local Dream: %s" % (d.get("message") or "Fehler"))

    def hochskalieren(self, png, pfad, opencl=False):
        breite, hoehe, rgb = traum_png.dekodieren(png)
        status, inhalt, kopf = _anfrage(self.basis + "/upscale", daten=rgb, zeit=600, kopf=dict(self.kopf, **{
            "Content-Type": "application/octet-stream", "X-Image-Width": str(breite), "X-Image-Height": str(hoehe),
            "X-Upscaler-Path": pfad, "X-Use-OpenCL": "true" if opencl else "false"}))
        if status != 200 or inhalt[:2] != b"\xff\xd8":
            raise TraumFehler("Hochskalieren: %s" % inhalt[:300].decode("utf-8", "replace"))
        return inhalt, ".jpg"


class Automatic1111:
    """AUTOMATIC1111, Forge, SD.Next: /sdapi/v1 (txt2img, img2img, progress, interrupt, extra-single-image)."""

    def __init__(self, server):
        self.basis = server["adresse"]
        self.kopf = _zugang(server)

    def _json(self, pfad, daten=None, zeit=30, methode=None):
        status, inhalt, _ = _anfrage(self.basis + pfad, daten=daten, kopf=self.kopf, zeit=zeit, methode=methode)
        if status == 401:
            raise TraumFehler("Der Bildserver will einen Zugang (Benutzer:Passwort).")
        if status >= 400:
            raise TraumFehler("Bildserver: HTTP %d %s" % (status, inhalt[:200].decode("utf-8", "replace")))
        try:
            return json.loads(inhalt.decode("utf-8") or "null")
        except ValueError:
            raise TraumFehler("Bildserver: keine JSON-Antwort – mit --api gestartet?")

    def pruefen(self):
        sampler = [[s["name"], s["name"]] for s in self._json("/sdapi/v1/samplers", zeit=10) or [] if isinstance(s, dict)]
        modelle = [m.get("title") for m in self._json("/sdapi/v1/sd-models", zeit=10) or [] if isinstance(m, dict)]
        hoch = [u.get("name") for u in self._json("/sdapi/v1/upscalers", zeit=10) or [] if isinstance(u, dict) and u.get("name") != "None"]
        aktiv = (self._json("/sdapi/v1/options", zeit=10) or {}).get("sd_model_checkpoint", "")
        return {"ok": True, "art": "a1111", "sampler": sampler, "modelle": modelle, "modell": aktiv, "hochskalierer": hoch,
                "text": "Bildserver läuft · %d Modelle" % len(modelle)}

    def modell(self, name):
        self._json("/sdapi/v1/options", {"sd_model_checkpoint": name}, zeit=300)

    def erzeugen(self, w, fortschritt, abbruch):
        anfrage = {"prompt": w["prompt"], "negative_prompt": w["negativ"], "steps": w["schritte"], "cfg_scale": w["cfg"], "seed": w["seed"],
                   "sampler_name": w["sampler"] or "Euler a", "width": w["breite"], "height": w["hoehe"], "batch_size": 1, "n_iter": 1,
                   "send_images": True, "save_images": False}
        pfad = "/sdapi/v1/txt2img"
        if w["bild"]:
            anfrage.update({"init_images": [w["bild"]], "denoising_strength": w["staerke"]})
            if w["maske"]:
                anfrage["mask"] = w["maske"]
            pfad = "/sdapi/v1/img2img"
        ergebnis = {}

        def los():
            try:
                ergebnis["d"] = self._json(pfad, anfrage, zeit=1800)
            except TraumFehler as f:
                ergebnis["f"] = f
        faden = threading.Thread(target=los, daemon=True)
        faden.start()
        while faden.is_alive():
            faden.join(1.0)
            if abbruch():
                try:
                    self._json("/sdapi/v1/interrupt", {}, zeit=10)
                finally:
                    raise Abgebrochen()
            try:
                p = self._json("/sdapi/v1/progress?skip_current_image=false", zeit=5) or {}
                s = p.get("state") or {}
                fortschritt(s.get("sampling_step", 0), s.get("sampling_steps") or w["schritte"], p.get("current_image"))
            except TraumFehler:
                pass
        if "f" in ergebnis:
            raise ergebnis["f"]
        d = ergebnis.get("d") or {}
        try:
            info = json.loads(d.get("info") or "{}")
        except ValueError:
            info = {}
        return [(base64.b64decode(b.split(",", 1)[-1]), {"seed": info.get("seed", w["seed"])}) for b in d.get("images") or []][:1]

    def hochskalieren(self, png, name, opencl=False):
        d = self._json("/sdapi/v1/extra-single-image", {"image": base64.b64encode(png).decode("ascii"), "upscaler_1": name or "R-ESRGAN 4x+",
                                                         "upscaling_resize": 4}, zeit=900)
        return base64.b64decode(d.get("image") or ""), ".png"


class LocalDreamHost:
    """Local Dream v3 im Host-Modus: Steuerport (Modelle, Auswahl, Status) + Bildport fuer /generate."""

    def __init__(self, server):
        self.server = server
        self.control = str(server["adresse"]).rstrip("/")
        self.generation = str(server.get("generation") or _mit_port(self.control, 8081)).rstrip("/")
        self.kopf = _zugang(server)

    def _json(self, pfad, daten=None, zeit=15):
        status, inhalt, _ = _anfrage(self.control + pfad, daten=daten, kopf=self.kopf, zeit=zeit)
        if status >= 400:
            raise TraumFehler("Local Dream Host: HTTP %d" % status)
        try:
            return json.loads(inhalt.decode("utf-8") or "null")
        except ValueError:
            raise TraumFehler("Local Dream Host: keine JSON-Antwort")

    def info(self):
        return self._json("/info")

    def modelle(self):
        d = self._json("/models") or {}
        return {"modelle": d.get("models") or [], "hochskalierer": d.get("upscalers") or [], "img2img": d.get("use_img2img", True)}

    def status(self):
        return self._json("/status") or {}

    def waehlen(self, modell, breite=1024, hoehe=1024):
        return self._json("/select", {"model_id": modell, "width": int(breite), "height": int(hoehe)}, zeit=30)

    def stoppen(self, modell=""):
        return self._json("/stop", {"model_id": modell}, zeit=15)

    def tokenize(self, prompt):
        import urllib.request
        try:
            with urllib.request.urlopen(urllib.request.Request(self.generation + "/tokenize", data=json.dumps({"prompt": prompt}).encode("utf-8"),
                                                               headers=dict(self.kopf, **{"Content-Type": "application/json"})), timeout=10) as a:
                return json.loads(a.read().decode("utf-8"))
        except (urllib.error.URLError, OSError, ValueError) as fehler:
            raise TraumFehler("Token-Zählung nicht erreichbar: %s" % fehler)

    def pruefen(self):
        info = self.info()
        if str(info.get("app") or "") != "localdream":
            raise TraumFehler("Kein Local Dream Host unter %s" % self.control)
        d = self.modelle()
        return {"ok": True, "art": "localdream", "host": True, "info": info, "modelle": d["modelle"],
                "hochskalierer": [u.get("path") for u in d["hochskalierer"] if u.get("path")], "status": self.status(),
                "text": "Local Dream Host %s · %d Modelle" % (info.get("device") or "", len(d["modelle"]))}

    def erzeugen(self, w, fortschritt, abbruch):
        status = self.status()
        modell = w.get("modell") or status.get("serving_model_id") or ""
        if modell:
            breite, hoehe = vorgabe_groesse(w["vorgabe"], w["breite"], w["hoehe"]) if w.get("vorgabe") else (w["breite"], w["hoehe"])
            if status.get("serving_model_id") != modell or status.get("width") != breite or status.get("height") != hoehe:
                self.waehlen(modell, breite, hoehe)
                for _ in range(60):
                    if abbruch():
                        raise Abgebrochen()
                    s = self.status()
                    if s.get("state") == "running" and s.get("serving_model_id") == modell:
                        break
                    if s.get("state") == "error":
                        raise TraumFehler("Local Dream Host: %s" % (s.get("message") or "Modell startet nicht"))
                    import time
                    time.sleep(0.5)
        return LocalDream(dict(self.server, adresse=self.generation)).erzeugen(w, fortschritt, abbruch)

    def hochskalieren(self, png, pfad, opencl=False):
        return LocalDream(dict(self.server, adresse=self.generation)).hochskalieren(png, pfad, opencl)


def server_client(server):
    if server.get("host"):
        return LocalDreamHost(server)
    return LocalDream(server) if server["art"] == "localdream" else Automatic1111(server)
