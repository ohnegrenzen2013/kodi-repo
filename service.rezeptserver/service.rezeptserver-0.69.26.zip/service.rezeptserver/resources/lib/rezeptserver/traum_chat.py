"""LocalDream: KI-Chat fuer Prompts und Begriffe aus der Antwort."""

import json
import re

from . import traum_studio
from .traum_grund import CHAT_ANWEISUNG, TraumFehler, _anfrage


class ChatMixin:
    # KI-Chat
    def chat(self, einstellung, nachrichten):
        basis, modell = einstellung.get("basis") or "", einstellung.get("modell") or ""
        if not basis or not modell:
            raise TraumFehler("Erst Anbieter, Adresse und Modell für den KI-Chat eintragen")
        verlauf = [{"role": "system", "content": CHAT_ANWEISUNG}]
        for n in (nachrichten or [])[-12:]:
            if isinstance(n, dict) and n.get("role") in ("user", "assistant") and isinstance(n.get("content"), str):
                verlauf.append({"role": n["role"], "content": n["content"][:4000]})
        kopf = {"Authorization": "Bearer " + einstellung["schluessel"]} if einstellung.get("schluessel") else {}
        status, inhalt, _ = _anfrage(basis.rstrip("/") + "/chat/completions", {"model": modell, "messages": verlauf, "temperature": 0.8},
                                     kopf=kopf, zeit=120)
        try:
            d = json.loads(inhalt.decode("utf-8"))
        except ValueError:
            d = {}
        if status >= 400:
            meldung = (d.get("error") or {}).get("message") if isinstance(d.get("error"), dict) else d.get("error")
            raise TraumFehler("KI-Chat: HTTP %d %s" % (status, meldung or ""))
        try:
            text = d["choices"][0]["message"]["content"]
        except (KeyError, IndexError, TypeError):
            raise TraumFehler("KI-Chat: unerwartete Antwort")
        return {"antwort": text, "begriffe": begriffe_aus(text)}


def begriffe_aus(text):
    """Englische Danbooru-Begriffe aus einer KI-Antwort (Code-Bloecke und Saetze fallen weg); gesperrte fliegen raus."""
    text = re.sub(r"```\w*", "", str(text or ""))
    kandidaten = []
    for zeile in text.splitlines():
        if zeile.count(",") >= 2:
            kandidaten += [t.strip(" .`*-\"'") for t in zeile.split(",")]
    begriffe = [t for t in kandidaten if t and len(t) <= 50 and re.match(r"^[\w\s().:'-]+$", t) and not re.search(r"[äöüÄÖÜß]", t)]
    return traum_studio.sperren(list(dict.fromkeys(begriffe)))[:40]
