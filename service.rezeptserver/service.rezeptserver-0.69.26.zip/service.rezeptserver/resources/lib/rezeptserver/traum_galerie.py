"""LocalDream: Galerie, Rezepte und Hochskalierer-Pfade."""

import json
import os
import re
import time
import uuid

from . import traum_png
from .traum_bildserver import LocalDream
from .traum_grund import HOCHSKALIERER_IDS, HOCHSKALIERER_ORDNER, MAX_GALERIE, TraumFehler


class GalerieMixin:
    def hochskalierer_suchen(self, server, opencl=False):
        """Die ueblichen Pfade der Local-Dream-Hochskalierer mit einem winzigen Bild ausprobieren."""
        client = LocalDream(server)
        test = traum_png.kodieren(8, 8, bytes([128, 160, 200]) * 64)
        gefunden, fehler = [], ""
        for ordner in HOCHSKALIERER_ORDNER:
            for kennung in HOCHSKALIERER_IDS:
                pfad = ordner + "/models/" + kennung + "/upscaler.bin"
                try:
                    client.hochskalieren(test, pfad, opencl)
                    gefunden.append(pfad)
                except TraumFehler as f:
                    fehler = str(f)
                    if "nicht erreichbar" in fehler:
                        raise
        return {"pfade": gefunden, "fehler": "" if gefunden else fehler}

    # Galerie
    def speichern(self, bild, endung, rezept):
        os.makedirs(self.ordner, exist_ok=True)
        name = time.strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:6] + endung
        with open(os.path.join(self.ordner, name), "wb") as f:
            f.write(bild)
        breite, hoehe = traum_png.groesse(bild)
        rezept = dict(rezept, breite=breite or rezept.get("breite"), hoehe=hoehe or rezept.get("hoehe"))
        with open(os.path.join(self.ordner, name + ".json"), "w", encoding="utf-8") as f:
            json.dump(rezept, f, ensure_ascii=False)
        self._aufraeumen()
        return name

    def _aufraeumen(self):
        bilder = sorted(n for n in os.listdir(self.ordner) if re.match(r"^[\w.-]+\.(png|jpg)$", n))
        for alt in bilder[:-MAX_GALERIE] if len(bilder) > MAX_GALERIE else []:
            self.weg(alt)

    def pfad(self, name):
        if not re.match(r"^[\w.-]+\.(png|jpg)$", str(name or "")):
            raise TraumFehler("Unbekanntes Bild")
        pfad = os.path.join(self.ordner, name)
        if not os.path.isfile(pfad):
            raise TraumFehler("Bild nicht da")
        return pfad

    def rezept(self, name):
        try:
            with open(self.pfad(name) + ".json", encoding="utf-8") as f:
                return json.load(f)
        except (OSError, ValueError):
            return {}

    def galerie(self):
        if not os.path.isdir(self.ordner):
            return []
        namen = sorted((n for n in os.listdir(self.ordner) if re.match(r"^[\w.-]+\.(png|jpg)$", n)), reverse=True)
        return [dict(self.rezept(n), name=n) for n in namen]

    def weg(self, name):
        pfad = self.pfad(name)
        for p in (pfad, pfad + ".json"):
            try:
                os.remove(p)
            except OSError:
                pass
