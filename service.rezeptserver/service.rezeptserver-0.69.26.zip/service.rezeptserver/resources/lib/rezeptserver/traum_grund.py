"""LocalDream: Konstanten, Nutzerdaten, Prozessor-Empfehlung, Netz und Wunschpruefung."""

import base64
import json
import re
import urllib.error
import urllib.request
import uuid
from urllib.parse import urlsplit

from . import __version__, traum_studio

SCHLUESSEL = "traum"
GERAET = {"id": "geraet", "name": "Dieses Gerät (Local Dream)", "art": "localdream", "adresse": "http://127.0.0.1:8081", "fest": True}
LD_KONTROLLE = "http://127.0.0.1:8808"  # Local Dream v3: Steuerport (Modelle/Status) neben dem Bildport 8081
ARTEN = {"localdream": "Local Dream", "a1111": "AUTOMATIC1111 / Forge / SD.Next"}
SAMPLER_LD = [["dpm", "DPM++ 2M"], ["dpm_karras", "DPM++ 2M Karras"], ["dpm_sde", "DPM++ SDE"], ["dpm_sde_karras", "DPM++ SDE Karras"],
              ["euler_a", "Euler a"], ["euler_a_karras", "Euler a Karras"], ["euler", "Euler"], ["euler_karras", "Euler Karras"], ["lcm", "LCM (schnelle Modelle)"]]
# Local Dream legt die Hochskalierer hier ab (wie im Vorbild Prompt Studio): <Ordner>/models/<id>/upscaler.bin
HOCHSKALIERER_ORDNER = ["/data/data/io.github.xororz.localdream/files", "/storage/emulated/0/Android/data/io.github.xororz.localdream/files",
                        "/storage/emulated/0/Download/LocalDream", "/sdcard/Download/LocalDream", "/storage/emulated/0/Android/media/io.github.xororz.localdream"]
HOCHSKALIERER_IDS = ["upscaler_anime", "upscaler_realistic"]
LD_PAKET = "io.github.xororz.localdream"
LD_REPO = "xororz/local-dream"
LD_VERSION = "v3.0.0-alpha.7"
LD_APK = "https://github.com/xororz/local-dream/releases/download/v3.0.0-alpha.7/LocalDream_armv8a_3.0.0-alpha.7.apk"
LD_APK_FILTER = "https://github.com/xororz/local-dream/releases/download/v3.0.0-alpha.7/LocalDream_armv8a_3.0.0-alpha.7_with_filter.apk"
PS_REPO = "justsmile3/PromptGenerator"
PS_PAKET = "com.promptgen.app"
PS_APK = "https://raw.githubusercontent.com/justsmile3/PromptGenerator/main/releases/PromptGenerator-v3.7.apk"
MAX_SERVER = 20
MAX_QUELLEN = 100
MAX_GALERIE = 500
MAX_WARTEND = 20
MAX_PAKET = 400 * 1024

# Eingebaute Quellen: was es fuer Prompt Studio und Local Dream gibt (eigene kommen per Adresse dazu)
QUELLEN = [
    {"id": "localdream", "art": "app", "name": "Local Dream (xororz)", "url": "https://github.com/xororz/local-dream",
     "text": "Die App: Stable Diffusion auf dem Gerät – NPU (Snapdragon), CPU oder GPU. Fertige APKs für arm64, mit oder ohne Bildfilter."},
    {"id": "localdreamhost", "art": "quelltext", "name": "Local Dream Host (AIExperimentsKooth)", "url": "https://github.com/AIExperimentsKooth/LocalDreamHost",
     "text": "Abwandlung von Local Dream mit Warteschlange (/queue/generate, /stream/<id>) und Auflösungs-Vorgaben. Mit --listen_all "
             "von anderen Geräten erreichbar – dann hier als Server eintragen. Nur Quelltext, keine fertigen APKs."},
    {"id": "promptstudio", "art": "app", "name": "SD Prompt Studio 3.7 (justsmile3)", "url": "https://github.com/justsmile3/PromptGenerator",
     "text": "Die eigenständige Prompt-Studio-App (MIT): 4.000+ Danbooru-Begriffe, Szenen-Logik, KI-Chat, LocalDream-Anbindung. "
             "Hier direkt installieren (Android) – H0rSts Prompt Studio bleibt zusätzlich erhalten."},
    {"id": "ldanleitung", "art": "anleitung", "name": "Anleitung zu Local Dream", "url": "https://ld-guide.chino.icu",
     "text": "Modelle laden, eigene Modelle umwandeln, NPU oder CPU wählen."},
    {"id": "hf", "art": "modelle", "name": "Modelle für Local Dream (Hugging Face)", "url": "https://huggingface.co/xororz",
     "text": "Fertig umgewandelte SD-1.5- und SDXL-Modelle; Local Dream lädt sie in der App."},
    {"id": "civitai", "art": "modelle", "name": "Civitai", "url": "https://civitai.com/models",
     "text": "Modelle und LoRAs für SD 1.5 und SDXL (für Local Dream erst umwandeln, für Forge & Co. direkt)."},
    {"id": "a1111", "art": "server", "name": "AUTOMATIC1111 Web UI", "url": "https://github.com/AUTOMATIC1111/stable-diffusion-webui",
     "text": "Bildserver für PC; mit --api --listen starten, dann seine Adresse als Server eintragen."},
    {"id": "forge", "art": "server", "name": "Stable Diffusion WebUI Forge", "url": "https://github.com/lllyasviel/stable-diffusion-webui-forge",
     "text": "Schnellere Abwandlung von AUTOMATIC1111, gleiche Schnittstelle."},
    {"id": "sdnext", "art": "server", "name": "SD.Next", "url": "https://github.com/vladmandic/sdnext", "text": "Gleiche Schnittstelle (/sdapi/v1)."},
    {"id": "comfyui", "art": "quelltext", "name": "ComfyUI (freie Video- und Bildmodelle)", "url": "https://github.com/comfyanonymous/ComfyUI",
     "text": "Knoten-Werkstatt für Wan, Hunyuan, LTX und SDXL. Mit --listen starten, dann im Portal als Reiter öffnen; "
             "H0rSt erkennt die Oberfläche auf Port 8188."},
    {"id": "wan2gp", "art": "quelltext", "name": "Wan2GP (lokale Videomodelle)", "url": "https://github.com/deepbeepmeep/Wan2GP",
     "text": "Wan 2.x, Hunyuan und LTX auf NVIDIA/AMD, ohne Cloud. H0rSt erkennt die Oberfläche auf Port 7860 im Portal."},
    {"id": "locallyuncensored", "art": "quelltext", "name": "Locally Uncensored (Chat, Bild und Video)", "url": "https://github.com/PurpleDoubleD/locally-uncensored",
     "text": "Freies lokales Studio (AGPL-3.0); Chat über die lokale API (Port 8129), Video und Bild über ComfyUI. "
             "Die Remote-Oberfläche auf Port 11435 lässt sich als Portal-Reiter einbinden."},
    {"id": "opengenerativeai", "art": "quelltext", "name": "Open Generative AI (Studio-Frontend)", "url": "https://github.com/Anil-matcha/Open-Generative-AI",
     "text": "Offenes Next.js- und Electron-Studio (MIT); die Modelle laufen über Muapi und brauchen einen API-Schlüssel. "
             "Lokale Video-Modelle nur in der Desktop-App über Wan2GP."},
    {"id": "modeltonpu", "art": "quelltext", "name": "Model-To-NPU (SDXL auf Snapdragon)", "url": "https://github.com/VitalikDen0/Model-To-NPU",
     "text": "SDXL nativ auf der Hexagon-NPU (Snapdragon 8 Elite), WAN-2.1-Workspace, APK ohne Root oder Termux. "
             "Nur für passende Qualcomm-Geräte, keine allgemeine Server-Schnittstelle."},
    {"id": "danbooru", "art": "anleitung", "name": "Danbooru-Begriffe", "url": "https://danbooru.donmai.us/wiki_pages/tag_groups",
     "text": "Die Begriffe, die Anime-Modelle verstehen, nach Gruppen."},
]
# KI-Chat (OpenAI-kompatibel): schreibt Prompts aus einer Beschreibung; der Schluessel bleibt auf dem Server
CHAT_ANBIETER = [
    {"id": "groq", "name": "Groq (kostenlos, sehr schnell)", "basis": "https://api.groq.com/openai/v1", "modell": "llama-3.3-70b-versatile",
     "schluessel_url": "https://console.groq.com/keys"},
    {"id": "gemini", "name": "Google Gemini (großzügig kostenlos)", "basis": "https://generativelanguage.googleapis.com/v1beta/openai",
     "modell": "gemini-2.0-flash", "schluessel_url": "https://aistudio.google.com/app/apikey"},
    {"id": "openrouter", "name": "OpenRouter (Modelle mit :free)", "basis": "https://openrouter.ai/api/v1",
     "modell": "meta-llama/llama-3.3-70b-instruct:free", "schluessel_url": "https://openrouter.ai/keys"},
    {"id": "mistral", "name": "Mistral (EU)", "basis": "https://api.mistral.ai/v1", "modell": "mistral-small-latest",
     "schluessel_url": "https://console.mistral.ai/api-keys"},
    {"id": "siliconflow", "name": "SiliconFlow (Registrierung schenkt Guthaben)", "basis": "https://api.siliconflow.cn/v1",
     "modell": "Qwen/Qwen2.5-7B-Instruct", "schluessel_url": "https://cloud.siliconflow.cn/account/ak"},
    {"id": "zhipu", "name": "Zhipu GLM (glm-4-flash kostenlos)", "basis": "https://open.bigmodel.cn/api/paas/v4",
     "modell": "glm-4-flash", "schluessel_url": "https://open.bigmodel.cn/usercenter/apikeys"},
    {"id": "moonshot", "name": "Moonshot Kimi", "basis": "https://api.moonshot.cn/v1", "modell": "moonshot-v1-8k",
     "schluessel_url": "https://platform.moonshot.cn/console/api-keys"},
    {"id": "dashscope", "name": "Alibaba Bailian (kostenloses Kontingent)", "basis": "https://dashscope.aliyuncs.com/compatible-mode/v1",
     "modell": "qwen-turbo", "schluessel_url": "https://bailian.console.aliyun.com/"},
    {"id": "deepseek", "name": "DeepSeek", "basis": "https://api.deepseek.com/v1", "modell": "deepseek-chat",
     "schluessel_url": "https://platform.deepseek.com/api_keys"},
    {"id": "openai", "name": "OpenAI", "basis": "https://api.openai.com/v1", "modell": "gpt-4o-mini", "schluessel_url": "https://platform.openai.com/api-keys"},
    {"id": "ollama", "name": "Ollama (im Heimnetz, ohne Schlüssel)", "basis": "http://127.0.0.1:11434/v1", "modell": "llama3.2", "schluessel_url": ""},
    {"id": "opencode", "name": "OpenCode Zen (API-Key; Free nur im OpenCode-Client)", "basis": "https://opencode.ai/inference/openai/v1",
     "modell": "kimi-k2.6", "schluessel_url": "https://opencode.ai/console"},
    {"id": "locallyuncensored", "name": "Locally Uncensored (LAN, Port 8129)", "basis": "http://127.0.0.1:8129/v1", "modell": "",
     "schluessel_url": ""},
    {"id": "eigen", "name": "Eigener Anbieter (OpenAI-kompatibel)", "basis": "", "modell": "", "schluessel_url": ""},
]
CHAT_ANWEISUNG = ("Du schreibst Prompts für Stable Diffusion 1.5 (Anime-Modelle). Antworte nur mit einer Zeile englischer "
                  "Danbooru-Begriffe, durch Kommas getrennt, höchstens 30 Begriffe, Qualitätsbegriffe zuerst. Keine Erklärungen. "
                  "Nur jugendfreie Inhalte; keine Nacktheit, keine sexuellen Inhalte, keine Kinder in irgendeinem anzüglichen Zusammenhang.")

# Hexagon-Version je Snapdragon (Build.SOC_MODEL); Local Dream braucht fuer SD 1.5 auf der NPU V68+, fuer SDXL 8 Gen 3+
HEXAGON = {"SM8350": 68, "SM7325": 68, "SM7350": 68, "SM8450": 69, "SM8475": 69, "SM7450": 69, "SM7475": 69, "SM8550": 73,
           "SM7550": 73, "SM8635": 73, "SM7675": 73, "SM8650": 75, "SM8750": 79, "SM8850": 81}
SNAPDRAGON_NAMEN = {"SM8350": "Snapdragon 888", "SM7325": "Snapdragon 778G", "SM7350": "Snapdragon 780G", "SM8450": "Snapdragon 8 Gen 1",
                    "SM8475": "Snapdragon 8+ Gen 1", "SM7450": "Snapdragon 7 Gen 1", "SM7475": "Snapdragon 7+ Gen 2", "SM8550": "Snapdragon 8 Gen 2",
                    "SM7550": "Snapdragon 7 Gen 3", "SM8635": "Snapdragon 8s Gen 3", "SM7675": "Snapdragon 7+ Gen 3", "SM8650": "Snapdragon 8 Gen 3",
                    "SM8750": "Snapdragon 8 Elite", "SM8850": "Snapdragon 8 Elite Gen 5"}


class TraumFehler(ValueError):
    pass


# --- Nutzerdaten ------------------------------------------------------------------------------------------------
def _text(wert, laenge):
    return " ".join(str(wert or "").split())[:laenge]


def _mit_port(url, port):
    teile = urlsplit(str(url or ""))
    host = teile.hostname or ""
    if ":" in host:  # IPv6
        host = "[" + host + "]"
    return "%s://%s:%d%s" % (teile.scheme or "http", host, int(port), teile.path or "")


def vorgabe_groesse(vorgabe, breite, hoehe):
    """Alte Local-Dream-Groessen (v2) in echte width/height uebersetzen; v3 kennt kein preset_resolution."""
    vorgabe = str(vorgabe or "")
    if vorgabe in ("512", "768", "1024"):
        return int(vorgabe), int(vorgabe)
    return {"square": (1024, 1024), "portrait": (768, 1024), "landscape": (1024, 768)}.get(vorgabe, (breite, hoehe))


def _adresse(wert):
    url = str(wert or "").strip().rstrip("/")
    if not re.match(r"^https?://", url):
        url = "http://" + url
    teile = urlsplit(url)
    if teile.scheme not in ("http", "https") or not teile.hostname:
        raise TraumFehler("Adresse wie http://192.168.1.20:8081 erwartet")
    return url[:300]


def _neue_id(text):
    return (re.sub(r"[^a-z0-9]+", "-", str(text).lower()).strip("-")[:24] or "eintrag") + "-" + uuid.uuid4().hex[:6]


def pruefe(roh):
    """Gespeicherte Werte; kaputte Eintraege fallen weg. Der Server "Dieses Geraet" ist immer dabei."""
    roh = roh if isinstance(roh, dict) else {}
    server = [dict(GERAET)]
    for s in roh.get("server") or []:
        try:
            if not isinstance(s, dict) or s.get("id") == GERAET["id"] or s.get("art") not in ARTEN:
                continue
            eintrag = {"id": _text(s.get("id"), 40) or _neue_id(s.get("name")), "name": _text(s.get("name"), 60) or "Server",
                       "art": s["art"], "adresse": _adresse(s.get("adresse")), "zugang": _text(s.get("zugang"), 200)}
            if s.get("host") is True:  # LocalDreamHost/Remote-Host: Steuerport + Bildport
                eintrag["host"] = True
                eintrag["generation"] = _adresse(s.get("generation")) if s.get("generation") else _mit_port(eintrag["adresse"], 8081)
            server.append(eintrag)
        except TraumFehler:
            continue
    quellen = []
    for q in roh.get("quellen") or []:
        if isinstance(q, dict) and q.get("url") and q.get("art"):
            eintrag = {"id": _text(q.get("id"), 40), "name": _text(q.get("name"), 80), "art": _text(q.get("art"), 20),
                       "url": str(q["url"])[:500], "text": _text(q.get("text"), 300)}
            if isinstance(q.get("paket"), dict):
                try:
                    eintrag["paket"] = traum_studio.paket_pruefen(q["paket"])
                except ValueError:
                    pass
            if isinstance(q.get("apks"), list):
                eintrag["apks"] = [a for a in q["apks"] if isinstance(a, dict) and a.get("name")][:20]
            quellen.append(eintrag)
    chat = roh.get("chat") if isinstance(roh.get("chat"), dict) else {}
    aktiv = roh.get("aktiv") if any(s["id"] == roh.get("aktiv") for s in server) else GERAET["id"]
    return {"server": server[:MAX_SERVER + 1], "aktiv": aktiv, "quellen": quellen[:MAX_QUELLEN],
            "chat": {"anbieter": _text(chat.get("anbieter"), 30), "basis": str(chat.get("basis") or "")[:300],
                     "modell": _text(chat.get("modell"), 120), "schluessel": str(chat.get("schluessel") or "")[:300]},
            "hochskalierer": str(roh.get("hochskalierer") or "")[:400]}


def fuer_oberflaeche(e):
    """Was die Seite sieht: ohne Zugangsdaten und Chat-Schluessel."""
    server = [dict(s, zugang=bool(s.get("zugang"))) for s in e["server"]]
    chat = dict(e["chat"], schluessel=bool(e["chat"].get("schluessel")))
    return {"server": server, "aktiv": e["aktiv"], "quellen": [{k: v for k, v in q.items() if k != "paket"} for q in e["quellen"]],
            "eingebaut": QUELLEN, "chat": chat, "chat_anbieter": CHAT_ANBIETER, "hochskalierer": e["hochskalierer"],
            "arten": ARTEN, "sampler_ld": SAMPLER_LD}


def studio(e):
    """Prompt-Studio-Daten mit allen eingetragenen Paketen."""
    d = traum_studio.daten()
    for q in e["quellen"]:
        p = q.get("paket")
        if not p:
            continue
        for topf, liste in p["toepfe"].items():
            d["toepfe"][topf] = list(dict.fromkeys(d["toepfe"].get(topf, []) + liste))
        d["szenen"] += [dict(s, paket=p["name"]) for s in p["szenen"]]
        d["stimmungen"].update(p["stimmungen"])
        d["figuren"] += p["figuren"]
        for en, de in p["deutsch"].items():
            d["deutsch"].setdefault(en, de)
    return d


def aendern(daten, wunsch):
    """{"aktion": server_dazu|server_weg|aktiv|quelle_weg|chat|hochskalierer, …} -> neue Werte (pruefe)."""
    if not isinstance(wunsch, dict):
        raise TraumFehler("JSON-Objekt erwartet")
    e = pruefe(daten.get(SCHLUESSEL))
    aktion = wunsch.get("aktion")
    if aktion == "server_dazu":
        if wunsch.get("art") not in ARTEN:
            raise TraumFehler("Art: " + ", ".join(ARTEN))
        if len(e["server"]) > MAX_SERVER:
            raise TraumFehler("Höchstens %d Server" % MAX_SERVER)
        neu = {"id": _neue_id(wunsch.get("name") or wunsch["art"]), "name": _text(wunsch.get("name"), 60) or ARTEN[wunsch["art"]],
               "art": wunsch["art"], "adresse": _adresse(wunsch.get("adresse")), "zugang": _text(wunsch.get("zugang"), 200)}
        if wunsch.get("host") is True:
            neu["host"] = True
            neu["generation"] = _adresse(wunsch.get("generation")) if wunsch.get("generation") else _mit_port(neu["adresse"], 8081)
        e["server"].append(neu)
        e["aktiv"] = neu["id"]
    elif aktion == "server_weg":
        e["server"] = [s for s in e["server"] if s.get("fest") or s["id"] != wunsch.get("id")]
        if not any(s["id"] == e["aktiv"] for s in e["server"]):
            e["aktiv"] = GERAET["id"]
    elif aktion == "aktiv":
        if not any(s["id"] == wunsch.get("id") for s in e["server"]):
            raise TraumFehler("Unbekannter Server")
        e["aktiv"] = wunsch["id"]
    elif aktion == "quelle_weg":
        e["quellen"] = [q for q in e["quellen"] if q["id"] != wunsch.get("id")]
    elif aktion == "chat":
        alt = e["chat"]
        e["chat"] = {"anbieter": _text(wunsch.get("anbieter"), 30), "basis": str(wunsch.get("basis") or "").strip()[:300],
                     "modell": _text(wunsch.get("modell"), 120),
                     "schluessel": alt["schluessel"] if wunsch.get("schluessel") in (None, True) else str(wunsch.get("schluessel") or "")[:300]}
        if e["chat"]["basis"] and not re.match(r"^https?://", e["chat"]["basis"]):
            raise TraumFehler("Basis-Adresse mit http(s)://")
    elif aktion == "hochskalierer":
        e["hochskalierer"] = str(wunsch.get("pfad") or "").strip()[:400]
    else:
        raise TraumFehler("Unbekannte Aktion")
    gespeichert = dict(e)
    gespeichert["server"] = [s for s in e["server"] if not s.get("fest")]
    daten[SCHLUESSEL] = gespeichert
    return e


def quelle_eintragen(daten, quelle):
    """Erkannte Quelle (erkennen) speichern; ein Bildserver kommt in die Server-Liste."""
    e = pruefe(daten.get(SCHLUESSEL))
    if quelle["art"] == "server_erkannt":
        neu = {"id": _neue_id(quelle["name"]), "name": quelle["name"][:60], "art": quelle["server_art"], "adresse": quelle["url"], "zugang": ""}
        if quelle.get("host"):
            neu["host"] = True
            neu["generation"] = _mit_port(quelle["url"], 8081)
        e["server"].append(neu)
        e["aktiv"] = neu["id"]
    else:
        if len(e["quellen"]) >= MAX_QUELLEN:
            raise TraumFehler("Höchstens %d eigene Quellen" % MAX_QUELLEN)
        e["quellen"] = [q for q in e["quellen"] if q["url"] != quelle["url"]] + [dict(quelle, id=_neue_id(quelle["name"]))]
    gespeichert = dict(e, server=[s for s in e["server"] if not s.get("fest")])
    daten[SCHLUESSEL] = gespeichert
    return e


# --- Empfehlung je Prozessor ----------------------------------------------------------------------------------
def empfehlung(chip="", abi="", gpu=""):
    """Welche Local-Dream-Variante zu diesem Geraet passt: {"npu", "sdxl", "apk", "opencl", "text", "chip"}."""
    chip, abi, gpu = str(chip or ""), str(abi or ""), str(gpu or "")
    m = re.search(r"\b(SM\d{4})", chip.upper())
    modell = m.group(1) if m else ""
    hexagon = HEXAGON.get(modell, 0)
    if not hexagon and modell and int(modell[2:]) >= 8350 and modell.startswith("SM8"):
        hexagon = 68  # neuere 8er-Snapdragon, die hier noch fehlen
    qualcomm = "QUALCOMM" in chip.upper() or "QTI" in chip.upper() or bool(modell)
    name = SNAPDRAGON_NAMEN.get(modell) or chip or "unbekannter Prozessor"
    apk = abi == "arm64-v8a"
    gpu_klein = gpu.lower()
    opencl = any(x in gpu_klein for x in ("adreno", "mali", "immortalis", "powervr", "xclipse"))
    if not abi:
        text = "Prozessor unbekannt (im Browser): in der H0rSt-App siehst du hier, was dein Gerät kann. Sonst einen Bildserver eintragen."
    elif not apk:
        text = ("Local Dream gibt es nur für 64-Bit-ARM (arm64-v8a); dieses Gerät ist %s. Bilder entstehen hier über einen "
                "Bildserver im Netz (Local Dream auf einem anderen Handy, AUTOMATIC1111, Forge, SD.Next)." % abi)
    elif hexagon >= 68:
        text = ("%s mit Hexagon-NPU V%d: NPU-Modelle für SD 1.5 laufen schnell%s. Die CPU/GPU-Modelle gehen auch."
                % (name, hexagon, ", dazu SDXL auf der NPU" if hexagon >= 75 else "; SDXL auf der NPU erst ab Snapdragon 8 Gen 3"))
    elif qualcomm:
        text = "%s: die NPU ist zu alt für Local Dream (ab Hexagon V68, z. B. Snapdragon 888). Nimm die CPU/GPU-Modelle (MNN)." % name
    else:
        text = "%s: keine Snapdragon-NPU. Nimm die CPU/GPU-Modelle (MNN)%s." % (name, " und schalte die GPU (OpenCL) ein" if opencl else "")
    return {"chip": name, "abi": abi, "npu": hexagon >= 68, "sdxl": hexagon >= 75, "hexagon": hexagon, "apk": apk, "opencl": opencl, "text": text}


# --- Netz -------------------------------------------------------------------------------------------------------
def _anfrage(url, daten=None, kopf=None, zeit=20, methode=None):
    """Direkter Abruf (Bildserver im Heimnetz gehen nicht ueber Tor oder Proxy). -> (status, bytes, header)."""
    k = {"User-Agent": "H0rSt/" + __version__}
    k.update(kopf or {})
    if isinstance(daten, (dict, list)):
        daten = json.dumps(daten).encode("utf-8")
        k.setdefault("Content-Type", "application/json")
    try:
        with urllib.request.urlopen(urllib.request.Request(url, data=daten, headers=k, method=methode), timeout=zeit) as a:
            return a.status, a.read(64 * 1024 * 1024), a.headers
    except urllib.error.HTTPError as fehler:
        try:
            return fehler.code, fehler.read(64 * 1024), fehler.headers
        finally:
            fehler.close()
    except (urllib.error.URLError, OSError) as fehler:
        raise TraumFehler("%s nicht erreichbar (%s)" % (urlsplit(url).netloc, getattr(fehler, "reason", fehler)))


def _zugang(server):
    z = server.get("zugang") or ""
    return {"Authorization": "Basic " + base64.b64encode(z.encode("utf-8")).decode("ascii")} if ":" in z else {}


class Abgebrochen(Exception):
    pass


# --- Wunsch pruefen ---------------------------------------------------------------------------------------------
def _zahl(wert, standard, klein, gross, art=int):
    try:
        zahl = art(wert)
        if isinstance(zahl, float) and not (float("-inf") < zahl < float("inf")):
            return standard
        return max(klein, min(gross, zahl))
    except (TypeError, ValueError, OverflowError):
        return standard


def _bild_b64(wert):
    text = str(wert or "")
    if not text:
        return ""
    text = text.split(",", 1)[-1] if text.startswith("data:") else text
    if len(text) > 30 * 1024 * 1024 or not re.match(r"^[A-Za-z0-9+/=\s]+$", text[:200]):
        raise TraumFehler("Bild als Base64 (PNG/JPEG) erwartet")
    return text


def wunsch_pruefen(roh):
    if not isinstance(roh, dict):
        raise TraumFehler("JSON-Objekt erwartet")
    prompt = str(roh.get("prompt") or "").strip()[:4000]
    if not prompt:
        raise TraumFehler("Prompt fehlt")
    try:
        traum_studio.prompt_pruefen(prompt)
    except ValueError as f:
        raise TraumFehler(str(f))
    vorgabe = roh.get("vorgabe") if roh.get("vorgabe") in ("512", "768", "1024", "square", "portrait", "landscape") else ""
    seed = _zahl(roh.get("seed"), -1, -1, 2 ** 32 - 1)
    referenzen = []
    rohe_refs = roh.get("referenzen") if isinstance(roh.get("referenzen"), list) else []
    for bild in rohe_refs[:4]:
        referenz = _bild_b64(bild)
        if len(referenz) > 16 * 1024 * 1024:
            raise TraumFehler("Referenzbild: hoechstens 16 MB je Bild")
        referenzen.append(referenz)
    ultrafix_steps = _zahl(roh.get("ultrafix_steps"), 10, 1, 150)
    seiten = str(roh.get("aspect_ratio") or "").strip()
    if not re.match(r"^\d{1,2}:\d{1,2}$", seiten):
        seiten = ""
    format_aus = str(roh.get("output_format") or "").lower()
    if format_aus not in ("png", "jpeg", "raw"):
        format_aus = "png"
    return {"prompt": prompt, "negativ": str(roh.get("negativ") or "")[:4000], "schritte": _zahl(roh.get("schritte"), 20, 1, 150),
            "cfg": _zahl(roh.get("cfg"), 7.0, 1.0, 30.0, float), "seed": seed, "sampler": _text(roh.get("sampler"), 60),
            "breite": _zahl(roh.get("breite"), 512, 64, 2048) // 8 * 8, "hoehe": _zahl(roh.get("hoehe"), 512, 64, 2048) // 8 * 8,
            "vorgabe": vorgabe, "anzahl": _zahl(roh.get("anzahl"), 1, 1, 8), "opencl": roh.get("opencl") is True,
            "zwischenbilder": roh.get("zwischenbilder") is not False, "bild": _bild_b64(roh.get("bild")), "maske": _bild_b64(roh.get("maske")),
            "staerke": _zahl(roh.get("staerke"), 0.6, 0.0, 1.0, float), "modell": _text(roh.get("modell"), 120),
            "ultrafix": roh.get("ultrafix") is True, "tile_size": _zahl(roh.get("tile_size"), 512, 64, 1024) // 8 * 8,
            "ultrafix_steps": ultrafix_steps,
            "ultrafix_denoise_steps": _zahl(roh.get("ultrafix_denoise_steps"), 4, 1, ultrafix_steps),
            "ultrafix_quality_denoise": roh.get("ultrafix_quality_denoise") is not False,
            "aspect_ratio": seiten, "vorschau_stride": _zahl(roh.get("vorschau_stride"), 2, 1, 20),
            "output_format": format_aus, "lowram": roh.get("lowram") is True, "seq_dit": roh.get("seq_dit") is True,
            "patch": _text(roh.get("patch"), 300),
            "referenzen": [x for x in referenzen if x]}
