"""PNG ohne Zusatzpakete: RGB-Bilder schreiben und PNGs (8 Bit, nicht verschraenkt) zu RGB lesen.

Gebraucht fuer LocalDream: der Hochskalierer von Local Dream will rohe RGB-Bytes, die Galerie speichert PNG.
"""

import struct
import zlib

KENNUNG = b"\x89PNG\r\n\x1a\n"


class PngFehler(ValueError):
    pass


def _block(art, inhalt):
    return struct.pack(">I", len(inhalt)) + art + inhalt + struct.pack(">I", zlib.crc32(art + inhalt) & 0xFFFFFFFF)


def kodieren(breite, hoehe, rgb):
    """Rohe RGB-Bytes (breite*hoehe*3) -> PNG."""
    zeile = breite * 3
    if len(rgb) != zeile * hoehe:
        raise PngFehler("RGB-Daten passen nicht zu %dx%d" % (breite, hoehe))
    roh = b"".join(b"\x00" + rgb[y * zeile:(y + 1) * zeile] for y in range(hoehe))
    return (KENNUNG + _block(b"IHDR", struct.pack(">IIBBBBB", breite, hoehe, 8, 2, 0, 0, 0))
            + _block(b"IDAT", zlib.compress(roh, 6)) + _block(b"IEND", b""))


def groesse(daten):
    """(breite, hoehe) eines PNG oder JPEG, sonst (0, 0)."""
    if daten[:8] == KENNUNG and len(daten) >= 24:
        return struct.unpack(">II", daten[16:24])
    if daten[:2] == b"\xff\xd8":
        i = 2
        while i + 9 < len(daten):
            if daten[i] != 0xFF:
                i += 1
                continue
            marke, laenge = daten[i + 1], struct.unpack(">H", daten[i + 2:i + 4])[0]
            if marke in (0xC0, 0xC1, 0xC2):
                hoehe, breite = struct.unpack(">HH", daten[i + 5:i + 9])
                return breite, hoehe
            i += 2 + laenge
    return 0, 0


def _paeth(a, b, c):
    p = a + b - c
    pa, pb, pc = abs(p - a), abs(p - b), abs(p - c)
    return a if pa <= pb and pa <= pc else (b if pb <= pc else c)


def dekodieren(daten):
    """PNG -> (breite, hoehe, rgb). 8 Bit je Kanal, Grau, Grau+Alpha, RGB oder RGBA, nicht verschraenkt."""
    if daten[:8] != KENNUNG:
        raise PngFehler("kein PNG")
    i, kopf, idat = 8, None, []
    while i + 8 <= len(daten):
        laenge = struct.unpack(">I", daten[i:i + 4])[0]
        art, inhalt = daten[i + 4:i + 8], daten[i + 8:i + 8 + laenge]
        if art == b"IHDR":
            kopf = struct.unpack(">IIBBBBB", inhalt)
        elif art == b"IDAT":
            idat.append(inhalt)
        elif art == b"IEND":
            break
        i += 12 + laenge
    if not kopf:
        raise PngFehler("PNG ohne Kopf")
    breite, hoehe, tiefe, farbe, _, _, verschraenkt = kopf
    kanaele = {0: 1, 2: 3, 4: 2, 6: 4}.get(farbe)
    if tiefe != 8 or not kanaele or verschraenkt:
        raise PngFehler("PNG-Art wird nicht unterstuetzt (Tiefe %d, Farbe %d)" % (tiefe, farbe))
    if breite * hoehe > 40_000_000:
        raise PngFehler("Bild zu gross")
    roh = zlib.decompress(b"".join(idat))
    zeile = breite * kanaele
    aus = bytearray(zeile * hoehe)
    vorher = bytearray(zeile)
    pos = 0
    for y in range(hoehe):
        filter_art = roh[pos]
        z = bytearray(roh[pos + 1:pos + 1 + zeile])
        pos += 1 + zeile
        if filter_art == 1:
            for x in range(kanaele, zeile):
                z[x] = (z[x] + z[x - kanaele]) & 0xFF
        elif filter_art == 2:
            for x in range(zeile):
                z[x] = (z[x] + vorher[x]) & 0xFF
        elif filter_art == 3:
            for x in range(zeile):
                links = z[x - kanaele] if x >= kanaele else 0
                z[x] = (z[x] + ((links + vorher[x]) >> 1)) & 0xFF
        elif filter_art == 4:
            for x in range(zeile):
                links = z[x - kanaele] if x >= kanaele else 0
                oben_links = vorher[x - kanaele] if x >= kanaele else 0
                z[x] = (z[x] + _paeth(links, vorher[x], oben_links)) & 0xFF
        elif filter_art != 0:
            raise PngFehler("unbekannter PNG-Filter %d" % filter_art)
        aus[y * zeile:(y + 1) * zeile] = z
        vorher = z
    if kanaele == 3:
        return breite, hoehe, bytes(aus)
    rgb = bytearray(breite * hoehe * 3)
    for p in range(breite * hoehe):
        if kanaele in (1, 2):
            g = aus[p * kanaele]
            rgb[p * 3:p * 3 + 3] = bytes((g, g, g))
        else:
            rgb[p * 3:p * 3 + 3] = aus[p * 4:p * 4 + 3]
    return breite, hoehe, bytes(rgb)
