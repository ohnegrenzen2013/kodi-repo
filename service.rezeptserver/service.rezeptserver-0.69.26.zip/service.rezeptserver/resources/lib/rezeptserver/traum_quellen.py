"""LocalDream: Quellen per Adresse erkennen und Local-Dream-APKs laden."""

import json
import os
import re
import urllib.error
import urllib.request
from urllib.parse import urlsplit

from . import __version__, magicwx, traum_studio
from .netz import NetzFehler
from .traum_grund import (ARTEN, LD_APK, LD_APK_FILTER, LD_REPO, LD_VERSION, MAX_PAKET, PS_APK, PS_REPO, TraumFehler, _adresse,
                          _anfrage, _mit_port, _text)


class QuellenMixin:
    # Quellen per Adresse
    def _json_holen(self, url):
        try:
            status, text = self.holen(url, "GET", {"Accept": "application/json"}, None, 20)
        except TypeError:  # holen mit Stichwortargumenten (urllib_holen)
            status, text = self.holen(url, methode="GET", header={"Accept": "application/json"}, zeitgrenze=20)
        if status >= 400:
            raise TraumFehler("HTTP %d bei %s" % (status, url))
        if len(text) > MAX_PAKET * 4:
            raise TraumFehler("Antwort zu groß")
        return json.loads(text)

    def erkennen(self, url):
        """Was steckt hinter dieser Adresse? -> Quelle {art, name, url, text, (paket|apks|server_art)}."""
        url = str(url or "").strip()
        if not re.match(r"^https?://", url):
            if re.match(r"^[\w.-]+(:\d+)?(/.*)?$", url):
                url = "http://" + url
            else:
                raise TraumFehler("Adresse mit http(s):// erwartet")
        teile = urlsplit(url)
        host = (teile.hostname or "").lower()
        gh = re.match(r"^/([\w.-]+)/([\w.-]+)", teile.path) if host in ("github.com", "www.github.com") else None
        if gh:
            repo = "%s/%s" % (gh.group(1), re.sub(r"\.git$", "", gh.group(2)))
            try:
                info = self._json_holen("https://api.github.com/repos/" + repo)
                releases = self._json_holen("https://api.github.com/repos/%s/releases?per_page=5" % repo)
            except (NetzFehler, ValueError) as f:
                raise TraumFehler("GitHub: %s" % f)
            apks = []
            for r in releases if isinstance(releases, list) else []:
                apks = [{"name": a.get("name"), "url": a.get("browser_download_url"), "groesse": a.get("size"), "version": r.get("tag_name")}
                        for a in r.get("assets") or [] if str(a.get("name", "")).endswith(".apk")]
                if apks:
                    break
            return {"art": "app" if apks else "quelltext", "name": str(info.get("name") or repo)[:80],
                    "url": "https://github.com/" + repo, "text": _text(info.get("description"), 300), "apks": apks}
        if host.endswith(("huggingface.co", "civitai.com")):
            return {"art": "modelle", "name": host + teile.path[:60], "url": url, "text": "Modelle"}
        # Bildserver? (Local Dream v3 Host: /info am Steuerport; sonst /health am Bildport)
        basis = url.rstrip("/")
        for kontrolle in (basis, _mit_port(basis, 8808)):
            try:
                status, inhalt, _ = _anfrage(kontrolle + "/info", zeit=3)
                if status == 200 and b'"localdream"' in inhalt and b'"protocol"' in inhalt:
                    return {"art": "server_erkannt", "server_art": "localdream", "host": True,
                            "name": "Local Dream Host " + teile.netloc, "url": kontrolle,
                            "text": "Local Dream Host (Fernsteuerung)"}
            except TraumFehler:
                pass
        try:
            status, _, _ = _anfrage(basis + "/sdapi/v1/options", zeit=4)
            if status in (200, 401):
                return {"art": "server_erkannt", "server_art": "a1111", "name": "Bildserver " + teile.netloc, "url": basis,
                        "text": "AUTOMATIC1111 / Forge / SD.Next"}
            status, inhalt, _ = _anfrage(basis + "/health", zeit=4)
            if status == 200 and len(inhalt) < 200:
                return {"art": "server_erkannt", "server_art": "localdream", "name": "Local Dream " + teile.netloc, "url": basis,
                        "text": "Local Dream"}
        except TraumFehler:
            pass
        # Paket fuer das Prompt Studio oder Erweiterung (JSON)
        try:
            roh = self._json_holen(url)
        except (NetzFehler, ValueError, TraumFehler):
            roh = None
        if isinstance(roh, dict):
            if roh.get("art") == "server" and roh.get("adresse"):
                art = roh.get("server_art") if roh.get("server_art") in ARTEN else "localdream"
                return {"art": "server_erkannt", "server_art": art, "name": _text(roh.get("name"), 60) or "Bildserver",
                        "url": _adresse(roh["adresse"]), "text": ARTEN[art]}
            try:
                paket = traum_studio.paket_pruefen(roh)
            except ValueError as f:
                raise TraumFehler(str(f))
            return {"art": "paket", "name": paket["name"], "url": url, "paket": paket,
                    "text": "Paket für das Prompt Studio: %d Töpfe, %d Szenen, %d Stimmungen, %d Figuren"
                            % (len(paket["toepfe"]), len(paket["szenen"]), len(paket["stimmungen"]), len(paket["figuren"]))}
        return {"art": "link", "name": host or url, "url": url, "text": "Seite"}

    # App (APK) von GitHub laden
    def apk_waehlen(self, quelle_apks, mit_filter=True):
        """arm64-APK aus einer Liste: bevorzugt mit bzw. ohne Bildfilter."""
        arm = [a for a in quelle_apks if "arm64" in a["name"].lower() or "armv8" in a["name"].lower()] or quelle_apks
        passend = [a for a in arm if ("filter" in a["name"].lower()) == mit_filter] or arm
        return passend[0] if passend else None

    def localdream_neueste(self):
        try:
            r = self._json_holen("https://api.github.com/repos/%s/releases?per_page=5" % LD_REPO)
            for rel in r if isinstance(r, list) else []:
                apks = [{"name": a.get("name"), "url": a.get("browser_download_url"), "groesse": a.get("size"),
                         "version": rel.get("tag_name")}
                        for a in rel.get("assets") or [] if str(a.get("name", "")).endswith(".apk")]
                if apks:
                    return apks
        except (NetzFehler, ValueError, TraumFehler):
            pass
        # Feste Freigabe (v3.0.0-alpha.7), falls die GitHub-API gerade nicht antwortet
        return [{"name": LD_APK.rsplit("/", 1)[-1], "url": LD_APK, "groesse": 0, "version": LD_VERSION},
                {"name": LD_APK_FILTER.rsplit("/", 1)[-1], "url": LD_APK_FILTER, "groesse": 0, "version": LD_VERSION}]

    def magicwx_neueste(self):
        """APK von MagicWX (GitHub-Release, sonst die feste 1.2.0)."""
        try:
            r = self._json_holen("https://api.github.com/repos/%s/releases?per_page=5" % magicwx.REPO)
            for rel in r if isinstance(r, list) else []:
                apks = [{"name": a.get("name"), "url": a.get("browser_download_url"), "groesse": a.get("size"),
                         "version": rel.get("tag_name")}
                        for a in rel.get("assets") or [] if str(a.get("name", "")).lower().endswith(".apk")]
                if apks:
                    return apks
        except (NetzFehler, ValueError, TraumFehler):
            pass
        return [{"name": magicwx.APK.rsplit("/", 1)[-1], "url": magicwx.APK, "groesse": 0, "version": magicwx.APK_VERSION}]

    def promptstudio_neueste(self):
        """APK der eigenstaendigen Prompt-Studio-App (GitHub-Inhalt, sonst die feste 3.7)."""
        try:
            dateien = self._json_holen("https://api.github.com/repos/%s/contents/releases" % PS_REPO)
            apks = [{"name": d.get("name"), "url": d.get("download_url"), "groesse": d.get("size"),
                     "version": re.sub(r"^[^0-9]*", "", re.sub(r"(?i)\.apk$", "", str(d.get("name") or "")))}
                    for d in dateien if isinstance(d, dict) and str(d.get("name", "")).lower().endswith(".apk") and d.get("download_url")]
            if apks:
                return apks[:10]
        except (NetzFehler, ValueError, TraumFehler):
            pass
        return [{"name": PS_APK.rsplit("/", 1)[-1], "url": PS_APK, "groesse": 0, "version": "3.7"}]

    def apk_laden(self, apk, datenordner):
        """APK nach <Datenordner>/traum/<name>.apk laden (in Stuecken, die Dateien sind ~100 MB)."""
        url = str(apk.get("url") or "")
        if not re.match(r"^https://(github\.com|objects\.githubusercontent\.com|raw\.githubusercontent\.com)/", url):
            raise TraumFehler("Nur APKs von GitHub")
        ziel_ordner = os.path.join(datenordner or ".", "traum")
        os.makedirs(ziel_ordner, exist_ok=True)
        ziel = os.path.join(ziel_ordner, re.sub(r"[^\w.-]", "_", apk["name"]))
        try:
            with urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": "H0rSt/" + __version__}), timeout=120) as a, \
                    open(ziel + ".neu", "wb") as f:
                groesse = 0
                while True:
                    stueck = a.read(1 << 20)
                    if not stueck:
                        break
                    groesse += len(stueck)
                    if groesse > 400 * 1024 * 1024:
                        raise TraumFehler("APK zu groß")
                    f.write(stueck)
        except (urllib.error.URLError, OSError) as fehler:
            raise TraumFehler("Download fehlgeschlagen: %s" % fehler)
        with open(ziel + ".neu", "rb") as f:
            if f.read(2) != b"PK":
                os.remove(ziel + ".neu")
                raise TraumFehler("Download ist keine APK")
        os.replace(ziel + ".neu", ziel)
        return ziel
