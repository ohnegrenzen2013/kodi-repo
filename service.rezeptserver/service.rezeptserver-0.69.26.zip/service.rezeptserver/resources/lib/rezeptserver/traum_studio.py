"""Prompt Studio (LocalDream): Begriffe, Szenen und Stimmungen fuer Bild-Prompts – auf Deutsch, ohne Inhalte fuer Erwachsene.

Nach dem Vorbild von „SD Prompt Studio“ (justsmile3/PromptGenerator, MIT-Lizenz): Danbooru-Begriffe in Toepfen, eine
Szenen-Logik (jede Szene bringt Handlung, Pose, Ausdruck, Ort, Licht und Kamera mit, die zusammenpassen) und
Gruppen, die sich ausschliessen (nie zwei Haarfarben). Die Begriffe bleiben englisch, weil Stable Diffusion sie so
versteht; die Oberflaeche zeigt sie deutsch. Die Szenen sind neu geschrieben: das Vorbild hat Stufen mit Nacktheit und
Sex, die H0rSt nicht uebernimmt.

Eigene Pakete (Quellen per Adresse) ergaenzen Toepfe, Szenen, Stimmungen und Figuren im selben Format; sperren()
entfernt dabei Begriffe fuer Erwachsene und alles, was nach Kindern klingt.
"""

import re

# Topf -> [(englisch, deutsch)]
TOEPFE = {
    "qualitaet": [("masterpiece", "Meisterwerk"), ("best quality", "beste Qualität"), ("ultra-detailed", "sehr detailreich"),
                  ("highres", "hohe Auflösung"), ("absurdres", "sehr hohe Auflösung"), ("extremely detailed CG", "extrem detaillierte CG"),
                  ("8k wallpaper", "8K-Hintergrundbild"), ("amazing quality", "erstklassige Qualität"), ("very aesthetic", "sehr ästhetisch")],
    "stil": [("anime style", "Anime-Stil"), ("anime coloring", "Anime-Farben"), ("anime screencap", "Anime-Standbild"),
             ("official art", "offizielles Artwork"), ("beautiful detailed eyes", "schöne, detaillierte Augen"),
             ("detailed background", "detaillierter Hintergrund"), ("sharp focus", "scharfer Fokus"), ("delicate illustration", "feine Illustration")],
    "motiv": [("1girl", "eine Frau"), ("1girl", "eine Frau"), ("1boy", "ein Mann"), ("solo", "allein"), ("1girl, solo", "eine Frau allein"),
              ("1boy, solo", "ein Mann allein"), ("2girls", "zwei Frauen"), ("1girl, 1boy", "eine Frau und ein Mann")],
    "haare": [("long hair", "lange Haare"), ("short hair", "kurze Haare"), ("twin tails", "Zöpfe"), ("ponytail", "Pferdeschwanz"),
              ("braid", "Flechtzopf"), ("hair bun", "Haarknoten"), ("bob cut", "Bob"), ("hime cut", "Hime-Schnitt"), ("wavy hair", "gewellte Haare"),
              ("straight hair", "glatte Haare"), ("silver hair", "silberne Haare"), ("white hair", "weiße Haare"), ("black hair", "schwarze Haare"),
              ("blonde hair", "blonde Haare"), ("brown hair", "braune Haare"), ("pink hair", "rosa Haare"), ("blue hair", "blaue Haare"),
              ("purple hair", "lila Haare"), ("red hair", "rote Haare"), ("green hair", "grüne Haare"), ("gradient hair", "Farbverlauf-Haare")],
    "augen": [("blue eyes", "blaue Augen"), ("red eyes", "rote Augen"), ("green eyes", "grüne Augen"), ("purple eyes", "lila Augen"),
              ("yellow eyes", "gelbe Augen"), ("pink eyes", "rosa Augen"), ("aqua eyes", "türkise Augen"), ("brown eyes", "braune Augen"),
              ("heterochromia", "zweifarbige Augen")],
    "koerper": [("slim", "schlank"), ("slender", "grazil"), ("athletic", "sportlich"), ("tall", "groß"), ("muscular", "muskulös")],
    "kleidung": [("dress", "Kleid"), ("maid outfit", "Dienstmädchen-Kleid"), ("kimono", "Kimono"), ("yukata", "Yukata"), ("sweater", "Pullover"),
                 ("hoodie", "Kapuzenpulli"), ("t-shirt", "T-Shirt"), ("casual", "Freizeitkleidung"), ("suit", "Anzug"), ("witch costume", "Hexenkostüm"),
                 ("armor", "Rüstung"), ("idol costume", "Idol-Kostüm"), ("pajamas", "Schlafanzug"), ("sundress", "Sommerkleid"),
                 ("cheongsam", "Qipao"), ("hanfu", "Hanfu"), ("sweater vest", "Pullunder"), ("cardigan", "Strickjacke"), ("denim jacket", "Jeansjacke"),
                 ("raincoat", "Regenmantel"), ("santa costume", "Weihnachtskostüm"), ("track suit", "Trainingsanzug"), ("overalls", "Latzhose"),
                 ("trench coat", "Trenchcoat"), ("tuxedo", "Smoking"), ("turtleneck", "Rollkragen"), ("poncho", "Poncho"),
                 ("military uniform", "Militäruniform"), ("lab coat", "Laborkittel"), ("chef uniform", "Kochkleidung"), ("wizard robe", "Zauberrobe"),
                 ("winter coat", "Wintermantel"), ("scarf", "Schal"), ("beret", "Baskenmütze"), ("glasses", "Brille"), ("headphones", "Kopfhörer")],
    "pose": [("sitting", "sitzend"), ("standing", "stehend"), ("lying", "liegend"), ("leaning forward", "vorgebeugt"), ("looking back", "zurückblickend"),
             ("arms behind head", "Arme hinter dem Kopf"), ("stretching", "sich streckend"), ("walking", "gehend"), ("cross-legged", "im Schneidersitz"),
             ("hand on hip", "Hand an der Hüfte"), ("arms crossed", "Arme verschränkt"), ("kneeling", "kniend"), ("squatting", "hockend"),
             ("running", "rennend"), ("jumping", "springend"), ("dancing", "tanzend"), ("hands in pockets", "Hände in den Taschen"),
             ("hand on chest", "Hand auf der Brust"), ("waving", "winkend"), ("saluting", "salutierend"), ("holding cup", "mit Tasse"),
             ("reading book", "lesend"), ("playing instrument", "musizierend"), ("adjusting hair", "richtet die Haare"), ("chin rest", "Kinn aufgestützt"),
             ("head tilt", "Kopf geneigt"), ("looking up", "nach oben schauend"), ("reaching out", "die Hand ausstreckend")],
    "ausdruck": [("smile", "Lächeln"), ("blush", "errötet"), ("shy", "schüchtern"), ("looking at viewer", "schaut in die Kamera"), ("closed eyes", "Augen zu"),
                 ("smirk", "Grinsen"), ("surprised", "überrascht"), ("pout", "Schmollmund"), ("gentle smile", "sanftes Lächeln"), ("sleepy", "müde"),
                 ("laughing", "lachend"), ("serious", "ernst"), ("determined", "entschlossen"), ("confident", "selbstbewusst"), ("wink", "zwinkernd"),
                 ("thinking", "nachdenklich"), ("open mouth", "offener Mund"), ("calm", "ruhig"), ("happy", "fröhlich"), ("melancholic", "wehmütig"),
                 ("focused", "konzentriert"), ("excited", "begeistert")],
    "hintergrund": [("bedroom", "Schlafzimmer"), ("street", "Straße"), ("beach", "Strand"), ("garden", "Garten"), ("cityscape", "Stadtansicht"),
                    ("night sky", "Nachthimmel"), ("cafe", "Café"), ("underwater", "unter Wasser"), ("cherry blossoms", "Kirschblüten"),
                    ("sunset", "Sonnenuntergang"), ("forest", "Wald"), ("rooftop", "Dach"), ("library", "Bibliothek"), ("shrine", "Schrein"),
                    ("train station", "Bahnhof"), ("alley", "Gasse"), ("park", "Park"), ("museum", "Museum"), ("aquarium", "Aquarium"),
                    ("festival", "Fest"), ("snow field", "Schneefeld"), ("desert", "Wüste"), ("mountain", "Berg"), ("lake", "See"),
                    ("flower field", "Blumenwiese"), ("balcony", "Balkon"), ("kitchen", "Küche"), ("castle", "Burg"), ("ruins", "Ruinen"),
                    ("space", "Weltall"), ("simple background", "schlichter Hintergrund")],
    "licht": [("cinematic lighting", "Kinolicht"), ("soft lighting", "weiches Licht"), ("rim lighting", "Kantenlicht"), ("backlighting", "Gegenlicht"),
              ("golden hour", "goldene Stunde"), ("dramatic lighting", "dramatisches Licht"), ("volumetric lighting", "Lichtstrahlen"),
              ("neon lighting", "Neonlicht"), ("moonlight", "Mondlicht"), ("lens flare", "Linsenreflex"), ("god rays", "Sonnenstrahlen"),
              ("candlelight", "Kerzenlicht"), ("studio lighting", "Studiolicht"), ("dappled sunlight", "Licht durch Blätter"), ("blue hour", "blaue Stunde"),
              ("sunrise", "Sonnenaufgang"), ("firelight", "Feuerschein"), ("bioluminescence", "leuchtende Natur"), ("glowing", "leuchtend")],
    "kamera": [("full body", "ganzer Körper"), ("upper body", "Oberkörper"), ("cowboy shot", "bis zur Hüfte"), ("close-up", "Nahaufnahme"),
               ("from above", "von oben"), ("from below", "von unten"), ("from side", "von der Seite"), ("dynamic angle", "dynamischer Winkel"),
               ("portrait", "Porträt"), ("wide shot", "Totale"), ("dutch angle", "schräger Winkel"), ("over the shoulder", "über die Schulter"),
               ("from behind", "von hinten"), ("profile", "Profil"), ("low angle", "Froschperspektive"), ("high angle", "Vogelperspektive")],
}

# Topf -> deutscher Name (Oberflaeche)
TOPF_NAMEN = {"qualitaet": "Qualität", "stil": "Stil", "motiv": "Motiv", "haare": "Haare", "augen": "Augen", "koerper": "Körper",
              "kleidung": "Kleidung", "pose": "Pose", "ausdruck": "Ausdruck", "hintergrund": "Ort", "licht": "Licht", "kamera": "Kamera",
              "szene": "Szene", "stimmung": "Stimmung", "eigen": "Eigene", "figur": "Figur"}

# Szenen-Logik: eine stimmige Szene (Kern + passende Pose, Ausdruck, Ort, Licht, Kamera, Kleidung); personen 0 = Landschaft
SZENEN = [
    {"id": "cafe", "name": "Café am Nachmittag", "kern": ["cafe", "holding cup", "table"], "pose": ["sitting", "leaning forward", "chin rest"],
     "ausdruck": ["gentle smile", "looking at viewer", "calm"], "ort": ["cafe", "window"], "licht": ["soft lighting", "dappled sunlight"],
     "kamera": ["upper body", "cowboy shot"], "kleidung": ["sweater", "cardigan", "casual"]},
    {"id": "bibliothek", "name": "Lesen in der Bibliothek", "kern": ["library", "reading book", "bookshelf"], "pose": ["sitting", "standing"],
     "ausdruck": ["calm", "focused", "gentle smile"], "ort": ["library"], "licht": ["soft lighting", "candlelight"],
     "kamera": ["cowboy shot", "from side"], "kleidung": ["sweater vest", "cardigan", "glasses"]},
    {"id": "regenstadt", "name": "Regen in der Stadt", "kern": ["rain", "umbrella", "puddle"], "pose": ["standing", "walking", "looking up"],
     "ausdruck": ["melancholic", "calm"], "ort": ["street", "cityscape"], "licht": ["neon lighting", "reflection"],
     "kamera": ["full body", "from side"], "kleidung": ["raincoat", "trench coat"]},
    {"id": "kirschbluete", "name": "Kirschblüten", "kern": ["cherry blossoms", "falling petals"], "pose": ["standing", "reaching out", "looking up"],
     "ausdruck": ["smile", "happy"], "ort": ["park", "shrine"], "licht": ["soft lighting", "dappled sunlight"],
     "kamera": ["upper body", "from below"], "kleidung": ["kimono", "dress"]},
    {"id": "sommerfest", "name": "Sommerfest", "kern": ["summer festival", "yukata", "paper lantern", "fireworks"], "pose": ["standing", "looking back"],
     "ausdruck": ["smile", "blush"], "ort": ["festival", "shrine"], "licht": ["lantern light", "night"], "kamera": ["cowboy shot", "from behind"]},
    {"id": "kriegerin", "name": "Fantasy-Kämpferin", "kern": ["armor", "sword", "cape"], "pose": ["fighting stance", "holding sword"],
     "ausdruck": ["determined", "serious"], "ort": ["battlefield", "castle", "ruins"], "licht": ["dramatic lighting", "sunset"],
     "kamera": ["full body", "dynamic angle", "from below"]},
    {"id": "magie", "name": "Magie", "kern": ["magic", "magic circle", "staff"], "pose": ["casting spell", "outstretched arm", "floating"],
     "ausdruck": ["focused", "confident"], "ort": ["ruins", "night sky", "forest"], "licht": ["glowing", "volumetric lighting", "bioluminescence"],
     "kamera": ["full body", "dynamic angle"], "kleidung": ["wizard robe", "witch hat", "cape"]},
    {"id": "cyberpunk", "name": "Cyberpunk-Nacht", "kern": ["cyberpunk", "neon lights", "holographic display"], "pose": ["standing", "hands in pockets", "leaning against wall"],
     "ausdruck": ["confident", "smirk"], "ort": ["cityscape", "alley", "rooftop"], "licht": ["neon lighting", "rim lighting", "night"],
     "kamera": ["cowboy shot", "low angle"], "kleidung": ["jacket", "headphones", "techwear"]},
    {"id": "raumstation", "name": "Raumstation", "kern": ["space station", "spacesuit", "earth (planet)", "stars"], "pose": ["floating", "looking out window"],
     "ausdruck": ["calm", "surprised"], "ort": ["space"], "licht": ["cinematic lighting"], "kamera": ["wide shot", "full body"]},
    {"id": "winterwald", "name": "Winterwald", "kern": ["snow", "snowflakes", "winter"], "pose": ["standing", "walking"],
     "ausdruck": ["smile", "blush"], "ort": ["forest", "snow field"], "licht": ["soft lighting", "blue hour"],
     "kamera": ["full body", "wide shot"], "kleidung": ["winter coat", "scarf", "beanie"]},
    {"id": "strand", "name": "Strand bei Sonnenuntergang", "kern": ["ocean", "waves", "sunset"], "pose": ["walking", "standing", "holding hat"],
     "ausdruck": ["smile", "calm"], "ort": ["beach"], "licht": ["golden hour", "lens flare"], "kamera": ["full body", "from behind", "wide shot"],
     "kleidung": ["sundress", "sun hat"]},
    {"id": "buehne", "name": "Idol-Bühne", "kern": ["concert stage", "microphone", "stage lights", "sparkles"], "pose": ["singing", "dancing", "waving"],
     "ausdruck": ["smile", "open mouth", "happy"], "ort": ["concert stage"], "licht": ["stage lights", "spotlight"],
     "kamera": ["full body", "dynamic angle"], "kleidung": ["idol costume"]},
    {"id": "maidcafe", "name": "Maid-Café", "kern": ["maid outfit", "maid headdress", "tray"], "pose": ["holding tray", "bowing", "standing"],
     "ausdruck": ["smile", "gentle smile"], "ort": ["cafe"], "licht": ["warm lighting"], "kamera": ["cowboy shot"]},
    {"id": "schrein", "name": "Am Schrein", "kern": ["shrine", "torii", "autumn leaves"], "pose": ["standing", "holding broom", "praying"],
     "ausdruck": ["calm", "closed eyes", "gentle smile"], "ort": ["shrine"], "licht": ["dappled sunlight", "golden hour"],
     "kamera": ["full body", "from side"], "kleidung": ["kimono", "hakama"]},
    {"id": "kochen", "name": "Kochen", "kern": ["kitchen", "cooking", "apron", "food"], "pose": ["holding ladle", "standing"],
     "ausdruck": ["smile", "happy"], "ort": ["kitchen"], "licht": ["warm lighting", "morning"], "kamera": ["upper body", "cowboy shot"]},
    {"id": "atelier", "name": "Malen im Atelier", "kern": ["painting", "easel", "paintbrush", "art studio"], "pose": ["holding paintbrush", "sitting"],
     "ausdruck": ["focused", "smile"], "ort": ["art studio"], "licht": ["window light", "soft lighting"], "kamera": ["from side", "cowboy shot"],
     "kleidung": ["apron", "beret"]},
    {"id": "musik", "name": "Musik machen", "kern": ["guitar", "playing guitar", "music notes"], "pose": ["sitting"],
     "ausdruck": ["closed eyes", "smile"], "ort": ["bedroom", "rooftop", "street"], "licht": ["sunset", "soft lighting"], "kamera": ["upper body"]},
    {"id": "spielen", "name": "Videospiele", "kern": ["video game", "game controller", "monitor"], "pose": ["sitting", "holding controller"],
     "ausdruck": ["excited", "focused"], "ort": ["bedroom"], "licht": ["monitor light", "rgb lighting"], "kamera": ["from side", "upper body"],
     "kleidung": ["hoodie", "headphones"]},
    {"id": "drache", "name": "Mit dem Drachen", "kern": ["dragon", "fantasy", "flying"], "pose": ["riding", "standing"],
     "ausdruck": ["determined"], "ort": ["sky", "mountain", "clouds"], "licht": ["sunrise", "dramatic lighting"], "kamera": ["wide shot", "from below"]},
    {"id": "unterwasser", "name": "Unter Wasser", "kern": ["underwater", "fish", "bubbles", "coral reef"], "pose": ["swimming", "floating"],
     "ausdruck": ["calm", "smile"], "ort": ["underwater"], "licht": ["caustics", "god rays"], "kamera": ["full body", "wide shot"]},
    {"id": "zug", "name": "Zugfahrt", "kern": ["train interior", "window", "scenery"], "pose": ["sitting", "looking out window", "chin rest"],
     "ausdruck": ["melancholic", "calm"], "ort": ["train interior"], "licht": ["golden hour", "dappled sunlight"], "kamera": ["upper body", "from side"]},
    {"id": "herbst", "name": "Herbst im Park", "kern": ["autumn", "autumn leaves", "bench"], "pose": ["sitting", "holding leaf"],
     "ausdruck": ["gentle smile"], "ort": ["park"], "licht": ["golden hour"], "kamera": ["cowboy shot"], "kleidung": ["coat", "scarf", "beret"]},
    {"id": "katze", "name": "Mit Katze", "kern": ["cat", "holding cat", "petting"], "pose": ["sitting", "hugging"],
     "ausdruck": ["smile", "happy"], "ort": ["living room", "garden"], "licht": ["soft lighting", "sunlight"], "kamera": ["upper body"]},
    {"id": "portraet", "name": "Porträt", "kern": ["portrait", "looking at viewer"], "pose": ["head tilt", "hand on cheek"],
     "ausdruck": ["smile", "gentle smile", "serious"], "ort": ["simple background", "gradient background"], "licht": ["studio lighting", "rim lighting"],
     "kamera": ["portrait", "close-up", "upper body"]},
    {"id": "landschaft", "name": "Landschaft (ohne Menschen)", "personen": 0, "kern": ["scenery", "no humans", "mountain", "lake", "sky"],
     "ort": ["mountain", "lake"], "licht": ["sunrise", "volumetric lighting"], "kamera": ["wide shot"]},
    {"id": "nachtstadt", "name": "Stadt bei Nacht (ohne Menschen)", "personen": 0, "kern": ["no humans", "cityscape", "night", "city lights", "skyline"],
     "ort": ["cityscape"], "licht": ["neon lighting", "night"], "kamera": ["wide shot", "from above"]},
{"id": "mondbasis", "name": "Mondbasis", "kern": ["astronaut", "moon", "spacesuit", "earth (planet)"], "pose": ["standing", "waving"],
     "ausdruck": ["calm", "smile"], "ort": ["moon", "space"], "licht": ["earthshine", "dramatic lighting"], "kamera": ["full body", "wide shot"],
     "kleidung": ["spacesuit"]},
    {"id": "wanderung", "name": "Bergwanderung", "kern": ["hiking", "backpack", "mountain trail"], "pose": ["walking", "standing"],
     "ausdruck": ["happy", "determined"], "ort": ["mountains", "mountain trail"], "licht": ["sunrise", "dappled sunlight"],
     "kamera": ["full body", "wide shot"], "kleidung": ["jacket", "hiking boots"]},
    {"id": "fahrrad", "name": "Fahrradtour", "kern": ["bicycle", "riding bicycle", "basket"], "pose": ["riding", "standing"],
     "ausdruck": ["smile", "happy"], "ort": ["street", "park"], "licht": ["golden hour", "sunlight"], "kamera": ["full body", "from side"],
     "kleidung": ["casual", "jacket"]},
    {"id": "picknick", "name": "Picknick im Park", "kern": ["picnic", "blanket", "basket", "sandwich"], "pose": ["sitting", "cross-legged"],
     "ausdruck": ["smile", "happy"], "ort": ["park", "flower field"], "licht": ["golden hour", "dappled sunlight"], "kamera": ["cowboy shot", "from above"],
     "kleidung": ["sundress", "casual"]},
    {"id": "kino", "name": "Kinoabend", "kern": ["cinema", "popcorn", "movie theater"], "pose": ["sitting", "holding cup"],
     "ausdruck": ["excited", "focused"], "ort": ["cinema"], "licht": ["screen light", "darkness"], "kamera": ["cowboy shot", "from side"],
     "kleidung": ["hoodie", "jacket"]},
    {"id": "weihnachtsmarkt", "name": "Weihnachtsmarkt", "kern": ["christmas market", "string lights", "lantern"], "pose": ["standing", "walking"],
     "ausdruck": ["smile", "blush"], "ort": ["christmas market", "cityscape"], "licht": ["warm lighting", "night"], "kamera": ["cowboy shot", "from side"],
     "kleidung": ["winter coat", "scarf", "beanie"]},
    {"id": "schneeball", "name": "Schneeballschlacht", "kern": ["snowball fight", "snow", "snowflakes"], "pose": ["running", "throwing"],
     "ausdruck": ["laughing", "happy"], "ort": ["snow field", "park"], "licht": ["soft lighting", "winter daylight"], "kamera": ["full body", "dynamic angle"],
     "kleidung": ["winter coat", "scarf"]},
    {"id": "fruehstueck", "name": "Frühstück", "kern": ["breakfast", "toast", "coffee cup", "table"], "pose": ["sitting", "holding cup"],
     "ausdruck": ["sleepy", "smile"], "ort": ["kitchen", "balcony"], "licht": ["morning", "sunlight"], "kamera": ["cowboy shot", "from above"],
     "kleidung": ["sweater", "casual"]},
    {"id": "buchladen", "name": "Buchladen", "kern": ["bookstore", "bookshelf", "book"], "pose": ["standing", "reaching out"],
     "ausdruck": ["focused", "gentle smile"], "ort": ["bookstore"], "licht": ["soft lighting", "window light"], "kamera": ["cowboy shot", "from side"],
     "kleidung": ["cardigan", "glasses"]},
    {"id": "blumenladen", "name": "Blumenladen", "kern": ["flower shop", "bouquet", "flowers"], "pose": ["standing", "holding flowers"],
     "ausdruck": ["smile", "gentle smile"], "ort": ["flower shop"], "licht": ["soft lighting", "sunlight"], "kamera": ["cowboy shot", "upper body"],
     "kleidung": ["apron", "casual"]},
    {"id": "baeckerei", "name": "Bäckerei", "kern": ["bakery", "bread", "pastry", "tray"], "pose": ["standing", "holding tray"],
     "ausdruck": ["smile", "happy"], "ort": ["bakery"], "licht": ["warm lighting", "morning"], "kamera": ["cowboy shot"],
     "kleidung": ["apron", "chef uniform"]},
    {"id": "labor", "name": "Forschungslabor", "kern": ["laboratory", "microscope", "beaker"], "pose": ["standing", "holding beaker"],
     "ausdruck": ["focused", "thinking"], "ort": ["laboratory"], "licht": ["studio lighting", "cool lighting"], "kamera": ["cowboy shot", "from side"],
     "kleidung": ["lab coat"]},
    {"id": "archaeologie", "name": "Ausgrabung", "kern": ["archaeologist", "ruins", "excavation", "artifact"], "pose": ["kneeling", "holding artifact"],
     "ausdruck": ["focused", "surprised"], "ort": ["ruins", "desert"], "licht": ["sunrise", "dramatic lighting"], "kamera": ["from above", "cowboy shot"],
     "kleidung": ["khaki outfit", "sun hat"]},
    {"id": "detektiv", "name": "Detektivbüro", "kern": ["detective", "office", "magnifying glass", "case files"], "pose": ["sitting", "thinking"],
     "ausdruck": ["serious", "focused"], "ort": ["office"], "licht": ["window light", "noir lighting"], "kamera": ["cowboy shot", "from side"],
     "kleidung": ["suit", "trench coat"]},
    {"id": "journalismus", "name": "Recherche in der Stadt", "kern": ["journalist", "notebook", "camera"], "pose": ["standing", "writing"],
     "ausdruck": ["focused", "determined"], "ort": ["street", "cityscape"], "licht": ["sunset", "dramatic lighting"], "kamera": ["cowboy shot", "from side"],
     "kleidung": ["jacket", "casual"]},
    {"id": "fotostudio", "name": "Fotostudio", "kern": ["photographer", "camera", "studio"], "pose": ["standing", "holding camera"],
     "ausdruck": ["focused", "confident"], "ort": ["studio"], "licht": ["studio lighting", "rim lighting"], "kamera": ["upper body", "from side"],
     "kleidung": ["casual", "jacket"]},
    {"id": "modedesign", "name": "Modedesign", "kern": ["fashion designer", "sewing machine", "fabric", "mannequin"], "pose": ["sitting", "holding fabric"],
     "ausdruck": ["focused", "smile"], "ort": ["atelier"], "licht": ["window light", "soft lighting"], "kamera": ["cowboy shot"],
     "kleidung": ["apron", "cardigan"]},
    {"id": "gewaechshaus", "name": "Gewächshaus", "kern": ["greenhouse", "plants", "watering can"], "pose": ["standing", "watering"],
     "ausdruck": ["gentle smile", "calm"], "ort": ["greenhouse", "garden"], "licht": ["sunlight", "dappled sunlight"], "kamera": ["cowboy shot", "from side"],
     "kleidung": ["apron", "sundress"]},
    {"id": "imkerei", "name": "Imkerei", "kern": ["beekeeper", "beehive", "bees", "flowers"], "pose": ["standing", "holding frame"],
     "ausdruck": ["calm", "smile"], "ort": ["flower field", "garden"], "licht": ["sunlight", "golden hour"], "kamera": ["cowboy shot"],
     "kleidung": ["beekeeper suit", "hat"]},
    {"id": "reiten", "name": "Ausritt", "kern": ["horse riding", "horse", "saddle"], "pose": ["riding", "standing"],
     "ausdruck": ["confident", "happy"], "ort": ["meadow", "forest"], "licht": ["golden hour", "sunrise"], "kamera": ["full body", "from side"],
     "kleidung": ["riding outfit", "boots"]},
    {"id": "segeln", "name": "Segeltörn", "kern": ["sailboat", "sailing", "ocean", "rope"], "pose": ["standing", "holding rope"],
     "ausdruck": ["confident", "smile"], "ort": ["ocean", "sea"], "licht": ["blue hour", "sunset"], "kamera": ["full body", "wide shot"],
     "kleidung": ["sailor outfit", "jacket"]},
    {"id": "kajak", "name": "Kajakfahrt", "kern": ["kayak", "river", "paddle", "life jacket"], "pose": ["sitting", "paddling"],
     "ausdruck": ["happy", "determined"], "ort": ["river", "lake"], "licht": ["sunrise", "dappled sunlight"], "kamera": ["from side", "wide shot"],
     "kleidung": ["life jacket", "sportswear"]},
    {"id": "camping", "name": "Camping", "kern": ["camping", "tent", "campfire", "sleeping bag"], "pose": ["sitting", "warming hands"],
     "ausdruck": ["calm", "smile"], "ort": ["forest", "lake"], "licht": ["firelight", "night"], "kamera": ["cowboy shot", "wide shot"],
     "kleidung": ["jacket", "beanie"]},
    {"id": "teleskop", "name": "Sternenhimmel", "kern": ["telescope", "starry sky", "night sky", "milky way"], "pose": ["standing", "looking up"],
     "ausdruck": ["surprised", "calm"], "ort": ["mountain", "field"], "licht": ["moonlight", "star light"], "kamera": ["from behind", "wide shot"],
     "kleidung": ["winter coat"]},
    {"id": "fruehlingsregen", "name": "Frühlingsregen", "kern": ["spring rain", "umbrella", "puddle", "rain"], "pose": ["walking", "holding umbrella"],
     "ausdruck": ["calm", "melancholic"], "ort": ["street", "park"], "licht": ["soft lighting", "overcast"], "kamera": ["full body", "from side"],
     "kleidung": ["raincoat", "boots"]},
    {"id": "herbstmarkt", "name": "Herbstmarkt", "kern": ["autumn market", "harvest", "apples", "pumpkin"], "pose": ["standing", "holding basket"],
     "ausdruck": ["smile", "happy"], "ort": ["market", "village"], "licht": ["golden hour", "warm lighting"], "kamera": ["cowboy shot"],
     "kleidung": ["coat", "scarf"]},
    {"id": "sternwarte", "name": "Sternwarte", "kern": ["observatory", "telescope", "dome", "night sky"], "pose": ["standing", "looking up"],
     "ausdruck": ["focused", "calm"], "ort": ["observatory", "mountain"], "licht": ["moonlight", "darkness"], "kamera": ["wide shot", "from behind"]},
    {"id": "windmuehle", "name": "Windmühle", "kern": ["windmill", "meadow", "tulips", "clouds"], "pose": ["standing", "walking"],
     "ausdruck": ["smile", "calm"], "ort": ["meadow", "village"], "licht": ["sunrise", "golden hour"], "kamera": ["wide shot", "full body"],
     "kleidung": ["sundress", "sweater"]},
    {"id": "lesenacht", "name": "Lesenacht", "kern": ["reading book", "blanket", "lamp", "bookshelf"], "pose": ["sitting", "reading"],
     "ausdruck": ["calm", "sleepy"], "ort": ["bedroom", "library"], "licht": ["lamp light", "warm lighting"], "kamera": ["upper body", "from above"],
     "kleidung": ["pajamas", "cardigan"]},
]

# Stimmungen: ein Klick, eine ganze Bildsprache (wie die "Presets" im Vorbild, erweitert)
STIMMUNGEN = {
    "weich": {"name": "Weich & pastell", "begriffe": ["pastel colors", "soft colors", "petals", "dreamy atmosphere", "floating particles"]},
    "dunkel": {"name": "Dunkel & gotisch", "begriffe": ["dark theme", "gothic", "night", "dark atmosphere", "moon", "purple theme"]},
    "niedlich": {"name": "Niedlich", "begriffe": ["chibi", "cute", "sparkles", "soft smile", "pastel"]},
    "gemalt": {"name": "Gemalt", "begriffe": ["painting (medium)", "oil painting", "thick brushstrokes", "artistic", "colorful"]},
    "aquarell": {"name": "Aquarell", "begriffe": ["watercolor (medium)", "soft colors", "paper texture", "traditional media"]},
    "cyber": {"name": "Cyberpunk", "begriffe": ["cyberpunk", "neon lights", "futuristic", "holographic", "high contrast"]},
    "fantasy": {"name": "Fantasy", "begriffe": ["fantasy", "magic", "glowing runes", "epic", "ethereal"]},
    "retro": {"name": "Retro-Anime", "begriffe": ["1990s (style)", "retro artstyle", "film grain", "cel shading"]},
}

NEGATIV = ["nsfw", "lowres", "bad anatomy", "bad hands", "missing fingers", "extra digits", "fewer digits", "worst quality", "low quality",
           "jpeg artifacts", "watermark", "signature", "blurry", "deformed", "disfigured", "bad proportions", "extra arms", "extra legs",
           "cropped", "long neck", "mutated hands"]
NEGATIV_EXTRA = ["duplicate", "error", "extra limb", "out of frame", "poorly drawn face", "poorly drawn hands", "malformed"]

# Gruppen, aus denen hoechstens ein Begriff vorkommt
AUSSCHLUSS = [
    ["long hair", "short hair", "bob cut"],
    ["black hair", "blonde hair", "silver hair", "white hair", "pink hair", "blue hair", "purple hair", "red hair", "green hair",
     "brown hair", "gradient hair"],
    ["twin tails", "ponytail", "braid", "hair bun", "bob cut", "hime cut", "wavy hair", "straight hair"],
    ["blue eyes", "red eyes", "green eyes", "purple eyes", "yellow eyes", "pink eyes", "aqua eyes", "brown eyes", "heterochromia"],
    # Pose: hoechstens eine Koerperhaltung
    ["standing", "sitting", "lying", "leaning forward", "looking back", "arms behind head", "stretching", "walking",
     "cross-legged", "hand on hip", "arms crossed", "kneeling", "squatting", "running", "jumping", "dancing",
     "hands in pockets", "hand on chest", "waving", "saluting", "holding cup", "reading book", "playing instrument",
     "adjusting hair", "chin rest", "head tilt", "looking up", "reaching out", "floating", "swimming", "riding"],
    # Aktivitaet: hoechstens eine Hauptbeschaeftigung
    ["reading book", "playing instrument", "holding cup", "fighting stance", "casting spell", "singing", "dancing",
     "cooking", "painting", "praying", "holding broom", "hiking", "riding bicycle", "picnic", "snowball fight",
     "throwing", "photographing", "sewing", "watering", "beekeeping", "horse riding", "sailing", "paddling", "camping",
     "warming hands", "writing", "holding sword", "holding tray", "holding ladle", "holding paintbrush"],
    ["smile", "crying", "pout", "serious", "laughing", "melancholic", "surprised", "blush", "shy", "smirk", "wink"],
    ["full body", "upper body", "cowboy shot", "close-up", "portrait", "wide shot"],
    ["night", "sunset", "sunrise", "golden hour", "blue hour", "morning"],
    ["slim", "slender", "athletic", "tall", "muscular"],
    # Kleidungszustand: hoechstens eine Hauptkleidung
    ["casual", "suit", "armor", "pajamas", "sportswear", "raincoat", "winter coat", "sundress", "kimono", "yukata",
     "maid outfit", "idol costume", "lab coat", "chef uniform", "apron", "hoodie", "sweater", "dress", "trench coat"],
    ["closed eyes", "looking at viewer", "looking back", "looking up", "sleepy"],
    ["indoor", "outdoor"],
]

# Deutsch fuer Begriffe aus Szenen und Stimmungen, die in keinem Topf stehen
DEUTSCH_EXTRA = {
    "holding cup": "mit Tasse", "table": "Tisch", "window": "Fenster", "bookshelf": "Bücherregal", "rain": "Regen", "umbrella": "Regenschirm",
    "puddle": "Pfütze", "reflection": "Spiegelung", "falling petals": "fallende Blüten", "summer festival": "Sommerfest", "paper lantern": "Papierlaterne",
    "fireworks": "Feuerwerk", "lantern light": "Laternenlicht", "night": "Nacht", "sword": "Schwert", "cape": "Umhang", "fighting stance": "Kampfhaltung",
    "holding sword": "hält ein Schwert", "battlefield": "Schlachtfeld", "magic": "Magie", "magic circle": "Zauberkreis", "staff": "Stab",
    "casting spell": "zaubert", "outstretched arm": "ausgestreckter Arm", "floating": "schwebend", "witch hat": "Hexenhut", "cyberpunk": "Cyberpunk",
    "neon lights": "Neonlichter", "holographic display": "Hologramm", "leaning against wall": "an die Wand gelehnt", "jacket": "Jacke",
    "techwear": "Techwear", "space station": "Raumstation", "spacesuit": "Raumanzug", "earth (planet)": "die Erde", "stars": "Sterne",
    "looking out window": "schaut aus dem Fenster", "snow": "Schnee", "snowflakes": "Schneeflocken", "winter": "Winter", "beanie": "Mütze",
    "ocean": "Meer", "waves": "Wellen", "holding hat": "hält den Hut", "sun hat": "Sonnenhut", "concert stage": "Konzertbühne", "microphone": "Mikrofon",
    "stage lights": "Bühnenlicht", "sparkles": "Glitzer", "singing": "singend", "spotlight": "Scheinwerfer", "maid headdress": "Häubchen",
    "tray": "Tablett", "holding tray": "hält ein Tablett", "bowing": "verbeugt sich", "warm lighting": "warmes Licht", "torii": "Torii",
    "autumn leaves": "Herbstlaub", "holding broom": "mit Besen", "praying": "betend", "hakama": "Hakama", "cooking": "kochend", "apron": "Schürze",
    "food": "Essen", "holding ladle": "mit Kochlöffel", "morning": "Morgen", "painting": "Malerei", "easel": "Staffelei", "paintbrush": "Pinsel",
    "art studio": "Atelier", "holding paintbrush": "mit Pinsel", "window light": "Fensterlicht", "guitar": "Gitarre", "playing guitar": "spielt Gitarre",
    "music notes": "Noten", "video game": "Videospiel", "game controller": "Controller", "monitor": "Bildschirm", "holding controller": "mit Controller",
    "monitor light": "Bildschirmlicht", "rgb lighting": "RGB-Licht", "dragon": "Drache", "fantasy": "Fantasy", "flying": "fliegend", "riding": "reitend",
    "sky": "Himmel", "clouds": "Wolken", "fish": "Fische", "bubbles": "Luftblasen", "coral reef": "Korallenriff", "caustics": "Lichtspiel im Wasser",
    "train interior": "im Zug", "scenery": "Landschaft", "autumn": "Herbst", "bench": "Bank", "holding leaf": "hält ein Blatt", "coat": "Mantel",
    "cat": "Katze", "holding cat": "hält eine Katze", "petting": "streichelt", "hugging": "umarmt", "living room": "Wohnzimmer", "sunlight": "Sonnenlicht",
    "hand on cheek": "Hand an der Wange", "gradient background": "Verlaufshintergrund", "no humans": "ohne Menschen", "city lights": "Stadtlichter",
    "skyline": "Skyline", "pastel colors": "Pastellfarben", "soft colors": "sanfte Farben", "petals": "Blütenblätter", "dreamy atmosphere": "verträumt",
    "floating particles": "schwebende Teilchen", "dark theme": "dunkel", "gothic": "gotisch", "dark atmosphere": "düstere Stimmung", "moon": "Mond",
    "purple theme": "in Lila", "chibi": "Chibi", "cute": "niedlich", "soft smile": "sanftes Lächeln", "pastel": "pastell",
    "painting (medium)": "Gemälde", "oil painting": "Ölgemälde", "thick brushstrokes": "dicke Pinselstriche", "artistic": "künstlerisch",
    "colorful": "farbenfroh", "watercolor (medium)": "Aquarell", "paper texture": "Papierstruktur", "traditional media": "traditionell gemalt",
    "futuristic": "futuristisch", "holographic": "holografisch", "high contrast": "starker Kontrast", "glowing runes": "leuchtende Runen",
    "epic": "episch", "ethereal": "ätherisch", "1990s (style)": "90er-Stil", "retro artstyle": "Retro-Stil", "film grain": "Filmkorn",
    "cel shading": "Cel-Shading", "nsfw": "nicht jugendfrei", "lowres": "niedrige Auflösung", "bad anatomy": "falsche Anatomie",
    "bad hands": "falsche Hände", "missing fingers": "fehlende Finger", "extra digits": "zu viele Finger", "fewer digits": "zu wenige Finger",
    "worst quality": "schlechteste Qualität", "low quality": "schlechte Qualität", "jpeg artifacts": "JPEG-Fehler", "watermark": "Wasserzeichen",
    "signature": "Signatur", "blurry": "unscharf", "deformed": "verformt", "disfigured": "entstellt", "bad proportions": "falsche Proportionen",
    "extra arms": "zu viele Arme", "extra legs": "zu viele Beine", "cropped": "abgeschnitten", "long neck": "langer Hals",
    "mutated hands": "verformte Hände", "duplicate": "doppelt", "error": "Fehler", "extra limb": "zusätzliche Gliedmaßen",
    "out of frame": "außerhalb des Bildes", "poorly drawn face": "schlecht gezeichnetes Gesicht", "poorly drawn hands": "schlecht gezeichnete Hände",
    "malformed": "missgebildet", "crying": "weinend", "swimming": "schwimmend", "jacket, headphones": "Jacke und Kopfhörer",
}

DEUTSCH_EXTRA.update({
    "astronaut": "Astronautin", "earthshine": "Erdenschein", "hiking": "Wanderung", "backpack": "Rucksack",
    "mountain trail": "Bergpfad", "mountains": "Berge", "hiking boots": "Wanderschuhe", "bicycle": "Fahrrad",
    "riding bicycle": "fährt Fahrrad", "basket": "Korb", "picnic": "Picknick", "blanket": "Decke",
    "sandwich": "Sandwich", "cinema": "Kino", "popcorn": "Popcorn", "movie theater": "Kinosaal",
    "screen light": "Bildschirmlicht", "darkness": "Dunkelheit", "christmas market": "Weihnachtsmarkt",
    "string lights": "Lichterkette", "lantern": "Laterne", "snowball fight": "Schneeballschlacht",
    "throwing": "werfend", "winter daylight": "Winterlicht", "breakfast": "Frühstück", "toast": "Toast",
    "coffee cup": "Kaffeetasse", "bookstore": "Buchladen", "book": "Buch", "flower shop": "Blumenladen",
    "bouquet": "Blumenstrauß", "flowers": "Blumen", "holding flowers": "hält Blumen", "bakery": "Bäckerei",
    "bread": "Brot", "pastry": "Gebäck", "laboratory": "Labor", "microscope": "Mikroskop", "beaker": "Becher",
    "holding beaker": "hält einen Becher", "cool lighting": "kühles Licht", "archaeologist": "Archäologin",
    "excavation": "Ausgrabung", "artifact": "Artefakt", "holding artifact": "hält ein Artefakt",
    "khaki outfit": "Khaki-Outfit", "detective": "Detektivin", "office": "Büro", "magnifying glass": "Lupe",
    "case files": "Akten", "noir lighting": "Noir-Licht", "journalist": "Journalistin", "notebook": "Notizbuch",
    "camera": "Kamera", "writing": "schreibend", "photographer": "Fotografin", "studio": "Studio",
    "holding camera": "hält eine Kamera", "fashion designer": "Modedesignerin", "sewing machine": "Nähmaschine",
    "fabric": "Stoff", "mannequin": "Schaufensterpuppe", "holding fabric": "hält Stoff", "atelier": "Atelier",
    "greenhouse": "Gewächshaus", "plants": "Pflanzen", "watering can": "Gießkanne", "watering": "gießend",
    "beekeeper": "Imkerin", "beehive": "Bienenstock", "bees": "Bienen", "holding frame": "hält einen Rahmen",
    "beekeeper suit": "Imkeranzug", "hat": "Hut", "horse riding": "Reiten", "horse": "Pferd", "saddle": "Sattel",
    "meadow": "Wiese", "riding outfit": "Reitkleidung", "boots": "Stiefel", "sailboat": "Segelboot",
    "sailing": "segelnd", "rope": "Seil", "holding rope": "hält ein Seil", "sea": "See", "sailor outfit": "Matrosenoutfit",
    "kayak": "Kajak", "river": "Fluss", "paddle": "Paddel", "life jacket": "Rettungsweste", "paddling": "paddelnd",
    "sportswear": "Sportkleidung", "camping": "Camping", "tent": "Zelt", "campfire": "Lagerfeuer",
    "sleeping bag": "Schlafsack", "warming hands": "wärmt die Hände", "telescope": "Teleskop",
    "starry sky": "Sternenhimmel", "milky way": "Milchstraße", "field": "Feld", "star light": "Sternenlicht",
    "spring rain": "Frühlingsregen", "holding umbrella": "hält einen Regenschirm", "overcast": "bewölkt",
    "autumn market": "Herbstmarkt", "harvest": "Ernte", "apples": "Äpfel", "pumpkin": "Kürbis",
    "holding basket": "hält einen Korb", "market": "Markt", "village": "Dorf", "observatory": "Sternwarte",
    "dome": "Kuppel", "windmill": "Windmühle", "tulips": "Tulpen", "lamp": "Lampe", "reading": "lesend",
    "lamp light": "Lampenlicht",
})

# Begriffe, die H0rSt in Paketen und KI-Antworten nicht durchlaesst: Inhalte fuer Erwachsene und alles, was nach Kindern klingt
_SPERRE = re.compile(
    r"\b(nsfw|nude|naked|nudity|topless|bottomless|sex|sexual|porn\w*|hentai|erotic\w*|lewd|nipples?|areola\w*|pussy|vagina\w*|penis|"
    r"cum\w*|orgasm\w*|masturbat\w*|fellatio|blowjob|paizuri|ahegao|bondage|shibari|lingerie|underwear|panties|bra|no bra|see-through|"
    r"cleavage|underboob|sideboob|breasts?|ass|butt|crotch|groin|spread legs|fetish|bdsm|rape|loli\w*|shota\w*|child\w*|kids?|toddler|"
    r"underage|minor|young girl|young boy|little girl|little boy|baby|infant|preteen|teen\w*|schoolgirl|school uniform|serafuku|jk|"
    r"elementary school|kindergarten|randoseru|petite|flat chest|aged down)\b", re.I)
# "nsfw" darf im Negativ-Prompt stehen (er haelt solche Bilder ja fern)
_NUR_POSITIV = re.compile(r"^nsfw$", re.I)


def gesperrt(begriff):
    return bool(_SPERRE.search(str(begriff or "")))


def sperren(begriffe, negativ=False):
    """Liste von Begriffen ohne die gesperrten (im Negativ-Prompt bleibt "nsfw")."""
    return [b for b in begriffe if not gesperrt(b) or (negativ and _NUR_POSITIV.match(str(b).strip()))]


def deutsch():
    """englisch -> deutsch fuer alle eingebauten Begriffe."""
    d = dict(DEUTSCH_EXTRA)
    for liste in TOEPFE.values():
        for en, de in liste:
            d.setdefault(en, de)
    return d


def daten():
    """Alles, was das Prompt Studio der Oberflaeche braucht (ohne Pakete)."""
    return {"toepfe": {k: [en for en, _ in v] for k, v in TOEPFE.items()}, "topf_namen": TOPF_NAMEN, "szenen": SZENEN,
            "stimmungen": STIMMUNGEN, "negativ": NEGATIV, "negativ_extra": NEGATIV_EXTRA, "ausschluss": AUSSCHLUSS,
            "deutsch": deutsch(), "figuren": []}


def _liste(wert, laenge=60, anzahl=300):
    if not isinstance(wert, list):
        return []
    return sperren([" ".join(str(x).split())[:laenge] for x in wert if isinstance(x, str) and x.strip()][:anzahl])


def paket_pruefen(roh):
    """Paket (JSON) fuer das Prompt Studio pruefen: {"name", "toepfe": {topf: [..]}, "szenen": [..], "stimmungen": {..},
    "figuren": [{"name", "begriffe": [..]}], "deutsch": {en: de}}. Gesperrte Begriffe fallen weg. ValueError, wenn nichts bleibt."""
    if not isinstance(roh, dict):
        raise ValueError("Paket als JSON-Objekt erwartet")
    p = {"name": " ".join(str(roh.get("name") or "Paket").split())[:80], "toepfe": {}, "szenen": [], "stimmungen": {}, "figuren": [], "deutsch": {}}
    for topf, liste in (roh.get("toepfe") or {}).items() if isinstance(roh.get("toepfe"), dict) else []:
        if re.match(r"^[a-z_]{1,30}$", str(topf)) and _liste(liste):
            p["toepfe"][topf] = _liste(liste)
    for s in (roh.get("szenen") or [])[:100] if isinstance(roh.get("szenen"), list) else []:
        if not isinstance(s, dict) or not s.get("name"):
            continue
        szene = {"id": re.sub(r"[^a-z0-9_]", "", str(s.get("id") or s["name"]).lower())[:30] or "szene", "name": str(s["name"])[:60]}
        for feld in ("kern", "pose", "ausdruck", "ort", "licht", "kamera", "kleidung"):
            szene[feld] = _liste(s.get(feld), anzahl=20)
        if szene["kern"] and not gesperrt(szene["name"]):
            szene["personen"] = 0 if s.get("personen") == 0 else 1
            p["szenen"].append(szene)
    for k, s in (roh.get("stimmungen") or {}).items() if isinstance(roh.get("stimmungen"), dict) else []:
        if isinstance(s, dict) and _liste(s.get("begriffe")) and not gesperrt(s.get("name")):
            p["stimmungen"][re.sub(r"[^a-z0-9_]", "", str(k).lower())[:30] or "stimmung"] = {
                "name": str(s.get("name") or k)[:60], "begriffe": _liste(s.get("begriffe"), anzahl=20)}
    for f in (roh.get("figuren") or [])[:300] if isinstance(roh.get("figuren"), list) else []:
        if isinstance(f, dict) and f.get("name") and not gesperrt(f["name"]) and _liste(f.get("begriffe")):
            p["figuren"].append({"name": str(f["name"])[:80], "begriffe": _liste(f.get("begriffe"), anzahl=10)})
    for en, de in (roh.get("deutsch") or {}).items() if isinstance(roh.get("deutsch"), dict) else []:
        if isinstance(de, str) and not gesperrt(en) and not gesperrt(de):
            p["deutsch"][str(en)[:60]] = de[:60]
    if not (p["toepfe"] or p["szenen"] or p["stimmungen"] or p["figuren"]):
        raise ValueError("Im Paket ist nichts Brauchbares (Töpfe, Szenen, Stimmungen oder Figuren)")
    return p


def prompt_pruefen(prompt):
    """Bild-Prompts, die Inhalte fuer Erwachsene mit Kindern verbinden, lehnt H0rSt ab (ValueError)."""
    text = str(prompt or "")
    kind = re.search(r"\b(loli\w*|shota\w*|child\w*|kids?|toddler|underage|minor|young girl|young boy|little girl|little boy|"
                     r"baby|infant|preteen|elementary school|kindergarten|aged down)\b", text, re.I)
    erwachsen = re.search(r"\b(nsfw|nude|naked|nudity|sex\w*|porn\w*|hentai|erotic\w*|lewd|nipples?|pussy|penis|cum\w*|"
                          r"orgasm\w*|lingerie|underwear|panties|bondage|fetish)\b", text, re.I)
    if kind and erwachsen:
        raise ValueError("Dieser Prompt verbindet Kinder mit Inhalten für Erwachsene – das erzeugt H0rSt nicht.")
