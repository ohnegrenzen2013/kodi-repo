"""Understand-Anything (github.com/Egonex-AI/Understand-Anything) auf diesem Rechner installieren:
KI-Coding-Skills fuer externe KI-Werkzeuge (Claude Code, Codex, Gemini CLI, Cline u. a.), nicht fuer
H0rSt selbst. Laeuft wie ollama_setup.ServerInstallation als Hintergrund-Thread (Muster
xdcc_client.Auftrag), ruft das offizielle install.sh ueber stdin an "sh -s --" auf - feste
Repo-/Skript-Adresse (anders als das Original, das per Umgebungsvariable UA_REPO_URL eine beliebige
Adresse erlaubt: ein von H0rSt aus frei eintragbares Repo wuerde ungeprueften Fremdcode beliebiger
Herkunft ausfuehren), Plattform-Id gegen eine feste Liste geprueft, bevor sie als Kommandozeilen-
Argument an das Skript geht."""

import shutil
import subprocess
import threading
import urllib.request

INSTALL_SKRIPT_URL = "https://raw.githubusercontent.com/Egonex-AI/Understand-Anything/main/install.sh"
ZEITLIMIT = 300  # Sekunden - git clone/pull + Symlinks setzen, kein grosser Download

# Plattform-Ids aus dem offiziellen install.sh (platforms_table()) - fest uebernommen, nicht vom Nutzer
# frei eintragbar, damit nie eine unbekannte Kennung als Kommandozeilen-Argument durchgeht.
PLATTFORMEN = ("gemini", "codex", "opencode", "pi", "openclaw", "antigravity", "vibe", "vscode",
               "hermes", "cline", "kimi", "trae", "nanobot", "kiro")


class UnderstandAnythingFehler(Exception):
    pass


class Installation:
    """Installieren/Aktualisieren/Entfernen teilen sich denselben Zustand und denselben Thread-Typ - alle
    drei rufen dasselbe Skript nur mit anderen Argumenten auf, immer nur einer zur Zeit."""

    def __init__(self, holen=None):
        self.holen = holen or (lambda url: urllib.request.urlopen(url, timeout=30))
        self._sperre = threading.Lock()
        self.laeuft = False
        self.fertig = False
        self.ok = None
        self.aktion = ""
        self.ausgabe = ""

    def zustand(self):
        return {"laeuft": self.laeuft, "fertig": self.fertig, "ok": self.ok, "aktion": self.aktion,
                "ausgabe": self.ausgabe, "git_verfuegbar": bool(shutil.which("git"))}

    def installieren(self, plattform):
        if plattform not in PLATTFORMEN:
            raise UnderstandAnythingFehler("Unbekannte Plattform: %s" % plattform)
        self._starten("installieren", [plattform])

    def aktualisieren(self):
        self._starten("aktualisieren", ["--update"])

    def entfernen(self, plattform):
        if plattform not in PLATTFORMEN:
            raise UnderstandAnythingFehler("Unbekannte Plattform: %s" % plattform)
        self._starten("entfernen", ["--uninstall", plattform])

    def _starten(self, aktion, argumente):
        with self._sperre:
            if self.laeuft:
                raise UnderstandAnythingFehler("Es läuft bereits eine Aktion")
            self.laeuft = True
            self.fertig = False
            self.ok = None
            self.aktion = aktion
            self.ausgabe = ""
        threading.Thread(target=self._lauf, args=(argumente,), name="understand-anything", daemon=True).start()

    def _lauf(self, argumente):
        if not shutil.which("git"):
            self._abschliessen(False, "git ist auf diesem Rechner nicht installiert")
            return
        try:
            with self.holen(INSTALL_SKRIPT_URL) as antwort:
                skript = antwort.read().decode("utf-8", "replace")
        except Exception as fehler:
            self._abschliessen(False, "Installationsskript nicht ladbar: %s" % fehler)
            return
        try:
            # "--" trennt sh's eigene Optionen von den Positionsparametern des Skripts - sonst wuerde z. B.
            # "--update" von sh selbst als (unbekannte) Option statt als $1 des Skripts interpretiert.
            ergebnis = subprocess.run(["sh", "-s", "--"] + argumente, input=skript, capture_output=True,
                                      text=True, timeout=ZEITLIMIT)
            text = (ergebnis.stdout or "") + (ergebnis.stderr or "")
        except subprocess.TimeoutExpired:
            self._abschliessen(False, "Zeitlimit überschritten (%d s)" % ZEITLIMIT)
            return
        except Exception as fehler:
            self._abschliessen(False, str(fehler))
            return
        self._abschliessen(ergebnis.returncode == 0, text[-4000:])

    def _abschliessen(self, ok, ausgabe):
        with self._sperre:
            self.laeuft = False
            self.fertig = True
            self.ok = ok
            self.ausgabe = ausgabe
