"""UNiQuanteX-Analyse: extrahiert Design-Tokens aus einer App-URL.

Nur stdlib, kein requests/BeautifulSoup. Folgt bis zu 2 Stylesheet-Links
und extrahiert:
  - :root-CSS-Custom-Properties (Farben, Radien, Abstaende)
  - @font-face family-Namen
  - dominante Farben (nach Haeufigkeit der Hex-Werte im CSS)
  - abgeleiteter UNiQuanteX-Stil-Vorschlag (body.stil-<key> { ... })
"""
from __future__ import annotations
import re
import urllib.request
import urllib.parse

from . import netz

_TIMEOUT = 10
_MAX_CSS_BYTES = 300_000
_MAX_HTML_BYTES = 500_000
_RE_HEX = re.compile(r'#([0-9a-fA-F]{6}|[0-9a-fA-F]{3})\b')
_RE_ROOT = re.compile(r':root\s*\{([^}]+)\}', re.DOTALL)
_RE_PROP = re.compile(r'(--[\w-]+)\s*:\s*([^;]+);')
_RE_FONT_FACE = re.compile(r"@font-face\s*\{([^}]+)\}", re.DOTALL)
_RE_FONT_FAMILY = re.compile(r'font-family\s*:\s*["\']?([^;"\',]+)["\']?')
_RE_STYLESHEET = re.compile(r'<link[^>]+rel=["\']stylesheet["\'][^>]*href=["\']([^"\']+)["\']', re.IGNORECASE)
_RE_STYLESHEET2 = re.compile(r'<link[^>]+href=["\']([^"\']+)["\'][^>]*rel=["\']stylesheet["\']', re.IGNORECASE)


class AnaliseFehler(ValueError):
    pass


def _ssrf_pruefen(url: str) -> None:
    """Blockt private/loopback-Adressen (SSRF-Schutz)."""
    try:
        netz.ip_oeffentlich_pruefen(url)
    except netz.NetzFehler as fehler:
        raise AnaliseFehler(str(fehler))


def _laden(url: str, max_bytes: int) -> str:
    req = urllib.request.Request(url, headers={"User-Agent": "H0rSt-UNiQuanteX/1.0"})
    with netz.oeffentlich_oeffnen(req, timeout=_TIMEOUT) as resp:
        return resp.read(max_bytes).decode("utf-8", errors="replace")


def _css_links(html: str, basis_url: str) -> list[str]:
    treffer = _RE_STYLESHEET.findall(html) + _RE_STYLESHEET2.findall(html)
    absolut = []
    for href in dict.fromkeys(treffer):  # Reihenfolge behalten, Duplikate entfernen
        absolut.append(urllib.parse.urljoin(basis_url, href))
    return absolut[:2]


def _root_props(css: str) -> dict[str, str]:
    ergebnis = {}
    for block in _RE_ROOT.finditer(css):
        for name, wert in _RE_PROP.findall(block.group(1)):
            ergebnis[name.strip()] = wert.strip()
    return ergebnis


def _font_namen(css: str) -> list[str]:
    namen = []
    for block in _RE_FONT_FACE.finditer(css):
        m = _RE_FONT_FAMILY.search(block.group(1))
        if m:
            namen.append(m.group(1).strip())
    return list(dict.fromkeys(namen))[:4]


def _dominante_farben(css: str, top_n: int = 8) -> list[str]:
    zaehler: dict[str, int] = {}
    for m in _RE_HEX.finditer(css):
        h = m.group(1).upper()
        if len(h) == 3:
            h = h[0]*2 + h[1]*2 + h[2]*2
        zaehler[f"#{h}"] = zaehler.get(f"#{h}", 0) + 1
    sortiert = sorted(zaehler, key=lambda k: -zaehler[k])
    return sortiert[:top_n]


def _props_filtern(props: dict[str, str]) -> dict[str, str]:
    """Nur Farb- und Geometrie-Properties behalten."""
    relevant = {}
    for k, v in props.items():
        v_kurz = v.lower().strip()
        if any(hinweis in v_kurz for hinweis in ("#", "rgb", "hsl", "oklch", "px", "rem", "%", "em")):
            relevant[k] = v
    return relevant


def _css_vorschlag(key: str, farben: list[str], fonts: list[str], props: dict[str, str]) -> str:
    """Erzeugt einen minimalen body.stil-<key>-Vorschlag."""
    grund = farben[0] if farben else "#0d0d0d"
    akzent = farben[1] if len(farben) > 1 else "#ffffff"
    font = f'"{fonts[0]}", sans-serif' if fonts else "sans-serif"
    zeilen = [
        f"body.stil-{key} {{",
        f"  --grund: {grund};",
        f"  --flaeche: color-mix(in srgb, {grund} 85%, white);",
        f"  --akzent: {akzent};",
        "  --akzent-text: #fff;",
        "  --text: #e8e8e8;",
        "  --leise: #888;",
        f"  --linie: color-mix(in srgb, {akzent} 30%, transparent);",
        f"  background: {grund};",
        f"  font-family: {font};",
        "  /* TODO: Farben und Tokens manuell verfeinern */",
        "}",
    ]
    # Bekannte Props direkt übernehmen
    bekannte = {"--bild-rund", "--rl-rund", "--schatten"}
    for prop in bekannte:
        if prop in props:
            zeilen.insert(-1, f"  {prop}: {props[prop]};")
    return "\n".join(zeilen)


def analysiere(url: str, name: str = "") -> dict:
    """Analysiert url und gibt UNiQuanteX-Design-Tokens zurück.

    Rückgabe:
      url, key (abgeleiteter Stil-Schlüssel), farben, fonts, props,
      css_vorschlag, css_links
    """
    _ssrf_pruefen(url)
    html = _laden(url, _MAX_HTML_BYTES)

    css_gesamt = ""
    css_urls = _css_links(html, url)
    for css_url in css_urls:
        try:
            _ssrf_pruefen(css_url)
            css_gesamt += _laden(css_url, _MAX_CSS_BYTES) + "\n"
        except (AnaliseFehler, OSError):
            pass

    props = _props_filtern(_root_props(css_gesamt))
    fonts = _font_namen(css_gesamt)
    farben = _dominante_farben(css_gesamt)

    if name:
        key = re.sub(r"[^a-z0-9]", "", name.lower())[:16] or "neu"
    else:
        host = urllib.parse.urlparse(url).hostname or "neu"
        key = re.sub(r"[^a-z0-9]", "", host.lower().split(".")[0])[:16] or "neu"

    vorschlag = _css_vorschlag(key, farben, fonts, props)

    return {
        "url": url,
        "key": key,
        "farben": farben,
        "fonts": fonts,
        "props": props,
        "css_vorschlag": vorschlag,
        "css_links": css_urls,
    }
