"""Zusaetzliche Untertitelquellen: SubSource, SubDL und Addic7ed (Ideen aus CloudStream, eigener Code).

SubSource und SubDL liefern ZIP-Pakete; H0rSt entpackt die erste Untertiteldatei und legt sie unter
`<Datenordner>/untertitel` ab. Die Oberflaeche und das Stremio-Addon bekommen eine Adresse dieses Servers
(`/api/untertitel/<datei>`), damit Browser, App und Kodi die Datei ohne CORS-/Referer-Probleme laden.

Einstellungen (Nutzerdaten): subsource_an (Standard true), subdl_key, addic7ed_an (Standard false).
"""

import hashlib
import html
import io
import os
import re
import zipfile
from urllib.parse import urlencode, urljoin

from .netz import (NetzFehler, antwort_holen, antwort_holen_roh, oeffentlich_antwort_holen,
                   oeffentlich_antwort_holen_roh)

SUBSOURCE = "https://api.subsource.net/v1"
SUBDL = "https://api.subdl.com"
SUBDL_DL = "https://dl.subdl.com"
ADDIC7ED = "https://www.addic7ed.com"
MAX_DATEI = 5 * 1024 * 1024
ENDUNGEN = (".srt", ".vtt", ".ass", ".ssa")
UA = "Rezeptserver-Untertitel"


class UntertitelFehler(ValueError):
    pass


def _txt(wert):
    return html.unescape(re.sub(r"<[^>]+>", "", str(wert or ""))).strip()


class UntertitelQuellen:
    def __init__(self, datenordner, holen=None, holen_roh=None):
        self.ordner = os.path.join(datenordner or ".", "untertitel")
        self.holen = holen or oeffentlich_antwort_holen(antwort_holen)
        self.holen_roh = holen_roh or oeffentlich_antwort_holen_roh(antwort_holen_roh)

    def _pfad(self, name):
        if not re.match(r"^[a-f0-9]{40}\.(srt|vtt|ass|ssa)$", name or ""):
            raise UntertitelFehler("Unbekannte Datei")
        return os.path.join(self.ordner, name)

    def datei(self, name):
        pfad = self._pfad(name)
        try:
            with open(pfad, "rb") as f:
                return f.read()
        except OSError:
            raise UntertitelFehler("Untertitel nicht gefunden")

    # --- Abruf und Entpacken --------------------------------------------------------
    def _abruf(self, url, methode="GET", header=None, daten=None, roh=False):
        kopf = {"User-Agent": UA, **(header or {})}
        try:
            status, text = (self.holen_roh(url, methode, kopf, daten) if roh
                            else self.holen(url, methode, kopf, daten))
        except NetzFehler as fehler:
            raise UntertitelFehler(str(fehler))
        if status >= 300:
            raise UntertitelFehler("HTTP %d" % status)
        if roh:
            return text if isinstance(text, bytes) else text.encode("utf-8", "replace")
        return text if isinstance(text, str) else text.decode("utf-8", "replace")

    def _speichern(self, inhalt, endung=".srt"):
        os.makedirs(self.ordner, exist_ok=True)
        name = hashlib.sha1(inhalt).hexdigest() + endung
        pfad = os.path.join(self.ordner, name)
        if not os.path.exists(pfad):
            with open(pfad, "wb") as f:
                f.write(inhalt)
        return name

    def _entpacken(self, inhalt):
        try:
            with zipfile.ZipFile(io.BytesIO(inhalt)) as z:
                for name in z.namelist():
                    if name.lower().endswith(ENDUNGEN):
                        with z.open(name) as e:
                            daten = e.read(MAX_DATEI)
                        return daten, os.path.splitext(name)[1].lower()
        except (zipfile.BadZipFile, OSError):
            pass
        return inhalt[:MAX_DATEI], ".srt"

    def _zip(self, url, header=None):
        daten = self._abruf(url, header=header, roh=True)
        inhalt, endung = self._entpacken(daten)
        return self._speichern(inhalt, endung)

    # --- SubSource ---------------------------------------------------------------
    def _subsource(self, imdb, staffel, folge, sprachen):
        if not imdb:
            return []
        import json
        text = self._abruf(SUBSOURCE + "/movie/search", "POST", {"Content-Type": "application/json"},
                           json.dumps({"includeSeasons": False, "limit": 15, "query": imdb, "signal": "{}"}))
        try:
            treffer = (json.loads(text).get("results") or [{}])[0]
        except (ValueError, AttributeError, IndexError):
            return []
        link = str(treffer.get("link") or "").replace("series", "subtitles")
        if not link:
            return []
        seite = self._abruf(SUBSOURCE + link)
        try:
            untertitel = json.loads(seite).get("subtitles") or []
        except (ValueError, AttributeError):
            return []
        ergebnis = []
        for u in untertitel:
            if not isinstance(u, dict) or not u.get("link"):
                continue
            if str(u.get("release_type") or "").lower() == "trailer":
                continue
            code = _sprachcode(u.get("language"))
            if sprachen and code not in sprachen:
                continue
            if staffel and folge and ("E%02d" % folge) not in str(u.get("release_info") or ""):
                continue
            try:
                detail = json.loads(self._abruf(SUBSOURCE + "/subtitle/" + str(u["link"]).lstrip("/")))
                token = ((detail.get("subtitle") or {}).get("download_token"))
                if not token:
                    continue
                name = self._zip(SUBSOURCE + "/subtitle/download/" + str(token))
            except (UntertitelFehler, ValueError, AttributeError):
                continue
            ergebnis.append({"url": "api/untertitel/" + name, "lang": code or "und",
                             "name": _txt(u.get("release_info")) or "SubSource"})
        return ergebnis

    # --- SubDL -------------------------------------------------------------------
    def _subdl(self, key, imdb, titel, jahr, staffel, folge, sprachen):
        if not key:
            return []
        import json
        werte = {"api_key": key, "languages": ",".join(sprachen or ["DE"])}
        if imdb:
            werte["imdb_id"] = imdb
        else:
            werte["film_name"] = titel
        if jahr:
            werte["year"] = jahr
        if staffel:
            werte["season_number"] = staffel
        if folge:
            werte["episode_number"] = folge
        text = self._abruf(SUBDL + "/api/v1/subtitles?" + urlencode(werte), header={"Accept": "application/json"})
        try:
            antwort = json.loads(text)
        except ValueError:
            return []
        ergebnis = []
        for u in (antwort.get("subtitles") or [])[:10]:
            if not isinstance(u, dict) or not u.get("url"):
                continue
            code = _sprachcode(u.get("lang") or u.get("language"))
            if sprachen and code not in sprachen:
                continue
            try:
                name = self._zip(SUBDL_DL + str(u["url"]))
            except UntertitelFehler:
                continue
            ergebnis.append({"url": "api/untertitel/" + name, "lang": code or "und",
                             "name": _txt(u.get("release_name") or u.get("name")) or "SubDL"})
        return ergebnis

    # --- Addic7ed ----------------------------------------------------------------
    def _addic7ed(self, titel, staffel, folge, sprachen):
        if not titel:
            return []
        suche = "%s %s %s" % (titel, staffel or "", folge or "")
        text = self._abruf(ADDIC7ED + "/search.php?" + urlencode({"search": suche.strip(), "Submit": "Search"}))
        ziele = re.findall(r'href="(/serie/[^"]+|/movie/[^"]+)"', text, re.I)
        ergebnis = []
        for ziel in ziele[:3]:
            try:
                seite = self._abruf(urljoin(ADDIC7ED, ziel), header={"Referer": ADDIC7ED + "/"})
            except UntertitelFehler:
                continue
            for treffer in re.finditer(r'href="(/original/[^"]+|/updated/[^"]+)"[^>]*>([^<]*)<', seite, re.I):
                code = _sprachcode(treffer.group(2))
                if sprachen and code not in sprachen:
                    continue
                try:
                    roh = self._abruf(urljoin(ADDIC7ED, treffer.group(1)), header={"Referer": ADDIC7ED + "/"}, roh=True)
                    name = self._speichern(roh, ".srt")
                except UntertitelFehler:
                    continue
                ergebnis.append({"url": "api/untertitel/" + name, "lang": code or "und", "name": "Addic7ed"})
        return ergebnis

    def suchen(self, anfrage, wunsch, daten):
        """Alle eingeschalteten Quellen zu einer Anfrage; liefert [{url, lang, name}]."""
        sprachen = [s.lower() for s in (wunsch or [])]
        imdb = str(((anfrage.get("ids") or {}).get("imdb")) or "")
        titel = str(anfrage.get("titel") or anfrage.get("text") or "")
        jahr = anfrage.get("jahr")
        staffel, folge = anfrage.get("staffel"), anfrage.get("folge")
        ergebnis = []
        if daten.get("subsource_an", True):
            try:
                ergebnis.extend(self._subsource(imdb, staffel, folge, sprachen))
            except (UntertitelFehler, OSError):
                pass
        if daten.get("subdl_key"):
            try:
                ergebnis.extend(self._subdl(str(daten["subdl_key"]), imdb, titel, jahr, staffel, folge, sprachen))
            except (UntertitelFehler, OSError):
                pass
        if daten.get("addic7ed_an"):
            try:
                ergebnis.extend(self._addic7ed(titel, staffel, folge, sprachen))
            except (UntertitelFehler, OSError):
                pass
        return ergebnis


def _sprachcode(wert):
    w = str(wert or "").strip().lower()
    return {"german": "de", "deutsch": "de", "english": "en", "englisch": "en", "french": "fr", "spanish": "es",
            "italian": "it", "portuguese": "pt", "russian": "ru", "turkish": "tr", "polish": "pl", "dutch": "nl",
            "japanese": "ja", "korean": "ko", "chinese": "zh", "arabic": "ar"}.get(w, w[:5])
