"""USB Magic: USB-Datentraeger auf dem H0rSt-Rechner finden, einhaengen (mounten), aushaengen und sicher auswerfen.

Nur gewoehnliche, gefahrlose Datentraeger-Arbeit: Sticks und Platten anzeigen, einhaengen, um darauf zu sichern oder
Dateien zu zeigen (ueber den Dateibrowser, dateien.py), und wieder sicher zu entfernen. H0rSt haengt nur **Wechsel-
Datentraeger** ein (removable oder am USB-Bus), nie die Systemplatte, und immer mit nosuid,nodev; nach Moeglichkeit
ueber udisks (ohne Root), sonst ueber `mount`. Fremde Pfade oder Geraete-Knoten vom Browser werden nie angefasst – es
geht nur, was in der erkannten Liste steht.

Android (ohne Root) meldet angesteckte OTG-Speicher ueber die App (dateien.app_orte); dort gibt es hier nichts zu mounten.
"""

import os
import re
import shutil
import subprocess

MOUNT_WURZEL = "/run/h0rst-usb"
# Dateisysteme, die wir einhaengen; der Rest (z. B. Systempartitionen) bleibt in Ruhe
FS_OK = ("vfat", "exfat", "ntfs", "ntfs3", "ext2", "ext3", "ext4", "f2fs", "hfsplus", "btrfs", "udf", "iso9660")
_KNOTEN = re.compile(r"^/dev/(sd[a-z]+[0-9]*|mmcblk[0-9]+(p[0-9]+)?|nvme[0-9]+n[0-9]+(p[0-9]+)?)$")


class UsbFehler(ValueError):
    pass


def _lauf(befehl, eingabe=None):
    """Ein Systembefehl ohne Shell: (code, ausgabe). Fehlt das Programm, code 127."""
    try:
        e = subprocess.run(befehl, capture_output=True, text=True, timeout=30, input=eingabe)
        return e.returncode, (e.stdout or "") + (e.stderr or "")
    except FileNotFoundError:
        return 127, ""
    except (OSError, subprocess.SubprocessError) as f:
        return 1, str(f)


def _lesen(pfad):
    try:
        with open(pfad, encoding="utf-8", errors="replace") as f:
            return f.read().strip()
    except OSError:
        return ""


def _mounts(pfad="/proc/mounts"):
    """{geraet: mountpunkt} der aktuell eingehaengten Geraete (entschluesselt Oktal-Escapes wie \\040)."""
    aus = {}
    for zeile in _lesen(pfad).splitlines():
        t = zeile.split()
        if len(t) >= 2 and t[0].startswith("/dev/"):
            aus[t[0]] = re.sub(r"\\0([0-7][0-7])", lambda m: chr(int(m.group(1), 8)), t[1])
    return aus


def _wechsel_knoten(sysfs="/sys/block"):
    """Namen der Wechsel-Datentraeger (removable=1 oder Transport usb): {"sdb", "mmcblk0", …}."""
    namen = set()
    try:
        scheiben = os.listdir(sysfs)
    except OSError:
        return namen
    for name in scheiben:
        basis = os.path.join(sysfs, name)
        if _lesen(os.path.join(basis, "removable")) == "1":
            namen.add(name)
            continue
        ziel = os.path.realpath(basis)  # .../usbX/.../block/sdb -> am USB-Bus?
        if "/usb" in ziel and "/block/" in ziel:
            namen.add(name)
    return namen


def _lsblk(lauf=_lauf):
    """Geraetebaum von lsblk (JSON) oder None, wenn lsblk fehlt."""
    import json
    code, aus = lauf(["lsblk", "-J", "-b", "-o", "NAME,PATH,SIZE,FSTYPE,LABEL,MOUNTPOINT,RM,HOTPLUG,TYPE,VENDOR,MODEL,RO"])
    if code != 0 or not aus.strip():
        return None
    try:
        return json.loads(aus)
    except ValueError:
        return None


def _groesse_lesbar(bytes_):
    if not bytes_:
        return ""
    einheiten = ["B", "KB", "MB", "GB", "TB"]
    z = float(bytes_)
    for e in einheiten:
        if z < 1024 or e == einheiten[-1]:
            return ("%.0f %s" if z >= 10 or e == "B" else "%.1f %s") % (z, e)
        z /= 1024


def _frei(mountpunkt):
    try:
        u = shutil.disk_usage(mountpunkt)
        return {"frei": u.free, "gesamt": u.total}
    except OSError:
        return {"frei": None, "gesamt": None}


def _aus_lsblk(baum):
    """Partitionen (und partitionslose Datentraeger) aus dem lsblk-Baum zu flachen Eintraegen."""
    funde = []

    def geh(knoten, platte):
        hotplug = knoten.get("hotplug") in (True, "1", 1) or knoten.get("rm") in (True, "1", 1)
        kinder = knoten.get("children") or []
        if knoten.get("type") in ("part", "rom") or (knoten.get("type") == "disk" and not kinder):
            funde.append({"platte": platte, "hotplug": hotplug, "knoten": knoten})
        for k in kinder:
            geh(k, platte or knoten)

    for platte in baum.get("blockdevices", []):
        geh(platte, None)
    return funde


def geraete(lsblk=_lsblk, mounts=_mounts, wechsel=_wechsel_knoten, sysfs="/sys/block"):
    """Angesteckte USB-/Wechsel-Datentraeger: [{knoten, name, groesse, fs, label, eingehaengt, pfad, schreibbar, auswerfbar}].

    Nutzt lsblk (JSON), wenn vorhanden; sonst /proc/mounts und /sys/block. Nur Wechsel-Datentraeger, nie die Systemplatte."""
    eingehaengt = mounts()
    baum = lsblk()
    funde = []
    if baum is not None:
        for e in _aus_lsblk(baum):
            k, platte = e["knoten"], e["platte"]
            knoten = k.get("path") or "/dev/" + (k.get("name") or "")
            if not (e["hotplug"] or (platte or {}).get("hotplug")) or not _KNOTEN.match(knoten):
                continue
            mp = k.get("mountpoint") or eingehaengt.get(knoten) or ""
            funde.append(_eintrag(knoten, k.get("size"), k.get("fstype") or "", k.get("label") or "",
                                  mp, k.get("ro") in (True, "1", 1),
                                  " ".join(x for x in [(platte or {}).get("vendor"), (platte or {}).get("model")] if x).strip()))
    else:
        namen = wechsel(sysfs) if wechsel is _wechsel_knoten else wechsel()
        for name in sorted(namen):
            basis = os.path.join(sysfs, name)
            teile = sorted(p for p in os.listdir(basis) if p.startswith(name)) if os.path.isdir(basis) else []
            modell = (_lesen(os.path.join(basis, "device/vendor")) + " " + _lesen(os.path.join(basis, "device/model"))).strip()
            for t in (teile or [name]):
                knoten = "/dev/" + t
                sektoren = _lesen(os.path.join(basis, t if t != name else "", "size")) or "0"
                groesse = int(sektoren) * 512 if sektoren.isdigit() else 0
                funde.append(_eintrag(knoten, groesse, "", "", eingehaengt.get(knoten, ""), False, modell))
    return [g for g in funde if _KNOTEN.match(g["knoten"])]


def _eintrag(knoten, groesse, fs, label, mountpunkt, nur_lesbar, modell):
    g = {"knoten": knoten, "name": label or modell or os.path.basename(knoten), "modell": modell.strip(),
         "groesse": int(groesse or 0), "groesse_text": _groesse_lesbar(int(groesse or 0)), "fs": fs, "label": label,
         "eingehaengt": bool(mountpunkt), "pfad": mountpunkt, "nur_lesbar": bool(nur_lesbar),
         "mountbar": not mountpunkt and (not fs or fs in FS_OK), "auswerfbar": bool(mountpunkt)}
    g.update(_frei(mountpunkt) if mountpunkt else {"frei": None, "gesamt": None})
    g["schreibbar"] = bool(mountpunkt) and not nur_lesbar and os.access(mountpunkt, os.W_OK)
    return g


def _finde(knoten, lsblk=_lsblk, mounts=_mounts, wechsel=_wechsel_knoten):
    g = next((x for x in geraete(lsblk, mounts, wechsel) if x["knoten"] == knoten), None)
    if not g:
        raise UsbFehler("Dieser USB-Datenträger ist nicht (mehr) angesteckt")
    return g


def einhaengen(knoten, nur_lesbar=False, lauf=_lauf, lsblk=_lsblk, mounts=_mounts, wechsel=_wechsel_knoten):
    """Einen Wechsel-Datentraeger einhaengen; nach Moeglichkeit ueber udisks (ohne Root), sonst `mount`. (pfad, hinweis)."""
    if not _KNOTEN.match(str(knoten or "")):
        raise UsbFehler("Kein gültiger Datenträger")
    g = _finde(knoten, lsblk, mounts, wechsel)
    if g["eingehaengt"]:
        return g["pfad"], "War schon eingehängt"
    if not g["mountbar"]:
        raise UsbFehler("Dieses Dateisystem (%s) hängt H0rSt nicht ein" % (g["fs"] or "unbekannt"))
    if shutil.which("udisksctl"):
        code, aus = lauf(["udisksctl", "mount", "-b", knoten] + (["--options", "ro"] if nur_lesbar else []))
        m = re.search(r"Mounted .* at (\S+)", aus)
        if code == 0 and m:
            return m.group(1).rstrip("."), "Eingehängt (udisks)"
        if "AlreadyMounted" in aus:
            return _finde(knoten, lsblk, mounts, wechsel)["pfad"], "War schon eingehängt"
    ziel = os.path.join(MOUNT_WURZEL, os.path.basename(knoten))
    try:
        os.makedirs(ziel, exist_ok=True)
    except OSError as f:
        raise UsbFehler("Einhängeordner nicht möglich: %s" % f)
    opt = "nosuid,nodev" + (",ro" if nur_lesbar else "")
    code, aus = lauf(["mount", "-o", opt, knoten, ziel])
    if code == 0:
        return ziel, "Eingehängt"
    if code == 127:
        raise UsbFehler("Einhängen geht auf diesem System nicht (weder udisks noch mount verfügbar). "
                        "Auf dem Raspberry Pi/Linux als root starten oder udisks2 installieren.")
    raise UsbFehler("Einhängen fehlgeschlagen: %s" % (aus.strip() or "unbekannt"))


def ganze_platte(knoten):
    """Geraeteknoten ohne Partition fuer das Abschalten: /dev/sdb1 -> /dev/sdb, /dev/mmcblk0p1 ->
    /dev/mmcblk0, /dev/nvme0n1p2 -> /dev/nvme0n1. Partitionslose Knoten (mmcblk0, nvme0n1) bleiben, wie sie sind."""
    m = re.match(r"^(/dev/(?:nvme\d+n\d+|mmcblk\d+))p\d+$", str(knoten or ""))
    if m:
        return m.group(1)
    m = re.match(r"^(/dev/sd[a-z]+)\d+$", str(knoten or ""))
    return m.group(1) if m else knoten


def aushaengen(knoten, auswerfen=False, lauf=_lauf, lsblk=_lsblk, mounts=_mounts, wechsel=_wechsel_knoten):
    """Aushaengen (und auf Wunsch sicher abschalten). Puffer werden vorher geschrieben, damit nichts verloren geht."""
    if not _KNOTEN.match(str(knoten or "")):
        raise UsbFehler("Kein gültiger Datenträger")
    g = _finde(knoten, lsblk, mounts, wechsel)
    if not g["eingehaengt"]:
        return "War nicht eingehängt"
    lauf(["sync"])
    if shutil.which("udisksctl"):
        code, aus = lauf(["udisksctl", "unmount", "-b", knoten])
        if code == 0:
            if not auswerfen:
                return "Ausgehängt"
            code, aus = lauf(["udisksctl", "power-off", "-b", ganze_platte(knoten)])
            if code == 0:
                return "Sicher entfernt – Stick kann ab"
            return "Ausgehängt – das Gerät ließ sich nicht abschalten: %s" % (aus.strip() or "unbekannt")
        if "NotMounted" in aus:
            return "War nicht eingehängt"
    code, aus = lauf(["umount", knoten])
    if code == 0:
        return "Sicher entfernt – Stick kann ab" if auswerfen else "Ausgehängt"
    if code == 127:
        raise UsbFehler("Aushängen geht auf diesem System nicht (umount fehlt)")
    raise UsbFehler("Aushängen fehlgeschlagen (ist eine Datei noch offen?): %s" % (aus.strip() or "unbekannt"))
