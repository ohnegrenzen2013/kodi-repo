"""USB-Tools: verschlüsselte Datenträger, VeraCrypt-Hilfen und Recovery-Werkzeuge.

Die Liste ergänzt USB Magic. Sie verlinkt freie Apps und Werkzeuge, die VeraCrypt-
Container oder verschlüsselte USB-Speicher öffnen, prüfen oder verwalten. Krypto-
Werkzeuge zum Knacken fremder Container stehen ausdrücklich nur als Sicherheits-
forschung/Recovery für eigene Datenträger dabei – mit Warnung.
"""

STAND = "2026-11-05"
GRUPPEN = [
    ("crypted", "Crypted – Android & Tresore"),
    ("veracrypt", "VeraCrypt & Container"),
    ("recovery", "Recovery & Sicherheitsforschung"),
    ("nicht", "Nicht übernommen / Gefahr"),
]

TOOLS = [
    {"id": "arcanum", "name": "Arcanum", "gruppe": "crypted", "art": "Android-App", "status": "ok",
     "url": "https://arcanum.zip", "lizenz": "Open Source (siehe Seite)",
     "text": "VeraCrypt-kompatibler verschlüsselter Tresor für Android: ein Container als Datei, ohne Cloud. "
             "Für eigene Container und Backups auf USB/SD."},
    {"id": "otgmaster", "name": "OTG Master", "gruppe": "crypted", "art": "Android-App", "status": "ok",
     "url": "https://moylali.github.io/OTGMaster/", "lizenz": "siehe Projekt",
     "text": "Öffnet verschlüsselte USB-Massenspeicher per OTG auf Android ohne Root: VeraCrypt, LUKS1/LUKS2 "
             "und BitLocker mit FAT32, exFAT, NTFS, ext4; dazu APFS-Laufwerke von Macs."},
    {"id": "vaultpony", "name": "VaultPony", "gruppe": "crypted", "art": "App (iOS/Android)", "status": "ok",
     "url": "https://vaultpony.app", "lizenz": "Open Source",
     "text": "VeraCrypt-kompatible verschlüsselte Vaults für iPhone, iPad und Android: versteckte Volumes, "
             "15 Verfahren/Kaskaden, Keyfiles, kein Konto und keine Cloud."},
    {"id": "androidcrypt", "name": "androidCrypt", "gruppe": "crypted", "art": "Android-App", "status": "ok",
     "url": "https://github.com/jmccoy600/androidCrypt", "lizenz": "siehe Projekt",
     "text": "Android-App für VeraCrypt-verschlüsselte Dateicontainer; Quellcode auf GitHub."},

    {"id": "veracrypt-jp", "name": "veracrypt.jp", "gruppe": "veracrypt", "art": "Info-Seite", "status": "prüfen",
     "url": "https://veracrypt.jp", "lizenz": "Info",
     "text": "Japanische VeraCrypt-Infoseite. Nicht die offizielle Veracrypt-Downloadseite; für Downloads "
             "veracrypt.fr bzw. das offizielle GitHub-Projekt nutzen."},
    {"id": "veracrypt-docker", "name": "veracrypt-in-docker", "gruppe": "veracrypt", "art": "Docker", "status": "ok",
     "url": "https://github.com/larserdmann/veracrypt-in-docker", "lizenz": "GPL-3.0",
     "text": "Docker-Container für automatisierte VeraCrypt-Verschlüsselung; auch für Skripte und NAS-Betrieb."},
    {"id": "veracrypt-sdk", "name": "VeraCrypt-SDK", "gruppe": "veracrypt", "art": "SDK", "status": "ok",
     "url": "https://github.com/veracrypt/VeraCrypt-SDK", "lizenz": "siehe VeraCrypt",
     "text": "C/C++-SDK zum programmatischen Erzeugen von VeraCrypt-Containern und Formatieren von Partitionen "
             "mit thread-sicherer DLL-Schnittstelle."},
    {"id": "veracrypt-mount", "name": "veracrypt-mount", "gruppe": "veracrypt", "art": "Docker", "status": "ok",
     "url": "https://github.com/tomerh2001/veracrypt-mount", "lizenz": "siehe Projekt",
     "text": "Docker-Image, das VeraCrypt-Volumes in Containern einhängt – auch mehrere Unterordner; für "
             "abgeschottete Dienste mit verschlüsselter Ablage."},
    {"id": "jellyfin-veracrypt", "name": "Jellyfin + VeraCrypt + systemd", "gruppe": "veracrypt", "art": "Anleitung", "status": "prüfen",
     "url": "https://gitlab.com/harmlessteddy/automation-of-jellyfin-using-docker_veracrypt_systemd", "lizenz": "siehe Projekt",
     "text": "GitLab-Anleitung/Automatisierung für Jellyfin in Docker mit VeraCrypt und systemd. GitLab antwortet derzeit "
             "mit 429 (zu viele Anfragen); Inhalt, Stand und Skripte vor dem Einsatz prüfen."},
    {"id": "linuxmuster-veracrypt", "name": "linuxmuster-client-veracrypt", "gruppe": "veracrypt", "art": "Client", "status": "ok",
     "url": "https://github.com/linuxmuster/linuxmuster-client-veracrypt", "lizenz": "siehe Projekt",
     "text": "VeraCrypt-Downloader und Installer für den linuxmuster-Client; für verwaltete Linux-Schulumgebungen."},
    {"id": "veracrypt-dcs", "name": "VeraCrypt-DCS", "gruppe": "veracrypt", "art": "Offizielles Projekt", "status": "ok",
     "url": "https://gitlab.com/veracrypt/VeraCrypt-DCS", "lizenz": "siehe VeraCrypt",
     "text": "VeraCrypt-DCS aus der offiziellen VeraCrypt-GitLab-Gruppe. Zweck und Stand auf der Projektseite prüfen."},
    {"id": "veracrypt-appimage", "name": "veracrypt-appimage", "gruppe": "veracrypt", "art": "AppImage", "status": "ok",
     "url": "https://github.com/myristicinC/veracrypt-appimage", "lizenz": "siehe Projekt",
     "text": "VeraCrypt als AppImage für Linux – ohne Systeminstallation startbar."},
    {"id": "veracrypt-appimage-builder", "name": "veracrypt-appimage-builder", "gruppe": "veracrypt", "art": "AppImage-Builder", "status": "ok",
     "url": "https://github.com/Kasi07/veracrypt-appimage-builder", "lizenz": "siehe Projekt",
     "text": "Skript, das die neueste VeraCrypt-Fassung als AppImage paketiert."},
    {"id": "veracrypt-mounter", "name": "veracrypt-mounter", "gruppe": "veracrypt", "art": "Werkzeug", "status": "unbekannt",
     "url": "https://gitlab.com/segfault3/veracrypt-mounter", "lizenz": "siehe Projekt",
     "text": "GitLab-Projekt ohne Beschreibung. Vor dem Einsatz README, Stand und Vertrauenswürdigkeit prüfen."},

    {"id": "veracryptcrack", "name": "veracryptcrack", "gruppe": "recovery", "art": "Recovery", "status": "warn",
     "url": "https://github.com/BillDietrich/veracryptcrack", "lizenz": "siehe Projekt",
     "text": "Wörterbuch-basierter Test eigener VeraCrypt-Container. Nur für eigene Datenträger und Recovery; "
             "keine fremden Passwörter, keine Umgehung von Rechten. Langsam und ohne Erfolgsgarantie."},
    {"id": "veracrypt-self-destruct", "name": "VeraCrypt Self-Destruct (BusKill)", "gruppe": "recovery", "art": "Hardware", "status": "warn",
     "url": "https://github.com/BusKill/veracrypt-self-destruct", "lizenz": "siehe Projekt",
     "text": "BusKill-Trigger, der VeraCrypt-Volumes bei Trennung selbst zerstört. Nur für eigene Geräte und "
             "mit vorher getestetem Backup – ein Fehlauslöser löscht sonst unwiederbringlich."},
    {"id": "veracrypt-bruteforcer", "name": "veracrypt-bruteforcer", "gruppe": "recovery", "art": "Recovery", "status": "warn",
     "url": "https://github.com/willshiao/veracrypt-bruteforcer", "lizenz": "siehe Projekt",
     "text": "Node.js-Programm, das Passwörter aus einer Wortliste gegen ein VeraCrypt-Volume testet. Nur für "
             "eigene Container; keine fremden Systeme."},
    {"id": "veracrypt-password-extractor", "name": "VeraCrypt Password Extractor", "gruppe": "recovery", "art": "Proof of Concept", "status": "warn",
     "url": "https://github.com/D4stiny/Veracrypt-Password-Extractor", "lizenz": "siehe Projekt",
     "text": "Proof-of-Concept-DLL, die ein eingegebenes VeraCrypt-Passwort mitschreibt. Nur für eigene Testsysteme; "
             "der Einsatz an fremden Geräten ist strafbar und wird von H0rSt nicht unterstützt."},
    {"id": "veracracker", "name": "VeraCracker", "gruppe": "recovery", "art": "Recovery", "status": "warn",
     "url": "https://github.com/NorthernSec/VeraCracker", "lizenz": "siehe Projekt",
     "text": "VeraCrypt-Passworttest für eigene Container. Kein Dietrich gegen fremde Datenträger; Prüfe vorher, "
             "ob du Eigentümer bist und ein Backup hast."},

    {"id": "password-sniffer", "name": "VeraCryptPasswordSniffer", "gruppe": "nicht", "art": "Gefahr", "status": "gefahr",
     "url": "https://github.com/Allevon412/VeraCryptPasswordSniffer", "lizenz": "siehe Projekt",
     "text": "Manipuliert Windows-Anwendungen und schreibt eingegebene VeraCrypt-Passwörter mit. Das ist ein "
             "Credential-Diebstahl-Werkzeug. H0rSt übernimmt es nicht und öffnet den Link nicht als Werkzeug."},
    {"id": "veracrypt-stealer", "name": "veracrypt-stealer", "gruppe": "nicht", "art": "Gefahr", "status": "gefahr",
     "url": "https://github.com/geobour98/veracrypt-stealer", "lizenz": "siehe Projekt",
     "text": "Ein ausdrücklich als Stealer bezeichnetes Werkzeug zum Auslesen fremder VeraCrypt-Zugänge. "
             "Wird aus Sicherheitsgründen nicht integriert und nicht verlinkt."},
    {"id": "fetchit", "name": "FetchIt", "gruppe": "nicht", "art": "Fremd-App", "status": "fremd",
     "url": "https://github.com/tharunbirla/FetchIt", "lizenz": "MIT",
     "text": "Android-App zum Herunterladen von Videos verschiedener Plattformen (Kotlin, MIT). Kein USB-, "
             "VeraCrypt- oder Datenträger-Werkzeug; deshalb hier nur als geprüfter Fremdfund vermerkt."},
    {"id": "veracrypt-crack-free", "name": "veracrypt-crack-free-download-in-2025", "gruppe": "nicht", "art": "Crack-Falle", "status": "gefahr",
     "url": "https://gitlab.com/diroccolymu7725/veracrypt-crack-free-download-in-2025", "lizenz": "unbekannt",
     "text": "Crack-/Download-Seite in einem fremden GitLab-Projekt. Solche Angebote sind typische Malware- oder "
             "Raubkopie-Fallen; H0rSt verlinkt sie nicht und lädt nichts davon."},
]


def zustand():
    return {"stand": STAND, "gruppen": [{"id": i, "name": n} for i, n in GRUPPEN],
            "tools": [dict(t) for t in TOOLS],
            "hinweis": "Verschlüsselte USB-Speicher: H0rSt hängt Datenträger nur ein, entschlüsselt sie nicht "
                       "heimlich und speichert keine Passwörter. Apps und Werkzeuge öffnen eigene Container; "
                       "Recovery- und Krypto-Tests nur an eigenen Datenträgern."}
