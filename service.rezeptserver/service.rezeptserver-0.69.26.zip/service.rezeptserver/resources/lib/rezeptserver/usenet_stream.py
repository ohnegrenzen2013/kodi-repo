"""Usenet-Streaming-Modus: NZB-Treffer ordnen, Sofort-Streams erkennen, Auto-Weiter, Ersatzsuche, Statuspruefung.

Vorbild ist UsenetStreamer (Sanket9225/UsenetStreamer, ISC-Lizenz): Indexer suchen, Treffer nach Aufloesung/Quelle/
Groesse ordnen, die gewaehlte NZB in NzbDAV (oder AltMount) einbinden und die Videodatei per WebDAV mit Range-Anfragen
abspielen, waehrend noch geladen wird. Der Code hier ist eigen geschrieben (Python statt Node), uebernommen ist nur
die Idee. Das Einbinden und Abspielen selbst steckt schon in dienste_downloads_sabnzbd.NzbDav.streamen und
stremio_debrid.usenet_weiter; dieses Modul ergaenzt:

  * konfig(ui)       Einstellungen des Modus (None = Modus aus, dann aendert sich nichts am bisherigen Verhalten)
  * ordnen(...)      Ausschluesse, Groessen- und Aufloesungsgrenzen, Duplikate, Sortierung, Grenze je Aufloesung
  * suchplan(...)    Newznab-Anfragen mit Ersatzstufen (Kennung -> Text), wenn der Indexer nichts findet
  * job_name(...)    Der Ordnername eines Jobs in NzbDAV (gleiche Regel wie beim Einbinden)
  * sofort_namen()   Welche Jobs NzbDAV schon fertig hat (Zwischenspeicher), Stream bekommt "Sofort"
  * status(...)      Pruefliste fuer die Oberflaeche: was fehlt noch zum Streamen?
Alles ohne Netz testbar; Zugangsdaten werden nie ausgegeben.
"""

import threading
import time

from .usenet_stream_grund import *  # noqa: F403

_sperre = threading.Lock()
_fertig = {}   # (anbieter-id, kategorie) -> (zeit, frozenset der Ordnernamen)


def suchplan(anfrage, torznab=False):
    """Newznab-Parameter in der Reihenfolge, in der sie probiert werden. Die erste Stufe ist genau die bisherige
    (anbindungen_anbieter.newznab_parameter), danach folgen Ersatzstufen mit anderer Kennung oder als Text."""
    from .anbindungen_anbieter import newznab_parameter
    erste = newznab_parameter(anfrage, torznab)
    plan = [erste]
    if torznab:
        return plan
    art = anfrage.get("art")
    ids = anfrage.get("ids") or {}
    imdb = str(ids.get("imdb") or "")
    titel = str(anfrage.get("titel") or anfrage.get("text") or "").strip()
    jahr = anfrage.get("jahr")
    staffel, folge = anfrage.get("staffel"), anfrage.get("folge")
    if art == "serie" and staffel is not None:
        if imdb.startswith("tt"):
            plan.append({"t": "tvsearch", "imdbid": imdb[2:], "season": staffel, "ep": folge if folge is not None else "",
                         "cat": "5000"})
        if titel and folge is not None:
            plan.append({"t": "search", "q": "%s S%02dE%02d" % (titel, int(staffel), int(folge)), "cat": "5000"})
    elif art == "film":
        if titel:
            plan.append({"t": "search", "q": ("%s %s" % (titel, jahr)).strip() if jahr else titel, "cat": "2000"})
    elif art == "serie" and titel:
        plan.append({"t": "search", "q": titel, "cat": "5000"})
    ergebnis = []
    for p in plan:
        if p not in ergebnis:
            ergebnis.append(p)
    return ergebnis[:MAX_STUFEN]


# --- Sofort: schon fertige Jobs in NzbDAV/AltMount ----------------------------------------------------------

def sofort_namen(streamer, uhr=time.monotonic):
    """Ordnernamen (und deren normalisierte Form) aller fertigen Jobs in Movies und TV der eingerichteten
    Usenet-Streamer [(id, client)]. Zwischenspeicher 60 s; nicht erreichbar -> leer, nie ein Fehler."""
    ergebnis = set()
    for aid, client in streamer:
        for kategorie in KATEGORIEN:
            schluessel = (aid, kategorie)
            with _sperre:
                alt = _fertig.get(schluessel)
            if alt and uhr() - alt[0] < SOFORT_GUELTIG:
                ergebnis |= alt[1]
                continue
            try:
                namen = set(client.fertige(kategorie))
            except Exception:  # NzbDAV aus, WebDAV-Zugang falsch ...: dann eben kein Sofort
                namen = set()
            namen |= {norm(n) for n in namen}
            with _sperre:
                _fertig[schluessel] = (uhr(), frozenset(namen))
            ergebnis |= namen
    return ergebnis


def cache_leeren():
    with _sperre:
        _fertig.clear()


# --- Auto-Weiter: mehrere Kandidaten hintereinander ----------------------------------------------------------

def kandidaten_paket(paare, anzahl):
    """Die ersten anzahl NZB-Paare als [[url, name], ...] fuer den Auto-Weiter-Stream."""
    ergebnis = []
    for treffer, stream in paare:
        if stream.get("nzb") and stream.get("url") and stream["url"] not in [u for u, _ in ergebnis]:
            ergebnis.append([str(stream["url"]), str(treffer.get("titel") or "video")])
        if len(ergebnis) >= anzahl:
            break
    return ergebnis


# --- Status -------------------------------------------------------------------------------------------------

def _punkt(pid, titel, ok, text, tipp="", pflicht=True):
    return {"id": pid, "titel": titel, "ok": bool(ok), "text": text, "tipp": "" if ok else tipp, "pflicht": pflicht}


def status(daten, dienste, ui, rustnzb_da=False):
    """Pruefliste {"bereit", "modus_an", "punkte": [...], "streamer": [{id, name, typ}]}. Keine Zugangsdaten darin.

    daten: Nutzerdaten (Anbieter/Einstellungen), dienste: {id: Client}, ui: Oberflaechen-Werte."""
    from . import anbindungen, easynews
    ui = ui or {}
    streamer = [{"id": aid, "name": getattr(c, "name", "") or getattr(c, "typ_name", aid), "typ": getattr(c, "typ", "")}
                for aid, c in sorted((dienste or {}).items()) if getattr(c, "typ", "") in ("nzbdav", "altmount")]
    indexer = [e.get("name") or i for typ in ("newznab", "binsearch") for i, e, _w in anbindungen.eigene(daten or {}, typ)]
    en_benutzer, en_pass = easynews.zugang(daten or {})
    nntp = [i for i, _e, w in anbindungen.eigene(daten or {}, "nntp")
            if str(w.get("host") or "").strip() and w.get("user") and w.get("pass")]
    basis = basis_adresse(ui.get("usenet_basis_url"))
    punkte = [
        _punkt("streamer", "Streaming-Dienst (NzbDAV oder AltMount)", streamer or rustnzb_da,
               ("Eingerichtet: " + ", ".join(s["name"] for s in streamer)) if streamer else
               ("rustnzb ist eingerichtet (streamt über seine Mediathek)." if rustnzb_da else
                "Fehlt: NzbDAV oder AltMount läuft noch nicht bei H0rSt."),
               "Einstellungen → Anbieter & Addons → Vorlage „NzbDAV (Usenet-Streaming)“: Adresse, API-Schlüssel "
               "(NzbDAV: Settings → SABnzbd) und WebDAV-Zugang (Settings → WebDAV) eintragen."),
        _punkt("indexer", "Suche (Newznab-Indexer, binsearch oder Easynews)", indexer or (en_benutzer and en_pass),
               ("Eingerichtet: " + ", ".join(indexer + (["Easynews"] if en_benutzer and en_pass else []))) if
               (indexer or (en_benutzer and en_pass)) else "Fehlt: noch keine Quelle, die Usenet-Treffer liefert.",
               "Anbieter & Addons → Vorlage wählen, z. B. NZBgeek, NZBFinder, NZBHydra2 oder „binsearch“ (ohne Konto)."),
        _punkt("provider", "Usenet-Provider (NNTP) – nur für Gesundheitsprüfung", nntp,
               "Eingetragen: %d" % len(nntp) if nntp else "Nicht eingetragen. NzbDAV braucht den Provider selbst; "
               "hier wird er nur für die Gesundheitsprüfung gebraucht.",
               "Anbieter & Addons → Vorlage „Newshosting“ oder ein anderer Usenet-Server.", pflicht=False),
        _punkt("adresse", "Adresse für Stremio (HTTPS von unterwegs)", basis.startswith("https://"),
               ("Eingestellt: " + basis) if basis else "Nicht eingestellt: H0rSt nimmt die Adresse, unter der Stremio "
               "es gerade erreicht (Host-Kopf, bei HTTPS-Proxy X-Forwarded-Proto).",
               "Nur nötig, wenn Stremio von außerhalb zugreift: deine HTTPS-Adresse (z. B. https://name.duckdns.org) "
               "unter Einstellungen → Usenet-Streaming eintragen.", pflicht=False),
        _punkt("modus", "Streaming-Modus eingeschaltet", bool(ui.get("usenet_modus_an")),
               "An: Treffer werden geordnet, ⚡ erkannt und Auto-Weiter angeboten." if ui.get("usenet_modus_an") else
               "Aus: Es gibt weiter die einfachen NzbDAV-Streams, aber ohne Ordnung, ⚡ und Auto-Weiter.",
               "Unten einschalten.", pflicht=False),
    ]
    bereit = all(p["ok"] for p in punkte if p["pflicht"])
    return {"bereit": bereit, "modus_an": bool(ui.get("usenet_modus_an")), "punkte": punkte, "streamer": streamer,
            "sortierungen": SORTIERUNGEN}
