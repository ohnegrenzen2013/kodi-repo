"""Usenet-Streaming-Modus: Einstellungen, Release-Merkmale und das Ordnen der NZB-Treffer.

Die reine Logik ohne Netz: konfig() liest die Oberflaechen-Werte, merkmale()/norm() lesen den Release-Namen,
ordnen()/anwenden() filtern, entdoppeln und sortieren. Empfehlungen, Sofort-Erkennung, Ersatzsuche und die
Pruefliste der Oberflaeche stehen in usenet_stream.py.
"""

import re
from urllib.parse import urlsplit

from . import deutsch_wertung, filtern

SORTIERUNGEN = {"qualitaet": "Beste Qualität zuerst (Auflösung, Quelle, Größe)",
                "groesse": "Größte Datei zuerst",
                "klein": "Kleinste Datei zuerst (spart Daten)",
                "neu": "Neueste zuerst"}
MAX_STUFEN = 3          # Anfragen je Indexer und Suche (erste Stufe plus Ersatz)
SOFORT_GUELTIG = 60.0   # Sekunden: so lange gilt die Liste fertiger Jobs
KATEGORIEN = ("Movies", "TV")

_AUFLOESUNG = re.compile(r"(?i)(?<![a-z0-9])(2160p|4k|uhd|1080[pi]|720p|576p|480p)(?![a-z0-9])")
_QUELLEN = (
    (re.compile(r"(?i)(?<![a-z0-9])remux(?![a-z0-9])"), "REMUX", 7),
    (re.compile(r"(?i)(?<![a-z0-9])(blu-?ray|bdrip|brrip|bd25|bd50)(?![a-z0-9])"), "BluRay", 6),
    (re.compile(r"(?i)(?<![a-z0-9])web[-. ]?dl(?![a-z0-9])"), "WEB-DL", 5),
    (re.compile(r"(?i)(?<![a-z0-9])(webrip|web)(?![a-z0-9])"), "WEBRip", 4),
    (re.compile(r"(?i)(?<![a-z0-9])(hdtv|pdtv|dvb|tvrip)(?![a-z0-9])"), "HDTV", 3),
    (re.compile(r"(?i)(?<![a-z0-9])(dvd(?:rip|scr)?|dvd9)(?![a-z0-9])"), "DVD", 2),
    (re.compile(r"(?i)(?<![a-z0-9])(cam|hdcam|ts|hdts|telesync|telecine|tc)(?![a-z0-9])"), "CAM/TS", 0),
)
_CODEC = ((re.compile(r"(?i)av1"), "AV1"), (re.compile(r"(?i)(x265|h[. ]?265|hevc)"), "HEVC"),
          (re.compile(r"(?i)(x264|h[. ]?264|avc)"), "H.264"))
_GRUPPE = re.compile(r"-([A-Za-z0-9]{2,15})(?:\.[a-z0-9]{2,4})?$")
_HDR = re.compile(r"(?i)(?<![a-z0-9])(hdr10\+?|hdr|dv|dolby[. ]?vision)(?![a-z0-9])")


def _zahl(wert, standard=0, kleinste=0, groesste=100000):
    try:
        return max(kleinste, min(groesste, int(float(str(wert).replace(",", ".")))))
    except (TypeError, ValueError):
        return standard


def konfig(ui):
    """Einstellungen des Modus aus den Oberflaechen-Werten, None wenn der Modus aus ist."""
    ui = ui or {}
    if not ui.get("usenet_modus_an"):
        return None
    sortierung = ui.get("usenet_sortierung") or "qualitaet"
    ausschluss = [w.strip().lower() for w in re.split(r"[,;\n]+", str(ui.get("usenet_ausschluss") or "")) if w.strip()]
    return {
        "sortierung": sortierung if sortierung in SORTIERUNGEN else "qualitaet",
        "max_bytes": _zahl(ui.get("usenet_max_gb"), 0, 0, 1000) * (1 << 30),
        "min_aufloesung": _zahl(ui.get("usenet_min_aufloesung"), 0, 0, 4320),
        "max_aufloesung": _zahl(ui.get("usenet_max_aufloesung"), 0, 0, 4320),
        "je_aufloesung": _zahl(ui.get("usenet_je_aufloesung"), 0, 0, 50),
        "ausschluss": ausschluss[:40],
        "dedupe": ui.get("usenet_dedupe", True) is not False,
        "sofort": ui.get("usenet_sofort", True) is not False,
        "auto": ui.get("usenet_auto_an", True) is not False,
        "auto_anzahl": _zahl(ui.get("usenet_auto_anzahl"), 4, 2, 8),
        "ersatzsuche": ui.get("usenet_ersatzsuche", True) is not False,
        "deutsch": deutsch_wertung.modus_von(ui.get("usenet_deutsch")),
        "basis": basis_adresse(ui.get("usenet_basis_url")),
    }


def basis_adresse(text):
    """Oeffentliche Adresse dieses Servers ("https://host[:port]/"), "" wenn leer oder ungueltig."""
    text = str(text or "").strip()
    if not text:
        return ""
    if "://" not in text:
        text = "https://" + text
    teile = urlsplit(text)
    if teile.scheme not in ("http", "https") or not teile.hostname or teile.username or teile.password:
        return ""
    try:
        port = teile.port
    except ValueError:
        return ""
    return "%s://%s%s/" % (teile.scheme, teile.hostname if ":" not in teile.hostname else "[%s]" % teile.hostname,
                           ":%d" % port if port else "")


# --- Merkmale eines Release-Namens ------------------------------------------------------------------------

def aufloesung_von(titel, treffer=None):
    """Hoehe in Pixel (2160, 1080 ...), 0 wenn unbekannt."""
    m = _AUFLOESUNG.search(str(titel or "")) or _AUFLOESUNG.search(str((treffer or {}).get("aufloesung") or ""))
    if not m:
        return 0
    w = m.group(1).lower()
    return 2160 if w in ("4k", "uhd") else int(re.match(r"\d+", w).group(0))


def merkmale(titel, treffer=None):
    """Aus dem Release-Namen: aufloesung (int), quelle, quelle_rang, codec, gruppe, hdr."""
    titel = str(titel or "")
    quelle, rang = "", -1
    for muster, name, wert in _QUELLEN:
        if muster.search(titel):
            quelle, rang = name, wert
            break
    codec = next((name for muster, name in _CODEC if muster.search(titel)), "")
    gruppe = _GRUPPE.search(titel.strip())
    return {"aufloesung": aufloesung_von(titel, treffer), "quelle": quelle, "quelle_rang": rang, "codec": codec,
            "gruppe": gruppe.group(1) if gruppe else "", "hdr": bool(_HDR.search(titel))}


def norm(name):
    """Name ohne Satzzeichen, klein: Grundlage fuer Duplikate und Sofort-Erkennung."""
    return re.sub(r"[^a-z0-9]+", "", str(name or "").lower())


def job_name(name):
    """Ordnername eines Jobs in NzbDAV/AltMount (so legt NzbDav.streamen ihn an)."""
    return re.sub(r"[^\w.\-]+", "_", str(name or "video"))[:100].strip("._") or "video"


def _wort_in(titel, wort):
    if " " in wort or len(wort) > 5:
        return wort in titel.lower()
    return re.search(r"(?<![a-z0-9])%s(?![a-z0-9])" % re.escape(wort), titel.lower()) is not None


# --- Ordnen ------------------------------------------------------------------------------------------------

def _schluessel(sortierung):
    if sortierung == "groesse":
        return lambda m: (-m["groesse"], -m["aufloesung"])
    if sortierung == "klein":
        return lambda m: (m["groesse"] or 1 << 62, -m["aufloesung"])
    if sortierung == "neu":
        return lambda m: (-m["datum"], -m["aufloesung"], -m["groesse"])
    return lambda m: (-m["aufloesung"], -m["quelle_rang"], -m["groesse"])


def ordnen(paare, cfg, sofort=None):
    """[(treffer, stream)] nur NZBs -> gefiltert und sortiert. cfg=None: unveraendert.

    Reihenfolge der Schritte: Ausschluesse, Groessengrenze, Aufloesungsgrenzen, Sortierung (Sofort-Treffer immer
    zuerst), Duplikate (der erste, also beste, bleibt), Grenze je Aufloesung. Jedes Paar bekommt in
    treffer["usenet_stream"] die gelesenen Merkmale und ob es sofort bereit ist."""
    if not cfg:
        return list(paare)
    sofort = sofort or set()
    zeilen = []
    for treffer, stream in paare:
        titel = str(treffer.get("titel") or "")
        if any(_wort_in(titel, w) for w in cfg["ausschluss"]):
            continue
        modus = cfg.get("deutsch", "aus")
        dw = deutsch_wertung.wertung(titel) if modus != "aus" else None
        if dw and not deutsch_wertung.zulassen(dw, modus):
            continue
        m = merkmale(titel, treffer)
        if dw:
            m["deutsch_sprache"], m["deutsch_bonus"], m["deutsch_labels"] = dw["sprache"], dw["bonus"], dw["labels"]
        m["groesse"] = int(filtern.groesse_bytes(treffer) or 0)
        zeit = filtern.zeitpunkt(treffer)
        m["datum"] = int(zeit) if zeit else 0
        if cfg["max_bytes"] and m["groesse"] > cfg["max_bytes"]:
            continue
        if cfg["min_aufloesung"] and m["aufloesung"] < cfg["min_aufloesung"]:
            continue
        if cfg["max_aufloesung"] and m["aufloesung"] > cfg["max_aufloesung"]:
            continue
        m["sofort"] = bool(cfg["sofort"] and (job_name(titel) in sofort or norm(titel) in sofort))
        zeilen.append((m, treffer, stream))
    schluessel = _schluessel(cfg["sortierung"])
    if cfg.get("deutsch", "aus") != "aus":
        # Sprache vor Aufloesung (wie ein Sprachprofil), verlustfreier Ton/x264 nur als Gleichstand-Entscheidung
        zeilen.sort(key=lambda z: (not z[0]["sofort"], -z[0].get("deutsch_sprache", 0)) + tuple(schluessel(z[0]))
                    + (-z[0].get("deutsch_bonus", 0),))
    else:
        zeilen.sort(key=lambda z: (not z[0]["sofort"], schluessel(z[0])))
    gesehen, je, ergebnis = set(), {}, []
    for m, treffer, stream in zeilen:
        if cfg["dedupe"]:
            n = norm(treffer.get("titel"))
            if n in gesehen:
                continue
            gesehen.add(n)
        if cfg["je_aufloesung"] and not m["sofort"]:
            if je.get(m["aufloesung"], 0) >= cfg["je_aufloesung"]:
                continue
            je[m["aufloesung"]] = je.get(m["aufloesung"], 0) + 1
        ergebnis.append((dict(treffer, usenet_stream=m), stream))
    return ergebnis


def anwenden(paare, cfg, sofort=None):
    """Wie ordnen, aber auf einer gemischten Liste: Nicht-NZBs bleiben an ihrem Platz, die NZBs stehen
    gemeinsam an der Stelle des ersten NZB."""
    paare = list(paare or [])
    if not cfg:
        return paare
    nzb = [p for p in paare if p[1].get("nzb") and p[1].get("url")]
    if not nzb:
        return paare
    neu = ordnen(nzb, cfg, sofort)
    ergebnis, eingesetzt = [], False
    for p in paare:
        if p[1].get("nzb") and p[1].get("url"):
            if not eingesetzt:
                ergebnis.extend(neu)
                eingesetzt = True
            continue
        ergebnis.append(p)
    return ergebnis


def marke(treffer):
    """Kurztext fuer den Stream-Namen, z. B. "1080p · WEB-DL · HEVC" (leer ohne Merkmale)."""
    m = (treffer or {}).get("usenet_stream") or {}
    teile = [("%dp" % m["aufloesung"]) if m.get("aufloesung") else "", m.get("quelle", ""), m.get("codec", ""),
             "HDR" if m.get("hdr") else ""] + list(m.get("deutsch_labels") or [])
    return " · ".join(t for t in teile if t)
