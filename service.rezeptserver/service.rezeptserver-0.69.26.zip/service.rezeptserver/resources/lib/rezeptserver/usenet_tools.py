"""Usenet-Werkzeuge: Apps, Downloader, Indexer, Medienverwaltung, Spotnet und Telegram.

Die Liste sammelt geprüfte Links für Usenet/Spotnet. Jeder Eintrag nennt Gruppe, Zweck,
Lizenz und Prüfstand. Nicht alles, was nach Usenet klingt, gehört dazu: als "fremd" oder
"tot" markierte Ziele werden erklärt, aber nicht als Werkzeug empfohlen.
"""

STAND = "2026-11-05"
GRUPPEN = [
    ("spotnet", "Spotnet & Spotweb"),
    ("apps", "Android-Apps"),
    ("download", "Downloader & Streaming"),
    ("indexer", "Indexer & Suche"),
    ("medien", "Medienverwaltung"),
    ("telegram", "Telegram & Mirror"),
    ("post", "Posten & Relay"),
    ("nicht", "Geprüft, aber nicht Usenet"),
]

TOOLS = [
    # --- Spotnet/Spotweb ---
    {"id": "spotweb", "name": "Spotweb (Kern)", "gruppe": "spotnet", "art": "Server", "status": "ok",
     "url": "https://github.com/spotweb/spotweb", "lizenz": "BSD-3-Clause",
     "text": "Die freie Spotnet-Community-Software: PHP mit MySQL, PostgreSQL oder SQLite, Spots aus dem Usenet, "
             "Newznab-Schnittstelle. Grundlage für einen eigenen Spotweb-Server."},
    {"id": "docker-spotweb", "name": "docker-spotweb", "gruppe": "spotnet", "art": "Docker", "status": "ok",
     "url": "https://github.com/edv/docker-spotweb", "lizenz": "MIT",
     "text": "Fertiges Docker-Setup für Spotweb auf Raspberry Pi (ARM) und x86, mit MySQL, PostgreSQL oder SQLite."},
    {"id": "spotwebng", "name": "SpotwebNG", "gruppe": "spotnet", "art": "Server", "status": "ok",
     "url": "https://github.com/Fornaxlabs/SpotwebNG", "lizenz": "siehe Projekt",
     "text": "Moderner Spotweb-Nachbau mit Spotnet/Usenet-Indexer, eigener Abruf-Engine und Newznab-API. "
             "Junge Alternative – Stand und Kompatibilität vor dem Einsatz prüfen."},
    {"id": "spotweb-venimk", "name": "Spotweb (VenimK)", "gruppe": "spotnet", "art": "Fork", "status": "unbekannt",
     "url": "https://github.com/VenimK/spotweb", "lizenz": "siehe Projekt",
     "text": "Abspaltung des Spotweb-Kerns ohne Beschreibung. Nur nutzen, wenn du den Fork und seine Änderungen kennst."},
    {"id": "spotweb-isuftin", "name": "Spotweb (isuftin)", "gruppe": "spotnet", "art": "Fork", "status": "unbekannt",
     "url": "https://github.com/isuftin/spotweb", "lizenz": "Unlicense",
     "text": "Weiterer Spotweb-Fork. README, Stand und Sicherheitsupdates vor dem Betrieb prüfen."},
    {"id": "spotweb-ahmedaley", "name": "SpotWeb (ahmedaley)", "gruppe": "spotnet", "art": "Fork", "status": "unbekannt",
     "url": "https://github.com/ahmedaley/SpotWeb", "lizenz": "GPL-3.0",
     "text": "Eigenständiges SpotWeb-Projekt. Nicht mit dem Spotweb-Kern verwechseln; vor dem Einsatz prüfen."},
    {"id": "spotweb-filter", "name": "Spotweb Filter Creator", "gruppe": "spotnet", "art": "Filter", "status": "ok",
     "url": "https://www.brainbytez.eu/projects/spotweb-filter-creator/", "lizenz": "Web-Werkzeug",
     "text": "Erstellt Filter für Spotweb (Blacklist/Whitelist), um unerwünschte Spots vor dem Abruf auszusortieren."},
    {"id": "spotweb-nzbfinder", "name": "Spotweb bei NZBFinder", "gruppe": "spotnet", "art": "Öffentliche Instanz", "status": "ok",
     "url": "https://spotweb.nzbfinder.ws", "lizenz": "Dienst des Anbieters",
     "text": "Öffentlich erreichbare Spotweb-Instanz mit Newznab-API. In H0rSt als Vorlage „Spotweb (NZBFinder)“ "
             "eintragen; API-Schlüssel aus dem NZBFinder-Konto."},

    # --- Android-Apps ---
    {"id": "nzb360", "name": "nzb360", "gruppe": "apps", "art": "Android-App", "status": "ok",
     "url": "https://play.google.com/store/apps/details?id=com.kevinforeman.nzb360",
     "apkpure": "https://apkpure.com/search?q=com.kevinforeman.nzb360", "lizenz": "proprietär",
     "text": "Media-Server-Manager für Sonarr, Radarr, SABnzbd, Torrents, Unraid und mehr – alles in einer App."},
    {"id": "nzbble", "name": "NZBble", "gruppe": "apps", "art": "Android-App", "status": "ok",
     "url": "https://play.google.com/store/apps/details?id=com.cabalea.nzbble",
     "apkpure": "https://apkpure.com/search?q=com.cabalea.nzbble", "lizenz": "proprietär",
     "text": "Überwacht SABnzbd-Downloads auf dem Handy."},
    {"id": "nzboctopus", "name": "NZBOctopus", "gruppe": "apps", "art": "Android-App", "status": "ok",
     "url": "https://play.google.com/store/apps/details?id=com.markusgey.nzboctopus",
     "apkpure": "https://apkpure.com/search?q=com.markusgey.nzboctopus", "lizenz": "proprietär",
     "text": "NZB-Downloader für Android mit PAR2-Reparatur, RAR-Extraktion und Export auf SMB/NAS."},
    {"id": "nzblnk", "name": "NZB Tarsier (NZBLNK)", "gruppe": "apps", "art": "Android-App", "status": "ok",
     "url": "https://play.google.com/store/apps/details?id=com.kroegerama.nzblnk",
     "apkpure": "https://apkpure.com/search?q=com.kroegerama.nzblnk", "lizenz": "proprietär",
     "text": "Öffnet NZBLNKs und leitet sie an einen NZBGet- oder SABnzbd-Server weiter."},
    {"id": "usenetpanda", "name": "Usenet Panda", "gruppe": "apps", "art": "Android-App", "status": "ok",
     "url": "https://play.google.com/store/apps/details?id=at.mann.usenetpanda",
     "apkpure": "https://apkpure.com/search?q=at.mann.usenetpanda", "lizenz": "proprietär",
     "text": "Usenet-Downloader mit Streaming und integrierter Suche."},
    {"id": "sicnzb", "name": "Sic NZB (sic.nzb.app)", "gruppe": "apps", "art": "Android-App", "status": "prüfen",
     "url": "https://apkpure.com/search?q=sic.nzb.app", "lizenz": "unbekannt",
     "text": "Nur als APKPure-Suche gefunden; nicht im Play Store. Paket, Stand und Vertrauenswürdigkeit vor dem "
             "Installieren prüfen. H0rSt nutzt dafür keine Zugangsdaten."},
    {"id": "nzbgetapp", "name": "NZBGet (nzbget.nzbget)", "gruppe": "apps", "art": "Android-App", "status": "prüfen",
     "url": "https://apkpure.com/search?q=nzbget.nzbget", "lizenz": "GPL-3.0 (NZBGet)",
     "text": "APKPure-Suche nach der NZBGet-Begleit-App; das Paket ist nicht im Play Store. Für H0rSt zählt der "
             "NZBGet-Server, nicht diese App."},

    # --- Downloader & Streaming ---
    {"id": "sabnzbd", "name": "SABnzbd (Flathub)", "gruppe": "download", "art": "Downloader", "status": "ok",
     "url": "https://flathub.org/apps/org.sabnzbd.sabnzbd", "lizenz": "GPL-2.0",
     "text": "Freier Usenet-Binärleser und Downloader für Linux; H0rSt bindet SABnzbd über die API an."},
    {"id": "nzbget", "name": "NZBGet", "gruppe": "download", "art": "Downloader", "status": "ok",
     "url": "https://nzbget.net", "lizenz": "GPL-3.0",
     "text": "Sehr effizienter Usenet-Downloader. Läuft auf PC, Pi, NAS und in der H0rSt-App; Anbindung über die API."},
    {"id": "nzbdav", "name": "NzbDAV", "gruppe": "download", "art": "Streaming", "status": "ok",
     "url": "https://github.com/nzbdav-dev/nzbdav", "lizenz": "GPL-3.0",
     "text": "Usenet-Streaming über WebDAV und eine SABnzbd-kompatible API. H0rSt bindet NZBs dort ein und "
             "spielt sie mit Range-Anfragen ab."},
    {"id": "infinidysk", "name": "infinidysk (früher NzbDAV)", "gruppe": "download", "art": "Streaming", "status": "ok",
     "url": "https://infinidysk.com", "lizenz": "siehe Projekt",
     "text": "NzbDAV als Rust-Neuentwicklung: NZBs als virtuelles Dateisystem, Streaming über WebDAV/FUSE, "
             "SABnzbd-kompatible API für Sonarr und Radarr."},
    {"id": "usenetstreamer", "name": "UsenetStreamer", "gruppe": "download", "art": "Streaming", "status": "ok",
     "url": "https://github.com/Sanket9225/UsenetStreamer", "lizenz": "siehe Projekt",
     "text": "Streamt NZBs direkt nach Stremio; mit Prowlarr, NZBHydra, eigenen Newznab-Indexern oder Easynews. "
             "Vorbild für H0rSt-Usenet-Streaming (eigener Code)."},

    # --- Indexer & Suche ---
    {"id": "nzbhydra2", "name": "NZBHydra2", "gruppe": "indexer", "art": "Metasuche", "status": "ok",
     "url": "https://github.com/theotherp/nzbhydra2", "lizenz": "Apache-2.0",
     "text": "Metasuche über viele NZB-Indexer mit Vereinheitlichung, Statistik und Newznab-Ausgabe."},
    {"id": "nzbhydra", "name": "NZBHydra (alt)", "gruppe": "indexer", "art": "Metasuche", "status": "ok",
     "url": "https://github.com/theotherp/nzbhydra", "lizenz": "Apache-2.0",
     "text": "Vorgänger von NZBHydra2; nur noch als Referenz für ältere Installationen."},
    {"id": "usntssearch", "name": "usntssearch", "gruppe": "indexer", "art": "Metasuche", "status": "ok",
     "url": "https://pillone.github.io/usntssearch/", "lizenz": "siehe Projekt",
     "text": "NZB-Metasuche von pillone: durchsucht mehrere Indexer und stellt die Treffer gebündelt bereit."},
    {"id": "reisub0-nzb", "name": "nzb (reisub0)", "gruppe": "indexer", "art": "Werkzeug", "status": "unbekannt",
     "url": "https://gitlab.com/reisub0/nzb", "lizenz": "siehe Projekt",
     "text": "Kleines GitLab-Projekt ohne Beschreibung. Vor dem Einsatz README und Zweck prüfen."},

    # --- Medienverwaltung ---
    {"id": "nzbtomedia", "name": "nzbToMedia", "gruppe": "medien", "art": "Nachbearbeitung", "status": "ok",
     "url": "https://github.com/clinton-hall/nzbToMedia", "lizenz": "GPL-3.0",
     "text": "Nachbearbeitung von NZB- und Torrent-Downloads für CouchPotato, SickBeard/SickRage, HeadPhones, "
             "Mylar und Gamez."},
    {"id": "medusa", "name": "Medusa", "gruppe": "medien", "art": "Serienverwaltung", "status": "ok",
     "url": "https://github.com/pymedusa/Medusa", "lizenz": "GPL-3.0",
     "text": "Automatische Serienbibliothek: beobachtet neue Folgen und übergibt sie an den Downloader."},
    {"id": "radarr", "name": "Radarr", "gruppe": "medien", "art": "Filme", "status": "ok",
     "url": "https://radarr.video", "lizenz": "GPL-3.0",
     "text": "Filmbibliothek und Downloadverwaltung; H0rSt bindet Radarr über die API an."},
    {"id": "lidarr", "name": "Lidarr", "gruppe": "medien", "art": "Musik", "status": "ok",
     "url": "https://lidarr.audio/", "lizenz": "GPL-3.0",
     "text": "Musikbibliothek und Downloadverwaltung; H0rSt bindet Lidarr über die API an."},
    {"id": "seerr", "name": "Seerr", "gruppe": "medien", "art": "Anfragen", "status": "ok",
     "url": "https://docs.seerr.dev", "lizenz": "MIT (Dokumentation)",
     "text": "Anfrage- und Freigabesystem für Sonarr, Radarr und Lidarr; H0rSt bindet Seerr an."},

    # --- Telegram & Mirror ---
    {"id": "mltb", "name": "MLTB Telegram-Kanal", "gruppe": "telegram", "art": "Telegram", "status": "ok",
     "url": "https://t.me/mltb_official_channel", "lizenz": "Kanal",
     "text": "Offizieller Kanal zum mirror-leech-telegram-bot (MLTB): Updates, Anleitungen, neue Funktionen."},
    {"id": "aeon", "name": "Aeon Discussion", "gruppe": "telegram", "art": "Telegram", "status": "ok",
     "url": "https://t.me/AeonDiscussion", "lizenz": "Kanal",
     "text": "Telegram-Diskussion rund um Aeon und verwandte Mirror-/Download-Bots. Inhalte Dritter, keine H0rSt-Dienste."},
    {"id": "zmirror", "name": "Z-Mirror", "gruppe": "telegram", "art": "Telegram-Bot", "status": "ok",
     "url": "https://dawn-india.github.io/Z-Mirror/", "lizenz": "siehe Projekt",
     "text": "Offizielles Zee-Repository: Telegram-Bot für direkte Links, Torrents, NZB, Cloud- und rclone-Ziele."},
    {"id": "mltbgitlab", "name": "mirror-leech-telegram-bot", "gruppe": "telegram", "art": "Telegram-Bot", "status": "ok",
     "url": "https://gitlab.com/barrunmab/mirror-leech-telegram-bot", "lizenz": "siehe Projekt",
     "text": "GitLab-Spiegel des MLTB: Mirror- und Leech-Bot für Telegram. H0rSt ruft ihn nicht selbst auf."},

    # --- Posten & Relay ---
    {"id": "nyuu", "name": "Nyuu", "gruppe": "post", "art": "Posten", "status": "ok",
     "url": "https://github.com/animetosho/Nyuu", "lizenz": "MIT",
     "text": "Flexibles Usenet-Binär-Posting-Werkzeug für NZBs und eigene Uploads."},
    {"id": "nzbrelay", "name": "NZBRelay", "gruppe": "post", "art": "Relay", "status": "ok",
     "url": "https://gitlab.com/UmbraMortis/nzbrelay", "lizenz": "siehe Projekt",
     "text": "GitLab-Projekt für einen NZB-Relay; README und Betriebsmodell vor dem Einsatz prüfen."},
    {"id": "nzbdarkonion", "name": "NZB Dark Onion Caramelizarr", "gruppe": "post", "art": "Werkzeug", "status": "unbekannt",
     "url": "https://gitlab.com/notapirate1/NzbDarkOnionCaramelizarr", "lizenz": "siehe Projekt",
     "text": "Kleines GitLab-Projekt im Umfeld von NZB und *arr. Ohne Beschreibung – nur nach eigener Prüfung nutzen."},

    # --- Geprüft, aber nicht Usenet ---
    {"id": "couchpota", "name": "couchpota.to", "gruppe": "nicht", "art": "Fremdseite", "status": "tot",
     "url": "https://couchpota.to", "lizenz": "–",
     "text": "Die frühere CouchPotato-Seite löst nicht mehr auf. CouchPotato ist eingestellt; nzbToMedia nennt es "
             "nur noch als Altlast."},
    {"id": "alirezarezvani", "name": "alirezarezvani.com", "gruppe": "nicht", "art": "Fremdseite", "status": "fremd",
     "url": "https://alirezarezvani.com", "lizenz": "–",
     "text": "Persönliche Seite eines AI-Beraters, kein Usenet-Werkzeug."},
    {"id": "spotwebtools", "name": "Spot Web Tools (com.swt.spotwebtools)", "gruppe": "nicht", "art": "Fremd-App", "status": "fremd",
     "url": "https://play.google.com/store/apps/details?id=com.swt.spotwebtools",
     "apkpure": "https://apkpure.com/search?q=com.swt.spotwebtools", "lizenz": "proprietär",
     "text": "Geprüft: eine Sammlung von Web-/SEO-Werkzeugen (HindukushSoft), keine Spotnet- oder Usenet-App."},
    {"id": "devcontrol", "name": "Dev Control (com.devcontrol.android)", "gruppe": "nicht", "art": "Fremd-App", "status": "fremd",
     "url": "https://play.google.com/store/apps/details?id=com.devcontrol.android", "lizenz": "proprietär",
     "text": "Geprüft: Schalter für Android-Entwickleroptionen und USB-Debugging, kein SpotWeb. Der angegebene Link "
             "führt nicht zu Spot Web Tools."},
    {"id": "spotrec", "name": "SpotRec", "gruppe": "nicht", "art": "Fremd-App", "status": "fremd",
     "url": "https://spotrec.en.uptodown.com/android", "lizenz": "Drittanbieter",
     "text": "Geprüft: ein Sprachnotiz-Recorder für Studierende, kein Spotnet/Usenet."},
    {"id": "spot56k", "name": "spot.56k.guru", "gruppe": "nicht", "art": "Fremdseite", "status": "fremd",
     "url": "https://spot.56k.guru", "lizenz": "Drittanbieter",
     "text": "Geprüft: zeigt aktuell Strompreise, keine Spotweb-Instanz. Nicht als Spotweb-Adresse eintragen."},
]


def zustand():
    return {"stand": STAND, "gruppen": [{"id": i, "name": n} for i, n in GRUPPEN],
            "tools": [dict(t) for t in TOOLS],
            "hinweis": "Usenet/Spotnet: H0rSt verbindet Spotweb über Newznab (Vorlage „Spotweb (NZBFinder)“ oder "
                       "„Eigener Spotweb-Server“). Fremde Apps und Seiten werden nur verlinkt und geprüft; keine "
                       "Zugangsdaten, keine Umgehung von Anmeldungen."}
