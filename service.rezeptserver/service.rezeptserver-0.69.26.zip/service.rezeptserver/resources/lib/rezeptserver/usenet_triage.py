"""usenet_triage.py: Verbindet NNTP-Artikelpruefung (nntp_pruefung.py) und NZB-Parsing (nzb_lesen.py) zu
einem Urteil je NZB-Kandidat - fuer die Usenet-Gesundheitspruefung (Vorbild UsenetStreamer).

Zwei Zugangswege: die Klasse UsenetTriage (Zwischenspeicher je Instanz, Muster Tmdb) und die
Modul-Funktionen mehrere()/im_hintergrund()/gelesen()/urteile_zu() auf einem gemeinsamen
Standard-Zwischenspeicher. So teilen sich Stream-Aufbau und Status-Abfrage dieselben Urteile.
"""

import logging
import threading
import time
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import unquote, urlsplit

from . import nntp_pruefung, nzb_lesen
from .rustnzb import nzb_laden

log = logging.getLogger("rezeptserver")

CACHE_GUELTIGKEIT = 30 * 60
GUELTIG = CACHE_GUELTIGKEIT
DEFAULT_STICHPROBEN = 6


def pruefen(nzb_url, name, werte, holen=nzb_laden, stichproben=6):
    """Laedt die NZB, zieht eine Stichprobe und prueft sie per NNTP. Wirft nie - jeder Fehlerfall (NZB
    nicht ladbar, kein NNTP-Anbieter konfiguriert, Provider nicht erreichbar) ergibt "unbekannt"."""
    if not (werte or {}).get("host"):
        return {"urteil": "unbekannt", "quote": "", "name": name}
    try:
        roh = holen(nzb_url)
    except Exception:
        return {"urteil": "unbekannt", "quote": "", "name": name}
    probe = nzb_lesen.stichprobe(nzb_lesen.lesen(roh), stichproben)
    if not probe:
        return {"urteil": "unbekannt", "quote": "", "name": name}
    ergebnis = nntp_pruefung.artikel_vorhanden(werte, probe)
    bekannt = [v for v in ergebnis.values() if v is not None]
    if not bekannt:
        return {"urteil": "unbekannt", "quote": "", "name": name}
    vorhanden = sum(1 for v in bekannt if v)
    quote = "%d/%d" % (vorhanden, len(bekannt))
    if vorhanden == len(bekannt):
        urteil = "verifiziert"
    elif vorhanden == 0:
        urteil = "blockiert"
    else:
        urteil = "unsicher"
    return {"urteil": urteil, "quote": quote, "name": name}


class UsenetTriage:
    """Haelt einen 30-Minuten-Zwischenspeicher je NZB-Adresse (Muster Tmdb: (zeit, urteil) je Schluessel),
    damit dieselbe NZB nicht bei jeder Anfrage neu geprueft wird."""

    def __init__(self, holen=nzb_laden, uhr=time.time, stichproben=6):
        self.holen = holen
        self.uhr = uhr
        self.stichproben = stichproben
        self._cache = {}

    def mehrere(self, kandidaten, werte, stichproben=None):
        """kandidaten: [(nzb_url, name), ...]. Liefert {nzb_url: urteil-dict}. Cache-Treffer werden nicht
        erneut geprueft, der Rest laeuft gleichzeitig (Ab18._parallel()-Muster), jeder Kandidat isoliert.
        stichproben ueberschreibt die Instanz-Vorgabe nur fuer diesen Aufruf (vermeidet eine gemeinsame,
        von gleichzeitigen Aufrufen mutierte Instanzvariable)."""
        stichproben = stichproben or self.stichproben
        jetzt = self.uhr()
        ergebnis = {}
        offen = []
        for nzb_url, name in kandidaten:
            eintrag = self._cache.get(nzb_url)
            if eintrag and jetzt - eintrag[0] < CACHE_GUELTIGKEIT:
                ergebnis[nzb_url] = eintrag[1]
            else:
                offen.append((nzb_url, name))
        if not offen:
            return ergebnis

        def eine(aufgabe):
            nzb_url, name = aufgabe
            return nzb_url, pruefen(nzb_url, name, werte, holen=self.holen, stichproben=stichproben)

        with ThreadPoolExecutor(max_workers=min(8, len(offen))) as pool:
            for nzb_url, urteil in pool.map(eine, offen):
                self._cache[nzb_url] = (jetzt, urteil)
                ergebnis[nzb_url] = urteil
        return ergebnis

    def urteile_aus_cache(self, nzb_urls):
        """Liefert {nzb_url: urteil-dict} nur fuer bereits geprueft im Zwischenspeicher stehende, noch
        gueltige Adressen - loest nie selbst eine Pruefung aus (fuer die Smart-Play-Statusabfrage im
        Hintergrund-Modus, U6). Adressen ohne (noch gueltigen) Eintrag fehlen einfach im Ergebnis."""
        jetzt = self.uhr()
        ergebnis = {}
        for nzb_url in nzb_urls:
            eintrag = self._cache.get(nzb_url)
            if eintrag and jetzt - eintrag[0] < CACHE_GUELTIGKEIT:
                ergebnis[nzb_url] = eintrag[1]
        return ergebnis


# Gemeinsamer Standard-Zwischenspeicher fuer App (stremio_kern) und Modul-Funktionen.
STANDARD = UsenetTriage()


def standard():
    return STANDARD


def cache_leeren():
    STANDARD._cache.clear()


def _paare(kandidaten):
    """[(url, name), ...] aus Tupeln oder dicts (die Oberflaeche nutzt beides)."""
    liste = []
    for k in kandidaten or []:
        if isinstance(k, dict):
            url, name = k.get("url") or "", k.get("name") or ""
        else:
            url, name = k[0], (k[1] if len(k) > 1 else "")
        if url:
            liste.append((str(url), str(name or "")))
    return liste


def nntp_werte(daten):
    """Erster vollstaendiger NNTP-Anbieter (host, user, pass) oder None."""
    from . import anbindungen

    for _i, _eintrag, werte in anbindungen.eigene(daten or {}, "nntp"):
        if str(werte.get("host") or "").strip():
            return werte
    return None


def mehrere(kandidaten, werte, stichproben=DEFAULT_STICHPROBEN, holen=None):
    """{nzb_url: urteil}. Jeder Kandidat fuer sich, einer darf die anderen nicht abreissen."""
    return STANDARD.mehrere(_paare(kandidaten), werte or {}, stichproben=stichproben)


def gelesen(url):
    """Gespeichertes Urteil oder None. Loest keine neue Pruefung aus."""
    return STANDARD.urteile_aus_cache([str(url or "")]).get(str(url or ""))


def im_hintergrund(kandidaten, werte, stichproben=DEFAULT_STICHPROBEN, holen=None):
    """Prueft, was noch nicht im Zwischenspeicher liegt. Kehrt sofort zurueck."""
    offen = [p for p in _paare(kandidaten) if not gelesen(p[0])]
    if not offen:
        return

    def lauf():
        try:
            STANDARD.mehrere(offen, werte or {}, stichproben=stichproben)
        except Exception as fehler:
            log.warning("Usenet-Prüfung im Hintergrund: %s", fehler)

    threading.Thread(target=lauf, name="usenet-triage", daemon=True).start()


def _nzb_aus_bezug(text, auspacken):
    """Das, was die Oberflaeche schon hat (NZB-Adresse, /usenet/<key>, dateisuche/nzb/<key>) -> NZB-URL."""
    text = unquote(str(text or "").strip())
    if not text:
        return ""
    pfad = unquote(urlsplit(text).path if "://" in text else text.split("?", 1)[0])
    schluessel = ""
    if "/usenet/" in pfad:
        schluessel = pfad.split("/usenet/", 1)[1].split("/", 1)[0]
    elif "dateisuche/nzb/" in pfad:
        schluessel = pfad.rsplit("/", 1)[-1]
    elif "/" not in pfad and "." in pfad:
        schluessel = pfad
    if schluessel and auspacken:
        roh = auspacken(schluessel) or ""
        return roh.split("\n", 1)[0].strip()
    if text.lower().startswith(("http://", "https://")):
        return text
    return ""


def urteile_zu(bezuege, auspacken):
    """Nur schon gespeicherte Urteile, Schluessel = der vom Client geschickte Bezug. Kein neuer Lauf."""
    ergebnis = {}
    for roh in list(bezuege or [])[:40]:
        roh = str(roh or "").strip()
        if not roh or roh in ergebnis:
            continue
        nzb = _nzb_aus_bezug(roh, auspacken)
        alt = gelesen(nzb) if nzb else None
        if alt:
            ergebnis[roh] = alt
    return ergebnis
