"""Verweise: tote Verbindungen zwischen Einstellungen finden und aufraeumen, damit nichts ins Leere zeigt.

Geprueft wird:
  * Netzweg, .onion- und .i2p-Weg und WireGuard (Sicherheit) zeigen auf einen vorhandenen Anbieter passender Art.
  * Ersatz-Adressen des Waechters gehoeren zu vorhandenen Anbietern.
  * Zugangsdaten (einstellungen) gehoeren zu einem vorhandenen Anbieter (eigener oder mitgeliefertes Rezept).
  * Startbereich und Navigation nennen nur vorhandene Reiter (das sortiert einstellungen.pruefe ohnehin).
Beim Entfernen eines Anbieters raeumt H0rSt sofort auf (aufraeumen), die Startseite zeigt den Stand.
"""

from . import einstellungen, sicherheit, waechter

WEGE = {"weg": sicherheit.WEG_TYPEN, "onion": ("tor",), "i2p": ("i2p",), "wireguard": ("wireguard",)}
WEG_NAMEN = {"weg": "Netzweg", "onion": ".onion-Weg (Tor)", "i2p": ".i2p-Weg", "wireguard": "WireGuard-VPN"}


def pruefen(daten, eingebaut=()):
    """Liste der Probleme: [{"art", "text"}]. eingebaut: IDs der mitgelieferten Anbieter (Rezepte)."""
    probleme = []
    eigene = daten.get("anbieter") or {}
    bekannt = set(eigene) | set(eingebaut)
    s = daten.get(sicherheit.SCHLUESSEL) if isinstance(daten.get(sicherheit.SCHLUESSEL), dict) else {}
    for schluessel, typen in WEGE.items():
        ziel = s.get(schluessel)
        if not ziel:
            continue
        if ziel not in eigene:
            probleme.append({"art": "sicherheit", "text": "%s zeigt auf einen entfernten Anbieter (%s)" % (WEG_NAMEN[schluessel], ziel)})
        elif (eigene[ziel] or {}).get("typ") not in typen:
            probleme.append({"art": "sicherheit", "text": "%s: %s passt nicht (falsche Art)" % (WEG_NAMEN[schluessel], eigene[ziel].get("name", ziel))})
    w = daten.get(waechter.SCHLUESSEL) if isinstance(daten.get(waechter.SCHLUESSEL), dict) else {}
    for aid in (w.get("ersatz") or {}):
        if aid not in bekannt:
            probleme.append({"art": "waechter", "text": "Ersatz-Adresse für einen entfernten Anbieter (%s)" % aid})
    for konto in (daten.get("einstellungen") or {}):
        if konto not in bekannt:
            probleme.append({"art": "zugang", "text": "Zugangsdaten ohne Anbieter (%s)" % konto})
    ui = daten.get(einstellungen.SCHLUESSEL) if isinstance(daten.get(einstellungen.SCHLUESSEL), dict) else {}
    eigene_tabs = {"eigen:" + t.get("id", "") for t in ui.get("eigene_tabs") or [] if isinstance(t, dict)}
    erlaubt = {z[0] for z in einstellungen._ZEILEN["startbereich"]["werte"]} | eigene_tabs
    if ui.get("startbereich") and ui["startbereich"] not in erlaubt:
        probleme.append({"art": "navigation", "text": "Startbereich gibt es nicht mehr (%s)" % ui["startbereich"]})
    return probleme


def aufraeumen(daten, eingebaut=()):
    """Entfernt tote Verweise in daten (aendert daten). Gibt die Zahl der Korrekturen zurueck."""
    anzahl = 0
    eigene = daten.get("anbieter") or {}
    bekannt = set(eigene) | set(eingebaut)
    s = daten.get(sicherheit.SCHLUESSEL)
    if isinstance(s, dict):
        for schluessel, typen in WEGE.items():
            ziel = s.get(schluessel)
            if ziel and (ziel not in eigene or (eigene[ziel] or {}).get("typ") not in typen):
                s[schluessel] = ""
                anzahl += 1
    w = daten.get(waechter.SCHLUESSEL)
    if isinstance(w, dict) and isinstance(w.get("ersatz"), dict):
        for aid in [a for a in w["ersatz"] if a not in bekannt]:
            del w["ersatz"][aid]
            anzahl += 1
    zugaenge = daten.get("einstellungen")
    if isinstance(zugaenge, dict):
        for konto in [k for k in zugaenge if k not in bekannt]:
            del zugaenge[konto]
            anzahl += 1
    ui = daten.get(einstellungen.SCHLUESSEL)
    if isinstance(ui, dict) and ui.get("startbereich"):
        eigene_tabs = {"eigen:" + t.get("id", "") for t in ui.get("eigene_tabs") or [] if isinstance(t, dict)}
        if ui["startbereich"] not in {z[0] for z in einstellungen._ZEILEN["startbereich"]["werte"]} | eigene_tabs:
            ui["startbereich"] = "start"
            anzahl += 1
    return anzahl
