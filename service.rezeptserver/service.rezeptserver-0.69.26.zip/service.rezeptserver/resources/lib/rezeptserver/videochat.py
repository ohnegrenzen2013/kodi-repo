"""Videochat: Vermittlung (Signalisierung) fuer WebRTC zwischen den Geraeten im Heimnetz.

Bild, Ton und Textnachrichten laufen direkt von Geraet zu Geraet (WebRTC, verschluesselt mit DTLS-SRTP).
H0rSt gibt nur die Verbindungsangebote weiter (SDP, ICE-Kandidaten) und merkt sich, wer in welchem Raum ist –
im Speicher, nichts wird aufgezeichnet. Ohne STUN/TURN bei fremden Diensten: im Heimnetz finden sich die Geraete
ueber ihre lokalen Adressen. Browser geben Kamera und Mikrofon nur ueber HTTPS frei (siehe tls.py) oder in der App.

Ablauf: beitreten -> Liste der anderen; der Neue schickt jedem ein Angebot (offer), die anderen antworten (answer),
Kandidaten (ice) folgen. abholen() wartet bis zu 20 s auf neue Nachrichten (Long Polling).
"""

import re
import secrets
import threading
import time
from collections import deque

MAX_RAEUME = 50
MAX_TEILNEHMER = 6       # Netz von Verbindungen (jeder mit jedem): mehr wird zaeh
MAX_NACHRICHT = 60000
ABGELAUFEN = 45          # Sekunden ohne Abholen -> gilt als gegangen
ARTEN = ("offer", "answer", "ice", "bye", "text", "foto")
_RAUM = re.compile(r"^[\w\- ]{1,40}$")


class ChatFehler(ValueError):
    pass


class Videochat:
    def __init__(self, uhr=time.time):
        self.uhr = uhr
        self._raeume = {}  # name -> {"teilnehmer": {id: {"name", "zuletzt"}}, "post": {id: deque}}
        self._bedingung = threading.Condition()

    @staticmethod
    def _raumname(name):
        name = " ".join(str(name or "").split())
        if not _RAUM.match(name):
            raise ChatFehler("Raumname: 1–40 Buchstaben, Ziffern, Leerzeichen oder -")
        return name.lower()

    def _aufraeumen(self, raum_name):
        raum = self._raeume.get(raum_name)
        if not raum:
            return
        jetzt = self.uhr()
        for tid, t in list(raum["teilnehmer"].items()):
            if jetzt - t["zuletzt"] > ABGELAUFEN:
                self._entfernen(raum, tid)
        if not raum["teilnehmer"]:
            del self._raeume[raum_name]

    def _entfernen(self, raum, tid):
        raum["teilnehmer"].pop(tid, None)
        raum["post"].pop(tid, None)
        for post in raum["post"].values():
            post.append({"von": tid, "art": "bye", "daten": None})

    def raeume(self):
        with self._bedingung:
            for r in list(self._raeume):
                self._aufraeumen(r)
            return [{"name": n, "teilnehmer": [t["name"] for t in r["teilnehmer"].values()]} for n, r in self._raeume.items()]

    def beitreten(self, raum_name, name):
        raum_name = self._raumname(raum_name)
        name = " ".join(str(name or "Gast").split())[:30] or "Gast"
        with self._bedingung:
            self._aufraeumen(raum_name)
            if raum_name not in self._raeume and len(self._raeume) >= MAX_RAEUME:
                raise ChatFehler("Zu viele Räume")
            raum = self._raeume.setdefault(raum_name, {"teilnehmer": {}, "post": {}})
            if len(raum["teilnehmer"]) >= MAX_TEILNEHMER:
                raise ChatFehler("Der Raum ist voll (höchstens %d Geräte)" % MAX_TEILNEHMER)
            tid = secrets.token_hex(8)
            andere = [{"id": i, "name": t["name"]} for i, t in raum["teilnehmer"].items()]
            raum["teilnehmer"][tid] = {"name": name, "zuletzt": self.uhr()}
            raum["post"][tid] = deque(maxlen=500)
            for i in raum["post"]:
                if i != tid:
                    raum["post"][i].append({"von": tid, "art": "hallo", "daten": {"name": name}})
            self._bedingung.notify_all()
            return {"ich": tid, "raum": raum_name, "andere": andere}

    def senden(self, raum_name, von, an, art, daten):
        raum_name = self._raumname(raum_name)
        if art not in ARTEN:
            raise ChatFehler("Unbekannte Nachricht")
        if len(str(daten)) > MAX_NACHRICHT:
            raise ChatFehler("Nachricht zu groß")
        with self._bedingung:
            raum = self._raeume.get(raum_name)
            if not raum or von not in raum["teilnehmer"]:
                raise ChatFehler("Nicht im Raum (neu beitreten)")
            raum["teilnehmer"][von]["zuletzt"] = self.uhr()
            if art == "bye":
                self._entfernen(raum, von)
            else:
                ziele = [an] if an else [i for i in raum["post"] if i != von]  # ohne Empfaenger: an alle (Text)
                for z in ziele:
                    if z in raum["post"] and z != von:
                        raum["post"][z].append({"von": von, "name": raum["teilnehmer"][von]["name"], "art": art, "daten": daten})
            self._bedingung.notify_all()

    def abholen(self, raum_name, ich, warten=20.0):
        raum_name = self._raumname(raum_name)
        ende = time.monotonic() + max(0.0, min(25.0, warten))
        with self._bedingung:
            while True:
                raum = self._raeume.get(raum_name)
                if not raum or ich not in raum["teilnehmer"]:
                    raise ChatFehler("Nicht im Raum (neu beitreten)")
                raum["teilnehmer"][ich]["zuletzt"] = self.uhr()
                post = raum["post"][ich]
                if post:
                    nachrichten = list(post)
                    post.clear()
                    return {"nachrichten": nachrichten,
                            "teilnehmer": [{"id": i, "name": t["name"]} for i, t in raum["teilnehmer"].items()]}
                rest = ende - time.monotonic()
                if rest <= 0:
                    return {"nachrichten": [], "teilnehmer": [{"id": i, "name": t["name"]} for i, t in raum["teilnehmer"].items()]}
                self._bedingung.wait(rest)
