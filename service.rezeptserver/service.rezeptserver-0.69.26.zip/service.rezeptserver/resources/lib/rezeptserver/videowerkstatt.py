"""Videowerkstatt: ComfyUI-Client, Auftragswarteschlange und Galerie.

Die Regeln stehen in videowerkstatt_grund.py. Auftraege laufen nacheinander in einem
Daemon-Thread (wie LocalDream), damit mehrere kurze Videos nicht gleichzeitig die GPU
ueberfahren. Ergebnisse liegen als animiertes WebP oder MP4 samt Rezept-JSON im
Datenordner und werden ueber /api/videowerkstatt/datei/<name> ausgeliefert.
"""

import json
import os
import re
import threading
import time
import uuid
from collections import OrderedDict, deque
from urllib.parse import urlencode

from .netz import antwort_holen, antwort_holen_roh
from .videowerkstatt_grund import (MAX_DATEI, MAX_JOBS, MAX_LAUF, MAX_WARTEND, STANDARD, VwFehler,
                                    graph, pruefe, wunsch_pruefen, zustand)

__all__ = ["MAX_DATEI", "MAX_JOBS", "MAX_WARTEND", "STANDARD", "Videowerkstatt", "VwFehler", "graph",
           "pruefe", "zustand"]


class Videowerkstatt:
    def __init__(self, datenordner, holen=None, roh=None):
        self.ordner = os.path.join(datenordner or ".", "videowerkstatt")
        self.holen = holen or antwort_holen
        self.roh = roh or antwort_holen_roh
        self.jobs = OrderedDict()
        self._warte = deque()
        self._sperre = threading.Lock()
        self._weckruf = threading.Event()
        self._faden = None

    def _json(self, werte, pfad, daten=None, zeit=30):
        kopf = {"Content-Type": "application/json"} if daten is not None else {}
        try:
            status, text = self.holen(werte["vw_url"] + pfad, "POST" if daten is not None else "GET", kopf,
                                      json.dumps(daten) if daten is not None else None, zeitgrenze=zeit)
        except Exception as fehler:  # noqa: BLE001
            raise VwFehler("ComfyUI nicht erreichbar: %s" % fehler)
        if status != 200:
            raise VwFehler("ComfyUI: HTTP %s %s" % (status, str(text or "")[:200]))
        try:
            return json.loads(text) if text else {}
        except ValueError:
            raise VwFehler("ComfyUI: keine JSON-Antwort")

    def doctor(self, werte):
        w = pruefe(werte)
        if not w["vw_an"]:
            raise VwFehler("Videowerkstatt ist ausgeschaltet")
        stats = self._json(w, "/system_stats", zeit=10)
        queue = self._json(w, "/queue", zeit=10)
        return {"ok": True, "stats": stats, "queue": queue, "modelle": self.modelle(w),
                "comfyui": bool(stats), "hinweis": "Motion-Modelle und VideoHelperSuite bleiben in ComfyUI."}

    def modelle(self, werte):
        w = pruefe(werte)
        try:
            info = self._json(w, "/object_info/CheckpointLoaderSimple", zeit=10)
            felder = ((info.get("CheckpointLoaderSimple") or {}).get("input") or {}).get("required") or {}
            liste = (felder.get("ckpt_name") or [[]])[0]
            return [str(x) for x in liste] if isinstance(liste, list) else []
        except VwFehler:
            return []

    def _speichern(self, daten, rezept):
        os.makedirs(self.ordner, exist_ok=True)
        endung = ".mp4" if daten[4:8] == b"ftyp" else ".gif" if daten[:3] == b"GIF" else ".webp"
        name = time.strftime("%Y%m%d-%H%M%S") + "-" + uuid.uuid4().hex[:6] + endung
        with open(os.path.join(self.ordner, name), "wb") as f:
            f.write(daten)
        with open(os.path.join(self.ordner, name + ".json"), "w", encoding="utf-8") as f:
            json.dump(dict(rezept, name=name, groesse=len(daten), zeit=int(time.time())), f, ensure_ascii=False)
        self._aufraeumen()
        return name

    def _aufraeumen(self):
        dateien = sorted(n for n in os.listdir(self.ordner) if re.match(r"^[\w.-]+\.(webp|mp4|gif)$", n))
        for alt in dateien[:-300]:
            self.weg(alt)

    def _ausgabe(self, werte, eintrag):
        for ausgabe in (eintrag.get("outputs") or {}).values():
            if not isinstance(ausgabe, dict):
                continue
            for schluessel in ("gifs", "videos", "images"):
                for datei in ausgabe.get(schluessel) or []:
                    if isinstance(datei, dict) and datei.get("filename"):
                        return datei
        return None

    def _ansehen(self, werte, datei):
        query = urlencode({"filename": str(datei.get("filename") or ""),
                           "subfolder": str(datei.get("subfolder") or ""),
                           "type": str(datei.get("type") or "output")})
        try:
            status, daten = self.roh(werte["vw_url"] + "/view?" + query, "GET", {}, None,
                                     zeitgrenze=300, grenze=MAX_DATEI)
        except Exception as fehler:  # noqa: BLE001
            raise VwFehler("Video holen: %s" % fehler)
        if status != 200 or not daten:
            raise VwFehler("Video holen: HTTP %s" % status)
        return daten

    def _erzeugen(self, job, werte, wunsch):
        start = wunsch["seed"] if wunsch["seed"] >= 0 else int(time.time() * 1000) % (2 ** 32)
        for nummer in range(wunsch["anzahl"]):
            if job.get("abbrechen"):
                raise VwFehler("abgebrochen")
            seed = (start + nummer * 7919) % (2 ** 32)
            d = self._json(werte, "/prompt", {"prompt": graph(werte, wunsch, seed), "client_id": job["id"]})
            pid = str(d.get("prompt_id") or "")
            if not pid:
                raise VwFehler("ComfyUI: keine prompt_id")
            job["prompt_id"], job["nr"], job["anzahl"] = pid, nummer + 1, wunsch["anzahl"]
            for _ in range(MAX_LAUF):
                if job.get("abbrechen"):
                    try:
                        self._json(werte, "/interrupt", {}, zeit=10)
                    except VwFehler:
                        pass
                    raise VwFehler("abgebrochen")
                h = self._json(werte, "/history/" + pid, zeit=10)
                eintrag = h.get(pid) if isinstance(h, dict) else None
                if eintrag:
                    if str((eintrag.get("status") or {}).get("status_str") or "").lower() == "error":
                        raise VwFehler("ComfyUI: Auftrag fehlgeschlagen")
                    datei = self._ausgabe(werte, eintrag)
                    if datei:
                        rezept = {k: werte["vw_" + k] for k in ("breite", "hoehe", "frames", "fps", "schritte",
                                                                 "cfg", "sampler", "scheduler", "modell", "format")}
                        rezept.update(prompt=wunsch["prompt"], negativ=wunsch["negativ"], seed=seed,
                                      quelle="ComfyUI", nummer=nummer + 1)
                        job["dateien"].append(self._speichern(self._ansehen(werte, datei), rezept))
                        job["fortschritt"] = int((nummer + 1) * 100 / wunsch["anzahl"])
                        break
                time.sleep(2)
            else:
                raise VwFehler("ComfyUI: Zeitueberschreitung (max. 30 Minuten)")

    def _arbeiten(self):
        while True:
            with self._sperre:
                job_id = self._warte.popleft() if self._warte else None
                job = self.jobs.get(job_id) if job_id else None
                if job:
                    job["status"] = "laeuft"
            if not job:
                self._weckruf.clear()
                if not self._weckruf.wait(60):
                    with self._sperre:
                        if not self._warte:
                            self._faden = None
                            return
                continue
            try:
                self._erzeugen(job, job["werte"], job["wunsch"])
                job["status"] = "abgebrochen" if job.get("abbrechen") else "fertig"
            except Exception as fehler:  # noqa: BLE001 – ein Auftrag darf den Server nicht reissen
                job["status"] = "abgebrochen" if job.get("abbrechen") else "fehler"
                job["fehler"] = str(fehler)[:300]
            finally:
                job["ende"] = int(time.time())

    def start(self, werte, wunsch):
        w = pruefe(werte)
        if not w["vw_an"]:
            raise VwFehler("Videowerkstatt ist ausgeschaltet")
        p = wunsch_pruefen(wunsch, w)
        with self._sperre:
            if len(self._warte) >= MAX_WARTEND:
                raise VwFehler("Schon %d Auftraege in der Warteschlange" % MAX_WARTEND)
            job = {"id": uuid.uuid4().hex[:12], "status": "wartet", "fortschritt": 0, "dateien": [],
                   "fehler": "", "prompt_id": "", "zeit": int(time.time()), "ende": 0, "nr": 0,
                   "anzahl": p["anzahl"], "prompt": p["prompt"][:200], "seed": p["seed"],
                   "werte": w, "wunsch": p}
            self.jobs[job["id"]] = job
            while len(self.jobs) > MAX_JOBS:
                alt = next(iter(self.jobs))
                if self.jobs[alt]["status"] in ("wartet", "laeuft"):
                    break
                self.jobs.pop(alt)
            self._warte.append(job["id"])
            if not self._faden or not self._faden.is_alive():
                self._faden = threading.Thread(target=self._arbeiten, name="videowerkstatt", daemon=True)
                self._faden.start()
        self._weckruf.set()
        return self.job(job["id"])

    def job(self, job_id):
        with self._sperre:
            job = self.jobs.get(str(job_id or ""))
            return self._oeffentlich(job) if job else None

    def liste(self):
        with self._sperre:
            return [self._oeffentlich(j) for j in sorted(self.jobs.values(), key=lambda j: j["zeit"], reverse=True)]

    @staticmethod
    def _oeffentlich(job):
        d = {k: job[k] for k in ("id", "status", "fortschritt", "dateien", "fehler", "prompt_id",
                                 "zeit", "ende", "nr", "anzahl", "prompt", "seed")}
        return d

    def abbrechen(self, job_id):
        with self._sperre:
            job = self.jobs.get(str(job_id or ""))
            if not job:
                raise VwFehler("Unbekannter Auftrag")
            job["abbrechen"] = True
            if job["status"] == "wartet" and job["id"] in self._warte:
                self._warte.remove(job["id"])
                job["status"] = "abgebrochen"
                job["ende"] = int(time.time())
            return self._oeffentlich(job)

    def weg(self, name):
        pfad = self.datei(name)
        for p in (pfad, pfad + ".json"):
            try:
                os.remove(p)
            except OSError:
                pass

    def datei(self, name):
        if not re.match(r"^[\w.-]+\.(webp|mp4|gif)$", str(name or "")):
            raise VwFehler("Unbekannte Datei")
        pfad = os.path.join(self.ordner, name)
        if not os.path.isfile(pfad):
            raise VwFehler("Datei nicht da")
        return pfad

    def galerie(self):
        if not os.path.isdir(self.ordner):
            return []
        namen = sorted((n for n in os.listdir(self.ordner) if re.match(r"^[\w.-]+\.(webp|mp4|gif)$", n)),
                       reverse=True)
        eintraege = []
        for name in namen:
            rezept = {}
            try:
                with open(os.path.join(self.ordner, name + ".json"), encoding="utf-8") as f:
                    rezept = json.load(f)
            except (OSError, ValueError):
                pass
            rezept.update(name=name)
            eintraege.append(rezept)
        return eintraege
