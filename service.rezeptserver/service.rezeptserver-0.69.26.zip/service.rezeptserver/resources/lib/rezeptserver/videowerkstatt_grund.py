"""Videowerkstatt: Regeln, Einstellungen, Wunsch und ComfyUI-Workflow.

Vorbild ist der AnimateDiff-Video-Workflow aus OmniRoute (MIT): Checkpoint laden,
Prompt/negativen Prompt kodieren, Bildfolge als Latent, samplen, dekodieren und als
animiertes WebP oder per VideoHelperSuite als MP4 speichern. H0rSt baut den Graphen
selbst nach; Modelle, Motion-Module und Ausgabeknoten bleiben in ComfyUI.
"""

import re
from urllib.parse import urlsplit

SCHLUESSEL = "videowerkstatt"
MAX_JOBS = 30
MAX_WARTEND = 20
MAX_DATEI = 200 * 1024 * 1024
MAX_LAUF = 1800
STANDARD = {
    "vw_an": False, "vw_url": "http://127.0.0.1:8188", "vw_modell": "",
    "vw_breite": "832", "vw_hoehe": "480", "vw_frames": "16", "vw_fps": "8",
    "vw_schritte": "20", "vw_cfg": "7.0", "vw_sampler": "euler", "vw_scheduler": "normal",
    "vw_seed": "-1", "vw_anzahl": "1", "vw_format": "webp",
    "vw_negativ": "worst quality, low quality, blurry, watermark, text",
}
SAMPLER = ("euler", "euler_ancestral", "dpmpp_2m", "dpmpp_2m_sde", "dpmpp_sde", "lcm")
SCHEDULER = ("normal", "karras", "exponential", "sgm_uniform", "simple", "beta")
FORMATE = ("webp", "mp4")
GROESSEN = ("832x480", "512x512", "768x512", "1280x720", "1024x576")


class VwFehler(ValueError):
    pass


def _text(wert, laenge):
    return " ".join(str(wert or "").split())[:laenge]


def _zahl(wert, standard, klein, gross):
    try:
        zahl = int(float(str(wert).replace(",", ".")))
        if zahl < 0 and standard < 0:
            return standard
        return max(klein, min(gross, zahl))
    except (TypeError, ValueError, OverflowError):
        return standard


def _wahl(wert, erlaubt, standard):
    wert = str(wert or "").strip().lower()
    return wert if wert in erlaubt else standard


def _adresse(wert):
    url = str(wert or "").strip().rstrip("/")
    if re.match(r"^[A-Za-z][A-Za-z0-9+.-]*://", url) and not re.match(r"^https?://", url, re.I):
        raise VwFehler("ComfyUI-Adresse muss http:// oder https:// sein")
    if not re.match(r"^https?://", url, re.I):
        url = "http://" + url
    try:
        teile = urlsplit(url)
    except ValueError:
        raise VwFehler("ComfyUI-Adresse ungueltig")
    if teile.scheme not in ("http", "https") or not teile.hostname:
        raise VwFehler("ComfyUI-Adresse wie http://127.0.0.1:8188 erwartet")
    return url[:300]


def pruefe(roh):
    roh = roh if isinstance(roh, dict) else {}
    breite = _zahl(roh.get("vw_breite"), 832, 64, 2048) // 8 * 8
    hoehe = _zahl(roh.get("vw_hoehe"), 480, 64, 2048) // 8 * 8
    return {
        "vw_an": roh.get("vw_an") is True,
        "vw_url": _adresse(roh.get("vw_url") or STANDARD["vw_url"]),
        "vw_modell": _text(roh.get("vw_modell"), 200),
        "vw_breite": str(breite), "vw_hoehe": str(hoehe),
        "vw_frames": str(_zahl(roh.get("vw_frames"), 16, 1, 64)),
        "vw_fps": str(_zahl(roh.get("vw_fps"), 8, 1, 30)),
        "vw_schritte": str(_zahl(roh.get("vw_schritte"), 20, 1, 100)),
        "vw_cfg": str(_zahl(roh.get("vw_cfg"), 7, 1, 20)),
        "vw_sampler": _wahl(roh.get("vw_sampler"), SAMPLER, "euler"),
        "vw_scheduler": _wahl(roh.get("vw_scheduler"), SCHEDULER, "normal"),
        "vw_seed": str(_zahl(roh.get("vw_seed"), -1, -1, 2 ** 32 - 1)),
        "vw_anzahl": str(_zahl(roh.get("vw_anzahl"), 1, 1, 4)),
        "vw_format": _wahl(roh.get("vw_format"), FORMATE, "webp"),
        "vw_negativ": _text(roh.get("vw_negativ") or STANDARD["vw_negativ"], 1000),
    }


def zustand(werte):
    w = pruefe(werte)
    return {"an": w["vw_an"], "url": w["vw_url"], "modell": w["vw_modell"],
            "breite": w["vw_breite"], "hoehe": w["vw_hoehe"], "frames": w["vw_frames"],
            "fps": w["vw_fps"], "schritte": w["vw_schritte"], "cfg": w["vw_cfg"],
            "sampler": w["vw_sampler"], "scheduler": w["vw_scheduler"], "seed": w["vw_seed"],
            "anzahl": w["vw_anzahl"], "format": w["vw_format"], "negativ": w["vw_negativ"],
            "sampler_liste": list(SAMPLER), "scheduler_liste": list(SCHEDULER),
            "formate": list(FORMATE), "groessen": list(GROESSEN),
            "hinweis": "Modelle, Motion-Module und der Ausgabeknoten bleiben in ComfyUI. "
                       "MP4 braucht die VideoHelperSuite (VHS_VideoCombine); sonst animiertes WebP."}


def wunsch_pruefen(roh, werte):
    if not isinstance(roh, dict):
        raise VwFehler("JSON-Objekt erwartet")
    w = pruefe(werte)
    prompt = str(roh.get("prompt") or "").strip()[:4000]
    if not prompt:
        raise VwFehler("Prompt fehlt")
    if not w["vw_modell"]:
        raise VwFehler("Checkpoint fehlt (Einstellungen -> Videowerkstatt oder ComfyUI-Modelle laden)")
    return {"prompt": prompt, "negativ": _text(roh.get("negativ") or w["vw_negativ"], 1000),
            "seed": _zahl(roh.get("seed"), int(w["vw_seed"]), -1, 2 ** 32 - 1),
            "anzahl": _zahl(roh.get("anzahl"), int(w["vw_anzahl"]), 1, 4)}


def graph(werte, wunsch, seed):
    """ComfyUI-Workflow fuer eine kurze Bildfolge (AnimateDiff-taugliches Grundgeruest)."""
    w = pruefe(werte)
    g = {
        "1": {"class_type": "CheckpointLoaderSimple", "inputs": {"ckpt_name": w["vw_modell"]}},
        "2": {"class_type": "CLIPTextEncode", "inputs": {"text": wunsch["prompt"], "clip": ["1", 1]}},
        "3": {"class_type": "CLIPTextEncode", "inputs": {"text": wunsch["negativ"], "clip": ["1", 1]}},
        "4": {"class_type": "EmptyLatentImage", "inputs": {"width": int(w["vw_breite"]),
                                                           "height": int(w["vw_hoehe"]),
                                                           "batch_size": int(w["vw_frames"])}},
        "5": {"class_type": "KSampler", "inputs": {
            "model": ["1", 0], "positive": ["2", 0], "negative": ["3", 0], "latent_image": ["4", 0],
            "seed": seed, "steps": int(w["vw_schritte"]), "cfg": float(w["vw_cfg"]),
            "sampler_name": w["vw_sampler"], "scheduler": w["vw_scheduler"], "denoise": 1.0}},
        "6": {"class_type": "VAEDecode", "inputs": {"samples": ["5", 0], "vae": ["1", 2]}},
    }
    if w["vw_format"] == "mp4":
        g["7"] = {"class_type": "VHS_VideoCombine", "inputs": {
            "images": ["6", 0], "frame_rate": int(w["vw_fps"]), "loop_count": 0,
            "filename_prefix": "h0rst-video", "format": "video/h264-mp4", "pingpong": False,
            "save_output": True}}
    else:
        g["7"] = {"class_type": "SaveAnimatedWEBP", "inputs": {
            "images": ["6", 0], "fps": int(w["vw_fps"]), "lossless": False, "quality": 80,
            "method": "default", "filename_prefix": "h0rst-video"}}
    return g
