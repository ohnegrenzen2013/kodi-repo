"""Vorlagen fuer Anbieter und das Anbieter-JSON.

Eine Vorlage ist ein fertig ausgefuellter eigener Anbieter: Kategorie, Typ, Anmeldeart und Standardwerte
(z. B. Server und Port eines Usenet-Providers oder die API-Adresse eines Indexers). Der Nutzer traegt nur
noch seine Zugangsdaten ein.

Anbieter lassen sich ausserdem per JSON hinzufuegen, als Datei oder ueber eine Adresse, so wie Stremio,
Nuvio oder ARVIO Addons ueber ihre manifest.json einbinden. Erkannt werden:

  1. H0rSt-Anbieter-JSON   {"format": "h0rst-anbieter", "version": 1, "anbieter": [
                              {"vorlage": "nzbgeek", "werte": {"api_key": "..."}},
                              {"name": "Mein Indexer", "kategorie": "indexer", "typ": "newznab",
                               "anmeldung": "url_api", "werte": {"url": "https://...", "api_key": "..."}}]}
     (auch eine blosse Liste solcher Eintraege oder ein einzelner Eintrag)
  2. Stremio-Addon-Manifest  {"id": "...", "name": "...", "resources": [...], "types": [...]}
     -> Anbieter vom Typ stremio-addon; die Adresse der manifest.json ist der Zugang
  3. vxparser-Linkliste      {"megakino": "https://...", "vavoo_api": "https://...", ...}
     -> je bekanntem Schluessel ein vxparser-Link (wie vxparsers url_list)
"""

from .vorlagen_grund import *
from .vorlagen_bauen import NACH_ID, VORLAGEN, _WG_HINWEIS, _debrid, _newznab, _nntp, _proxy, _v, _wg
from .vorlagen_json import aus_text, eintraege_aus_json, holen_json, ist_manifest, ist_mhub_manifest, manifest_adresse
from .vorlagen_anbieter import anlegen, ausgeben, einlesen, liste
