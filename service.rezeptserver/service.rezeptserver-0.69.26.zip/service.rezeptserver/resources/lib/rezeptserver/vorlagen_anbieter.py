"""Vorlagen anwenden: eigene Anbieter anlegen, JSON einlesen und ausgeben."""

from .vorlagen_grund import (
    FORMAT,
    FORMAT_VERSION,
    VorlagenFehler,
    anbieter,
    json,
)

from .vorlagen_bauen import NACH_ID, VORLAGEN

from .vorlagen_json import eintraege_aus_json

def liste():
    """Alle Vorlagen nach Kategorie, mit Feldern (Standardwerte vorbelegt)."""
    reihenfolge = list(anbieter.KATEGORIEN)
    ergebnis = []
    for v in sorted(VORLAGEN, key=lambda v: reihenfolge.index(v["kategorie"])):
        felder = []
        for f in anbieter.FELDER[v["anmeldung"]]:
            felder.append(dict(f, wert=v["werte"].get(f["key"], "")))
        ergebnis.append(dict(v, felder=felder, kategorie_name=anbieter.KATEGORIEN[v["kategorie"]],
                             typ_name=anbieter.TYPEN[v["typ"]], anmeldung_name=anbieter.ANMELDUNGEN[v["anmeldung"]]))
    return ergebnis


def anlegen(daten, module, vorlage_id, werte=None, name=None):
    """Eigenen Anbieter aus einer Vorlage anlegen; werte ergaenzen/ueberschreiben die Standardwerte."""
    v = NACH_ID.get(vorlage_id)
    if not v:
        raise VorlagenFehler("Unbekannte Vorlage: %s" % vorlage_id)
    name = (name or "").strip() or v["name"]
    if v["typ"] == "vxparser-link":
        # ein Link je Schluessel: vorhandenen Eintrag aktualisieren statt doppelt anlegen
        for anbieter_id, eintrag in (daten.get("anbieter") or {}).items():
            if eintrag.get("vorlage") == vorlage_id:
                anbieter.zugang_setzen(daten, module, anbieter_id, dict(v["werte"], **(werte or {})))
                return anbieter_id
    gesamt = dict(v["werte"])
    # nur fehlende Werte nehmen den Standard der Vorlage; ein leerer Wert ist gewollt (z. B. abgewaehlter Schalter)
    gesamt.update({k: w for k, w in (werte or {}).items() if w is not None})
    anbieter_id = anbieter.freie_id(daten, module, name)
    return anbieter.hinzufuegen(daten, module, name, v["kategorie"], v["anmeldung"], gesamt, typ=v["typ"],
                                vorlage=vorlage_id, anbieter_id=anbieter_id)


def einlesen(daten, module, roh, quelle=None):
    """Legt alle Anbieter aus dem JSON an. Gibt die Liste der neuen (oder aktualisierten) ids zurueck.

    Alles oder nichts: bei einem Fehler bleibt daten unveraendert."""
    eintraege = eintraege_aus_json(roh, quelle)
    arbeit = json.loads(json.dumps(daten))
    ids = []
    for e in eintraege:
        try:
            if e.get("vorlage"):
                ids.append(anlegen(arbeit, module, e["vorlage"], e["werte"], e.get("name")))
            else:
                if e["anmeldung"] not in anbieter.EIGENE_ANMELDUNGEN:
                    raise VorlagenFehler("%s: Anmeldung %s nicht erlaubt" % (e["name"], e["anmeldung"]))
                anbieter_id = anbieter.freie_id(arbeit, module, e["name"])
                ids.append(anbieter.hinzufuegen(arbeit, module, e["name"], e["kategorie"], e["anmeldung"],
                                                e["werte"], typ=e["typ"], anbieter_id=anbieter_id))
        except anbieter.AnbieterFehler as fehler:
            raise VorlagenFehler(str(fehler))
    daten.clear()
    daten.update(arbeit)
    return ids


def ausgeben(daten, geheimnisse=False):
    """Eigene Anbieter als H0rSt-Anbieter-JSON. Ohne geheimnisse fehlen Passwoerter und API-Schluessel."""
    werte = daten.get("einstellungen") or {}
    liste_ = []
    for anbieter_id, e in sorted((daten.get("anbieter") or {}).items()):
        geheim = {f["key"] for f in anbieter.FELDER[e["anmeldung"]] if f.get("typ") == "passwort"}
        eintrag = {"name": e["name"], "kategorie": e["kategorie"], "typ": e.get("typ", ""),
                   "anmeldung": e["anmeldung"],
                   "werte": {k: w for k, w in (werte.get(anbieter_id) or {}).items()
                             if geheimnisse or k not in geheim}}
        if e.get("vorlage"):
            eintrag["vorlage"] = e["vorlage"]
        liste_.append(eintrag)
    return {"format": FORMAT, "version": FORMAT_VERSION, "anbieter": liste_}


