"""Vorlagen bauen: die Hilfen fuer Eintraege und die feste Liste VORLAGEN samt NACH_ID."""

from .vorlagen_grund import (
    vxparser,
)

def _v(vid, name, kategorie, typ, anmeldung, werte=None, hinweis="", seite=""):
    return {"id": vid, "name": name, "kategorie": kategorie, "typ": typ, "anmeldung": anmeldung,
            "werte": werte or {}, "hinweis": hinweis, "seite": seite}


def _nntp(vid, name, host, seite="", port="563"):
    return _v(vid, name, "usenet", "nntp", "nntp", {"host": host, "port": port, "ssl": "1", "verbindungen": "8"},
              "Server und Port laut Kundenbereich prüfen. Wird für NZB-Streams in Stremio genutzt.", seite)


def _newznab(vid, name, url, seite=""):
    return _v(vid, name, "indexer", "newznab", "url_api", {"url": url},
              "API-Schlüssel steht im Profil des Indexers. Sucht Filme und Serien, Streams per NZB.", seite)


def _debrid(vid, name, seite):
    return _v(vid, name, "hoster", "debrid", "api", {}, "API-Schlüssel aus dem Kontobereich.", seite)


_WG_HINWEIS = ("Konfigurationsdatei (.conf) beim Anbieter erzeugen und ihren Inhalt hier einfügen. "
               "In der App verbindet H0rSt damit selbst (Tab Sicherheit), auf PC/Pi mit wg-quick.")


def _wg(vid, name, seite, hinweis=""):
    return _v(vid, name, "sicherheit", "wireguard", "wireguard", {}, (hinweis + " " if hinweis else "") + _WG_HINWEIS, seite)


def _proxy(vid, name, typ, host, port, hinweis, seite=""):
    return _v(vid, name, "sicherheit", typ, "proxy", {"host": host, "port": port}, hinweis, seite)


VORLAGEN = [
    # Usenet-Provider (NNTP)
    # Sicherheit: VPN (WireGuard), Tor, I2P, Proxys
    _wg("wg-mullvad", "Mullvad (WireGuard)", "https://mullvad.net/de/account/wireguard-config",
        "Ohne E-Mail, auch bar bezahlbar, keine Protokolle."),
    _wg("wg-proton", "Proton VPN (WireGuard)", "https://account.protonvpn.com/downloads",
        "Unter Downloads → WireGuard-Konfiguration; auch im kostenlosen Tarif."),
    _wg("wg-ivpn", "IVPN (WireGuard)", "https://www.ivpn.net/account/wireguard-config"),
    _wg("wg-airvpn", "AirVPN (WireGuard)", "https://airvpn.org/generator/", "Im Config Generator WireGuard wählen."),
    _wg("wg-windscribe", "Windscribe (WireGuard)", "https://windscribe.com/getconfig/wireguard"),
    _wg("wg-surfshark", "Surfshark (WireGuard)", "https://my.surfshark.com",
        "Im Konto unter VPN → Manuelle Einrichtung → WireGuard."),
    _wg("wg-warp", "Cloudflare WARP (WireGuard)", "https://github.com/ViRb3/wgcf",
        "Kostenlos; die .conf erzeugt das Programm wgcf (wgcf register, wgcf generate). Verschlüsselt, aber nicht anonym."),
    _wg("wg-fritzbox", "FRITZ!Box zu Hause (WireGuard)", "https://avm.de/service/vpn/",
        "Sicher ins eigene Heimnetz: FRITZ!OS 7.50+, Internet → Freigaben → VPN (WireGuard) → Gerät hinzufügen. "
        "Unterwegs erreichst du dann H0rSt, NAS und Dienste zu Hause, und fremde WLANs sehen nichts."),
    _wg("wg-eigen", "Eigener WireGuard-Server (PiVPN, Router …)", "https://pivpn.io",
        "Auf dem Pi: pivpn add, die erzeugte .conf hier einfügen."),
    _proxy("tor", "Tor (Orbot oder tor)", "tor", "127.0.0.1", "9050",
           "In der App: Orbot installieren und hier starten. Auf PC/Pi: Dienst tor (SOCKS 9050). Langsam, aber anonym; "
           ".onion-Adressen gehen nur so.", "https://orbot.app"),
    _proxy("i2p", "I2P (i2pd)", "i2p", "127.0.0.1", "4447",
           "i2pd starten (App „PurpleI2P“ oder Dienst i2pd), SOCKS-Port 4447. Für .i2p-Seiten.", "https://i2pd.website"),
    _proxy("i2p-http", "I2P über HTTP-Proxy (Java-I2P oder i2pd)", "i2p", "127.0.0.1", "4444",
           "Der Java-Router (geti2p.net, App „I2P“) hat keinen SOCKS-Port, aber den HTTP-Proxy 4444; i2pd hat ihn auch. "
           "Für .i2p-Seiten.", "https://geti2p.net/de/"),
    _proxy("mullvad-socks", "Mullvad SOCKS5 (zweiter Ausgang)", "socks5", "10.64.0.1", "1080",
           "Nur bei laufender Mullvad-Verbindung erreichbar. Für einen anderen Ausgang einen Mullvad-Server als Host "
           "eintragen (z. B. se-got-wg-socks5-001.relays.mullvad.net) – H0rSt nimmt dann einen zweiten Sprung.",
           "https://mullvad.net/de/help/socks5-proxy"),
    _proxy("nordvpn-socks", "NordVPN SOCKS5", "socks5", "amsterdam.nl.socks.nordhold.net", "1080",
           "Dienst-Zugangsdaten (nicht das Konto-Passwort) aus dem NordVPN-Konto unter Manuelle Einrichtung.",
           "https://my.nordaccount.com/dashboard/nordvpn/manual-configuration/"),
    _proxy("pia-socks", "Private Internet Access SOCKS5", "socks5", "proxy-nl.privateinternetaccess.com", "1080",
           "Eigene SOCKS-Zugangsdaten im PIA-Kontrollfeld erzeugen.", "https://www.privateinternetaccess.com"),
    _proxy("socks-eigen", "Eigener SOCKS5-Proxy (z. B. ssh -D 1080)", "socks5", "", "1080",
           "Z. B. ein SSH-Tunnel zum eigenen Server: ssh -D 1080 -N benutzer@server.", ""),
    _proxy("http-proxy", "Eigener HTTP-Proxy", "http-proxy", "", "8080", "HTTPS geht per CONNECT verschlüsselt durch.", ""),
    _nntp("eweka", "Eweka", "news.eweka.nl", "https://www.eweka.nl"),
    _v("newshosting", "Newshosting", "usenet", "nntp", "nntp",
       {"host": "news.newshosting.com", "port": "563", "ssl": "1", "verbindungen": "30"},
       "Benutzer und Passwort aus dem Newshosting-Kundenbereich; SSL auf Port 563 (Alternative 443), je nach Tarif bis zu "
       "100 Verbindungen. H0rSt nutzt den Zugang überall: NZB-Streams in Stremio, NZBGet in der App, rustnzb („Server "
       "übertragen“) und – von Hand eingetragen – NzbDAV/AltMount. Der Newshosting-Client selbst ist ein Desktop-Programm "
       "ohne Schnittstelle; seine Suche ersetzen in H0rSt binsearch und deine Indexer (oder NZBHydra2).",
       "https://www.newshosting.com"),
    _nntp("usenetexpress", "UsenetExpress", "news.usenetexpress.com", "https://www.usenetexpress.com"),
    _nntp("frugalusenet", "Frugal Usenet", "news.frugalusenet.com", "https://frugalusenet.com"),
    _nntp("tweaknews", "Tweaknews", "news.tweaknews.eu", "https://www.tweaknews.eu"),
    _nntp("giganews", "Giganews", "news.giganews.com", "https://www.giganews.com"),
    _nntp("newsgroupninja", "Newsgroup Ninja", "news.newsgroup.ninja", "https://www.newsgroup.ninja"),
    _nntp("usenetfarm", "Usenet.Farm", "news.usenet.farm", "https://www.usenet.farm"),
    _nntp("easynews-nntp", "Easynews (NNTP)", "secure.news.easynews.com", "https://www.easynews.com"),
    _nntp("nntp", "Eigener Usenet-Server", "", ""),
    # Usenet-Indexer (Newznab) und Meta-Indexer
    _newznab("nzbgeek", "NZBgeek", "https://api.nzbgeek.info", "https://nzbgeek.info"),
    _newznab("nzbfinder", "NZBFinder", "https://nzbfinder.ws", "https://nzbfinder.ws"),
    _newznab("drunkenslug", "DrunkenSlug", "https://drunkenslug.com", "https://drunkenslug.com"),
    _newznab("nzbplanet", "NZBPlanet", "https://api.nzbplanet.net", "https://nzbplanet.net"),
    _newznab("dognzb", "DOGnzb", "https://api.dognzb.cr", "https://dognzb.cr"),
    _newznab("althub", "altHUB", "https://api.althub.co.za", "https://althub.co.za"),
    _newznab("ninjacentral", "NinjaCentral", "https://ninjacentral.co.za", "https://ninjacentral.co.za"),
    _newznab("nzbsu", "nzb.su", "https://api.nzb.su", "https://nzb.su"),
    _newznab("scenenzbs", "SceneNZBs", "https://scenenzbs.com", "https://scenenzbs.com"),
    _newznab("usenet-crawler", "Usenet-Crawler", "https://www.usenet-crawler.com", "https://www.usenet-crawler.com"),
    _v("nzbhydra2", "NZBHydra2 (Meta-Indexer)", "indexer", "newznab", "url_api", {"url": "http://127.0.0.1:5076"},
       "Bündelt alle deine Usenet-Indexer hinter einer Adresse: H0rSt fragt nur Hydra, Hydra fragt alle (Statistik, "
       "Limits und Suchverlauf bleiben in Hydra). Auch binsearch über H0rSt lässt sich in Hydra als Newznab-Indexer "
       "eintragen. API-Schlüssel: Config → Main → Security.", "https://github.com/theotherp/nzbhydra2"),
    _v("nzbhydra2-torznab", "NZBHydra2 (Torznab)", "indexer", "torznab", "url_api", {"url": "http://127.0.0.1:5076/torznab"},
       "Die Torrent-Indexer, die NZBHydra2 bündelt (Torznab unter /torznab/api). API-Schlüssel wie bei Newznab: "
       "Config → Main → Security.", "https://github.com/theotherp/nzbhydra2"),
    _v("binsearch", "binsearch (Usenet-Suche ohne Konto)", "indexer", "binsearch", "keine", {},
       "Freie Usenet-Suche in den Betreffzeilen der Binär-Newsgroups – ohne Konto und API-Schlüssel. Findet weniger "
       "sauber benannte Releases als Indexer, dafür alles, was im Usenet steht. Abspielen über deinen Usenet-Provider "
       "(z. B. Newshosting), NzbDAV, AltMount oder rustnzb. Für NZBHydra2, Prowlarr, Sonarr und Radarr gibt es "
       "binsearch über H0rSt als Newznab-Indexer: Adresse http://<H0rSt>:<Port>/<token>/binsearch/api "
       "oder ohne Token im Pfad und das Token als API-Schlüssel.",
       "https://www.binsearch.info"),
    _newznab("newznab", "Eigener Newznab-Indexer", "", ""),
    _v("spotweb-nzbfinder", "Spotweb (NZBFinder)", "indexer", "newznab", "url_api", {"url": "https://spotweb.nzbfinder.ws"},
       "Spots aus dem Usenet (Spotnet) über die Spotweb-Instanz von NZBFinder, mit Newznab-API: Filme, Serien, Musik, "
       "Software. API-Schlüssel aus deinem NZBFinder-Konto (Profil → API). Durchsuchbar in Dateisuche → Indexer & Spotweb "
       "und als Quelle für Filme und Serien.", "https://spotweb.nzbfinder.ws"),
    _v("spotweb", "Eigener Spotweb-Server", "indexer", "newznab", "url_api", {"url": "http://spotweb.local/spotweb"},
       "Spotweb (github.com/spotweb/spotweb) auf deinem Server: Adresse der Spotweb-Seite, API-Schlüssel unter "
       "Einstellungen → Benutzer → API-Schlüssel.", "https://github.com/spotweb/spotweb"),
    _v("prowlarr", "Prowlarr (Torznab)", "indexer", "torznab", "url_api", {"url": "http://127.0.0.1:9696/1"},
       "Adresse eines Indexers in Prowlarr (…/<id>), API-Schlüssel unter Settings → General.",
       "https://prowlarr.com"),
    _v("jackett", "Jackett (Torznab)", "indexer", "torznab", "url_api",
       {"url": "http://127.0.0.1:9117/api/v2.0/indexers/all/results/torznab"},
       "Torznab-Adresse aus Jackett, API-Schlüssel oben rechts in Jackett.", "https://github.com/Jackett/Jackett"),
    _v("torznab", "Eigener Torznab-Indexer", "indexer", "torznab", "url_api", {}, "", ""),
    # Hoster & Debrid
    _debrid("realdebrid", "Real-Debrid", "https://real-debrid.com/apitoken"),
    _debrid("alldebrid", "AllDebrid", "https://alldebrid.com/apikeys/"),
    _debrid("premiumize", "Premiumize", "https://www.premiumize.me/account"),
    _debrid("torbox", "TorBox", "https://torbox.app/settings"),
    _debrid("debridlink", "Debrid-Link", "https://debrid-link.com/webapp/apikey"),
    _v("1fichier", "1fichier", "hoster", "", "api", {}, "Premium-API-Schlüssel aus den Kontoeinstellungen.",
       "https://1fichier.com"),
    _v("rapidgator", "Rapidgator", "hoster", "", "login", {}, "Premium-Zugang.", "https://rapidgator.net"),
    _v("ddownload", "DDownload", "hoster", "", "api", {}, "API-Schlüssel aus dem Kontobereich.",
       "https://ddownload.com"),
    _v("hoster-login", "Eigener Hoster (Login)", "hoster", "", "url_login", {}, "", ""),
    _v("hoster-api", "Eigener Hoster (API)", "hoster", "", "url_api", {}, "", ""),
    # Stremio-Addons (wie in Stremio, Nuvio und ARVIO ueber die manifest.json)
    _v("cinemeta", "Cinemeta", "addons", "stremio-addon", "url",
       {"url": "https://v3-cinemeta.strem.io/manifest.json"}, "Offizielles Metadaten-Addon von Stremio.",
       "https://www.stremio.com"),
    _v("opensubtitles-v3", "OpenSubtitles v3", "addons", "stremio-addon", "url",
       {"url": "https://opensubtitles-v3.strem.io/manifest.json"}, "Untertitel-Addon von Stremio.",
       "https://www.stremio.com"),
    _v("streambridge-emby", "StreamBridge (Emby)", "addons", "stremio-addon", "url", {},
       "Streams vom eigenen Emby-Server zu Filmen und Serien (IMDb/TMDB). Auf der Konfigurationsseite Emby-Adresse, "
       "User ID und Access Token eintragen – der Helfer dort holt beides mit Benutzer und Passwort –, dann die erzeugte "
       "manifest.json-Adresse hier einfügen (stremio:// geht auch).",
       "https://39427cdac546-streambridge.baby-beamup.club/configure"),
    _v("stremio-addon", "Stremio-Addon (manifest.json)", "addons", "stremio-addon", "url", {},
       "Adresse der manifest.json, wie in Stremio, Nuvio oder ARVIO. stremio:// geht auch.", ""),
    _v("mhub-addon", "mHub-Addon (mhub-addon.json)", "addons", "mhub-addon", "url", {},
       "Adresse eines mHub-Addons (MediaHubMX-Protokoll v2): die mhub-addon.json oder die Basis-Adresse. Dessen Quellen, "
       "Untertitel und Suchkataloge kommen zu Filmen und Serien dazu.", "https://www.mhub.mx"),
    # IPTV & vxparser
    _v("vxparser", "vxparser", "iptv", "vxparser", "url", {"url": vxparser.STANDARD_ADRESSE},
       "vxparser-Server (Termux-App 0.118.3+vxparser.1.5.1 oder pip). Auf diesem Gerät: http://127.0.0.1:8080.",
       "https://github.com/Mastaaa1987/vxparser"),
    _v("xtream", "Xtream-Codes-Zugang", "iptv", "xtream", "url_login", {},
       "Eigenes IPTV-Abo mit Xtream-Zugang (Server, Benutzer, Passwort).", ""),
    # Eigene Medienserver: Filme und Folgen aus der eigenen Mediathek als Quelle (Direct Play)
    _v("jellyfin", "Jellyfin", "heimserver", "jellyfin", "url_api", {"url": "http://192.168.1.10:8096"},
       "Adresse deines Jellyfin-Servers und ein API-Schlüssel (Dashboard → API-Schlüssel → +). Filme und Folgen aus "
       "deiner Mediathek erscheinen dann als Quelle, gefunden über die IMDb-Nummer, sonst über Titel und Jahr.",
       "https://jellyfin.org"),
    _v("emby", "Emby", "heimserver", "emby", "url_api", {"url": "http://192.168.1.10:8096"},
       "Adresse deines Emby-Servers und ein API-Schlüssel (Einstellungen → Erweitert → API-Schlüssel). Filme und Folgen "
       "aus deiner Mediathek erscheinen dann als Quelle.", "https://emby.media"),
    _v("plex", "Plex", "heimserver", "plex", "url_api", {"url": "http://192.168.1.10:32400"},
       "Adresse deines Plex-Servers und dein Plex-Token als API-Schlüssel (in Plex Web bei einem Titel „…“ → "
       "„Medien-Info“ → „XML anzeigen“: der Wert X-Plex-Token in der Adresse). Filme und Folgen aus deiner Mediathek "
       "erscheinen dann als Quelle.", "https://support.plex.tv/articles/204059436"),
    # Downloader
    _v("sabnzbd", "SABnzbd", "downloader", "sabnzbd", "url_api", {"url": "http://127.0.0.1:8080"},
       "API-Schlüssel unter Config → General. NZB-Treffer lassen sich dorthin schicken.", "https://sabnzbd.org"),
    _v("nzbdav", "NzbDAV (Usenet-Streaming)", "downloader", "nzbdav", "nzbdav", {"url": "http://127.0.0.1:3000"},
       "Spielt NZB-Treffer ohne Herunterladen: H0rSt bindet die NZB ein und streamt die Videodatei per WebDAV, mit "
       "Vorspulen. Dazu Warteschlange und Verlauf. API-Schlüssel unter Settings → SABnzbd, WebDAV-Zugang unter Settings → "
       "WebDAV, Usenet-Provider (z. B. Newshosting) in NzbDAV selbst eintragen. Das Original wird nicht mehr gepflegt – "
       "Abzweigungen wie nzbdavex oder infinidysk gehen genauso.", "https://github.com/nzbdav-dev/nzbdav"),
    _v("altmount", "AltMount (Usenet-Streaming)", "downloader", "altmount", "nzbdav", {"url": "http://127.0.0.1:8080"},
       "Nachfolger-Idee von NzbDAV: NZBs per WebDAV streamen, ohne Download. API-Schlüssel und WebDAV-Zugang aus den "
       "AltMount-Einstellungen.", "https://github.com/kipsilabs/altmount"),
    _v("rustnzb", "rustnzb", "downloader", "rustnzb", "rustnzb", {"url": "http://127.0.0.1:9090"},
       "Usenet-Downloader mit Mediathek: NZB-Treffer in jedem Player streamen, Downloads, Warteschlange im Bereich "
       "Downloads. API-Schlüssel: general.api_key in der config.toml; Mediathek: [dav] enabled = true.",
       "https://github.com/TheDancingDeveloper-org/rustnzb"),
    _v("nzbget", "NZBGet", "downloader", "nzbget", "url_login", {"url": "http://127.0.0.1:6789"},
       "Benutzer und Passwort aus Settings → Security (ControlUsername/ControlPassword). Abgestimmt auf v26.3: "
       "Warteschlange, Verlauf, Tempolimit, NZB senden (H0rSt lädt die NZB selbst).", "https://nzbget.com"),
    _v("qbittorrent", "qBittorrent", "downloader", "qbittorrent", "url_login_optional", {"url": "http://127.0.0.1:8080"},
       "Web-UI-Zugang (Optionen → Web-UI). Torrents aus der Suche lassen sich hierher schicken.",
       "https://www.qbittorrent.org"),
    _v("transmission", "Transmission", "downloader", "transmission", "url_login_optional",
       {"url": "http://127.0.0.1:9091"}, "RPC-Zugang (rpc-username/rpc-password), falls gesetzt.",
       "https://transmissionbt.com"),
    _v("deluge", "Deluge", "downloader", "deluge", "url_pass", {"url": "http://127.0.0.1:8112"},
       "Passwort der Deluge-Weboberfläche.", "https://deluge-torrent.org"),
    _v("downloadmaster", "ASUS Download Master", "downloader", "downloadmaster", "url_login",
       {"url": "http://router.asus.com:8081"},
       "Download Master am ASUS-Router (USB-Anwendung, Port 8081), Zugang wie der Router. Lädt HTTP, FTP, Torrents/"
       "Magnet, NZB und ed2k direkt auf die USB-Platte. Bei Router-IP z. B. http://192.168.50.1:8081.",
       "https://www.asus.com/support/faq/114001/"),
    # Netzwerk
    _v("pihole", "Pi-hole", "medien", "pihole", "url_pass", {"url": "http://pi.hole"},
       "Pi-hole v6: Passwort der Weboberfläche oder App-Passwort (Settings → Web interface/API); v5: API-Token. "
       "Mit Docker (docker/docker-compose.yml, Profil pihole) z. B. http://127.0.0.1:8053.", "https://pi-hole.net"),
    # Medienverwaltung (wie nzb360)
    _v("sonarr", "Sonarr", "medien", "sonarr", "url_api", {"url": "http://127.0.0.1:8989"},
       "API-Schlüssel unter Settings → General. Kalender, Warteschlange, Fehlendes, Serien aus der Suche hinzufügen.",
       "https://sonarr.tv"),
    _v("radarr", "Radarr", "medien", "radarr", "url_api", {"url": "http://127.0.0.1:7878"},
       "API-Schlüssel unter Settings → General. Kalender, Warteschlange, Fehlendes, Filme aus der Suche hinzufügen.",
       "https://radarr.video"),
    _v("lidarr", "Lidarr", "medien", "lidarr", "url_api", {"url": "http://127.0.0.1:8686"},
       "API-Schlüssel unter Settings → General. Alben im Kalender und in der Warteschlange.", "https://lidarr.audio"),
    _v("seerr", "Seerr (Overseerr/Jellyseerr)", "medien", "seerr", "url_api", {"url": "http://127.0.0.1:5055"},
       "API-Schlüssel unter Settings → General. Anfragen von Familie und Freunden genehmigen oder ablehnen.",
       "https://github.com/seerr-team/seerr"),
    _v("prowlarr-suche", "Prowlarr (Suche & Holen)", "medien", "prowlarr", "url_api", {"url": "http://127.0.0.1:9696"},
       "Suche über alle Indexer in Prowlarr; „Holen“ schickt an Prowlarrs Download-Client.", "https://prowlarr.com"),
    _v("kodi", "Kodi (Fernseher, Box)", "medien", "kodi", "url_login_optional", {"url": "http://192.168.178.20:8080"},
       "In Kodi: Einstellungen → Dienste → Steuerung → „Fernsteuerung über HTTP erlauben“ (Port 8080, Benutzer und "
       "Passwort setzen). Dann startet H0rSt Titel über deine Player (TMDb Helper, Jacktook …) und Streams auf dem Fernseher.",
       "https://kodi.wiki/view/Settings/Services/Control"),
    _v("tautulli", "Tautulli", "medien", "tautulli", "url_api", {"url": "http://127.0.0.1:8181"},
       "API-Schlüssel unter Settings → Web Interface. Zeigt laufende Plex-Streams.", "https://tautulli.com"),
    _v("bazarr", "Bazarr", "medien", "bazarr", "url_api", {"url": "http://127.0.0.1:6767"},
       "API-Schlüssel unter Settings → General. Zeigt fehlende Untertitel.", "https://www.bazarr.media"),
]
VORLAGEN += [_v(vxparser.link_vorlage(k), "vxparser: " + name, "vxparser", "vxparser-link", "url",
                {"url": standard}, "Gruppe %s, Schlüssel %s. Leer = vxparser-Standard." % (gruppe, k), "")
             for k, standard, gruppe, name in vxparser.LINKS]


NACH_ID = {v["id"]: v for v in VORLAGEN}


