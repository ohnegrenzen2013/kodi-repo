"""Grundlage von Vorlagen: Importe, Formate, Grenzen und der Fehler.
Alles hier wird samt Importen wieder exportiert (rezeptserver.vorlagen.*)."""


import json
import urllib.error
import urllib.request
from urllib.parse import urlsplit

from . import anbieter, vxparser
from .netz import USER_AGENT

FORMAT = "h0rst-anbieter"
FORMAT_VERSION = 1
MAX_JSON = 1024 * 1024
MAX_EINTRAEGE = 200


class VorlagenFehler(ValueError):
    pass
