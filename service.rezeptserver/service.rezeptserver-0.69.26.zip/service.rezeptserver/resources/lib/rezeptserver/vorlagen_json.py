"""Anbieter-JSON einlesen: Manifest, H0rSt-JSON und vxparser-Linklisten von Datei oder Adresse."""

from .vorlagen_grund import (
    FORMAT,
    FORMAT_VERSION,
    MAX_EINTRAEGE,
    MAX_JSON,
    USER_AGENT,
    VorlagenFehler,
    json,
    urllib,
    urlsplit,
    vxparser,
)

from .vorlagen_bauen import NACH_ID
from .anbindungen_mhub import MHUB_DATEI, ist_mhub_bundle, ist_mhub_manifest, ist_mhub_repository, mhub_basis

def ist_manifest(roh):
    return isinstance(roh, dict) and isinstance(roh.get("id"), str) and "resources" in roh \
        and ("types" in roh or "catalogs" in roh)


def manifest_adresse(url):
    """stremio://host/manifest.json -> https://host/manifest.json; ohne manifest.json wird es angehaengt."""
    url = str(url or "").strip()
    if url.lower().startswith("stremio://"):
        url = "https://" + url[len("stremio://"):]
    if not url.lower().startswith(("http://", "https://")):
        raise VorlagenFehler("Adresse muss mit http://, https:// oder stremio:// beginnen")
    if not urlsplit(url).path.endswith(".json"):
        url = url.rstrip("/") + "/manifest.json"
    return url


def eintraege_aus_json(roh, quelle=None):
    """Zerlegt JSON in eine Liste von Anlagen {vorlage?, name, kategorie, typ, anmeldung, werte}."""
    if ist_mhub_repository(roh) or ist_mhub_bundle(roh):
        basis = mhub_basis(quelle)
        if not basis:
            raise VorlagenFehler("Ein mHub-Repository oder -Bundle bitte über seine Adresse hinzufügen")
        return [{"name": str(roh.get("name") or roh.get("id") or "mHub-Repository")[:60], "kategorie": "addons",
                 "typ": "mhub-addon", "anmeldung": "url", "werte": {"url": basis}}]
    if ist_mhub_manifest(roh):  # mHub-Addon (MediaHubMX v2) – vor dem Stremio-Manifest pruefen (gleiche Felder)
        basis = mhub_basis(quelle)
        if not basis:
            raise VorlagenFehler("Ein mHub-Addon bitte über seine Adresse hinzufügen (z. B. https://…/%s)" % MHUB_DATEI)
        return [{"name": str(roh.get("name") or roh["id"])[:60], "kategorie": "addons", "typ": "mhub-addon",
                 "anmeldung": "url", "werte": {"url": basis}}]
    if ist_manifest(roh):
        if not quelle:
            raise VorlagenFehler("Ein Stremio-Manifest bitte über seine Adresse hinzufügen (z. B. https://…/manifest.json)")
        return [{"name": str(roh.get("name") or roh["id"])[:60], "kategorie": "addons", "typ": "stremio-addon",
                 "anmeldung": "url", "werte": {"url": quelle}}]
    if isinstance(roh, dict) and roh.get("format") == FORMAT:
        if not isinstance(roh.get("version"), int) or roh["version"] > FORMAT_VERSION:
            raise VorlagenFehler("Anbieter-JSON stammt aus einer neueren Version von H0rSt")
        roh = roh.get("anbieter")
    elif isinstance(roh, dict) and roh and all(isinstance(w, str) for w in roh.values()) \
            and any(k in vxparser.SCHLUESSEL for k in roh):
        return [{"vorlage": vxparser.link_vorlage(k), "werte": {"url": w.strip()}}
                for k, w in roh.items() if k in vxparser.SCHLUESSEL and w.strip()]
    elif isinstance(roh, dict):
        roh = [roh]
    if not isinstance(roh, list) or not roh:
        raise VorlagenFehler("Kein Anbieter-JSON, Stremio-Manifest oder vxparser-Linkliste erkannt")
    if len(roh) > MAX_EINTRAEGE:
        raise VorlagenFehler("Höchstens %d Anbieter auf einmal" % MAX_EINTRAEGE)
    ergebnis = []
    for nummer, e in enumerate(roh, 1):
        if not isinstance(e, dict):
            raise VorlagenFehler("Eintrag %d ist kein Objekt" % nummer)
        werte = e.get("werte") or {}
        if not isinstance(werte, dict):
            raise VorlagenFehler("Eintrag %d: werte muss ein Objekt sein" % nummer)
        werte = {str(k): str(w) for k, w in werte.items() if isinstance(w, (str, int, float, bool))}
        if e.get("vorlage"):
            if e["vorlage"] not in NACH_ID:
                raise VorlagenFehler("Eintrag %d: unbekannte Vorlage %s" % (nummer, e["vorlage"]))
            ergebnis.append({"vorlage": e["vorlage"], "name": str(e.get("name") or ""), "werte": werte})
            continue
        for feld in ("name", "kategorie", "anmeldung"):
            if not e.get(feld):
                raise VorlagenFehler("Eintrag %d: %s fehlt (oder vorlage angeben)" % (nummer, feld))
        ergebnis.append({"name": str(e["name"]), "kategorie": e["kategorie"], "typ": e.get("typ") or "",
                         "anmeldung": e["anmeldung"], "werte": werte})
    return ergebnis


def holen_json(url, oeffnen=None):
    """JSON von einer Adresse (http/https, hoechstens 1 MB). Gibt (daten, endgueltige Adresse) zurueck."""
    url = str(url or "").strip()
    if url.lower().startswith("stremio://"):
        url = manifest_adresse(url)
    if not url.lower().startswith(("http://", "https://")):
        raise VorlagenFehler("Adresse muss mit http:// oder https:// beginnen")
    anfrage = urllib.request.Request(url, headers={"User-Agent": USER_AGENT, "Accept": "application/json"})
    try:
        with (oeffnen or urllib.request.urlopen)(anfrage, timeout=15) as antwort:
            inhalt = antwort.read(MAX_JSON + 1)
            ziel = antwort.geturl() if hasattr(antwort, "geturl") else url
    except (urllib.error.URLError, OSError, ValueError) as fehler:
        raise VorlagenFehler("Abruf fehlgeschlagen: %s" % fehler)
    if len(inhalt) > MAX_JSON:
        raise VorlagenFehler("JSON größer als 1 MB")
    try:
        return json.loads(inhalt.decode("utf-8-sig")), ziel or url
    except (ValueError, UnicodeDecodeError) as fehler:
        # Basis-Adresse ohne Dateinamen: Addon-Manifest an den ueblichen Stellen suchen
        if oeffnen is None and not urlsplit(url).path.rstrip("/").endswith(".json"):
            for datei in (MHUB_DATEI, "manifest.json"):
                try:
                    return holen_json(url.rstrip("/") + "/" + datei)
                except VorlagenFehler:
                    continue
        raise VorlagenFehler("Kein gültiges JSON: %s" % fehler)


def aus_text(text):
    try:
        return json.loads(text.lstrip("﻿"))
    except ValueError as fehler:
        raise VorlagenFehler("Kein gültiges JSON: %s" % fehler)


