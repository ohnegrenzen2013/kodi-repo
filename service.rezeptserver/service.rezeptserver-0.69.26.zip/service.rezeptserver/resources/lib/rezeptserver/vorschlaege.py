"""Vorschlaege: KI-generierte Datei-Aenderungen, die ein Admin erst annehmen muss, bevor sie angewendet
werden (schreiben, pruefen, committen – siehe vorschlag_anwenden.py). Nach dem Muster der
Beitrittsanfragen in profile.py: ein "ja"/"nein" entscheidet, der Eintrag wird dabei immer aus der
Warteschlange entfernt, eine Obergrenze verhindert eine ausufernde Liste.

Nutzerdaten "vorschlaege": {"liste": [...], "verlauf": [...]}
"""

import difflib
import hashlib
import json
import os
import re
import secrets
import time

from . import fix_vorlagen, ki_anbieter, mcp_client, profile

SCHLUESSEL = "vorschlaege"
MAX_VORSCHLAEGE = 20
MAX_VERLAUF = 50
MAX_DATEIEN = 8
MAX_GROESSE = 200_000  # Byte, Summe aller neuen Dateiinhalte eines Vorschlags

# Nur diese Teile des Repos duerfen ueberhaupt vorgeschlagen werden – alles andere (vor allem
# konfig.json, docker/.env, *.jks) bleibt kategorisch ausgeschlossen. Zweite Pruefung in
# vorschlag_anwenden.anwenden() vor dem eigentlichen Schreiben (Verteidigung in der Tiefe).
_ERLAUBTE_ORDNER = ("rezeptserver/", "tests/")
_ERLAUBTE_DATEIEN = ("README.md", "WISSEN.md", "kodi/service.rezeptserver/addon.xml")


class VorschlagFehler(ValueError):
    pass


class KeinRecht(VorschlagFehler):
    pass


def daten_von(daten):
    v = daten.get(SCHLUESSEL) if isinstance(daten.get(SCHLUESSEL), dict) else {}
    v.setdefault("liste", [])
    v.setdefault("verlauf", [])
    daten[SCHLUESSEL] = v
    return v


def pfad_erlaubt(pfad):
    """True nur fuer einen relativen, sauberen Pfad innerhalb eines erlaubten Teils des Repos."""
    pfad = str(pfad or "").strip().replace("\\", "/")
    if not pfad or pfad.startswith(("/", "~")):
        return False
    teile = pfad.split("/")
    if ".." in teile or any(t in (".", "") for t in teile):
        return False
    if pfad in _ERLAUBTE_DATEIEN:
        return True
    return any(pfad.startswith(o) for o in _ERLAUBTE_ORDNER)


def _lesen(pfad, wurzel):
    voller = os.path.join(wurzel or ".", pfad)
    if not os.path.isfile(voller):
        return None
    with open(voller, encoding="utf-8", errors="replace") as f:
        return f.read()


def _hash(text):
    return hashlib.sha1(text.encode("utf-8")).hexdigest() if text is not None else None


def einreichen(daten, wer, vorlage_id, dateien, begruendung, wurzel=None, uhr=time.time):
    """dateien: {pfad: neuer_inhalt}. Legt nur einen Eintrag an - kein Schreibzugriff hier."""
    if not isinstance(dateien, dict) or not dateien:
        raise VorschlagFehler("Mindestens eine Datei nötig")
    if len(dateien) > MAX_DATEIEN:
        raise VorschlagFehler("Höchstens %d Dateien je Vorschlag" % MAX_DATEIEN)
    gesamt = 0
    for pfad, inhalt in dateien.items():
        if not pfad_erlaubt(pfad):
            raise VorschlagFehler("Nicht erlaubter Pfad: %s" % pfad)
        gesamt += len(str(inhalt).encode("utf-8"))
    if gesamt > MAX_GROESSE:
        raise VorschlagFehler("Vorschlag zu groß (höchstens %d KB)" % (MAX_GROESSE // 1000))
    v = daten_von(daten)
    if len(v["liste"]) >= MAX_VORSCHLAEGE:
        raise VorschlagFehler("Gerade zu viele offene Vorschläge")
    eintrag = {
        "id": secrets.token_hex(4),
        "vorlage_id": str(vorlage_id or "")[:40],
        "dateien": {pfad: str(inhalt) for pfad, inhalt in dateien.items()},
        "basis_hash": {pfad: _hash(_lesen(pfad, wurzel)) for pfad in dateien},
        "begruendung": " ".join(str(begruendung or "").split())[:500],
        "von": (wer or {}).get("id", "") if isinstance(wer, dict) else "",
        "erstellt": int(uhr()),
        "status": "offen",
    }
    v["liste"].append(eintrag)
    return eintrag


def diff_vorschau(eintrag, wurzel=None):
    """[{pfad, alt, neu, diff, aktuell_abweichend}] - liest jede Datei frisch von der Platte, damit
    die Vorschau gegen den LEBENDEN Inhalt steht, nicht nur gegen den Stand beim Einreichen."""
    ergebnis = []
    for pfad, neu in eintrag["dateien"].items():
        alt = _lesen(pfad, wurzel)
        diff = "\n".join(difflib.unified_diff((alt or "").splitlines(), neu.splitlines(),
                                               fromfile=pfad, tofile=pfad, lineterm=""))
        ergebnis.append({"pfad": pfad, "alt": alt, "neu": neu, "diff": diff,
                          "aktuell_abweichend": _hash(alt) != eintrag["basis_hash"].get(pfad)})
    return ergebnis


def entscheiden(daten, wer, vid, ja, wurzel=None, uhr=time.time):
    """Immer aus der Liste entfernen (ja oder nein). Bei ja: anwenden (siehe vorschlag_anwenden.py).
    Ergebnis landet im Verlauf (gekappt bei MAX_VERLAUF) und wird zurueckgegeben."""
    if not profile.darf(daten, wer, "einstellungen"):
        raise KeinRecht("Vorschläge entscheidet ein Admin")
    v = daten_von(daten)
    eintrag = next((e for e in v["liste"] if e["id"] == vid), None)
    if not eintrag:
        raise VorschlagFehler("Vorschlag nicht (mehr) da")
    v["liste"].remove(eintrag)
    if not ja:
        verlauf_eintrag = dict(eintrag, status="abgelehnt", entschieden=int(uhr()))
    else:
        from . import vorschlag_anwenden  # spaeter Import: nur diese Richtung, kein Ringimport
        ergebnis = vorschlag_anwenden.anwenden(eintrag, daten, wurzel)
        verlauf_eintrag = dict(eintrag, entschieden=int(uhr()), **ergebnis)
    v["verlauf"].insert(0, verlauf_eintrag)
    del v["verlauf"][MAX_VERLAUF:]
    return verlauf_eintrag


def zustand(daten):
    v = daten_von(daten)
    return {"liste": list(v["liste"]), "verlauf": list(v["verlauf"])}


def ki_vorschlagen(daten, vorlage_id, werte=None, fehler_kontext=""):
    """Baut den Prompt aus einer Fix-Vorlage + Parametern (+ optionalem, schon geschwärzten
    Fehlerkontext aus fehlerliste.schwaerzen()), ruft ki_anbieter.anfrage() (oder, wenn die Vorlage
    "mcp_erlaubt" gesetzt hat und ein MCP-Server eingetragen ist, ki_anbieter.anfrage_mit_werkzeugen() -
    Phase 2 Schritt 2) und parst {"dateien": {...}, "begruendung": "..."} aus der Antwort - gleiches
    re.search(r'\\{.*\\}', ...)-Muster wie oberflaeche_uniqx.uniqx_generieren(). Gibt das Roh-dict zurück,
    schreibt/speichert nichts - einreichen() prüft und legt den Vorschlag erst danach an."""
    vorlage = fix_vorlagen.finde(daten, vorlage_id)
    try:
        prompt = vorlage["prompt"].format(**{k: str(v) for k, v in (werte or {}).items()})
    except KeyError as fehler:
        raise VorschlagFehler("Vorlage %s braucht den Parameter %s" % (vorlage_id, fehler)) from fehler
    if fehler_kontext:
        prompt += "\n\nKontext (bereits geschwärzt):\n%s" % str(fehler_kontext)[:4000]
    if vorlage.get("mcp_erlaubt") and mcp_client.konfiguriert(daten):
        verbunden = mcp_client.verbinden(daten)

        def werkzeug_aufruf(name, argumente):
            return mcp_client.aufrufen(daten, verbunden["session_id"], name, argumente)

        text = ki_anbieter.anfrage_mit_werkzeugen(prompt, verbunden["werkzeuge"], daten, werkzeug_aufruf)
    else:
        text = ki_anbieter.anfrage(prompt, daten)
    treffer = re.search(r"\{.*\}", text, re.DOTALL)
    if not treffer:
        raise VorschlagFehler("KI-Antwort enthält kein JSON")
    try:
        ergebnis = json.loads(treffer.group(0))
    except json.JSONDecodeError as fehler:
        raise VorschlagFehler("KI-Antwort ist kein gültiges JSON: %s" % fehler) from fehler
    if not isinstance(ergebnis, dict) or not isinstance(ergebnis.get("dateien"), dict):
        raise VorschlagFehler("KI-Antwort hat nicht die erwartete Form {dateien: {...}}")
    return ergebnis
