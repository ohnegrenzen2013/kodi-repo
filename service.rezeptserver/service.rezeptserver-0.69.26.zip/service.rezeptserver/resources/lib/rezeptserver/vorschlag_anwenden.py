"""Anwenden eines Vorschlags: schreiben, pruefen, bei Fehlschlag zurueckrollen, bei Erfolg committen
(nie pushen - siehe git_commit.py). anwenden() ist der einzige Pruefpunkt fuer den Automatisierungs-
Schalter "ki_automatisierung_erlaubt": ohne ihn (Vorgabe aus) bleibt jeder angenommene Vorschlag bei der
reinen Vorschau aus vorschlaege.diff_vorschau() stehen, es wird nichts geschrieben.
"""

import os

from . import git_commit, pruefungen, vorschlaege


def _lesen(voller):
    if not os.path.isfile(voller):
        return None
    with open(voller, encoding="utf-8") as f:
        return f.read()


def _schreiben(voller, inhalt):
    ordner = os.path.dirname(voller)
    if ordner:
        os.makedirs(ordner, exist_ok=True)
    with open(voller, "w", encoding="utf-8") as f:
        f.write(inhalt)


def _zuruecksetzen(voller, alt_inhalt):
    if alt_inhalt is None:
        if os.path.isfile(voller):
            os.remove(voller)
    else:
        _schreiben(voller, alt_inhalt)


def anwenden(eintrag, daten, wurzel=None):
    """Gibt {"status": "angewendet"|"fehlgeschlagen", ...} zurueck."""
    if not daten.get("ki_automatisierung_erlaubt"):
        return {"status": "fehlgeschlagen",
                "hinweis": "Automatisches Anwenden ist ausgeschaltet (Einstellungen → KI & Werkzeuge)."}
    dateien = eintrag["dateien"]
    for pfad in dateien:
        if not vorschlaege.pfad_erlaubt(pfad):  # Verteidigung in der Tiefe, siehe vorschlaege.einreichen()
            return {"status": "fehlgeschlagen", "hinweis": "Nicht erlaubter Pfad: %s" % pfad}

    voll = {pfad: os.path.join(wurzel or ".", pfad) for pfad in dateien}
    alt = {pfad: _lesen(voll[pfad]) for pfad in dateien}
    for pfad, inhalt in dateien.items():
        _schreiben(voll[pfad], inhalt)

    pruefung = pruefungen.pruefen(wurzel)
    if not pruefung["ok"]:
        for pfad in dateien:
            _zuruecksetzen(voll[pfad], alt[pfad])
        return {"status": "fehlgeschlagen", "pruefung": pruefung}

    nachricht = "KI-Vorschlag: %s" % (eintrag.get("begruendung") or eintrag.get("vorlage_id") or "ohne Begründung")
    try:
        commit = git_commit.committen(list(dateien), nachricht[:72], wurzel)
    except git_commit.GitFehler as fehler:
        for pfad in dateien:
            _zuruecksetzen(voll[pfad], alt[pfad])
        return {"status": "fehlgeschlagen", "pruefung": pruefung, "hinweis": str(fehler)}
    return {"status": "angewendet", "pruefung": pruefung, "sha": commit["sha"]}
