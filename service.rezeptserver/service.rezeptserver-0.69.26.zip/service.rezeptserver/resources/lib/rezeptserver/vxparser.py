"""vxparser anbinden: Links (Domains & APIs) als Anbieter, Zugriff ueber die Xtream-Schnittstelle.

vxparser (https://github.com/Mastaaa1987/vxparser, als Termux-App "0.118.3+vxparser.1.5.1") laeuft als
eigener Server, ab Werk auf Port 8080. H0rSt spricht ihn nur ueber dessen vorhandene Schnittstellen an,
vxparser selbst bleibt unveraendert:

  - Links: jeder Schluessel aus vxparser/helper/urls.py ist eine Vorlage (Kategorie "vxparser"). Was der
    Nutzer davon in H0rSt eintraegt, steht unter /vxparser/urls.json bereit. Diese Adresse in vxparser
    unter "Links (Domains & API's) => url_list" eintragen, dann uebernimmt vxparser die Links bei jedem Start.
  - Zugriff: player_api.php (Live, Filme, Serien), die M3U8-Listen und epg.xml.gz. Stream-Adressen
    loest der Server auf (vxparser antwortet mit einer Weiterleitung), damit sie auch auf anderen Geraeten
    im Netzwerk laufen, wenn vxparser nur auf 127.0.0.1 erreichbar ist.
"""

import json
import re
import threading
import time
from urllib.parse import quote, urlencode, urljoin, urlsplit

from .netz import Abrufer, NetzFehler, Weiterleitung, urllib_holen

STANDARD_ADRESSE = "http://127.0.0.1:8080"
BENUTZER = "h0rst"  # vxparser prueft Benutzer und Passwort nicht
ZWISCHENSPEICHER = 600
MAX_EINTRAEGE = 300

# Stand vxparser 1.5.1, helper/urls.py (DEFAULTS); Gruppe nur fuer die Anzeige
LINKS = [
    ("url_list", "", "Allgemein", "Remote-Link-Liste (leer = aus)"),
    ("public_ip", "https://v4.ident.me", "Allgemein", "Ermittlung der öffentlichen IP"),
    ("vavoo_api", "https://www2.vavoo.to/ccapi/", "Vavoo / Live-TV", "Vavoo API"),
    ("vavoo_veclist", "https://mastaaa1987.github.io/repo/veclist.json", "Vavoo / Live-TV", "Vavoo veclist"),
    ("vavoo_ping", "https://www.vavoo.tv/api/box/ping2", "Vavoo / Live-TV", "Vavoo Signatur (ping)"),
    ("vavoo_live2", "https://www.vavoo.to/live2/index?output=json", "Vavoo / Live-TV", "Vavoo Senderliste"),
    ("vavoo_resolve", "https://vavoo.to/mediahubmx-resolve.json", "Vavoo / Live-TV", "Vavoo Auflösen"),
    ("vavoo_catalog", "https://vavoo.to/mediahubmx-catalog.json", "Vavoo / Live-TV", "Vavoo Katalog"),
    ("lokke_ping", "https://www.lokke.app/api/app/ping", "Vavoo / Live-TV", "Signatur für Live-TV"),
    ("oha_directory", "https://www.oha.to/oha-tv-index/directory.watched", "Vavoo / Live-TV", "Gruppen für Live-TV"),
    ("einschalten", "https://einschalten.in/", "Seiten (Filme & Serien)", "einschalten"),
    ("hdfilme", "https://hdfilme.baby/", "Seiten (Filme & Serien)", "hdfilme"),
    ("hdfilme_1", "https://hdfilme.my/", "Seiten (Filme & Serien)", "hdfilme (2)"),
    ("kinokiste", "https://kinokiste.cloud/", "Seiten (Filme & Serien)", "kinokiste"),
    ("kkiste", "https://kkiste.run/", "Seiten (Filme & Serien)", "kkiste"),
    ("megakino", "https://megakino.kim/", "Seiten (Filme & Serien)", "megakino"),
    ("movie2k", "https://api.movie2k.ch/", "Seiten (Filme & Serien)", "movie2k API"),
    ("movie2k_origin", "https://www2.movie2k.ch/", "Seiten (Filme & Serien)", "movie2k Origin-Header"),
    ("movie4k", "https://movie4k.bid/", "Seiten (Filme & Serien)", "movie4k"),
    ("serienstream", "http://186.2.175.5/", "Seiten (Filme & Serien)", "serienstream"),
    ("serienstream_referer", "https://s.to/", "Seiten (Filme & Serien)", "serienstream Referer-Header"),
    ("xcine", "https://xcine.click/", "Seiten (Filme & Serien)", "xcine"),
    ("dokus4", "http://www.dokus4.me/", "Seiten (Filme & Serien)", "dokus4"),
    ("filmpalast", "https://filmpalast-to.net/", "Seiten (Filme & Serien)", "filmpalast"),
    ("moflix-stream", "https://moflix-stream.xyz/", "Seiten (Filme & Serien)", "moflix-stream"),
    ("streamcloud", "https://streamcloud.my/", "Seiten (Filme & Serien)", "streamcloud"),
    ("topstreamfilm", "https://www.topstreamfilm.live/", "Seiten (Filme & Serien)", "topstreamfilm"),
]
SCHLUESSEL = {k: (standard, gruppe, name) for k, standard, gruppe, name in LINKS}
VORLAGE_PRAEFIX = "vxparser:"
ARTEN = {"live": ("get_live_categories", "get_live_streams"), "vod": ("get_vod_categories", "get_vod_streams"),
         "serie": ("get_series_categories", "get_series")}


class VxFehler(ValueError):
    pass


def link_vorlage(schluessel):
    return VORLAGE_PRAEFIX + schluessel


def schluessel_von(vorlage):
    """'vxparser:megakino' -> 'megakino', sonst None."""
    if vorlage and vorlage.startswith(VORLAGE_PRAEFIX) and vorlage[len(VORLAGE_PRAEFIX):] in SCHLUESSEL:
        return vorlage[len(VORLAGE_PRAEFIX):]
    return None


def link_werte(daten):
    """{schluessel: url} aller vxparser-Links, die der Nutzer in H0rSt eingetragen hat (Anbieter typ vxparser-link)."""
    werte = daten.get("einstellungen") or {}
    ergebnis = {}
    for anbieter_id, eintrag in sorted((daten.get("anbieter") or {}).items()):
        schluessel = schluessel_von(eintrag.get("vorlage", ""))
        url = str((werte.get(anbieter_id) or {}).get("url", "")).strip()
        if eintrag.get("typ") == "vxparser-link" and schluessel and url:
            ergebnis[schluessel] = url
    return ergebnis


def urls_json(daten):
    """Inhalt fuer vxparsers url_list: nur selbst eingetragene Links. Standardwerte fehlen absichtlich,
    sonst wuerde vxparser eigene, dort eingetragene Links wieder zuruecksetzen."""
    werte = link_werte(daten)
    werte.pop("url_list", None)  # die Liste verweist nicht auf sich selbst
    return werte


def links_uebersicht(daten):
    eigene = link_werte(daten)
    ids = {schluessel_von(e.get("vorlage", "")): i for i, e in (daten.get("anbieter") or {}).items()
           if e.get("typ") == "vxparser-link"}
    return [{"schluessel": k, "standard": standard, "gruppe": gruppe, "name": name, "wert": eigene.get(k, ""),
             "anbieter": ids.get(k, "")} for k, standard, gruppe, name in LINKS]


def adresse_pruefen(url):
    url = str(url or "").strip().rstrip("/")
    if not url:
        return STANDARD_ADRESSE
    if "://" not in url:
        url = "http://" + url
    teile = urlsplit(url)
    if teile.scheme not in ("http", "https") or not teile.hostname:
        raise VxFehler("vxparser-Adresse muss http://host:port sein")
    return "%s://%s" % (teile.scheme, teile.netloc)


class Client:
    """Spricht einen vxparser-Server (oder einen anderen Xtream-Server) ueber player_api.php an."""

    def __init__(self, url, benutzer=BENUTZER, passwort=BENUTZER, holen=urllib_holen, zeitgrenze=15.0):
        self.url = adresse_pruefen(url)
        self.benutzer = benutzer or BENUTZER
        self.passwort = passwort or BENUTZER
        self.holen = holen
        self.abrufer = Abrufer([urlsplit(self.url).hostname], holen=holen, zeitgrenze=zeitgrenze)
        self._cache = {}
        self._sperre = threading.Lock()

    def _api(self, aktion=None, **werte):
        parameter = {"username": self.benutzer, "password": self.passwort}
        if aktion:
            parameter["action"] = aktion
        parameter.update({k: v for k, v in werte.items() if v not in (None, "")})
        schluessel = json.dumps(parameter, sort_keys=True)
        with self._sperre:
            alt = self._cache.get(schluessel)
            if aktion and alt and time.time() - alt[0] < ZWISCHENSPEICHER:
                return alt[1]
        try:
            antwort = json.loads(self.abrufer.abruf("%s/player_api.php?%s" % (self.url, urlencode(parameter))))
        except ValueError:
            raise VxFehler("Antwort von %s ist kein JSON" % self.url)
        with self._sperre:
            if len(self._cache) > 50:
                self._cache.clear()
            self._cache[schluessel] = (time.time(), antwort)
        return antwort

    def leeren(self):
        with self._sperre:
            self._cache.clear()

    def zustand(self):
        """Erreichbarkeit, Server-Info und Anzahl der Kategorien je Art."""
        try:
            info = self._api()
        except (NetzFehler, VxFehler) as fehler:
            return {"erreichbar": False, "fehler": str(fehler), "url": self.url}
        anzahl = {}
        for art, (kategorien, _) in ARTEN.items():
            try:
                liste = self._api(kategorien)
                anzahl[art] = len(liste) if isinstance(liste, list) else 0
            except (NetzFehler, VxFehler):
                anzahl[art] = None
        server = info.get("server_info") if isinstance(info, dict) else {}
        nutzer = info.get("user_info") if isinstance(info, dict) else {}
        return {"erreichbar": True, "fehler": "", "url": self.url, "kategorien": anzahl,
                "server": {k: (server or {}).get(k) for k in ("url", "port", "time_now", "timezone")},
                "meldung": (nutzer or {}).get("message", "")}

    def kategorien(self, art):
        if art not in ARTEN:
            raise VxFehler("Art muss live, vod oder serie sein")
        liste = self._api(ARTEN[art][0])
        return [{"id": str(k.get("category_id", "")), "name": str(k.get("category_name", ""))}
                for k in (liste if isinstance(liste, list) else []) if isinstance(k, dict)]

    def inhalte(self, art, kategorie=None, suche=""):
        if art not in ARTEN:
            raise VxFehler("Art muss live, vod oder serie sein")
        liste = self._api(ARTEN[art][1], category_id=kategorie or None)
        woerter = _woerter(suche)
        ergebnis = []
        for e in liste if isinstance(liste, list) else []:
            if not isinstance(e, dict):
                continue
            name = str(e.get("name") or "")
            if woerter and not woerter <= _woerter(name):
                continue
            if art == "serie":
                ergebnis.append({"id": str(e.get("series_id", "")), "name": name, "bild": str(e.get("cover") or ""),
                                 "jahr": str(e.get("releaseDate") or "")[:4], "genre": str(e.get("genre") or ""),
                                 "handlung": str(e.get("plot") or "")})
            else:
                ergebnis.append({"id": str(e.get("stream_id", "")), "name": name,
                                 "bild": str(e.get("stream_icon") or ""),
                                 "endung": str(e.get("container_extension") or ("m3u8" if art == "live" else "mp4"))})
            if len(ergebnis) >= MAX_EINTRAEGE:
                break
        return ergebnis

    def serie(self, serie_id):
        info = self._api("get_series_info", series_id=serie_id)
        folgen = []
        episoden = info.get("episodes") if isinstance(info, dict) else None
        if isinstance(episoden, dict):
            staffeln = sorted(episoden.items(), key=lambda p: int(p[0]) if str(p[0]).isdigit() else 0)
            for staffel, liste in staffeln:
                for e in liste if isinstance(liste, list) else []:
                    if isinstance(e, dict):
                        folgen.append({"id": str(e.get("id", "")), "staffel": str(staffel),
                                       "folge": str(e.get("episode_num", "")), "name": str(e.get("title") or ""),
                                       "endung": str(e.get("container_extension") or "mp4")})
        return folgen

    def stream_adresse(self, art, stream_id, endung=None):
        """Adresse eines Streams auf dem vxparser-Server (leitet auf die eigentliche Quelle weiter)."""
        if not re.match(r"^\d{1,12}$", str(stream_id)):
            raise VxFehler("ungueltige Stream-ID")
        pfad = {"live": "live", "vod": "movie", "serie": "series"}.get(art)
        if not pfad:
            raise VxFehler("Art muss live, vod oder serie sein")
        endung = endung if endung and re.match(r"^[A-Za-z0-9]{1,5}$", endung) else ("m3u8" if art == "live" else "mp4")
        return "%s/%s/%s/%s/%s.%s" % (self.url, pfad, quote(self.benutzer, safe=""), quote(self.passwort, safe=""),
                                      stream_id, endung)

    def aufloesen(self, art, stream_id, endung=None):
        """Folgt der Weiterleitung von vxparser einmal und gibt das Ziel zurueck (oder die eigene Adresse)."""
        adresse = self.stream_adresse(art, stream_id, endung)
        try:
            status, _ = self.holen(adresse, methode="GET", zeitgrenze=30.0)
        except Weiterleitung as weiter:
            return weiter.ziel
        except NetzFehler as fehler:
            raise VxFehler("vxparser liefert keinen Stream: %s" % fehler)
        return adresse if status < 400 else None

    def listen(self):
        """M3U8-Listen und EPG, die vxparser auf seiner Startseite anbietet."""
        text = self.abrufer.abruf(self.url + "/")
        namen = []
        for name in re.findall(r'href="([^"<>]+)"', text):
            if re.match(r"^[\w.\- ]{1,120}\.(m3u8?|xml\.gz|xml)$", name) and name not in namen:
                namen.append(name)
        return [{"name": n, "url": urljoin(self.url + "/", quote(n))} for n in namen]

    def m3u_adresse(self):
        return "%s/get.php?%s" % (self.url, urlencode({"username": self.benutzer, "password": self.passwort,
                                                         "type": "m3u_plus", "output": "hls"}))


def _woerter(text):
    return {w for w in re.split(r"[^0-9a-zäöüß]+", str(text or "").lower()) if w}
