"""Wächter: prueft eingerichtete Anbieter und Dienste regelmaessig und schaltet bei Ausfall auf eine Ersatz-Adresse.

Geprueft wird mit demselben Test wie "Verbindung pruefen" (anbindungen.pruefen): Usenet-Server, Indexer, Xtream,
vxparser, Stremio-Addons, Debrid, alle Dienste (NZBGet, Sonarr, Kodi ...), rustnzb und Netzwege (Proxy, Tor, I2P).

Je Anbieter: erreichbar ja/nein, seit wann, letzte Meldung, Antwortzeit, Verfuegbarkeit der letzten Pruefungen.
Ersatz-Adresse: Faellt die Adresse zweimal hintereinander aus und eine erreichbare Ersatz-Adresse ist eingetragen,
tauscht H0rSt beide (die alte wird zur Ersatz-Adresse, so geht es auch wieder zurueck).
Einstellungen in den Nutzerdaten unter "waechter": {"an", "minuten", "ersatz": {anbieter_id: adresse}};
der Stand liegt neben den Nutzerdaten in waechter.json (bleibt ueber einen Neustart erhalten).
"""

import json
import logging
import os
import threading
import time
from concurrent.futures import ThreadPoolExecutor

log = logging.getLogger("rezeptserver")

SCHLUESSEL = "waechter"
STANDARD = {"an": True, "minuten": 15, "ersatz": {}}
MINUTEN = (5, 15, 30, 60, 180)
NICHT_PRUEFEN = ("", "vxparser-link", "wireguard")
VERLAUF = 48          # so viele Pruefungen fuer die Verfuegbarkeit in Prozent
UMSCHALTEN_NACH = 2   # Fehlversuche in Folge, bevor auf die Ersatz-Adresse gewechselt wird
MAX_MELDUNGEN = 50
DATEI = "waechter.json"


class WaechterFehler(ValueError):
    pass


def pruefe(roh):
    e = dict(STANDARD)
    if isinstance(roh, dict):
        e.update({k: roh[k] for k in STANDARD if k in roh})
    e["an"] = e["an"] is not False
    try:
        e["minuten"] = int(e["minuten"])
    except (TypeError, ValueError):
        raise WaechterFehler("minuten muss eine Zahl sein")
    if e["minuten"] not in MINUTEN:
        raise WaechterFehler("minuten muss eine von %s sein" % ", ".join(map(str, MINUTEN)))
    if not isinstance(e["ersatz"], dict):
        raise WaechterFehler("ersatz muss die Form {anbieter: adresse} haben")
    ersatz = {}
    for aid, adresse in e["ersatz"].items():
        adresse = str(adresse or "").strip()
        if adresse:
            ersatz[str(aid)[:64]] = adresse[:500]
    e["ersatz"] = ersatz
    return e


def adressfeld(eintrag, werte):
    """Welches Feld die Adresse traegt: url, bei Usenet-Servern und Proxys host."""
    if "url" in werte or eintrag.get("anmeldung") in ("url", "url_api", "url_login", "url_pass", "url_login_optional",
                                                       "rustnzb"):
        return "url"
    if eintrag.get("anmeldung") in ("nntp", "proxy"):
        return "host"
    return None


class Waechter:
    def __init__(self, verwaltung, ordner, pruefen=None, uhr=time.time):
        self.verwaltung = verwaltung
        self.pfad = os.path.join(ordner or ".", DATEI)
        self._pruefen = pruefen  # (eintrag, werte) -> (ok, meldung); Standard: anbindungen.pruefen
        self.uhr = uhr
        self._sperre = threading.Lock()
        self._stand = self._laden()
        self._meldungen = []  # [(nummer, zeit, text, ok)] fuer Benachrichtigungen
        self._nummer = 0
        self._halt = threading.Event()
        self._faden = None
        self.laeuft_gerade = False

    # --- Stand ----------------------------------------------------------------------------------
    def _laden(self):
        try:
            with open(self.pfad, encoding="utf-8") as f:
                d = json.load(f)
            return d if isinstance(d, dict) else {}
        except (OSError, ValueError):
            return {}

    def _sichern(self):
        try:
            temp = self.pfad + ".neu"
            with open(temp, "w", encoding="utf-8") as f:
                json.dump(self._stand, f, ensure_ascii=False)
            os.replace(temp, self.pfad)
        except OSError as fehler:
            log.warning("Wächter: Stand nicht speicherbar: %s", fehler)

    def einstellungen(self):
        daten = self.verwaltung.daten() if self.verwaltung else {}
        return pruefe(daten.get(SCHLUESSEL))

    # --- Pruefen --------------------------------------------------------------------------------
    def _test(self, eintrag, werte):
        if self._pruefen:
            return self._pruefen(eintrag, werte)
        from . import anbindungen
        return anbindungen.pruefen(eintrag, werte)

    def ziele(self, daten):
        werte_alle = daten.get("einstellungen") or {}
        for aid, eintrag in sorted((daten.get("anbieter") or {}).items()):
            if eintrag.get("typ", "") in NICHT_PRUEFEN:
                continue
            werte = {k: str(w) for k, w in (werte_alle.get(aid) or {}).items()}
            feld = adressfeld(eintrag, werte)
            if feld and not werte.get(feld, "").strip():
                continue  # noch nicht eingerichtet
            yield aid, eintrag, werte

    def _eine(self, ziel):
        aid, eintrag, werte = ziel
        start = self.uhr()
        try:
            ok, meldung = self._test(eintrag, werte)
        except Exception as fehler:  # ein Test darf den Waechter nicht anhalten
            ok, meldung = False, str(fehler)
        return aid, eintrag, werte, bool(ok), str(meldung)[:300], round(self.uhr() - start, 2)

    def pruefen(self, nur=None):
        """Alle (oder einen) Anbieter pruefen; gibt den Zustand zurueck."""
        if not self.verwaltung:
            return self.zustand()
        daten = self.verwaltung.daten()
        e = pruefe(daten.get(SCHLUESSEL))
        ziele = [z for z in self.ziele(daten) if nur is None or z[0] == nur]
        if nur is not None and not ziele:
            raise WaechterFehler("%s wird nicht überwacht" % nur)
        self.laeuft_gerade = True
        try:
            with ThreadPoolExecutor(max_workers=max(1, min(6, len(ziele)))) as pool:
                ergebnisse = list(pool.map(self._eine, ziele))
        finally:
            self.laeuft_gerade = False
        umschalten = []
        jetzt = self.uhr()
        with self._sperre:
            for aid, eintrag, werte, ok, meldung, dauer in ergebnisse:
                alt = self._stand.get(aid) or {}
                s = {"name": eintrag.get("name", aid), "typ": eintrag.get("typ", ""), "ok": ok, "meldung": meldung,
                     "dauer": dauer, "zuletzt": jetzt, "seit": alt.get("seit") if alt.get("ok") == ok else jetzt,
                     "fehlversuche": 0 if ok else int(alt.get("fehlversuche") or 0) + 1,
                     "verlauf": ((alt.get("verlauf") or []) + [1 if ok else 0])[-VERLAUF:],
                     "umgeschaltet": alt.get("umgeschaltet", "")}
                self._stand[aid] = s
                if "ok" in alt and alt["ok"] != ok:
                    self._melden("%s %s" % (s["name"], "wieder erreichbar" if ok else "gestört: " + meldung), ok)
                feld = adressfeld(eintrag, werte)
                if not ok and feld and e["ersatz"].get(aid) and s["fehlversuche"] >= UMSCHALTEN_NACH:
                    umschalten.append((aid, eintrag, werte, feld, e["ersatz"][aid]))
            for aid in [a for a in self._stand if a not in (daten.get("anbieter") or {})]:
                del self._stand[aid]  # entfernte Anbieter vergessen
            self._sichern()
        for ziel in umschalten:
            self._umschalten(*ziel)
        return self.zustand()

    def _umschalten(self, aid, eintrag, werte, feld, ersatz):
        """Ersatz-Adresse pruefen und bei Erfolg mit der Hauptadresse tauschen."""
        probe = dict(werte, **{feld: ersatz})
        _, _, _, ok, meldung, _ = self._eine((aid, eintrag, probe))
        if not ok:
            log.info("Wächter: Ersatz für %s auch gestört (%s)", eintrag.get("name", aid), meldung)
            return
        alt = werte.get(feld, "")

        def tauschen(d):
            d.setdefault("einstellungen", {}).setdefault(aid, {})[feld] = ersatz
            w = pruefe(d.get(SCHLUESSEL))
            w["ersatz"][aid] = alt
            d[SCHLUESSEL] = w
        self.verwaltung.aendern(tauschen)  # laedt die Anbieter neu, die neue Adresse gilt sofort
        with self._sperre:
            s = self._stand.get(aid) or {}
            s.update(ok=True, meldung="Auf Ersatz-Adresse umgeschaltet: " + meldung, fehlversuche=0, seit=self.uhr(),
                     umgeschaltet=time.strftime("%Y-%m-%d %H:%M", time.localtime(self.uhr())))
            self._stand[aid] = s
            self._sichern()
        self._melden("%s: auf Ersatz-Adresse %s umgeschaltet" % (eintrag.get("name", aid), ersatz), True)
        log.info("Wächter: %s auf Ersatz-Adresse umgeschaltet", eintrag.get("name", aid))

    def _melden(self, text, ok):
        self._nummer += 1
        self._meldungen = (self._meldungen + [(self._nummer, self.uhr(), text, ok)])[-MAX_MELDUNGEN:]
        log.log(logging.INFO if ok else logging.WARNING, "Wächter: %s", text)
        from . import ereignisse
        threading.Thread(target=ereignisse.melden, args=("waechter", text, ok), daemon=True).start()

    def meldungen_seit(self, nummer):
        with self._sperre:
            return [{"nummer": n, "zeit": z, "text": t, "ok": o} for n, z, t, o in self._meldungen if n > nummer]

    def zustand(self):
        e = self.einstellungen()
        with self._sperre:
            eintraege = []
            for aid, s in sorted(self._stand.items(), key=lambda x: (x[1].get("ok", True), x[1].get("name", "").lower())):
                verlauf = s.get("verlauf") or []
                eintraege.append(dict(s, id=aid, ersatz=e["ersatz"].get(aid, ""),
                                      prozent=round(100.0 * sum(verlauf) / len(verlauf), 1) if verlauf else None))
            meldungen = [{"zeit": z, "text": t, "ok": o} for _, z, t, o in self._meldungen[-10:]][::-1]
        return {"einstellungen": e, "minuten": list(MINUTEN), "anbieter": eintraege, "laeuft": self.laeuft_gerade,
                "gestoert": sum(1 for x in eintraege if not x.get("ok")), "meldungen": meldungen}

    def einstellen(self, neu):
        def setzen(d):
            e = pruefe(d.get(SCHLUESSEL))
            for k, w in neu.items():
                if k not in STANDARD:
                    raise WaechterFehler("Unbekannte Einstellung: %s" % k)
                e[k] = dict(e["ersatz"], **w) if k == "ersatz" and isinstance(w, dict) else w
            d[SCHLUESSEL] = pruefe(e)
        self.verwaltung.aendern(setzen)
        return self.zustand()

    # --- im Hintergrund -------------------------------------------------------------------------
    def starten(self):
        if self._faden is None and self.verwaltung:
            self._halt.clear()
            self._faden = threading.Thread(target=self._schleife, name="waechter", daemon=True)
            self._faden.start()

    def stoppen(self):
        self._halt.set()

    def _schleife(self):
        self._halt.wait(60)  # erst den Start abwarten
        while not self._halt.is_set():
            try:
                e = self.einstellungen()
                if e["an"]:
                    self.pruefen()
                warten = e["minuten"] * 60
            except Exception:
                log.exception("Wächter")
                warten = 900
            self._halt.wait(warten)
