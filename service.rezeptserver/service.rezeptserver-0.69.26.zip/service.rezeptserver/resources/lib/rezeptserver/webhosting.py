"""Webhosting: eigene Webseiten und Foren im Heimnetz – phpMyAdmin, phpBB, WordPress, WoltLab, Adminer, ARVIO Web.

H0rSt selbst spricht kein PHP. Den Webserver liefert der Docker-Baustein "web" (docker/docker-compose.yml, Profil web):
MariaDB (Datenbank), phpMyAdmin (Datenbank verwalten) und ein PHP-8.3-Apache (die Seiten). Der Ordner mit den Seiten
ist auch in H0rSt eingebunden (H0RST_WEB_ORDNER), so kann H0rSt Anwendungen mit einem Klick hineinlegen:
  * phpBB (Forum, frei)                – neueste 3.3-Version von download.phpbb.com, danach der Installer im Browser
  * WordPress (Webseite/Blog, frei)   – deutsche Fassung von de.wordpress.org
  * Adminer (Datenbank, eine Datei)   – schlanke Alternative zu phpMyAdmin
  * WoltLab Suite / Burning Board     – kostenpflichtig (Burning Board) bzw. frei (Suite Core): Installer aus dem
                                         WoltLab-Kundenbereich in den Ordner legen; H0rSt zeigt den Weg
Ohne Docker (z. B. auf dem Pi) geht dasselbe mit apache2, php und mariadb; vorhandene Server traegt man nur als
Adresse ein. Nutzerdaten "webhosting": {"ordner", "web", "phpmyadmin"} (Umgebung hat Vorrang).
"""

import io
import json
import os
import re
import shutil
import threading
import urllib.error
import urllib.request
import zipfile

from .archiv import ZIP_FEHLER
from .netz import USER_AGENT

SCHLUESSEL = "webhosting"
PHPBB_BEKANNT = "3.3.15"
PHPBB = "https://download.phpbb.com/pub/release/%s/%s/phpBB-%s.zip"
WORDPRESS = "https://de.wordpress.org/latest-de_DE.zip"
ADMINER = "https://api.github.com/repos/vrana/adminer/releases/latest"
MAX_ZIP = 120 * 1024 * 1024
MAX_ENTPACKT = 1024 * 1024 * 1024
_install_sperre = threading.Lock()  # zwei Klicks gleichzeitig sollen sich nicht in die Quere kommen
ANWENDUNGEN = {
    "phpbb": {"name": "phpBB", "art": "Forum", "ordner": "forum", "frei": True,
              "text": "Das bekannte freie Forum. Nach dem Herunterladen im Browser den Installer starten und die Datenbank "
                      "(MariaDB, siehe unten) eintragen. Deutsches Sprachpaket gibt es auf phpbb.de."},
    "wordpress": {"name": "WordPress", "art": "Webseite & Blog", "ordner": "wordpress", "frei": True,
                  "text": "Webseiten und Blogs, deutsche Fassung. Beim ersten Aufruf fragt WordPress nach der Datenbank."},
    "adminer": {"name": "Adminer", "art": "Datenbank verwalten", "ordner": "adminer", "frei": True,
                "text": "Eine einzige PHP-Datei zum Verwalten der Datenbank – schlanke Alternative zu phpMyAdmin."},
    "woltlab": {"name": "WoltLab Suite / Burning Board", "art": "Forum & Community", "ordner": "woltlab", "frei": False,
                "text": "Die WoltLab Suite Core ist frei, das Forum Burning Board ist kostenpflichtig. Den Installer "
                        "(install.php und WCFSetup.tar.gz) aus dem WoltLab-Kundenbereich bzw. von woltlab.com in den "
                        "Ordner „woltlab“ legen und dann im Browser …/woltlab/install.php öffnen.",
                "seite": "https://www.woltlab.com/de/woltlab-suite-download/"},
    "arvio": {"name": "ARVIO Web", "art": "Media-Portal (selbst gehostet)", "ordner": "arvio", "frei": True,
              "text": "ARVIO als selbst gehostete Web-App (Next.js). Lädt den Quellcode von GitHub, entpackt ihn und schreibt .env.local mit TMDb-Schlüssel (optional)."},
}
# Ordner, in die PHP schreiben muss (phpBB-Anleitung, WordPress-Uploads)
SCHREIBBAR = {"phpbb": ["cache", "store", "files", "images/avatars/upload", "config.php"], "wordpress": ["wp-content"],
              "woltlab": ["."]}


class WebFehler(ValueError):
    pass


def pruefe(roh):
    e = {"ordner": "", "web": "", "phpmyadmin": ""}
    if isinstance(roh, dict):
        e.update({k: str(roh.get(k) or "").strip()[:500] for k in e})
    for k in ("web", "phpmyadmin"):
        if e[k] and not re.match(r"^https?://", e[k], re.I):
            raise WebFehler("Adresse mit http(s)://")
    return e


def einstellung(daten):
    e = pruefe((daten or {}).get(SCHLUESSEL))
    e["ordner"] = os.environ.get("H0RST_WEB_ORDNER") or e["ordner"]
    e["web"] = os.environ.get("H0RST_WEB_ADRESSE") or e["web"]
    e["phpmyadmin"] = os.environ.get("H0RST_PMA_ADRESSE") or e["phpmyadmin"]
    e["datenbank"] = {"host": os.environ.get("H0RST_DB_HOST", "mariadb"), "name": os.environ.get("H0RST_DB_NAME", "h0rst"),
                      "benutzer": os.environ.get("H0RST_DB_BENUTZER", "h0rst")} if os.environ.get("H0RST_DB_NAME") else None
    return e


def _abruf(url, holen=None, grenze=MAX_ZIP):
    if holen:
        daten = holen(url)
        if len(daten) > grenze:
            raise WebFehler("Download zu groß")
        return daten
    anfrage = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 " + USER_AGENT})
    try:
        with urllib.request.urlopen(anfrage, timeout=120) as a:
            daten = a.read(grenze + 1)
    except urllib.error.HTTPError as fehler:
        fehler.close()
        raise WebFehler("Download fehlgeschlagen: HTTP %d" % fehler.code)
    except (urllib.error.URLError, OSError) as fehler:
        raise WebFehler("Download fehlgeschlagen: %s" % getattr(fehler, "reason", fehler))
    if len(daten) > grenze:
        raise WebFehler("Download zu groß")
    return daten


def erreichbar(url, zeit=5):
    if not url:
        return None
    try:
        with urllib.request.urlopen(urllib.request.Request(url, method="HEAD", headers={"User-Agent": USER_AGENT}), timeout=zeit):
            return True
    except urllib.error.HTTPError as fehler:
        fehler.close()
        return fehler.code < 500  # 401/403/404: der Server antwortet
    except (urllib.error.URLError, OSError, ValueError):
        return False


def phpbb_version(holen=None, bekannt=PHPBB_BEKANNT):
    """Neueste 3.3-Version: von der bekannten aus die naechsten Ausgaben ertasten (die Versionsliste blockt Programme)."""
    haupt, _, teil = bekannt.rpartition(".")
    neueste = bekannt
    for n in range(int(teil) + 1, int(teil) + 12):
        kandidat = "%s.%d" % (haupt, n)
        url = PHPBB % (haupt, kandidat, kandidat)
        try:
            if holen:
                holen(url, kopf=True)
            else:
                with urllib.request.urlopen(urllib.request.Request(url, method="HEAD", headers={"User-Agent": USER_AGENT}), timeout=10):
                    pass
            neueste = kandidat
        except Exception:
            break
    return neueste


def _php_schreibbar(pfad):
    """PHP (www-data) muss hier schreiben duerfen – auch spaeter abgelegte Dateien (z. B. WoltLab-Installer)."""
    if os.path.isdir(pfad):
        for wurzel, _ordner, dateien in os.walk(pfad):
            os.chmod(wurzel, 0o777)
            for d in dateien:
                os.chmod(os.path.join(wurzel, d), 0o666)
    elif os.path.isfile(pfad):
        os.chmod(pfad, 0o666)


def _entpacken(roh, ziel, oben=None):
    """ZIP sicher nach ziel; oben: Ordner im ZIP, dessen Inhalt nach ziel kommt (z. B. "phpBB3/")."""
    try:
        archiv = zipfile.ZipFile(io.BytesIO(roh))
    except zipfile.BadZipFile:
        raise WebFehler("Download ist kein ZIP")
    except ZIP_FEHLER as fehler:
        # z. B. unbekannte ZIP-Version oder verschluesselte Eintraege im Kopf
        raise WebFehler("Download ist kein ZIP: %s" % fehler)
    ziel = os.path.realpath(ziel)
    anzahl = 0
    groesse = 0
    try:
        for eintrag in archiv.infolist():
            name = eintrag.filename
            if oben:
                if not name.startswith(oben):
                    continue
                name = name[len(oben):]
            if not name or name.endswith("/"):
                continue
            pfad = os.path.realpath(os.path.join(ziel, name))
            if not pfad.startswith(ziel + os.sep):
                continue  # kein Ausbruch aus dem Ordner
            groesse += max(eintrag.file_size, 0)
            if groesse > MAX_ENTPACKT:
                raise WebFehler("Archiv zu groß beim Entpacken")
            os.makedirs(os.path.dirname(pfad), exist_ok=True)
            with archiv.open(eintrag) as quelle, open(pfad, "wb") as datei:
                shutil.copyfileobj(quelle, datei)
            anzahl += 1
    except WebFehler:
        raise
    except ZIP_FEHLER as fehler:
        # beschaedigte oder unvollstaendige Daten fallen erst beim Lesen auf (CRC, gepatchter Deflate-Strom)
        raise WebFehler("Archiv ist beschädigt: %s" % fehler)
    finally:
        archiv.close()
    return anzahl


def installiert(ordner):
    if not ordner or not os.path.isdir(ordner):
        return {}
    ergebnis = {}
    for aid, a in ANWENDUNGEN.items():
        pfad = os.path.join(ordner, a["ordner"])
        if os.path.isdir(pfad) and os.listdir(pfad):
            ergebnis[aid] = {"pfad": a["ordner"]}
    return ergebnis


def installieren(anwendung, ordner, holen=None):
    """Anwendung in <ordner>/<unterordner> legen. Gibt {"pfad", "version", "weiter"} zurueck."""
    if anwendung not in ANWENDUNGEN:
        raise WebFehler("Unbekannte Anwendung")
    if not ordner:
        raise WebFehler("Kein Webordner eingestellt (Docker-Profil web oder Ordner unten eintragen)")
    if not os.path.isdir(ordner):
        raise WebFehler("Webordner gibt es nicht: %s" % ordner)
    a = ANWENDUNGEN[anwendung]
    if anwendung == "arvio":
        raise WebFehler("ARVIO wird über die eigene Installation eingerichtet (arvio_web.installieren)")
    ziel = os.path.join(ordner, a["ordner"])
    if os.path.isfile(ziel):
        raise WebFehler("Der Platz für %s ist eine Datei statt eines Ordners: %s" % (a["name"], ziel))
    with _install_sperre:
        if os.path.isdir(ziel) and os.listdir(ziel) and anwendung != "woltlab":
            raise WebFehler("%s ist schon da (Ordner „%s“). Zum Neuinstallieren den Ordner erst leeren." % (a["name"], a["ordner"]))
        if anwendung == "woltlab":  # von Hand gefuellt: nichts entpacken, nur den Weg zeigen
            os.makedirs(ziel, exist_ok=True)
            with open(os.path.join(ziel, "LIES-MICH.txt"), "w", encoding="utf-8") as f:
                f.write("WoltLab Suite / Burning Board:\n1. install.php und WCFSetup.tar.gz aus dem WoltLab-Kundenbereich "
                        "(Burning Board) bzw. von %s (Suite Core, frei) in diesen Ordner legen.\n2. Im Browser …/woltlab/install.php "
                        "oeffnen und die Datenbank eintragen.\n" % a["seite"])
            for teil in SCHREIBBAR.get(anwendung, []):  # PHP (www-data) muss hier schreiben duerfen
                _php_schreibbar(os.path.join(ziel, teil))
            return {"pfad": a["ordner"], "version": "", "weiter": a["ordner"] + "/install.php"}
        # erst in einen Nebenordner, dann tauschen – ein Abbruch laesst keine halbe Installation zurueck
        neu = ziel + ".neu"
        try:
            if os.path.islink(neu) or os.path.isfile(neu):
                os.remove(neu)
            elif os.path.isdir(neu):
                shutil.rmtree(neu)
            os.makedirs(neu, exist_ok=True)
        except OSError as fehler:
            raise WebFehler("Nebenordner %s lässt sich nicht anlegen: %s" % (neu, fehler))
        version, weiter = "", ""
        try:
            if anwendung == "phpbb":
                version = phpbb_version(holen)
                haupt = version.rpartition(".")[0]
                if not _entpacken(_abruf(PHPBB % (haupt, version, version), holen), neu, "phpBB3/"):
                    raise WebFehler("PHPBB-Archiv enthielt keine Dateien")
                weiter = a["ordner"] + "/install/"
            elif anwendung == "wordpress":
                if not _entpacken(_abruf(WORDPRESS, holen), neu, "wordpress/"):
                    raise WebFehler("WordPress-Archiv enthielt keine Dateien")
                version, weiter = "aktuell (deutsch)", a["ordner"] + "/"
            elif anwendung == "adminer":
                info = json.loads(_abruf(ADMINER, holen, 1024 * 1024))
                datei = next((x for x in info.get("assets") or [] if re.match(r"^adminer-[\d.]+-mysql\.php$", x.get("name", ""))), None) or \
                    next((x for x in info.get("assets") or [] if re.match(r"^adminer-[\d.]+\.php$", x.get("name", ""))), None)
                if not datei:
                    raise WebFehler("Adminer-Datei nicht gefunden")
                with open(os.path.join(neu, "index.php"), "wb") as f:
                    f.write(_abruf(datei["browser_download_url"], holen, 5 * 1024 * 1024))
                version, weiter = str(info.get("tag_name", "")), a["ordner"] + "/"
            for teil in SCHREIBBAR.get(anwendung, []):  # PHP (www-data) muss hier schreiben duerfen
                _php_schreibbar(os.path.join(neu, teil))
        except BaseException:
            shutil.rmtree(neu, ignore_errors=True)
            raise
        # alten Ordner beiseitelegen, neuen einsetzen; scheitert der Tausch, kommt der alte zurueck
        alt = ziel + ".alt"
        try:
            shutil.rmtree(alt, ignore_errors=True)
            if os.path.lexists(ziel):
                os.replace(ziel, alt)
            os.replace(neu, ziel)
        except OSError as fehler:
            if os.path.lexists(alt) and not os.path.lexists(ziel):
                try:
                    os.replace(alt, ziel)
                except OSError:
                    pass
            shutil.rmtree(neu, ignore_errors=True)
            raise WebFehler("Ordner „%s“ lässt sich nicht ersetzen: %s" % (a["ordner"], fehler))
        shutil.rmtree(alt, ignore_errors=True)
        os.chmod(ziel, 0o755)
        return {"pfad": a["ordner"], "version": version, "weiter": weiter}
