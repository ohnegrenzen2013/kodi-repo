"""Wiedergabe-Check: warum hat ein Titel keine Quelle oder laeuft nicht?

Die Idee stammt aus den Anleitungen von ARVIO (arvio.tv/guides: "Browser playback checklist", "Debrid playback",
"Stremio-compatible addons", "help when a title has no playable source"): Quellenzugang und Formatprobleme getrennt
pruefen, die Rollen von Player, Addon und Anbieter auseinanderhalten. Es ist kein Text und kein Code uebernommen.

Dieses Modul prueft nur den Quellenzugang aus den eigenen Anbietern (lesend, ohne Netz, ohne Zugangsdaten in der Antwort).
Die Formatpruefung (Codecs, HLS, Mischinhalte) macht die Oberflaeche im Browser selbst, weil nur er weiss, was er abspielt.
"""

QUELLEN = (
    ("addons", "Stremio-/mHub-Addons", ("stremio-addon", "mhub-addon")),
    ("debrid", "Debrid-Dienst", ("debrid",)),
    ("usenet_stream", "Usenet-Streaming (NzbDAV, AltMount, rustnzb)", ("nzbdav", "altmount", "rustnzb")),
    ("usenet_indexer", "Usenet-Indexer", ("newznab", "binsearch")),
    ("torrent", "Torrent-Indexer", ("torznab",)),
    ("heimserver", "Eigener Medienserver (Jellyfin, Emby, Plex)", ("jellyfin", "emby", "plex")),
)


def _zaehlen(daten):
    n = {}
    for e in (daten.get("anbieter") or {}).values():
        if isinstance(e, dict):
            n[e.get("typ")] = n.get(e.get("typ"), 0) + 1
    return n


def quellen(daten):
    """{punkte: [{id, titel, anzahl, ok}], hinweise: [{stufe, text, tipp}]} - was eingerichtet ist und was dazu fehlt."""
    n = _zaehlen(daten or {})
    anzahl = {k: sum(n.get(t, 0) for t in typen) for k, _, typen in QUELLEN}
    punkte = [{"id": k, "titel": titel, "anzahl": anzahl[k], "ok": anzahl[k] > 0} for k, titel, _ in QUELLEN]
    h = []

    def sag(stufe, text, tipp):
        h.append({"stufe": stufe, "text": text, "tipp": tipp})
    if not any(anzahl.values()):
        sag("fehler", "Es ist keine Quelle eingerichtet – deshalb hat kein Titel einen Stream.",
            "Einstellungen → Anbieter & Addons: ein Addon per Manifest-Adresse, einen eigenen Medienserver oder Usenet eintragen.")
    if anzahl["debrid"] and not anzahl["addons"]:
        sag("warnung", "Ein Debrid-Dienst allein liefert keine Titel.",
            "Debrid löst nur Treffer auf. Die Treffer kommen von einem Addon (Manifest-Adresse) oder einem Indexer, der den Dienst nutzt.")
    if anzahl["usenet_indexer"] and not anzahl["usenet_stream"]:
        sag("hinweis", "Usenet-Indexer liefern nur NZB-Dateien, keinen Stream.",
            "Zum sofortigen Abspielen braucht es NzbDAV, AltMount oder rustnzb (Reiter Usenet-Stream); sonst lädt ein Downloader die Datei erst.")
    if anzahl["usenet_stream"] and not anzahl["usenet_indexer"]:
        sag("warnung", "Usenet-Streaming ohne Indexer findet nichts.", "Einen Newznab-Indexer eintragen (oder binsearch ohne Konto).")
    if anzahl["torrent"] and not anzahl["debrid"]:
        sag("hinweis", "Torrent-Treffer sind nur mit Debrid-Dienst oder Downloader abspielbar.",
            "Ohne Debrid lädt ein Torrent-Client die Datei erst herunter (Reiter Herunterladen).")
    return {"punkte": punkte, "hinweise": h}
