"""World-Repo-Repository: geprüfte Kodi-Repositories aus einer Sammlung.

Quelle: https://github.com/akeotaseo/World-Repo-Repository
Geprüft am 2026-11-05: 261 Einträge, davon 238 mit erreichbarer addons.xml,
23 nicht erreichbar. world_repo.json hält das Ergebnis (ID, Name, Version,
Addon-Zahl, Info-Adresse, Empfehlung). Installiert werden nur Repository-Addons;
die eigentlichen Plugins holt danach das jeweilige Repository.
"""

import json
import os

QUELLE = "https://raw.githubusercontent.com/akeotaseo/World-Repo-Repository/main/"
DATEI = os.path.join(os.path.dirname(os.path.abspath(__file__)), "world_repo.json")
_cache = None


def daten():
    global _cache
    if _cache is None:
        with open(DATEI, encoding="utf-8") as f:
            _cache = json.load(f)
    return _cache


def empfohlene():
    return [r["id"] for r in daten()["repos"] if r.get("empfohlen")]


def gueltig(aid):
    return any(r["id"] == aid for r in daten()["repos"])
