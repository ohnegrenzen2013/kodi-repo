"""XDCC: Pakete von IRC-Bots suchen und laden (nur Python-Standardbibliothek).

Suche ueber mehrere Suchseiten gleichzeitig (xdcc.eu, xdcc.it, xdcc.info, xdcc.rocks, xdccsearch.com, nibl.co.uk fuer
Anime), zusammengefuehrt und ohne
doppelte Pakete (Netzwerk, Server, Kanal, Bot, Paket, Groesse, Name, Quelle). Laden wie ein IRC-Client:
  1. Verbindung zum IRC-Server (TLS auf 6697, sonst 6667), Nick h0rst<zufall>, PING/PONG.
  2. Kanal betreten (viele Bots liefern nur an Kanal-Mitglieder), dann "XDCC SEND #<paket>" an den Bot.
  3. Der Bot bietet die Datei per CTCP "DCC SEND name ip port groesse" an; H0rSt verbindet sich und laedt,
     mit den ueblichen 4-Byte-Bestaetigungen. Liegt schon ein Teil da, fragt H0rSt mit DCC RESUME nach dem Rest.
Passives DCC (Port 0: der Bot will sich zu uns verbinden) geht nicht, weil H0rSt meist hinter NAT steht.
Ein eingestellter Netzweg (Tab Sicherheit) gilt auch hier, weil alle Verbindungen ueber
socket.create_connection laufen. Dateien liegen in <datenordner>/xdcc und lassen sich ueber H0rSt abspielen.
"""

from .xdcc_grund import *
from .xdcc_grund import _DATA, _DCC, _NAME_OK, _TAGS, _XDCCIT, _ZEILE, _ZELLE, _nibl_bots
from .xdcc_suche import dateiname, eigene_aendern, eigene_lesen, eigene_pruefe, ip_aus, netz_server, nibl_lesen, suche_lesen, suchen, suchen_alle, xdccinfo_lesen, xdccit_lesen, xdccrocks_lesen, xdccsearch_lesen, _abruf, _eigene_url, _groesse, _nibl, _text
from .xdcc_client import Auftrag, Irc, Xdcc, dcc_laden
