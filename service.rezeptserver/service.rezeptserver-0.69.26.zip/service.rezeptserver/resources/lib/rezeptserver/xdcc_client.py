"""XDCC-Client: Auftrag, IRC-Verbindung, DCC-Download und die Auftragsverwaltung."""

from .xdcc_grund import (
    ANGEBOT_WARTEN,
    BLOCK,
    DCC_ZEIT,
    MAX_JOBS,
    ORDNER,
    XdccFehler,
    _DCC,
    _TAGS,
    ereignisse,
    log,
    os,
    random,
    re,
    socket,
    ssl,
    string,
    struct,
    threading,
    time,
)

from .xdcc_suche import dateiname, ip_aus

class Auftrag:
    def __init__(self, nummer, server, kanal, bot, paket, name, ordner):
        self.id = str(nummer)
        self.server, self.kanal, self.bot, self.paket = server, kanal, bot, paket
        self.name = dateiname(name) if name else ""
        self.ordner = ordner
        self.status = "wartet"
        self.meldung = ""
        self.fehler = ""
        self.groesse = 0
        self.geladen = 0
        self.tempo = 0
        self.start = time.time()
        self.ende = None
        self._halt = threading.Event()
        self._socks = []

    def als_dict(self):
        return {"id": self.id, "name": self.name or "%s %s" % (self.bot, self.paket), "status": self.status,
                "meldung": self.meldung, "fehler": self.fehler, "groesse": self.groesse, "geladen": self.geladen,
                "prozent": round(100.0 * self.geladen / self.groesse, 1) if self.groesse else 0.0,
                "tempo": self.tempo, "bot": self.bot, "paket": self.paket, "kanal": self.kanal, "server": self.server,
                "laeuft": self.ende is None}

    def abbrechen(self):
        self._halt.set()
        for s in list(self._socks):
            try:
                s.close()
            except OSError:
                pass


class Irc:
    """Kleiner IRC-Client fuer genau einen XDCC-Auftrag."""

    def __init__(self, auftrag, verbinden=None, tls=True):
        self.a = auftrag
        self.verbinden = verbinden or socket.create_connection
        self.tls = tls
        self.nick = "h0rst" + "".join(random.choice(string.ascii_lowercase + string.digits) for _ in range(6))
        self.puffer = b""
        self.sock = None

    def _oeffnen(self):
        host, _, port = self.a.server.partition(":")
        versuche = [(int(port), self.tls)] if port else ([(6697, True), (6667, False)] if self.tls else [(6667, False)])
        fehler = None
        for p, mit_tls in versuche:
            try:
                s = self.verbinden((host, p), 20)
                if mit_tls:
                    s = ssl.create_default_context().wrap_socket(s, server_hostname=host)
                self.sock = s
                self.a._socks.append(s)
                return
            except (OSError, ssl.SSLError) as f:
                fehler = f
        raise XdccFehler("IRC-Server %s nicht erreichbar: %s" % (host, fehler))

    def senden(self, zeile):
        self.sock.sendall((zeile + "\r\n").encode("utf-8"))

    def zeilen(self, bis):
        """Zeilen bis zur Frist; beantwortet PING selbst."""
        while time.time() < bis and not self.a._halt.is_set():
            while b"\r\n" in self.puffer or b"\n" in self.puffer:
                trenner = b"\r\n" if b"\r\n" in self.puffer else b"\n"
                zeile, _, self.puffer = self.puffer.partition(trenner)
                text = zeile.decode("utf-8", "replace")
                if text.startswith("PING"):
                    self.senden("PONG" + text[4:])
                    continue
                yield text
            self.sock.settimeout(max(0.5, min(5, bis - time.time())))
            try:
                teil = self.sock.recv(4096)
            except socket.timeout:
                continue
            if not teil:
                raise XdccFehler("IRC-Server hat die Verbindung beendet")
            self.puffer += teil

    def ablauf(self):
        a = self.a
        a.status, a.meldung = "verbindet", "Verbinde mit %s …" % a.server
        self._oeffnen()
        self.senden("NICK " + self.nick)
        self.senden("USER %s 0 * :H0rSt" % self.nick)
        frist = time.time() + 60
        willkommen = False
        for zeile in self.zeilen(frist):
            teile = zeile.split(" ")
            if len(teile) > 1 and teile[1] == "001":
                willkommen = True
                break
            if len(teile) > 1 and teile[1] == "433":  # Nick vergeben
                self.nick += random.choice(string.digits)
                self.senden("NICK " + self.nick)
        if not willkommen:
            raise XdccFehler("IRC-Anmeldung ohne Antwort")
        if a.kanal:
            a.status, a.meldung = "verbindet", "Betrete %s …" % a.kanal
            self.senden("JOIN " + a.kanal)
            for zeile in self.zeilen(time.time() + 20):
                teile = zeile.split(" ")
                if len(teile) > 1 and teile[1] in ("366", "473", "474", "475", "477"):
                    if teile[1] != "366":
                        a.meldung = "Kanal verweigert (%s), frage den Bot trotzdem" % teile[1]
                    break
        a.status, a.meldung = "angefragt", "XDCC SEND %s an %s" % (a.paket, a.bot)
        self.senden("PRIVMSG %s :XDCC SEND %s" % (a.bot, a.paket))
        return self.angebot_abwarten()

    def angebot_abwarten(self):
        a = self.a
        frist = time.time() + ANGEBOT_WARTEN
        resume = None
        for zeile in self.zeilen(frist):
            absender = zeile[1:].split("!", 1)[0].lower() if zeile.startswith(":") else ""
            if absender != a.bot.lower():
                continue
            if " NOTICE " in zeile:
                a.meldung = _TAGS.sub("", zeile.split(" :", 1)[-1]).replace("\x02", "")[:200]
                frist = max(frist, time.time() + 60)  # Warteschlange: weiter warten
                continue
            m = _DCC.search(zeile)
            if not m:
                continue
            art, name, ip, port = m.group(1), m.group(2).strip('"'), m.group(3), int(m.group(4))
            if art == "SEND":
                groesse = int(m.group(5) or 0)
                if port == 0:
                    raise XdccFehler("Der Bot verlangt passives DCC; das geht hinter NAT nicht")
                a.name = a.name or dateiname(name)
                a.groesse = groesse
                teil = os.path.join(a.ordner, a.name + ".part")
                vorhanden = os.path.getsize(teil) if os.path.exists(teil) else 0
                if 0 < vorhanden < groesse:
                    resume = (ip, port, vorhanden)
                    self.senden('PRIVMSG %s :\x01DCC RESUME "%s" %d %d\x01' % (a.bot, name, port, vorhanden))
                    a.meldung = "Setze fort ab %d Bytes …" % vorhanden
                    continue
                return ip_aus(ip), port, 0
            if art == "ACCEPT" and resume:
                # "DCC ACCEPT name port position" (ohne Adresse): verbunden wird mit der Adresse des Angebots
                return ip_aus(resume[0]), int(ip) if ip.isdigit() else resume[1], int(m.group(4))
        raise XdccFehler("Kein Angebot vom Bot: %s" % (a.meldung or "keine Antwort"))

    def schliessen(self):
        try:
            if self.sock:
                self.senden("QUIT :H0rSt")
                self.sock.close()
        except OSError:
            pass


def dcc_laden(auftrag, ip, port, start, verbinden=None):
    """Datei vom Bot holen; Bestaetigung (gesamt empfangen, 32 Bit) nach jedem Block."""
    a = auftrag
    os.makedirs(a.ordner, exist_ok=True)
    teil = os.path.join(a.ordner, a.name + ".part")
    s = (verbinden or socket.create_connection)((ip, port), DCC_ZEIT)
    a._socks.append(s)
    s.settimeout(DCC_ZEIT)
    a.status, a.meldung, a.geladen = "lädt", "", start
    letzte_zeit, letzte_menge = time.time(), start
    with open(teil, "r+b" if start else "wb") as f:
        f.seek(start)
        f.truncate()
        while a.geladen < a.groesse or not a.groesse:
            if a._halt.is_set():
                raise XdccFehler("abgebrochen")
            daten = s.recv(BLOCK)
            if not daten:
                break
            if a.groesse:
                daten = daten[:a.groesse - a.geladen]  # nie ueber die angekuendigte Groesse hinaus
            f.write(daten)
            a.geladen += len(daten)
            try:
                s.sendall(struct.pack("!I", a.geladen & 0xFFFFFFFF))
            except OSError:
                pass  # manche Bots schliessen sofort nach dem letzten Block
            jetzt = time.time()
            if jetzt - letzte_zeit >= 1:
                a.tempo = int((a.geladen - letzte_menge) / (jetzt - letzte_zeit))
                letzte_zeit, letzte_menge = jetzt, a.geladen
    s.close()
    if a.groesse and a.geladen < a.groesse:
        raise XdccFehler("Verbindung abgebrochen bei %d von %d Bytes (wird beim nächsten Mal fortgesetzt)"
                         % (a.geladen, a.groesse))
    ziel = os.path.join(a.ordner, a.name)
    os.replace(teil, ziel)
    return ziel


class Xdcc:
    """Auftraege verwalten (je Auftrag ein Faden) und die geladenen Dateien."""

    def __init__(self, datenordner, verbinden=None, tls=True, fertig=None):
        self.ordner = os.path.join(datenordner or ".", ORDNER)
        self.verbinden = verbinden
        self.tls = tls
        self.fertig = fertig  # optional: fertig(auftrag) nach erfolgreichem Download (z. B. Markenerkennung)
        self.auftraege = {}
        self._nummer = 0
        self._sperre = threading.Lock()

    def laden(self, server, kanal, bot, paket, name=""):
        server = str(server or "").strip()
        bot = str(bot or "").strip()
        paket = str(paket or "").strip()
        kanal = str(kanal or "").strip()
        if not re.match(r"^[\w.-]+(?::\d{2,5})?$", server):
            raise XdccFehler("Server ungültig")
        if not re.match(r"^[^\s:!@]{1,40}$", bot):
            raise XdccFehler("Bot ungültig")
        if not re.match(r"^#\d{1,7}$", paket):
            raise XdccFehler("Paket muss #<Zahl> sein")
        if kanal and not re.match(r"^[#&][^\s,]{1,60}$", kanal):
            raise XdccFehler("Kanal ungültig")
        with self._sperre:
            if sum(1 for a in self.auftraege.values() if a.ende is None) >= 5:
                raise XdccFehler("Höchstens 5 Downloads gleichzeitig")
            self._nummer += 1
            a = Auftrag(self._nummer, server, kanal, bot, paket, name, self.ordner)
            self.auftraege[a.id] = a
            for alt in sorted((x for x in self.auftraege.values() if x.ende), key=lambda x: x.ende)[:-MAX_JOBS]:
                del self.auftraege[alt.id]
        threading.Thread(target=self._lauf, args=(a,), name="xdcc-" + a.id, daemon=True).start()
        return a.als_dict()

    def _lauf(self, a):
        irc = Irc(a, self.verbinden, self.tls)
        try:
            ip, port, start = irc.ablauf()
            dcc_laden(a, ip, port, start, self.verbinden)
            a.status, a.meldung, a.tempo = "fertig", "", 0
            log.info("XDCC: %s fertig (%d Bytes)", a.name, a.geladen)
            ereignisse.melden("download", "XDCC fertig: %s" % a.name, True)
            if self.fertig:
                try:
                    self.fertig(a)
                except Exception as fehler:
                    log.warning("XDCC-Fertig-Meldung fuer %s: %s", a.name, fehler)
        except (XdccFehler, OSError, ssl.SSLError, ValueError) as fehler:
            a.status = "abgebrochen" if a._halt.is_set() else "fehler"
            a.fehler = str(fehler)[:300]
            if not a._halt.is_set():
                ereignisse.melden("download", "XDCC fehlgeschlagen: %s %s – %s" % (a.bot, a.paket, a.fehler), False)
            a.tempo = 0
            log.warning("XDCC %s %s: %s", a.bot, a.paket, fehler)
        finally:
            irc.schliessen()
            a.ende = time.time()

    def abbrechen(self, auftrag_id):
        a = self.auftraege.get(str(auftrag_id))
        if not a:
            raise XdccFehler("Unbekannter Download")
        a.abbrechen()

    def dateien(self):
        try:
            namen = os.listdir(self.ordner)
        except OSError:
            return []
        liste = []
        for n in namen:
            pfad = os.path.join(self.ordner, n)
            if os.path.isfile(pfad):
                st = os.stat(pfad)
                liste.append({"name": n, "groesse": st.st_size, "zeit": int(st.st_mtime), "teil": n.endswith(".part")})
        return sorted(liste, key=lambda d: -d["zeit"])

    def pfad(self, name):
        name = dateiname(name)
        pfad = os.path.join(self.ordner, name)
        if not os.path.isfile(pfad) or os.path.dirname(os.path.abspath(pfad)) != os.path.abspath(self.ordner):
            raise XdccFehler("Datei nicht gefunden")
        return pfad

    def loeschen(self, name):
        os.remove(self.pfad(name))

    def zustand(self):
        with self._sperre:
            auftraege = sorted(self.auftraege.values(), key=lambda a: -int(a.id))
        return {"auftraege": [a.als_dict() for a in auftraege], "dateien": self.dateien(), "ordner": self.ordner}


