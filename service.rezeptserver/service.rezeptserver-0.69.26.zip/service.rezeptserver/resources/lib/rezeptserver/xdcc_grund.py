"""Grundlage von XDCC: Importe, Logger, Konstanten, Fehler und Adress-Helfer.
Alles hier wird samt Importen wieder exportiert (rezeptserver.xdcc.*)."""


import html
import ipaddress
import logging
import os
import random
import re
import socket
import ssl
import string
import struct
import threading
import time
import urllib.request
from urllib.parse import quote

from . import ereignisse
from .netz import USER_AGENT

log = logging.getLogger("rezeptserver")

SUCHE = "https://www.xdcc.eu/search.php?searchkey=%s"
SUCHE_XDCCIT = "https://xdcc.it/search?l=en&q=%s"
SUCHE_XDCCINFO = "https://www.xdcc.info/search?q=%s"
SUCHE_XDCCROCKS = "https://www.xdcc.rocks/search/?searchword=%s"
SUCHE_XDCCSEARCH = "https://xdccsearch.com/api/search?query=%s"
NIBL_SUCHE = "https://api.nibl.co.uk/nibl/search?query=%s&episodeNumber=-1"
NIBL_BOTS = "https://api.nibl.co.uk/nibl/bots"
# Reihenfolge = Anzeige-Reihenfolge der Quellen in der einen, vereinten Suche
QUELLEN = {"xdcceu": "xdcc.eu", "xdccit": "xdcc.it", "xdccinfo": "xdcc.info", "xdccrocks": "xdcc.rocks",
           "xdccsearch": "xdccsearch.com", "nibl": "nibl.co.uk (Anime)"}
# IRC-Netz (Kurzname) -> Serveradresse, wo die Quelle nur den Netznamen nennt (xdccsearch.com u. a.).
# Grossgeschrieben/mit Punkten normalisiert der Aufrufer vorher (siehe netz_server()).
NETZ_SERVER = {
    "rizon": "irc.rizon.net", "abjects": "irc.abjects.net", "scenep2p": "irc.scenep2p.net",
    "abandoned-irc": "irc.abandoned-irc.net", "abandonedirc": "irc.abandoned-irc.net", "terrachat": "irc.terrachat.net",
    "criten": "irc.criten.net", "swiftirc": "irc.swiftirc.net", "synirc": "irc.synirc.net", "coreirc": "irc.coreirc.net",
    "undernet": "irc.undernet.org", "ircnet": "irc.ircnet.net", "efnet": "irc.efnet.org",
    # weitere bekannte XDCC-Netze (Film, Serien, Anime)
    "irchighway": "irc.irchighway.net", "globalgamers": "irc.globalgamers.net", "mixxnet": "irc.mixxnet.net",
    "snoonet": "irc.snoonet.org", "p2p-network": "irc.p2p-network.net", "p2pnetwork": "irc.p2p-network.net",
    "onlinegamesnet": "irc.onlinegamesnet.net", "dejatoons": "irc.dejatoons.net", "quakenet": "irc.quakenet.org",
    "libera": "irc.libera.chat", "liberachat": "irc.libera.chat", "gamesurge": "irc.gamesurge.net",
    "euirc": "irc.euirc.net", "spotchat": "irc.spotchat.org", "chatspike": "irc.chatspike.net",
    "darkscience": "irc.darkscience.net", "xertion": "irc.xertion.org", "austnet": "irc.austnet.org",
    "7-indonesia": "irc.7-indonesia.org", "allnetwork": "irc.allnetwork.org", "atrum": "irc.atrum.org",
    "deltaanime": "irc.deltaanime.net", "desirutoebi": "irc.desirutoebi.org", "epiknet": "irc.epiknet.org",
    "esper": "irc.esper.net", "freenode": "irc.libera.chat", "hashmark": "irc.hashmark.net",
    "immortal-anime": "irc.immortalanime.net", "immortalanime": "irc.immortalanime.net", "mindforge": "irc.mindforge.org",
    "moddingway": "irc.moddingway.com", "pirc": "irc.pirc.pl", "ptnet": "irc.ptnet.org", "rebelzone": "irc.rebelz.one",
    "serenity-irc": "irc.serenity-irc.net", "serenityirc": "irc.serenity-irc.net", "slashnet": "irc.slashnet.org",
    "sohbet": "irc.sohbet.net", "stormbit": "irc.stormbit.net", "subluminal": "irc.subluminal.net",
    "thunderirc": "irc.thunderirc.net", "virtualife": "irc.virtualife.com.br", "whatnet": "irc.whatnet.org",
    "zoite": "irc.zoite.net", "2600net": "irc.2600.net", "chaat": "irc.chaat.fr", "geekshed": "irc.geekshed.net",
    "ouch": "irc.ouch.chat", "ponychat": "irc.ponychat.net", "recycled-irc": "irc.recycled-irc.net"}
MAX_EIGENE_QUELLEN = 10
_PACKROW = re.compile(r'<tr class="pack-row"([^>]*)>', re.S)  # xdcc.info: Treffer stehen in data-*-Attributen
_DATAATTR = re.compile(r'data-([a-z-]+)="([^"]*)"')
ORDNER = "xdcc"
MAX_TREFFER = 300
ANGEBOT_WARTEN = 120      # Sekunden auf das DCC-Angebot (Warteschlangen der Bots)
DCC_ZEIT = 60
BLOCK = 64 * 1024
MAX_JOBS = 30
_ZEILE = re.compile(r"<tr>(.*?)</tr>", re.S)
_ZELLE = re.compile(r"<td[^>]*>(.*?)</td>", re.S)
_DATA = re.compile(r'data-s="([^"]*)"\s+data-c="([^"]*)"\s+data-p="([^"]*)"')
_TAGS = re.compile(r"<[^>]+>")
_DCC = re.compile(r'\x01DCC (SEND|ACCEPT) ("[^"]+"|\S+) (\S+) (\d+)(?: (\d+))?(?: (\d+))?\x01')
_NAME_OK = re.compile(r"[^\w .,()\[\]+&'!@#%=~-]")


class XdccFehler(Exception):
    pass


_XDCCIT = re.compile(r'\{"id":\[0,\d+\].*?"formattedSize":\[0,[^\]]*\]\}', re.S)


_nibl_bots = {"zeit": 0, "namen": {}}
