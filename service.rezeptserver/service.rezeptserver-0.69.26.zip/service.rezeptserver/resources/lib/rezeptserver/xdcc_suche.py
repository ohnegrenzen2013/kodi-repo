"""XDCC-Suche: Treffer von xdcc.eu, xdcc.it, xdcc.info, xdcc.rocks, xdccsearch.com und nibl.co.uk, zu einer Suche
vereint (parallel, ohne doppelte Pakete), dazu Namens-/Adress-Helfer."""

from .xdcc_grund import (
    MAX_EIGENE_QUELLEN,
    MAX_TREFFER,
    NETZ_SERVER,
    NIBL_BOTS,
    NIBL_SUCHE,
    QUELLEN,
    SUCHE,
    SUCHE_XDCCINFO,
    SUCHE_XDCCIT,
    SUCHE_XDCCROCKS,
    SUCHE_XDCCSEARCH,
    _DATAATTR,
    _PACKROW,
    USER_AGENT,
    XdccFehler,
    _DATA,
    _NAME_OK,
    _TAGS,
    _XDCCIT,
    _ZEILE,
    _ZELLE,
    _nibl_bots,
    html,
    ipaddress,
    log,
    os,
    quote,
    re,
    time,
    urllib,
)

def _text(roh):
    return html.unescape(_TAGS.sub("", roh)).strip()


def netz_server(netz):
    """IRC-Serveradresse zu einem Netz-Kurznamen (xdccsearch.com u. a. nennen nur ihn). Fallback irc.<name>.net."""
    schluessel = re.sub(r"[^a-z0-9.-]", "", str(netz or "").strip().lower())
    if not schluessel:
        return ""
    return NETZ_SERVER.get(schluessel) or NETZ_SERVER.get(schluessel.replace(".", "")) or "irc.%s.net" % schluessel


def _groesse(text):
    m = re.match(r"([\d.]+)\s*([KMGT]?)", str(text).upper())
    if not m:
        return 0
    return int(float(m.group(1)) * {"": 1, "K": 1 << 10, "M": 1 << 20, "G": 1 << 30, "T": 1 << 40}[m.group(2)])


def suche_lesen(text):
    """Trefferliste aus der Ergebnisseite von xdcc.eu."""
    treffer = []
    for zeile in _ZEILE.findall(text):
        zellen = _ZELLE.findall(zeile)
        daten = _DATA.search(zeile)
        if len(zellen) < 7 or not daten:
            continue
        bot, _, pack = html.unescape(daten.group(3)).partition(" xdcc send ")
        if not pack.startswith("#"):
            continue
        treffer.append({"netzwerk": _text(zellen[0]), "server": html.unescape(daten.group(1)),
                        "kanal": html.unescape(daten.group(2)), "bot": bot.strip(), "paket": pack.strip(),
                        "abrufe": _text(zellen[4]), "groesse_text": _text(zellen[5]), "groesse": _groesse(_text(zellen[5])),
                        "name": _text(zellen[6])})
        if len(treffer) >= MAX_TREFFER:
            break
    return treffer


def _abruf(url, holen=None):
    if holen:
        return holen(url)
    anfrage = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0 " + USER_AGENT})
    with urllib.request.urlopen(anfrage, timeout=30) as a:
        return a.read(4 * 1024 * 1024).decode("utf-8", "replace")


def xdccit_lesen(seite):
    """xdcc.it: Treffer stehen als Astro-Daten ({"feld": [0, wert]}) in der Seite."""
    import json
    treffer = []
    for roh in _XDCCIT.findall(html.unescape(seite)):
        try:
            d = {k: (w[1] if isinstance(w, list) and len(w) == 2 else w) for k, w in json.loads(roh).items()}
        except ValueError:
            continue
        if not d.get("botName") or d.get("packNumber") is None or not d.get("networkServer"):
            continue
        port = d.get("networkPort")
        groesse_text = str(d.get("sizeLabel") or d.get("formattedSize") or "")
        treffer.append({"netzwerk": str(d.get("networkName") or ""),
                        "server": "%s:%s" % (d["networkServer"], port) if port else str(d["networkServer"]),
                        "kanal": str(d.get("channel") or ""), "bot": str(d["botName"]), "paket": "#%s" % d["packNumber"],
                        "abrufe": "", "groesse_text": groesse_text,
                        "groesse": int(d["sizeBytes"]) if d.get("sizeBytes") else _groesse(groesse_text),
                        "name": str(d.get("filename") or "")})
        if len(treffer) >= MAX_TREFFER:
            break
    return treffer


def nibl_lesen(text, bots):
    import json
    d = json.loads(text)
    treffer = []
    for p in d.get("content") or []:
        bot = bots.get(p.get("botId"))
        if not bot or p.get("number") is None:
            continue
        treffer.append({"netzwerk": "Rizon", "server": "irc.rizon.net", "kanal": "#nibl", "bot": bot,
                        "paket": "#%s" % p["number"], "abrufe": "", "groesse_text": str(p.get("size") or ""),
                        "groesse": int(p.get("sizekbits") or 0) or _groesse(str(p.get("size") or "")),
                        "name": str(p.get("name") or "")})
    return treffer[:MAX_TREFFER]


def _nibl(text, holen=None):
    import json
    if not _nibl_bots["namen"] or time.time() - _nibl_bots["zeit"] > 6 * 3600:
        bots = json.loads(_abruf(NIBL_BOTS, holen)).get("content") or []
        _nibl_bots.update(zeit=time.time(), namen={b["id"]: b["name"] for b in bots if b.get("id") and b.get("name")})
    return nibl_lesen(_abruf(NIBL_SUCHE % quote(text), holen), _nibl_bots["namen"])


def xdccinfo_lesen(seite):
    """xdcc.info: jede Trefferzeile <tr class="pack-row" data-...> traegt alles in data-Attributen."""
    treffer = []
    for attrs in _PACKROW.findall(seite):
        d = {k: html.unescape(v) for k, v in _DATAATTR.findall(attrs)}
        if not d.get("bot") or not d.get("pack-num") or not (d.get("network-address") or d.get("network")):
            continue
        treffer.append({"netzwerk": d.get("network", ""),
                        "server": d.get("network-address") or d.get("network", ""),
                        "kanal": d.get("channel", ""), "bot": d["bot"], "paket": "#" + d["pack-num"],
                        "abrufe": d.get("gets", ""), "groesse_text": d.get("filesize", ""),
                        "groesse": _groesse(d.get("filesize", "")), "name": d.get("filename", "")})
        if len(treffer) >= MAX_TREFFER:
            break
    return treffer


def xdccrocks_lesen(text):
    """xdcc.rocks: verschachtelt results[].channels[].bots[].files[] mit serverhost je Treffer."""
    import json
    daten = json.loads(text)
    treffer = []
    for netz in daten.get("results") or []:
        server = str(netz.get("serverhost") or "")
        if netz.get("serverport") and str(netz["serverport"]) not in ("6667", "0"):
            server += ":%s" % netz["serverport"]
        for kanal in netz.get("channels") or []:
            for bot in kanal.get("bots") or []:
                for datei in bot.get("files") or []:
                    f = datei.get("file") or {}
                    if not bot.get("botname") or datei.get("packnumber") is None or not server:
                        continue
                    groesse = int(f["filesizeinbytes"]) if f.get("filesizeinbytes") else _groesse(str(f.get("filesize") or ""))
                    treffer.append({"netzwerk": str(netz.get("servername") or ""), "server": server,
                                    "kanal": str(kanal.get("channelname") or ""), "bot": str(bot["botname"]),
                                    "paket": "#%s" % datei["packnumber"], "abrufe": str(datei.get("numdownloads") or ""),
                                    "groesse_text": str(f.get("filesize") or ""), "groesse": groesse,
                                    "name": str(f.get("filename") or "")})
                    if len(treffer) >= MAX_TREFFER:
                        return treffer
    return treffer


def xdccsearch_lesen(text):
    """xdccsearch.com: flache JSON-Liste; der Server ergibt sich aus dem Netz-Kurznamen (NETZ_SERVER)."""
    import json
    daten = json.loads(text)
    treffer = []
    for p in daten.get("data") or []:
        netz = str(p.get("network") or "").lower()
        if not p.get("botname") or p.get("slot") is None or not netz:
            continue
        server = netz_server(netz)
        treffer.append({"netzwerk": str(p.get("network") or ""), "server": server,
                        "kanal": str(p.get("channel") or ""), "bot": str(p["botname"]), "paket": "#%s" % p["slot"],
                        "abrufe": str(p.get("gets") or ""), "groesse_text": "",
                        "groesse": int(p.get("size_bytes") or 0), "name": str(p.get("filename") or "")})
        if len(treffer) >= MAX_TREFFER:
            break
    return treffer


def eigene_pruefe(daten):
    """Eigene XDCC-Listen (XDCCParser/iroffer oder ein Klon von xdcc.eu/.info/.rocks) aus den Nutzerdaten.
    Nutzerdaten "xdcc": {"eigene": [{"id", "name", "url"}]}; in url steht %s fuer den Suchbegriff."""
    roh = (daten or {}).get("xdcc") if isinstance(daten, dict) else None
    liste, ids = [], set()
    for e in ((roh or {}).get("eigene") or [])[:MAX_EIGENE_QUELLEN] if isinstance(roh, dict) else []:
        if not isinstance(e, dict):
            continue
        url = str(e.get("url") or "").strip()
        if not url.lower().startswith(("http://", "https://")):
            continue
        name = " ".join(str(e.get("name") or "").split())[:60] or re.sub(r"^https?://(www\.)?", "", url).split("/")[0]
        eid = re.sub(r"[^a-z0-9]", "", str(e.get("id") or name).lower())[:16] or "q"
        while eid in ids:
            eid += "x"
        ids.add(eid)
        liste.append({"id": eid, "name": name, "url": url[:500]})
    return liste


def eigene_aendern(daten, wunsch):
    """{"aktion": "hinzu", "name", "url"} oder {"aktion": "weg", "id"}. Gibt die neue Liste zurueck."""
    if not isinstance(wunsch, dict):
        raise XdccFehler("JSON-Objekt erwartet")
    eigene = eigene_pruefe(daten)
    aktion = wunsch.get("aktion")
    if aktion == "hinzu":
        url = str(wunsch.get("url") or "").strip()
        if not url.lower().startswith(("http://", "https://")):
            raise XdccFehler("Adresse muss mit http:// oder https:// beginnen")
        if len(eigene) >= MAX_EIGENE_QUELLEN:
            raise XdccFehler("Höchstens %d eigene Quellen" % MAX_EIGENE_QUELLEN)
        eigene.append({"id": "", "name": str(wunsch.get("name") or ""), "url": url})
    elif aktion == "weg":
        eigene = [e for e in eigene if e["id"] != str(wunsch.get("id") or "")]
    else:
        raise XdccFehler("Unbekannte Aktion")
    daten["xdcc"] = dict(daten.get("xdcc") or {}, eigene=[{"name": e["name"], "url": e["url"]} for e in eigene])
    return eigene_pruefe(daten)


def _eigene_url(url, text):
    return url % quote(text) if "%s" in url else url + quote(text)


def eigene_lesen(text):
    """Antwort einer eigenen XDCC-Liste erkennen und lesen: JSON (xdcc.rocks/xdccsearch) oder HTML
    (xdcc.info-Zeilen, xdcc.eu-Tabelle, xdcc.it-Astro). Nimmt das erste Format, das Treffer liefert."""
    anfang = text.lstrip()[:1]
    kandidaten = [xdccrocks_lesen, xdccsearch_lesen] if anfang in ("{", "[") else [xdccinfo_lesen, suche_lesen, xdccit_lesen]
    for fn in kandidaten:
        try:
            liste = fn(text)
        except Exception:
            continue
        if liste:
            return liste
    return []


def suchen_alle(text, holen=None, quellen=None, eigene=None):
    """Alle Suchseiten parallel. Gibt (treffer, {quelle: anzahl oder Fehlertext}) zurueck."""
    from concurrent.futures import ThreadPoolExecutor
    text = " ".join(str(text or "").split())[:100]
    if len(text) < 2:
        raise XdccFehler("Suchbegriff zu kurz")
    arbeit = {"xdcceu": lambda: suche_lesen(_abruf(SUCHE % quote(text), holen)),
              "xdccit": lambda: xdccit_lesen(_abruf(SUCHE_XDCCIT % quote(text), holen)),
              "xdccinfo": lambda: xdccinfo_lesen(_abruf(SUCHE_XDCCINFO % quote(text), holen)),
              "xdccrocks": lambda: xdccrocks_lesen(_abruf(SUCHE_XDCCROCKS % quote(text), holen)),
              "xdccsearch": lambda: xdccsearch_lesen(_abruf(SUCHE_XDCCSEARCH % quote(text), holen)),
              "nibl": lambda: _nibl(text, holen)}
    namen = dict(QUELLEN)
    for e in eigene or []:
        sid = "eigen:" + e["id"]
        namen[sid] = e["name"]
        arbeit[sid] = (lambda u=e["url"]: eigene_lesen(_abruf(_eigene_url(u, text), holen)))
    gewaehlt = [q for q in (quellen or list(namen)) if q in arbeit]
    stand, treffer, gesehen = {}, [], set()
    with ThreadPoolExecutor(max_workers=len(gewaehlt) or 1) as pool:
        laufend = {q: pool.submit(arbeit[q]) for q in gewaehlt}
        for q, f in laufend.items():
            try:
                liste = f.result(timeout=40)
            except Exception as fehler:
                stand[q] = "Fehler: %s" % str(fehler)[:120]
                log.info("XDCC-Suche %s: %s", q, fehler)
                continue
            stand[q] = len(liste)
            for t in liste:
                schluessel = (t["server"].split(":")[0].lower(), t["bot"].lower(), t["paket"])
                if schluessel not in gesehen:
                    gesehen.add(schluessel)
                    treffer.append(dict(t, quelle=namen[q]))
    if not treffer and stand and all(isinstance(w, str) for w in stand.values()):
        raise XdccFehler("Keine Suchseite erreichbar: " + "; ".join("%s %s" % (namen[q], w) for q, w in stand.items()))
    return treffer, stand


def suchen(text, holen=None):
    """Nur xdcc.eu (bleibt fuer Aufrufer, die eine Liste erwarten)."""
    return suchen_alle(text, holen, ["xdcceu"])[0]


def dateiname(roh):
    """Sicherer Dateiname (kein Pfad, keine Steuerzeichen)."""
    name = os.path.basename(str(roh or "").strip().strip('"').replace("\\", "/"))
    name = _NAME_OK.sub("_", name).strip(" .")
    if not name:
        raise XdccFehler("Ungültiger Dateiname")
    return name[:200]


def ip_aus(wert):
    """DCC-Adresse: Ganzzahl (IPv4) oder Text (IPv6/IPv4)."""
    if wert.isdigit():
        return str(ipaddress.IPv4Address(int(wert)))
    return str(ipaddress.ip_address(wert))


