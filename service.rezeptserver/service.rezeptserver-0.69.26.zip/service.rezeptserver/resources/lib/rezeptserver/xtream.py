"""Xtream-Codes-Schnittstelle fuer das Live-TV, damit IPTV-Apps (IPTV Smarters, TiviMate, XCIPTV ...)
den Server ueber Server-Adresse, Benutzer und Passwort einbinden koennen (wie in vxparser).

Pfade, ohne Token-Praefix erreichbar (viele Apps vertragen keinen Pfad in der Server-Adresse):
  /player_api.php   Anmeldung, Kategorien, Sender, Kurz-EPG (get_short_epg, get_simple_data_table)
  /panel_api.php    alles auf einmal (aeltere Apps)
  /get.php          Senderliste als M3U (Stream-Adressen ueber /live/...)
  /xmltv.php        EPG (dieselbe wie /epg.xml)
  /live/<benutzer>/<passwort>/<stream-id>.<endung>   leitet auf die Stream-Adresse weiter

Anmeldung: Benutzer beliebig (nicht leer), Passwort ist immer das Token. Ohne Token ist niemand
angemeldet. Inhalt: offizielle Sender und eigene Listen, wie /tv.m3u.
Filme und Serien (VOD) bleiben leer, die laufen ueber das Stremio-Addon.
"""

import base64
import calendar
import gzip
import hmac
import json
import logging
import os
import re
import threading
import time
import xml.etree.ElementTree as ET
import zlib
from datetime import datetime
from urllib.parse import parse_qs, quote, unquote

from . import __version__, livetv

log = logging.getLogger("rezeptserver")

_API = re.compile(r"^/(player_api|panel_api|get|xmltv)\.php$")
_LIVE = re.compile(r"^/live/([^/]+)/([^/]+)/(\d{1,10})(?:\.[A-Za-z0-9]{1,5})?$")
LISTEN_START = 1000  # Stream-IDs bis hier gehoeren den offiziellen Sendern (Position in livetv.SENDER)
EPG_VORLAUF = 2 * 86400  # Kurz-EPG: Sendungen bis zwei Tage im Voraus
EPG_NEU_BAUEN = 6 * 3600
LEER = {"get_vod_categories": [], "get_vod_streams": [], "get_series_categories": [], "get_series": [],
        "get_vod_info": {}, "get_series_info": {}}


def ist_route(pfad):
    return bool(_API.match(pfad) or _LIVE.match(pfad))


def _listen_id(liste_id, url):
    """Stabile Stream-ID fuer einen Eintrag einer eigenen Liste (bleibt bei gleicher Adresse gleich)."""
    return LISTEN_START + zlib.crc32(("%s\n%s" % (liste_id, url)).encode("utf-8")) % 1000000000


def _stand(pfad):
    try:
        return os.path.getmtime(pfad)
    except OSError:
        return 0


def _b64(text):
    return base64.b64encode(str(text or "").encode("utf-8")).decode("ascii")


def xmltv_zeit(text):
    """'20261011203000 +0200' -> Unix-Zeit; ohne Zone als UTC, None wenn unverstaendlich."""
    text = str(text or "").strip()
    try:
        if len(text) > 14:
            return datetime.strptime(text[:14] + " " + text[14:].strip(), "%Y%m%d%H%M%S %z").timestamp()
        return float(calendar.timegm(time.strptime(text[:14], "%Y%m%d%H%M%S")))
    except ValueError:
        return None


def zeitzone():
    """IANA-Name der Zeitzone des Geraets (fuer server_info), sonst UTC."""
    tz = os.environ.get("TZ", "").lstrip(":")
    if "/" in tz:
        return tz
    try:
        with open("/etc/timezone", encoding="utf-8") as f:
            name = f.read().strip()
        if name:
            return name
    except OSError:
        pass
    ziel = os.path.realpath("/etc/localtime")
    return ziel.split("zoneinfo/", 1)[1] if "zoneinfo/" in ziel else "UTC"


def _lokal(zeitpunkt):
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(zeitpunkt))


def epg_index(pfad, kennungen, jetzt=None):
    """{tvg-id: [(start, ende, titel, beschreibung)]} aus einer gepackten XMLTV-Datei.

    Nur Sender aus kennungen und nur Sendungen, die noch laufen oder in den naechsten zwei Tagen beginnen;
    so bleibt auch eine grosse EPG-Quelle klein im Speicher."""
    jetzt = time.time() if jetzt is None else jetzt
    index = {}
    with gzip.open(pfad, "rb") as f:
        wurzel = None
        for ereignis, elem in ET.iterparse(f, events=("start", "end")):
            if wurzel is None:
                wurzel = elem
            if ereignis != "end" or elem.tag != "programme":
                continue
            kanal = elem.get("channel")
            if kanal in kennungen:
                start, ende = xmltv_zeit(elem.get("start")), xmltv_zeit(elem.get("stop"))
                if start is not None and ende is not None and ende > jetzt and start < jetzt + EPG_VORLAUF:
                    index.setdefault(kanal, []).append((start, ende, elem.findtext("title") or "",
                                                        elem.findtext("desc") or ""))
            wurzel.clear()  # verarbeitete Sendungen freigeben
    for sendungen in index.values():
        sendungen.sort()
    return index


class Xtream:
    def __init__(self, app):
        self.app = app
        self.seit = int(time.time())
        self._sperre = threading.Lock()
        self._kanaele = (None, [])
        self._epg = (None, 0.0, {})
        self._epg_faden = None

    # --- Anmeldung ------------------------------------------------------
    def angemeldet(self, benutzer, passwort):
        if not benutzer or not self.app.token:
            return False
        gegeben = str(passwort or "").encode("utf-8")
        erwartet = self.app.token.encode("utf-8")
        if len(gegeben) != len(erwartet):
            return False
        return hmac.compare_digest(gegeben, erwartet)

    def user_info(self, benutzer, passwort):
        return {"username": benutzer, "password": passwort, "message": "m0dulh0st - H0rSt %s" % __version__,
                "auth": 1, "status": "Active", "exp_date": None, "is_trial": "0", "active_cons": "0",
                "created_at": str(self.seit), "max_connections": "10", "allowed_output_formats": ["m3u8"]}

    @staticmethod
    def server_info(kopf):
        host = (kopf.get("Host") or "").strip()
        name, _, port = host.rpartition(":") if host.count(":") == 1 else (host, "", "")
        jetzt = time.time()
        return {"url": name or host, "port": port or "80", "https_port": "", "server_protocol": "http",
                "rtmp_port": "", "timezone": zeitzone(), "timestamp_now": int(jetzt), "time_now": _lokal(jetzt),
                "process": True}

    # --- Sender ---------------------------------------------------------
    def kanaele(self):
        """Eingeschaltete Sender und Eintraege der eigenen Listen:
        [{"id", "name", "gruppe", "tvg_id", "logo", "logo_id", "url"}]; logo_id = mitgeliefertes Senderlogo."""
        listen = list(self.app.listen.values())
        schluessel = (json.dumps(self.app.livetv, sort_keys=True), self.app.adressen.quelle,
                      _stand(self.app.adressen.pfad), tuple((l.id, _stand(l.pfad)) for l in listen))
        with self._sperre:
            if self._kanaele[0] == schluessel:
                return self._kanaele[1]
        ergebnis, ids = [], set()
        for nummer, s in enumerate(livetv.sender(self.app.livetv, self.app.adressen.adressen()), 1):
            if s["an"]:
                ergebnis.append({"id": nummer, "name": s["name"], "gruppe": s["gruppe"], "tvg_id": s["tvg_id"],
                                 "logo": s["logo"] or "", "logo_id": s["id"] if s["logo"] else None, "url": s["url"]})
        for liste in listen:
            for e in liste.eintraege():
                sid = _listen_id(liste.id, e["url"])
                if sid in ids:
                    continue  # dieselbe Adresse doppelt in einer Liste
                ids.add(sid)
                a = e["attribute"]
                ergebnis.append({"id": sid, "name": e["name"], "gruppe": a.get("group-title") or liste.name,
                                 "tvg_id": a.get("tvg-id") or "", "logo": a.get("tvg-logo") or "", "logo_id": None,
                                 "url": e["url"]})
        with self._sperre:
            self._kanaele = (schluessel, ergebnis)
        return ergebnis

    @staticmethod
    def kategorien(kanaele):
        gruppen = []
        for k in kanaele:
            if k["gruppe"] not in gruppen:
                gruppen.append(k["gruppe"])
        return gruppen

    def streams(self, kanaele, logo_basis, kategorie=None):
        gruppen = self.kategorien(kanaele)
        ergebnis = []
        for k in kanaele:
            kid = str(gruppen.index(k["gruppe"]) + 1)
            if kategorie not in (None, "", kid):
                continue
            logo = "%slogos/%s.png" % (logo_basis, k["logo_id"]) if logo_basis and k["logo_id"] else k["logo"]
            ergebnis.append({"num": len(ergebnis) + 1, "name": k["name"], "stream_type": "live", "stream_id": k["id"],
                             "stream_icon": logo, "epg_channel_id": k["tvg_id"], "added": str(self.seit),
                             "is_adult": 0, "category_id": kid, "category_ids": [int(kid)], "custom_sid": "",
                             "tv_archive": 0, "direct_source": "", "tv_archive_duration": 0})
        return ergebnis

    # --- Kurz-EPG -------------------------------------------------------
    def _index(self, kennungen):
        """EPG-Index der aktuellen EPG-Datei; wird im Hintergrund gebaut, solange gibt es den alten (oder keinen)."""
        try:
            stand = os.path.getmtime(self.app.epg.pfad)
        except OSError:
            return {}
        schluessel = (self.app.epg.pfad, stand, frozenset(kennungen))
        with self._sperre:
            alt, gebaut, index = self._epg
            if alt == schluessel and time.time() - gebaut < EPG_NEU_BAUEN:
                return index
            if self._epg_faden is None or not self._epg_faden.is_alive():
                self._epg_faden = threading.Thread(target=self._index_bauen, args=(schluessel,),
                                                   name="xtream-epg", daemon=True)
                self._epg_faden.start()
            return index

    def _index_bauen(self, schluessel):
        pfad, _, kennungen = schluessel
        try:
            index = epg_index(pfad, kennungen)
        except (OSError, ET.ParseError, EOFError) as fehler:
            log.warning("Xtream: EPG nicht lesbar: %s", fehler)
            index = {}
        with self._sperre:
            self._epg = (schluessel, time.time(), index)

    def kurz_epg(self, kanaele, stream_id, limit=None):
        kanal = next((k for k in kanaele if str(k["id"]) == str(stream_id)), None)
        if not kanal or not kanal["tvg_id"]:
            return {"epg_listings": []}
        sendungen = self._index({k["tvg_id"] for k in kanaele if k["tvg_id"]}).get(kanal["tvg_id"], [])
        jetzt = time.time()
        sendungen = [s for s in sendungen if s[1] > jetzt]
        if limit is not None:
            sendungen = sendungen[:limit]
        return {"epg_listings": [
            {"id": str(nummer), "epg_id": str(kanal["id"]), "title": _b64(titel), "lang": "de",
             "start": _lokal(start), "end": _lokal(ende), "description": _b64(text), "channel_id": kanal["tvg_id"],
             "start_timestamp": str(int(start)), "stop_timestamp": str(int(ende)),
             "now_playing": 1 if start <= jetzt < ende else 0, "has_archive": 0}
            for nummer, (start, ende, titel, text) in enumerate(sendungen, 1)]}

    # --- Routing --------------------------------------------------------
    def bearbeite(self, pfad, abfrage, methode, koerper, kopf):
        """Wie App.bearbeite; zusaetzlich ("weiter", url) fuer die Weiterleitung auf einen Stream."""
        live = _LIVE.match(pfad)
        if live:
            benutzer, passwort, sid = live.groups()
            if not self.angemeldet(unquote(benutzer), unquote(passwort)):
                return 403, "application/json", {"err": "forbidden"}
            kanal = next((k for k in self.kanaele() if str(k["id"]) == sid), None)
            if not kanal:
                return 404, "application/json", {"err": "unbekannter Sender"}
            return "weiter", kanal["url"]
        parameter = {k: v[0] for k, v in parse_qs(abfrage).items()}
        if methode == "POST":
            try:
                for k, v in parse_qs(koerper.decode("utf-8")).items():
                    parameter.setdefault(k, v[0])
            except UnicodeDecodeError:
                return 400, "application/json", {"err": "bad request"}
        elif methode != "GET":
            return 405, "application/json", {"err": "method not allowed"}
        benutzer, passwort = parameter.get("username", ""), parameter.get("password", "")
        art = _API.match(pfad).group(1)
        if not self.angemeldet(benutzer, passwort):
            return (200 if art == "player_api" and not parameter.get("action") else 401), "application/json", \
                {"user_info": {"auth": 0}}
        logo_basis = self.app.eigene_basis(kopf)
        if art == "get":
            return 200, "audio/x-mpegurl", self.m3u(benutzer, passwort, kopf, parameter.get("type") == "m3u")
        if art == "xmltv":
            epg = self.app.epg
            if not epg.quelle:
                return 404, "application/json", {"err": "keine EPG eingerichtet"}
            epg.bei_bedarf_erneuern(warten=epg.alter() is None)
            if epg.alter() is None:
                return 503, "application/json", {"err": "EPG noch nicht geladen: %s" % (epg.fehler or "bitte warten")}
            return "datei", epg.pfad, True
        kanaele = self.kanaele()
        kategorien = [{"category_id": str(i), "category_name": g, "parent_id": 0}
                      for i, g in enumerate(self.kategorien(kanaele), 1)]
        if art == "panel_api":
            return 200, "application/json", {
                "user_info": self.user_info(benutzer, passwort), "server_info": self.server_info(kopf),
                "categories": {"live": kategorien, "movie": [], "series": []},
                "available_channels": {str(s["stream_id"]): s for s in self.streams(kanaele, logo_basis)}}
        aktion = parameter.get("action", "")
        if not aktion:
            return 200, "application/json", {"user_info": self.user_info(benutzer, passwort),
                                             "server_info": self.server_info(kopf)}
        if aktion == "get_live_categories":
            return 200, "application/json", kategorien
        if aktion == "get_live_streams":
            return 200, "application/json", self.streams(kanaele, logo_basis, parameter.get("category_id"))
        if aktion in ("get_short_epg", "get_simple_data_table"):
            limit = parameter.get("limit", "4")
            limit = max(1, min(int(limit), 100)) if limit.isdigit() else 4
            return 200, "application/json", self.kurz_epg(kanaele, parameter.get("stream_id"),
                                                          limit if aktion == "get_short_epg" else None)
        if aktion in LEER:
            return 200, "application/json", LEER[aktion]
        return 400, "application/json", {"err": "unbekannte Aktion"}

    def m3u(self, benutzer, passwort, kopf, einfach=False):
        """Senderliste wie get.php eines Xtream-Servers; Stream-Adressen zeigen auf /live/... dieses Servers."""
        host = (kopf.get("Host") or "").strip()
        wurzel = "http://%s/" % host if host and not any(z in host for z in ' "/\\<>') else "/"
        zugang = "%s/%s" % (quote(benutzer, safe=""), quote(passwort, safe=""))
        kopfzeile = "#EXTM3U"
        if self.app.epg.quelle:
            kopfzeile += ' url-tvg="%sxmltv.php?username=%s&password=%s"' % (
                wurzel, quote(benutzer, safe=""), quote(passwort, safe=""))
        zeilen = [kopfzeile]
        kanaele = self.kanaele()
        for k, s in zip(kanaele, self.streams(kanaele, self.app.eigene_basis(kopf))):
            if einfach:
                zeilen.append("#EXTINF:-1,%s" % s["name"].replace("\n", " "))
            else:
                zeilen.append('#EXTINF:-1 tvg-id="%s" tvg-name="%s" tvg-logo="%s" group-title="%s",%s' % (
                    livetv._attribut(s["epg_channel_id"]), livetv._attribut(s["name"]),
                    livetv._attribut(s["stream_icon"]), livetv._attribut(k["gruppe"]), s["name"].replace("\n", " ")))
            zeilen.append("%slive/%s/%d.m3u8" % (wurzel, zugang, s["stream_id"]))
        return "\n".join(zeilen) + "\n"
