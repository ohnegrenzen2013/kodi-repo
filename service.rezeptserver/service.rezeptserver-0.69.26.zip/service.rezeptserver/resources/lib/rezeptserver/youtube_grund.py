"""Grundlage von YouTube: Importe, Logger, Einstellungen, Konstanten und der Fehler.
Alles hier wird samt Importen wieder exportiert (rezeptserver.youtube.*)."""


import json
import logging
import os
import re
import shutil
import subprocess
import threading
import time
import urllib.error
import urllib.request
import xml.etree.ElementTree as ET
from concurrent.futures import ThreadPoolExecutor, wait
from urllib.parse import quote

from . import ereignisse
from .netz import USER_AGENT

log = logging.getLogger("rezeptserver")

SCHLUESSEL = "youtube"
STANDARD = {"kanaele": [], "sponsorblock": True}
MAX_KANAELE = 200
FEED = "https://www.youtube.com/feeds/videos.xml?channel_id=%s"
SPONSORBLOCK = "https://sponsor.ajay.app/api/skipSegments?videoID=%s&categories=%s"
SB_KATEGORIEN = ["sponsor", "selfpromo", "interaction", "intro", "outro", "preview", "music_offtopic"]
SB_NAMEN = {"sponsor": "Sponsor", "selfpromo": "Eigenwerbung", "interaction": "Abo-Aufruf", "intro": "Intro",
            "outro": "Abspann", "preview": "Vorschau", "music_offtopic": "Nicht-Musik"}
_KENNUNG = re.compile(r"^[\w-]{11}$")
_KANAL = re.compile(r"^UC[\w-]{22}$")
_NS = {"a": "http://www.w3.org/2005/Atom", "yt": "http://www.youtube.com/xml/schemas/2015",
       "m": "http://search.yahoo.com/mrss/"}
# Zustimmungs-Seite der EU ueberspringen (wie nach "Alle ablehnen")
_KEKS = {"Cookie": "CONSENT=PENDING+987; SOCS=CAESEwgDEgk0ODE3Nzk3MjQaAmRlIAEaBgiA_LyaBg"}
ABLAUF = 4 * 3600
LIVE_ZEIT = 5 * 60  # Live-Status (YT6): nur beim Oeffnen des Reiters/"Neu pruefen" geprueft, kein Hintergrundlauf
MAX_LIVE_KANAELE = 60
SHORTS_ZEIT = 30 * 60  # Shorts (YT7): seltener aktuell als Live, deshalb laengerer Zwischenspeicher
MAX_SHORTS_KANAELE = 12
MAX_SHORTS_JE_KANAL = 10
# live()/shorts() rufen _ytdlp() bis zu 60x/12x je Anfrage auf (Code-Review-Fund): ohne eigenes Zeitlimit
# haengt ein einzelner nicht antwortender Kanal sonst den ganzen Request-Thread unbegrenzt auf.
NETZ_ZEITGRENZE = 10
# NETZ_ZEITGRENZE begrenzt nur den einzelnen yt-dlp-Aufruf; bei 60/12 Kanaelen und 8 Threads summieren
# sich mehrere Runden sonst auf ein Vielfaches davon (Code-Review-Fund). GESAMT_ZEITGRENZE kappt live()/
# shorts() als Ganzes - noch laufende Pruefungen zaehlen dann als "nicht erreicht", nicht als Fehler.
GESAMT_ZEITGRENZE = 25
ORDNER = "youtube"
MIN_TEMPO, MAX_TEMPO = 0.25, 4.0


class YoutubeFehler(ValueError):
    pass
