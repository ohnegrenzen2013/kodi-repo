"""YouTube-Kanal: Suche, Abo-Feed, Kanaele, Wiedergabe-Adresse und SponsorBlock."""

from .youtube_grund import (
    ABLAUF,
    ET,
    FEED,
    GESAMT_ZEITGRENZE,
    LIVE_ZEIT,
    MAX_KANAELE,
    MAX_LIVE_KANAELE,
    MAX_SHORTS_JE_KANAL,
    MAX_SHORTS_KANAELE,
    NETZ_ZEITGRENZE,
    SHORTS_ZEIT,
    SB_KATEGORIEN,
    SB_NAMEN,
    SPONSORBLOCK,
    STANDARD,
    ThreadPoolExecutor,
    USER_AGENT,
    YoutubeFehler,
    _KANAL,
    _KEKS,
    _KENNUNG,
    _NS,
    json,
    log,
    quote,
    re,
    threading,
    time,
    urllib,
    wait,
)

# Kanalbilder liegen bei Google auf yt3.ggpht.com bzw. yt3.googleusercontent.com; nur solche Adressen werden gemerkt
_KANALBILD = re.compile(r"^https://yt3\.(?:ggpht|googleusercontent)\.com/[\w\-=/.]{1,300}$")


def pruefe(roh):
    e = dict(STANDARD)
    if isinstance(roh, dict):
        e.update({k: roh[k] for k in STANDARD if k in roh})
    e["sponsorblock"] = e["sponsorblock"] is not False
    kanaele = []
    for k in e["kanaele"] if isinstance(e["kanaele"], list) else []:
        if isinstance(k, dict) and _KANAL.match(str(k.get("id", ""))):
            kanal = {"id": k["id"], "name": str(k.get("name") or k["id"])[:100]}
            if _KANALBILD.match(str(k.get("bild") or "")):
                kanal["bild"] = k["bild"]
            kategorie = " ".join(str(k.get("kategorie") or "").split())[:20]
            if kategorie:
                kanal["kategorie"] = kategorie
            kanaele.append(kanal)
    if len(kanaele) > MAX_KANAELE:
        raise YoutubeFehler("Höchstens %d Kanäle" % MAX_KANAELE)
    e["kanaele"] = kanaele
    return e


def _holen(url, kopf=None, zeit=20):
    anfrage = urllib.request.Request(url, headers=dict({"User-Agent": "Mozilla/5.0 " + USER_AGENT,
                                                        "Accept-Language": "de-DE,de;q=0.9"}, **(kopf or {})))
    with urllib.request.urlopen(anfrage, timeout=zeit) as a:
        return a.read(4 * 1024 * 1024).decode("utf-8", "replace")


def _ytdlp(optionen):
    try:
        from yt_dlp import YoutubeDL
    except Exception:
        raise YoutubeFehler("Für YouTube fehlt yt-dlp (pip install yt-dlp; in der App eingebaut)")
    from . import sicherheit
    proxy = sicherheit.NETZWEG.ytdlp_proxy()
    basis = {"quiet": True, "no_warnings": True, "skip_download": True}
    if proxy:
        basis["proxy"] = proxy
    return YoutubeDL(dict(basis, **optionen))


def bild(video_id):
    return "https://i.ytimg.com/vi/%s/hqdefault.jpg" % video_id


def _video(e):
    vid = str(e.get("id") or "")
    return {"id": vid, "titel": str(e.get("title") or ""), "kanal": str(e.get("channel") or e.get("uploader") or ""),
            "kanal_id": str(e.get("channel_id") or ""), "dauer": int(e.get("duration") or 0),
            "aufrufe": int(e.get("view_count") or 0), "bild": bild(vid), "datum": "",
            "live": e.get("live_status") == "is_live"}


class Youtube:
    def __init__(self, einstellung=None, speichern=None, holen=None):
        self.einstellung = pruefe(einstellung)
        self._speichern = speichern
        self.holen = holen or _holen
        self._sperre = threading.Lock()
        self._adressen = {}  # video_id -> (zeit, ergebnis)
        self._live_sperre = threading.Lock()
        self._live = None  # (zeit, ergebnis)
        self._shorts_sperre = threading.Lock()
        self._shorts = None  # (zeit, ergebnis)

    def _sichern(self):
        if self._speichern:
            self._speichern(dict(self.einstellung))

    # --- Suche und Feed ------------------------------------------------------------------------
    def suchen(self, text, anzahl=30):
        text = " ".join(str(text or "").split())[:150]
        if len(text) < 2:
            raise YoutubeFehler("Suchbegriff zu kurz")
        with _ytdlp({"extract_flat": True}) as y:
            try:
                info = y.extract_info("ytsearch%d:%s" % (max(1, min(60, anzahl)), text), download=False)
            except Exception as fehler:
                raise YoutubeFehler("YouTube-Suche fehlgeschlagen: %s" % str(fehler)[:200])
        return [_video(e) for e in info.get("entries") or [] if e and _KENNUNG.match(str(e.get("id", "")))]

    def _feed(self, kanal):
        roh = self.holen(FEED % kanal["id"])
        wurzel = ET.fromstring(roh)
        videos = []
        for eintrag in wurzel.findall("a:entry", _NS):
            vid = eintrag.findtext("yt:videoId", "", _NS)
            gruppe = eintrag.find("m:group", _NS)
            aufrufe = 0
            if gruppe is not None:
                stat = gruppe.find("m:community/m:statistics", _NS)
                aufrufe = int(stat.get("views") or 0) if stat is not None else 0
            if _KENNUNG.match(vid):
                videos.append({"id": vid, "titel": eintrag.findtext("a:title", "", _NS), "kanal": kanal["name"],
                               "kanal_id": kanal["id"], "dauer": 0, "aufrufe": aufrufe, "bild": bild(vid),
                               "datum": eintrag.findtext("a:published", "", _NS)[:16].replace("T", " "), "live": False})
        return videos

    def feed(self, anzahl=60):
        """Neueste Videos aller abonnierten Kanaele."""
        kanaele = list(self.einstellung["kanaele"])
        if not kanaele:
            return {"videos": [], "fehler": []}
        fehler = []

        def eins(k):
            try:
                return self._feed(k)
            except Exception as f:
                fehler.append({"kanal": k["name"], "fehler": str(f)[:120]})
                return []
        with ThreadPoolExecutor(max_workers=min(8, len(kanaele))) as pool:
            alle = [v for liste in pool.map(eins, kanaele) for v in liste]
        alle.sort(key=lambda v: v["datum"], reverse=True)
        neueste = {}  # je Kanal das Datum des neuesten Videos, auch wenn es unter den ersten `anzahl` nicht mehr steht
        for v in alle:
            neueste.setdefault(v["kanal_id"], v["datum"])
        return {"videos": alle[:anzahl], "fehler": fehler, "neueste": neueste}

    # --- Live (YT6) ------------------------------------------------------------------------------
    def _live_flach(self, kanal):
        """Billige Pruefung, ob der Kanal gerade live ist: liefert die Video-Kennung oder "". Wirft nie -
        ein nicht lebender/gesperrter/unerreichbarer Kanal zaehlt wie "nicht live", kein Fehler nach aussen."""
        try:
            with _ytdlp({"extract_flat": True, "socket_timeout": NETZ_ZEITGRENZE}) as y:
                info = y.extract_info("https://www.youtube.com/channel/%s/live" % kanal["id"], download=False)
        except Exception:
            return ""
        vid = str((info or {}).get("id") or "")
        return vid if _KENNUNG.match(vid) else ""

    def _live_voll(self, video_id, kanal):
        """Volle Extraktion NUR fuer einen bereits als live erkannten Kanal (Titel, Bild, Zuschauerzahl
        falls yt-dlp sie liefert - niemals erfunden, siehe YT0). None, wenn die Sendung inzwischen vorbei ist."""
        try:
            with _ytdlp({"socket_timeout": NETZ_ZEITGRENZE}) as y:
                info = y.extract_info("https://www.youtube.com/watch?v=" + video_id, download=False)
        except Exception:
            return None
        if (info or {}).get("live_status") != "is_live":
            return None
        return {"id": video_id, "titel": str(info.get("title") or ""), "kanal": kanal["name"],
                "kanal_id": kanal["id"], "bild": bild(video_id), "dauer": 0, "live": True,
                "zuschauer": info.get("concurrent_view_count")}

    def live(self, erzwingen=False):
        """{"live": [...], "geprueft": n, "fehler": [...], "zeit": t} - 5 Minuten zwischengespeichert, nur
        auf Zuruf geprueft (Reiter oeffnen/"Neu pruefen"), kein Hintergrundlauf (Ressourcenverbrauch)."""
        if not erzwingen:
            with self._live_sperre:
                if self._live and time.time() - self._live[0] < LIVE_ZEIT:
                    return self._live[1]
        kanaele = list(self.einstellung["kanaele"])[:MAX_LIVE_KANAELE]
        fehler = []

        def eins(k):
            try:
                vid = self._live_flach(k)
                return self._live_voll(vid, k) if vid else None
            except Exception as f:
                fehler.append({"kanal": k["name"], "fehler": str(f)[:120]})
                return None
        pool = ThreadPoolExecutor(max_workers=min(8, len(kanaele) or 1))
        try:
            aufgaben = [pool.submit(eins, k) for k in kanaele]
            fertig, _ = wait(aufgaben, timeout=GESAMT_ZEITGRENZE)
            treffer = [f.result() for f in fertig if f.result()]
        finally:
            pool.shutdown(wait=False)  # noch laufende Pruefungen enden fuer sich, blockieren die Antwort nicht laenger
        treffer.sort(key=lambda v: -(v.get("zuschauer") or 0))
        ergebnis = {"live": treffer, "geprueft": len(fertig), "fehler": fehler, "zeit": time.time()}
        with self._live_sperre:
            self._live = (time.time(), ergebnis)
        return ergebnis

    # --- Shorts (YT7) ------------------------------------------------------------------------------
    def _kanal_shorts(self, kanal):
        """Bis zu MAX_SHORTS_JE_KANAL Shorts eines Kanals (dessen /shorts-Tab, flach - wie suchen()).
        Wirft nie - ein Kanal ohne Shorts-Tab zaehlt wie "keine Shorts", kein Fehler nach aussen."""
        try:
            with _ytdlp({"extract_flat": True, "playlistend": MAX_SHORTS_JE_KANAL, "socket_timeout": NETZ_ZEITGRENZE}) as y:
                info = y.extract_info("https://www.youtube.com/channel/%s/shorts" % kanal["id"], download=False)
        except Exception:
            return []
        videos = []
        for e in (info or {}).get("entries") or []:
            vid = str((e or {}).get("id") or "") if isinstance(e, dict) else ""
            if _KENNUNG.match(vid):
                videos.append({"id": vid, "titel": str(e.get("title") or ""), "kanal": kanal["name"],
                               "kanal_id": kanal["id"], "dauer": int(e.get("duration") or 0),
                               "aufrufe": int(e.get("view_count") or 0), "bild": bild(vid), "datum": "", "live": False})
            if len(videos) >= MAX_SHORTS_JE_KANAL:
                break
        return videos

    def shorts(self, erzwingen=False):
        """{"videos": [...], "fehler": [...], "zeit": t} - 30 Minuten zwischengespeichert, wie live()."""
        if not erzwingen:
            with self._shorts_sperre:
                if self._shorts and time.time() - self._shorts[0] < SHORTS_ZEIT:
                    return self._shorts[1]
        kanaele = list(self.einstellung["kanaele"])[:MAX_SHORTS_KANAELE]
        fehler = []

        def eins(k):
            try:
                return self._kanal_shorts(k)
            except Exception as f:
                fehler.append({"kanal": k["name"], "fehler": str(f)[:120]})
                return []
        pool = ThreadPoolExecutor(max_workers=min(8, len(kanaele) or 1))
        try:
            aufgaben = [pool.submit(eins, k) for k in kanaele]
            fertig, _ = wait(aufgaben, timeout=GESAMT_ZEITGRENZE)
            alle = [v for f in fertig for v in f.result()]
        finally:
            pool.shutdown(wait=False)
        ergebnis = {"videos": alle, "fehler": fehler, "zeit": time.time()}
        with self._shorts_sperre:
            self._shorts = (time.time(), ergebnis)
        return ergebnis

    # --- Kanaele ---------------------------------------------------------------------------------
    def kanal_finden(self, eingabe):
        """UC-Kennung, Kanal-Adresse, @Name oder Video-Adresse -> {"id", "name"}."""
        eingabe = str(eingabe or "").strip()
        if not eingabe:
            raise YoutubeFehler("Kanal fehlt")
        m = re.search(r"(UC[\w-]{22})", eingabe)
        if m and ("/channel/" in eingabe or _KANAL.match(eingabe)):
            kid = m.group(1)
            seite = None
        else:
            if eingabe.startswith("@"):
                url = "https://www.youtube.com/" + quote(eingabe)
            elif eingabe.lower().startswith(("http://", "https://")) and re.search(r"(^|\.)youtube\.com/|youtu\.be/", eingabe):
                url = eingabe
            elif re.match(r"^[\w.-]{3,30}$", eingabe):
                url = "https://www.youtube.com/@" + quote(eingabe)
            else:
                raise YoutubeFehler("Bitte Kanal-Adresse, @Name oder UC-Kennung angeben")
            try:
                seite = self.holen(url, _KEKS)
            except Exception as fehler:
                raise YoutubeFehler("Kanal nicht gefunden: %s" % fehler)
            m = re.search(r'"(?:channelId|externalId|browseId)":"(UC[\w-]{22})"', seite) or \
                re.search(r'youtube\.com/channel/(UC[\w-]{22})', seite)
            if not m:
                raise YoutubeFehler("Keine Kanal-Kennung auf der Seite gefunden")
            kid = m.group(1)
        name = kid
        try:
            titel = ET.fromstring(self.holen(FEED % kid)).findtext("a:title", "", _NS)
            name = titel or name
        except Exception:
            if seite:
                og = re.search(r'<meta property="og:title" content="([^"]+)"', seite)
                name = og.group(1) if og else name
        kanal = {"id": kid, "name": name[:100]}
        bild_ = self._kanalbild(kid, seite)
        if bild_:
            kanal["bild"] = bild_
        return kanal

    def _kanalbild(self, kanal_id, seite=None):
        """Adresse des Kanalbilds aus der Kanalseite (og:image) oder "". Wirft nicht."""
        try:
            seite = seite or self.holen("https://www.youtube.com/channel/" + kanal_id, _KEKS)
        except Exception:
            return ""
        m = re.search(r'<meta property="og:image" content="([^"]+)"', seite)
        return m.group(1) if m and _KANALBILD.match(m.group(1)) else ""

    def kanalbilder(self, hoechstens=12):
        """Holt fuer Abos ohne Bild das Kanalbild nach (aeltere Abos haben keins). Gibt die Zahl der neuen Bilder zurueck."""
        ohne = [k["id"] for k in self.einstellung["kanaele"] if not k.get("bild")][:hoechstens]
        if not ohne:
            return 0
        with ThreadPoolExecutor(max_workers=min(8, len(ohne))) as pool:
            gefunden = {kid: b for kid, b in zip(ohne, pool.map(self._kanalbild, ohne)) if b}
        if gefunden:
            with self._sperre:
                self.einstellung = pruefe(dict(self.einstellung, kanaele=[
                    dict(k, bild=gefunden[k["id"]]) if k["id"] in gefunden else k for k in self.einstellung["kanaele"]]))
            self._sichern()
        return len(gefunden)

    def kategorie_setzen(self, kanal_id, kategorie):
        """Eigene Kategorie eines Abos (z. B. "Musik"); leer loescht sie. Daraus entstehen die Pillen der Startseite."""
        with self._sperre:
            if not any(k["id"] == kanal_id for k in self.einstellung["kanaele"]):
                raise YoutubeFehler("Kanal ist nicht abonniert")
            self.einstellung = pruefe(dict(self.einstellung, kanaele=[
                dict(k, kategorie=kategorie) if k["id"] == kanal_id else k for k in self.einstellung["kanaele"]]))
        self._sichern()

    def abonnieren(self, eingabe):
        kanal = self.kanal_finden(eingabe)
        with self._sperre:
            if not any(k["id"] == kanal["id"] for k in self.einstellung["kanaele"]):
                self.einstellung = pruefe(dict(self.einstellung, kanaele=self.einstellung["kanaele"] + [kanal]))
        self._sichern()
        return kanal

    def abbestellen(self, kanal_id):
        with self._sperre:
            self.einstellung = pruefe(dict(self.einstellung, kanaele=[k for k in self.einstellung["kanaele"]
                                                                      if k["id"] != kanal_id]))
        self._sichern()

    def einstellen(self, daten):
        with self._sperre:
            self.einstellung = pruefe(dict(self.einstellung, **{k: v for k, v in daten.items() if k == "sponsorblock"}))
        self._sichern()

    # --- Abspielen -------------------------------------------------------------------------------
    def adresse(self, video_id):
        """{"url", "hls", "titel", "kanal", "dauer", "bild", "kopf"} (zwischengespeichert, solange gueltig)."""
        if not _KENNUNG.match(str(video_id or "")):
            raise YoutubeFehler("Ungültige Video-Kennung")
        with self._sperre:
            alt = self._adressen.get(video_id)
        if alt and time.time() - alt[0] < ABLAUF:
            return alt[1]
        with _ytdlp({}) as y:
            try:
                info = y.extract_info("https://www.youtube.com/watch?v=" + video_id, download=False)
            except Exception as fehler:
                raise YoutubeFehler("Video nicht abspielbar: %s" % str(fehler)[:200])
        formate = info.get("formats") or []
        hls = [f for f in formate if "m3u8" in (f.get("protocol") or "") and f.get("manifest_url")]
        gemischt = [f for f in formate if f.get("vcodec") not in (None, "none") and f.get("acodec") not in (None, "none")
                    and f.get("url") and "m3u8" not in (f.get("protocol") or "")]
        if hls:
            url, ist_hls, kopf = hls[0]["manifest_url"], True, hls[0].get("http_headers") or {}
        elif gemischt:
            f = sorted(gemischt, key=lambda f: f.get("height") or 0)[-1]
            url, ist_hls, kopf = f["url"], False, f.get("http_headers") or {}
        elif info.get("manifest_url"):
            url, ist_hls, kopf = info["manifest_url"], True, info.get("http_headers") or {}
        else:
            raise YoutubeFehler("YouTube liefert für dieses Video keine abspielbare Fassung")
        ergebnis = {"url": url, "hls": ist_hls, "titel": info.get("title") or "", "kanal": info.get("channel") or "",
                    "kanal_id": info.get("channel_id") or "", "dauer": int(info.get("duration") or 0),
                    "bild": bild(video_id), "live": info.get("live_status") == "is_live",
                    "kopf": {k: v for k, v in kopf.items() if k.lower() in ("user-agent", "referer", "origin")}}
        with self._sperre:
            self._adressen[video_id] = (time.time(), ergebnis)
            for k in [k for k, (t, _) in self._adressen.items() if time.time() - t > ABLAUF]:
                del self._adressen[k]
        return ergebnis

    def sponsorblock(self, video_id):
        """[[anfang, ende, art], ...] in Sekunden; leer, wenn nichts gemeldet ist oder es aus ist."""
        if not self.einstellung["sponsorblock"] or not _KENNUNG.match(str(video_id or "")):
            return []
        try:
            roh = self.holen(SPONSORBLOCK % (video_id, quote(json.dumps(SB_KATEGORIEN))), zeit=8)
        except urllib.error.HTTPError as fehler:
            if fehler.code == 404:
                return []
            raise
        except Exception as fehler:
            log.info("SponsorBlock: %s", fehler)
            return []
        segmente = []
        for s in json.loads(roh):
            try:
                anfang, ende = float(s["segment"][0]), float(s["segment"][1])
            except (KeyError, ValueError, TypeError, IndexError):
                continue
            if ende - anfang >= 1:
                segmente.append([round(anfang, 2), round(ende, 2), SB_NAMEN.get(s.get("category"), s.get("category", ""))])
        return sorted(segmente)


