"""YouTube-Quellen fuer die eigenen Reihen: Kanal-Abos und Playlists per RSS, Suche mit eigenem API-Schluessel.

  * Kanal (@Name, Kanal-Adresse, UC-Kennung) und Playlist (list=PL..., Playlist-Adresse oder Kennung) werden zu einer
    Reihe, die ihre neuesten Videos aus dem oeffentlichen Feed holt: youtube.com/feeds/videos.xml?channel_id=… bzw.
    ?playlist_id=… (ohne Schluessel, ohne Konto; die Feeds liefern die neuesten ~15 Videos). Gespeichert wird nur die
    Kennung, die Videos kommen frisch (15 Minuten Zwischenspeicher, hoechstens 100 Eintraege).
  * Kinderprofile: Reihen aendern kann nur, wer die Eltern-PIN hat (kinder.MIT_FREIGABE); ein Kind spielt nur Videos
    aus den so freigegebenen Reihen. Fuer Quellen-Reihen zaehlen die zuletzt gezeigten Feed-Videos (auch abgelaufene
    Eintraege bis 24 Stunden), nie ein beliebiges Video.
  * Suche: mit einem eigenen YouTube-Data-API-Schluessel (Nutzerdaten "youtube_api", nur im Server, nie in Antworten
    oder Fehlermeldungen) ueber search.list; ohne Schluessel bleibt die bisherige Suche ueber yt-dlp.
Kein Werbeblocker, kein Download, keine Umgehung – abgespielt wird ueber den vorhandenen YouTube-Weg.
"""

import json
import re
import threading
import time
import xml.etree.ElementTree as ET
from urllib.parse import quote, urlencode, urlsplit, parse_qs

SCHLUESSEL = "youtube_api"
FEED = "https://www.youtube.com/feeds/videos.xml?%s=%s"
API_SUCHE = "https://www.googleapis.com/youtube/v3/search?"
FRISCH, BEHALTEN, MAX_CACHE, MAX_VIDEOS = 900, 86400, 100, 30
_NS = {"a": "http://www.w3.org/2005/Atom", "yt": "http://www.youtube.com/xml/schemas/2015"}
_KANAL = re.compile(r"^UC[\w-]{22}$")
_LISTE = re.compile(r"^(?:PL|UU|FL|OLAK5uy_|LL|RD)[\w-]{10,60}$")
_VIDEO = re.compile(r"^[\w-]{11}$")
_HOSTS = {"youtube.com", "www.youtube.com", "m.youtube.com", "music.youtube.com"}


class QuellenFehler(ValueError):
    pass


def playlist_id_aus(text):
    """Playlist-Adresse (…/playlist?list=PL…, auch watch?v=…&list=PL…) oder nackte Kennung -> Kennung, sonst None."""
    roh = " ".join(str(text or "").split())
    if _LISTE.match(roh):
        return roh
    try:
        t = urlsplit(roh)
    except ValueError:
        return None
    if t.scheme not in ("http", "https") or (t.hostname or "").lower() not in _HOSTS:
        return None
    kennung = (parse_qs(t.query).get("list") or [""])[0]
    return kennung if _LISTE.match(kennung) else None


def feed_adresse(art, kennung):
    if art == "kanal" and _KANAL.match(kennung):
        return FEED % ("channel_id", kennung)
    if art == "playlist" and _LISTE.match(kennung):
        return FEED % ("playlist_id", kennung)
    raise QuellenFehler("Unbekannte Quelle")


def feed_lesen(text, bild):
    """Atom-Feed -> (Titel, [{"id","titel","kanal","bild"}]); bild(vid) liefert die Vorschau-Adresse."""
    try:
        wurzel = ET.fromstring(text)
    except ET.ParseError:
        raise QuellenFehler("Der YouTube-Feed ist unlesbar")
    videos = []
    for e in wurzel.findall("a:entry", _NS):
        vid = e.findtext("yt:videoId", "", _NS)
        if not _VIDEO.match(vid):
            continue
        autor = e.find("a:author", _NS)
        kanal = autor.findtext("a:name", "", _NS) if autor is not None else ""
        videos.append({"id": vid, "titel": " ".join((e.findtext("a:title", "", _NS) or "").split())[:200] or "YouTube-Video " + vid,
                       "kanal": " ".join(kanal.split())[:80], "bild": bild(vid)})
        if len(videos) >= MAX_VIDEOS:
            break
    return " ".join((wurzel.findtext("a:title", "", _NS) or "").split())[:100], videos


class Zwischenspeicher:
    """(art, kennung) -> (Zeit, Videos). Abgelaufene Eintraege bleiben als Freigabe-Nachweis (BEHALTEN) erhalten."""

    def __init__(self, uhr=time.time):
        self.uhr, self._d, self._sperre = uhr, {}, threading.Lock()

    def holen(self, art, kennung, frisch=True):
        with self._sperre:
            e = self._d.get((art, kennung))
        if not e:
            return None
        alter = self.uhr() - e[0]
        return e[1] if alter <= (FRISCH if frisch else BEHALTEN) else None

    def setzen(self, art, kennung, videos):
        with self._sperre:
            jetzt = self.uhr()
            for k in [k for k, (t, _) in self._d.items() if jetzt - t > BEHALTEN]:
                del self._d[k]
            while len(self._d) >= MAX_CACHE:
                self._d.pop(next(iter(self._d)))
            self._d[(art, kennung)] = (jetzt, list(videos))


SPEICHER = Zwischenspeicher()


def videos_holen(art, kennung, holen, bild, speicher=None):
    """Neueste Videos einer Quelle; bei Netzfehler der letzte bekannte Stand (falls vorhanden), sonst Fehler."""
    speicher = speicher or SPEICHER
    frisch = speicher.holen(art, kennung)
    if frisch is not None:
        return frisch
    try:
        _, videos = feed_lesen(holen(feed_adresse(art, kennung)), bild)
    except QuellenFehler:
        raise
    except Exception as fehler:  # Netz, HTTP 404 (Playlist weg/privat) u. a.
        alt = speicher.holen(art, kennung, frisch=False)
        if alt is not None:
            return alt
        raise QuellenFehler("Feed nicht ladbar: %s" % str(fehler)[:120])
    speicher.setzen(art, kennung, videos)
    return videos


def quellen_enthalten(reihen, vid, speicher=None):
    """Steht das Video in einer der Quellen-Reihen (zuletzt gezeigter Stand)? Fuer die Kinder-Freigabe."""
    speicher = speicher or SPEICHER
    for r in reihen:
        q = r.get("quelle")
        if q:
            videos = speicher.holen(q["art"], q["id"], frisch=False) or []
            if any(v["id"] == vid for v in videos):
                return True
    return False


# --- Suche mit eigenem API-Schluessel ---------------------------------------------------------------------
def schluessel(daten):
    return str(((daten or {}).get(SCHLUESSEL) or {}).get("api_key") or "").strip()


def schluessel_einstellen(daten, wert):
    neu = " ".join(str(wert or "").split())
    if neu and not re.match(r"^[\w-]{20,80}$", neu):
        raise QuellenFehler("Das sieht nicht wie ein YouTube-API-Schlüssel aus (nur Buchstaben, Ziffern, - und _)")
    daten[SCHLUESSEL] = {"api_key": neu}
    return {"gesetzt": bool(neu)}


def suchen_api(text, api_key, holen, anzahl=25, bild=None):
    """search.list (Videos). Fehlertexte enthalten nie den Schluessel."""
    text = " ".join(str(text or "").split())[:150]
    if len(text) < 2:
        raise QuellenFehler("Suchbegriff zu kurz")
    if not api_key:
        raise QuellenFehler("Kein YouTube-API-Schlüssel eingetragen")
    adresse = API_SUCHE + urlencode({"part": "snippet", "type": "video", "maxResults": max(1, min(50, anzahl)), "q": text,
                                     "safeSearch": "moderate", "key": api_key})
    try:
        roh = holen(adresse)
        d = json.loads(roh)
    except Exception as fehler:
        raise QuellenFehler("YouTube-Suche fehlgeschlagen: %s" % str(fehler).replace(api_key, "<Schlüssel>")[:160])
    if not isinstance(d, dict):
        raise QuellenFehler("YouTube-Suche: unerwartete Antwort")
    if d.get("error"):
        grund = str(((d["error"].get("errors") or [{}])[0] or {}).get("reason") or d["error"].get("message") or "Fehler")
        raise QuellenFehler("YouTube-Suche abgelehnt (%s) – Schlüssel und Kontingent in der Google Cloud Console prüfen" % grund.replace(api_key, "<Schlüssel>")[:80])
    bild = bild or (lambda vid: "https://i.ytimg.com/vi/%s/hqdefault.jpg" % quote(vid))
    ergebnis = []
    for e in d.get("items") or []:
        vid = str(((e or {}).get("id") or {}).get("videoId") or "")
        s = (e or {}).get("snippet") or {}
        if _VIDEO.match(vid):
            ergebnis.append({"id": vid, "titel": " ".join(str(s.get("title") or "").split())[:200], "kanal": str(s.get("channelTitle") or "")[:80],
                             "kanal_id": str(s.get("channelId") or ""), "dauer": 0, "aufrufe": 0, "bild": bild(vid),
                             "datum": str(s.get("publishedAt") or "")[:16].replace("T", " "), "live": s.get("liveBroadcastContent") == "live"})
    return ergebnis
