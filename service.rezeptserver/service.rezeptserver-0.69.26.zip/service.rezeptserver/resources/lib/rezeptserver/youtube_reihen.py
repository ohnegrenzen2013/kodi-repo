"""Eigene YouTube-Reihen (ARVIO 2.3): einzelne Videos per Link in benannte Reihen, je Profil, auf der Startseite.

  * Link-Erkennung: youtu.be/ID, youtube.com/watch?v=ID, /shorts/ID, /embed/ID, /live/ID, /v/ID (auch m., music.,
    youtube-nocookie.com). Playlists, Kanaele und Suchseiten sind keine einzelnen Videos und werden abgelehnt.
  * Titel, Kanal und Vorschaubild kommen per oEmbed (youtube.com/oembed). Antwortet oEmbed nicht, bleibt das Video
    mit der Standard-Vorschau (i.ytimg.com) nutzbar; fremde Bildadressen werden nie uebernommen.
  * Abspielen laeuft ueber den vorhandenen YouTube-Weg (POST /api/youtube/abspielen), die Reihen speichern nur Kennungen.
Nutzerdaten: "youtube_reihen": {profil-id oder "": [{"id", "name", "videos": [{"id", "titel", "kanal", "bild"}]}]}
"""

import json
import re
import secrets
from urllib.parse import parse_qs, quote, urlsplit

from . import youtube_quellen

SCHLUESSEL = "youtube_reihen"
MAX_REIHEN, MAX_VIDEOS, MAX_NAME, MAX_TITEL = 20, 100, 60, 200
_KENNUNG = re.compile(r"^[A-Za-z0-9_-]{11}$")
_HOSTS = {"youtube.com", "www.youtube.com", "m.youtube.com", "music.youtube.com", "youtube-nocookie.com", "www.youtube-nocookie.com"}
_PFAD = re.compile(r"^/(?:shorts|embed|live|v)/([A-Za-z0-9_-]{11})/?$")
_BILD = re.compile(r"^https://i\d?\.ytimg\.com/[\w./-]+$")


class ReihenFehler(ValueError):
    pass


def video_id_aus(text):
    """Einzelvideo-Link -> 11-stellige Kennung, sonst None."""
    roh = " ".join(str(text or "").split())
    if not roh:
        return None
    if not re.match(r"^[a-z][a-z0-9+.-]*://", roh, re.I):
        if re.match(r"^[a-z][a-z0-9+.-]*:", roh, re.I) and not re.match(r"^[\w.-]+:\d+", roh):
            return None  # javascript:, mailto: …
        roh = "https://" + roh
    try:
        u = urlsplit(roh)
        host = (u.hostname or "").lower()
    except ValueError:
        return None
    if u.scheme not in ("http", "https"):
        return None
    if host == "youtu.be":
        m = re.match(r"^/([A-Za-z0-9_-]{11})/?$", u.path)
        return m.group(1) if m else None
    if host not in _HOSTS:
        return None
    if u.path.rstrip("/") == "/watch":
        v = (parse_qs(u.query).get("v") or [""])[0]
        return v if _KENNUNG.match(v) else None
    m = _PFAD.match(u.path)
    return m.group(1) if m else None


def standard_bild(vid):
    return "https://i.ytimg.com/vi/%s/hqdefault.jpg" % vid


def _text(roh, grenze):
    return " ".join(str(roh or "").split())[:grenze]


def oembed(vid, holen):
    """{titel, kanal, bild} per oEmbed; holen(url) -> Text. Faellt bei jedem Fehler auf Standardwerte zurueck."""
    standard = {"titel": "YouTube-Video " + vid, "kanal": "", "bild": standard_bild(vid)}
    url = "https://www.youtube.com/oembed?" + "url=%s&format=json" % quote("https://www.youtube.com/watch?v=" + vid, safe="")
    try:
        d = json.loads(holen(url))
    except Exception:  # noqa: BLE001 - nie am Netz scheitern: das Video bleibt nutzbar
        return standard
    if not isinstance(d, dict):
        return standard
    bild = str(d.get("thumbnail_url") or "")
    return {"titel": _text(d.get("title"), MAX_TITEL) or standard["titel"], "kanal": _text(d.get("author_name"), 80),
            "bild": bild if _BILD.match(bild) else standard["bild"]}


# --- Reihen -------------------------------------------------------------------------------------
def _alle(daten):
    d = daten.get(SCHLUESSEL) if isinstance(daten.get(SCHLUESSEL), dict) else {}
    daten[SCHLUESSEL] = d
    return d


def _liste(daten, profil):
    d = _alle(daten)
    liste = d.get(profil or "") if isinstance(d.get(profil or ""), list) else []
    d[profil or ""] = liste
    return liste


def _video_sauber(v):
    if not isinstance(v, dict) or not _KENNUNG.match(str(v.get("id") or "")):
        return None
    bild = str(v.get("bild") or "")
    return {"id": v["id"], "titel": _text(v.get("titel"), MAX_TITEL) or "YouTube-Video " + v["id"], "kanal": _text(v.get("kanal"), 80),
            "bild": bild if _BILD.match(bild) else standard_bild(v["id"])}


def _reihe_sauber(r):
    if not isinstance(r, dict) or not isinstance(r.get("id"), str) or not r.get("id"):
        return None
    q = r.get("quelle") if isinstance(r.get("quelle"), dict) else None
    quelle = {"art": q["art"], "id": q["id"]} if q and (q.get("art") == "kanal" and youtube_quellen._KANAL.match(str(q.get("id") or ""))
                                                       or q.get("art") == "playlist" and youtube_quellen._LISTE.match(str(q.get("id") or ""))) else None
    ergebnis = {"id": r["id"], "name": _text(r.get("name"), MAX_NAME) or "Reihe",
                "videos": [x for x in (_video_sauber(v) for v in (r.get("videos") if isinstance(r.get("videos"), list) else [])) if x]}
    if quelle:
        ergebnis["quelle"] = quelle  # Videos kommen dann frisch aus dem Feed (oberflaeche_reihen.py), nie aus der Ablage
        ergebnis["videos"] = []
    return ergebnis


def lesen(daten, profil):
    """Die Reihen eines Profils, bereinigt (kaputte Eintraege fallen weg, Bilder nur von i.ytimg.com)."""
    roh = (daten.get(SCHLUESSEL) or {}).get(profil or "") if isinstance(daten.get(SCHLUESSEL), dict) else None
    return [x for x in (_reihe_sauber(r) for r in (roh if isinstance(roh, list) else [])) if x]


def enthaelt(daten, profil, vid):
    reihen = lesen(daten, profil)
    return any(v["id"] == vid for r in reihen for v in r["videos"]) or youtube_quellen.quellen_enthalten(reihen, vid)


def _finden(daten, profil, rid):
    r = next((r for r in _liste(daten, profil) if isinstance(r, dict) and r.get("id") == rid), None)
    if r is None:
        raise ReihenFehler("Reihe nicht gefunden")
    r.setdefault("videos", [])
    return r


def _name(roh):
    name = _text(roh, MAX_NAME)
    if not name:
        raise ReihenFehler("Name der Reihe fehlt")
    return name


def neu(daten, profil, name):
    liste = _liste(daten, profil)
    name = _name(name)
    if len(liste) >= MAX_REIHEN:
        raise ReihenFehler("Höchstens %d Reihen" % MAX_REIHEN)
    r = {"id": secrets.token_hex(4), "name": name, "videos": []}
    liste.append(r)
    return dict(r)


def quelle_dazu(daten, profil, art, kennung, name):
    """Reihe aus einem Kanal (art "kanal", UC-Kennung) oder einer Playlist (art "playlist"). Dieselbe Quelle nur einmal je Profil."""
    if art == "kanal" and not youtube_quellen._KANAL.match(str(kennung)):
        raise ReihenFehler("Keine gültige Kanal-Kennung")
    if art == "playlist" and not youtube_quellen._LISTE.match(str(kennung)):
        raise ReihenFehler("Keine gültige Playlist-Kennung")
    if art not in ("kanal", "playlist"):
        raise ReihenFehler("Unbekannte Quelle")
    liste = _liste(daten, profil)
    if any(isinstance(r, dict) and (r.get("quelle") or {}).get("id") == kennung for r in liste):
        raise ReihenFehler("Diese Quelle ist schon als Reihe angelegt")
    if len(liste) >= MAX_REIHEN:
        raise ReihenFehler("Höchstens %d Reihen" % MAX_REIHEN)
    r = {"id": secrets.token_hex(4), "name": _name(name), "videos": [], "quelle": {"art": art, "id": kennung}}
    liste.append(r)
    return {"id": r["id"], "name": r["name"], "videos": [], "quelle": dict(r["quelle"])}


def umbenennen(daten, profil, rid, name):
    _finden(daten, profil, rid)["name"] = _name(name)


def weg(daten, profil, rid):
    liste = _liste(daten, profil)
    r = _finden(daten, profil, rid)
    liste.remove(r)


def reihe_verschieben(daten, profil, rid, nach):
    liste = _liste(daten, profil)
    r = _finden(daten, profil, rid)
    liste.remove(r)
    liste.insert(max(0, min(int(nach), len(liste))), r)


def video_dazu(daten, profil, rid, link, info):
    """Einzelvideo hinzufuegen; info = {titel, kanal, bild} (oembed). Gibt das gespeicherte Video zurueck."""
    vid = video_id_aus(link)
    if not vid:
        raise ReihenFehler("Das ist kein Link zu einem einzelnen YouTube-Video (youtu.be, watch?v=, shorts, embed)")
    r = _finden(daten, profil, rid)
    if r.get("quelle"):
        raise ReihenFehler("Diese Reihe kommt von einem Kanal oder einer Playlist; einzelne Videos lassen sich dort nicht ergänzen")
    if any(isinstance(v, dict) and v.get("id") == vid for v in r["videos"]):
        raise ReihenFehler("Das Video ist schon in dieser Reihe")
    if len(r["videos"]) >= MAX_VIDEOS:
        raise ReihenFehler("Höchstens %d Videos je Reihe" % MAX_VIDEOS)
    v = _video_sauber(dict(info or {}, id=vid))
    r["videos"].append(v)
    return dict(v)


def video_weg(daten, profil, rid, vid):
    r = _finden(daten, profil, rid)
    v = next((v for v in r["videos"] if isinstance(v, dict) and v.get("id") == vid), None)
    if v is None:
        raise ReihenFehler("Video nicht in der Reihe")
    r["videos"].remove(v)


def verschieben(daten, profil, rid, vid, nach):
    r = _finden(daten, profil, rid)
    v = next((v for v in r["videos"] if isinstance(v, dict) and v.get("id") == vid), None)
    if v is None:
        raise ReihenFehler("Video nicht in der Reihe")
    r["videos"].remove(v)
    r["videos"].insert(max(0, min(int(nach), len(r["videos"]))), v)
