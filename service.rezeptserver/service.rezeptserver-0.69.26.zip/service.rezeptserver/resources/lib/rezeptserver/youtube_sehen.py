"""YouTube: Verlauf, "Später ansehen", "Mag ich" und der zuletzt gesehene Stand je Kanal - je Profil (Muster livetv_sehen.py).

Ohne Google-Konto kennt YouTube diese Listen nicht; H0rSt fuehrt sie selbst. Der Stand je Kanal ("gesehen")
ist das Datum des neuesten Videos, das beim letzten Antippen des Kanals im Feed stand - daraus entsteht der
Ring um den Kanal-Kreis, sobald ein neueres Video erscheint.

Nutzerdaten "youtube_sehen": {"<profil-id oder ''>": {"verlauf": [karte], "gemerkt": [karte], "mag": [karte],
                                                        "gesehen": {kanal_id: "JJJJ-MM-TT hh:mm"}}}
karte: {"id", "titel", "kanal", "kanal_id", "dauer", "zeit"}; beim Lesen kommt "bild" dazu.
"""

import re
import time

from .youtube_grund import _KANAL, _KENNUNG
from .youtube_kanal import bild

SCHLUESSEL = "youtube_sehen"
LISTEN = ("gemerkt", "mag")
MAX_VERLAUF = 200
MAX_LISTE = 300
MAX_KANAELE = 400
_DATUM = re.compile(r"^\d{4}-\d\d-\d\d \d\d:\d\d$")


def _karte(roh, zeit=None):
    """Gepruefte Karte oder None. Das Bild folgt aus der Kennung und wird nicht gespeichert."""
    if not isinstance(roh, dict) or not _KENNUNG.match(str(roh.get("id") or "")):
        return None
    try:
        dauer = max(0, int(roh.get("dauer") or 0))
    except (TypeError, ValueError):
        dauer = 0
    try:
        wann = float(roh.get("zeit") or 0) if zeit is None else float(zeit)
    except (TypeError, ValueError):
        wann = 0.0
    kanal_id = str(roh.get("kanal_id") or "")
    return {"id": str(roh["id"]), "titel": " ".join(str(roh.get("titel") or "").split())[:200],
            "kanal": " ".join(str(roh.get("kanal") or "").split())[:100],
            "kanal_id": kanal_id if _KANAL.match(kanal_id) else "", "dauer": dauer, "zeit": wann}


def _liste(roh, grenze):
    karten, gesehen = [], set()
    for eintrag in roh if isinstance(roh, list) else []:
        k = _karte(eintrag)
        if k and k["id"] not in gesehen:
            gesehen.add(k["id"])
            karten.append(k)
        if len(karten) >= grenze:
            break
    return karten


def _eintrag(daten, profil_id):
    alle = daten.get(SCHLUESSEL) if isinstance(daten.get(SCHLUESSEL), dict) else {}
    eigen = alle.get(profil_id or "") if isinstance(alle.get(profil_id or ""), dict) else {}
    stand = eigen.get("gesehen") if isinstance(eigen.get("gesehen"), dict) else {}
    return {"verlauf": _liste(eigen.get("verlauf"), MAX_VERLAUF),
            "gemerkt": _liste(eigen.get("gemerkt"), MAX_LISTE), "mag": _liste(eigen.get("mag"), MAX_LISTE),
            "gesehen": {k: d for k, d in list(stand.items())[:MAX_KANAELE]
                        if _KANAL.match(str(k)) and isinstance(d, str) and _DATUM.match(d)}}


def _mit_bild(eintrag):
    return dict(eintrag, **{n: [dict(k, bild=bild(k["id"])) for k in eintrag[n]] for n in ("verlauf",) + LISTEN})


def lesen(daten, profil_id=""):
    """Listen dieses Profils, jede Karte mit Bild; kaputte Eintraege fallen weg."""
    return _mit_bild(_eintrag(daten if isinstance(daten, dict) else {}, profil_id))


def _speichern(daten, profil_id, eintrag):
    alle = daten.get(SCHLUESSEL) if isinstance(daten.get(SCHLUESSEL), dict) else {}
    alle[profil_id or ""] = eintrag
    daten[SCHLUESSEL] = alle
    return _mit_bild(eintrag)


def angesehen_setzen(daten, profil_id, video, jetzt=None):
    """Video vorn in den Verlauf setzen (nicht doppelt)."""
    karte = _karte(video, time.time() if jetzt is None else jetzt)
    if not karte:
        raise ValueError("Ungültige Video-Kennung")
    eintrag = _eintrag(daten, profil_id)
    eintrag["verlauf"] = ([karte] + [k for k in eintrag["verlauf"] if k["id"] != karte["id"]])[:MAX_VERLAUF]
    return _speichern(daten, profil_id, eintrag)


def liste_setzen(daten, profil_id, liste, video, an, jetzt=None):
    """Video in "gemerkt" (Später ansehen) oder "mag" (Mag ich) ein- oder austragen."""
    if liste not in LISTEN:
        raise ValueError("Unbekannte Liste")
    karte = _karte(video, time.time() if jetzt is None else jetzt)
    if not karte:
        raise ValueError("Ungültige Video-Kennung")
    eintrag = _eintrag(daten, profil_id)
    rest = [k for k in eintrag[liste] if k["id"] != karte["id"]]
    eintrag[liste] = ([karte] + rest if an else rest)[:MAX_LISTE]
    return _speichern(daten, profil_id, eintrag)


def verlauf_weg(daten, profil_id, video_id=""):
    """Ein Video aus dem Verlauf nehmen; ohne Kennung den ganzen Verlauf leeren."""
    eintrag = _eintrag(daten, profil_id)
    eintrag["verlauf"] = [k for k in eintrag["verlauf"] if k["id"] != video_id] if video_id else []
    return _speichern(daten, profil_id, eintrag)


def kanal_gesehen(daten, profil_id, kanal_id, datum):
    """Merkt das Datum des neuesten Videos, das der Nutzer bei diesem Kanal gesehen hat (nie rueckwaerts)."""
    kanal_id, datum = str(kanal_id or ""), str(datum or "")
    if not _KANAL.match(kanal_id) or not _DATUM.match(datum):
        raise ValueError("Kanal und Datum erwartet")
    eintrag = _eintrag(daten, profil_id)
    if datum > eintrag["gesehen"].get(kanal_id, ""):
        eintrag["gesehen"][kanal_id] = datum
    return _speichern(daten, profil_id, eintrag)
