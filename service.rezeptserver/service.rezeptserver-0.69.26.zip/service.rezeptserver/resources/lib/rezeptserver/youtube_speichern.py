"""Download und REC (Server): Auftraege mit yt-dlp und ffmpeg."""

from .youtube_grund import (
    MAX_TEMPO,
    MIN_TEMPO,
    ORDNER,
    YoutubeFehler,
    _KENNUNG,
    ereignisse,
    log,
    os,
    re,
    shutil,
    subprocess,
    threading,
)

from .youtube_kanal import _ytdlp

def ffmpeg():
    return shutil.which("ffmpeg")


def _atempo(tempo):
    """atempo kann je Filter 0.5..2; groessere Spruenge als Kette (z. B. 4x = 2x * 2x)."""
    teile, rest = [], tempo
    while rest > 2.0:
        teile.append(2.0)
        rest /= 2.0
    while rest < 0.5:
        teile.append(0.5)
        rest /= 0.5
    teile.append(rest)
    return ",".join("atempo=%.4f" % t for t in teile)


def dateiname(titel):
    name = re.sub(r'[\\/:*?"<>|\x00-\x1f]+', "_", str(titel or "video")).strip(" ._")[:150]
    return name or "video"


class Speichern:
    """Download- und REC-Auftraege auf dem Server (je Auftrag ein Faden)."""

    def __init__(self, datenordner):
        self.ordner = os.path.join(datenordner or ".", ORDNER)
        self.auftraege = {}
        self._nummer = 0
        self._sperre = threading.Lock()

    def starten(self, video_id, titel="", tempo=1.0):
        if not _KENNUNG.match(str(video_id or "")):
            raise YoutubeFehler("Ungültige Video-Kennung")
        try:
            tempo = round(float(tempo or 1.0), 2)
        except (TypeError, ValueError):
            raise YoutubeFehler("Tempo muss eine Zahl sein")
        if not MIN_TEMPO <= tempo <= MAX_TEMPO:
            raise YoutubeFehler("Tempo zwischen 0,25 und 4")
        if not ffmpeg():
            raise YoutubeFehler("Download und REC brauchen auf dem Server ffmpeg (YouTube liefert Bild und Ton getrennt), "
                                "z. B. apt install ffmpeg. In der App ist alles eingebaut.")
        with self._sperre:
            if sum(1 for a in self.auftraege.values() if a["laeuft"]) >= 3:
                raise YoutubeFehler("Höchstens 3 gleichzeitig")
            self._nummer += 1
            a = {"id": str(self._nummer), "video": video_id, "titel": titel or video_id, "tempo": tempo,
                 "art": "REC" if tempo != 1.0 else "Download", "status": "startet", "prozent": 0.0, "tempo_dl": 0,
                 "fehler": "", "datei": "", "laeuft": True}
            self.auftraege[a["id"]] = a
        threading.Thread(target=self._lauf, args=(a,), name="youtube-" + a["id"], daemon=True).start()
        return dict(a)

    def _lauf(self, a):
        os.makedirs(self.ordner, exist_ok=True)
        basis = dateiname(a["titel"])
        ziel = os.path.join(self.ordner, basis + (" (%sx)" % ("%g" % a["tempo"]) if a["art"] == "REC" else ""))
        try:
            def fortschritt(d):
                gesamt = d.get("total_bytes") or d.get("total_bytes_estimate") or 0
                if gesamt:
                    a["prozent"] = round(90.0 * d.get("downloaded_bytes", 0) / gesamt if a["art"] == "REC"
                                         else 100.0 * d.get("downloaded_bytes", 0) / gesamt, 1)
                a["tempo_dl"] = int(d.get("speed") or 0)
                a["status"] = "lädt"
            optionen = {"outtmpl": ziel + ".%(ext)s", "progress_hooks": [fortschritt], "noplaylist": True,
                        "format": "bv*[height<=1080]+ba/b", "merge_output_format": "mp4",
                        "ffmpeg_location": ffmpeg()}
            with _ytdlp(optionen) as y:
                info = y.extract_info("https://www.youtube.com/watch?v=" + a["video"], download=True)
                datei = y.prepare_filename(info)
            if not os.path.exists(datei):
                datei = os.path.splitext(datei)[0] + ".mp4"
            if a["art"] == "REC":
                a["status"] = "rechnet um"
                aus = ziel + ".mp4"
                temp = ziel + ".neu.mp4"
                befehl = [ffmpeg(), "-y", "-loglevel", "error", "-i", datei, "-filter_complex",
                          "[0:v]setpts=PTS/%.4f[v];[0:a]%s[a]" % (a["tempo"], _atempo(a["tempo"])),
                          "-map", "[v]", "-map", "[a]", "-c:v", "libx264", "-preset", "veryfast", "-crf", "22",
                          "-c:a", "aac", "-b:a", "160k", "-movflags", "+faststart", temp]
                ergebnis = subprocess.run(befehl, capture_output=True, text=True)
                if ergebnis.returncode != 0:
                    raise YoutubeFehler("ffmpeg: " + (ergebnis.stderr or "Fehler")[-200:])
                os.replace(temp, aus)
                if os.path.abspath(datei) != os.path.abspath(aus):
                    os.remove(datei)
                datei = aus
            a.update(status="fertig", prozent=100.0, datei=os.path.basename(datei), tempo_dl=0)
            log.info("YouTube %s fertig: %s", a["art"], a["datei"])
            ereignisse.melden("download", "YouTube-%s fertig: %s" % (a["art"], a["datei"]), True)
        except Exception as fehler:
            a.update(status="fehler", fehler=str(fehler)[:300], tempo_dl=0)
            log.warning("YouTube %s %s: %s", a["art"], a["video"], fehler)
            ereignisse.melden("download", "YouTube-%s fehlgeschlagen: %s – %s" % (a["art"], a["titel"], a["fehler"]), False)
        finally:
            a["laeuft"] = False

    def dateien(self):
        try:
            namen = [n for n in os.listdir(self.ordner) if not n.endswith((".part", ".ytdl", ".neu.mp4"))]
        except OSError:
            return []
        liste = []
        for n in namen:
            pfad = os.path.join(self.ordner, n)
            if os.path.isfile(pfad):
                st = os.stat(pfad)
                liste.append({"name": n, "groesse": st.st_size, "zeit": int(st.st_mtime)})
        return sorted(liste, key=lambda d: -d["zeit"])

    def pfad(self, name):
        name = os.path.basename(str(name or ""))
        pfad = os.path.join(self.ordner, name)
        if not name or not os.path.isfile(pfad):
            raise YoutubeFehler("Datei nicht gefunden")
        return pfad

    def loeschen(self, name):
        os.remove(self.pfad(name))

    def zustand(self):
        with self._sperre:
            auftraege = sorted((dict(a) for a in self.auftraege.values()), key=lambda a: -int(a["id"]))[:30]
        return {"auftraege": auftraege, "dateien": self.dateien(), "ffmpeg": bool(ffmpeg()), "ordner": self.ordner}


