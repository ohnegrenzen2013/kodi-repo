"""Kuratierter Stremio-Community-Addon-Katalog: Liste, Installation und Entfernen."""

import json

from . import community_addons


class CommunityAddonsMixin:
    def community_addons_lesen(self, werte):
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        vorhanden = community_addons.installiert(daten)
        eintraege = []
        for eintrag in community_addons.liste(werte.get("q", ""), werte.get("typ", "")):
            m = eintrag["manifest"]
            eintraege.append({"transportUrl": eintrag["transportUrl"], "manifest": m,
                              "empfohlen": bool(eintrag.get("empfohlen")),
                              "installiert": eintrag["transportUrl"] in vorhanden,
                              "anbieter_id": vorhanden.get(eintrag["transportUrl"], "")})
        return 200, "application/json", {"quelle": community_addons.daten().get("quelle", ""),
                                         "geprueft": community_addons.daten().get("geprueft", ""),
                                         "hinweis": community_addons.daten().get("hinweis", ""),
                                         "addons": eintraege}

    def community_addons_post(self, koerper):
        if not self.app.verwaltung:
            return 503, "application/json", {"fehler": "Anbieter-Verwaltung nicht verfuegbar"}
        if not self.darf("anbieter"):
            return 403, "application/json", {"fehler": "Kein Recht auf Anbieter", "recht": True}
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
        except (ValueError, UnicodeDecodeError):
            return 400, "application/json", {"fehler": "JSON-Fehler"}
        if not isinstance(wunsch, dict):
            return 400, "application/json", {"fehler": "JSON-Objekt erwartet"}
        try:
            aktion = str(wunsch.get("aktion") or "")
            verwaltung = self.app.verwaltung
            if aktion == "grundausstattung":
                ids = verwaltung.aendern(lambda d: community_addons.grundausstattung(d, verwaltung.module))
                return 200, "application/json", {"ok": True, "neu": len(ids or []), "ids": ids or []}
            if aktion == "installieren":
                anbieter_id = verwaltung.aendern(lambda d: community_addons.installieren(
                    d, verwaltung.module, wunsch.get("url", "")))
                return 200, "application/json", {"ok": True, "anbieter_id": anbieter_id}
            if aktion == "entfernen":
                verwaltung.aendern(lambda d: community_addons.entfernen(d, wunsch.get("id")))
                return 200, "application/json", {"ok": True}
            return 400, "application/json", {"fehler": "aktion: installieren, entfernen oder grundausstattung"}
        except (ValueError, FileNotFoundError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
