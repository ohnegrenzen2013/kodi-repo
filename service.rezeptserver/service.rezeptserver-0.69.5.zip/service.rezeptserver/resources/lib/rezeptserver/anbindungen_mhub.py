"""Fremde mHub-Addons (MediaHubMX Addon-Protokoll v2, https://github.com/MediaHubMX/protocol).

Ein mHub-Addon ist ein Ordner mit JSON-Dateien (statisch, nur GET), vom Aufbau wie ein Stremio-Addon, aber mit eigenen
Endpunkten:
  /mhub-addon.json                     Manifest (id, name, specVersion 2, resources, types, idPrefixes, catalogs)
  /source/{type}/{id}.json             Quellen (Streams) zu einer ID  -> wie H0rSt-Auflöser
  /subtitle/{type}/{id}.json           Untertitel zu einer ID         -> wie H0rSt-Anreicherer
  /catalog/{type}/{catalogId}.json     durchblätterbarer Katalog (?search=) -> Suche wie bei Stremio-Addons

H0rSt übersetzt die mHub-Antworten in dieselbe Form wie fremde Stremio-Addons, damit sie ohne Sonderweg in Filme,
Serien und der Suche auftauchen (anbindungen_stremio.StremioAddons liefert dieselbe Schnittstelle). IDs: H0rSt spricht
Titel über ihre IMDb-ID an (tt...), mHub adressiert sie als "imdb:tt..."; Streams und Untertitel laufen über den
Inhaltstyp "video" (so auch für Serienfolgen tt...:staffel:folge).
"""

import base64
from urllib.parse import urljoin

from .netz import (Weiterleitung, antwort_holen_roh, oeffentlich_antwort_holen,
                   oeffentlich_antwort_holen_roh)

from .anbindungen_grund import (
    ADDON_ZEIT,
    Abrufer,
    NetzFehler,
    ThreadPoolExecutor,
    _host,
    eigene,
    json,
    log,
    oeffentlich_holen,
    quote,
    re,
    threading,
    time,
    urlencode,
    urllib_holen,
    wait,
)

MHUB_DATEI = "mhub-addon.json"
MAX_KINDER = 60
MAX_TIEFE = 3


def mhub_basis(url):
    """Basis-Adresse eines mHub-Addons aus Eingabe (mit oder ohne /mhub-addon.json) oder ''."""
    url = str(url or "").strip()
    if url.lower().startswith("mhub://"):
        url = "https://" + url[len("mhub://"):]
    url = re.sub(r"/%s$" % re.escape(MHUB_DATEI), "", url.rstrip("/"), flags=re.I)
    if url.lower().startswith(("http://", "https://")) and _host(url):
        return url
    return ""


def ist_mhub_manifest(roh):
    return isinstance(roh, dict) and isinstance(roh.get("id"), str) and roh.get("specVersion") == 2 \
        and isinstance(roh.get("resources"), list)


def ist_mhub_repository(roh):
    return isinstance(roh, dict) and isinstance(roh.get("id"), str) and roh.get("specVersion") == 2 \
        and isinstance(roh.get("addons"), list)


def ist_mhub_bundle(roh):
    return isinstance(roh, dict) and isinstance(roh.get("id"), str) and roh.get("specVersion") == 2 \
        and isinstance(roh.get("requires"), list) and not roh.get("resources")


def _konfig(wert):
    """Mhub-Config als Objekt: JSON-Text aus den Anbieter-Einstellungen oder ein dict."""
    if isinstance(wert, dict):
        return wert
    try:
        d = json.loads(str(wert or "{}"))
    except ValueError:
        return {}
    return d if isinstance(d, dict) else {}


def _muster_passt(url, muster):
    """mHub-urlPatterns sind Glob-Muster (https://*.example.com/watch*)."""
    muster = str(muster or "").strip()
    if not muster:
        return False
    if muster.startswith("^") or muster.endswith("$"):
        try:
            return re.match(muster, url) is not None
        except re.error:
            return False
    teile = [re.escape(t) for t in muster.split("*")]
    try:
        return re.match("^" + ".*".join(teile) + "$", url, re.I) is not None
    except re.error:
        return False


class MhubAddons:
    """mHub-Addons: Quellen (Streams), Untertitel und Suchkataloge zu einer ID einsammeln (parallel, mit Zeitgrenze)."""

    def __init__(self, addons, holen=urllib_holen, zeitgrenze=ADDON_ZEIT):
        self.addons = []
        for a in addons:
            basis = mhub_basis(a.get("url"))
            if basis:
                self.addons.append({"id": a["id"], "name": a["name"], "basis": basis,
                                    "heimnetz_erlaubt": bool(a.get("heimnetz_erlaubt")),
                                    "konfig": _konfig(a.get("konfig")),
                                    "tracking": str(a.get("tracking") or "") == "1"})
        self.holen = holen
        self.zeitgrenze = zeitgrenze
        self.zaehler = None  # nutzung.Nutzung.zaehler (setzt die App), Rangliste im Admin-Panel
        self._manifeste = {}
        self._erweitert = set()
        self._sperre = threading.Lock()
        self._pool = ThreadPoolExecutor(max_workers=6, thread_name_prefix="mhub") if self.addons else None

    def _abrufer(self, addon):
        holen = self.holen if addon.get("heimnetz_erlaubt") else oeffentlich_holen(self.holen)
        return Abrufer([_host(addon["basis"])], holen=holen, zeitgrenze=self.zeitgrenze)

    def manifest(self, addon):
        with self._sperre:
            alt = self._manifeste.get(addon["id"])
            if alt and time.time() - alt[0] < 3600:
                return alt[1]
        try:
            m = json.loads(self._abrufer(addon).abruf("%s/%s" % (addon["basis"], MHUB_DATEI)))
            m = m if (ist_mhub_manifest(m) or ist_mhub_repository(m) or ist_mhub_bundle(m)) else {}
            if ist_mhub_repository(m) or ist_mhub_bundle(m):
                self._erweitern(addon, m)
        except (NetzFehler, ValueError) as fehler:
            log.warning("mHub-Addon %s: Manifest nicht lesbar: %s", addon["name"], fehler)
            m = {}
        with self._sperre:
            self._manifeste[addon["id"]] = (time.time(), m)
        return self._manifeste[addon["id"]][1]

    def _erweitern(self, addon, m):
        """Repository (addons) oder Bundle (requires) in einzelne Addons aufloesen – hoechstens MAX_TIEFE Ebenen."""
        basis = addon["basis"]
        with self._sperre:
            if basis in self._erweitert or addon.get("tiefe", 0) >= MAX_TIEFE:
                return
            self._erweitert.add(basis)
        ist_repo = ist_mhub_repository(m)
        eintraege = (m.get("addons") if ist_repo else m.get("requires")) or []
        vorhanden = {a["basis"] for a in self.addons}
        for e in eintraege[:MAX_KINDER]:
            if isinstance(e, str):
                ziel, an = e, not ist_repo
            elif isinstance(e, dict):
                ziel, an = e.get("url"), e.get("enabled", not ist_repo)
            else:
                continue
            if not ziel or not an:
                continue
            try:
                kind_basis = mhub_basis(urljoin(basis.rstrip("/") + "/", str(ziel)))
            except ValueError:
                continue
            if not kind_basis or kind_basis in vorhanden:
                continue
            vorhanden.add(kind_basis)
            self.addons.append({"id": "%s-%d" % (addon["id"], len(vorhanden)), "name": str(
                (e.get("name") if isinstance(e, dict) else "") or kind_basis.rsplit("/", 1)[-1])[:80],
                "basis": kind_basis, "heimnetz_erlaubt": addon.get("heimnetz_erlaubt", False),
                "konfig": {}, "tracking": False,
                "tiefe": int(addon.get("tiefe", 0)) + 1})

    @staticmethod
    def _bietet(manifest, ressource):
        return ressource in (manifest.get("resources") or [])

    @staticmethod
    def _id_passt(manifest, praefix="imdb"):
        p = manifest.get("idPrefixes")
        return not p or praefix in p

    @staticmethod
    def _kopf(addon):
        """Mhub-Config nur, wenn der Nutzer Werte eingetragen hat (kein Header auf dem Manifest)."""
        return {"Mhub-Config": json.dumps(addon["konfig"], ensure_ascii=False)} if addon.get("konfig") else {}

    def _client_fetch(self, addon, anfrage, tiefe=0):
        """ClientFetchRequest: die App holt die Adresse selbst und reicht das Ergebnis an /client-fetch."""
        if tiefe > 3 or not isinstance(anfrage, dict):
            return None
        cf = anfrage.get("clientFetch") if isinstance(anfrage.get("clientFetch"), dict) else {}
        url, kennung = str(cf.get("url") or ""), cf.get("id")
        if not url.startswith(("http://", "https://")) or kennung in (None, ""):
            return None
        methode = str(cf.get("method") or "GET").upper()
        if methode not in ("GET", "POST", "PUT", "PATCH", "DELETE", "HEAD"):
            methode = "GET"
        kopf = cf.get("headers") if isinstance(cf.get("headers"), dict) else {}
        kopf = {str(k): str(v) for k, v in kopf.items()}
        koerper = cf.get("body") if isinstance(cf.get("body"), str) else None
        roh = self.holen is urllib_holen
        if roh:
            holen = antwort_holen_roh if addon.get("heimnetz_erlaubt") else oeffentlich_antwort_holen_roh(antwort_holen_roh)
        else:
            holen = self.holen if addon.get("heimnetz_erlaubt") else oeffentlich_antwort_holen(self.holen)
        try:
            status, text = holen(url, methode=methode, header=kopf, daten=koerper, zeitgrenze=self.zeitgrenze)
        except (NetzFehler, Weiterleitung, OSError, ValueError) as fehler:
            log.warning("mHub-ClientFetch %s: %s", url, fehler)
            return None
        kodierung = "utf-8"
        if isinstance(text, bytes):
            try:
                text = text.decode("utf-8")
            except UnicodeDecodeError:
                text = base64.b64encode(text).decode("ascii")
                kodierung = "base64"
        ergebnis = {"id": kennung, "status": int(status or 0), "body": text or "", "encoding": kodierung,
                    "headers": {}}
        ziel = "%s/client-fetch" % addon["basis"]
        try:
            return self._abruf(addon, ziel, "POST", json.dumps(ergebnis), tiefe=tiefe + 1)
        except (NetzFehler, ValueError) as fehler:
            log.warning("mHub-ClientFetch-Antwort %s: %s", addon["name"], fehler)
            return None

    def _abruf(self, addon, url, methode="GET", daten=None, tiefe=0):
        """Ein Endpunkt-Abruf: Mhub-Config mitschicken und ClientFetch-Antworten aufloesen."""
        kopf = self._kopf(addon)
        if daten is not None:
            kopf["Content-Type"] = "application/json"
        text = self._abrufer(addon).abruf(url, methode, header=kopf, daten=daten)
        daten_json = json.loads(text) if text and text.strip() else None
        if isinstance(daten_json, dict) and isinstance(daten_json.get("clientFetch"), dict):
            return self._client_fetch(addon, daten_json, tiefe)
        return daten_json

    def _hole(self, addon, ressource, typ, sid, feld):
        m = self.manifest(addon)
        if not self._bietet(m, ressource) or not self._id_passt(m):
            return []
        url = "%s/%s/%s/%s.json" % (addon["basis"], ressource, quote(typ, safe=""), quote("imdb:" + sid, safe=":"))
        daten = self._abruf(addon, url)
        liste = daten.get(feld) if isinstance(daten, dict) else None
        return [e for e in liste or [] if isinstance(e, dict)]

    def _erweitern_alle(self):
        for a in list(self.addons):
            self.manifest(a)  # Repositories/Bundles legen ihre Kinder hier an

    def _sammeln(self, ressource, typ, sid, feld):
        if not self._pool:
            return []
        self._erweitern_alle()
        zukuenfte = {self._pool.submit(self._hole, a, ressource, typ, sid, feld): a for a in self.addons}
        fertig, offen = wait(zukuenfte, timeout=self.zeitgrenze)
        for z in offen:
            log.warning("mHub-Addon %s: Zeitgrenze überschritten", zukuenfte[z]["name"])
            self._zaehlen(ressource, zukuenfte[z], fehler=True)
        ergebnis = []
        for a in self.addons:  # Reihenfolge wie eingetragen
            for z, addon in zukuenfte.items():
                if addon is a and z in fertig:
                    try:
                        liste = z.result()
                    except Exception as fehler:
                        log.warning("mHub-Addon %s: %s", a["name"], fehler)
                        self._zaehlen(ressource, a, fehler=True)
                        continue
                    ergebnis.extend((a, e) for e in liste)
                    self._zaehlen(ressource, a, len(liste))
        return ergebnis

    def _zaehlen(self, ressource, addon, treffer=0, fehler=False):
        if ressource == "source" and getattr(self, "zaehler", None):
            try:
                self.zaehler("addons", addon["name"], treffer, fehler)
            except Exception:
                pass

    def _tracker(self):
        return [a for a in self.addons if a.get("tracking") and "playback" in (self.manifest(a).get("resources") or [])]

    def melden(self, ereignis):
        """Ein Ereignis an alle mHub-Tracker schicken, die der Nutzer eingeschaltet hat."""
        if not isinstance(ereignis, dict) or not self._pool:
            return 0
        anzahl = 0
        for addon in self._tracker():
            try:
                self._abruf(addon, "%s/playback" % addon["basis"], "POST", json.dumps([ereignis]))
                anzahl += 1
            except (NetzFehler, ValueError) as fehler:
                log.warning("mHub-Tracker %s: %s", addon["name"], fehler)
        return anzahl

    def _aufloesen(self, url):
        """Resolver-Addons (resources: resolve + urlPatterns) fuer eine Quell-Adresse befragen."""
        if not url.startswith(("http://", "https://")):
            return None
        self._erweitern_alle()
        for addon in self.addons:
            m = self.manifest(addon)
            if "resolve" not in (m.get("resources") or []):
                continue
            if not any(_muster_passt(url, muster) for muster in m.get("urlPatterns") or []):
                continue
            try:
                d = self._abruf(addon, "%s/resolve?%s" % (addon["basis"], urlencode({"url": url})))
            except (NetzFehler, ValueError) as fehler:
                log.warning("mHub-Resolver %s: %s", addon["name"], fehler)
                continue
            if isinstance(d, dict) and isinstance(d.get("url"), str) and d["url"].startswith(("http://", "https://")):
                return d
        return None

    def streams(self, typ, sid):
        """Quellen aller mHub-Addons zu tt... als Streams in der Form fremder Stremio-Addons."""
        streams = []
        for addon, s in self._sammeln("source", "video", sid, "sources"):
            if s.get("kind") != "website":
                aufgeloest = self._aufloesen(str(s.get("url") or ""))
                if aufgeloest:
                    s = dict(aufgeloest, name=s.get("name") or aufgeloest.get("name"))
            x = _quelle_zu_stream(addon, s)
            if x:
                streams.append(x)
        return streams

    def untertitel(self, typ, sid):
        liste = []
        for n, (a, u) in enumerate(self._sammeln("subtitle", "video", sid, "subtitles")):
            if u.get("url") and u.get("language"):
                liste.append({"id": "mhub-%s-%d" % (a["id"], n), "url": str(u["url"]), "lang": str(u["language"])})
        return liste

    def _katalog_hole(self, addon, typ, kid, text):
        alle, cursor = [], None
        for _ in range(3):  # höchstens drei Seiten je Katalog, damit eine Suche nicht endlos blättert
            werte = {"search": text}
            if cursor is not None:
                werte["cursor"] = cursor
            url = "%s/catalog/%s/%s.json?%s" % (addon["basis"], quote(typ, safe=""), quote(kid, safe=""),
                                                urlencode(werte))
            daten = self._abruf(addon, url)
            if not isinstance(daten, dict):
                break
            alle.extend(daten.get("items") or [])
            cursor = daten.get("nextCursor")
            if cursor in (None, ""):
                break
        metas = [_item_zu_meta(i) for i in alle if isinstance(i, dict)]
        return [m for m in metas if m]

    def katalog_suche(self, text):
        """Suche in den Katalogen (features.search) aller mHub-Addons -> [(addon, meta)] wie bei Stremio-Addons."""
        if not self._pool:
            return []
        self._erweitern_alle()
        auftraege = []
        for addon in self.addons:
            m = self.manifest(addon)
            if not self._bietet(m, "catalog"):
                continue
            for k in m.get("catalogs") or []:
                if not isinstance(k, dict) or not k.get("id") or k.get("type") not in ("video", "series"):
                    continue
                if (k.get("features") or {}).get("search"):
                    auftraege.append((addon, self._pool.submit(self._katalog_hole, addon, k["type"], k["id"], text)))
        fertig, _ = wait([z for _, z in auftraege], timeout=self.zeitgrenze)
        ergebnis = []
        for addon, z in auftraege:
            if z in fertig:
                try:
                    ergebnis.extend((addon, m) for m in z.result()[:40])
                except Exception as fehler:
                    log.warning("mHub-Addon %s: Suche: %s", addon["name"], fehler)
        return ergebnis

    def schliessen(self):
        if self._pool:
            self._pool.shutdown(wait=False)


def _quelle_zu_stream(addon, s):
    """mHub-Source -> Stream wie von einem Stremio-Addon (url/externalUrl, name, behaviorHints.proxyHeaders)."""
    url = str(s.get("url") or "").strip()
    if not url.startswith(("http://", "https://")):
        return None
    zusatz = " · ".join(x for x in (s.get("quality"), " ".join(s.get("languages") or [])) if x)
    name = "\n".join(x for x in (addon["name"], " ".join(y for y in (s.get("name"), s.get("quality")) if y)) if x)
    titel = "\n".join(x for x in (str(s.get("name") or ""), zusatz) if x) or url
    if s.get("kind") == "website":  # Anbieterseite (Netflix, JustWatch …): im Browser öffnen, nie abspielen
        return {"name": name or addon["name"], "title": titel, "externalUrl": url,
                "behaviorHints": {"bingeGroup": "mhub-%s" % addon["id"]}}
    stream = {"name": name or addon["name"], "title": titel, "url": url,
              "behaviorHints": {"notWebReady": True, "bingeGroup": "mhub-%s" % addon["id"]}}
    kopf = s.get("headers")
    if isinstance(kopf, dict) and kopf:
        stream["behaviorHints"]["proxyHeaders"] = {"request": {str(k): str(v) for k, v in kopf.items()}}
    if isinstance(s.get("size"), int) and s["size"] > 0:
        stream["behaviorHints"]["videoSize"] = s["size"]
    return stream


def _item_zu_meta(item):
    """mHub-Item -> Cinemeta-artige Meta (nur Titel mit IMDb-ID, damit H0rSt sie öffnen kann)."""
    ids = item.get("ids") if isinstance(item.get("ids"), dict) else {}
    imdb = str(ids.get("imdb") or "")
    if not re.match(r"^tt\d{1,10}", imdb):
        return None
    bilder = item.get("images") if isinstance(item.get("images"), dict) else {}
    backdrops = bilder.get("backdrops") if isinstance(bilder.get("backdrops"), list) else []
    typ = "series" if item.get("type") == "series" else "movie"
    bewertung = (item.get("ratings") or {}).get("imdb") if isinstance(item.get("ratings"), dict) else None
    return {"id": imdb.split(":")[0], "type": typ, "name": str(item.get("name") or ""),
            "poster": str(bilder.get("poster") or ""), "background": str(backdrops[0] if backdrops else ""),
            "logo": str(bilder.get("logo") or ""), "releaseInfo": str(item.get("year") or ""),
            "imdbRating": str(bewertung) if bewertung is not None else "",
            "genres": [g for g in (item.get("genres") or []) if isinstance(g, str)][:4],
            "description": str(item.get("description") or ""), "runtime": str(item.get("runtime") or "")}


def mhub_addons(daten, holen=urllib_holen):
    return MhubAddons([{"id": i, "name": e["name"], "url": w.get("url", ""),
                        "heimnetz_erlaubt": w.get("heimnetz_erlaubt") == "1",
                        "konfig": w.get("konfig", ""), "tracking": w.get("tracking") == "1"}
                       for i, e, w in eigene(daten, "mhub-addon") if w.get("url")], holen=holen)


class KombiAddons:
    """Fremde Addons aus mehreren Protokollen (Stremio + mHub) unter einer Schnittstelle zusammenfassen."""

    def __init__(self, *teile):
        self.teile = [t for t in teile if t is not None]
        self.zeitgrenze = max([t.zeitgrenze for t in self.teile], default=ADDON_ZEIT)
        self._zaehler = None

    @property
    def addons(self):
        return [a for t in self.teile for a in t.addons]

    @property
    def zaehler(self):
        return self._zaehler

    @zaehler.setter
    def zaehler(self, wert):
        self._zaehler = wert
        for t in self.teile:
            t.zaehler = wert

    def streams(self, typ, sid):
        ergebnis = []
        for t in self.teile:
            ergebnis.extend(t.streams(typ, sid))
        return ergebnis

    def untertitel(self, typ, sid):
        ergebnis = []
        for t in self.teile:
            ergebnis.extend(t.untertitel(typ, sid))
        return ergebnis

    def katalog_suche(self, text):
        ergebnis = []
        for t in self.teile:
            ergebnis.extend(t.katalog_suche(text))
        return ergebnis

    def melden(self, ereignis):
        anzahl = 0
        for t in self.teile:
            if hasattr(t, "melden"):
                anzahl += t.melden(ereignis)
        return anzahl

    def katalog_liste(self):
        """Durchstoeberbare Kataloge - vorerst nur von Stremio-Addons (StremioAddons.katalog_liste)."""
        ergebnis = []
        for t in self.teile:
            if hasattr(t, "katalog_liste"):
                ergebnis.extend(t.katalog_liste())
        return ergebnis

    def katalog_holen(self, addon_id, typ, katalog, genre="", skip=0):
        for t in self.teile:
            if hasattr(t, "katalog_holen") and any(a["id"] == addon_id for a in t.addons):
                return t.katalog_holen(addon_id, typ, katalog, genre, skip)
        raise ValueError("Unbekanntes Addon: %s" % addon_id)

    def schliessen(self):
        for t in self.teile:
            t.schliessen()
