"""App-Store: Android-Apps aus offenen Quellen finden, installieren und aktuell halten (Idee aus Vyxel Apps, eigener Code).

Quellen: F-Droid, IzzyOnDroid (beides F-Droid-Repos mit signierten Builds), GitHub, Codeberg und GitLab (Releases mit APK)
         sowie APKMB (Webseite mit APK-Downloads).
  * Suche in allen Quellen zugleich, Ergebnisse zusammengefuehrt; je App die Versionen mit ihren APKs.
  * Vertrauenswert 0–100 fuer GitHub/Codeberg (Sterne, Aktivitaet, Releases, Forks, Lizenz; archiviert zaehlt dagegen).
  * Laden: H0rSt holt die APK nach <Datenordner>/appstore (nur von den Hosts der jeweiligen Quelle, hoechstens 400 MB);
    die H0rSt-App installiert sie und prueft vorher, ob die Signatur zur schon installierten App passt.
  * Updates: die App meldet ihre installierten Apps samt Versionscode; H0rSt vergleicht mit F-Droid, IzzyOnDroid und den
    beobachteten GitHub-/Codeberg-Projekten.
  * Verlauf jeder Installation (zum Zurueckrollen auf eine fruehere Version), Favoriten, Sterne eines GitHub-Nutzers.
  * Hintergrund-Pruefung (alle paar Stunden): der zuletzt von der App gemeldete Installations-Schnappschuss plus
    beobachtete Projekte werden auf Updates geprueft, ohne dass die App dafuer selbst aktiv sein muss - Ergebnis
    zwischengespeichert und ueber ereignisse.melden() gemeldet.
  * Eigene Repositories: bis zu MAX_EIGENE_REPOS zusaetzliche GitHub-/GitLab-/Codeberg-Projekte oder
    F-Droid-kompatible Katalog-Indizes eintragen - nur strukturierte Quellen, keine beliebige APK-Seite.
    eigener_repo_app() liest sie ab; die Hintergrund-Pruefung meldet eine neue Version seit dem letzten Lauf.
  * Update-Kontrollen je App: ausschliessen, eine Version uebergehen, eine Quelle bevorzugen oder festnageln
    (nur fuer fdroid/izzy, wo updates() wirklich zwischen mehreren Treffern waehlt).

Nutzerdaten "appstore": {"verlauf": [{id, name, paket, version, quelle, zeit}], "favoriten": [id], "beobachtet": {paket: id},
                         "github_token": "", "letzte_installierte_liste": {paket: {code, version, name}},
                         "letzte_installierte_zeit": 0, "hintergrund_zeit": 0, "hintergrund_ergebnis": [...],
                         "eigene_repos": [{"id", "name", "typ", "url", "aktiv"}],
                         "eigene_repos_versionen": {repo_id: version},
                         "einstellungen_je_app": {paket: {"ausgeschlossen", "uebersprungene_version",
                                                           "bevorzugte_quelle", "quelle_fest"}}}
"""

import os
import re
import threading
import time

from . import ereignisse
from .appstore_app import AppMixin
from .appstore_datei import DateiMixin
from .appstore_grund import *
from .appstore_grund import _ABI_WORTE, _PAKET, _REPO, _eigener_repo_pruefen, _quelle_pruefen, _tage_seit, _text
from .appstore_suche import SucheMixin
from .netz import antwort_holen


class AppStore(SucheMixin, AppMixin, DateiMixin):
    def __init__(self, datenordner, verwaltung, holen=None, laden=None, uhr=None):
        self.ordner = os.path.join(datenordner or ".", "appstore")
        self._verwaltung = verwaltung  # Funktion: Verwaltung der Nutzerdaten (oder None)
        self.holen = holen or antwort_holen
        self.laden_roh = laden or roh_laden
        self.uhr = uhr or time.time
        self._speicher = {}
        self._sperre = threading.Lock()
        self._izzy = None
        self._izzy_sperre = threading.Lock()
        self._hintergrund_sperre = threading.Lock()
        self._hintergrund_laeuft = False

    # --- Nutzerdaten: Verlauf, Favoriten, Beobachten, Token ------------------------------------------------------------
    @staticmethod
    def aendern(daten, wunsch, uhr=time.time):
        """{installiert: {id, name, paket, version}} | {favorit: id, an: bool} | {beobachten: {paket, id}} | {vergessen: paket}
        | {github_token: text}. Gibt den oeffentlichen Stand zurueck."""
        s = dict(daten.get(SCHLUESSEL) or {})
        if isinstance(wunsch.get("installiert"), dict):
            w = wunsch["installiert"]
            AppStore._zerlegen(w.get("id"))
            eintrag = {
                "id": str(w["id"]),
                "name": _text(w.get("name"), 80),
                "paket": _text(w.get("paket"), 200),
                "version": _text(w.get("version"), 60),
                "quelle": str(w["id"]).split(":")[0],
                "zeit": int(uhr()),
            }
            s["verlauf"] = ([eintrag] + [v for v in s.get("verlauf") or [] if isinstance(v, dict)])[:MAX_VERLAUF]
            if eintrag["paket"] and _PAKET.match(eintrag["paket"]) and eintrag["quelle"] in ("github", "codeberg"):
                s["beobachtet"] = dict(s.get("beobachtet") or {}, **{eintrag["paket"]: eintrag["id"]})
        if "favorit" in wunsch:
            AppStore._zerlegen(wunsch["favorit"])
            fav = [f for f in s.get("favoriten") or [] if f != wunsch["favorit"]]
            s["favoriten"] = ([wunsch["favorit"]] + fav if wunsch.get("an", True) else fav)[:MAX_FAVORITEN]
        if isinstance(wunsch.get("beobachten"), dict):
            paket, app_id = str(wunsch["beobachten"].get("paket") or ""), str(wunsch["beobachten"].get("id") or "")
            if not _PAKET.match(paket):
                raise StoreFehler("Ungültiger Paketname")
            AppStore._zerlegen(app_id)
            s["beobachtet"] = dict(s.get("beobachtet") or {}, **{paket: app_id})
        if "vergessen" in wunsch:
            s["beobachtet"] = {p: i for p, i in (s.get("beobachtet") or {}).items() if p != wunsch["vergessen"]}
        if "github_token" in wunsch:
            token = str(wunsch.get("github_token") or "").strip()
            if len(token) > 200 or not re.match(r"^[\w-]*$", token):
                raise StoreFehler("Ungültiger GitHub-Token")
            s["github_token"] = token
        if isinstance(wunsch.get("repo_dazu"), dict):
            neu = _eigener_repo_pruefen(wunsch["repo_dazu"])
            vorhandene = [r for r in s.get("eigene_repos") or [] if isinstance(r, dict)]
            if neu["url"] not in {r.get("url") for r in vorhandene} and len(vorhandene) >= MAX_EIGENE_REPOS:
                raise StoreFehler("Höchstens %d eigene Repositories" % MAX_EIGENE_REPOS)
            s["eigene_repos"] = [r for r in vorhandene if r.get("url") != neu["url"]] + [neu]
        if "repo_weg" in wunsch:
            s["eigene_repos"] = [r for r in s.get("eigene_repos") or [] if isinstance(r, dict) and r.get("id") != wunsch["repo_weg"]]
        for aktion, feld, wert in (
            ("app_ausschliessen", "ausgeschlossen", lambda w: bool(w.get("an", True))),
            ("version_uebergehen", "uebersprungene_version", lambda w: _text(w.get("version"), 60)),
            ("quelle_bevorzugen", "bevorzugte_quelle", lambda w: _quelle_pruefen(w.get("quelle"))),
            ("quelle_festnageln", "quelle_fest", lambda w: _quelle_pruefen(w.get("quelle"))),
        ):
            if isinstance(wunsch.get(aktion), dict):
                w = wunsch[aktion]
                paket = str(w.get("paket") or "")
                if not _PAKET.match(paket):
                    raise StoreFehler("Ungültiger Paketname")
                je_app = dict(s.get("einstellungen_je_app") or {})
                eintrag = {k: v for k, v in (je_app.get(paket) or {}).items() if v}
                eintrag[feld] = wert(w)
                eintrag = {k: v for k, v in eintrag.items() if v}  # False/"" wieder entfernen (zuruecksetzen)
                je_app = {p: e for p, e in je_app.items() if p != paket}
                if eintrag:
                    je_app[paket] = eintrag
                s["einstellungen_je_app"] = je_app
        daten[SCHLUESSEL] = s
        return oeffentlich(daten)

    @staticmethod
    def schnappschuss_merken(daten, installiert, uhr=time.time):
        """Speichert die zuletzt von der App gemeldete Liste installierter Pakete (Schnappschuss fuer die
        Hintergrund-Pruefung - der Server kennt den echten Installationsstand sonst nicht)."""
        if not isinstance(installiert, dict):
            return
        s = dict(daten.get(SCHLUESSEL) or {})
        sauber = {}
        for paket, info in list(installiert.items())[:MAX_SCHNAPPSCHUSS]:
            if not _PAKET.match(str(paket)) or not isinstance(info, dict):
                continue
            try:
                code = int(info.get("code") or 0)
            except (TypeError, ValueError):
                code = 0
            sauber[paket] = {"code": code, "version": _text(info.get("version"), 60), "name": _text(info.get("name"), 80)}
        s["letzte_installierte_liste"] = sauber
        s["letzte_installierte_zeit"] = int(uhr())
        daten[SCHLUESSEL] = s

    def sterne_holen(self, benutzer):
        """Oeffentliche Sterne eines GitHub-Nutzers: Android-Projekte (Thema android oder Kotlin/Java) als App-Kennungen."""
        if not re.match(r"^[\w-]{1,39}$", str(benutzer or "")):
            raise StoreFehler("Ungültiger GitHub-Name")
        d = self._json("%s/users/%s/starred?per_page=100" % (GITHUB, benutzer), self._github_kopf()) or []
        return [
            "github:" + r["full_name"]
            for r in d
            if isinstance(r, dict)
            and _REPO.match(str(r.get("full_name")))
            and ("android" in (r.get("topics") or []) or r.get("language") in ("Kotlin", "Java", "Dart"))
        ]


def eingeschaltet(daten):
    """Globaler Schalter, Standard AN - anders als bei brandneuen, riskanten Features (nuvio_plugin,
    mcp_server), die ab Werk aus starten: der App-Store laeuft schon laenger, ein Default-Wechsel auf
    "aus" wuerde ihn bestehenden Nutzern unangekuendigt abschalten."""
    return bool((daten or {}).get("appstore_an", True))


def oeffentlich(daten):
    s = (daten or {}).get(SCHLUESSEL) if isinstance((daten or {}).get(SCHLUESSEL), dict) else {}
    return {
        "an": eingeschaltet(daten),
        "verlauf": s.get("verlauf") or [],
        "favoriten": s.get("favoriten") or [],
        "beobachtet": s.get("beobachtet") or {},
        "github_token": bool(s.get("github_token")),
        "quellen": QUELLEN,
        "letzte_installierte_zeit": s.get("letzte_installierte_zeit", 0),
        "hintergrund_zeit": s.get("hintergrund_zeit", 0),
        "hintergrund_ergebnis": s.get("hintergrund_ergebnis") or [],
        "eigene_repos": eigene_repos(daten),
        "repo_typen": REPO_TYPEN,
        "einstellungen_je_app": s.get("einstellungen_je_app") or {},
    }
