"""m0dul-Baukasten: der gefuehrte Rundgang beim ersten Start (wie das Setup von CloudStream).

H0rSt ist ein Modul-Host. Jedes Modul bringt einen Bereich (Reiter) mit; was man nicht braucht, bleibt
"abgedockt" und stoert nicht. Der Rundgang fuehrt Station fuer Station durch die H0rSt-Welt:

  Willkommen  -> wie H0rSt aufgebaut ist (Module, Quellen, Geraete)
  Sprache     -> Ton- und Untertitelsprache
  4 Welten    -> Sehen, Finden & Laden, Zuhause, Schutz: jedes Modul mit "Was ist das? Wofuer? Was brauchst du?",
                 frei an- und abdocken
  Quellen     -> fuer jedes angedockte Modul direkt in den Hinzufuegen-Assistenten (oder per Adresse)
  Aussehen    -> Geraet (Handy, Tablet, Fernseher), Akzentfarbe, Startanimation
  Fertig      -> Uebersicht, und wo man spaeter umbaut

Andocken heisst: die Reiter des Moduls sind sichtbar (Einstellungen -> Navigation). Abdocken blendet sie aus;
Einstellungen, Zugaenge und Daten bleiben erhalten, ein spaeteres Andocken bringt alles zurueck.

Nutzerdaten "baukasten": {"fertig": bool, "version": int, "zeit": int}
"""

import time

from . import einstellungen

SCHLUESSEL = "baukasten"
VERSION = 1

AUFBAU = [
    {"symbol": "🧩", "name": "Module",
     "text": "Bereiche wie Filme, Live-TV, Downloads oder Kameras. Du dockst an, was du nutzt – der Rest bleibt "
             "unsichtbar und kostet nichts."},
    {"symbol": "🔌", "name": "Quellen",
     "text": "Woher die Inhalte kommen: Addons, Usenet, Debrid, Mediatheken, deine eigenen Speicher. Ein Modul "
             "zeigt an, was seine Quellen liefern."},
    {"symbol": "📱", "name": "Geräte",
     "text": "Ein H0rSt, viele Wege hinein: diese App, jeder Browser im Heimnetz, Stremio, Kodi und IPTV-Apps "
             "nutzen denselben Server – deine Einstellungen gelten überall."},
]

SPRACHEN = [
    {"id": "de", "name": "Deutsch", "text": "Deutscher Ton und deutsche Untertitel zuerst.",
     "werte": {"audio": "de", "untertitel": "de"}},
    {"id": "de_en", "name": "Deutsch, sonst Englisch", "text": "Erst Deutsch, gibt es das nicht, Englisch.",
     "werte": {"audio": "de, en", "untertitel": "de, en"}},
    {"id": "en", "name": "Englisch", "text": "Englischer Ton und englische Untertitel zuerst.",
     "werte": {"audio": "en", "untertitel": "en"}},
    {"id": "original", "name": "Originalton mit deutschen Untertiteln", "text": "Keine Tonsprache bevorzugen, "
     "Untertitel auf Deutsch.", "werte": {"audio": "", "untertitel": "de"}},
]

LAYOUTS = [
    {"id": "handy", "name": "Handy", "symbol": "📱", "text": "Kompakt, kleinere Karten – passt auf schmale Bildschirme.",
     "werte": {"schrift": "normal", "dichte": "kompakt", "kartengroesse": "klein"}},
    {"id": "tablet", "name": "Tablet & PC", "symbol": "💻", "text": "Ausgewogen, mittlere Karten.",
     "werte": {"schrift": "normal", "dichte": "normal", "kartengroesse": "mittel"}},
    {"id": "tv", "name": "Fernseher", "symbol": "📺", "text": "Große Schrift und Karten, viel Abstand – gut mit "
     "der Fernbedienung.", "werte": {"schrift": "tv", "dichte": "luftig", "kartengroesse": "gross"}},
]


def _m(mid, name, symbol, tabs, was, wofuer, brauchst, standard=True, assistent=None, nur_app=False, docker=""):
    return {"id": mid, "name": name, "symbol": symbol, "tabs": tabs, "was": was, "wofuer": wofuer,
            "brauchst": brauchst, "standard": standard, "assistent": assistent, "nur_app": nur_app, "docker": docker}


WELTEN = [
    {"id": "sehen", "name": "Sehen", "symbol": "🎬", "gruppe": "g:sehen",
     "text": "Alles, was läuft: Filme, Serien, Fernsehen, Videos und Spiele.",
     "module": [
         _m("filme_serien", "Filme & Serien", "🎬", ["filme", "serien"],
            "Filme und Serien entdecken (Top-Listen, Genres, Trailer), suchen und abspielen – mit Staffeln, Folgen "
            "und „Weiterschauen“.",
            "Dein Mediacenter: H0rSt sammelt an jedem Titel die Streams aus all deinen Quellen und zeigt Qualität, "
            "Ton und Sprache auf einen Blick.",
            "Mindestens eine Quelle. Ohne Konto laufen schon Mediatheken und Archive.org; mehr bringen "
            "Stremio-Addons, Usenet oder ein Debrid-Dienst.", assistent="quellen"),
         _m("nuvio", "Nuvio Mobile – m0dul", "🎬", ["nuvio"],
            "Nuvio Mobile als Client zum Modul-Host: Filme, Serien, Downloads und Plugins auf Android und iOS. "
            "Die App haengt H0rSt als Stremio-Addon ein und nutzt zusaetzlich die H0rSt-APIs fuer Suche, Streams, "
            "Untertitel, Fortschritt und Tracker.",
            "H0rSt bleibt die Quelle und der Modul-Host – Nuvio ist der neue Anzug davor. Addon- und API-Adresse "
            "stehen im Reiter zum Kopieren bereit, die App kommt aus dem App-Store (GitHub).",
            "Die App Nuvio Mobile (GitHub/App-Store) und ein erreichbarer H0rSt; fuer unterwegs eine feste "
            "HTTPS-Adresse in den Einstellungen.", standard=False),
         _m("livetv", "Live-TV", "📺", ["livetv"],
            "Fernsehen mit Programmführer (EPG): kostenlose Sender sind eingebaut, dazu eigene M3U-Listen und "
            "Xtream-Zugänge.",
            "Live-TV direkt in H0rSt – und als Senderliste (tv.m3u mit EPG) für IPTV-Apps, Kodi und TiviMate.",
            "Nichts. Eigene Listen oder Xtream-Zugänge kannst du jederzeit dazunehmen.", assistent="tv"),
         _m("youtube", "YouTube", "▶", ["youtube"],
            "YouTube ohne Konto und ohne Werbung: Suche, Abos, SponsorBlock, freies Tempo, Speichern.",
            "Videos schauen, ohne Google-Konto und ohne Werbeunterbrechung.", "Nichts."),
         _m("radio", "Radio", "📻", ["radio"],
            "Über 50.000 Internetradio-Sender aus aller Welt (radio-browser.info): suchen, nach Genre stöbern, Favoriten "
            "merken.",
            "Musik, Nachrichten und Hörspiel im Hintergrund – im Browser, in der App oder per 📺 auf Fernseher, "
            "Lautsprecher und Receiver; die Favoriten auch als Senderliste für Kodi und IPTV-Apps.",
            "Nichts – ohne Konto."),
         _m("kodiaddons", "Kodi-Addons", "🧩", ["kodiaddons"],
            "Kodi-Plugins (plugin.video …) direkt in H0rSt: aus dem offiziellen Kodi-Repository, eigenen Repositories "
            "oder als ZIP installieren, durchblättern, suchen und abspielen – ohne Kodi.",
            "Mediatheken und Dienste, für die es ein Kodi-Addon gibt (Arte, ARD, ZDF, YouTube …), auf Handy, Browser und "
            "Fernseher; geschützte Streams per „→ Kodi“ an ein Kodi im Heimnetz.",
            "Nichts – die Addons holt H0rSt selbst. Manche Addons brauchen ein eigenes Konto beim Anbieter."),
         _m("gamehub", "GameHub", "🎮", ["gamehub"],
            "Startpunkt für Cloud-Gaming: Amazon Luna, Xbox Cloud Gaming, GeForce NOW, Boosteroid, Steam Link, "
            "Moonlight – und in der App deine installierten Spiele.",
            "Alles, was du spielst, an einem Ort.",
            "Konten bei den jeweiligen Diensten. Sie öffnen im Browser oder in ihrer eigenen App.", standard=False),
         _m("brause", "Brause – m0dul", "🦊", ["brause"],
            "Ein richtiger Browser auf Firefox-Basis (Mozilla GeckoView): Lesezeichen und Favoriten, Erweiterungen (.xpi) "
            "wie uBlock Origin oder Dark Reader, Tracking-Schutz, Downloads.",
            "Surfen ohne Werbung und Tracker, mit deinen Lesezeichen auf allen Geräten – Lesezeichen und Erweiterungs-Liste "
            "liegen bei H0rSt.",
            "Die App „H0rSt Brause“ – H0rSt installiert sie dir mit einem Tipp (rund 95 MB, je nach Gerät). Im Browser "
            "pflegst du hier nur die Lesezeichen.", standard=False),
         _m("lesehalle", "Lesehalle – m0dul", "📖", ["lesehalle"],
            "Die Lesehalle: ein Regal für offene Medienkataloge (Bücher, Hörbücher, Hörspiele). Quellen schaltest du "
            "selbst ein, der Fortschritt bleibt auf dem Gerät. Sie steckt als eigene Seite in der App, mit Fernbedienung "
            "bedienbar.",
            "Freie Kataloge lesen und hören, ohne Konto – direkt aus H0rSt gestartet.",
            "Die App (im Browser gibt es diesen Bereich nicht) und Internet für die Kataloge.", nur_app=True),
         _m("portal", '("_• )—* – m0dul', "•", ["portal"],
            "Adresse, IP, Gerätename oder MAC eingeben – H0rSt prüft sie (erreichbar? welches Gerät? einbettbar?) und macht "
            "daraus einen eigenen Reiter. Reiter bleiben, bis du sie schließt; 📌 verankert sie. Dazu Verlauf, Favoriten, "
            "Zusammenführen (bis zu vier Seiten in einem Reiter), Wake-on-LAN und viele Ansichts-Einstellungen.",
            "Router, NAS, Home Assistant oder jede Webseite direkt in H0rSt – auch Seiten, die sich sonst nicht einbetten "
            "lassen: H0rSt reicht sie durch, auch ins Heimnetz von unterwegs.",
            "Nichts. Für das Durchreichen über H0rSt braucht ein Profil das Recht „Einstellungen“; MAC-Adressen findet "
            "H0rSt nur, wenn es im selben Heimnetz läuft. Dazu USB Magic: USB-Sticks und -Platten einhängen, Daten "
            "anzeigen, darauf sichern und wiederherstellen (Recht „Ablage und externe Speicher“).", standard=False),
         _m("party", "Party – m0dul", "🎉", ["gemeinsam", "daumenkino", "karaoke"],
            "Gemeinsam schauen (Filme und Serien im selben Takt, mit Chat und Reaktionen – auch unterwegs), "
            "Daumenkino-Werkstatt (Bildfolgen aus Videos, Fotos, Kamera oder Zeichnungen – zum Blättern, als GIF oder als "
            "Druckbogen zum Ausschneiden) und Couch-Play-Karaoke mit YouTube: H0rSt misst Ton und Pegel und vergibt Punkte.",
            "Abends mit Freunden – daheim oder übers Netz. Gute Runden bringen Aufgaben-Joker, die Aufgaben erfüllt man im Videochat.",
            "Ein Mikrofon für Karaoke (Handy, Headset). Für Spieler über das Netz muss H0rSt dort erreichbar sein.", standard=False),
         _m("localdream", "LocalDream – m0dul", "✨", ["localdream"],
            "Bilder aus Text: das Prompt Studio würfelt stimmige Prompts (Szenen, Stimmungen, Begriffe sperren, KI-Chat), "
            "Local Dream erzeugt sie auf dem Handy (Snapdragon-NPU, CPU oder GPU) – oder ein Bildserver im Netz "
            "(AUTOMATIC1111, Forge, SD.Next). Mit Galerie, Hochskalieren und Quellen per Adresse.",
            "Eigene Bilder ohne Cloud und ohne Konto – auch für Hintergründe, Avatare oder das Daumenkino.",
            "Für Bilder auf dem Gerät die App Local Dream (H0rSt lädt sie passend zum Prozessor) und ein Modell; sonst die "
            "Adresse eines Bildservers.", standard=False),
         _m("ab18", "Ab 18", "🔞", ["ab18"],
            "Erwachsenen-Inhalte mehrerer Seiten (ePorner, Pornhub, RedTube, RedGifs, xHamster, XVideos, XNXX, YouPorn), mit Suche "
            "über alle, Merkliste und Verlauf. Weitere Seiten – auch BlueMovie oder eine Seite mit API – fügst du einfach per "
            "Adresse hinzu: H0rSt erkennt Liste, Seitenzahlen und Suche selbst und speichert sie als Anbieter (mit in jeder Sicherung). "
            "Ansicht frei einstellbar (Bildgröße, bewegte Vorschau), dazu das Party-Spiel „Synchron“.",
            "Sauber getrennt vom Rest – ab Werk gesperrt, auf Wunsch mit PIN.",
            "Die Bestätigung „mindestens 18“. Ohne Freigabe bleibt der Bereich zu, auch wenn er angedockt ist.",
            standard=False),
     ]},
    {"id": "laden", "name": "Finden & Laden", "symbol": "⬇", "gruppe": "g:laden",
     "text": "Dateien finden und auf deine Geräte holen – aus dem Usenet, per Torrent, aus FTP-Verzeichnissen, "
             "IRC oder dem eD2k-Netz.",
     "module": [
         _m("dateisuche", "Dateisuche", "🔎", ["dateisuche"],
            "Suche über FTP-Server, offene Web-Verzeichnisse, einen Web-Crawler und das eD2k-Netz.",
            "Dateien finden, die in keinem Film-Katalog stehen – und gleich abspielen oder herunterladen.",
            "Nichts."),
         _m("easynews", "Easynews", "📰", ["easynews"],
            "Die Suche des Easynews-Mitgliederbereichs mit Vorschaubildern.",
            "Usenet-Dateien ohne NZB-Umweg sofort abspielen oder laden.",
            "Ein Easynews-Konto.", standard=False, assistent="usenet"),
         _m("usenet", "Usenet-Stream", "⚡", ["usenet"],
            "Usenet-Filme und -Serien in Stremio sofort abspielen, ohne sie erst herunterzuladen (Vorbild: UsenetStreamer): "
            "H0rSt sucht bei deinen Indexern, bindet die NZB in NzbDAV oder AltMount ein und reicht die Datei per WebDAV "
            "durch. Mit Ordnung nach Qualität, ⚡ für fertige Releases, „Usenet Auto“ und Ersatzsuche.",
            "Kino aus dem Usenet auf jedem Gerät mit Stremio – ohne Platte und ohne Warten auf den Download.",
            "NzbDAV oder AltMount, mindestens einen Indexer (Newznab oder binsearch) und einen Usenet-Provider (in NzbDAV "
            "eingetragen). Von unterwegs eine HTTPS-Adresse.", standard=False, assistent="laden"),
         _m("downloads", "Herunterladen", "⬇", ["dienste"],
            "Die Zentrale für deine Download-Programme: NZBGet (auch direkt in der App), SABnzbd, NzbDAV und AltMount "
            "(Usenet streamen ohne Download), rustnzb, "
            "qBittorrent, Transmission, Deluge, ASUS Download Master – dazu Sonarr, Radarr, Lidarr, Seerr, "
            "Prowlarr und Pi-hole.",
            "Alles an einem Ort steuern: Warteschlange, Tempo, Kalender, Anfragen, Werbefilter.",
            "Mindestens ein Download-Programm oder Dienst – oder NZBGet in der App einschalten.",
            assistent="laden", docker="Läuft auch im Docker-Verbund: Pi-hole richtet sich dort beim ersten Start "
                                     "selbst ein."),
         _m("xdcc", "XDCC", "💬", ["xdcc"],
            "Dateien aus IRC-Kanälen (XDCC) suchen und laden – eine Suche über xdcc.eu, xdcc.it, xdcc.info, xdcc.rocks, xdccsearch.com und nibl.",
            "Seltene Dateien und Anime-Releases, die es sonst kaum gibt.", "Nichts.", standard=False),
         _m("ember", "Ember (eD2k/Kad)", "🔥", ["ember"],
            "Das eD2k- und Kad-Netz wie bei eMule: suchen, sammeln, an den Download Master weitergeben.",
            "Alte und seltene Dateien aus dem Tauschnetz.",
            "Ember auf einem PC oder Server, oder den ASUS Download Master am Router.", standard=False),
     ]},
    {"id": "zuhause", "name": "Zuhause", "symbol": "⌂", "gruppe": "g:zuhause",
     "text": "Dein Heimnetz an einem Ort: Speicher, Kameras, Licht, Videochat und eigene Webseiten.",
     "module": [
         _m("heim", "Heim & Speicher", "⌂", ["heim"],
            "Deine Speicher im Heimnetz: ASUS AiCloud, Nextcloud, Synology und andere WebDAV-Speicher, dazu "
            "Heim-Links und ein eigener FTP-Server.",
            "Eigene Filme, Musik und Dateien durchsuchen und abspielen – auf jedem Gerät.",
            "Einen Speicher mit WebDAV oder FTP – oder nur die Heim-Links nutzen.", assistent="speicher"),
         _m("kameras", "Kameras", "📷", ["kameras"],
            "IP-Webcams live ansehen, Fotos auf Knopfdruck und Überwachung im festen Abstand.",
            "Ein Blick nach Hause, von jedem Gerät aus. Ein altes Handy mit „IP Webcam“ reicht als Kamera.",
            "Eine Kamera mit MJPEG-, Einzelbild-, HLS- oder RTSP-Adresse.", standard=False, assistent="kamera"),
         _m("videochat", "Videochat", "🎥", ["videochat"],
            "Video- und Sprachchat mit Textnachrichten und Fotos zwischen deinen Geräten – direkt von Gerät zu "
            "Gerät, ohne fremde Server.",
            "Gegensprechanlage, Babyfon oder einfach Hallo sagen – im eigenen Netz.",
            "Die App oder einen Browser über den HTTPS-Zugang, den H0rSt selbst einrichtet.", standard=False),
         _m("smarthome", "Smart Home & Fernseher", "💡", ["licht"],
            "Philips Hue (Licht), dazu alle Fernseher und Lautsprecher wie bei Castify: Chromecast, Google TV, Nest, "
            "Smart-TVs mit DLNA, Roku und Receiver mit Enigma2 (Dreambox, Vu+) – plus Sprachbefehle per Webhook.",
            "Licht schalten, und Filme, Live-TV, Musik und Radio auf den großen Bildschirm schicken und dort steuern – "
            "auch per Telegram oder Sprache. Umgekehrt finden Fernseher und Receiver H0rSt als Medienserver (DLNA).",
            "Eine Hue-Bridge oder Geräte im selben WLAN. Das Senden (📺) geht überall, auch wenn dieser Reiter abgedockt ist.",
            assistent="zuhause"),
         _m("webhosting", "Webhosting", "🌐", ["webhosting"],
            "Eigene Webseiten und Foren mit einem Klick: phpBB, WordPress, Adminer, WoltLab – mit MariaDB und "
            "phpMyAdmin.",
            "Das eigene Forum oder die Familienseite, im Heimnetz gehostet.",
            "Den Docker-Baustein „web“ oder einen eigenen Webserver mit PHP.", standard=False,
            docker="Dockt als eigener Docker-Baustein an: docker compose --profile web up -d"),
         _m("vx", "vxparser", "🧪", ["vx"],
            "vxparser in Termux steuern: Listen, Links und Eingaben, ohne Terminal.",
            "Für alle, die vxparser schon nutzen.", "Termux mit vxparser auf dem Gerät.", standard=False),
         _m("apps", "Apps & Startbildschirm", "▦", ["apps"],
            "Alle Apps dieses Geräts starten – und H0rSt auf Wunsch als Startbildschirm, der den Home-Bildschirm "
            "ersetzt.",
            "Ein Gerät, eine Oberfläche: Fernseher-Box oder Tablet ganz auf H0rSt.",
            "Die App (im Browser gibt es diesen Bereich nicht).", nur_app=True),
     ]},
    {"id": "schutz", "name": "Schutz", "symbol": "🛡", "gruppe": None,
     "text": "Sicher unterwegs und zu Hause.",
     "module": [
         _m("sicherheit", "Sicherheit", "🛡", ["sicherheit"],
            "VPN (WireGuard), Tor, I2P, Proxy, eine Notbremse und Private DNS – mit Prüfung, was Anbieter von "
            "dir sehen.",
            "Anbieter sehen nicht deine eigene Adresse; unterwegs bleibt alles verschlüsselt.",
            "Für VPN einen Zugang (z. B. Mullvad oder die eigene FRITZ!Box), für Tor die App Orbot.",
            assistent="sicherheit"),
         _m("passwort_tresor", "Passwort-Tresor", "🔐", ["tresor"],
            "pass-kompatible Passwörter und Einmalcodes: Einträge liegen OpenPGP-verschlüsselt in einem Ordner "
            "oder Git-Repository, optional gemeinsam mit Password Store auf Android. Mit Suche, Passwort-Generator, "
            "TOTP, Git-Abgleich und Erkennung von Passkey-Dateien (Vorbild: Password Store, GPL-3.0).",
            "Passwörter, Zugangsdaten und Einmalcodes an einem Ort – ohne Cloud und ohne Klartext auf der Platte. "
            "Derselbe Tresor funktioniert in H0rSt, auf dem PC und in Password Store auf Android.",
            "GnuPG mit einem Schlüsselpaar (auf PC/Pi meist schon da). Für den Abgleich ein Git-Repository. "
            "Passkeys selbst bleiben der Android-App vorbehalten; H0rSt zeigt sie nur an.",
            standard=False, assistent="sicherheit"),
     ]},
]

FEST = ["start", "einstellungen"]  # immer da: ohne sie kaeme man nicht zurueck
MODULE = {m["id"]: m for w in WELTEN for m in w["module"]}


class BaukastenFehler(ValueError):
    pass


def _navigation(daten):
    e = einstellungen.pruefe((daten or {}).get(einstellungen.SCHLUESSEL))
    return {x["id"]: x["an"] for x in e["navigation"]}, e


def _sprache(daten):
    s = (daten or {}).get(einstellungen.SPRACHEN) or {}
    wert = {k: ", ".join(v) if isinstance(v, list) else str(v or "") for k, v in s.items()}
    for eintrag in SPRACHEN:
        if all(wert.get(k, "") == v for k, v in eintrag["werte"].items()):
            return eintrag["id"]
    return ""


def zustand(daten):
    """Alles fuer den Rundgang: Katalog mit dem aktuellen Stand (angedockt oder nicht)."""
    nav, e = _navigation(daten)
    b = (daten or {}).get(SCHLUESSEL) or {}
    an = {m["id"]: all(nav.get(t, True) for t in m["tabs"]) for m in MODULE.values()}
    # erster Rundgang mit unveraenderter Navigation (alles sichtbar): die Grundauswahl vorschlagen
    werkszustand = not b.get("fertig") and all(an.values())
    welten = []
    for w in WELTEN:
        welten.append(dict(w, module=[dict(m, an=an[m["id"]], vorschlag=m["standard"] if werkszustand else an[m["id"]])
                                      for m in w["module"]]))
    layout = next((l["id"] for l in LAYOUTS if all(e.get(k) == v for k, v in l["werte"].items())), "")
    return {"fertig": bool(b.get("fertig")), "version": VERSION, "aufbau": AUFBAU, "welten": welten,
            "sprachen": SPRACHEN, "sprache": _sprache(daten), "layouts": LAYOUTS, "layout": layout,
            "akzent": e.get("akzent"), "startanimation": e.get("startanimation")}


def anwenden(daten, wahl):
    """Auswahl des Rundgangs uebernehmen: {"module": [ids], "sprache", "layout", "akzent", "startanimation"}
    (jeder Teil optional) oder {"ueberspringen": true}. Danach gilt der Baukasten als erledigt."""
    if not isinstance(wahl, dict):
        raise BaukastenFehler("JSON-Objekt erwartet")
    if not wahl.get("ueberspringen"):
        neu = {}
        if "module" in wahl:
            if not isinstance(wahl["module"], list):
                raise BaukastenFehler("module muss eine Liste sein")
            an = {str(m) for m in wahl["module"]}
            unbekannt = an - set(MODULE)
            if unbekannt:
                raise BaukastenFehler("Unbekanntes Modul: %s" % ", ".join(sorted(unbekannt)))
            nav, _ = _navigation(daten)
            schalter = {}
            for w in WELTEN:
                for m in w["module"]:
                    for t in m["tabs"]:
                        schalter[t] = m["id"] in an
                if w["gruppe"]:
                    schalter[w["gruppe"]] = any(m["id"] in an for m in w["module"])
            schalter["g:party"] = "party" in an  # eigene Ueberschrift fuer das Party-Modul
            e = einstellungen.pruefe(daten.get(einstellungen.SCHLUESSEL))
            neu["navigation"] = [{"id": x["id"], "an": schalter.get(x["id"], x["an"])} for x in e["navigation"]]
        if wahl.get("sprache"):
            eintrag = next((s for s in SPRACHEN if s["id"] == wahl["sprache"]), None)
            if not eintrag:
                raise BaukastenFehler("Unbekannte Sprache")
            neu.update(eintrag["werte"])
        if wahl.get("layout"):
            eintrag = next((l for l in LAYOUTS if l["id"] == wahl["layout"]), None)
            if not eintrag:
                raise BaukastenFehler("Unbekanntes Layout")
            neu.update(eintrag["werte"])
        for k in ("akzent", "startanimation"):
            if wahl.get(k):
                neu[k] = wahl[k]
        if neu:
            try:
                einstellungen.aendern(daten, neu)
            except einstellungen.EinstellungsFehler as fehler:
                raise BaukastenFehler(str(fehler))
    daten[SCHLUESSEL] = {"fertig": True, "version": VERSION, "zeit": int(time.time())}
    return zustand(daten)


def neu_starten(daten):
    """Rundgang beim naechsten Oeffnen wieder zeigen."""
    daten[SCHLUESSEL] = dict(daten.get(SCHLUESSEL) or {}, fertig=False)
    return zustand(daten)
