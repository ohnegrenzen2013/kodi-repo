"""Dank-Liste (Einstellungen -> Ueber): wer die Zutaten fuer H0rSt gebraut hat, mit Laempchen.

Der Grundsatz UNiQuanteX (README, WISSEN.md 7) vergibt zwei Arten von Dank:

  * Hat eine App eine eigene Oberflaeche UND ist deren Palette belegbar, wird daraus ein Style
    [ "Name" @ H0rSt ] (seite.css). Das sind ARVIO, Stremio, Nuvio, StreamCloud, ROGplay,
    Vyxel Apps, Jellyfin, Winlator, Open Generative AI, Opera GX, NOVA, Netflix und GNUnet.
  * Alles andere - Addons, Repos, Quellen, Protokolle, Motoren - steht in dieser Liste.

Je Eintrag sagt "pruef", woran H0rSt erkennt, ob er bei dieser Installation in Betrieb ist:

  "anbieter:<id>"  der Anbieter ist eingerichtet (alle Pflichtfelder gefuellt, anbieter.liste)
  "modul:<id>"     das Modul ist angedockt (baukasten.zustand)
  "pfad:a.b.c"     in den Nutzerdaten steht unter diesem Pfad ein nicht-leerer Wert
  "dabei"          liegt mitgeliefert bei und laeuft immer - kein Laempchen
  "vorbild"        reiner Dank, nichts zu schalten - kein Laempchen

"dabei" und "vorbild" liefern aktiv=None. Das ist Absicht: ein rotes Laempchen unter einem
Entwicklernamen liest sich wie ein Urteil ueber ihn und nicht wie der Zustand einer Installation,
und ein gruenes unter mitgeliefertem Code sagt nichts. Gezeigt wird ein Laempchen nur da, wo es
wirklich einen Zustand gibt.

Aktiv heisst eingerichtet oder eingeschaltet, nicht erreichbar. Erreichbarkeit steht auf der
Startseite unter "was gerade laeuft"; diese Seite antwortet ohne Netz.

Schnittstelle: GET /api/dank -> {titel, untertitel, arten, gruppen: [{art, name, eintraege: [...]}]}
"""

TITEL = ("Thanks go's out @ all Developers they're brewing the ingredients for \"m0Dular - h0rSt\" "
         "and To the people who support UNiQuanteX, and a big thank you 4 @ll people's they thinking "
         "about things")

UNTERTITEL = ("Alles, was H0rSt an fremder Arbeit nutzt: Addons, Repos, Quellen, Protokolle und Motoren. "
              "Ein Laempchen steht nur dort, wo es etwas zu schalten gibt - gruen heisst eingerichtet "
              "oder angedockt, rot heisst vorhanden, aber bei dir nicht in Betrieb. Wer eine eigene "
              "Oberflaeche mit belegbarer Palette hat, bekommt stattdessen einen Style "
              "(Darstellung -> Heim-Styles).")

ARTEN = [
    ("quelle", "Quellen", "Woher Filme, Serien, Sender und Dateien kommen."),
    ("konto", "Konten & Abgleich", "Dienste mit eigenem Zugang, die H0rSt anbindet."),
    ("addon", "Addons & Protokolle", "Fremde Schnittstellen, die H0rSt spricht oder bereitstellt."),
    ("werkzeug", "Werkzeuge", "Programme, die H0rSt aufruft, wenn sie da sind."),
    ("dabei", "Liegt bei", "Fremdcode, der unveraendert mitgeliefert wird - laeuft immer mit."),
    ("vorbild", "Vorbilder", "Apps und Projekte, von denen Ideen stammen, in eigenem Code nachgebaut."),
]

EINTRAEGE = [
    # --- Quellen ---
    {"id": "easynews", "name": "Easynews", "art": "quelle", "pruef": "anbieter:easynews",
     "was": "Usenet-Suche wie im Members-Bereich, mit Vorschaubildern; Streams laufen ueber H0rSt.",
     "url": "https://easynews.com", "lizenz": ""},
    {"id": "archive", "name": "Internet Archive", "art": "quelle", "pruef": "anbieter:archive",
     "was": "Freie Filme und Aufnahmen aus archive.org, samt Vorschaubildern und Schlagwoertern.",
     "url": "https://archive.org", "lizenz": ""},
    {"id": "mediathek", "name": "MediathekViewWeb", "art": "quelle", "pruef": "anbieter:mediathek",
     "was": "Die Mediatheken der oeffentlich-rechtlichen Sender als Quelle.",
     "url": "https://mediathekviewweb.de", "lizenz": ""},
    {"id": "jellyfin", "name": "Jellyfin", "art": "quelle", "pruef": "anbieter:jellyfin",
     "was": "Dein eigener Medienserver als Quelle (Direct Play). Hat als einziger hier auch einen Style.",
     "url": "https://github.com/jellyfin/jellyfin-web", "lizenz": "GPL-2.0"},
    {"id": "emby", "name": "Emby", "art": "quelle", "pruef": "anbieter:emby",
     "was": "Dein eigener Medienserver als Quelle. Kein Style: die offenen Teile haben keine Theme-Dateien.",
     "url": "https://emby.media", "lizenz": ""},
    {"id": "plex", "name": "Plex", "art": "quelle", "pruef": "anbieter:plex",
     "was": "Dein eigener Medienserver als Quelle. Kein Style: Oberflaeche proprietaer, Palette nicht belegbar.",
     "url": "https://plex.tv", "lizenz": ""},
    {"id": "radiobrowser", "name": "radio-browser.info", "art": "quelle", "pruef": "modul:radio",
     "was": "Ueber 50.000 Internetradio-Sender, ohne Konto, nur zuletzt erreichbare.",
     "url": "https://www.radio-browser.info", "lizenz": "freies Verzeichnis"},
    {"id": "mjh", "name": "i.mjh.nz (Matt Huisman)", "art": "quelle", "pruef": "pfad:livetv.kostenlos",
     "was": "Senderdaten, Logos und Programm fuer Samsung TV Plus und Pluto TV - dieselbe Quelle wie die "
            "SlyGuy-Addons fuer Kodi.",
     "url": "https://i.mjh.nz", "lizenz": ""},
    {"id": "sexlist", "name": "Sex List (plugin.video.sexlist)", "art": "quelle", "pruef": "modul:ab18",
     "was": "Die Seiten-Module in Ab 18 stammen unveraendert aus diesem Kodi-Addon. Kein Link, weil keine "
            "offizielle Quelle belegbar ist.",
     "url": "", "lizenz": "Kodi-Addon 1.3.0"},

    # --- Konten & Abgleich ---
    {"id": "trakt", "name": "Trakt", "art": "konto", "pruef": "pfad:trakt.app.client_id",
     "was": "Merkliste, Verlauf und Weiterschauen je Profil abgleichen; oeffentliche Listen als Katalog.",
     "url": "https://trakt.tv", "lizenz": ""},
    {"id": "simkl", "name": "Simkl", "art": "konto", "pruef": "pfad:simkl.app.client_id",
     "was": "Merkliste, Verlauf und Weiterschauen je Profil abgleichen - wie Trakt, eigene API-Form.",
     "url": "https://simkl.com", "lizenz": ""},
    {"id": "mdblist", "name": "MDBList", "art": "konto", "pruef": "pfad:kataloge.mdblist_key",
     "was": "Oeffentliche Listen als Katalog, per Adresse oder Suche.",
     "url": "https://mdblist.com", "lizenz": ""},
    {"id": "gdrive", "name": "Google Drive", "art": "konto", "pruef": "pfad:gdrive.konto.refresh_token",
     "was": "Speicherort fuer Komplettsicherungen jeder Art.",
     "url": "https://drive.google.com", "lizenz": ""},
    {"id": "tmdb", "name": "TMDb", "art": "konto", "pruef": "anbieter:tmdb",
     "was": "Metadaten und Vorschaubilder, wo der Anbieter selbst keine liefert. Braucht einen API-Schluessel.",
     "url": "https://www.themoviedb.org", "lizenz": ""},
    {"id": "opensubtitles", "name": "OpenSubtitles", "art": "konto", "pruef": "anbieter:opensubtitles",
     "was": "Untertitel zu Filmen und Folgen.",
     "url": "https://www.opensubtitles.com", "lizenz": ""},

    # --- Addons & Protokolle ---
    {"id": "cinemeta", "name": "Cinemeta (Stremio)", "art": "addon", "pruef": "dabei",
     "was": "Titel, Poster und Folgenlisten ohne API-Schluessel - die Metadaten hinter Suche und Entdecken.",
     "url": "https://www.stremio.com", "lizenz": ""},
    {"id": "mhub", "name": "mHub / MediaHubMX", "art": "addon", "pruef": "pfad:mhub.an",
     "was": "H0rSt als mHub-Addon und Tracker (Addon Protocol v2).",
     "url": "https://www.mediahubmx.com", "lizenz": ""},
    {"id": "sponsorblock", "name": "SponsorBlock", "art": "addon", "pruef": "pfad:youtube.sponsorblock",
     "was": "Gemeldete Sponsor-Abschnitte, Intros und Abspaenne in YouTube ueberspringen.",
     "url": "https://sponsor.ajay.app", "lizenz": ""},
    {"id": "apkmb", "name": "APKMB", "art": "addon", "pruef": "pfad:appstore.quellen.apkmb",
     "was": "Quelle im App-Store, neben F-Droid, IzzyOnDroid, GitHub und Codeberg.",
     "url": "https://apkmb.com", "lizenz": ""},
    {"id": "xrel", "name": "xREL", "art": "addon", "pruef": "dabei",
     "was": "Die neuesten Scene-Releases als Katalog, mit IMDb-Kennung (API v2).",
     "url": "https://www.xrel.to", "lizenz": ""},
    {"id": "nuviobadges", "name": "Nuvio Fusion Badges", "art": "addon", "pruef": "pfad:badges.sets",
     "was": "Badge-Sets im Nuvio-Format per Raw-Adresse einbinden (bis zu drei).",
     "url": "https://nuvio.wiki/settings/badges", "lizenz": ""},
    {"id": "nuvio_mobile", "name": "Nuvio Mobile", "art": "addon", "pruef": "modul:nuvio",
     "was": "Der Client zum Modul-Host: liegt im Repo (NuvioMobile/, Kotlin Multiplatform), haengt H0rSt als "
            "Stremio-Addon ein und nutzt /api/nuvio fuer Adressen und Funktionen.",
     "url": "https://github.com/NuvioMedia/NuvioMobile", "lizenz": "GPL-3.0"},

    # --- Werkzeuge ---
    {"id": "ytdlp", "name": "yt-dlp", "art": "werkzeug", "pruef": "modul:youtube",
     "was": "Holt Video-Adressen fuer YouTube und Ab 18, ohne Werbung und ohne Konto.",
     "url": "https://github.com/yt-dlp/yt-dlp", "lizenz": "Unlicense"},
    {"id": "ffmpeg", "name": "FFmpeg", "art": "werkzeug", "pruef": "modul:youtube",
     "was": "Download und Aufnahme auf Server, PC und Pi; in der App die NextLib-Decoder.",
     "url": "https://ffmpeg.org", "lizenz": "LGPL/GPL"},
    {"id": "ember", "name": "Ember-P2P", "art": "werkzeug", "pruef": "modul:ember",
     "was": "eD2K und KAD: H0rSt steuert Ember auf demselben Rechner (Start, Stopp, Fortschritt, Listen) und "
            "blendet den Reiter per Schalter aus. Vorbild fuer den hellen Blau-Rose-Style; kein fremder Code uebernommen.",
     "url": "https://github.com/untaimed18/Ember-P2P", "lizenz": "GPL-3.0"},
    {"id": "emuleese", "name": "eMule eSE LiveTV", "art": "vorbild", "pruef": "vorbild",
     "was": "eMule-0.70b-Zweig fuer dezentrales Live-HLS ueber eD2K und Kad, mit Dashboard und RTMP-Eingang. "
            "Vorbild fuer den Orange-Pink-Style und die eSE-Einstellungen; H0rSt startet die App nicht.",
     "url": "https://github.com/diad87/eMule-eSE-LiveTV", "lizenz": "GPL-2.0"},
    {"id": "vxparser", "name": "vxparser", "art": "werkzeug", "pruef": "modul:vx",
     "was": "Zugriff und Steuerung; der Magenta-EPG-Grabber ist von dort uebernommen.",
     "url": "https://github.com/Mastaaa1987/vxparser", "lizenz": ""},

    # --- Liegt bei ---
    {"id": "hlsjs", "name": "hls.js", "art": "dabei", "pruef": "dabei",
     "was": "HLS im Browser-Player, mit getrennten Tonspuren. Liegt unveraendert bei.",
     "url": "https://github.com/video-dev/hls.js", "lizenz": "Apache-2.0"},
    {"id": "qrcodegen", "name": "QR Code generator (Project Nayuki)", "art": "dabei", "pruef": "dabei",
     "was": "QR-Codes fuer Koppeln und Einladungen. Liegt unveraendert bei.",
     "url": "https://www.nayuki.io/page/qr-code-generator-library", "lizenz": "MIT"},
    {"id": "media3", "name": "Media3 ExoPlayer + NextLib", "art": "dabei", "pruef": "dabei",
     "was": "Der Player der Android-App samt FFmpeg-Decodern.",
     "url": "https://github.com/androidx/media", "lizenz": "Apache-2.0 / GPL-3.0"},
    {"id": "geckoview", "name": "GeckoView", "art": "dabei", "pruef": "dabei",
     "was": "Der Motor der Brause, des Browsers in der H0rSt-App.",
     "url": "https://mozilla.github.io/geckoview/", "lizenz": "MPL-2.0"},
    {"id": "schriften", "name": "Inter, Plus Jakarta Sans, Outfit", "art": "dabei", "pruef": "dabei",
     "was": "Die Schriften der Styles, zusammen rund 110 KB; der Browser laedt eine erst bei Bedarf.",
     "url": "https://openfontlicense.org", "lizenz": "SIL OFL"},

    # --- Vorbilder ---
    {"id": "arvio", "name": "ARVIO", "art": "vorbild", "pruef": "vorbild",
     "was": "Vorbild fuer Suche, Entdecken, Einstellungen und Medienserver als Quelle. Hat einen Style.",
     "url": "https://github.com/ProdigyV21/ARVIO", "lizenz": "Apache-2.0"},
    {"id": "vyxel", "name": "Vyxel Apps", "art": "vorbild", "pruef": "vorbild",
     "was": "Vorbild fuer den App-Store. Hat einen Style.",
     "url": "https://github.com/NikhilKain/vyxel-apps", "lizenz": "AGPL-3.0"},
    {"id": "usenetstreamer", "name": "UsenetStreamer", "art": "vorbild", "pruef": "vorbild",
     "was": "Vorbild fuer das Usenet-Streaming: Indexer durchsuchen, nach Qualitaet ordnen, Sofort-Streams aus NzbDAV, Smart Play und Gesundheitspruefung. Kein Code uebernommen, alles in Python nachgebaut.",
     "url": "https://github.com/Sanket9225/UsenetStreamer", "lizenz": "ISC (laut package.json)"},
    {"id": "netflix", "name": "Netflix", "art": "vorbild", "pruef": "vorbild",
     "was": "Vorbild fuer den Netflix-Stil (Bottom-Navigation, Hero mit Meine-Liste, Episodenkarten, "
            "Mein Netflix) - nach Screenshots nachgebaut, kein Quellcode-Zugriff. Hat einen Style.",
     "url": "https://play.google.com/store/apps/details?id=com.netflix.mediaclient", "lizenz": ""},
    {"id": "jacktook", "name": "Jacktook", "art": "vorbild", "pruef": "vorbild",
     "was": "Das Kodi-Addon, in dem H0rSt als Stremio-Addon laeuft.",
     "url": "https://github.com/Sam-Max/plugin.video.jacktook", "lizenz": ""},
    {"id": "kodi", "name": "Kodi / XBMC", "art": "vorbild", "pruef": "vorbild",
     "was": "Referenz fuer Kodi-Addons ohne Kodi, Kodi-Skins und cacert.pem.",
     "url": "https://github.com/xbmc/xbmc", "lizenz": "GPL-2.0"},
    {"id": "nzb360", "name": "nzb360", "art": "vorbild", "pruef": "vorbild",
     "was": "Vorbild fuer die Medienverwaltung unter Herunterladen.",
     "url": "https://nzb360.com", "lizenz": ""},
    {"id": "cloudstream", "name": "CloudStream", "art": "vorbild", "pruef": "vorbild",
     "was": "Vorbild fuer den Rundgang des m0dul-Baukastens.",
     "url": "https://github.com/recloudstream/cloudstream", "lizenz": "GPL-3.0"},
    {"id": "streamwatch", "name": "StreamWatch", "art": "vorbild", "pruef": "vorbild",
     "was": "Vorbild fuer Gemeinsam schauen. Kein Link, weil keine offizielle Quelle belegbar ist.",
     "url": "", "lizenz": ""},
    {"id": "blumovies", "name": "Blu Movies", "art": "vorbild", "pruef": "vorbild",
     "was": "Vorbild fuer den Aufbau von Ab 18: Startseite mit dem Neuesten je Seite, Genres ueber alle "
            "Seiten. Nachgebaut, ohne Katalog, Werbung und Analyse. Kein Link, weil keine offizielle "
            "Quelle belegbar ist.",
     "url": "", "lizenz": ""},

    # --- KI, Video & Werkzeuge ---
    {"id": "passwordstore", "name": "Password Store (pando85)", "art": "vorbild", "pruef": "vorbild",
     "was": "pass-kompatible Passwörter, OpenPGP, TOTP, Git und Passkeys – Vorbild für den Passwort-Tresor.",
     "url": "https://github.com/pando85/Android-Password-Store", "lizenz": "GPL-3.0"},
    {"id": "fixupxer", "name": "FixupXer (NeatCode Labs)", "art": "vorbild", "pruef": "vorbild",
     "was": "Lokaler Link-Reiniger: Tracking-Parameter, Frontends und Private Link Guard – Vorbild für den Link-Reiniger unter Sicherheit.",
     "url": "https://fixupxer.com", "lizenz": "GPL-3.0-or-later"},
    {"id": "operagx", "name": "Opera GX", "art": "vorbild", "pruef": "vorbild",
     "was": "GX Corner, Neon-Optik, Shortcut-Leiste und GX Control – Vorbild für O|Brause|GX; eigener Code.",
     "url": "https://www.opera.com/de/gx", "lizenz": "proprietär (nur Vorbild)"},
    {"id": "nova", "name": "NOVA Video Player", "art": "vorbild", "pruef": "vorbild",
     "was": "Freier Video-Player für Telefon, Tablet und Android TV: Netzwerkordner per SMB, WebDAV, FTP und UPnP, "
            "Metadaten und Untertitel. Hat einen Style; H0rSt übernimmt die belegbare Palette, keinen fremden Code.",
     "url": "https://github.com/nova-video-player/aos-AVP", "lizenz": "Apache-2.0"},
    {"id": "gnunet", "name": "GNUnet", "art": "vorbild", "pruef": "vorbild",
     "was": "Freier Netzwerk-Stack für sichere, verteilte Anwendungen (GNS, Filesharing, Conversation, Messenger). "
            "Vorbild für die GNUnet-Werkzeugliste unter Sicherheit und Namensgeber des hellen Styles; H0rSt startet "
            "GNUnet nicht selbst.",
     "url": "https://www.gnunet.org", "lizenz": "AGPL-3.0-or-later"},
    {"id": "payloaddumper", "name": "Payload Dumper (rajmani7584)", "art": "werkzeug", "pruef": "vorbild",
     "was": "OTA.zip und payload.bin direkt auf Android entpacken; unter USB-Tools verlinkt.",
     "url": "https://github.com/rajmani7584/Payload-Dumper-Android", "lizenz": "GPL-3.0"},
    {"id": "opengenerativeai", "name": "Open Generative AI (Anil-matcha)", "art": "vorbild", "pruef": "vorbild",
     "was": "Namensgeber des Schwarzglas-Styles und Vorbild für ein Studio aus Bild und Video: ein offenes "
            "Next.js-Frontend, dessen Modelle über Muapi laufen. H0rSt übernimmt die belegbare Palette, nicht den "
            "kostenpflichtigen Dienst.",
     "url": "https://github.com/Anil-matcha/Open-Generative-AI", "lizenz": "MIT"},
    {"id": "locallyuncensored", "name": "Locally Uncensored", "art": "vorbild", "pruef": "vorbild",
     "was": "Freies lokales KI-Studio (AGPL-3.0) mit Chat, Bildern und Videos über ComfyUI. H0rSt erkennt seine "
            "lokale API (Port 8129) und die Remote-Oberfläche (11435) im Portal.",
     "url": "https://github.com/PurpleDoubleD/locally-uncensored", "lizenz": "AGPL-3.0"},
    {"id": "comfyui", "name": "ComfyUI", "art": "vorbild", "pruef": "vorbild",
     "was": "Freie Knoten-Werkstatt für Bild- und Videomodelle (Wan, Hunyuan, LTX). H0rSt erkennt die "
            "Weboberfläche auf Port 8188 im Portal.",
     "url": "https://github.com/comfyanonymous/ComfyUI", "lizenz": "GPL-3.0"},
    {"id": "wan2gp", "name": "Wan2GP", "art": "vorbild", "pruef": "vorbild",
     "was": "Freie lokale Video- und Bildmodelle (Wan 2.x, Hunyuan, LTX) für NVIDIA/AMD. H0rSt erkennt die "
            "Gradio-Oberfläche auf Port 7860 im Portal.",
     "url": "https://github.com/deepbeepmeep/Wan2GP", "lizenz": ""},
    {"id": "modeltonpu", "name": "Model-To-NPU (VitalikDen0)", "art": "vorbild", "pruef": "vorbild",
     "was": "Snapdragon-8-Elite-Experiment (PolyForm Noncommercial): SDXL nativ auf der Hexagon-NPU und ein "
            "WAN-2.1-Workspace. Kein HTTP-Dienst, deshalb nur als Vorbild geführt.",
     "url": "https://github.com/VitalikDen0/Model-To-NPU", "lizenz": "PolyForm Noncommercial 1.0.0"},
    {"id": "mtmanager", "name": "MT Manager", "art": "vorbild", "pruef": "vorbild",
     "was": "Datei- und APK-Werkzeugkasten (proprietaer). Vorbild fuer den Style und den MCP-Preset: der lokale "
            "APK-MCP-Dienst auf Port 8787 wird von H0rSt als Werkzeugserver angebunden. Kein MT-Code uebernommen, "
            "keine APK mitgeliefert.",
     "url": "https://mt2.cn", "lizenz": "proprietaer"},
    {"id": "shizuku", "name": "Shizuku (yangFenTuoZi)", "art": "vorbild", "pruef": "vorbild",
     "was": "ADB- und Root-Rechte fuer normale Apps ueber einen Dienst und die rish-Shell. Vorbild fuer den "
            "Material-3-Style und die Rechtebruecke: H0rSt merkt sich die Shizuku-Einstellungen und baut "
            "rish-Befehle, fuehrt sie aber nicht aus. Kein Code uebernommen, keine APK mitgeliefert.",
     "url": "https://github.com/yangFenTuoZi/Shizuku", "lizenz": "Apache-2.0"},
    {"id": "keepadb", "name": "KeepADB (m00sfett)", "art": "vorbild", "pruef": "vorbild",
     "was": "Wireless Debugging wach halten ueber Netzregel, vertraute Zugangspunkte, Kraft-Modus und Webhook. "
            "Vorbild fuer den Style und die KeepADB-Regeln: H0rSt bewertet Netze, maskiert Adressen und baut "
            "Schaltbefehle, fuehrt sie aber nicht aus. Kein Code uebernommen, keine APK mitgeliefert.",
     "url": "https://github.com/m00sfett/KeepADB", "lizenz": "AGPL-3.0-or-later"},
    {"id": "omnisearch", "name": "OmniSearch (Eul45)", "art": "vorbild", "pruef": "vorbild",
     "was": "Windows-Dateisuche mit Android-Begleit-App. Vorbild fuer den hellen Style und die lokale "
            "Dateisuche; H0rSt durchsucht nur die selbst freigegebenen Orte. Kein Code uebernommen.",
     "url": "https://github.com/Eul45/omni-search", "lizenz": "MIT"},
    {"id": "nsfw_data_scraper", "name": "NSFW Data Scraper (alex000kim)", "art": "vorbild", "pruef": "vorbild",
     "was": "Vorbild fuer die lokale Bild-Datensatz-Pflege: Kategorien als Ordner, kaputte Bilder aussortieren, "
            "Duplikate erkennen und train/test aufteilen. Die Scraper- und Download-Skripte sind bewusst nicht "
            "uebernommen; H0rSt laedt keine fremden Bilder.",
     "url": "https://github.com/alex000kim/nsfw_data_scraper", "lizenz": "MIT"},
    {"id": "discord_nsfw_bot", "name": "NSFW Discord Bot (VictorMoises)", "art": "vorbild", "pruef": "vorbild",
     "was": "Vorbild fuer den Discord-Bildbot: Kategorien wie 4k, amateur, hentai und uniform, Zufallsbilder und "
            "die Warnung vor Nicht-NSFW-Kanaelen. H0rSt baut den Versand als Webhook nach, ohne fremden Code, "
            "ohne Bot-Token und ohne Gateway; die Bilder bleiben bei den Ab-18-Seiten. Keine Lizenz angegeben.",
     "url": "https://github.com/VictorMoises/NSFW", "lizenz": "keine Lizenz angegeben"},
    {"id": "qwen21_nsfw_pose", "name": "Qwen21 NSFW Pose Skill (Arekejoker)", "art": "vorbild", "pruef": "vorbild",
     "was": "Vorbild fuer das Qwen-Image-2.1-Pose-Studio: T2I-/Edit-Workflows, Pose-Stufen L0–L3 und die "
            "VNCCS-Pose-Bibliothek. H0rSt uebernimmt nur die Workflow-Struktur und die Bedienung; Modelle, LoRAs, "
            "explizite Prompts und Beispielbilder bleiben in ComfyUI bzw. beim Nutzer.",
     "url": "https://github.com/Arekejoker/qwen21-nsfw-pose-skill", "lizenz": "Apache-2.0"},
    {"id": "magicwx", "name": "MagicWX", "art": "vorbild", "pruef": "vorbild",
     "was": "Offline-Chat und SD-1.5-Bilder auf Android (MIT): RWKV/ONNX/MediaPipe fuer Text, MNN fuer Bilder. "
            "Vorbild fuer den gruenen Material-3-Style und den Parameterblock, der sich in MagicWX importieren laesst; "
            "kein fremder Code uebernommen.",
     "url": "https://github.com/Pangu-Immortal/MagicWX", "lizenz": "MIT"},
    {"id": "opencode", "name": "OpenCode Zen", "art": "vorbild", "pruef": "vorbild",
     "was": "KI-Anbieter mit OpenAI-kompatibler Schnittstelle; H0rSt hat einen Preset für bezahlte Modelle. "
            "Die Free-Modelle sind laut Anbieter nur im OpenCode-Client nutzbar, andere Clients bekommen HTTP 403.",
     "url": "https://opencode.ai/docs/console/api/inference/", "lizenz": "MIT (Client)"},
    # --- Smart Glasses ---
    {"id": "heycyan_ebowwa", "name": "HeyCyanSmartGlassesSDK (ebowwa)", "art": "vorbild", "pruef": "vorbild",
     "was": "BLE-SDK fuer HeyCyan-kompatible Smart Glasses (iOS Objective-C + Android Kotlin). "
            "Liefert das Hardware-Protokoll; kein eigener Python-Code uebernommen.",
     "url": "https://github.com/ebowwa/HeyCyanSmartGlassesSDK", "lizenz": "MIT"},
    {"id": "cyanbridge_fersaiyan", "name": "CyanBridge (FerSaiyan)", "art": "vorbild", "pruef": "vorbild",
     "was": "Alternative Android-App fuer HeyCyan-Glasses: lokale LLM-Inferenz (llama.cpp, LiteRT-LM), "
            "Gemini Live und OpenAI-kompatibler Endpunkt. Modellkatalog und Endpunkt-Typen als Vorbild "
            "fuer das Brille-Tab nachgebaut; kein Style-Klon (Palette nicht belegbar).",
     "url": "https://github.com/FerSaiyan/Alternative-HeyCyan-App-and-SDK", "lizenz": "MIT"},
]


def _pfad_wert(daten, pfad):
    """Wert unter "a.b.c" aus den Nutzerdaten, oder None."""
    stelle = daten or {}
    for teil in pfad.split("."):
        if not isinstance(stelle, dict):
            return None
        stelle = stelle.get(teil)
    return stelle


def _aktiv(eintrag, daten, eingerichtet, angedockt):
    pruef = eintrag.get("pruef") or "vorbild"
    if pruef in ("dabei", "vorbild"):
        return None  # kein Laempchen: nichts zu schalten
    if pruef.startswith("anbieter:"):
        return bool(eingerichtet.get(pruef.split(":", 1)[1]))
    if pruef.startswith("modul:"):
        return bool(angedockt.get(pruef.split(":", 1)[1]))
    if pruef.startswith("pfad:"):
        return bool(_pfad_wert(daten, pruef.split(":", 1)[1]))
    return None


def zustand(daten=None, anbieter=None, welten=None):
    """Die Dank-Liste mit dem Stand dieser Installation.

    anbieter: Liste aus anbieter.liste (fuer "vollstaendig"), welten: aus baukasten.zustand (fuer "an").
    Fehlt eines, gelten die zugehoerigen Eintraege als nicht in Betrieb."""
    eingerichtet = {a["id"]: a.get("vollstaendig") for a in (anbieter or [])}
    angedockt = {}
    for welt in welten or []:
        for modul in welt.get("module") or []:
            angedockt[modul["id"]] = modul.get("an")
    gruppen = []
    for art, name, text in ARTEN:
        eintraege = [dict(e, aktiv=_aktiv(e, daten, eingerichtet, angedockt))
                     for e in EINTRAEGE if e["art"] == art]
        if eintraege:
            gruppen.append({"art": art, "name": name, "text": text, "eintraege": eintraege})
    return {"titel": TITEL, "untertitel": UNTERTITEL, "gruppen": gruppen,
            "anzahl": len(EINTRAEGE)}
