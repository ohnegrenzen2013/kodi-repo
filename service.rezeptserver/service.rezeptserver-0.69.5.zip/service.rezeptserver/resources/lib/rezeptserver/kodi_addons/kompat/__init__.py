"""Ersatz fuer Module, die Python ab 3.12 nicht mehr hat, Kodi 21 (Python 3.11) aber noch: imp, distutils.version,
cgi, imghdr, pipes. Der Ordner steht waehrend eines Plugin-Aufrufs ganz hinten in sys.path – gibt es das echte Modul,
gewinnt es. (Dieser Ordner selbst ist kein Paket fuer H0rSt; die Datei haelt nur die Beschreibung.)"""
