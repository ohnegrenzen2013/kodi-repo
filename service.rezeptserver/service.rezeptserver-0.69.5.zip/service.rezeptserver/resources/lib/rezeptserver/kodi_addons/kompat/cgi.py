"""cgi (bis Python 3.12) – escape, parse_qs, parse_qsl, parse_header."""
import html
from email.message import Message
from urllib.parse import parse_qs, parse_qsl  # noqa: F401


def escape(s, quote=False):
    return html.escape(s, quote=quote)


def parse_header(line):
    m = Message()
    m["content-type"] = line
    werte = m.get_params() or []
    return (werte[0][0] if werte else ""), dict(werte[1:])
