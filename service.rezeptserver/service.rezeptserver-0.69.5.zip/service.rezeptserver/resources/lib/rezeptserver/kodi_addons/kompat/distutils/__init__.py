"""distutils (bis Python 3.11) – nur, was Kodi-Addons davon brauchen: version und util.strtobool."""
