"""distutils.version: LooseVersion und StrictVersion wie bis Python 3.11."""
import re


class Version:
    def __init__(self, vstring=None):
        if vstring:
            self.parse(vstring)

    def __repr__(self):
        return "%s ('%s')" % (self.__class__.__name__, str(self))

    def _cmp(self, other):
        if isinstance(other, str):
            other = self.__class__(other)
        a, b = self._schluessel(), other._schluessel()
        return (a > b) - (a < b)

    def __eq__(self, other):
        return self._cmp(other) == 0

    def __lt__(self, other):
        return self._cmp(other) < 0

    def __le__(self, other):
        return self._cmp(other) <= 0

    def __gt__(self, other):
        return self._cmp(other) > 0

    def __ge__(self, other):
        return self._cmp(other) >= 0

    __hash__ = None


class LooseVersion(Version):
    component_re = re.compile(r"(\d+ | [a-z]+ | \.)", re.VERBOSE)

    def parse(self, vstring):
        self.vstring = vstring
        teile = [x for x in self.component_re.split(vstring) if x and x != "."]
        self.version = [int(x) if x.isdigit() else x for x in teile]

    def __str__(self):
        return self.vstring

    def _schluessel(self):
        # Zahlen vor Text, wie der alte Vergleich es in der Praxis meist tat (ohne TypeError bei gemischten Teilen)
        return [(0, x, "") if isinstance(x, int) else (1, 0, x) for x in self.version]


class StrictVersion(Version):
    version_re = re.compile(r"^(\d+) \. (\d+) (\. (\d+))? ([ab](\d+))?$", re.VERBOSE | re.ASCII)

    def parse(self, vstring):
        m = self.version_re.match(vstring)
        if not m:
            raise ValueError("invalid version number '%s'" % vstring)
        major, minor, patch, pre, prenum = m.group(1, 2, 4, 5, 6)
        self.version = (int(major), int(minor), int(patch or 0))
        self.prerelease = (pre[0], int(prenum)) if pre else None

    def __str__(self):
        v = ".".join(map(str, self.version if self.version[2] else self.version[:2]))
        return v + (self.prerelease[0] + str(self.prerelease[1]) if self.prerelease else "")

    def _schluessel(self):
        return (self.version, (1, "", 0) if self.prerelease is None else (0,) + self.prerelease)
