"""imghdr (bis Python 3.12) – Bildformat an den ersten Bytes erkennen."""


def what(file, h=None):
    if h is None:
        if isinstance(file, str):
            with open(file, "rb") as f:
                h = f.read(32)
        else:
            stelle = file.tell()
            h = file.read(32)
            file.seek(stelle)
    if h[6:10] in (b"JFIF", b"Exif") or h[:3] == b"\xff\xd8\xff":
        return "jpeg"
    if h.startswith(b"\x89PNG\r\n\x1a\n"):
        return "png"
    if h[:6] in (b"GIF87a", b"GIF89a"):
        return "gif"
    if h.startswith(b"RIFF") and h[8:12] == b"WEBP":
        return "webp"
    if h.startswith(b"BM"):
        return "bmp"
    if h[:2] in (b"MM", b"II"):
        return "tiff"
    return None
