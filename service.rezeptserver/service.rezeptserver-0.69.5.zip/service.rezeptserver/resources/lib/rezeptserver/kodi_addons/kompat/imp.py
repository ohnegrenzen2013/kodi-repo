"""imp (bis Python 3.11) – nachgebaut ueber importlib, so weit Kodi-Addons es nutzen."""
import importlib
import importlib.machinery
import importlib.util
import os
import sys
import types

SEARCH_ERROR, PY_SOURCE, PY_COMPILED, C_EXTENSION, PY_RESOURCE, PKG_DIRECTORY = 0, 1, 2, 3, 4, 5
reload = importlib.reload


def new_module(name):
    return types.ModuleType(name)


def get_suffixes():
    return [(s, "rb", C_EXTENSION) for s in importlib.machinery.EXTENSION_SUFFIXES] + \
        [(s, "r", PY_SOURCE) for s in importlib.machinery.SOURCE_SUFFIXES]


def load_source(name, pathname, file=None):
    spec = importlib.util.spec_from_file_location(name, pathname)
    modul = importlib.util.module_from_spec(spec)
    sys.modules[name] = modul
    spec.loader.exec_module(modul)
    return modul


def find_module(name, path=None):
    for ordner in path or sys.path:
        paket = os.path.join(ordner, name)
        if os.path.isfile(os.path.join(paket, "__init__.py")):
            return None, paket, ("", "", PKG_DIRECTORY)
        datei = paket + ".py"
        if os.path.isfile(datei):
            return open(datei, "r", encoding="utf-8"), datei, (".py", "r", PY_SOURCE)
    raise ImportError("No module named %s" % name)


def load_module(name, file, pathname, description):
    try:
        if description[2] == PKG_DIRECTORY:
            return load_source(name, os.path.join(pathname, "__init__.py"))
        return load_source(name, pathname)
    finally:
        if file:
            file.close()


def acquire_lock():
    pass


def release_lock():
    pass


def lock_held():
    return False
