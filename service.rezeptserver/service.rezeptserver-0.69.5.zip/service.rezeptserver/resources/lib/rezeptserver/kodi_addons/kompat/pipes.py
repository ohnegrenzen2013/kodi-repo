"""pipes (bis Python 3.12) – nur quote."""
from shlex import quote  # noqa: F401
