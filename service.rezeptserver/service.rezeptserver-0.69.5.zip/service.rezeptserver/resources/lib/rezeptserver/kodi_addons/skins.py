"""Kodi-Skins als Heim-Style: Farbschemata, Schriften und Hintergruende eines skin.* uebernehmen.

Die Fenster eines Skins (1080i/*.xml) braucht H0rSt nicht – nur, wie er aussieht:
  colors/defaults.xml + colors/<Schema>.xml   <color name="…">AARRGGBB</color>   -> Farben eines Heim-Styles
  <res folder>/Font.xml                       Schrift von font13 (Fliesstext) und die kraeftigste fuer Ueberschriften
  …/backgrounds/*.jpg, resources/fanart.jpg   Hintergruende, resources/screenshot-*.jpg als Vorschau
  media/Textures.xbt                          beim Installieren ausgewaehlte Texturen als PNG nach h0rst/ (xbt.py):
                                              grosse 16:9-Bilder als Hintergruende, eine Fokus- und eine Panel-Textur
Die Namen der Farben sind in jedem Skin anders; zugeordnet wird deshalb nach Wert und Kontrast.
Beim Installieren entpackt H0rSt nur diese Teile (auswahl) – Arctic Zephyr z. B. hat 91 MB, gebraucht werden wenige.
"""

import colorsys
import json
import logging
import os
import re
import xml.etree.ElementTree as ET

from . import xbt

log = logging.getLogger("rezeptserver")

BILD = (".jpg", ".jpeg", ".png", ".webp")
SCHRIFT = (".ttf", ".otf", ".woff", ".woff2")
MAX_HINTERGRUENDE = 40
MAX_BILD = 8 * 1024 * 1024
_HEX = re.compile(r"^[0-9a-fA-F]{8}$|^[0-9a-fA-F]{6}$")
_AKZENT_NAMEN = re.compile(r"(?i)highlight|focus|accent|primary|selected|active|main_?colou?r|theme")
_GRUND_NAMEN = re.compile(r"(?i)^(background|bg|.*_bg|.*background.*|window.*)$")
_FLAECHE_NAMEN = re.compile(r"(?i)panel|dialog|menu|card|info|box|list")
_TEXT_NAMEN = re.compile(r"(?i)text|label|font")
# Texturen aus Textures.xbt
TEXTUR_ORDNER = "h0rst"
MAX_XBT = 128 * 1024 * 1024
MAX_TEXTUR_HINTERGRUENDE = 3
HINTERGRUND_BREITE = 1280
MIN_VIELFALT = 24  # darunter einfarbig: moderne Skins faerben weisse Texturen nur ein – die Farben kommen aus colors/
_KEIN_HINTERGRUND = re.compile(r"(?i)default|fallback|broken|diffuse|flag|overlay|mask|floor|trailer|reflect|shadow|white|black|poster|"
                               r"thumb|icon|logo|weather|spinner|busy|osd|progress|rating|studio|mpaa|square")
_HINTERGRUND_NAME = re.compile(r"(?i)(^|[/_\-])(bg|background|backdrop|wallpaper|fanart|home)")
_FOKUS = re.compile(r"(?i)focus|[_\-]fo\.png$|highlight")
_FOKUS_NICHT = re.compile(r"(?i)scroll|slider|osd|radio|check|spin|seek|progress|unfocus|nofocus|nf\.png$|keyboard|epg|flag|shutdown|power|"
                          r"exit|close|mover|arrow|folder|thumb|poster|icon")
_PANEL = re.compile(r"(?i)contentpanel|panel|dialog[\w-]*back|dialogbg|dialog[/_-]?background|mediaitemdetail|infopanel|box")
_PANEL_NICHT = re.compile(r"(?i)focus|shadow|mirror|reflect|button|flag|icon|scroll|osd|globalsearch")


# --- Auswahl beim Entpacken --------------------------------------------------------------------------------
def res_ordner(addon_root):
    """Ordner der Fenster (<res folder="1080i">) aus der addon.xml; der Standard zuerst."""
    ordner = []
    for ext in addon_root.iter("extension"):
        if ext.get("point") == "xbmc.gui.skin":
            for res in sorted(ext.findall("res"), key=lambda r: r.get("default") != "true"):
                if res.get("folder") and res.get("folder") not in ordner:
                    ordner.append(res.get("folder"))
    return ordner or ["1080i", "720p", "16x9", "21x9"]


def schriften_aus_font_xml(text):
    """(Fliesstext, Ueberschrift): Dateinamen aus dem ersten fontset – font13 und die kraeftigste haeufige Schrift."""
    try:
        fontset = ET.fromstring(text).find("fontset")
    except ET.ParseError:
        return "", ""
    if fontset is None:
        return "", ""
    dateien = [((f.findtext("name") or "").strip(), (f.findtext("filename") or "").strip()) for f in fontset.findall("font")]
    dateien = [(n, d) for n, d in dateien if d]
    if not dateien:
        return "", ""
    haeufig = {}
    for _, d in dateien:
        haeufig[d] = haeufig.get(d, 0) + 1
    text_datei = next((d for n, d in dateien if n == "font13"), max(haeufig, key=haeufig.get))
    kraeftig = [d for d in haeufig if re.search(r"(?i)bold|black|heavy|semibold|medium", os.path.basename(d))]
    titel_datei = max(kraeftig, key=lambda d: haeufig[d]) if kraeftig else text_datei
    return text_datei, titel_datei


def auswahl(zip_datei, oben, addon_root):
    """Namen im ZIP, die ein Skin fuer den Heim-Style braucht."""
    namen = zip_datei.namelist()
    rel = {n[len(oben) + 1:]: n for n in namen if n.startswith(oben + "/") and not n.endswith("/")}
    behalten = {"addon.xml"}
    schriften = set()
    for ordner in res_ordner(addon_root):
        if ordner + "/Font.xml" in rel:
            behalten.add(ordner + "/Font.xml")
            for d in schriften_aus_font_xml(zip_datei.read(rel[ordner + "/Font.xml"])):
                if d:
                    schriften.add("fonts/" + d)
            break
    hintergruende = 0
    for r, voll in sorted(rel.items()):
        klein = r.lower()
        if klein.startswith(("colors/", "resources/")) and (klein.endswith(".xml") or klein.endswith(BILD)):
            behalten.add(r)
        elif r in schriften or (klein.startswith("fonts/") and re.search(r"(?i)licen[cs]e|ofl|readme", klein)):
            behalten.add(r)
        elif klein.endswith(BILD) and "background" in klein and hintergruende < MAX_HINTERGRUENDE \
                and zip_datei.getinfo(voll).file_size <= MAX_BILD:
            behalten.add(r)
            hintergruende += 1
    return {rel[r] for r in behalten if r in rel}


# --- Texturen aus Textures.xbt ------------------------------------------------------------------------------
def _rand(b, h, rgba):
    """Rahmenbreite eines Panels fuer border-image: wo die Diagonale von oben links deckend wird (abgerundete Ecken)."""
    for i in range(min(b, h) // 4):
        if rgba[(i * b + i) * 4 + 3] >= 250:
            return max(8, min(min(b, h) // 4, i + 6))
    return 8


def texturen_auswaehlen(eintraege):
    """{hintergrund: [Eintraege], fokus: [..], flaeche: [..]} – Kandidaten nach Name und Groesse, beste zuerst."""
    hg, fokus, flaeche = [], [], []
    for e in eintraege:
        n, b, h = e["name"], e["breite"], e["hoehe"]
        if b >= 1280 and h >= 600 and 1.5 <= b / max(h, 1) <= 2.0 and not _KEIN_HINTERGRUND.search(n):
            hg.append(e)
        elif _FOKUS.search(n) and not _FOKUS_NICHT.search(n) and b >= 64 and h >= 24 and b >= 2 * h:  # Knopf, kein Symbol
            fokus.append(e)
        elif _PANEL.search(n) and not _PANEL_NICHT.search(n) and b >= 128 and h >= 64:
            flaeche.append(e)
    hg.sort(key=lambda e: (not _HINTERGRUND_NAME.search(e["name"]), -e["breite"] * e["hoehe"], e["name"]))
    def fokus_rang(e):
        name = os.path.basename(e["name"]).lower()
        return (not name.startswith(("button", "btn")), "button" not in name, -e["breite"] * e["hoehe"], name)
    fokus.sort(key=fokus_rang)
    flaeche.sort(key=lambda e: ("contentpanel" not in e["name"].lower(), "dialog" not in e["name"].lower(), -e["breite"] * e["hoehe"], e["name"]))
    return {"hintergrund": hg, "fokus": fokus, "flaeche": flaeche}


def texturen_entpacken(zip_datei, oben, ziel):
    """Textures.xbt aus dem Skin-ZIP lesen, die passenden Texturen als PNG nach <ziel>/h0rst/ schreiben (texturen.json).
    Gibt die Beschreibung zurueck; Fehler sind kein Grund, die Installation abzubrechen."""
    namen = [n for n in zip_datei.namelist() if n.startswith(oben + "/media/") and n.lower().endswith(".xbt")]
    namen.sort(key=lambda n: (not n.lower().endswith("/textures.xbt"), n))
    if not namen or zip_datei.getinfo(namen[0]).file_size > MAX_XBT:
        return {}
    daten = zip_datei.read(namen[0])
    try:
        wahl = texturen_auswaehlen(xbt.verzeichnis(daten))
    except xbt.XbtFehler as fehler:
        log.info("Kodi-Skin: %s nicht lesbar: %s", namen[0], fehler)
        return {}
    ordner = os.path.join(ziel, TEXTUR_ORDNER)
    os.makedirs(ordner, exist_ok=True)
    beschreibung = {"quelle": os.path.basename(namen[0]), "hintergruende": []}

    def schreiben(e, datei, breite=None):
        b, h, rgba = xbt.bild(daten, e)
        if xbt.vielfalt(rgba) < MIN_VIELFALT:
            return None
        if breite:
            b, h, rgba = xbt.verkleinern(b, h, rgba, breite)
        with open(os.path.join(ordner, datei), "wb") as f:
            f.write(xbt.png(b, h, rgba, not xbt.deckend(rgba)))
        return b, h, rgba
    for art, anzahl in (("hintergrund", MAX_TEXTUR_HINTERGRUENDE), ("fokus", 1), ("flaeche", 1)):
        gefunden = 0
        for e in wahl[art][:12]:
            if gefunden >= anzahl:
                break
            datei = "%s-%d.png" % (art, gefunden + 1)
            try:
                bild = schreiben(e, datei, HINTERGRUND_BREITE if art == "hintergrund" else None)
            except xbt.XbtFehler as fehler:
                log.info("Kodi-Skin: Textur %s: %s", e["name"], fehler)
                continue
            if not bild:
                continue
            gefunden += 1
            if art == "hintergrund":
                beschreibung["hintergruende"].append({"name": os.path.splitext(os.path.basename(e["name"]))[0], "datei": datei})
            else:
                beschreibung[art] = {"datei": datei, "name": e["name"], "breite": bild[0], "hoehe": bild[1]}
                if art == "flaeche":
                    beschreibung[art]["rand"] = _rand(*bild)
    with open(os.path.join(ordner, "texturen.json"), "w", encoding="utf-8") as f:
        json.dump(beschreibung, f, ensure_ascii=False, indent=1)
    return beschreibung


# --- Farben ------------------------------------------------------------------------------------------------
def _farbe(wert, alle, tiefe=0):
    """AARRGGBB (oder Name einer anderen Farbe) -> (r, g, b, a) mit 0..1, sonst None."""
    w = (wert or "").strip()
    if w in alle and tiefe < 5:
        return _farbe(alle[w], alle, tiefe + 1)
    if not _HEX.match(w):
        return None
    if len(w) == 6:
        w = "ff" + w
    a, r, g, b = (int(w[i:i + 2], 16) / 255 for i in (0, 2, 4, 6))
    return r, g, b, a


def _hell(f):
    def kanal(c):
        return c / 12.92 if c <= 0.03928 else ((c + 0.055) / 1.055) ** 2.4
    return 0.2126 * kanal(f[0]) + 0.7152 * kanal(f[1]) + 0.0722 * kanal(f[2])


def _kontrast(a, b):
    h1, h2 = sorted((_hell(a), _hell(b)), reverse=True)
    return (h1 + 0.05) / (h2 + 0.05)


def _saettigung(f):
    return colorsys.rgb_to_hls(*f[:3])[2]


def _hex(f):
    return "#%02x%02x%02x" % tuple(round(c * 255) for c in f[:3])


def _rgba(f, alpha):
    return "rgba(%d,%d,%d,%.2f)" % (round(f[0] * 255), round(f[1] * 255), round(f[2] * 255), alpha)


def _mischen(a, b, anteil):
    return tuple(a[i] + (b[i] - a[i]) * anteil for i in range(3)) + (1.0,)


def farben_lesen(datei):
    try:
        root = ET.parse(datei).getroot()
    except (OSError, ET.ParseError):
        return {}
    return {(c.get("name") or "").strip(): (c.text or "").strip() for c in root.iter("color") if c.get("name")}


def heim_farben(roh):
    """Kodi-Farben eines Schemas -> Variablen eines Heim-Styles (Grund, Flaeche, Text, Akzent …)."""
    farben = {n: f for n, f in ((n, _farbe(w, roh)) for n, w in roh.items()) if f}
    deckend = {n: f for n, f in farben.items() if f[3] >= 0.85}
    grund = next((f for n, f in deckend.items() if _GRUND_NAMEN.match(n)), None)
    if grund is None:  # ohne benannte Hintergrundfarbe: dunkel wie fast alle Kodi-Skins – das dunkelste Neutrale oder fast Schwarz
        dunkle = [f for f in deckend.values() if _saettigung(f) < 0.2 and _hell(f) < 0.02]
        grund = min(dunkle, key=_hell) if dunkle else (0.04, 0.04, 0.05, 1.0)
    dunkel = _hell(grund) < 0.3
    neutral = [f for f in deckend.values() if _saettigung(f) < 0.2] or [(1, 1, 1, 1) if dunkel else (0.07, 0.07, 0.07, 1)]
    benannt = [f for n, f in deckend.items() if _TEXT_NAMEN.search(n) and _saettigung(f) < 0.2 and _kontrast(f, grund) >= 4.5]
    text = benannt[0] if benannt else max(neutral, key=lambda f: _kontrast(f, grund))
    if _kontrast(text, grund) < 4.5:
        text = (0.93, 0.93, 0.93, 1.0) if dunkel else (0.08, 0.08, 0.09, 1.0)
    bunt = [(n, f) for n, f in deckend.items() if _saettigung(f) >= 0.25 and _kontrast(f, grund) >= 1.8]
    akzent = next((f for n, f in bunt if _AKZENT_NAMEN.search(n)), None) or \
        (max(bunt, key=lambda nf: _saettigung(nf[1]) * min(_kontrast(nf[1], grund), 6))[1] if bunt else (0.0, 0.84, 0.53, 1.0))
    passend = [(n, f) for n, f in farben.items() if f[3] >= 0.5 and _saettigung(f) < 0.3 and 1.05 <= _kontrast(f, grund) <= 2.2
               and (_hell(f) > _hell(grund)) == dunkel]  # etwas heller als ein dunkler Grund (dunkler als ein heller)
    flaeche = next((f for n, f in passend if _FLAECHE_NAMEN.search(n)), None) or \
        (min((f for _, f in passend), key=lambda f: abs(_kontrast(f, grund) - 1.25)) if passend else _mischen(grund, text, 0.07))
    return {"grund": _hex(grund), "flaeche": _hex(flaeche), "flaeche-glas": _rgba(flaeche, 0.88), "text": _hex(text),
            "leise": _rgba(text, 0.64), "linie": _rgba(text, 0.14), "akzent": _hex(akzent),
            "akzent-text": "#000000" if _hell(akzent) > 0.35 else "#ffffff", "hell": not dunkel}


# --- Skin lesen ----------------------------------------------------------------------------------------------
def _innen(wurzel, *teile):
    """Pfad unterhalb des Skin-Ordners oder None (Namen aus Font.xml/addon.xml sind fremde Daten: kein ../)."""
    voll = os.path.abspath(os.path.join(wurzel, *teile))
    return voll if voll.startswith(os.path.abspath(wurzel) + os.sep) else None


def lesen(info, bild_url):
    """Alles fuer den Heim-Style: Schemata mit Farben, Schriften, Hintergruende, Vorschau. bild_url(pfad) -> Adresse."""
    pfad = info["pfad"]
    schemata = []
    basis = farben_lesen(os.path.join(pfad, "colors", "defaults.xml"))
    if basis:
        schemata.append({"id": "defaults", "name": "Standard", "farben": heim_farben(basis)})
    ordner = os.path.join(pfad, "colors")
    for datei in sorted(os.listdir(ordner)) if os.path.isdir(ordner) else []:
        if datei.lower().endswith(".xml") and datei.lower() != "defaults.xml":
            roh = dict(basis, **farben_lesen(os.path.join(ordner, datei)))
            if roh:
                schemata.append({"id": datei[:-4], "name": datei[:-4], "farben": heim_farben(roh)})
    if not schemata:
        schemata.append({"id": "defaults", "name": "Standard", "farben": heim_farben({})})
    schriften = {}
    try:
        root = ET.parse(os.path.join(pfad, "addon.xml")).getroot()
    except (OSError, ET.ParseError):
        root = None
    for res in res_ordner(root) if root is not None else []:
        font_xml = _innen(pfad, res, "Font.xml")
        if font_xml and os.path.exists(font_xml):
            with open(font_xml, "rb") as f:
                text_datei, titel_datei = schriften_aus_font_xml(f.read())
            for art, d in (("text", text_datei), ("titel", titel_datei)):
                voll = _innen(pfad, "fonts", d) if d else None
                if voll and os.path.isfile(voll) and d.lower().endswith(SCHRIFT):
                    schriften[art] = bild_url(voll)
            break
    hintergruende, vorschau = [], []
    texturen = {}
    try:
        with open(os.path.join(pfad, TEXTUR_ORDNER, "texturen.json"), encoding="utf-8") as f:
            t = json.load(f)
        for h in t.get("hintergruende") or []:
            datei = os.path.join(pfad, TEXTUR_ORDNER, os.path.basename(str(h.get("datei") or "")))
            if os.path.isfile(datei):
                hintergruende.append({"name": "Textur: " + str(h.get("name") or ""), "url": bild_url(datei)})
        for art in ("fokus", "flaeche"):
            x = t.get(art) or {}
            datei = os.path.join(pfad, TEXTUR_ORDNER, os.path.basename(str(x.get("datei") or "")))
            if x and os.path.isfile(datei):
                texturen[art] = {"url": bild_url(datei), "rand": int(x.get("rand") or 0), "name": str(x.get("name") or "")}
    except (OSError, ValueError, TypeError):
        pass
    for wurzel, _, dateien in sorted(os.walk(pfad)):
        for d in sorted(dateien):
            voll = os.path.join(wurzel, d)
            if not d.lower().endswith(BILD):
                continue
            rel = os.path.relpath(voll, pfad).replace(os.sep, "/").lower()
            if rel.startswith(TEXTUR_ORDNER + "/"):
                continue  # schon oben
            if rel.startswith("resources/screenshot"):
                vorschau.append(bild_url(voll))
            elif "background" in rel or rel in ("resources/fanart.jpg", "fanart.jpg"):
                hintergruende.append({"name": os.path.splitext(d)[0], "url": bild_url(voll)})
    return {"id": info["id"], "name": info["name"], "version": info["version"], "autor": info.get("autor", ""),
            "lizenz": info.get("lizenz", ""), "icon": bild_url(info["icon"]) if info.get("icon") else "",
            "schemata": schemata, "schriften": schriften, "hintergruende": hintergruende[:MAX_HINTERGRUENDE], "vorschau": vorschau[:6],
            "texturen": texturen, "texturen_geprueft": os.path.isfile(os.path.join(pfad, TEXTUR_ORDNER, "texturen.json"))}
