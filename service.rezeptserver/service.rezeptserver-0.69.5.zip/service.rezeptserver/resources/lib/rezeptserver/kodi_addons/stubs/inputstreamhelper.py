"""inputstreamhelper – H0rSt spielt HLS und DASH selbst; Widevine-Pruefung meldet "vorhanden", damit das Plugin
den Stream liefert (geschuetzte Streams zeigt die Oberflaeche dann als DRM an und bietet Kodi an)."""

L = None
__version__ = "0.7.0"


class Helper:
    def __init__(self, protocol, drm=None):
        self.protocol, self.drm = protocol, drm
        self.inputstream_addon = "inputstream.adaptive"

    def check_inputstream(self):
        return True

    def install_widevine(self):
        return True

    def remove_widevine(self):
        return True

    def info_dialog(self):
        pass
