"""xbmc – nachgebaut fuer Plugins in H0rSt (Kodi 21 "Omega"). L ist kodi_addons.laufzeit (setzt der Lader)."""

import json
import logging
import re
import threading
import time

L = None  # wird beim Laden gesetzt
_log = logging.getLogger("rezeptserver")

LOGDEBUG, LOGINFO, LOGNOTICE, LOGWARNING, LOGERROR, LOGSEVERE, LOGFATAL, LOGNONE = 0, 1, 1, 2, 3, 4, 4, 5
_STUFEN = {0: logging.DEBUG, 1: logging.INFO, 2: logging.WARNING, 3: logging.ERROR, 4: logging.CRITICAL}
PLAYLIST_MUSIC, PLAYLIST_VIDEO = 0, 1
ISO_639_1, ISO_639_2, ENGLISH_NAME, ISO_NAME = 0, 1, 2, 3
# ESERVERS aus xbmc/network/NetworkServices.h: der Webserver ist 1, nicht 0
SERVER_NONE, SERVER_WEBSERVER, SERVER_AIRPLAYSERVER, SERVER_JSONRPCSERVER = 0, 1, 2, 3
SERVER_UPNPRENDERER, SERVER_UPNPSERVER, SERVER_EVENTSERVER, SERVER_ZEROCONF = 4, 5, 6, 7
DRIVE_NOT_READY, TRAY_OPEN, TRAY_CLOSED_NO_MEDIA, TRAY_CLOSED_MEDIA_PRESENT = 1, 16, 64, 96
DEVICE_POWER_NO_ADAPTER, DEVICE_POWER_ON, DEVICE_POWER_STANDBY = 0, 1, 2
DEVICE_POWER_TRANSITION_TO_ON, DEVICE_POWER_TRANSITION_TO_STANDBY, DEVICE_POWER_UNKNOWN = 3, 4, 5
abortRequested = False
VERSION = "21.2"
_INFO = {"system.buildversion": VERSION + " (21.2.0) Git:H0rSt", "system.buildversionshort": VERSION,
         "system.platform.android": "", "system.language": "German", "system.osversioninfo": "H0rSt",
         "system.screenwidth": "1920", "system.screenheight": "1080", "system.screenresolution": "1920x1080",
         "system.friendlyname": "H0rSt", "network.ipaddress": "127.0.0.1", "system.date": "", "system.time": "",
         "container.foldername": "", "container.pluginname": "", "listitem.label": ""}


def _lauf():
    return L.AKTUELL


_im_log = threading.local()


def log(msg, level=LOGDEBUG):
    # Viele Addons haengen einen logging-Handler an, der xbmc.log ruft – ohne Sperre liefe das im Kreis
    if getattr(_im_log, "an", False):
        return
    _im_log.an = True
    try:
        lauf = _lauf()
        _log.log(min(_STUFEN.get(level, logging.INFO), logging.INFO) if level < LOGERROR else _STUFEN.get(level, logging.ERROR),
                 "Kodi %s: %s", lauf.addon["id"] if lauf else "?", msg)
    finally:
        _im_log.an = False


def sleep(timemillis):
    lauf = _lauf()
    if lauf:
        lauf.pruefen()
    time.sleep(max(0, min(int(timemillis or 0), 10000)) / 1000.0)


def getInfoLabel(cLine):
    k = str(cLine or "").strip().lower()
    if k == "system.date":
        return time.strftime("%d.%m.%Y")
    if k == "system.time":
        return time.strftime("%H:%M")
    if k == "container.pluginname" and _lauf():
        return _lauf().addon["id"]
    m = re.match(r"window\((\w+)\)\.property\((.+)\)", k)
    if m and _lauf():
        return str(_lauf().fenster.get(m.group(2), ""))
    return _INFO.get(k, "")


def getCondVisibility(condition):
    b = str(condition or "").strip()
    m = re.match(r"(?i)^!?\s*system\.hasaddon\((.+)\)$", b)
    if m:
        lauf = _lauf()
        da = bool(lauf and lauf.verwaltung.vorhanden(m.group(1).strip()))
        return not da if b.startswith("!") else da
    m = re.match(r"(?i)^system\.addonisenabled\((.+)\)$", b)
    if m:
        lauf = _lauf()
        return bool(lauf and lauf.verwaltung.vorhanden(m.group(1).strip()))
    if re.match(r"(?i)^system\.platform\.(android)$", b):
        import os
        return bool(os.environ.get("ANDROID_ROOT"))
    if re.match(r"(?i)^system\.platform\.linux$", b):
        import sys
        return sys.platform.startswith("linux")
    if re.match(r"(?i)^system\.platform\.windows$", b):
        import sys
        return sys.platform.startswith("win")
    return False


def executebuiltin(function, wait=False):
    lauf = _lauf()
    if not lauf:
        return
    b = str(function or "").strip()
    m = re.match(r"(?is)^([\w.]+)\s*\((.*)\)\s*$", b)
    name, args = (m.group(1).lower(), m.group(2)) if m else (b.lower(), "")
    teile = [a.strip().strip('"') for a in re.split(r",(?![^(]*\))", args)] if args else []
    if name == "container.update" and teile:
        lauf.weiter = {"url": teile[0], "ersetzen": "replace" in [t.lower() for t in teile[1:]]}
    elif name in ("activatewindow", "activatewindowandfocus") and len(teile) > 1 and teile[1].startswith("plugin://"):
        lauf.weiter = {"url": teile[1], "ersetzen": False}
    elif name == "container.refresh":
        lauf.neu_laden = True
    elif name == "notification" and teile:
        lauf.melden(teile[0], teile[1] if len(teile) > 1 else "")
    elif name == "playmedia" and teile:
        lauf.aufgeloest = (teile[0], None)
    elif name in ("runplugin", "runaddon", "runscript"):
        lauf.befehle.append({"art": name, "ziel": teile[0] if teile else ""})
    elif name == "addon.opensettings" and teile:
        lauf.befehle.append({"art": "einstellungen", "ziel": teile[0]})


def executeJSONRPC(jsonrpccommand):
    try:
        a = json.loads(jsonrpccommand)
    except ValueError:
        return json.dumps({"jsonrpc": "2.0", "error": {"code": -32700, "message": "Parse error"}})
    methode, aid = a.get("method", ""), a.get("id", 1)
    lauf = _lauf()
    if methode == "Addons.GetAddonDetails" and lauf:
        ziel = (a.get("params") or {}).get("addonid", "")
        info = lauf.verwaltung.info(ziel)
        if info or lauf.verwaltung.vorhanden(ziel):
            return json.dumps({"jsonrpc": "2.0", "id": aid, "result": {"addon": {"addonid": ziel, "enabled": True,
                               "version": (info or {}).get("version", "21.0.0"), "name": (info or {}).get("name", ziel)}}})
        return json.dumps({"jsonrpc": "2.0", "id": aid, "error": {"code": -32602, "message": "Invalid params"}})
    if methode == "Addons.SetAddonEnabled":
        return json.dumps({"jsonrpc": "2.0", "id": aid, "result": "OK"})
    if methode == "Settings.GetSettingValue":
        werte = {"locale.language": "resource.language.de_de", "locale.audiolanguage": "German",
                 "locale.subtitlelanguage": "German", "network.usehttpproxy": False}
        return json.dumps({"jsonrpc": "2.0", "id": aid, "result": {"value": werte.get((a.get("params") or {}).get("setting", ""), "")}})
    if methode == "JSONRPC.Version":
        return json.dumps({"jsonrpc": "2.0", "id": aid, "result": {"version": {"major": 13, "minor": 0, "patch": 0}}})
    return json.dumps({"jsonrpc": "2.0", "id": aid, "result": {}})


def executescript(script):
    """Ein Python-Skript wie Kodi im laufenden Aufruf ausfuehren; Fehler landen im Log, nie beim Plugin."""
    lauf = _lauf()
    if lauf is None:
        return
    pfad = lauf.pfad(str(script or ""))
    try:
        import runpy
        runpy.run_path(pfad, run_name="__main__")
    except SystemExit:
        pass
    except Exception as fehler:  # noqa: BLE001 – ein fremdes Skript darf den Aufruf nicht mitreissen
        _log.warning("Kodi-Skript %s: %s", pfad, fehler)


def translatePath(path):
    lauf = _lauf()
    return lauf.pfad(path) if lauf else str(path)


def getLanguage(format=ENGLISH_NAME, region=False):
    return {ISO_639_1: "de", ISO_639_2: "ger"}.get(format, "German") + ("-de" if region and format == ISO_639_1 else "")


def convertLanguage(sprache, format):
    s = str(sprache or "").lower()
    tabelle = {"german": ("de", "ger", "German"), "deutsch": ("de", "ger", "German"), "de": ("de", "ger", "German"),
               "ger": ("de", "ger", "German"), "deu": ("de", "ger", "German"), "english": ("en", "eng", "English"),
               "en": ("en", "eng", "English"), "eng": ("en", "eng", "English"), "french": ("fr", "fre", "French"),
               "fr": ("fr", "fre", "French"), "spanish": ("es", "spa", "Spanish"), "es": ("es", "spa", "Spanish")}
    t = tabelle.get(s)
    return t[format] if t and 0 <= format <= 2 else sprache


def getRegion(was):
    return {"dateshort": "%d.%m.%Y", "datelong": "%A, %d. %B %Y", "time": "%H:%M:%S", "meridiem": "",
            "tempunit": "°C", "speedunit": "km/h"}.get(str(was), "")


def getDVDState():
    return TRAY_CLOSED_NO_MEDIA  # ohne Laufwerk wie ein geschlossenes Fach ohne Medium


def getInfoImage(infotag):
    return ""  # Skin-Bilder gibt es ohne Kodis Oberflaeche nicht


def getDatabaseName(dbType):
    """Die versionierten Datenbanknamen, die Kodi 23 fuer die Bibliotheken meldet."""
    return {"video": "MyVideos132", "music": "MyMusic85", "texture": "Textures14",
            "view": "ViewModes6", "epg": "Epg17", "adsp": "Addons33"}.get(str(dbType or "").lower(), "")


def getDevicePowerStatus(adapterName=""):
    return DEVICE_POWER_NO_ADAPTER


def getCecAdapterNames():
    return []


def skinHasImage(image):
    return False


def startServer(iTyp, bStart):
    """H0rSt hat nur einen HTTP-Server; alles andere kann nicht gestartet werden."""
    return int(iTyp or 0) == SERVER_WEBSERVER


def registerMonitor(monitor):
    pass


def unregisterMonitor(monitor):
    pass


def getLocalizedString(nummer):
    return L.KODI_TEXTE.get(int(nummer), "")


def getSkinDir():
    return "skin.estuary"


def getUserAgent():
    return "Kodi/%s (Linux; Android) App_Bitness/64 Version/%s-H0rSt" % (VERSION, VERSION)


def getFreeMem():
    return 1024


def getGlobalIdleTime():
    return 0


def getIPAddress():
    return "127.0.0.1"


def getCacheThumbName(pfad):
    import zlib
    return "%08x.tbn" % (zlib.crc32(str(pfad).lower().encode("utf-8")) & 0xffffffff)


def getCleanMovieTitle(pfad, usefoldername=False):
    """Dateiname oder Ordner in Titel und Jahr zerlegen, wie Kodis Scraper-Vorbereitung."""
    name = str(pfad or "").replace("\\", "/").rstrip("/").rsplit("/", 1)[-1]
    if not usefoldername:
        name = re.sub(r"\.[A-Za-z0-9]{2,4}$", "", name)
    name = name.replace(".", " ").replace("_", " ").strip()
    treffer = re.search(r"(?:^|\s|\()((?:19|20)\d{2})(?:\s|$|\))", name)
    if treffer:
        titel = (name[:treffer.start()] + name[treffer.end():]).strip(" ()-")
        return titel or name, treffer.group(1)
    return name, ""


def makeLegalFilename(name, fatX=True):
    return re.sub(r'[<>:"/\\|?*]', "_", str(name))


def validatePath(pfad):
    return str(pfad)


def getSupportedMedia(art):
    return {"video": ".m4v|.3g2|.3gp|.nsv|.tp|.ts|.ty|.pls|.rm|.rmvb|.mpd|.m3u|.m3u8|.ifo|.mov|.qt|.divx|.xvid|.bivx|.vob|.nrg|.img|.iso|.udf|.pva|.wmv|.asf|.asx|.ogm|.m2v|.avi|.bin|.dat|.mpg|.mpeg|.mp4|.mkv|.mk3d|.avc|.vp3|.svq3|.nuv|.viv|.dv|.fli|.flv|.001|.wpl|.xspf|.vdr|.dvr-ms|.xsp|.mts|.m2t|.m2ts|.evo|.ogv|.sdp|.avs|.rec|.url|.pxml|.vc1|.h264|.rcv|.rss|.mpls|.mpl|.webm|.bdmv|.bdm|.wtv|.trp|.f4v",
            "music": ".nsv|.m4a|.flac|.aac|.strm|.pls|.rm|.rma|.mpa|.wav|.wma|.ogg|.mp3|.mp2|.m3u|.gdm|.imf|.m15|.sfx|.uni|.ac3|.dts|.cue|.aif|.aiff|.wpl|.xspf|.ape|.mac|.mpc|.mp+|.mpp|.shn|.zip|.wv|.dsp|.xsp|.xwav|.waa|.wvs|.wam|.gcm|.idsp|.mpdsp|.mss|.spt|.rsd|.sap|.cmc|.cmr|.dmc|.mpt|.mpd|.rmt|.tmc|.tm8|.tm2|.oga|.url|.pxml|.tta|.rss|.wtv|.mka|.tak|.opus|.dff|.dsf|.m4b|.dtshd",
            "picture": ".png|.jpg|.jpeg|.bmp|.gif|.ico|.tif|.tiff|.tga|.pcx|.cbz|.zip|.rss|.webp|.jp2|.apng"}.get(art, "")


def playSFX(*args, **kwargs):
    pass


def stopSFX():
    pass


def enableNavSounds(an):
    pass


def audioSuspend():
    pass


def audioResume():
    pass


def restart():
    pass


def shutdown():
    pass


class Monitor:
    def __init__(self, *args, **kwargs):
        pass

    def abortRequested(self):
        lauf = _lauf()
        return bool(lauf and lauf.abgebrochen)

    def waitForAbort(self, timeout=None):
        # Blockiert bis zum Abbruch oder bis `timeout` Sekunden vergangen sind - in 0,2-s-Schritten,
        # damit ein erzwungener Abbruch (laufzeit._stoppen) weiterhin zeitnah zuschlagen kann, statt
        # in einem einzigen langen time.sleep() zu stecken. Vorher kehrte die Funktion nach spaetestens
        # 0,2 s immer zurueck, egal wie gross `timeout` war - Dienst-Addons mit der ueblichen
        # "while not abortRequested(): if waitForAbort(300): break"-Schleife liefen dadurch um ein
        # Vielfaches haeufiger als beabsichtigt.
        ende = time.monotonic() + float(timeout) if timeout is not None else None
        while True:
            lauf = _lauf()
            if lauf and lauf.abgebrochen:
                return True
            rest = (ende - time.monotonic()) if ende is not None else None
            if rest is not None and rest <= 0:
                return False
            time.sleep(0.2 if rest is None else min(0.2, rest))

    def onSettingsChanged(self):
        pass

    def onNotification(self, sender, method, data):
        pass

    def onScreensaverActivated(self):
        pass

    def onScreensaverDeactivated(self):
        pass

    def onDPMSActivated(self):
        pass

    def onDPMSDeactivated(self):
        pass

    def onScanStarted(self, library):
        pass

    def onScanFinished(self, library):
        pass

    def onCleanStarted(self, library):
        pass

    def onCleanFinished(self, library):
        pass


class Player:
    def __init__(self, *args, **kwargs):
        self._spielt, self._datei, self._li = False, "", None
        self._zeit, self._gesamt, self._tempo, self._audio, self._video = 0.0, 0.0, 1, -1, -1

    def play(self, item="", listitem=None, windowed=False, startpos=-1):
        lauf = _lauf()
        if lauf is None:
            return
        if hasattr(item, "getPath"):  # ListItem
            listitem, item = item, item.getPath()
        if hasattr(item, "_eintraege"):  # PlayList: den ersten Eintrag abspielen
            erstes = item._eintraege[0] if item._eintraege else ("", None)
            item, listitem = erstes
        self._li = listitem
        self._datei = str(item or (listitem.getPath() if listitem is not None else ""))
        self._zeit, self._gesamt, self._tempo = 0.0, 0.0, 1
        lauf.aufgeloest = (self._datei, listitem)
        self._spielt = True
        self.onPlayBackStarted()

    def playnext(self):
        pass

    def playprevious(self):
        pass

    def playselected(self, selected):
        pass

    def stop(self):
        if self._spielt:
            self._spielt = False
            self.onPlayBackStopped()

    def pause(self):
        if self._spielt:
            self.onPlayBackPaused()

    def isPlaying(self):
        return self._spielt

    def isPlayingVideo(self):
        return self._spielt

    def isPlayingAudio(self):
        return False

    def isPlayingRDS(self):
        return False

    def isPlayingGame(self):
        return False

    def isExternalPlayer(self):
        return False

    def getTime(self):
        return self._zeit

    def getTotalTime(self):
        return self._gesamt

    def seekTime(self, t):
        self._zeit = max(0.0, float(t or 0))
        self.onPlayBackSeek(int(self._zeit), 0)

    def getPlayingFile(self):
        return self._datei

    def getPlayingItem(self):
        return self._li

    def showSubtitles(self, an):
        pass

    def setSubtitles(self, pfad):
        pass

    def getSubtitles(self):
        return ""

    def getAvailableAudioStreams(self):
        return []

    def getAvailableVideoStreams(self):
        return []

    def getAvailableSubtitleStreams(self):
        return []

    def setAudioStream(self, iStream):
        self._audio = int(iStream or -1)

    def setVideoStream(self, iStream):
        self._video = int(iStream or -1)

    def updateInfoTag(self, item):
        self._li = item

    def getVideoInfoTag(self):
        return (self._li or L.stub("xbmcgui").ListItem()).getVideoInfoTag()

    def getMusicInfoTag(self):
        return InfoTagMusic()

    def getGameInfoTag(self):
        return InfoTagGame()

    def getRadioRDSInfoTag(self):
        return InfoTagRadioRDS()

    # Rueckrufe, die Kodi beim Abspielen aufruft; Plugins ueberschreiben sie
    def onPlayBackStarted(self):
        pass

    def onAVStarted(self):
        pass

    def onAVChange(self):
        pass

    def onPlayBackEnded(self):
        pass

    def onPlayBackStopped(self):
        pass

    def onPlayBackError(self):
        pass

    def onPlayBackPaused(self):
        pass

    def onPlayBackResumed(self):
        pass

    def onQueueNextItem(self):
        pass

    def onPlayBackSpeedChanged(self, speed):
        pass

    def onPlayBackSeek(self, time, seekOffset):
        pass

    def onPlayBackSeekChapter(self, chapter):
        pass


class PlayList:
    def __init__(self, art=PLAYLIST_VIDEO):
        self._art, self._eintraege, self._position, self._reihenfolge = int(art or 0), [], 0, []

    def add(self, url, listitem=None, index=-1):
        if hasattr(url, "getPath") and listitem is None:
            listitem, url = url, url.getPath()
        eintrag = (str(url), listitem)
        if 0 <= int(index or 0) < len(self._eintraege):
            self._eintraege.insert(int(index), eintrag)
        else:
            self._eintraege.append(eintrag)

    def clear(self):
        self._eintraege, self._position, self._reihenfolge = [], 0, []

    def load(self, filename):
        """M3U/PLS (Datei oder http) laden wie Kodi; True, wenn Eintraege gefunden."""
        quelle = str(filename or "")
        try:
            if quelle.lower().startswith(("http://", "https://")):
                import urllib.request
                with urllib.request.urlopen(urllib.request.Request(quelle, headers={"User-Agent": getUserAgent()}), timeout=20) as a:
                    text = a.read(2 * 1024 * 1024).decode("utf-8", "replace")
            else:
                with open(translatePath(quelle), encoding="utf-8", errors="replace") as f:
                    text = f.read(2 * 1024 * 1024)
        except (OSError, ValueError):
            return False
        neu, titel = [], ""
        for zeile in text.splitlines():
            z = zeile.strip()
            if z.upper().startswith("#EXTINF"):
                titel = z.split(",", 1)[1].strip() if "," in z else ""
            elif re.match(r"(?i)^file\d+=", z):
                neu.append((z.split("=", 1)[1].strip(), ""))
            elif re.match(r"(?i)^title\d+=", z) and neu:
                neu[-1] = (neu[-1][0], z.split("=", 1)[1].strip())
            elif z and not z.startswith(("#", "[")) and "=" not in z.split("/", 1)[0]:
                neu.append((z, titel))
                titel = ""
        for url, name in neu:
            self.add(url, L.stub("xbmcgui").ListItem(name or url, path=url))
        return bool(neu)

    def remove(self, filename):
        self._eintraege = [e for e in self._eintraege if e[0] != str(filename)]

    def __getitem__(self, stelle):
        url, li = self._eintraege[stelle]
        return li if li is not None else L.stub("xbmcgui").ListItem(path=url)

    def size(self):
        return len(self._eintraege)

    def __len__(self):
        return len(self._eintraege)

    def getposition(self):
        return self._position

    def shuffle(self):
        import random
        self._reihenfolge = list(self._eintraege)
        random.shuffle(self._eintraege)

    def unshuffle(self):
        if self._reihenfolge:
            self._eintraege, self._reihenfolge = self._reihenfolge, []

    def getPlayListId(self):
        return self._art


class Keyboard:
    def __init__(self, default="", heading="", hidden=False):
        self._text, self._titel, self._versteckt, self._ok = str(default or ""), str(heading or ""), hidden, False

    def setHeading(self, titel):
        self._titel = str(titel)

    def setDefault(self, text):
        self._text = str(text)

    def setHiddenInput(self, an):
        self._versteckt = bool(an)

    def doModal(self, autoclose=0):
        antwort = _lauf().fragen({"art": "eingabe", "titel": L.ohne_format(self._titel) or "Eingabe", "standard": self._text,
                                  "versteckt": self._versteckt})
        self._ok = antwort is not None
        if self._ok:
            self._text = str(antwort)

    def isConfirmed(self):
        return self._ok

    def getText(self):
        return self._text


def _w3c(datum):
    """'2024-01-02' -> '2024-01-02T00:00:00Z' wie Kodis ...AsW3C-Getter."""
    text = str(datum or "")
    return text + "T00:00:00Z" if re.match(r"^\d{4}-\d{2}-\d{2}$", text) else text


class _InfoTag:
    """Gemeinsame Ablage der InfoTags: Getter liefern Typ, Setter merken den Wert."""

    _ZAHLEN = frozenset()  # Getter liefern int (oder float bei Rating)
    _LISTEN = frozenset()  # Getter liefern eine Liste

    def __init__(self, daten=None, *args, **kwargs):
        self._d = daten if isinstance(daten, dict) else {}

    def __getattr__(self, name):
        if name.startswith("set"):
            feld = name[3:]
            schluessel = feld.lower()

            def setzen(wert=None, *rest, **kw):
                if feld in self._LISTEN:
                    self._d[schluessel] = " / ".join(str(w) for w in (wert or []))
                elif feld == "Rating":
                    self._d[schluessel] = float(wert or 0)
                elif feld in self._ZAHLEN:
                    try:
                        self._d[schluessel] = int(wert or 0)
                    except (TypeError, ValueError):
                        self._d[schluessel] = 0
                else:
                    self._d[schluessel] = wert
            return setzen
        if name.startswith("get"):
            feld = name[3:]
            schluessel = feld.lower()
            if feld.endswith("AsW3C"):
                basis = schluessel[:-5]
                return lambda *a, **k: _w3c(self._d.get(basis, ""))
            if feld in self._LISTEN:
                return lambda *a, **k: [x for x in str(self._d.get(schluessel, "")).split(" / ") if x]
            if feld == "DbId":
                return lambda *a, **k: int(self._d.get("dbid", -1))
            if feld == "Rating":
                return lambda *a, **k: float(self._d.get("rating", 0.0) or 0)
            if feld in self._ZAHLEN:
                return lambda *a, **k: int(self._d.get(schluessel, 0) or 0)
            return lambda *a, **k: self._d.get(schluessel, "")
        raise AttributeError(name)


class InfoTagMusic(_InfoTag):
    _LISTEN = frozenset({"Genres", "MusicBrainzArtistID", "MusicBrainzAlbumArtistID"})
    _ZAHLEN = frozenset({"Duration", "Year", "UserRating", "Track", "Disc", "Listeners", "PlayCount"})


class InfoTagRadioRDS(_InfoTag):
    _ZAHLEN = frozenset({"AlbumTrackNumber"})


class InfoTagGame(_InfoTag):
    _LISTEN = frozenset({"Genres", "Tags"})
    _ZAHLEN = frozenset({"Year", "Players"})


class InfoTagPicture(_InfoTag):
    def getResolution(self):
        return str(self._d.get("resolution", ""))

    def setResolution(self, width, height):
        self._d["resolution"] = "%dx%d" % (int(width or 0), int(height or 0))


class RenderCapture:
    def __init__(self, *args, **kwargs):
        self._breite, self._hoehe = 0, 0

    def capture(self, width=0, height=0):
        self._breite, self._hoehe = int(width or 0), int(height or 0)

    def getWidth(self):
        return self._breite

    def getHeight(self):
        return self._hoehe

    def getAspectRatio(self):
        return self._breite / float(self._hoehe) if self._hoehe else 0.0

    def getImageFormat(self):
        return "BGRA"

    def getImage(self, msecs=0):
        return b""

    def GetPixels(self, msec):
        return False


def __getattr__(name):  # unbekannte Funktionen: nichts tun statt abstuerzen
    if name.startswith("__"):
        raise AttributeError(name)
    if name in ("InfoTagVideo", "InfoTagPicture", "Actor", "VideoStreamDetail", "AudioStreamDetail", "SubtitleStreamDetail"):
        return getattr(L.stub("xbmcgui"), name)  # seit Kodi 20 in xbmc
    return lambda *args, **kwargs: None
