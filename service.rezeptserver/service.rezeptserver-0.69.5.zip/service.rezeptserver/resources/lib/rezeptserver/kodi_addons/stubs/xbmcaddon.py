"""xbmcaddon – Infos, Einstellungen und Texte eines installierten Addons."""

L = None  # wird beim Laden gesetzt


def _lauf():
    return L.AKTUELL


class Settings:
    def __init__(self, aid):
        self._id = aid

    def _v(self):
        return _lauf().verwaltung

    def getString(self, id):
        return str(self._v().einstellung(self._id, id))

    def getBool(self, id):
        return str(self._v().einstellung(self._id, id)).lower() == "true"

    def getInt(self, id):
        try:
            return int(float(self._v().einstellung(self._id, id) or 0))
        except ValueError:
            return 0

    def getNumber(self, id):
        try:
            return float(self._v().einstellung(self._id, id) or 0)
        except ValueError:
            return 0.0

    def getStringList(self, id):
        return [x for x in str(self._v().einstellung(self._id, id)).split("|") if x]

    def getIntList(self, id):
        return [int(x) for x in self.getStringList(id) if x.lstrip("-").isdigit()]

    def setString(self, id, value):
        self._v().einstellung_setzen(self._id, id, str(value))

    def setBool(self, id, value):
        self._v().einstellung_setzen(self._id, id, "true" if value else "false")

    def setInt(self, id, value):
        self._v().einstellung_setzen(self._id, id, str(int(value)))

    def setNumber(self, id, value):
        self._v().einstellung_setzen(self._id, id, str(value))

    def setStringList(self, id, values):
        self._v().einstellung_setzen(self._id, id, "|".join(str(w) for w in values))

    def setIntList(self, id, values):
        self.setStringList(id, values)

    def getBoolList(self, id):
        return [x.lower() == "true" for x in self.getStringList(id)]

    def getNumberList(self, id):
        werte = []
        for x in self.getStringList(id):
            try:
                werte.append(float(x))
            except ValueError:
                pass
        return werte

    def setBoolList(self, id, values):
        self.setStringList(id, ["true" if v else "false" for v in values])

    def setNumberList(self, id, values):
        self.setStringList(id, values)


class Addon:
    def __init__(self, id=None):
        lauf = _lauf()
        if lauf is None:
            raise RuntimeError("xbmcaddon ausserhalb eines Plugin-Aufrufs")
        self._id = id or lauf.addon["id"]
        self._info = lauf.verwaltung.info(self._id) or lauf.verwaltung.virtuell(self._id)
        if self._info is None:
            raise RuntimeError("Unknown addon id '%s'." % self._id)

    def getAddonInfo(self, id):
        v = _lauf().verwaltung
        w = str(id).lower()
        if w == "profile":
            return "special://profile/addon_data/%s/" % self._id
        if w == "path":
            return self._info.get("pfad", "")
        if w in ("icon", "fanart"):
            return self._info.get(w, "")
        if w == "type":
            return self._info.get("typ", "xbmc.python.pluginsource")
        if w == "changelog":
            return ""
        if w == "stars":
            return "-1"  # wie Kodi, wenn es keine Bewertung gibt
        if w == "libpath":
            return v.pfad_uebersetzen(self._info.get("pfad", "") + "/" + self._info.get("skript", ""))
        return str(self._info.get({"id": "id", "name": "name", "version": "version", "author": "autor", "summary": "zusammenfassung",
                                   "description": "beschreibung", "disclaimer": "hinweis"}.get(w, w), "") or "")

    def getSetting(self, id):
        return str(_lauf().verwaltung.einstellung(self._id, id))

    def getSettingBool(self, id):
        return Settings(self._id).getBool(id)

    def getSettingInt(self, id):
        return Settings(self._id).getInt(id)

    def getSettingNumber(self, id):
        return Settings(self._id).getNumber(id)

    def getSettingString(self, id):
        return self.getSetting(id)

    def setSetting(self, id, value):
        _lauf().verwaltung.einstellung_setzen(self._id, id, str(value))

    def setSettingBool(self, id, value):
        Settings(self._id).setBool(id, value)
        return True

    def setSettingInt(self, id, value):
        Settings(self._id).setInt(id, value)
        return True

    def setSettingNumber(self, id, value):
        Settings(self._id).setNumber(id, value)
        return True

    def setSettingString(self, id, value):
        self.setSetting(id, value)
        return True

    def getSettings(self):
        return Settings(self._id)

    def getLocalizedString(self, id):
        return _lauf().verwaltung.text(self._id, id)

    def openSettings(self):
        _lauf().befehle.append({"art": "einstellungen", "ziel": self._id})
