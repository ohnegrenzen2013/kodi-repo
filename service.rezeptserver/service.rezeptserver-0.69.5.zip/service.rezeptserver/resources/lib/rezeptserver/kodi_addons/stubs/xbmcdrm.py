"""xbmcdrm – CryptoSession gibt es ohne Kodi nicht; Plugins pruefen das und weichen aus."""

L = None


class CryptoSession:
    """DRM gibt es in H0rSt nicht; die Methoden bleiben fuer die API-Pruefung vorhanden."""

    def __init__(self, uuid="", license_key="", *args, **kwargs):
        raise RuntimeError("DRM (CryptoSession) gibt es in H0rSt nicht")

    def GetKeyRequest(self, init, mimeType, offlineKey, optionalParameters):
        raise RuntimeError("DRM (CryptoSession) gibt es in H0rSt nicht")

    def GetPropertyString(self, name):
        raise RuntimeError("DRM (CryptoSession) gibt es in H0rSt nicht")

    def ProvideKeyResponse(self, response):
        raise RuntimeError("DRM (CryptoSession) gibt es in H0rSt nicht")

    def RemoveKeys(self):
        raise RuntimeError("DRM (CryptoSession) gibt es in H0rSt nicht")

    def RestoreKeys(self, keySetId):
        raise RuntimeError("DRM (CryptoSession) gibt es in H0rSt nicht")

    def SetPropertyString(self, name, value):
        raise RuntimeError("DRM (CryptoSession) gibt es in H0rSt nicht")

    def Decrypt(self, cipherKeyId, input, iv):
        raise RuntimeError("DRM (CryptoSession) gibt es in H0rSt nicht")

    def Encrypt(self, cipherKeyId, input, iv):
        raise RuntimeError("DRM (CryptoSession) gibt es in H0rSt nicht")

    def Sign(self, macKeyId, message):
        raise RuntimeError("DRM (CryptoSession) gibt es in H0rSt nicht")

    def Verify(self, macKeyId, message, signature):
        raise RuntimeError("DRM (CryptoSession) gibt es in H0rSt nicht")
