"""xbmcgui – ListItem, InfoTagVideo und Dialoge. Dialoge mit Antwort werden zu Rueckfragen an die Oberflaeche."""

L = None  # wird beim Laden gesetzt

INPUT_ALPHANUM, INPUT_NUMERIC, INPUT_DATE, INPUT_TIME, INPUT_IPADDRESS, INPUT_PASSWORD = range(6)
INPUT_TYPE_READONLY, INPUT_TYPE_TEXT, INPUT_TYPE_NUMBER, INPUT_TYPE_SECONDS = -1, 0, 1, 2
INPUT_TYPE_TIME, INPUT_TYPE_DATE, INPUT_TYPE_IPADDRESS, INPUT_TYPE_PASSWORD = 3, 4, 5, 6
INPUT_TYPE_PASSWORD_MD5, INPUT_TYPE_SEARCH, INPUT_TYPE_FILTER, INPUT_TYPE_PASSWORD_NUMBER_VERIFY_NEW = 7, 8, 9, 10
PASSWORD_VERIFY, ALPHANUM_HIDE_INPUT = 1, 2
NOTIFICATION_INFO, NOTIFICATION_WARNING, NOTIFICATION_ERROR = "info", "warning", "error"
HORIZONTAL, VERTICAL = 0, 1
DLG_YESNO_NO_BTN, DLG_YESNO_YES_BTN, DLG_YESNO_CUSTOM_BTN = 10, 11, 12
ICON_TYPE_NONE, ICON_TYPE_SETTINGS, ICON_TYPE_PROGRAMS, ICON_TYPE_WEATHER, ICON_TYPE_PICTURES, ICON_TYPE_VIDEOS, ICON_TYPE_MUSIC = 0, 1, 2, 3, 4, 5, 6
ICON_OVERLAY_NONE, ICON_OVERLAY_RAR, ICON_OVERLAY_ZIP, ICON_OVERLAY_LOCKED = 0, 1, 2, 3
ICON_OVERLAY_UNWATCHED, ICON_OVERLAY_WATCHED, ICON_OVERLAY_HD = 4, 5, 6

# ACTION_* aus xbmc/input/actions/ActionIDs.h und KEY_* aus
# xbmc/input/keymaps/keyboard/KeyIDs.h, Stand Kodi 23 (Alpha 1).
_AKTIONEN = {
    "NONE": 0, "MOVE_LEFT": 1, "MOVE_RIGHT": 2, "MOVE_UP": 3, "MOVE_DOWN": 4, "PAGE_UP": 5,
    "PAGE_DOWN": 6, "SELECT_ITEM": 7, "HIGHLIGHT_ITEM": 8, "PARENT_DIR": 9, "PREVIOUS_MENU": 10,
    "SHOW_INFO": 11, "PAUSE": 12, "STOP": 13, "NEXT_ITEM": 14, "PREV_ITEM": 15, "FORWARD": 16,
    "REWIND": 17, "SHOW_GUI": 18, "ASPECT_RATIO": 19, "STEP_FORWARD": 20, "STEP_BACK": 21,
    "BIG_STEP_FORWARD": 22, "BIG_STEP_BACK": 23, "SHOW_OSD": 24, "SHOW_SUBTITLES": 25,
    "NEXT_SUBTITLE": 26, "PLAYER_DEBUG": 27, "NEXT_PICTURE": 28, "PREV_PICTURE": 29, "ZOOM_OUT": 30,
    "ZOOM_IN": 31, "TOGGLE_SOURCE_DEST": 32, "SHOW_PLAYLIST": 33, "QUEUE_ITEM": 34, "REMOVE_ITEM": 35,
    "SHOW_FULLSCREEN": 36, "ZOOM_LEVEL_NORMAL": 37, "ZOOM_LEVEL_1": 38, "ZOOM_LEVEL_2": 39,
    "ZOOM_LEVEL_3": 40, "ZOOM_LEVEL_4": 41, "ZOOM_LEVEL_5": 42, "ZOOM_LEVEL_6": 43, "ZOOM_LEVEL_7": 44,
    "ZOOM_LEVEL_8": 45, "ZOOM_LEVEL_9": 46, "CALIBRATE_SWAP_ARROWS": 47, "CALIBRATE_RESET": 48,
    "ANALOG_MOVE": 49, "ROTATE_PICTURE_CW": 50, "ROTATE_PICTURE_CCW": 51, "SUBTITLE_DELAY_MIN": 52,
    "SUBTITLE_DELAY_PLUS": 53, "AUDIO_DELAY_MIN": 54, "AUDIO_DELAY_PLUS": 55, "AUDIO_NEXT_LANGUAGE": 56,
    "CHANGE_RESOLUTION": 57, "PLAYER_PROCESS_INFO": 69, "PLAYER_PROGRAM_SELECT": 70,
    "PLAYER_RESOLUTION_SELECT": 71, "SMALL_STEP_BACK": 76, "PLAYER_FORWARD": 77, "PLAYER_REWIND": 78,
    "PLAYER_PLAY": 79, "DELETE_ITEM": 80, "COPY_ITEM": 81, "MOVE_ITEM": 82, "TAKE_SCREENSHOT": 85,
    "RENAME_ITEM": 87, "VOLUME_UP": 88, "VOLUME_DOWN": 89, "VOLAMP": 90, "MUTE": 91, "NAV_BACK": 92,
    "VOLAMP_UP": 93, "VOLAMP_DOWN": 94, "CREATE_EPISODE_BOOKMARK": 95, "CREATE_BOOKMARK": 96,
    "CHAPTER_OR_BIG_STEP_FORWARD": 97, "CHAPTER_OR_BIG_STEP_BACK": 98, "CYCLE_SUBTITLE": 99,
    "MOUSE_START": 100, "MOUSE_LEFT_CLICK": 100, "MOUSE_RIGHT_CLICK": 101, "MOUSE_MIDDLE_CLICK": 102,
    "MOUSE_DOUBLE_CLICK": 103, "MOUSE_WHEEL_UP": 104, "MOUSE_WHEEL_DOWN": 105, "MOUSE_DRAG": 106,
    "MOUSE_MOVE": 107, "MOUSE_LONG_CLICK": 108, "MOUSE_DRAG_END": 109, "MOUSE_END": 109,
    "BACKSPACE": 110, "SCROLL_UP": 111, "SCROLL_DOWN": 112, "ANALOG_FORWARD": 113, "ANALOG_REWIND": 114,
    "MOVE_ITEM_UP": 115, "MOVE_ITEM_DOWN": 116, "CONTEXT_MENU": 117, "SHIFT": 118, "SYMBOLS": 119,
    "CURSOR_LEFT": 120, "CURSOR_RIGHT": 121, "BUILT_IN_FUNCTION": 122, "SHOW_OSD_TIME": 123,
    "ANALOG_SEEK_FORWARD": 124, "ANALOG_SEEK_BACK": 125, "VIS_PRESET_SHOW": 126, "VIS_PRESET_NEXT": 128,
    "VIS_PRESET_PREV": 129, "VIS_PRESET_LOCK": 130, "VIS_PRESET_RANDOM": 131,
    "VIS_RATE_PRESET_PLUS": 132, "VIS_RATE_PRESET_MINUS": 133, "SHOW_VIDEOMENU": 134, "ENTER": 135,
    "INCREASE_RATING": 136, "DECREASE_RATING": 137, "NEXT_SCENE": 138, "PREV_SCENE": 139,
    "NEXT_LETTER": 140, "PREV_LETTER": 141, "JUMP_SMS2": 142, "JUMP_SMS3": 143, "JUMP_SMS4": 144,
    "JUMP_SMS5": 145, "JUMP_SMS6": 146, "JUMP_SMS7": 147, "JUMP_SMS8": 148, "JUMP_SMS9": 149,
    "FILTER_CLEAR": 150, "FILTER_SMS2": 151, "FILTER_SMS3": 152, "FILTER_SMS4": 153, "FILTER_SMS5": 154,
    "FILTER_SMS6": 155, "FILTER_SMS7": 156, "FILTER_SMS8": 157, "FILTER_SMS9": 158, "FIRST_PAGE": 159,
    "LAST_PAGE": 160, "AUDIO_DELAY": 161, "SUBTITLE_DELAY": 162, "MENU": 163, "SET_RATING": 164,
    "PREV_SUBTITLE": 165, "RECORD": 170, "PASTE": 180, "NEXT_CONTROL": 181, "PREV_CONTROL": 182,
    "CHANNEL_SWITCH": 183, "CHANNEL_UP": 184, "CHANNEL_DOWN": 185, "NEXT_CHANNELGROUP": 186,
    "PREVIOUS_CHANNELGROUP": 187, "PVR_PLAY": 188, "PVR_PLAY_TV": 189, "PVR_PLAY_RADIO": 190,
    "PVR_SHOW_TIMER_RULE": 191, "CHANNEL_NUMBER_SEP": 192, "PVR_ANNOUNCE_REMINDERS": 193,
    "TOGGLE_FULLSCREEN": 199, "TOGGLE_WATCHED": 200, "SCAN_ITEM": 201, "TOGGLE_DIGITAL_ANALOG": 202,
    "RELOAD_KEYMAPS": 203, "GUIPROFILE_BEGIN": 204, "TELETEXT_RED": 215, "TELETEXT_GREEN": 216,
    "TELETEXT_YELLOW": 217, "TELETEXT_BLUE": 218, "INCREASE_PAR": 219, "DECREASE_PAR": 220,
    "VSHIFT_UP": 227, "VSHIFT_DOWN": 228, "PLAYER_PLAYPAUSE": 229, "SUBTITLE_VSHIFT_UP": 230,
    "SUBTITLE_VSHIFT_DOWN": 231, "SUBTITLE_ALIGN": 232, "FILTER": 233, "SWITCH_PLAYER": 234,
    "STEREOMODE_NEXT": 235, "STEREOMODE_PREVIOUS": 236, "STEREOMODE_TOGGLE": 237,
    "STEREOMODE_SELECT": 238, "STEREOMODE_TOMONO": 239, "STEREOMODE_SET": 240, "SETTINGS_RESET": 241,
    "SETTINGS_LEVEL_CHANGE": 242, "TRIGGER_OSD": 243, "INPUT_TEXT": 244, "VOLUME_SET": 245,
    "TOGGLE_COMMSKIP": 246, "BROWSE_SUBTITLE": 247, "PLAYER_RESET": 248, "TOGGLE_FONT": 249,
    "VIDEO_NEXT_STREAM": 250, "QUEUE_ITEM_NEXT": 251, "HDR_TOGGLE": 260, "CYCLE_TONEMAP_METHOD": 261,
    "PLAYER_DEBUG_VIDEO": 262, "KEYBOARD_COMPOSING_KEY": 263, "KEYBOARD_COMPOSING_KEY_CANCELLED": 264,
    "KEYBOARD_COMPOSING_KEY_FINISHED": 265, "PLAYER_INCREASE_TEMPO": 266, "PLAYER_DECREASE_TEMPO": 267,
    "CHAPTER_OR_SCENE_OR_BIG_STEP_FORWARD": 268, "CHAPTER_OR_SCENE_OR_BIG_STEP_BACK": 269,
    "DIALOG_SELECT_VIDEO": 270, "DIALOG_SELECT_AUDIO": 271, "DIALOG_SELECT_SUBTITLE": 272,
    "VOICE_RECOGNIZE": 300, "TOUCH_TAP": 401, "TOUCH_TAP_TEN": 410, "TOUCH_LONGPRESS": 411,
    "TOUCH_LONGPRESS_TEN": 420, "GESTURE_NOTIFY": 500, "GESTURE_BEGIN": 501, "GESTURE_ZOOM": 502,
    "GESTURE_ROTATE": 503, "GESTURE_PAN": 504, "GESTURE_ABORT": 505, "GESTURE_SWIPE_LEFT": 511,
    "GESTURE_SWIPE_LEFT_TEN": 520, "GESTURE_SWIPE_RIGHT": 521, "GESTURE_SWIPE_RIGHT_TEN": 530,
    "GESTURE_SWIPE_UP": 531, "GESTURE_SWIPE_UP_TEN": 540, "GESTURE_SWIPE_DOWN": 541,
    "GESTURE_SWIPE_DOWN_TEN": 550, "GESTURE_END": 599, "ANALOG_MOVE_X_LEFT": 601,
    "ANALOG_MOVE_X_RIGHT": 602, "ANALOG_MOVE_Y_UP": 603, "ANALOG_MOVE_Y_DOWN": 604,
    "ERROR": 998, "NOOP": 999,
}
_TASTEN = {
    "BUTTON_A": 256, "BUTTON_B": 257, "BUTTON_X": 258, "BUTTON_Y": 259, "BUTTON_BLACK": 260,
    "BUTTON_WHITE": 261, "BUTTON_LEFT_TRIGGER": 262, "BUTTON_RIGHT_TRIGGER": 263,
    "BUTTON_LEFT_THUMB_STICK": 264, "BUTTON_RIGHT_THUMB_STICK": 265,
    "BUTTON_RIGHT_THUMB_STICK_UP": 266, "BUTTON_RIGHT_THUMB_STICK_DOWN": 267,
    "BUTTON_RIGHT_THUMB_STICK_LEFT": 268, "BUTTON_RIGHT_THUMB_STICK_RIGHT": 269,
    "BUTTON_DPAD_UP": 270, "BUTTON_DPAD_DOWN": 271, "BUTTON_DPAD_LEFT": 272, "BUTTON_DPAD_RIGHT": 273,
    "BUTTON_START": 274, "BUTTON_BACK": 275, "BUTTON_LEFT_THUMB_BUTTON": 276,
    "BUTTON_RIGHT_THUMB_BUTTON": 277, "BUTTON_LEFT_ANALOG_TRIGGER": 278,
    "BUTTON_RIGHT_ANALOG_TRIGGER": 279, "BUTTON_LEFT_THUMB_STICK_UP": 280,
    "BUTTON_LEFT_THUMB_STICK_DOWN": 281, "BUTTON_LEFT_THUMB_STICK_LEFT": 282,
    "BUTTON_LEFT_THUMB_STICK_RIGHT": 283, "VKEY": 0xF000, "VKEY_MAX": 0xF3FF, "VKEY_MASK": 0x03FF,
    "UNICODE": 0xFFFE, "VMOUSE": 0xEFFF, "MOUSE_START": 0xE000, "MOUSE_CLICK": 0xE000,
    "MOUSE_RIGHTCLICK": 0xE001, "MOUSE_MIDDLECLICK": 0xE002, "MOUSE_DOUBLE_CLICK": 0xE010,
    "MOUSE_LONG_CLICK": 0xE020, "MOUSE_WHEEL_UP": 0xE101, "MOUSE_WHEEL_DOWN": 0xE102,
    "MOUSE_MOVE": 0xE103, "MOUSE_DRAG": 0xE104, "MOUSE_DRAG_START": 0xE105, "MOUSE_DRAG_END": 0xE106,
    "MOUSE_RDRAG": 0xE107, "MOUSE_RDRAG_START": 0xE108, "MOUSE_RDRAG_END": 0xE109,
    "MOUSE_NOOP": 0xEFFF, "MOUSE_END": 0xEFFF, "APPCOMMAND": 0xD000, "INVALID": 0xFFFF,
}
globals().update(("ACTION_" + name, wert) for name, wert in _AKTIONEN.items())
globals().update(("KEY_" + name, wert) for name, wert in _TASTEN.items())


def _lauf():
    return L.AKTUELL


def _text(t):
    return L.ohne_format(t)


def _w3c(datum):
    """'2024-01-02' -> '2024-01-02T00:00:00Z' wie Kodis ...AsW3C-Getter."""
    text = str(datum or "")
    return text + "T00:00:00Z" if len(text) == 10 and text[4] == "-" and text[7] == "-" else text


class InfoTagVideo:
    _FELDER = {"Title": "title", "OriginalTitle": "originaltitle", "SortTitle": "sorttitle", "Plot": "plot",
               "PlotOutline": "plotoutline", "Tagline": "tagline", "Year": "year", "Duration": "duration",
               "Rating": "rating", "UserRating": "userrating", "Mpaa": "mpaa", "MediaType": "mediatype",
               "Season": "season", "Episode": "episode", "TvShowTitle": "tvshowtitle", "Premiered": "premiered",
               "FirstAired": "aired", "Trailer": "trailer", "IMDBNumber": "imdbnumber", "Votes": "votes",
               "Top250": "top250", "PlayCount": "playcount", "Path": "path", "FilenameAndPath": "file",
               "DateAdded": "dateadded", "LastPlayed": "lastplayed", "Album": "album", "TrackNumber": "tracknumber",
               "SortSeason": "sortseason", "SortEpisode": "sortepisode", "Set": "set", "SetOverview": "setoverview",
               "ProductionCode": "code", "EpisodeGuide": "episodeguide", "OriginalLanguage": "originallanguage",
               "TvShowStatus": "tvshowstatus", "VideoAssetTitle": "videoassettitle", "Track": "tracknumber",
               "PictureURL": "pictureurl"}
    _LISTEN = {"Genres": "genre", "Genre": "genre", "Countries": "country", "Directors": "director",
               "Director": "director", "Studios": "studio", "Writers": "writer", "Writer": "writer",
               "Tags": "tag", "Artists": "artist", "Artist": "artist", "ShowLinks": "showlink"}

    def __init__(self, daten=None, offscreen=False):
        self._d = daten if daten is not None else {}

    def __getattr__(self, name):
        if name.startswith("set"):
            feld = name[3:]
            if feld in self._FELDER:
                return lambda wert, *rest: self._d.__setitem__(self._FELDER[feld], wert)
            if feld in self._LISTEN:
                return lambda wert, *rest: self._d.__setitem__(self._LISTEN[feld], " / ".join(str(w) for w in (wert or [])))
            return lambda *a, **k: None
        if name.startswith("get"):
            feld = name[3:]
            schluessel = self._FELDER.get(feld) or self._LISTEN.get(feld)
            if schluessel:
                wert = self._d.get(schluessel, "")
                return (lambda: [w for w in str(wert).split(" / ") if w]) if feld in self._LISTEN else (lambda: wert)
            return lambda *a, **k: ""
        if name.startswith(("add", "update")):
            return lambda *a, **k: None
        raise AttributeError(name)

    def setUniqueIDs(self, ids, standard=""):
        self._d["uniqueids"] = dict(ids or {})

    def setUniqueID(self, wert, art="", standard=False):
        self._d.setdefault("uniqueids", {})[art or "unknown"] = wert

    def getUniqueID(self, art):
        return (self._d.get("uniqueids") or {}).get(art, "")

    def setCast(self, darsteller):
        self._d["cast"] = [getattr(a, "_name", str(a)) for a in (darsteller or [])]
        self._d["actors"] = list(darsteller or [])

    def getCast(self):
        return " / ".join(self._d.get("cast") or [])

    def getActors(self):
        return list(self._d.get("actors") or [])

    def getGenre(self):
        return " / ".join(self.getGenres())

    def getDirector(self):
        return " / ".join(self.getDirectors())

    def getWritingCredits(self):
        return " / ".join(self.getWriters())

    def setResumePoint(self, zeit, gesamt=0.0):
        self._d["resume"], self._d["resume_total"] = zeit, gesamt

    def getResumeTime(self):
        return self._d.get("resume", 0.0)

    def getResumeTimeTotal(self):
        return self._d.get("resume_total", 0.0)

    def setDbId(self, dbid):
        self._d["dbid"] = int(dbid or -1)

    def getDbId(self):
        return int(self._d.get("dbid", -1))

    def setSetId(self, setid):
        self._d["setid"] = int(setid or -1)

    def setRatings(self, ratings, defaultrating=""):
        self._d["ratings"] = dict(ratings or {})

    def getVotesAsInt(self, type=""):
        return int(self._d.get("votes", 0) or 0)

    def getLastPlayedAsW3C(self):
        return _w3c(self._d.get("lastplayed", ""))

    def getPremieredAsW3C(self):
        return _w3c(self._d.get("premiered", ""))

    def getFirstAiredAsW3C(self):
        return _w3c(self._d.get("aired", ""))

    def addSeason(self, number, name="", plot=""):
        self._d.setdefault("seasons", []).append((int(number or 0), str(name or ""), str(plot or "")))

    def addSeasons(self, seasons):
        for eintrag in seasons or []:
            self.addSeason(*eintrag)

    def addVideoStream(self, stream):
        self._d.setdefault("videostreams", []).append(stream)

    def addAudioStream(self, stream):
        self._d.setdefault("audiostreams", []).append(stream)

    def addSubtitleStream(self, stream):
        self._d.setdefault("subtitlestreams", []).append(stream)

    def addAvailableArtwork(self, url, art_type="", preview="", referrer="", cache="", post=False,
                            isgz=False, season=-1):
        self._d.setdefault("availableartwork", []).append({"url": url, "type": art_type, "preview": preview,
                                                           "referrer": referrer, "cache": cache,
                                                           "post": post, "isgz": isgz, "season": season})

    def setAvailableFanart(self, images):
        self._d["availablefanart"] = [dict(b) for b in (images or [])]


class Actor:
    def __init__(self, name="", role="", order=-1, thumbnail=""):
        self._name, self._rolle, self._order, self._thumb = name, role, order, thumbnail

    def getName(self):
        return self._name

    def getRole(self):
        return self._rolle

    def getOrder(self):
        return self._order

    def getThumbnail(self):
        return self._thumb

    def setName(self, name):
        self._name = name

    def setRole(self, role):
        self._rolle = role

    def setOrder(self, order):
        self._order = int(order or -1)

    def setThumbnail(self, thumbnail):
        self._thumb = thumbnail


class VideoStreamDetail:
    def __init__(self, width=0, height=0, aspect=0.0, duration=0, codec="", stereoMode="",
                 language="", hdrType="", hdrDetail=""):
        self._w, self._h, self._aspect, self._dauer = int(width or 0), int(height or 0), float(aspect or 0), int(duration or 0)
        self._codec, self._stereo, self._sprache = codec, stereoMode, language
        self._hdr, self._hdr_detail = hdrType, hdrDetail

    def getWidth(self):
        return self._w

    def getHeight(self):
        return self._h

    def getAspect(self):
        return self._aspect

    def getDuration(self):
        return self._dauer

    def getCodec(self):
        return self._codec

    def getStereoMode(self):
        return self._stereo

    def getLanguage(self):
        return self._sprache

    def getHDRType(self):
        return self._hdr

    def getHDRDetail(self):
        return self._hdr_detail

    def setWidth(self, width):
        self._w = int(width or 0)

    def setHeight(self, height):
        self._h = int(height or 0)

    def setAspect(self, aspect):
        self._aspect = float(aspect or 0)

    def setDuration(self, duration):
        self._dauer = int(duration or 0)

    def setCodec(self, codec):
        self._codec = codec

    def setStereoMode(self, stereomode):
        self._stereo = stereomode

    def setLanguage(self, language):
        self._sprache = language

    def setHDRType(self, hdrtype):
        self._hdr = hdrtype

    def setHDRDetail(self, hdrdetail):
        self._hdr_detail = hdrdetail


class AudioStreamDetail:
    def __init__(self, channels=-1, codec="", language=""):
        self._kanaele, self._codec, self._sprache = int(channels if channels is not None else -1), codec, language

    def getChannels(self):
        return self._kanaele

    def getCodec(self):
        return self._codec

    def getLanguage(self):
        return self._sprache

    def setChannels(self, channels):
        self._kanaele = int(channels if channels is not None else -1)

    def setCodec(self, codec):
        self._codec = codec

    def setLanguage(self, language):
        self._sprache = language


class SubtitleStreamDetail:
    def __init__(self, language=""):
        self._sprache = language

    def getLanguage(self):
        return self._sprache

    def setLanguage(self, language):
        self._sprache = language


class ListItem:
    def __init__(self, label="", label2="", path="", offscreen=False, iconImage="", thumbnailImage=""):
        # seit Kodi 19 ist das dritte Argument der Pfad; iconImage/thumbnailImage (Kodi 18) nur noch als Schluesselwort
        self._label, self._label2, self._pfad = L.text(label), L.text(label2), L.text(path)
        self._info, self._kunst, self._eigen, self._kontext = {}, {}, {}, []
        self._untertitel, self._mime, self._ordner = [], "", None
        if iconImage:
            self._kunst["icon"] = iconImage
        if thumbnailImage:
            self._kunst["thumb"] = thumbnailImage

    # fuer laufzeit.eintrag/stream
    def info_daten(self):
        return self._info

    def kunst(self):
        return self._kunst

    def eigenschaften(self):
        return self._eigen

    def kontext(self):
        return self._kontext

    def untertitel(self):
        return self._untertitel

    def mime(self):
        return self._mime

    # Kodi-API
    def getLabel(self):
        return self._label

    def setLabel(self, label):
        self._label = L.text(label)

    def getLabel2(self):
        return self._label2

    def setLabel2(self, label):
        self._label2 = L.text(label)

    def getPath(self):
        return self._pfad

    def setPath(self, path):
        self._pfad = L.text(path)

    def setArt(self, dictionary):
        self._kunst.update({k: v for k, v in (dictionary or {}).items() if v})

    def getArt(self, key):
        return self._kunst.get(key, "")

    def setIconImage(self, iconImage):
        self._kunst["icon"] = iconImage

    def setThumbnailImage(self, thumbFilename):
        self._kunst["thumb"] = thumbFilename

    def setInfo(self, type=None, infoLabels=None):
        werte = infoLabels if infoLabels is not None else (type if isinstance(type, dict) else {})
        for k, v in (werte or {}).items():
            k = str(k).lower()
            if isinstance(v, (list, tuple)):
                v = " / ".join(str(x) for x in v)
            self._info[k] = v

    def getVideoInfoTag(self):
        return InfoTagVideo(self._info)

    def getMusicInfoTag(self):
        return L.stub("xbmc").InfoTagMusic(self._info)

    def getPictureInfoTag(self):
        return L.stub("xbmc").InfoTagPicture(self._info)

    def getGameInfoTag(self):
        return L.stub("xbmc").InfoTagGame(self._info)

    def getDateTime(self):
        return str(self._info.get("date") or self._info.get("premiered") or "")

    def isFolder(self):
        return bool(self._ordner)

    def setFileTitle(self, title):
        self._info["filetitle"] = str(title or "")

    def setCount(self, count):
        self._info["count"] = int(count or 0)

    def setSize(self, size):
        self._info["size"] = int(size or 0)

    def setOverlay(self, overlay):
        self._eigen["overlay"] = str(overlay)

    def addSeason(self, number, name="", plot=""):
        self._info.setdefault("seasons", []).append((int(number or 0), str(name or ""), str(plot or "")))

    def getVotes(self, key=""):
        return int(self._info.get("votes", 0) or 0)

    def setProperty(self, key, value):
        self._eigen[str(key).lower()] = str(value)

    def setProperties(self, dictionary):
        for k, v in (dictionary or {}).items():
            self.setProperty(k, v)

    def getProperty(self, key):
        return self._eigen.get(str(key).lower(), "")

    def addContextMenuItems(self, items, replaceItems=False):
        self._kontext.extend((str(t), str(b)) for t, b in (items or []))

    def setSubtitles(self, subtitleFiles):
        self._untertitel = [str(u) for u in (subtitleFiles or [])]

    def setMimeType(self, mimetype):
        self._mime = str(mimetype or "")

    def setContentLookup(self, enable):
        pass

    def setIsFolder(self, isFolder):
        self._ordner = bool(isFolder)

    def isSelected(self):
        return False

    def select(self, selected):
        pass

    def setRating(self, type="", rating=0.0, votes=0, defaultt=False):
        if isinstance(type, (int, float)) and not isinstance(type, bool):  # alte Schreibweise setRating(rating[, votes])
            type, rating, votes = "default", type, rating or 0
        self._info.setdefault("ratings", {})[str(type or "default")] = (float(rating or 0), int(votes or 0))
        self._info["rating"] = float(rating or 0)

    def addStreamInfo(self, cType, dictionary):
        self._info.setdefault("streamdetails", {})[str(cType or "")] = dict(dictionary or {})

    def setCast(self, actors):
        self._info["cast"] = actors
        self._info["actors"] = list(actors or [])

    def setUniqueIDs(self, dictionary, defaultrating=""):
        self._info["uniqueids"] = dict(dictionary or {})

    def setDateTime(self, dateTime):
        self._info["premiered"] = str(dateTime)[:10]

    def addAvailableArtwork(self, url, art_type="", preview="", referrer="", cache="", post=False,
                            isgz=False, season=-1):
        self._info.setdefault("availableartwork", []).append(
            {"url": url, "type": art_type, "preview": preview, "referrer": referrer,
             "cache": cache, "post": post, "isgz": isgz, "season": season})

    def setAvailableFanart(self, images):
        self._info["availablefanart"] = [dict(b) for b in (images or [])]

    def getDuration(self):
        return int(self._info.get("duration") or 0)

    def getRating(self, *args):
        return float(self._info.get("rating") or 0)

    def getUniqueID(self, key):
        return (self._info.get("uniqueids") or {}).get(key, "")

    def getfilename(self):
        return self._pfad


class Dialog:
    def ok(self, heading, message="", *rest, **kw):
        _lauf().melden(heading, " ".join([str(message)] + [str(r) for r in rest]))
        return True

    def notification(self, heading, message, icon="", time=5000, sound=True):
        _lauf().melden(heading, message)

    def textviewer(self, heading, text, usemono=False):
        _lauf().melden(heading, text)

    def yesno(self, heading, message="", nolabel="", yeslabel="", autoclose=0, defaultbutton=None, **kw):
        a = _lauf().fragen({"art": "janein", "titel": _text(heading), "text": _text(message),
                            "nein": _text(nolabel) or "Nein", "ja": _text(yeslabel) or "Ja"})
        return bool(a)

    def yesnocustom(self, heading, message, customlabel, nolabel="", yeslabel="", autoclose=0, defaultbutton=None):
        a = _lauf().fragen({"art": "auswahl", "titel": _text(heading), "text": _text(message),
                            "optionen": [_text(nolabel) or "Nein", _text(yeslabel) or "Ja", _text(customlabel)]})
        return {0: 0, 1: 1, 2: 2}.get(a if isinstance(a, int) else -1, -1)

    def select(self, heading, list, autoclose=0, preselect=-1, useDetails=False):
        optionen = [_text(x.getLabel() if hasattr(x, "getLabel") else x) for x in list]
        a = _lauf().fragen({"art": "auswahl", "titel": _text(heading), "optionen": optionen, "vorwahl": preselect})
        return a if isinstance(a, int) and 0 <= a < len(optionen) else -1

    def contextmenu(self, list):
        return self.select("", list)

    def multiselect(self, heading, options, autoclose=0, preselect=None, useDetails=False):
        optionen = [_text(x.getLabel() if hasattr(x, "getLabel") else x) for x in options]
        a = _lauf().fragen({"art": "mehrfach", "titel": _text(heading), "optionen": optionen, "vorwahl": list(preselect or [])})
        return [i for i in a if isinstance(i, int) and 0 <= i < len(optionen)] if isinstance(a, list) else None

    def input(self, heading, defaultt="", type=INPUT_ALPHANUM, option=0, autoclose=0):
        a = _lauf().fragen({"art": "eingabe", "titel": _text(heading), "standard": str(defaultt or ""),
                            "zahl": type == INPUT_NUMERIC, "versteckt": type == INPUT_PASSWORD or option == ALPHANUM_HIDE_INPUT})
        return "" if a is None else str(a)

    def numeric(self, type, heading, defaultt="", bHiddenInput=False):
        a = _lauf().fragen({"art": "eingabe", "titel": _text(heading), "standard": str(defaultt or ""), "zahl": True})
        return "" if a is None else str(a)

    def colorpicker(self, heading, selectedcolor="", colorfile="", colorlist=None):
        return str(selectedcolor or "")  # ohne Kodis Farbauswahl bleibt die Vorgabe stehen

    def browse(self, type, heading, shares, mask="", useThumbs=False, treatAsFolder=False, defaultt="", enableMultiple=False):
        return defaultt

    def browseSingle(self, *args, **kwargs):
        return ""

    def browseMultiple(self, *args, **kwargs):
        return []

    def info(self, item):
        return True


class DialogProgress:
    def create(self, heading, message=""):
        pass

    def update(self, percent, message=""):
        lauf = _lauf()
        if lauf:
            lauf.pruefen()

    def iscanceled(self):
        lauf = _lauf()
        return bool(lauf and lauf.abgebrochen)

    def close(self):
        pass


class DialogProgressBG(DialogProgress):
    def update(self, percent=0, heading="", message=""):
        lauf = _lauf()
        if lauf:
            lauf.pruefen()

    def isFinished(self):
        return True


class DialogBusy(DialogProgress):
    pass


class Window:
    def __init__(self, existingWindowId=-1):
        self._id = existingWindowId

    def _speicher(self):
        lauf = _lauf()
        return lauf.fenster if lauf else {}

    def getProperty(self, key):
        return str(self._speicher().get(str(key).lower(), ""))

    def setProperty(self, key, value):
        self._speicher()[str(key).lower()] = str(value)

    def clearProperty(self, key):
        self._speicher().pop(str(key).lower(), None)

    def clearProperties(self):
        self._speicher().clear()

    def show(self):
        pass

    def close(self):
        pass

    def doModal(self):
        pass

    def getFocusId(self):
        return 0

    def getFocus(self):
        return Control()

    def getControl(self, cid):
        return Control()

    def addControl(self, *a):
        pass

    def addControls(self, *a):
        pass

    def removeControl(self, *a):
        pass

    def removeControls(self, *a):
        pass

    def setFocus(self, *a):
        pass

    def setFocusId(self, *a):
        pass

    def getWidth(self):
        return 1920

    def getHeight(self):
        return 1080


class WindowDialog(Window):
    pass


class WindowXML(Window):
    def __init__(self, xmlFilename="", scriptPath="", defaultSkin="Default", defaultRes="720p", isMedia=False):
        Window.__init__(self)
        self._liste, self._position, self._container = [], 0, {}

    def addItem(self, item, position=2 ** 31 - 1):
        if int(position or 0) < len(self._liste):
            self._liste.insert(int(position), item)
        else:
            self._liste.append(item)

    def addItems(self, items):
        for item in items or []:
            self.addItem(item)

    def removeItem(self, position):
        if 0 <= int(position or 0) < len(self._liste):
            del self._liste[int(position)]

    def getCurrentListPosition(self):
        return self._position

    def setCurrentListPosition(self, position):
        self._position = max(0, int(position or 0))

    def getListItem(self, position):
        return self._liste[int(position)] if 0 <= int(position or 0) < len(self._liste) else None

    def getListSize(self):
        return len(self._liste)

    def clearList(self):
        self._liste, self._position = [], 0

    def setContainerProperty(self, strProperty, strValue):
        self._container[str(strProperty).lower()] = str(strValue)

    def setContent(self, strValue):
        self._container["content"] = str(strValue)

    def getCurrentContainerId(self):
        return 0


WindowXMLDialog = WindowXML


class Control:
    """Stellvertreter fuer Kodis Steuerelemente: Werte bleiben im Speicher, angezeigt wird nichts."""

    def __init__(self, x=0, y=0, width=0, height=0):
        self._id, self._x, self._y, self._w, self._h = 0, int(x or 0), int(y or 0), int(width or 0), int(height or 0)
        self._label, self._label2, self._text = "", "", ""
        self._sichtbar, self._an = True, True
        self._liste, self._position, self._prozent = [], 0, 0.0
        self._int, self._float, self._item_height, self._space = 0, 0.0, 0, 0

    def getId(self):
        return self._id

    def getPosition(self):
        return [self._x, self._y]

    def getX(self):
        return self._x

    def getY(self):
        return self._y

    def getHeight(self):
        return self._h

    def getWidth(self):
        return self._w

    def setEnabled(self, enabled):
        self._an = bool(enabled)

    def setVisible(self, visible):
        self._sichtbar = bool(visible)

    def isVisible(self):
        return self._sichtbar

    def setPosition(self, x, y):
        self._x, self._y = int(x or 0), int(y or 0)

    def setWidth(self, width):
        self._w = int(width or 0)

    def setHeight(self, height):
        self._h = int(height or 0)

    def getLabel(self):
        return self._label

    def getLabel2(self):
        return self._label2

    def setLabel(self, label="", font=None, textColor=None, disabledColor=None, shadowColor=None,
                 focusedColor=None, label2=""):
        self._label = L.text(label)
        if label2:
            self._label2 = L.text(label2)

    def getText(self):
        return self._text

    def setText(self, text):
        self._text = L.text(text)

    def addItem(self, item, sendMessage=True):
        self._liste.append(item)

    def addItems(self, items):
        self._liste.extend(list(items or []))

    def removeItem(self, index):
        if 0 <= int(index or 0) < len(self._liste):
            del self._liste[int(index)]

    def selectItem(self, item):
        self._position = max(0, int(item or 0))

    def reset(self):
        self._liste, self._position = [], 0

    def getSelectedPosition(self):
        return self._position

    def getSelectedItem(self):
        return self._liste[self._position] if 0 <= self._position < len(self._liste) else None

    def getListItem(self, index):
        return self._liste[int(index)] if 0 <= int(index or 0) < len(self._liste) else None

    def size(self):
        return len(self._liste)

    def setImageDimensions(self, imageWidth, imageHeight):
        pass

    def setItemHeight(self, height):
        self._item_height = int(height or 0)

    def getItemHeight(self):
        return self._item_height

    def setSpace(self, space):
        self._space = int(space or 0)

    def getSpace(self):
        return self._space

    def setPageControlVisible(self, visible):
        pass

    def setImage(self, imageFilename, useCache=True):
        self._text = L.text(imageFilename)

    def setColorDiffuse(self, hexString):
        pass

    def setPercent(self, pct):
        self._prozent = float(pct or 0)

    def getPercent(self):
        return self._prozent

    def setDisabledColor(self, color):
        pass

    def setSelected(self, selected):
        self._an = bool(selected)

    def isSelected(self):
        return self._an

    def setRadioDimension(self, x, y, width, height):
        self.setPosition(x, y)
        self._w, self._h = int(width or 0), int(height or 0)

    def getInt(self):
        return self._int

    def setInt(self, value, min=0, delta=0, max=0):
        self._int = int(value or 0)

    def getFloat(self):
        return self._float

    def setFloat(self, value, min=0.0, delta=0.0, max=0.0):
        self._float = float(value or 0)

    def getSpinControl(self):
        return Control()

    def __getattr__(self, name):  # weitere Steuerelement-Methoden: nichts tun statt abstuerzen
        return lambda *a, **k: None


ControlButton = ControlLabel = ControlImage = ControlList = ControlTextBox = ControlFadeLabel = ControlEdit = Control
ControlGroup = ControlProgress = ControlRadioButton = ControlSlider = ControlSpin = ControlButton


class Action:
    def __init__(self, id=0, buttonCode=0, amount1=0.0, amount2=0.0):
        self._id, self._button, self._amount1, self._amount2 = int(id or 0), int(buttonCode or 0), amount1, amount2

    def getId(self):
        return self._id

    def getButtonCode(self):
        return self._button

    def getAmount1(self):
        return self._amount1

    def getAmount2(self):
        return self._amount2


def getCurrentWindowId():
    return 10025  # Videos


def getCurrentWindowDialogId():
    return 9999


def getScreenHeight():
    return 1080


def getScreenWidth():
    return 1920
