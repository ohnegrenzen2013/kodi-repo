"""xbmcplugin – was ein Plugin an Kodi meldet, sammelt der laufende Aufruf (laufzeit.Lauf)."""

L = None  # wird beim Laden gesetzt

# Werte aus xbmc/SortFileItem.h (SortMethod) in der Reihenfolge, in der
# xbmc/interfaces/legacy/ModuleXbmcplugin.h sie als SORT_METHOD_* herausgibt.
SORT_METHOD_NONE, SORT_METHOD_LABEL, SORT_METHOD_LABEL_IGNORE_THE, SORT_METHOD_DATE, SORT_METHOD_SIZE = 0, 1, 2, 3, 4
SORT_METHOD_FILE, SORT_METHOD_DRIVE_TYPE, SORT_METHOD_TRACKNUM, SORT_METHOD_DURATION = 5, 6, 7, 8
SORT_METHOD_TITLE, SORT_METHOD_TITLE_IGNORE_THE, SORT_METHOD_ARTIST, SORT_METHOD_ARTIST_IGNORE_THE = 9, 10, 11, 13
SORT_METHOD_ALBUM, SORT_METHOD_ALBUM_IGNORE_THE, SORT_METHOD_GENRE, SORT_METHOD_COUNTRY = 14, 15, 16, 17
SORT_METHOD_VIDEO_YEAR, SORT_METHOD_VIDEO_RATING, SORT_METHOD_VIDEO_USER_RATING, SORT_METHOD_DATEADDED = 18, 19, 20, 21
SORT_METHOD_PROGRAM_COUNT, SORT_METHOD_PLAYLIST_ORDER, SORT_METHOD_EPISODE = 22, 23, 24
SORT_METHOD_VIDEO_TITLE, SORT_METHOD_VIDEO_SORT_TITLE, SORT_METHOD_VIDEO_SORT_TITLE_IGNORE_THE = 25, 26, 27
SORT_METHOD_PRODUCTIONCODE, SORT_METHOD_SONG_RATING, SORT_METHOD_SONG_USER_RATING, SORT_METHOD_MPAA_RATING = 28, 29, 30, 31
SORT_METHOD_VIDEO_RUNTIME, SORT_METHOD_STUDIO, SORT_METHOD_STUDIO_IGNORE_THE = 32, 33, 34
SORT_METHOD_FULLPATH, SORT_METHOD_LABEL_IGNORE_FOLDERS, SORT_METHOD_LASTPLAYED, SORT_METHOD_PLAYCOUNT = 35, 36, 37, 38
SORT_METHOD_LISTENERS, SORT_METHOD_UNSORTED, SORT_METHOD_CHANNEL, SORT_METHOD_BITRATE = 39, 40, 41, 43
SORT_METHOD_DATE_TAKEN, SORT_METHOD_VIDEO_ORIGINAL_TITLE, SORT_METHOD_VIDEO_ORIGINAL_TITLE_IGNORE_THE = 44, 49, 50


def _lauf():
    return L.AKTUELL


def addDirectoryItem(handle, url, listitem, isFolder=False, totalItems=0):
    lauf = _lauf()
    if lauf is None:
        return False
    lauf.pruefen()
    lauf.eintraege.append((L.text(url), listitem, bool(isFolder)))
    return True


def addDirectoryItems(handle, items, totalItems=0):
    for eintrag in items or []:
        url, li = eintrag[0], eintrag[1]
        addDirectoryItem(handle, url, li, eintrag[2] if len(eintrag) > 2 else False)
    return True


def endOfDirectory(handle, succeeded=True, updateListing=False, cacheToDisc=True):
    lauf = _lauf()
    if lauf is not None:
        lauf.ende = bool(succeeded)


def setResolvedUrl(handle, succeeded, listitem):
    lauf = _lauf()
    if lauf is None:
        return
    if succeeded and listitem is not None:
        lauf.aufgeloest = (listitem.getPath(), listitem)
    elif not succeeded:
        lauf.melden("Nicht abspielbar", "Das Addon hat keinen Stream geliefert.")


def setContent(handle, content):
    lauf = _lauf()
    if lauf is not None:
        lauf.inhalt = str(content or "")


def setPluginCategory(handle, category):
    lauf = _lauf()
    if lauf is not None:
        lauf.kategorie = str(category or "")


def addSortMethod(handle, sortMethod, labelMask="", label2Mask=""):
    pass


def setPluginFanart(handle, image=None, color1=None, color2=None, color3=None):
    pass


def setProperty(handle, key, value):
    lauf = _lauf()
    if lauf is not None:
        lauf.fenster["plugin." + str(key).lower()] = str(value)


def getSetting(handle, id):
    lauf = _lauf()
    return lauf.verwaltung.einstellung(lauf.addon["id"], id) if lauf else ""


def setSetting(handle, id, value):
    lauf = _lauf()
    if lauf:
        lauf.verwaltung.einstellung_setzen(lauf.addon["id"], id, value)


def __getattr__(name):  # weitere Sortierarten aus neueren Kodi-Versionen: sortiert wird ohnehin in der Oberflaeche
    if name.startswith("SORT_METHOD_"):
        return 0
    raise AttributeError(name)
