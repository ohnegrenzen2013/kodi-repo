"""xbmcvfs – Dateien; special://-Pfade zeigen in den Kodi-Ordner von H0rSt."""

import os
import shutil

L = None  # wird beim Laden gesetzt


def translatePath(path):
    lauf = L.AKTUELL
    return lauf.pfad(path) if lauf else str(path)


def _p(path):
    return translatePath(path)


def exists(path):
    p = _p(path)
    return os.path.isdir(p) if str(path).endswith(("/", "\\")) else os.path.exists(p)


def mkdir(path):
    try:
        os.mkdir(_p(path))
        return True
    except OSError:
        return os.path.isdir(_p(path))


def mkdirs(path):
    os.makedirs(_p(path), exist_ok=True)
    return True


def rmdir(path, force=False):
    try:
        (shutil.rmtree if force else os.rmdir)(_p(path))
        return True
    except OSError:
        return False


def delete(file):
    try:
        os.remove(_p(file))
        return True
    except OSError:
        return False


deleteFile = delete  # alte Schreibweise aus Kodi 18; das Modul bietet seit Kodi 19 delete


def rename(file, newFile):
    try:
        os.replace(_p(file), _p(newFile))
        return True
    except OSError:
        return False


def copy(strSource, strDestination):
    try:
        shutil.copyfile(_p(strSource), _p(strDestination))
        return True
    except OSError:
        return False


def listdir(path):
    p = _p(path)
    try:
        namen = os.listdir(p)
    except OSError:
        return [], []
    return ([n for n in namen if os.path.isdir(os.path.join(p, n))], [n for n in namen if not os.path.isdir(os.path.join(p, n))])


def makeLegalFilename(name):
    import re
    return re.sub(r'[<>:"|?*]', "_", str(name))


def validatePath(path):
    return str(path)


class Stat:
    def __init__(self, path):
        try:
            self._s = os.stat(_p(path))
        except OSError:
            self._s = None

    def st_size(self):
        return self._s.st_size if self._s else 0

    def st_mtime(self):
        return int(self._s.st_mtime) if self._s else 0

    def st_ctime(self):
        return int(self._s.st_ctime) if self._s else 0

    def st_atime(self):
        return int(self._s.st_atime) if self._s else 0

    def st_mode(self):
        return self._s.st_mode if self._s else 0

    def st_ino(self):
        return int(getattr(self._s, "st_ino", 0) or 0) if self._s else 0

    def st_dev(self):
        return int(getattr(self._s, "st_dev", 0) or 0) if self._s else 0

    def st_nlink(self):
        return int(getattr(self._s, "st_nlink", 0) or 0) if self._s else 0

    def st_uid(self):
        return int(getattr(self._s, "st_uid", 0) or 0) if self._s else 0

    def st_gid(self):
        return int(getattr(self._s, "st_gid", 0) or 0) if self._s else 0


class File:
    def __init__(self, filepath, mode="r"):
        p = _p(filepath)
        modus = {"r": "rb", "w": "wb", "a": "ab", "rb": "rb", "wb": "wb", "ab": "ab"}.get(str(mode or "r"), "rb")
        if "w" in modus or "a" in modus:
            os.makedirs(os.path.dirname(p) or ".", exist_ok=True)
        try:
            self._f = open(p, modus)
        except OSError:
            self._f = None

    def read(self, n=-1):
        if not self._f:
            return ""
        daten = self._f.read() if n is None or n < 0 else self._f.read(n)
        return daten.decode("utf-8", "replace")

    def readBytes(self, n=-1):
        if not self._f:
            return b""
        return bytearray(self._f.read() if n is None or n < 0 else self._f.read(n))

    def write(self, daten):
        if not self._f:
            return False
        try:
            self._f.write(daten.encode("utf-8") if isinstance(daten, str) else bytes(daten))
        except OSError:  # z. B. Platte voll - wie mkdir/rmdir/delete/rename/copy: False statt werfen
            return False
        return True

    def size(self):
        if not self._f:
            return 0
        return os.fstat(self._f.fileno()).st_size

    def seek(self, pos, whence=0):
        return self._f.seek(pos, whence) if self._f else 0

    def tell(self):
        return self._f.tell() if self._f else 0

    def close(self):
        if self._f:
            self._f.close()
            self._f = None

    def __enter__(self):
        return self

    def __exit__(self, *args):
        self.close()
