"""Kodi-Addons verwalten: Repositories, Installieren mit Abhaengigkeiten, Entfernen, Updates, Einstellungen, Aufrufe."""

import collections
import gzip
import io
import os
import threading

from ..archiv import GZIP_FEHLER
from .verwaltung_aufrufe import AufrufeMixin
from .verwaltung_einstellungen import EinstellungenMixin
from .verwaltung_grund import *
from .verwaltung_grund import _KODI_SIX, _KODI_SIX_UTILS, _LINK, _ZAHL, _ZIFFERN, _holen_standard, _teil_vergleich
from .verwaltung_installieren import InstallierenMixin
from .verwaltung_pfade import PfadeMixin
from .verwaltung_repos import ReposMixin


def _entpackt(roh):
    """addons.xml(.gz): gzip mit Obergrenze entpacken."""
    if roh[:2] != b"\x1f\x8b":
        return roh
    try:
        with gzip.GzipFile(fileobj=io.BytesIO(roh)) as g:
            daten = g.read(MAX_XML + 1)
    except GZIP_FEHLER as fehler:  # BadGzipFile ist ein OSError
        raise KodiFehler("addons.xml nicht lesbar: %s" % fehler)
    if len(daten) > MAX_XML:
        raise KodiFehler("addons.xml zu groß")
    return daten


class KodiAddons(PfadeMixin, ReposMixin, InstallierenMixin, EinstellungenMixin, AufrufeMixin):
    _entpackt = staticmethod(_entpackt)

    def __init__(self, datenordner, holen=None):
        self.basis = os.path.abspath(os.path.join(datenordner or ".", "kodi"))
        self.addons = os.path.join(self.basis, "addons")
        self.userdata = os.path.join(self.basis, "userdata")
        self._holen = holen or _holen_standard
        self._sperre = threading.RLock()
        self._infos = {}       # id -> (mtime, info)
        self._kataloge = {}    # repo-id -> (zeit, {id: info})
        self._texte = {}       # id -> {nummer: text}
        self._werte = {}       # id -> {einstellung: wert}
        self.fenster = {}      # Fenster-Eigenschaften (Window(10000).setProperty), bleiben bis zum Neustart
        self._repo_fehler = {}  # repo-id -> (zeit, Fehlermeldung) beim letzten Laden der addons.xml
        self._auto_zeit = 0
        self._direkt = collections.OrderedDict()  # direkte Adressen, die Plugins geliefert haben (nur die spielt H0rSt ab)
        for o in (self.addons, os.path.join(self.userdata, "addon_data"), os.path.join(self.basis, "temp")):
            os.makedirs(o, exist_ok=True)
        modul = os.path.join(self.addons, "script.module.kodi-six", "lib", "kodi_six")
        for name, inhalt in (("__init__.py", _KODI_SIX), ("utils.py", _KODI_SIX_UTILS)):  # neu schreiben, wenn H0rSt sie aendert
            datei = os.path.join(modul, name)
            try:
                with open(datei, encoding="utf-8") as f:
                    if f.read() == inhalt:
                        continue
            except OSError:
                os.makedirs(modul, exist_ok=True)
            with open(datei, "w", encoding="utf-8") as f:
                f.write(inhalt)
        if not os.path.exists(os.path.join(self.addons, "script.module.kodi-six", "addon.xml")):
            with open(os.path.join(self.addons, "script.module.kodi-six", "addon.xml"), "w", encoding="utf-8") as f:
                f.write('<addon id="script.module.kodi-six" name="Kodi Six (H0rSt)" version="0.1.3.1" provider-name="H0rSt">'
                        '<extension point="xbmc.python.module" library="lib"/></addon>')
