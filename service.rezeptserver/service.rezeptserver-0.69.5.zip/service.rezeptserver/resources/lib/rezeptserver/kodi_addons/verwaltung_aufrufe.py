"""Kodi-Addons: Plugins aufrufen, Skins und direkte Streams."""

import os

from . import laufzeit, skins
from .verwaltung_grund import KodiFehler


class AufrufeMixin:
    # --- Aufrufen --------------------------------------------------------------------------------------
    def aufrufen(self, url, antworten=(), tiefe=0):
        """Plugin-Aufruf -> Ergebnis fuer die Oberflaeche; leitet setResolvedUrl auf plugin:// weiter (bis 3x)."""
        aid = laufzeit.zerlegen(url)[0]
        if self.info(aid):  # Kodi legt den Profilordner an, manche Addons schreiben ohne Pruefung hinein
            os.makedirs(os.path.join(self.userdata, "addon_data", aid), exist_ok=True)
        lauf = laufzeit.ausfuehren(self, url, antworten)
        e = laufzeit.ergebnis(lauf)
        with self._sperre:
            for x in e["eintraege"]:
                if not x["ordner"] and x["url"].lower().startswith(("http://", "https://")):
                    self._direkt[x["url"]] = x["titel"]
                    self._direkt.move_to_end(x["url"])
            while len(self._direkt) > 5000:
                self._direkt.popitem(last=False)
        s = e.get("stream")
        if s and s["url"].startswith("plugin://") and tiefe < 3 and not e.get("frage"):
            ziel = s["url"]
            if self.info(laufzeit.zerlegen(ziel)[0]):
                return self.aufrufen(ziel, (), tiefe + 1)
            e["stream"] = None
            e["fehler"] = "Braucht das Addon %s – bitte installieren" % laufzeit.zerlegen(ziel)[0]
        return e

    def skins(self):
        """Installierte Skins mit Farbschemata, Schriften und Hintergruenden fuer den Heim-Style."""
        return [skins.lesen(i, lambda p: laufzeit.bild(self, p)) for i in self.installiert() if i["art"] == "skin"]

    def direkter_stream(self, url):
        """Stream zu einer direkten Adresse aus einer Plugin-Liste – andere Adressen nimmt H0rSt nicht an (kein offener Proxy)."""
        with self._sperre:
            titel = self._direkt.get(str(url or ""))
        if titel is None:
            raise KodiFehler("Diese Adresse kommt aus keinem Addon – bitte den Ordner neu laden")
        return laufzeit.stream_aus_adresse(url, titel)

    def _ausfuehren_datei(self):
        return os.path.join(self.basis, "ausfuehren")

    def ausfuehren_erlaubt(self):
        """ZIP, Adresse und Repository duerfen neuen Code holen. Ab Werk aus (Datei fehlt)."""
        try:
            with open(self._ausfuehren_datei(), encoding="utf-8") as f:
                return f.read().strip() == "1"
        except OSError:
            return False

    def ausfuehren_setzen(self, an):
        pfad = self._ausfuehren_datei()
        if an:
            with open(pfad, "w", encoding="utf-8") as f:
                f.write("1\n")
        else:
            try:
                os.remove(pfad)
            except OSError:
                pass
        return self.ausfuehren_erlaubt()

    def uebersicht(self):
        liste = []
        for i in self.installiert():
            liste.append({"id": i["id"], "name": i["name"], "version": i["version"], "art": i["art"], "inhalt": i["inhalt"],
                          "zusammenfassung": i["zusammenfassung"][:300], "autor": i["autor"],
                          "icon": laufzeit.bild(self, i["icon"]), "fanart": laufzeit.bild(self, i["fanart"]),
                          "fehlt": self.fehlende(i["id"]), "einstellungen": os.path.exists(os.path.join(i["pfad"], "resources", "settings.xml")),
                          "repo": bool(i.get("repo"))})
        return {"addons": liste, "repos": [{"id": r["id"], "name": r["name"]} for r in self.repos()],
                "quellen": [{"id": q["id"], "name": q["name"], "url": q["url"], "repo": bool(q.get("repo"))} for q in self.quellen()],
                "ausfuehren": self.ausfuehren_erlaubt()}
