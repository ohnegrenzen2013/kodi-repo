"""Kodi-Addons: Einstellungen und Texte der installierten Addons."""

import os

from . import einstellungen
from .verwaltung_grund import KodiFehler


class EinstellungenMixin:
    # --- Einstellungen und Texte -----------------------------------------------------------------------
    def _einstellungs_datei(self, aid):
        return os.path.join(self.userdata, "addon_data", aid, "settings.xml")

    def _werte_von(self, aid):
        with self._sperre:
            if aid not in self._werte:
                info = self.info(aid)
                werte = einstellungen.standardwerte(info["pfad"]) if info else {}
                werte.update(einstellungen.lesen(self._einstellungs_datei(aid)))
                self._werte[aid] = werte
            return self._werte[aid]

    def einstellung(self, aid, sid):
        return self._werte_von(aid).get(str(sid), "")

    def einstellung_setzen(self, aid, sid, wert):
        with self._sperre:
            werte = self._werte_von(aid)
            werte[str(sid)] = "" if wert is None else str(wert)
            einstellungen.schreiben(self._einstellungs_datei(aid), werte)

    def einstellungen_lesen(self, aid):
        info = self.info(aid)
        if not info:
            raise KodiFehler("%s ist nicht installiert" % aid)
        werte = self._werte_von(aid)
        seiten = einstellungen.definitionen(info["pfad"], self.texte(aid))
        for s in seiten:
            for f in s["felder"]:
                if "id" in f:
                    f["wert"] = werte.get(f["id"], f.get("standard", ""))
        return {"id": aid, "name": info["name"], "seiten": [s for s in seiten if s["felder"]]}

    def einstellungen_setzen(self, aid, neu):
        if not isinstance(neu, dict):
            raise KodiFehler("Werte als Objekt erwartet")
        with self._sperre:
            werte = self._werte_von(aid)
            for k, v in neu.items():
                werte[str(k)[:120]] = ("true" if v else "false") if isinstance(v, bool) else str(v)[:4000]
            einstellungen.schreiben(self._einstellungs_datei(aid), werte)
        return self.einstellungen_lesen(aid)

    def texte(self, aid):
        with self._sperre:
            if aid not in self._texte:
                info = self.info(aid)
                self._texte[aid] = einstellungen.texte(info["pfad"]) if info else {}
            return self._texte[aid]

    def text(self, aid, nummer):
        try:
            n = int(nummer)
        except (TypeError, ValueError):
            return ""
        return self.texte(aid).get(n) or einstellungen.KODI_TEXTE.get(n, "")
