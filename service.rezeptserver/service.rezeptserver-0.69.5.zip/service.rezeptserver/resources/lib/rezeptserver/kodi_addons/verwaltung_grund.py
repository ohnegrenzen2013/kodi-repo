"""Kodi-Addons: Konstanten, Versionsvergleich, Standardabruf und addon.xml lesen."""

import logging
import re
import urllib.request
import xml.etree.ElementTree as ET

from . import laufzeit

log = logging.getLogger("rezeptserver")

OFFIZIELL = {"id": "kodi-omega", "name": "Kodi (offiziell, Omega)", "info": "https://mirrors.kodi.tv/addons/omega/addons.xml.gz",
             "daten": "https://mirrors.kodi.tv/addons/omega", "fest": True}
KODI_VERSION = (21, 2)
MAX_ZIP = 200 * 1024 * 1024
MAX_XML = 256 * 1024 * 1024  # addons.xml entpackt (gegen Kompressionsbomben)
# Addon-ID: beginnt mit Buchstabe oder Ziffer – "." und ".." waeren Ordner oberhalb von addons/
GUELTIGE_ID = re.compile(r"^[A-Za-z0-9_][\w.\-]{0,119}$")
MAX_DATEIEN = 20000
KATALOG_ZEIT = 6 * 3600
FEHLER_ZEIT = 10 * 60  # nach einem Fehler fragt H0rSt ein Repository so lange nicht erneut (sonst je Addon 60 s warten)
MAX_QUELLEN = 30
AUTO_ZEIT = 6 * 3600  # automatische Updates (Repo-Center) hoechstens so oft
_ZIFFERN = "0123456789"
_ZAHL = re.compile(r"\d*")
_LINK = re.compile(r"""(?i)href\s*=\s*["']([^"'#]+)["']""")
USER_AGENT = "Kodi/21.2 (Linux; Android) H0rSt"
# Abhaengigkeiten, die Kodi selbst mitbringt oder die H0rSt nachbildet: nicht installieren
VIRTUELL = re.compile(r"^(xbmc\.|kodi\.|inputstream\.|resource\.language\.|script\.module\.inputstreamhelper$|"
                      r"script\.module\.kodi-six$|repository\.xbmc\.org$|skin\.|webinterface\.|game\.|audioencoder\.|"
                      r"audiodecoder\.|imagedecoder\.|peripheral\.|pvr\.|visualization\.|screensaver\.)")
# Art eines Addons nach Rangfolge seiner Erweiterungen (ein Plugin mit Dienst bleibt Plugin)
ARTEN = [("xbmc.python.pluginsource", "plugin"), ("xbmc.addon.repository", "repository"), ("xbmc.python.module", "modul"),
         ("xbmc.python.script", "skript"), ("xbmc.python.library", "skript"), ("xbmc.gui.skin", "skin"), ("xbmc.service", "dienst")]
_KODI_SIX = '''"""kodi_six – H0rSt: Python 3, also einfach die Kodi-Module (wie das echte kodi-six unter Python 3)."""
import xbmc, xbmcgui, xbmcplugin, xbmcaddon, xbmcvfs  # noqa: E401,F401
from .utils import PY2, py2_encode, py2_decode, encode_decode  # noqa: F401
'''
_KODI_SIX_UTILS = '''"""kodi_six.utils – unter Python 3 bleibt Text Text."""
import sys

PY2 = sys.version_info[0] == 2


def py2_encode(s, encoding="utf-8", errors="strict"):
    return s


def py2_decode(s, encoding="utf-8", errors="strict"):
    return s


def encode_decode(func):
    return func
'''


class KodiFehler(ValueError):
    pass


def version_tupel(v):
    teile = []
    for t in re.split(r"[.\-~+]", str(v or "0")):
        m = re.match(r"(\d+)", t)
        teile.append(int(m.group(1)) if m else -1 if t else 0)
    return tuple(teile)


def _teil_vergleich(a, b):
    """Kodis CompareComponent (AddonVersion.cpp): Ziffernfolgen als Zahl, sonst Zeichen fuer Zeichen; "~" kommt vor allem."""
    i = j = 0
    while i < len(a) and j < len(b):
        while i < len(a) and j < len(b) and a[i] not in _ZIFFERN and b[j] not in _ZIFFERN:
            if a[i] != b[j]:
                return -1 if a[i] == "~" else 1 if b[j] == "~" else -1 if a[i] < b[j] else 1
            i, j = i + 1, j + 1
        if i < len(a) and j < len(b) and (a[i] not in _ZIFFERN or b[j] not in _ZIFFERN):
            return -1 if a[i] == "~" else 1 if b[j] == "~" else -1 if a[i] in _ZIFFERN else 1
        za, zb = _ZAHL.match(a, i).group(), _ZAHL.match(b, j).group()
        if int(za or 0) != int(zb or 0):
            return -1 if int(za or 0) < int(zb or 0) else 1
        i, j = i + len(za), j + len(zb)
    if i >= len(a) and j >= len(b):
        return 0
    if i < len(a):
        return -1 if a[i] == "~" else 1
    return 1 if b[j] == "~" else -1


def version_vergleich(a, b):
    """Wie Kodi Addon-Versionen vergleicht: [epoche:]version[~vorab] – 1.0.0~beta1 < 1.0.0 < 1.0.0+matrix.1. -> -1, 0, 1"""
    def zerlegen(v):
        v = str(v or "").strip() or "0.0.0"
        epoche = 0
        if ":" in v:
            e, v = v.split(":", 1)
            epoche = int(_ZAHL.match(e).group() or 0)
        haupt, _, vorab = v.partition("~")
        return epoche, haupt, vorab, "~" in v
    ea, ha, va, ta = zerlegen(a)
    eb, hb, vb, tb = zerlegen(b)
    if ea != eb:
        return -1 if ea < eb else 1
    erg = _teil_vergleich(ha, hb)
    if erg or ta != tb:
        return erg or (-1 if ta else 1)  # mit Vorab-Kennung (~beta) aelter als ohne
    return _teil_vergleich(va, vb)


def neuer(a, b):
    """Ist Version a neuer als b?"""
    return version_vergleich(a, b) > 0


def _holen_standard(url, grenze=MAX_ZIP):
    anfrage = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(anfrage, timeout=60) as a:
        daten = a.read(grenze + 1)
    if len(daten) > grenze:
        raise KodiFehler("Zu groß: %s" % url)
    return daten


def addon_xml_lesen(text):
    """addon.xml (ein <addon>) -> dict mit id, name, version, typ, art, skript, bibliothek, abhaengig, repo …"""
    root = ET.fromstring(text) if isinstance(text, (bytes, str)) else text
    if root.tag != "addon":
        root = root.find("addon")
    if root is None or not root.get("id"):
        raise KodiFehler("Keine gültige addon.xml")
    d = {"id": root.get("id"), "name": laufzeit.ohne_format(root.get("name") or root.get("id")), "version": root.get("version") or "0",
         "autor": root.get("provider-name") or "", "abhaengig": [], "art": "sonstiges", "typ": "", "skript": "", "bibliothek": "",
         "inhalt": [], "repo": [], "zusammenfassung": "", "beschreibung": "", "icon_rel": "", "fanart_rel": "", "lizenz": ""}
    for imp in root.findall("requires/import"):
        if imp.get("addon"):
            d["abhaengig"].append({"id": imp.get("addon"), "version": imp.get("version") or "", "optional": imp.get("optional") == "true"})
    punkte = {ext.get("point") or "" for ext in root.findall("extension")}
    d["typ"], d["art"] = next(((p, a) for p, a in ARTEN if p in punkte), ("", "sonstiges"))
    for ext in root.findall("extension"):
        punkt = ext.get("point") or ""
        if punkt == "xbmc.python.pluginsource":
            d["skript"] = ext.get("library") or "default.py"
            d["inhalt"] = [p.strip() for p in (ext.findtext("provides") or "video").split() if p.strip()]
        elif punkt == "xbmc.python.module":
            d["bibliothek"] = ext.get("library") or "lib"
        elif punkt == "xbmc.addon.repository":
            dirs = ext.findall("dir") or [ext]
            for di in dirs:
                info, daten = (di.findtext("info") or "").strip(), (di.findtext("datadir") or "").strip()
                mini = di.get("minversion") or "0"
                maxi = di.get("maxversion") or ""
                if info and daten and version_tupel(mini) <= KODI_VERSION and (not maxi or version_tupel(maxi) >= KODI_VERSION[:1]):
                    d["repo"].append({"info": info, "daten": daten.rstrip("/")})
        elif punkt == "xbmc.addon.metadata":
            for feld, ziel in (("summary", "zusammenfassung"), ("description", "beschreibung")):
                texte = {(e.get("lang") or "en_GB").lower(): (e.text or "").strip() for e in ext.findall(feld)}
                d[ziel] = texte.get("de_de") or texte.get("en_gb") or texte.get("en") or next(iter(texte.values()), "")
            d["lizenz"] = (ext.findtext("license") or "").strip()[:200]
            assets = ext.find("assets")
            if assets is not None:
                d["icon_rel"] = (assets.findtext("icon") or "").strip()
                d["fanart_rel"] = (assets.findtext("fanart") or "").strip()
    return d
