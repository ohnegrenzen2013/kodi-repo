"""Kodi-Addons: ZIP entpacken, installieren, entfernen und Updates."""

import io
import os
import shutil
import zipfile
import xml.etree.ElementTree as ET

from ..archiv import ZIP_FEHLER
from . import laufzeit, skins
from .verwaltung_grund import GUELTIGE_ID, MAX_DATEIEN, MAX_ZIP, VIRTUELL, KodiFehler, addon_xml_lesen, log, neuer


class InstallierenMixin:
    # --- Installieren -----------------------------------------------------------------------------------
    def _entpacken(self, daten, erwartet=None):
        """ZIP eines Addons in addons/<id>; gibt die Info zurueck."""
        try:
            z = zipfile.ZipFile(io.BytesIO(daten))
        except zipfile.BadZipFile:
            raise KodiFehler("Keine ZIP-Datei")
        except ZIP_FEHLER as fehler:
            raise KodiFehler("Keine ZIP-Datei: %s" % fehler)
        try:
            namen = z.namelist()
            if len(namen) > MAX_DATEIEN or sum(i.file_size for i in z.infolist()) > MAX_ZIP * 3:
                raise KodiFehler("ZIP zu groß")
            xml = sorted((n for n in namen if n.count("/") == 1 and n.endswith("/addon.xml")), key=len)
            if not xml:
                raise KodiFehler("Kein Kodi-Addon (addon.xml fehlt)")
            oben = xml[0].split("/")[0]
            info = addon_xml_lesen(z.read(xml[0]))
            # Skins: nur was der Heim-Style braucht (Farben, Schriften, Hintergruende) – nicht 100 MB Fenster und Texturen
            nur = skins.auswahl(z, oben, ET.fromstring(z.read(xml[0]))) if info["art"] == "skin" else None
            if erwartet and info["id"] != erwartet:
                raise KodiFehler("ZIP enthält %s statt %s" % (info["id"], erwartet))
            if not GUELTIGE_ID.match(info["id"]):
                raise KodiFehler("Ungültige Addon-ID")
            ziel = os.path.join(self.addons, info["id"])
            # Zwischenordner mit Punkt vorn: so kann keine Addon-ID heissen (frueher "<id>.neu" – das traf plugin.video.neu)
            neu = os.path.join(self.addons, "." + info["id"] + ".neu")
            shutil.rmtree(neu, ignore_errors=True)
            os.makedirs(neu)
            for eintrag in z.infolist():
                name = eintrag.filename
                if not name.startswith(oben + "/") or name.endswith("/") or (nur is not None and name not in nur):
                    continue
                rel = name[len(oben) + 1:]
                pfad = os.path.abspath(os.path.join(neu, rel))
                if not pfad.startswith(os.path.abspath(neu) + os.sep):  # zip slip
                    continue
                os.makedirs(os.path.dirname(pfad), exist_ok=True)
                with z.open(eintrag) as q, open(pfad, "wb") as f:
                    shutil.copyfileobj(q, f)
            if info["art"] == "skin":  # Texturen aus Textures.xbt als PNG (die .xbt selbst bleibt im ZIP)
                try:
                    skins.texturen_entpacken(z, oben, neu)
                except Exception:  # noqa: BLE001 – ein kaputtes Texturpaket darf die Installation nicht verhindern
                    log.warning("Kodi-Skin %s: Texturen nicht übernommen", info["id"], exc_info=True)
            alt = os.path.join(self.addons, "." + info["id"] + ".alt")
            shutil.rmtree(alt, ignore_errors=True)
            with laufzeit.kein_lauf():  # nicht unter einem laufenden Plugin die Dateien tauschen
                if os.path.exists(ziel):
                    os.replace(ziel, alt)
                os.replace(neu, ziel)
            shutil.rmtree(alt, ignore_errors=True)
            with self._sperre:
                self._infos.pop(info["id"], None)
                self._texte.pop(info["id"], None)
                self._werte.pop(info["id"], None)
            return self.info(info["id"])
        except KodiFehler:
            raise
        except ZIP_FEHLER as fehler:
            # beschaedigte Daten fallen oft erst beim Lesen auf (CRC, gepatchter Deflate-Strom)
            raise KodiFehler("ZIP ist beschädigt: %s" % fehler)
        finally:
            z.close()

    def installieren(self, aid, repo=None, _gesehen=None, erneut=False):
        """Addon samt Abhaengigkeiten aus den Repositories; gibt die Liste der installierten IDs zurueck.
        erneut: auch bei gleicher Version neu entpacken (z. B. Skins, die vor den Texturen installiert wurden)."""
        gesehen = set() if _gesehen is None else _gesehen
        if aid in gesehen or (VIRTUELL.match(aid) and _gesehen is not None):  # Skins u. a. nur, wenn ausdruecklich gewuenscht
            return []
        gesehen.add(aid)
        gefunden = self._finden(aid, repo)
        if not gefunden:
            if self.info(aid):
                return []
            raise KodiFehler("%s ist in keinem Repository" % aid)
        r, d = gefunden
        neu = []
        da = self.info(aid)
        if not da or erneut or neuer(d["version"], da["version"]):
            url = "%s/%s/%s-%s.zip" % (r["daten"], aid, aid, d["version"])
            log.info("Kodi-Addon %s %s aus %s", aid, d["version"], r["name"])
            self._entpacken(self._holen(url), aid)
            neu.append(aid)
        for a in (d["abhaengig"] if d["art"] != "skin" else []):  # Skins brauchen fuer den Heim-Style keine Skripte
            if a["optional"] or VIRTUELL.match(a["id"]):
                continue
            try:
                neu += self.installieren(a["id"], r["id"], gesehen)
            except KodiFehler as fehler:
                log.warning("Kodi-Addon %s: Abhängigkeit %s: %s", aid, a["id"], fehler)
        return neu

    def installieren_zip(self, daten):
        info = self._entpacken(daten)
        neu = [info["id"]]
        for a in (info["abhaengig"] if info["art"] != "skin" else []):
            if not a["optional"] and not self.vorhanden(a["id"]):
                try:
                    neu += self.installieren(a["id"], info["id"] if info.get("repo") else None)
                except KodiFehler as fehler:
                    log.warning("Kodi-Addon %s: Abhängigkeit %s: %s", info["id"], a["id"], fehler)
        return neu

    def installieren_url(self, url):
        url = str(url or "").strip()
        if not url.lower().startswith(("http://", "https://")):
            raise KodiFehler("Adresse muss mit http(s):// beginnen")
        return self.installieren_zip(self._holen(url))

    def entfernen(self, aid):
        info = self.info(aid)
        if not info:
            raise KodiFehler("%s ist nicht installiert" % aid)
        with laufzeit.kein_lauf():
            shutil.rmtree(info["pfad"], ignore_errors=True)
        with self._sperre:
            self._infos.pop(aid, None)
            for rid in [k for k in self._kataloge if k == aid or k.startswith(aid + "#")]:
                self._kataloge.pop(rid, None)
        return {"ok": True}

    def updates(self, rid=None):
        """Neuere Versionen installierter Addons – in allen aktiven Repositories oder nur in rid."""
        ergebnis = []
        katalog = self.katalog(rid) if rid else None
        repos = self.repos()
        for info in self.installiert():
            if info["id"] == "script.module.kodi-six":
                continue
            if katalog is not None:
                d = katalog.get(info["id"])
                gefunden = (self._repo(rid), d) if d else None
            else:
                gefunden = self._finden(info["id"], repos=repos)
            if gefunden and neuer(gefunden[1]["version"], info["version"]):
                ergebnis.append({"id": info["id"], "name": info["name"], "version": info["version"], "neu": gefunden[1]["version"]})
        return ergebnis
