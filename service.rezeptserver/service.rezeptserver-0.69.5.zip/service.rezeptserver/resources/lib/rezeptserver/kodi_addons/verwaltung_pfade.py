"""Kodi-Addons: Pfade, Zertifikate und installierte Addons."""

import os
import shutil
import xml.etree.ElementTree as ET

from .verwaltung_grund import GUELTIGE_ID, VIRTUELL, KodiFehler, addon_xml_lesen, log


class PfadeMixin:
    # --- Pfade ------------------------------------------------------------------------------------
    def zertifikate(self):
        """Kodi bringt special://xbmc/system/certs/cacert.pem mit; manche Addons laden es fuer ssl."""
        ziel = os.path.join(self.basis, "system", "certs", "cacert.pem")
        if os.path.exists(ziel):
            return ziel
        kandidaten = []
        try:
            import certifi
            kandidaten.append(certifi.where())
        except ImportError:
            pass
        import ssl
        kandidaten += [ssl.get_default_verify_paths().cafile or "", "/etc/ssl/certs/ca-certificates.crt", "/etc/ssl/cert.pem",
                       "/etc/pki/tls/certs/ca-bundle.crt", os.path.join(self.addons, "script.module.certifi", "lib", "certifi", "cacert.pem")]
        for k in kandidaten:
            if k and os.path.isfile(k):
                os.makedirs(os.path.dirname(ziel), exist_ok=True)
                shutil.copyfile(k, ziel)
                return ziel
        return None

    def pfad_uebersetzen(self, pfad):
        p = str(pfad or "")
        ersatz = [("special://profile/", self.userdata + "/"), ("special://masterprofile/", self.userdata + "/"),
                  ("special://userdata/", self.userdata + "/"), ("special://home/", self.basis + "/"),
                  ("special://xbmc/", self.basis + "/"), ("special://temp/", os.path.join(self.basis, "temp") + "/"),
                  ("special://cache/", os.path.join(self.basis, "temp") + "/"), ("special://logpath/", os.path.join(self.basis, "temp") + "/"),
                  ("special://database/", os.path.join(self.userdata, "Database") + "/"),
                  ("special://thumbnails/", os.path.join(self.userdata, "Thumbnails") + "/"),
                  ("special://xbmcbin/", self.basis + "/"), ("special://xbmcbinaddons/", self.addons + "/")]
        for alt, neu in ersatz:
            if p.lower().startswith(alt):
                return neu + p[len(alt):]
            if p.lower() == alt.rstrip("/"):
                return neu.rstrip("/")
        return p

    def relativ(self, pfad):
        p = os.path.abspath(pfad)
        return os.path.relpath(p, self.basis) if p.startswith(self.basis + os.sep) else ""

    def datei(self, rel):
        """Datei unterhalb des Kodi-Ordners (Bilder der Addons) oder None."""
        p = os.path.abspath(os.path.join(self.basis, str(rel or "")))
        return p if p.startswith(self.basis + os.sep) and os.path.isfile(p) else None

    # --- Installierte Addons -----------------------------------------------------------------------
    def info(self, aid):
        aid = str(aid or "")
        if not GUELTIGE_ID.match(aid):
            return None
        ordner = os.path.join(self.addons, aid)
        xml = os.path.join(ordner, "addon.xml")
        try:
            zeit = os.path.getmtime(xml)
        except OSError:
            return None
        with self._sperre:
            alt = self._infos.get(aid)
            if alt and alt[0] == zeit:
                return alt[1]
        try:
            with open(xml, "rb") as f:
                d = addon_xml_lesen(f.read())
        except (OSError, ET.ParseError, KodiFehler) as fehler:
            log.warning("Kodi-Addon %s: addon.xml nicht lesbar: %s", aid, fehler)
            return None
        if d["id"] != aid:  # z. B. Rest einer abgebrochenen Installation alter Art (<id>.neu) – kein eigenes Addon
            return None
        d["pfad"] = ordner
        for art in ("icon", "fanart"):
            rel = d.pop(art + "_rel") or ("icon.png" if art == "icon" else "fanart.jpg")
            for kandidat in (rel, "resources/" + os.path.basename(rel), os.path.basename(rel)):
                if os.path.isfile(os.path.join(ordner, kandidat)):
                    d[art] = os.path.join(ordner, kandidat)
                    break
            else:
                d[art] = ""
        with self._sperre:
            self._infos[aid] = (zeit, d)
        return d

    def vorhanden(self, aid):
        return bool(VIRTUELL.match(str(aid or ""))) or self.info(aid) is not None

    def virtuell(self, aid):
        if VIRTUELL.match(str(aid or "")):
            return {"id": aid, "name": aid, "version": "21.0.0", "pfad": "", "icon": "", "fanart": "", "typ": "", "skript": ""}
        return None

    def installiert(self):
        ergebnis = []
        for aid in sorted(os.listdir(self.addons)):
            i = self.info(aid)
            if i:
                ergebnis.append(i)
        return ergebnis

    def bibliotheken(self, aid, gesehen=None):
        """Bibliotheksordner aller Abhaengigkeiten (rekursiv); notnagel() liefert die uebrigen Module."""
        gesehen = set() if gesehen is None else gesehen
        liste = []

        def sammeln(i):
            info = self.info(i)
            if not info or i in gesehen:
                return
            gesehen.add(i)
            if info.get("bibliothek"):
                liste.append(os.path.join(info["pfad"], info["bibliothek"]))
            for a in info["abhaengig"]:
                sammeln(a["id"])
        sammeln(aid)
        return liste

    def notnagel(self, aid):
        """Bibliotheken der uebrigen Module (script.module.*), fuer Addons mit unvollstaendigen Abhaengigkeiten – nur
        echte Module, keine Plugins, die nebenbei ein Modul anbieten (deren resources/lib verdeckte sonst fremde Namen)."""
        eigene = set(self.bibliotheken(aid))
        return [os.path.join(i["pfad"], i["bibliothek"]) for i in self.installiert()
                if i.get("bibliothek") and i["art"] == "modul" and os.path.join(i["pfad"], i["bibliothek"]) not in eigene]

    def fehlende(self, aid):
        info = self.info(aid)
        if not info:
            return []
        return [a["id"] for a in info["abhaengig"] if not a["optional"] and not self.vorhanden(a["id"])]
