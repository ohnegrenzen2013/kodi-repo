"""Kodi-Addons: Repositories, Repo-Center, Quellen und Katalogsuche."""

import hashlib
import json
import os
import re
import time
import xml.etree.ElementTree as ET
from urllib.parse import unquote, urljoin, urlsplit

from .verwaltung_grund import (
    AUTO_ZEIT,
    FEHLER_ZEIT,
    KATALOG_ZEIT,
    MAX_QUELLEN,
    OFFIZIELL,
    KodiFehler,
    _LINK,
    addon_xml_lesen,
    log,
    neuer,
)


class ReposMixin:
    # --- Repositories --------------------------------------------------------------------------------
    def repos(self, alle=False):
        """Repositories: offiziell, installierte repository.*-Addons, Quellen mit addons.xml; abgeschaltete nur mit alle=True."""
        liste = [dict(OFFIZIELL, art="offiziell")]
        for info in self.installiert():
            for n, r in enumerate(info.get("repo") or []):
                liste.append({"id": info["id"] + ("" if n == 0 else "#%d" % n), "name": info["name"] + ("" if n == 0 else " (%d)" % (n + 1)),
                              "info": r["info"], "daten": r["daten"], "addon": info["id"], "art": "addon"})
        bekannt = {r["info"] for r in liste}
        for q in self.quellen():  # Quelle mit addons.xml ist selbst ein Repository (wenn ihr repository.*-Addon noch fehlt)
            if q.get("repo") and q["url"] + "addons.xml" not in bekannt:
                liste.append({"id": q["id"], "name": q["name"], "info": q["url"] + "addons.xml", "daten": q["url"].rstrip("/"), "quelle": q["id"], "art": "quelle"})
        optionen = self._repo_optionen()
        for r in liste:
            o = optionen.get(r["id"]) or {}
            r.update(aktiv=o.get("aktiv", True) is not False, auto=bool(o.get("auto")), name=o.get("name") or r["name"])
        return liste if alle else [r for r in liste if r["aktiv"]]

    # --- Repo-Center: Einstellungen je Repository ----------------------------------------------------
    def _repo_optionen(self):
        try:
            with open(os.path.join(self.basis, "repos.json"), encoding="utf-8") as f:
                d = json.load(f)
            return d if isinstance(d, dict) else {}
        except (OSError, ValueError):
            return {}

    def repo_einstellen(self, rid, werte):
        """{aktiv, auto, name} fuer ein Repository (Name leer = wie im Repository)."""
        self._repo(rid)
        if not isinstance(werte, dict):
            raise KodiFehler("Werte als Objekt erwartet")
        with self._sperre:
            alle = self._repo_optionen()
            o = dict(alle.get(rid) or {})
            for k in ("aktiv", "auto"):
                if k in werte:
                    o[k] = bool(werte[k])
            if "name" in werte:
                o["name"] = " ".join(str(werte["name"] or "").split())[:60]
            alle[rid] = o
            tmp = os.path.join(self.basis, "repos.json.neu")
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(alle, f, ensure_ascii=False, indent=1)
            os.replace(tmp, os.path.join(self.basis, "repos.json"))
        return self.repo_center()

    def repo_center(self, laden=False):
        """Alle Repositories mit Art, Adresse, Einstellungen, Zahl der Addons, Stand und Fehler; laden=True holt die addons.xml frisch."""
        installiert = {i["id"]: i["version"] for i in self.installiert()}
        ergebnis = []
        for r in self.repos(alle=True):
            if laden and r["aktiv"]:
                try:
                    self.katalog(r["id"], frisch=True)
                except (KodiFehler, OSError, ValueError):
                    pass  # steht in _repo_fehler
            with self._sperre:
                k = self._kataloge.get(r["id"])
            eintrag = {k2: r.get(k2) for k2 in ("id", "name", "art", "info", "daten", "addon", "quelle", "aktiv", "auto")}
            eintrag["fest"] = r["art"] == "offiziell"
            eintrag["fehler"] = (self._repo_fehler.get(r["id"]) or (0, ""))[1]
            if k:
                arten = {}
                for d in k[1].values():
                    arten[d["art"]] = arten.get(d["art"], 0) + 1
                eintrag.update(stand=int(k[0]), anzahl=len(k[1]), arten=arten,
                               installiert=sum(1 for aid in k[1] if aid in installiert),
                               updates=sum(1 for aid, d in k[1].items() if aid in installiert and neuer(d["version"], installiert[aid])))
            ergebnis.append(eintrag)
        return {"repos": ergebnis, "quellen": self.quellen()}

    def repo_entfernen(self, rid):
        r = self._repo(rid)
        if r["art"] == "offiziell":
            raise KodiFehler("Das offizielle Kodi-Repository lässt sich nur abschalten")
        if r["art"] == "quelle":
            self.quelle_entfernen(r["quelle"])
        else:
            self.entfernen(r["addon"])  # bei einem Repository-Addon mit mehreren <dir> gehen alle mit
        return self.repo_center()

    def auto_faellig(self):
        return time.time() - self._auto_zeit >= AUTO_ZEIT and any(r["auto"] for r in self.repos())

    def auto_updates(self):
        """Updates aus Repositories mit "automatisch aktualisieren" (hoechstens alle 6 Stunden); gibt die neuen IDs zurueck.

        Ab Werk aus: ohne den Schalter "ausfuehren" wird nichts nachgeladen."""
        if not self.ausfuehren_erlaubt():
            return []
        with self._sperre:
            if time.time() - self._auto_zeit < AUTO_ZEIT:
                return []
            self._auto_zeit = time.time()
        neu = []
        for r in self.repos():
            if not r["auto"]:
                continue
            try:
                liste = self.updates(r["id"])
            except (KodiFehler, OSError, ValueError) as fehler:  # ein Repository nicht erreichbar: die anderen trotzdem
                log.warning("Kodi-Repository %s: automatische Updates: %s", r["name"], fehler)
                continue
            for u in liste:
                try:
                    neu += self.installieren(u["id"], r["id"])
                except (KodiFehler, OSError, ValueError) as fehler:
                    log.warning("Kodi-Addon %s: automatisches Update aus %s: %s", u["id"], r["name"], fehler)
        if neu:
            log.info("Kodi-Addons automatisch aktualisiert: %s", ", ".join(neu))
        return neu

    # --- Quellen (wie Kodi: Dateimanager -> Quelle hinzufuegen) ---------------------------------------
    def _quellen_datei(self):
        return os.path.join(self.basis, "quellen.json")

    def quellen(self):
        try:
            with open(self._quellen_datei(), encoding="utf-8") as f:
                liste = json.load(f)
        except (OSError, ValueError):
            return []
        return [q for q in liste if isinstance(q, dict) and q.get("url") and q.get("id")] if isinstance(liste, list) else []

    def _quellen_schreiben(self, liste):
        with self._sperre:
            tmp = self._quellen_datei() + ".neu"
            with open(tmp, "w", encoding="utf-8") as f:
                json.dump(liste, f, ensure_ascii=False, indent=1)
            os.replace(tmp, self._quellen_datei())

    @staticmethod
    def _quellen_url(url):
        url = str(url or "").strip()
        if not re.match(r"(?i)^https?://[^\s/]+", url):
            raise KodiFehler("Adresse muss mit http(s):// beginnen")
        return url if url.endswith("/") or url.lower().endswith(".zip") else url + "/"

    def quelle_inhalt(self, url):
        """Was unter einer Quelle liegt: Repository (addons.xml), ZIP-Dateien und Unterordner der Seite."""
        url = self._quellen_url(url)
        if url.lower().endswith(".zip"):
            return {"url": url, "repo": False, "zips": [{"name": unquote(url.rsplit("/", 1)[-1]), "url": url}], "ordner": []}
        repo = False
        try:
            roh = self._holen(url + "addons.xml", 64 * 1024 * 1024)
            ET.fromstring(self._entpackt(roh))
            repo = True
        except (KodiFehler, OSError, EOFError, ValueError, ET.ParseError):
            pass
        try:
            seite = self._holen(url, 4 * 1024 * 1024).decode("utf-8", "replace")
        except (KodiFehler, OSError, ValueError) as fehler:
            if not repo:
                raise KodiFehler("Quelle nicht erreichbar: %s" % fehler)
            seite = ""
        zips, ordner, gesehen = [], [], set()
        for href in _LINK.findall(seite):
            ziel = urljoin(url, href.strip())
            if ziel in gesehen or not ziel.lower().startswith(("http://", "https://")):
                continue
            gesehen.add(ziel)
            name = unquote(urlsplit(ziel).path.rstrip("/").rsplit("/", 1)[-1])
            if urlsplit(ziel).path.lower().endswith(".zip"):
                zips.append({"name": name, "url": ziel})
            elif ziel.endswith("/") and ziel.startswith(url) and ziel != url and "?" not in ziel:
                ordner.append({"name": name, "url": ziel})  # Verzeichnisliste ("Index of"), nur unterhalb der Quelle
        zips.sort(key=lambda z: (not z["name"].startswith("repository."), z["name"].lower()))
        return {"url": url, "repo": repo, "zips": zips[:500], "ordner": ordner[:200]}

    def quelle_hinzufuegen(self, url, name=""):
        inhalt = self.quelle_inhalt(url)
        if not inhalt["repo"] and not inhalt["zips"] and not inhalt["ordner"]:
            raise KodiFehler("Unter %s liegen weder eine addons.xml noch ZIP-Dateien" % inhalt["url"])
        liste = [q for q in self.quellen() if q["url"] != inhalt["url"]]
        if len(liste) >= MAX_QUELLEN:
            raise KodiFehler("Höchstens %d Quellen" % MAX_QUELLEN)
        name = " ".join(str(name or "").split())[:60] or urlsplit(inhalt["url"]).netloc
        qid = "quelle-" + hashlib.sha1(inhalt["url"].encode("utf-8")).hexdigest()[:10]
        liste.append({"id": qid, "name": name, "url": inhalt["url"], "repo": inhalt["repo"]})
        self._quellen_schreiben(liste)
        with self._sperre:
            self._kataloge.pop(qid, None)
        return dict(inhalt, id=qid, name=name)

    def quelle_entfernen(self, qid):
        self._quellen_schreiben([q for q in self.quellen() if q["id"] != qid])
        with self._sperre:
            self._kataloge.pop(qid, None)
        return {"ok": True}

    def _repo(self, rid):
        for r in self.repos(alle=True):
            if r["id"] == rid:
                return r
        raise KodiFehler("Unbekanntes Repository: %s" % rid)

    def katalog(self, rid, frisch=False):
        """{id: info} aus addons.xml eines Repositories (6 Stunden zwischengespeichert).

        Ist ein Repository nicht erreichbar, gilt die letzte Liste weiter; ohne Liste wird es 10 Minuten nicht neu gefragt."""
        with self._sperre:
            alt = self._kataloge.get(rid)
            fehler_alt = self._repo_fehler.get(rid)
        if alt and not frisch and time.time() - alt[0] < KATALOG_ZEIT:
            return alt[1]
        if fehler_alt and not frisch and time.time() - fehler_alt[0] < FEHLER_ZEIT:
            if alt:
                return alt[1]
            raise KodiFehler(fehler_alt[1])
        r = self._repo(rid)
        try:
            root = ET.fromstring(self._entpackt(self._holen(r["info"], 64 * 1024 * 1024)))
        except (ET.ParseError, KodiFehler, OSError, EOFError, ValueError) as fehler:
            text = ("addons.xml von %s nicht lesbar: %s" if isinstance(fehler, ET.ParseError) else "%s: %s") % (r["name"], fehler)
            with self._sperre:
                self._repo_fehler[rid] = (time.time(), text[:300])
            if alt:
                log.info("Kodi-Repository %s: %s – nutze die Liste von vorher", r["name"], fehler)
                return alt[1]
            raise KodiFehler(text)
        with self._sperre:
            self._repo_fehler.pop(rid, None)
        eintraege = {}
        for a in root.findall("addon"):
            try:
                d = addon_xml_lesen(a)
            except KodiFehler:
                continue
            d["repo"] = rid
            d["daten"] = r["daten"]
            alt_d = eintraege.get(d["id"])
            if not alt_d or neuer(d["version"], alt_d["version"]):
                eintraege[d["id"]] = d
        with self._sperre:
            self._kataloge[rid] = (time.time(), eintraege)
        return eintraege

    def suchen(self, rid, text="", art="plugin"):
        text = str(text or "").lower().strip()
        katalog = self.katalog(rid)
        installiert = {i["id"]: i for i in self.installiert()}  # einmal, nicht je Katalog-Eintrag (offiziell: ueber 1000)
        treffer = []
        for d in katalog.values():
            if art and d["art"] != art:
                continue
            if text and text not in (d["name"] + " " + d["id"] + " " + d["zusammenfassung"]).lower():
                continue
            da = installiert.get(d["id"])
            treffer.append({"id": d["id"], "name": d["name"], "version": d["version"], "art": d["art"], "inhalt": d["inhalt"],
                            "zusammenfassung": d["zusammenfassung"][:300], "autor": d["autor"],
                            "icon": d["daten"] + "/" + d["id"] + "/" + (d["icon_rel"] or "icon.png"),
                            "installiert": da["version"] if da else "",
                            "update": bool(da and neuer(d["version"], da["version"]))})
        treffer.sort(key=lambda t: t["name"].lower())
        return treffer

    def _finden(self, aid, bevorzugt=None, repos=None):
        """(repo, info) mit der hoechsten Version; das bevorzugte Repository zuerst."""
        bester = None
        for r in sorted(self.repos() if repos is None else repos, key=lambda r: r["id"] != bevorzugt):
            try:
                d = self.katalog(r["id"]).get(aid)
            except (KodiFehler, OSError, ValueError) as fehler:
                log.info("Kodi-Repository %s: %s", r["name"], fehler)
                continue
            if d and (not bester or neuer(d["version"], bester[1]["version"])):
                bester = (r, d)
                if r["id"] == bevorzugt:
                    break
        return bester
