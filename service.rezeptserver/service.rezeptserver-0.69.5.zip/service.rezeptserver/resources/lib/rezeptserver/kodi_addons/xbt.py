"""Kodis Textur-Pakete (media/Textures.xbt) lesen: XBTF-Verzeichnis, LZO1X-Entpacken, Bild als PNG.

Aufbau (Kodi xbmc/guilib/XBTF.h): "XBTF" + Version "2" + uint32 Anzahl; je Datei Pfad (256 Byte), loop, Anzahl Bilder;
je Bild Breite, Hoehe, Format, gepackte und entpackte Groesse (uint64), Dauer, Lage in der Datei (uint64).
Formate: 16 = A8R8G8B8 (im Speicher B, G, R, A), 64 = RGBA8, 128 = RGB8, 32 = A8; 1/2/4/8 = DXT (hier nicht noetig –
Kodis TexturePacker schreibt seit Jahren ARGB mit LZO). Ist die gepackte Groesse kleiner, ist das Bild LZO1X-gepackt.
Alles in reinem Python (die Android-App hat kein python-lzo).
"""

import struct
import zlib

ARGB, A8, RGBA8, RGB8 = 16, 32, 64, 128
MAX_PIXEL = 4096 * 4096


class XbtFehler(ValueError):
    pass


def verzeichnis(daten):
    """[{name, breite, hoehe, format, gepackt, entpackt, lage}] – nur das erste Bild je Datei (Animationen braucht hier keiner)."""
    if daten[:4] != b"XBTF":
        raise XbtFehler("Keine XBT-Datei")
    try:
        (anzahl,) = struct.unpack_from("<I", daten, 5)
        lage, liste = 9, []
        for _ in range(min(anzahl, 100000)):
            name = daten[lage:lage + 256].split(b"\0", 1)[0].decode("utf-8", "replace")
            _, bilder = struct.unpack_from("<II", daten, lage + 256)
            lage += 264
            for n in range(bilder):
                b, h, fmt, gepackt, entpackt, _, ort = struct.unpack_from("<IIIQQIQ", daten, lage)
                lage += 40
                if n == 0:
                    liste.append({"name": name, "breite": b, "hoehe": h, "format": fmt & 0xFFFF, "deckend": bool(fmt & 0x10000),
                                  "gepackt": gepackt, "entpackt": entpackt, "lage": ort})
    except struct.error:
        raise XbtFehler("XBT-Verzeichnis abgeschnitten")
    return liste


def lzo1x(quelle, laenge):
    """LZO1X entpacken (wie lzo1x_decompress_safe); laenge = erwartete Groesse."""
    q, aus, ip = quelle, bytearray(), 0
    n = len(q)

    def kopie(abstand, anzahl):
        start = len(aus) - abstand
        if start < 0:
            raise XbtFehler("LZO: Verweis vor den Anfang")
        if len(aus) + anzahl > laenge:  # vor dem Kopieren pruefen – wenige Eingabe-Bytes koennen riesige Laengen kodieren
            raise XbtFehler("LZO: mehr Daten als angegeben")
        if abstand >= anzahl:
            aus.extend(aus[start:start + anzahl])
        else:  # ueberlappend: das Muster wiederholt sich
            muster = bytes(aus[start:])
            aus.extend((muster * (anzahl // abstand + 1))[:anzahl])

    def lang(t, basis):
        nonlocal ip
        while q[ip] == 0:
            t += 255
            ip += 1
        t += basis + q[ip]
        ip += 1
        return t

    try:
        zustand = "anfang"
        t = 0
        if q[0] > 17:
            t = q[0] - 17
            ip = 1
            aus.extend(q[ip:ip + t])
            ip += t
            zustand = "nach_literal" if t >= 4 else "treffer_folgt"
        while True:
            if zustand in ("anfang", "schleife"):
                t = q[ip]
                ip += 1
                if t >= 16:
                    zustand = "treffer"
                    continue
                if t == 0:
                    t = lang(t, 15)
                if ip + t + 3 > n:
                    raise XbtFehler("LZO: Daten abgeschnitten")
                aus.extend(q[ip:ip + t + 3])
                ip += t + 3
                zustand = "nach_literal"
            if zustand == "nach_literal":  # first_literal_run
                t = q[ip]
                ip += 1
                if t < 16:
                    abstand = 1 + 0x0800 + (t >> 2) + (q[ip] << 2)
                    ip += 1
                    kopie(abstand, 3)
                    zustand = "fertig_treffer"
                else:
                    zustand = "treffer"
            if zustand == "treffer_folgt":  # nach dem ersten kurzen Literal direkt ein Treffer
                t = q[ip]
                ip += 1
                zustand = "treffer"
            if zustand == "treffer":
                if t >= 64:
                    abstand = 1 + ((t >> 2) & 7) + (q[ip] << 3)
                    ip += 1
                    kopie(abstand, (t >> 5) + 1)
                elif t >= 32:
                    t &= 31
                    if t == 0:
                        t = lang(t, 31)
                    abstand = 1 + ((q[ip] | (q[ip + 1] << 8)) >> 2)
                    ip += 2
                    kopie(abstand, t + 2)
                elif t >= 16:
                    abstand = (t & 8) << 11
                    t &= 7
                    if t == 0:
                        t = lang(t, 7)
                    abstand += (q[ip] | (q[ip + 1] << 8)) >> 2
                    ip += 2
                    if abstand == 0:
                        break  # Ende des Datenstroms
                    kopie(abstand + 0x4000, t + 2)
                else:
                    abstand = 1 + (t >> 2) + (q[ip] << 2)
                    ip += 1
                    kopie(abstand, 2)
                zustand = "fertig_treffer"
            if zustand == "fertig_treffer":
                t = q[ip - 2] & 3
                if t == 0:
                    zustand = "schleife"
                    continue
                aus.extend(q[ip:ip + t])  # bis zu 3 Literale, dann der naechste Treffer
                ip += t
                t = q[ip]
                ip += 1
                zustand = "treffer"
            if len(aus) > laenge:
                raise XbtFehler("LZO: mehr Daten als angegeben")
    except IndexError:
        raise XbtFehler("LZO: Daten abgeschnitten")
    if len(aus) != laenge or ip > n:
        raise XbtFehler("LZO: %d statt %d Byte" % (len(aus), laenge))
    return bytes(aus)


def bild(daten, eintrag):
    """(breite, hoehe, RGBA-Bytes) eines Eintrags oder XbtFehler (DXT u. a. nicht)."""
    b, h, fmt = eintrag["breite"], eintrag["hoehe"], eintrag["format"]
    if not (0 < b and 0 < h and b * h <= MAX_PIXEL):
        raise XbtFehler("Ungültige Größe")
    noetig = b * h * {ARGB: 4, RGBA8: 4, RGB8: 3, A8: 1}.get(fmt, 0)
    if not noetig:
        raise XbtFehler("Format %d (DXT) wird nicht entpackt" % fmt)
    if not (noetig <= eintrag["entpackt"] <= noetig + 4096):  # angegebene Groesse muss zum Bild passen
        raise XbtFehler("Größe passt nicht zum Bild")
    roh = daten[eintrag["lage"]:eintrag["lage"] + eintrag["gepackt"]]
    if len(roh) != eintrag["gepackt"]:
        raise XbtFehler("Bild abgeschnitten")
    if eintrag["gepackt"] != eintrag["entpackt"]:
        roh = lzo1x(roh, eintrag["entpackt"])
    if len(roh) < noetig:
        raise XbtFehler("Zu wenig Bilddaten")
    if fmt == ARGB:  # B, G, R, A -> R, G, B, A
        rgba = bytearray(roh[:b * h * 4])
        rgba[0::4], rgba[2::4] = roh[2:b * h * 4:4], roh[0:b * h * 4:4]
        return b, h, bytes(rgba)
    if fmt == RGBA8:
        return b, h, bytes(roh[:b * h * 4])
    if fmt == RGB8:
        rgba = bytearray(b * h * 4)
        for i in range(3):
            rgba[i::4] = roh[i:b * h * 3:3]
        rgba[3::4] = b"\xff" * (b * h)
        return b, h, bytes(rgba)
    if fmt == A8:
        rgba = bytearray(b"\xff" * (b * h * 4))
        rgba[3::4] = roh[:b * h]
        return b, h, bytes(rgba)


def verkleinern(b, h, rgba, hoechstens):
    """Auf hoechstens Pixel Breite verkleinern (naechster Nachbar) – Hintergruende sollen wenig Platz belegen."""
    if b <= hoechstens:
        return b, h, rgba
    nb, nh = hoechstens, max(1, round(h * hoechstens / b))
    spalten = [min(b - 1, x * b // nb) * 4 for x in range(nb)]
    zeilen = []
    for y in range(nh):
        start = min(h - 1, y * h // nh) * b * 4
        zeile = rgba[start:start + b * 4]
        zeilen.append(b"".join(zeile[x:x + 4] for x in spalten))
    return nb, nh, b"".join(zeilen)


def deckend(rgba):
    return rgba[3::4].count(255) == len(rgba) // 4


def png(b, h, rgba, mit_alpha=True):
    """PNG (Farbtyp 6 RGBA oder 2 RGB) mit Filter 0 je Zeile."""
    if not mit_alpha:
        rgb = bytearray(b * h * 3)
        for i in range(3):
            rgb[i::3] = rgba[i::4]
        roh, kanaele, farbtyp = bytes(rgb), 3, 2
    else:
        roh, kanaele, farbtyp = rgba, 4, 6
    zeile = b * kanaele
    daten = b"".join(b"\0" + roh[y * zeile:(y + 1) * zeile] for y in range(h))

    def block(art, inhalt):
        return struct.pack(">I", len(inhalt)) + art + inhalt + struct.pack(">I", zlib.crc32(art + inhalt) & 0xFFFFFFFF)
    return b"\x89PNG\r\n\x1a\n" + block(b"IHDR", struct.pack(">IIBBBBB", b, h, 8, farbtyp, 0, 0, 0)) + \
        block(b"IDAT", zlib.compress(daten, 6)) + block(b"IEND", b"")


def vielfalt(rgba, schritt=97):
    """Wie unterschiedlich die Pixel sind (0 = einfarbig) – einfarbige "Diffuse"-Texturen faerbt Kodi nur ein."""
    proben = [rgba[i:i + 4] for i in range(0, len(rgba) - 3, 4 * schritt)] or [rgba[:4]]
    kanaele = list(zip(*proben))
    return max(max(k) - min(k) for k in kanaele) if kanaele else 0
