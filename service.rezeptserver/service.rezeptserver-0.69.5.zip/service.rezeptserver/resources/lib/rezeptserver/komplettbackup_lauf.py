"""KomplettBackup: ein Lauf zur Zeit (Muster GDrive.im_hintergrund/spiegeln_faellig), sichert die
gewaehlten Teile zuerst lokal (je Teil eine ZIP-Datei), dann nach Google Drive - pro Teil
fehlerisoliert, ein fehlgeschlagener Teil haelt die anderen nicht auf. Einstellungen im eigenen
daten["komplettbackup"]. wiederherstellbar()/jetzt_wiederherstellen() spielen eine lokale ZIP-Datei
wieder ein (ersetzt den jeweiligen Teil komplett) - nur fuer lokale Ziele, Google Drive nicht."""

from . import komplettbackup_kopie as kopie
from .gdrive import DriveFehler
from .komplettbackup_grund import (
    DRIVE_ORDNER,
    INTERVALL_STANDARD,
    INTERVALL_WAHL,
    KomplettBackupFehler,
    SCHLUESSEL,
    log,
    os,
    threading,
    time,
)
from .komplettbackup_teile import aufgeloest, roh


class KomplettBackup:
    def __init__(self, verwaltung, gdrive=None, datenordner=".", uhr=None):
        self._verwaltung = verwaltung
        self.gdrive = gdrive
        self.datenordner = datenordner
        self.uhr = uhr or time.time
        self._sperre = threading.Lock()
        self.auftrag = None  # {fertig, uebersprungen, gesamt, fehler, ende}

    @staticmethod
    def _abschnitt(daten):
        k = daten.get(SCHLUESSEL) if isinstance(daten.get(SCHLUESSEL), dict) else {}
        daten[SCHLUESSEL] = k
        return k

    def _v(self):
        v = self._verwaltung()
        if v is None:
            raise KomplettBackupFehler("Nutzerdaten nicht verfügbar")
        return v

    def _k(self):
        d = self._v().daten()
        return d.get(SCHLUESSEL) if isinstance(d.get(SCHLUESSEL), dict) else {}

    def _setzen(self, **werte):
        def tun(d):
            k = self._abschnitt(d)
            for name, wert in werte.items():
                if wert is None:
                    k.pop(name, None)
                else:
                    k[name] = wert
        self._v().bearbeiten(tun)

    def stand(self, daten):
        k = daten.get(SCHLUESSEL) if isinstance(daten.get(SCHLUESSEL), dict) else {}
        return {"teile": list(k.get("teile") or []), "lokal_an": bool(k.get("lokal_an")),
                "lokal_pfad": str(k.get("lokal_pfad") or ""), "drive_an": bool(k.get("drive_an")),
                "intervall_stunden": int(k.get("intervall_stunden") or INTERVALL_STANDARD),
                "zuletzt": k.get("zuletzt", 0), "fehler": k.get("fehler", ""), "auftrag": self.auftrag}

    @staticmethod
    def einstellungen_setzen(daten, wunsch):
        k = KomplettBackup._abschnitt(daten)
        if "teile" in wunsch:
            teile = wunsch["teile"] if isinstance(wunsch["teile"], list) else []
            k["teile"] = [str(t)[:60] for t in teile if str(t).strip()][:40]
        if "lokal_pfad" in wunsch:
            pfad = str(wunsch["lokal_pfad"] or "").strip()
            k["lokal_pfad"] = kopie.ziel_pruefen(pfad) if pfad else ""
        if "lokal_an" in wunsch:
            k["lokal_an"] = bool(wunsch["lokal_an"])
        if "drive_an" in wunsch:
            k["drive_an"] = bool(wunsch["drive_an"])
        if "intervall_stunden" in wunsch:
            try:
                stunden = int(wunsch["intervall_stunden"])
            except (TypeError, ValueError):
                stunden = -1
            if stunden not in INTERVALL_WAHL:
                raise KomplettBackupFehler("Intervall: " + "/".join(str(s) for s in INTERVALL_WAHL))
            k["intervall_stunden"] = stunden
        return {name: k.get(name) for name in ("teile", "lokal_an", "lokal_pfad", "drive_an", "intervall_stunden")}

    def faellig(self):
        k = self._k()
        return bool(k.get("teile")) and (bool(k.get("lokal_an")) or bool(k.get("drive_an"))) and \
            self.uhr() - float(k.get("zuletzt") or 0) > int(k.get("intervall_stunden") or INTERVALL_STANDARD) * 3600 and \
            not (self.auftrag and not self.auftrag.get("ende"))

    def jetzt_starten(self):
        with self._sperre:
            if self.auftrag and not self.auftrag.get("ende"):
                raise KomplettBackupFehler("Ein Lauf läuft schon")
            self.auftrag = {"fertig": 0, "uebersprungen": 0, "gesamt": 0, "fehler": "", "ende": 0}
        k = self._k()
        einstellung = {"teile": list(k.get("teile") or []), "lokal_an": bool(k.get("lokal_an")),
                       "lokal_pfad": str(k.get("lokal_pfad") or ""), "drive_an": bool(k.get("drive_an"))}

        def los():
            try:
                self._lauf(einstellung)
                self._setzen(zuletzt=self.uhr(), fehler="")
            except KomplettBackupFehler as fehler:
                self.auftrag["fehler"] = str(fehler)
                self._setzen(fehler=str(fehler))
                log.warning("Komplett-Backup: %s", fehler)
            finally:
                self.auftrag["ende"] = self.uhr()
        threading.Thread(target=los, name="komplettbackup", daemon=True).start()
        return self.auftrag

    def _zaehlen(self, ergebnis):
        for schluessel in ("fertig", "uebersprungen", "gesamt"):
            self.auftrag[schluessel] += ergebnis.get(schluessel, 0)

    def _aufgeloeste_pfade(self, teil, namen):
        gefunden = []
        for muster in teil["pfade"]:
            for rel in aufgeloest(namen, muster):
                quelle = os.path.join(self.datenordner, rel)
                if os.path.exists(quelle):
                    gefunden.append((rel, quelle))
        return gefunden

    def _lauf(self, einstellung):
        alle = {t["id"]: t for t in roh(self.datenordner)}
        try:
            namen = os.listdir(self.datenordner)
        except OSError:
            namen = []
        for teil_id in einstellung["teile"]:
            teil = alle.get(teil_id)
            if not teil:
                continue
            pfade = self._aufgeloeste_pfade(teil, namen)
            if not pfade:
                continue
            if einstellung["lokal_an"] and einstellung["lokal_pfad"]:
                try:
                    ziel_zip = os.path.join(einstellung["lokal_pfad"], teil_id + ".zip")
                    ergebnis = kopie.zip_erstellen([(rel, quelle, teil["ausschluss"]) for rel, quelle in pfade], ziel_zip)
                    self.auftrag["fertig"] += ergebnis["dateien"]
                    self.auftrag["gesamt"] += ergebnis["dateien"]
                except (KomplettBackupFehler, OSError) as fehler:
                    log.warning("Komplett-Backup lokal (%s): %s", teil_id, fehler)
            if einstellung["drive_an"] and self.gdrive:
                for rel, quelle in pfade:
                    try:
                        self._zaehlen(self.gdrive.sichern(quelle, [DRIVE_ORDNER, teil_id], ausschluss=teil["ausschluss"]))
                    except (DriveFehler, OSError) as fehler:
                        log.warning("Komplett-Backup Drive (%s/%s): %s", teil_id, rel, fehler)

    def wiederherstellbar(self, daten):
        """Lokale ZIP-Dateien im aktuellen Zielordner, die zu einem bekannten Teil passen:
        [{"id", "name", "groesse", "zeit"}]."""
        k = daten.get(SCHLUESSEL) if isinstance(daten.get(SCHLUESSEL), dict) else {}
        lokal_pfad = str(k.get("lokal_pfad") or "")
        if not lokal_pfad or not os.path.isdir(lokal_pfad):
            return []
        namen = {t["id"]: t["name"] for t in roh(self.datenordner)}
        ergebnis = []
        try:
            dateinamen = os.listdir(lokal_pfad)
        except OSError:
            dateinamen = []
        for datei in sorted(dateinamen):
            teil_id = datei[:-4] if datei.endswith(".zip") else None
            if not teil_id or teil_id not in namen:
                continue
            try:
                st = os.stat(os.path.join(lokal_pfad, datei))
            except OSError:
                continue
            ergebnis.append({"id": teil_id, "name": namen[teil_id], "groesse": st.st_size, "zeit": st.st_mtime})
        return ergebnis

    def jetzt_wiederherstellen(self, teil_id):
        """Spielt die lokale ZIP-Datei eines Teils wieder ein - ersetzt dessen Inhalt komplett."""
        alle = {t["id"] for t in roh(self.datenordner)}
        if teil_id not in alle:
            raise KomplettBackupFehler("Unbekannter Teil: %s" % teil_id)
        k = self._k()
        lokal_pfad = str(k.get("lokal_pfad") or "")
        if not lokal_pfad:
            raise KomplettBackupFehler("Kein lokaler Zielordner eingetragen")
        ziel_zip = os.path.join(lokal_pfad, teil_id + ".zip")
        with self._sperre:
            if self.auftrag and not self.auftrag.get("ende"):
                raise KomplettBackupFehler("Ein Lauf läuft schon")
            self.auftrag = {"fertig": 0, "uebersprungen": 0, "gesamt": 0, "fehler": "", "ende": 0, "art": "wiederherstellen"}

        def los():
            try:
                ergebnis = kopie.zip_wiederherstellen(ziel_zip, self.datenordner)
                self.auftrag["fertig"] = self.auftrag["gesamt"] = ergebnis["teile"]
            except KomplettBackupFehler as fehler:
                self.auftrag["fehler"] = str(fehler)
                log.warning("Komplett-Backup wiederherstellen (%s): %s", teil_id, fehler)
            finally:
                self.auftrag["ende"] = self.uhr()
        threading.Thread(target=los, name="komplettbackup-wiederherstellen", daemon=True).start()
        return self.auftrag
