"""Grundbausteine von Live-TV: Konstanten, Senderlisten, Einstellungspruefung und der
Basis-Abholer. Alles hier wird samt Importen wieder exportiert (rezeptserver.livetv.*),
damit die Aufteilung nach aussen unsichtbar bleibt."""


import base64
import gzip
import json
import logging
import os
import re
import shutil
import threading
import time
import urllib.request
from urllib.parse import quote, urljoin, urlsplit

from . import epg_magenta, frei_tv
from .netz import USER_AGENT

log = logging.getLogger("rezeptserver")

EPG_DATEI = "epg.xml.gz"
EPG_ALTER = 24 * 3600
EPG_MAX_BYTES = 300 * 1024 * 1024  # Standard; wirksam ist GRENZEN["epg"]
STANDARD = {"aus": [], "epg_quelle": "", "epg_grabber": "", "listen": [], "adressen": {}, "adressen_quelle": "",
            "frei": []}
# eingebaute EPG-Grabber: Schluessel -> Anzeigename
GRABBER = {"magenta": epg_magenta.NAME}
ADRESSEN_DATEI = "sender-adressen.json"
ADRESSEN_MAX_BYTES = 50 * 1024 * 1024

# id, Name, Gruppe, tvg-id (XMLTV), offizielle Adresse des Senders
SENDER = [
    ("daserste", "Das Erste", "ARD", "DasErste.de",
     "https://daserste-live.ard-mcdn.de/daserste/live/hls/de/master.m3u8"),
    ("zdf", "ZDF", "ZDF", "ZDF.de", "https://zdf-hls-15.akamaized.net/hls/live/2016498/de/high/master.m3u8"),
    ("3sat", "3sat", "ZDF", "3sat.de", "https://zdf-hls-18.akamaized.net/hls/live/2016501/dach/high/master.m3u8"),
    ("arte", "arte", "Weitere", "ARTE.de", "https://artesimulcast.akamaized.net/hls/live/2030993/artelive_de/index.m3u8"),
    ("phoenix", "phoenix", "Weitere", "phoenix.de",
     "https://zdf-hls-19.akamaized.net/hls/live/2016502/de/high/master.m3u8"),
    ("kika", "KiKA", "Weitere", "KiKA.de", "https://kikageohls.akamaized.net/hls/live/2022693/livetvkika_de/master.m3u8"),
    ("zdfneo", "ZDFneo", "ZDF", "ZDFneo.de", "https://zdf-hls-16.akamaized.net/hls/live/2016499/de/high/master.m3u8"),
    ("zdfinfo", "ZDFinfo", "ZDF", "ZDFinfo.de", "https://zdf-hls-17.akamaized.net/hls/live/2016500/de/high/master.m3u8"),
    ("tagesschau24", "tagesschau24", "ARD", "tagesschau24.de",
     "https://tagesschau-live.ard-mcdn.de/tagesschau/live/hls/de/master.m3u8"),
    ("one", "ONE", "ARD", "One.de", "https://mcdn-one.ard.de/ardone/hls/master.m3u8"),
    ("ardalpha", "ARD alpha", "ARD", "ARDalpha.de", "https://mcdn.br.de/br/fs/ard_alpha/hls/de/master.m3u8"),
    ("br", "BR Fernsehen", "Regional", "BRFernsehenSud.de", "https://mcdn.br.de/br/fs/bfs_sued/hls/de/master.m3u8"),
    ("hr", "hr-fernsehen", "Regional", "hrfernsehen.de", "https://hrhls.akamaized.net/hls/live/2024525/hrhls/index.m3u8"),
    ("mdr", "MDR Sachsen", "Regional", "MDRSachsen.de",
     "https://mdrtvsnhls.akamaized.net/hls/live/2016928/mdrtvsn/index.m3u8"),
    ("ndr", "NDR Niedersachsen", "Regional", "NDRNiedersachsen.de",
     "https://mcdn.ndr.de/ndr/hls/ndr_fs/ndr_nds/master.m3u8"),
    ("rbb", "rbb Berlin", "Regional", "rbbBerlin.de",
     "https://rbb-hls-berlin.akamaized.net/hls/live/2017824/rbb_berlin/index.m3u8"),
    ("sr", "SR Fernsehen", "Regional", "SRFernsehen.de", "https://sr-live.ard-mcdn.de/sr/live/hls/de/master.m3u8"),
    ("swr", "SWR BW", "Regional", "SWRBadenWurttemberg.de",
     "https://swrbwd-hls.akamaized.net/hls/live/2018672/swrbwd/master.m3u8"),
    ("wdr", "WDR", "Regional", "WDR.de", "https://wdr-live.ard-mcdn.de/wdr/live/hls/de/master.m3u8"),
    ("dw", "DW Deutsch", "Weitere", "DWDeutsch.de",
     "https://dwamdstream106.akamaized.net/hls/live/2017965/dwstream106/index.m3u8"),
]
_IDS = [s[0] for s in SENDER]
_STANDARD_ADRESSEN = {s[0]: s[4] for s in SENDER}

# Logos von Wikimedia Commons (aktuelle Fassung laut Wikidata, Eigenschaft P154, alle gemeinfrei).
# Mitgeliefert in rezeptserver/logos/; neu laden mit tools/logos_holen.py.
LOGO_BREITE = 330
LOGO_MAX_BYTES = 1024 * 1024
LOGO_ORDNER = "logos"
LOGOS = {
    "daserste": "c/ca/Das_Erste_2014.svg", "zdf": "c/c1/ZDF_logo.svg", "3sat": "8/81/3sat_2019.svg",
    "arte": "e/ee/Arte_Logo_2026.svg", "phoenix": "4/43/Phoenix-logo-2018.svg", "kika": "e/ef/KIKA-Logo.svg",
    "zdfneo": "c/cc/ZDFneo_2017.svg", "zdfinfo": "3/34/ZDFinfo_2011.svg",
    "tagesschau24": "2/24/Tagesschau24-2012.svg", "one": "3/3d/One_2022.svg", "ardalpha": "4/4b/ARD_alpha.svg",
    "br": "5/51/Logo_Bayerischer_Rundfunk_2024.svg", "hr": "e/ea/HR-Fernsehen_Logo_2023.svg",
    "mdr": "6/61/MDR_Logo_2017.svg", "ndr": "e/e9/Logo_NDR_Fernsehen_2017.svg",
    "rbb": "e/ec/Rbb_Fernsehen_Logo_2017.08.svg", "sr": "9/9c/SR_Fernsehen_Logo_2023.svg",
    "swr": "2/26/SWR_Logo_2023.svg", "wdr": "b/b3/Wdr_fernsehen_logo_2016.svg",
    "dw": "7/75/Deutsche_Welle_symbol_2012.svg",
}


def logo_quelle(sender_id):
    """Adresse des Logos bei Wikimedia Commons, None ohne Logo."""
    pfad = LOGOS.get(sender_id)
    if not pfad:
        return None
    return "https://upload.wikimedia.org/wikipedia/commons/thumb/%s/%dpx-%s.png" % (
        pfad, LOGO_BREITE, pfad.rsplit("/", 1)[1])


class LiveTvFehler(ValueError):
    pass


def pruefe(roh):
    if roh is None:
        roh = {}
    if not isinstance(roh, dict):
        raise LiveTvFehler("livetv muss ein JSON-Objekt sein")
    unbekannt = set(roh) - set(STANDARD)
    if unbekannt:
        raise LiveTvFehler("Unbekannte Live-TV-Einstellungen: %s" % ", ".join(sorted(unbekannt)))
    aus = roh.get("aus") or []
    if not isinstance(aus, list) or not all(isinstance(a, str) for a in aus):
        raise LiveTvFehler("livetv.aus muss eine Liste von Sender-IDs sein")
    falsch = [a for a in aus if a not in _IDS]
    if falsch:
        raise LiveTvFehler("Unbekannte Sender: %s" % ", ".join(falsch))
    try:
        frei = frei_tv.pruefe(roh.get("frei"))
    except frei_tv.FreiFehler as e:
        raise LiveTvFehler(str(e))
    grabber = str(roh.get("epg_grabber") or "").strip()
    if grabber and grabber not in GRABBER:
        raise LiveTvFehler("Unbekannter EPG-Grabber: %s (bekannt: %s)" % (grabber, ", ".join(GRABBER)))
    return {"aus": sorted(set(aus), key=_IDS.index), "epg_quelle": _pruefe_quelle(roh.get("epg_quelle"), "EPG-Quelle"),
            "epg_grabber": grabber, "listen": _pruefe_listen(roh.get("listen")), "adressen": pruefe_adressen(roh.get("adressen")),
            "adressen_quelle": _pruefe_quelle(roh.get("adressen_quelle"), "Adressen-Liste"), "frei": frei}


_UNSICHTBAR = dict.fromkeys(map(ord, "\u200b\u200c\u200d\u2060\ufeff\u00a0"), None)
_GITHUB_BLOB = re.compile(r"^(https?://)(?:www\.)?github\.com/([^/]+)/([^/]+)/blob/(.+?)(?:\?raw=true)?$", re.I)


def adresse_normalisieren(roh):
    """Eingefuegte Playlist- und EPG-Adressen glaetten: Leerraum, unsichtbare Zeichen, Anfuehrungszeichen, <...>, ein
    mitkopiertes url-tvg="...", abgebrochene Zeilen, fehlendes https:// und GitHub-Seiten-Links (blob) -> raw.
    Was danach nicht mit http(s) beginnt, bleibt unveraendert und wird von der Pruefung abgelehnt."""
    text = str(roh or "").translate(_UNSICHTBAR).strip()
    treffer = re.search(r"""(?:url-tvg|x-tvg-url|tvg-url)\s*=\s*["']?([^"'\s]+)""", text, re.I)
    if treffer:
        text = treffer.group(1)
    text = text.strip().strip("<>\"',;").strip()
    if "\n" in text and re.match(r"(?i)https?://", text):
        text = "".join(text.split())  # eine abgebrochene Adresse (Zeilenumbruch beim Einfuegen)
    if text.startswith("//"):
        text = "https:" + text
    elif text and not re.match(r"(?i)^[a-z][a-z0-9+.-]*:", text) and re.match(r"^[\w-]+(\.[\w-]+)+(:\d+)?(/\S*)?$", text):
        text = "https://" + text
    blob = _GITHUB_BLOB.match(text)
    if blob:
        text = "https://raw.githubusercontent.com/%s/%s/%s" % blob.group(2, 3, 4)
    return text


def _pruefe_quelle(roh, was):
    quelle = adresse_normalisieren(roh)
    if quelle and not quelle.lower().startswith(("http://", "https://")):
        raise LiveTvFehler("%s muss mit http:// oder https:// beginnen" % was)
    return quelle


def pruefe_adressen(roh, streng=True):
    """{sender-id: adresse} -> nur abweichende http(s)-Adressen bekannter Sender, in Senderreihenfolge.

    streng=False (Adressen-Liste aus dem Internet): Unbekanntes und Kaputtes wird still uebergangen."""
    roh = roh or {}
    if not isinstance(roh, dict):
        raise LiveTvFehler("Sender-Adressen muessen ein JSON-Objekt {sender-id: adresse} sein")
    adressen = {}
    for sid, url in roh.items():
        url = url.strip() if isinstance(url, str) else None
        if sid not in _STANDARD_ADRESSEN or url is None or (url and not url.lower().startswith(("http://", "https://"))):
            if streng:
                raise LiveTvFehler("Sender %s: Adresse muss mit http:// oder https:// beginnen" % sid
                                   if sid in _STANDARD_ADRESSEN else "Unbekannter Sender: %s" % sid)
            continue
        if url and url != _STANDARD_ADRESSEN[sid]:
            adressen[sid] = url
    return {sid: adressen[sid] for sid in _IDS if sid in adressen}


def liste_id(name):
    from .anbieter import AnbieterFehler, neue_id

    try:
        return neue_id(name)
    except AnbieterFehler as e:
        raise LiveTvFehler(str(e))


def _pruefe_listen(roh):
    roh = roh or []
    if not isinstance(roh, list) or len(roh) > MAX_LISTEN:
        raise LiveTvFehler("livetv.listen muss eine Liste mit hoechstens %d Eintraegen sein" % MAX_LISTEN)
    listen, ids = [], set()
    for eintrag in roh:
        if not isinstance(eintrag, dict) or set(eintrag) - {"name", "url", "an"}:
            raise LiveTvFehler("Jede Liste braucht name und url (optional an)")
        name = " ".join(str(eintrag.get("name") or "").split())[:60]
        url = adresse_normalisieren(eintrag.get("url"))
        if not name:
            raise LiveTvFehler("Liste ohne Namen")
        if not url.lower().startswith(("http://", "https://")):
            raise LiveTvFehler("Liste %s: Adresse muss mit http:// oder https:// beginnen" % name)
        lid = liste_id(name)
        if lid in ids:
            raise LiveTvFehler("Liste %s gibt es doppelt" % name)
        ids.add(lid)
        listen.append({"name": name, "url": url, "an": eintrag.get("an", True) is not False})
    return listen


class _Abholer:
    """Holt eine Quelle hoechstens einmal am Tag im Hintergrund; die letzte gute Fassung bleibt liegen."""

    art = "Quelle"

    def __init__(self, pfad, quelle, holen=None):
        self.pfad = pfad
        self.quelle = quelle
        self.holen = holen or _urllib_oeffnen
        self.fehler = ""
        self._sperre = threading.Lock()
        self._laeuft = False
        self._faden = None

    def _frisch(self):
        return True

    def alter(self):
        try:
            return time.time() - os.path.getmtime(self.pfad)
        except OSError:
            return None

    def zustand(self):
        alter = self.alter()
        return {"quelle": self.quelle, "vorhanden": alter is not None,
                "stand": time.strftime("%Y-%m-%d %H:%M", time.localtime(os.path.getmtime(self.pfad)))
                if alter is not None else "", "fehler": self.fehler}

    def bei_bedarf_erneuern(self, warten=False):
        """Startet eine Aktualisierung, wenn die Datei fehlt oder aelter als einen Tag ist."""
        if not self.quelle and not getattr(self, "zusatz", None):
            return
        if warten:
            # erst eine laufende Aktualisierung abwarten: ist sie gerade fertig, aber die Datei schon wieder
            # veraltet, wuerde die neue sonst an ihr haengen bleiben und nichts laden
            with self._sperre:
                laufend = self._faden if self._laeuft else None
            if laufend is not None:
                laufend.join(timeout=120)
        alter = self.alter()
        if alter is not None and alter < EPG_ALTER and self._frisch():
            return
        with self._sperre:
            faden = self._faden if self._laeuft else None
            if faden is None:
                self._laeuft = True
                faden = self._faden = threading.Thread(target=self._erneuern, name=self.art, daemon=True)
                faden.start()
        if warten:
            faden.join(timeout=120)

    def _erneuern(self):
        temp = self.pfad + ".neu"
        try:
            os.makedirs(os.path.dirname(self.pfad) or ".", exist_ok=True)
            self._laden(temp)
            self._pruefen(temp)
            os.replace(temp, self.pfad)
            self.fehler = ""
            log.info("%s aktualisiert (%d KB)", self.art, os.path.getsize(self.pfad) >> 10)
        except Exception as fehler:  # Quelle down, falsches Format ... die alte Datei bleibt
            self.fehler = str(fehler)
            log.warning("%s konnte nicht geladen werden: %s", self.art, fehler)
            try:
                os.remove(temp)
            except OSError:
                pass
        finally:
            with self._sperre:
                self._laeuft = False

    def _laden(self, temp):
        with self.holen(self.quelle) as antwort:
            self._schreiben(antwort, temp)

    def _schreiben(self, antwort, temp):
        raise NotImplementedError

    def _pruefen(self, temp):
        pass


def _xmltv_innen(daten):
    """Inhalt zwischen <tv ...> und </tv> (Kanaele und Sendungen)."""
    if len(daten) > GRENZEN["epg"]:
        raise zu_gross("EPG", "epg")
    anfang = daten.find(b"<tv")
    ende = daten.rfind(b"</tv>")
    if anfang < 0 or ende < 0:
        return b""
    return daten[daten.find(b">", anfang) + 1:ende].strip() + b"\n"


# --- Eigene Listen (M3U/M3U8 aus dem Internet) --------------------------------

LISTEN_ORDNER = "listen"
MAX_LISTEN = 20
LISTE_MAX_BYTES = 50 * 1024 * 1024
# Groessen-Grenzen fuer geladene Listen – stellt der Admin ein (Admin-Panel → Grenzen, nutzung.server_grenzen_anwenden)
GRENZEN = {"adressen": ADRESSEN_MAX_BYTES, "liste": LISTE_MAX_BYTES, "epg": EPG_MAX_BYTES}


def zu_gross(art, groesse):
    """Fehlermeldung mit Hinweis, wo die Grenze steht."""
    return OSError("%s größer als %d MB – die Grenze stellt der Admin unter Einstellungen → Admin-Panel → Grenzen ein"
                   % (art, max(1, GRENZEN[groesse] >> 20)))
LISTE_MAX_EINTRAEGE = 5000
# nur Netzwerk-Adressen; plugin://, file:// usw. werden ausgelassen
ERLAUBTE_SCHEMATA = ("http", "https", "rtmp", "rtmps", "rtsp", "rtp", "udp")
_ATTRIBUT = re.compile(r'([a-zA-Z0-9-]+)="([^"]*)"')


def _pruefe_xmltv(pfad):
    with gzip.open(pfad, "rb") as f:
        anfang = f.read(4096)
    if b"<tv" not in anfang:
        raise ValueError("Quelle liefert kein XMLTV (kein <tv>-Element am Anfang)")


def _urllib_oeffnen(url):
    teile = urllib.parse.urlsplit(url)
    if teile.username is None:
        # ohne Zugangsdaten, deshalb duerfen Weiterleitungen (z. B. GitHub-Releases) gefolgt werden
        return urllib.request.urlopen(urllib.request.Request(url, headers={"User-Agent": USER_AGENT}), timeout=60)
    # Zugang in der Adresse (z. B. Enigma2-Receiver mit OpenWebif-Passwort): als Basic-Anmeldung schicken und
    # keiner Weiterleitung folgen, damit das Passwort nicht bei einem anderen Server landet
    zugang = "%s:%s" % (urllib.parse.unquote(teile.username), urllib.parse.unquote(teile.password or ""))
    ohne = teile._replace(netloc=teile.hostname + (":%d" % teile.port if teile.port else "")).geturl()

    class _NichtFolgen(urllib.request.HTTPRedirectHandler):
        def redirect_request(self, *args, **kwargs):
            return None

    kopf = {"User-Agent": USER_AGENT, "Authorization": "Basic " + base64.b64encode(zugang.encode("utf-8")).decode("ascii")}
    return urllib.request.build_opener(_NichtFolgen).open(urllib.request.Request(ohne, headers=kopf), timeout=60)
