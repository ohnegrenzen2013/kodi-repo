"""Oberflaeche "Durchsuchen": die Klasse Oberflaeche aus Mixins, alles Weitere aus oberflaeche_grund.

Aufgeteilt: Vorlage in statisch/seite.html, seite.css, seite.js, seite_html/, seite_css/ und seite_js/ (zusammengesetzt in seite.py), Konstanten/Hilfen in oberflaeche_grund.py, die Methoden nach Fach
in oberflaeche_<fach>.py. Nach aussen bleibt alles gleich (rezeptserver.oberflaeche.*)."""

from .oberflaeche_grund import *
from .oberflaeche_grund import __version__, _HLS_URI, _OEFFNER, _RELEASE, _SPRACHE, _datum, _f
from .oberflaeche_kern import KernMixin as _KernMixin
from .oberflaeche_zuhause import ZuhauseMixin as _ZuhauseMixin
from .oberflaeche_suchen import SuchenMixin as _SuchenMixin
from .oberflaeche_anbieter import AnbieterMixin as _AnbieterMixin
from .oberflaeche_dienste import DiensteMixin as _DiensteMixin
from .oberflaeche_heim import HeimMixin as _HeimMixin
from .oberflaeche_wiedergabe import WiedergabeMixin as _WiedergabeMixin
from .oberflaeche_baukasten import BaukastenMixin as _BaukastenMixin
from .oberflaeche_modulstatus import ModulStatusMixin as _ModulStatusMixin
from .oberflaeche_menue import MenueMixin as _MenueMixin
from .oberflaeche_pass_tresor import PassTresorMixin as _PassTresorMixin
from .oberflaeche_link_reiniger import LinkReinigerMixin as _LinkReinigerMixin
from .oberflaeche_spotweb import SpotwebToolsMixin as _SpotwebToolsMixin
from .oberflaeche_usb_tools import UsbToolsMixin as _UsbToolsMixin
from .oberflaeche_gnunet import GnunetToolsMixin as _GnunetToolsMixin
from .oberflaeche_dank import DankMixin as _DankMixin
from .oberflaeche_discord import DiscordMixin as _DiscordMixin
from .oberflaeche_emuleese import EmuleEseMixin as _EmuleEseMixin
from .oberflaeche_qwen_pose import QwenPoseMixin as _QwenPoseMixin
from .oberflaeche_radio import RadioMixin as _RadioMixin
from .oberflaeche_brause import BrauseMixin as _BrauseMixin
from .oberflaeche_sehen import SehenMixin as _SehenMixin
from .oberflaeche_traum import TraumMixin as _TraumMixin
from .oberflaeche_portal import PortalMixin as _PortalMixin
from .oberflaeche_listen import ListenMixin as _ListenMixin
from .oberflaeche_anonym import AnonymMixin as _AnonymMixin
from .oberflaeche_party import PartyMixin as _PartyMixin
from .oberflaeche_kataloge import KatalogeMixin as _KatalogeMixin
from .oberflaeche_sammlungen import SammlungenMixin as _SammlungenMixin
from .oberflaeche_trakt import TraktMixin as _TraktMixin
from .oberflaeche_gdrive import GdriveMixin as _GdriveMixin
from .oberflaeche_appstore import AppStoreMixin as _AppStoreMixin
from .oberflaeche_ember import EmberMixin as _EmberMixin
from .oberflaeche_profile import ProfileMixin as _ProfileMixin
from .oberflaeche_dateien import DateienMixin as _DateienMixin
from .oberflaeche_omnisearch import OmniSearchMixin as _OmniSearchMixin
from .oberflaeche_fehler import FehlerMixin as _FehlerMixin
from .oberflaeche_kodiaddons import KodiAddonsMixin as _KodiAddonsMixin
from .oberflaeche_speicher import SpeicherMixin as _SpeicherMixin
from .oberflaeche_uniqx import UniqxMixin as _UniqxMixin
from .oberflaeche_brillen import BrillenMixin as _BrillenMixin
from .oberflaeche_ki_diff import KiDiffMixin as _KiDiffMixin
from .oberflaeche_magicwx import MagicWxMixin as _MagicWxMixin
from .oberflaeche_shizuku import ShizukuMixin as _ShizukuMixin
from .oberflaeche_keepadb import KeepAdbMixin as _KeepAdbMixin
from .oberflaeche_bilddatensatz import BildDatensatzMixin as _BildDatensatzMixin
from .oberflaeche_vorschlaege import VorschlaegeMixin as _VorschlaegeMixin
from .oberflaeche_mcp import McpMixin as _McpMixin
from .oberflaeche_mcp_server import McpServerMixin as _McpServerMixin
from .oberflaeche_markenerkennung import MarkenErkennungMixin as _MarkenErkennungMixin
from .oberflaeche_komplettbackup import KomplettBackupMixin as _KomplettBackupMixin
from .oberflaeche_suche_global import SucheGlobalMixin as _SucheGlobalMixin
from .oberflaeche_usenet import UsenetMixin as _UsenetMixin
from .oberflaeche_usenet import UsenetStreamMixin as _UsenetStreamMixin
from .oberflaeche_nuvio_plugin import NuvioPluginMixin as _NuvioPluginMixin
from .oberflaeche_benachrichtigungen import BenachrichtigungenMixin as _BenachrichtigungenMixin
from .oberflaeche_understand_anything import UnderstandAnythingMixin as _UnderstandAnythingMixin
from .oberflaeche_p2p_torrent import P2pTorrentMixin as _P2pTorrentMixin
from .oberflaeche_geraete_sync import GeraeteSyncMixin as _GeraeteSyncMixin
from .oberflaeche_kinder import KinderMixin as _KinderMixin
from .oberflaeche_lesezeichen import _LesezeichenMixin
from .oberflaeche_reihen import ReihenMixin as _ReihenMixin
from .oberflaeche_poster import PosterMixin as _PosterMixin
from .oberflaeche_mdblist import MdblistMixin as _MdblistMixin
from .oberflaeche_trailer import TrailerMixin as _TrailerMixin
from .oberflaeche_simkl import SimklMixin as _SimklMixin
from .oberflaeche_nuvio import NuvioMixin as _NuvioMixin
from .oberflaeche_anime_tracker import AnimeTrackerMixin as _AnimeTrackerMixin
from .oberflaeche_untertitel import UntertitelMixin as _UntertitelMixin
from .oberflaeche_downloads import DownloadsMixin as _DownloadsMixin
from .oberflaeche_cloudstream import CloudStreamMixin as _CloudStreamMixin
from .oberflaeche_szene_musik import _SzeneMusikMixin


class Oberflaeche(_KernMixin, _ZuhauseMixin, _SuchenMixin, _AnbieterMixin, _DiensteMixin, _HeimMixin, _WiedergabeMixin, _BaukastenMixin, _ModulStatusMixin, _MenueMixin, _PassTresorMixin, _LinkReinigerMixin, _SpotwebToolsMixin, _UsbToolsMixin, _GnunetToolsMixin, _DankMixin, _DiscordMixin, _EmuleEseMixin, _QwenPoseMixin, _RadioMixin, _BrauseMixin, _SehenMixin, _TraumMixin, _PortalMixin, _ListenMixin, _AnonymMixin, _PartyMixin, _KatalogeMixin, _SammlungenMixin, _TraktMixin, _SimklMixin, _NuvioMixin, _AnimeTrackerMixin, _UntertitelMixin, _DownloadsMixin, _CloudStreamMixin, _GdriveMixin, _AppStoreMixin, _EmberMixin, _ProfileMixin, _DateienMixin, _OmniSearchMixin, _FehlerMixin, _KodiAddonsMixin, _SpeicherMixin, _UniqxMixin, _BrillenMixin, _KiDiffMixin, _MagicWxMixin, _ShizukuMixin, _KeepAdbMixin, _BildDatensatzMixin, _VorschlaegeMixin, _McpMixin, _McpServerMixin, _MarkenErkennungMixin, _KomplettBackupMixin, _SucheGlobalMixin, _UsenetMixin, _UsenetStreamMixin, _BenachrichtigungenMixin, _NuvioPluginMixin, _UnderstandAnythingMixin, _P2pTorrentMixin, _GeraeteSyncMixin, _KinderMixin, _LesezeichenMixin, _ReihenMixin, _PosterMixin, _MdblistMixin, _TrailerMixin, _SzeneMusikMixin):
    """Oberflaeche "Durchsuchen" samt /api/-Schnittstelle."""
