"Medien und Dienste: YouTube, XDCC, Stream-Badges und Waechter."

from .oberflaeche_heim_grund import (
    BADGE_BEISPIELE,
    badges_modul,
    json,
    threading,
    urlsplit,
    xdcc,
    youtube,
)

class _MedienMixin:

    # --- YouTube --------------------------------------------------------------------------------
    def youtube_post(self, pfad, koerper):
        yt = self.app.youtube
        try:
            daten = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(daten, dict):
                raise ValueError("JSON-Objekt erwartet")
            if pfad == "/api/youtube/abspielen":
                a = yt.adresse(str(daten.get("id", "")))
                antwort = {k: a[k] for k in ("titel", "kanal", "kanal_id", "dauer", "bild", "live", "hls")}
                antwort["extern"] = a["url"]  # App, Kodi, VLC: direkt
                antwort["url"] = self.hls_merken(a["url"], a["kopf"]) if a["hls"] else \
                    "api/wiedergabe/" + self._wiedergabe_merken(a["url"], a["kopf"], [urlsplit(a["url"]).hostname or ""])
                antwort["segmente"] = yt.sponsorblock(str(daten.get("id", "")))
                return 200, "application/json", antwort
            if pfad == "/api/youtube/speichern":  # Download (tempo 1) oder REC (anderes Tempo)
                self.app.youtube_speichern.starten(str(daten.get("id", "")), str(daten.get("titel", "")),
                                                   daten.get("tempo", 1.0))
                return 200, "application/json", self.app.youtube_speichern.zustand()
            if pfad == "/api/youtube/datei_weg":
                self.app.youtube_speichern.loeschen(daten.get("name"))
                return 200, "application/json", self.app.youtube_speichern.zustand()
            if pfad == "/api/youtube/api_schluessel":
                return 200, "application/json", self.youtube_api_schluessel(daten)
            if pfad == "/api/youtube/abonnieren":
                kanal = yt.abonnieren(daten.get("kanal"))
                return 200, "application/json", {"einstellung": yt.einstellung, "neu": kanal}
            if pfad == "/api/youtube/abbestellen":
                yt.abbestellen(str(daten.get("id", "")))
            elif pfad == "/api/youtube/einstellungen":
                yt.einstellen(daten)
            else:
                return 404, "application/json", {"fehler": "nicht gefunden"}
            return 200, "application/json", {"einstellung": yt.einstellung}
        except (ValueError, UnicodeDecodeError, youtube.YoutubeFehler, OSError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}

    # --- XDCC -----------------------------------------------------------------------------------
    def xdcc_post(self, pfad, koerper):
        try:
            daten = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(daten, dict):
                raise ValueError("JSON-Objekt erwartet")
            x = self.app.xdcc
            if pfad == "/api/xdcc/laden":
                x.laden(daten.get("server"), daten.get("kanal"), daten.get("bot"), daten.get("paket"), daten.get("name", ""))
            elif pfad == "/api/xdcc/abbrechen":
                x.abbrechen(daten.get("id"))
            elif pfad == "/api/xdcc/loeschen":
                x.loeschen(daten.get("name"))
            elif pfad == "/api/xdcc/quelle":  # eigene XDCC-Liste (XDCCParser/iroffer) hinzufuegen oder entfernen
                if not self.app.verwaltung:
                    return 503, "application/json", {"fehler": "Nutzerdaten nicht verfügbar"}
                eigene = self.app.verwaltung.bearbeiten(lambda d: xdcc.eigene_aendern(d, daten))
                return 200, "application/json", dict(x.zustand(), eigene=eigene)
            else:
                return 404, "application/json", {"fehler": "nicht gefunden"}
            daten_jetzt = self.app.verwaltung.daten() if self.app.verwaltung else {}
            return 200, "application/json", dict(x.zustand(), eigene=xdcc.eigene_pruefe(daten_jetzt))
        except (ValueError, UnicodeDecodeError, xdcc.XdccFehler, OSError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}

    # --- Stream-Badges (wie Nuvio) --------------------------------------------------------------
    def badges_speichern(self, koerper):
        try:
            neu = badges_modul.pruefe(json.loads(koerper.decode("utf-8") or "{}"))
            if self.app.verwaltung:
                def setzen(d):
                    d[badges_modul.SCHLUESSEL] = neu
                self.app.verwaltung.aendern(setzen)
            self.app.badges.setzen(neu, laden=True)  # neue Sets gleich laden, damit die Vorschau stimmt
        except (ValueError, UnicodeDecodeError, badges_modul.BadgeFehler) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        return 200, "application/json", dict(self.app.badges.zustand(),
                                             beispiele=[{"text": t, "badges": self.app.badges.zuordnen(t)} for t in BADGE_BEISPIELE])

    # --- Waechter: Verfuegbarkeit ---------------------------------------------------------------
    def waechter_post(self, pfad, koerper):
        from . import waechter
        try:
            daten = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(daten, dict):
                raise ValueError("JSON-Objekt erwartet")
            if pfad == "/api/waechter/pruefen":
                if daten.get("id"):
                    return 200, "application/json", self.app.waechter.pruefen(str(daten["id"]))
                if not self.app.waechter.laeuft_gerade:
                    threading.Thread(target=self.app.waechter.pruefen, name="waechter-jetzt", daemon=True).start()
                return 200, "application/json", dict(self.app.waechter.zustand(), laeuft=True)
            if pfad == "/api/waechter/einstellungen":
                if not self.app.verwaltung:
                    raise ValueError("Nutzerdaten nicht verfügbar")
                return 200, "application/json", self.app.waechter.einstellen(daten)
        except (ValueError, UnicodeDecodeError, waechter.WaechterFehler) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        return 404, "application/json", {"fehler": "nicht gefunden"}
