"""Kataloge zur Auswahl (kataloge.py): Streaming-Anbieter, Reality, Shows, Konzerte, xREL, eigene Feeds,
durchstoeberbare Kataloge eingetragener Stremio-Addons und eigene Quellen fuer Filme/Serien (eigene_quelle.py).

  GET  /api/kataloge                               Uebersicht (Kataloge, Streaming-Dienste, eigene Feeds/Quellen, Addon-Kataloge)
  GET  /api/katalog?art=demnaechst&id=movie|series  TMDb: die naechsten 60 Tage (nur mit TMDb-Schlüssel)
  GET  /api/katalog?art=streaming&id=nfx&typ=movie  Titel bei einem Streaming-Anbieter
  GET  /api/katalog?art=thema&id=reality&skip=0     Reality, Talkshows, Spielshows, Konzerte, Dokus
  GET  /api/katalog?art=xrel&id=movie|series|xxx&seite=1   neueste Releases (xxx nur mit Ab-18-Freigabe)
  GET  /api/katalog?art=feed&url=…                  ein eingetragener RSS-/Atom-Feed
  GET  /api/katalog?art=liste&id=URL                eine eingetragene Liste von MDBList oder Trakt
  GET  /api/katalog?art=listensuche&q=…             oeffentliche Listen auf MDBList und Trakt suchen
  GET  /api/katalog?art=addon&addon=ID&typ=movie|series&id=KATALOG&genre=…&skip=…   Katalog eines Addons
  GET  /api/katalog?art=quelle&url=…&seite=1&q=…    eine eingetragene eigene Quelle (Filme/Serien), q grenzt ein
  GET  /api/katalog?art=trending&id=movie|series    TMDb: Top 10 heute (nur mit TMDb-Schlüssel)
  GET  /api/katalog?art=jahrzehnt&id=movie-2020&skip=0   TMDb: ein Jahrzehnt (nur mit TMDb-Schlüssel)
  GET  /api/katalog?art=franchise&id=Star+Wars      TMDb: ein Franchise/eine Collection (nur mit TMDb-Schlüssel)
  GET  /api/katalog?art=zusatz&id=TMDB_ID&typ=movie TMDb: Budget/FSK/Streaming-Anbieter zu einem Titel (nur mit TMDb-Schlüssel)
  POST /api/kataloge                               {feed_dazu: {name, url}} | {feed_weg: url} | {liste_dazu: {name, url}}
                                                   | {liste_weg: url} | {quelle_dazu: {name, url, muster?, typ?, aktiv?}}
                                                   | {quelle_weg: url} | {mdblist_key: text} | {tmdb_key: text}
                                                   | {dienst_dazu: {name, seite, suche?, katalog?, art?, symbol?, farbe?, id?}}
                                                   | {dienst_weg: id}
  POST /api/kataloge/erkennen                      {url} -> Vorschau einer eigenen Quelle, speichert nichts
  POST /api/seiten-suche/erkennen                  {url, probe?} -> Suchformular/OpenSearch einer Webseite erkennen
"""

import json

from . import eigene_quelle, kataloge, seiten_suche
from .netz import NetzFehler


class KatalogeMixin:

    def kataloge_lesen(self, pfad, werte):
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        k = self.app.kataloge
        try:
            if pfad == "/api/kataloge":
                return 200, "application/json", k.uebersicht(daten)
            art, kid = werte.get("art"), werte.get("id", "")
            if art == "streaming":
                return 200, "application/json", k.streaming(kid, werte.get("typ", "movie"))
            if art == "thema":
                return 200, "application/json", k.thema(kid, werte.get("skip", 0))
            if art == "xrel":
                if kid == "xxx" and not self.app.ab18.freigegeben:
                    return 403, "application/json", {"fehler": "Erst Ab 18 freigeben"}
                return 200, "application/json", k.xrel(kid, werte.get("seite", 1))
            if art == "feed":
                return 200, "application/json", k.feed(werte.get("url", ""), daten)
            if art == "liste":
                return 200, "application/json", k.liste(werte.get("id") or werte.get("url", ""), daten)
            if art == "listensuche":
                return 200, "application/json", k.listen_suchen(werte.get("q", ""), daten)
            if art == "addon":
                return 200, "application/json", k.addon(werte.get("addon", ""), werte.get("typ", "movie"), kid,
                                                         werte.get("genre", ""), werte.get("skip", 0))
            if art == "quelle":
                return 200, "application/json", self.app.eigene_quellen.katalog(werte.get("url", ""), daten,
                                                                                werte.get("seite", 1), werte.get("q", ""))
            if art == "trending":
                return 200, "application/json", k.tmdb_trending(kid, daten)
            if art == "demnaechst":
                return 200, "application/json", k.demnaechst(kid, daten)
            if art == "jahrzehnt":
                typ, _, dekade = kid.partition("-")
                return 200, "application/json", k.jahrzehnt(typ, dekade, werte.get("skip", 0), daten)
            if art == "franchise":
                return 200, "application/json", k.tmdb_franchise(kid, daten)
            if art == "zusatz":
                return 200, "application/json", k.tmdb_zusatz(kid, werte.get("typ", "movie"), daten)
            return 400, "application/json", {"fehler": "art: streaming, thema, xrel, feed, liste, listensuche, addon, quelle, "
                                                        "trending, demnaechst, jahrzehnt, franchise oder zusatz"}
        except (kataloge.KatalogFehler, eigene_quelle.KatalogFehler, NetzFehler) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}

    def kataloge_post(self, koerper):
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(wunsch, dict):
                raise ValueError("JSON-Objekt erwartet")
            if not self.app.verwaltung:
                raise ValueError("Nutzerdaten nicht verfügbar")
            return 200, "application/json", self.app.verwaltung.bearbeiten(lambda d: kataloge.aendern(d, wunsch))
        except (ValueError, UnicodeDecodeError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}

    def seiten_suche_erkennen(self, koerper):
        """Eine Webseite laden und ihre Suche erkennen; speichert nichts."""
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(wunsch, dict):
                raise ValueError("JSON-Objekt erwartet")
            sucher = seiten_suche.SeitenSuche(holen=self.app.eigene_quellen.holen,
                                             probe=wunsch.get("probe") is True)
            return 200, "application/json", sucher.erkennen(wunsch.get("url", ""))
        except (ValueError, UnicodeDecodeError, seiten_suche.SeitenSucheFehler, NetzFehler) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}

    def kataloge_erkennen(self, koerper):
        """POST /api/kataloge/erkennen {url} -> Vorschau einer eigenen Quelle (eigene_quelle.erkennen), speichert nichts."""
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(wunsch, dict):
                raise ValueError("JSON-Objekt erwartet")
            return 200, "application/json", self.app.eigene_quellen.erkennen(wunsch.get("url", ""))
        except (ValueError, UnicodeDecodeError, eigene_quelle.KatalogFehler, NetzFehler) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
