"""Live-TV-Teil des SuchenMixin: Sender, EPG, eigene Listen und Xtream."""

import time

from . import iptv_archiv
from .oberflaeche_grund import frei_tv, json, livetv, livetv_sehen, log


class SuchenLivetvMixin:
    # --- Live-TV ---------------------------------------------------------------
    def _alle_sender(self):
        """Alle spielbaren Sender (oeffentlich-rechtlich, kostenlos, eigene Listen) in einer Form fuer das Sender-Grid.

        gruppe ist die Quelle (Playlist: "Öffentlich-rechtlich" oder der Listenname, fuer die Playlists-Ansicht);
        kategorie ist der Inhalt (ARD/ZDF/Regional/Weitere bzw. das group-title der M3U, fuer die Kategorien-Ansicht)."""
        ergebnis = [{"id": s["id"], "name": s["name"], "logo": ("logos/" + s["id"] + ".png") if s["logo"] else None,
                     "url": s["url"], "gruppe": "Öffentlich-rechtlich", "kategorie": s["gruppe"], "tvg_id": s["tvg_id"]}
                    for s in livetv.sender(self.app.livetv, self.app.adressen.adressen()) if s["an"]]
        for lid, liste in self.app.listen.items():
            for i, e in enumerate(liste.eintraege()):
                attr = e.get("attribute") or {}
                eintrag = {"id": "%s-%d" % (lid, i), "name": e["name"],
                           "logo": attr.get("tvg-logo") or None, "url": e["url"], "gruppe": liste.name,
                           "kategorie": attr.get("group-title") or liste.name}
                tvg = str(attr.get("tvg-id") or "").strip()
                if tvg:
                    eintrag["tvg_id"] = tvg
                tage = iptv_archiv.tage_von(attr)
                if tage:
                    eintrag["archiv_tage"] = tage
                ergebnis.append(eintrag)
        return ergebnis

    def _listen_eintrag(self, sender_id):
        """Roheintrag einer eigenen Liste zu einer Grid-Id 'liste-index', sonst None."""
        lid, _, index = str(sender_id or "").rpartition("-")
        liste = self.app.listen.get(lid) if lid and index.isdigit() else None
        if liste is None:
            return None
        eintraege = liste.eintraege()
        stelle = int(index)
        if stelle < 0 or stelle >= len(eintraege):
            return None
        return eintraege[stelle]

    def jetzt_lesen(self):
        """{sender_id: {"titel","bis"}} der aktuell laufenden Sendung je Kachel mit tvg-id.

        Eigene Listen nur, wenn die M3U selbst eine tvg-id traegt, die in der EPG vorkommt. Kurzer
        Zeit-Zwischenspeicher (2 Minuten), damit ein Sender-Grid die XMLTV-Datei nicht staendig neu parst."""
        jetzt = time.time()
        stand = self.__dict__.get("_jetzt_stand")
        if stand and jetzt - stand[0] < 120:
            return stand[1]
        zuordnung = {s["tvg_id"]: s["id"] for s in self._alle_sender() if s.get("tvg_id")}
        treffer = livetv.jetzt_sendungen(self.app.datenordner, zuordnung, jetzt=jetzt)
        ergebnis = {zuordnung[tvg_id]: wert for tvg_id, wert in treffer.items()}
        self._jetzt_stand = (jetzt, ergebnis)
        return ergebnis

    def guide_lesen(self, sender_id, archiv=False):
        """Programm-Vorschau (GUIDE, L4) fuer einen einzelnen Sender aus dem Grid. Eigene Listen nur,
        wenn die M3U eine tvg-id mitbringt, die in der EPG vorkommt — keine erfundene Zuordnung.
        archiv=True nimmt beendete Sendungen im ausgewiesenen Archiv-Fenster dazu (nur wenn die Playlist
        Archiv-Tage nennt)."""
        sender = next((s for s in self._alle_sender() if s["id"] == sender_id), None)
        tvg_id = sender.get("tvg_id") if sender else None
        tage = int((sender or {}).get("archiv_tage") or 0)
        zurueck = tage * 86400 if archiv and tage else 0
        return {"sendungen": livetv.programm_liste(
            self.app.datenordner, tvg_id, anzahl=40 if zurueck else 3, zurueck=zurueck) if tvg_id else []}

    def raster_lesen(self, ids, von, bis):
        """Programmuebersicht: {"von","bis","kanaele": [{"id","sendungen": [{"titel","beginn","ende"}]}]} fuer bis zu
        MAX_KANAELE Sender-Ids (Komma-getrennt) im Zeitfenster. Nur Sender mit tvg-id, die die EPG kennt."""
        wunsch = [i for i in str(ids or "").split(",") if i][:livetv.MAX_KANAELE]
        zuordnung = {s["id"]: s["tvg_id"] for s in self._alle_sender() if s.get("tvg_id") and s["id"] in wunsch}
        try:
            von, bis = livetv.fenster_pruefen(von, bis)
        except ValueError as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        treffer = livetv.raster(self.app.datenordner, set(zuordnung.values()), von, bis)
        kanaele = [{"id": i, "sendungen": treffer[zuordnung[i]]} for i in wunsch if i in zuordnung and zuordnung[i] in treffer]
        return 200, "application/json", {"von": von, "bis": bis, "kanaele": kanaele}

    def archiv_lesen(self, sender_id, beginn, ende):
        """Mitschnitt-Adresse einer beendeten Sendung, oder {url: null}. Baut sie nur aus den Attributen
        der eigenen Liste (siehe iptv_archiv.py)."""
        eintrag = self._listen_eintrag(sender_id)
        if not eintrag:
            return {"url": None}
        url = iptv_archiv.mitschnitt_url(eintrag.get("attribute"), eintrag.get("url"), beginn, ende)
        return {"url": url}

    def livetv_sehen_lesen(self):
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        profil_id = self._sehen_profil()
        return 200, "application/json", dict(livetv_sehen.lesen(daten, profil_id), haeufig=livetv_sehen.haeufig(daten, profil_id))

    def livetv_sehen_post(self, koerper):
        if not self.app.verwaltung:
            return 503, "application/json", {"fehler": "Nutzerdaten nicht verfügbar"}
        profil_id = self._sehen_profil()
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
            aktion = wunsch.get("aktion") if isinstance(wunsch, dict) else None
            if aktion == "favorit":
                e = self.app.verwaltung.bearbeiten(
                    lambda d: livetv_sehen.favorit_setzen(d, profil_id, wunsch.get("id"), bool(wunsch.get("an"))))
            elif aktion == "angesehen":
                e = self.app.verwaltung.bearbeiten(
                    lambda d: livetv_sehen.angesehen_setzen(d, profil_id, wunsch.get("id")))
            else:
                return 400, "application/json", {"fehler": "Unbekannte Aktion"}
            return 200, "application/json", dict(e, haeufig=livetv_sehen.haeufig(self.app.verwaltung.daten(), profil_id))
        except (ValueError, UnicodeDecodeError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}

    def livetv_lesen(self):
        listen = []
        for eintrag in self.app.livetv["listen"]:
            lid = livetv.liste_id(eintrag["name"])
            liste = self.app.listen.get(lid)
            zustand = liste.zustand() if liste else {"vorhanden": False, "stand": "", "fehler": "", "anzahl": 0}
            listen.append(dict(eintrag, id=lid, **{k: zustand[k] for k in ("vorhanden", "stand", "fehler", "anzahl")}))
        frei = []
        for eintrag in frei_tv.auswahl():
            liste = self.app.listen.get("frei-" + eintrag["id"])
            z = liste.zustand() if liste else {"stand": "", "fehler": "", "anzahl": 0}
            frei.append(dict(eintrag, an=liste is not None, **{k: z[k] for k in ("stand", "fehler", "anzahl")}))
        return {"einstellung": self.app.livetv, "frei": frei,
                "sender": livetv.sender(self.app.livetv, self.app.adressen.adressen()), "alle": self._alle_sender(),
                "epg": self.app.epg.zustand(), "adressen_liste": self.app.adressen.zustand(), "listen": listen,
                "grabber": [{"id": k, "name": n} for k, n in livetv.GRABBER.items()]}

    def livetv_speichern(self, koerper):
        try:
            neu = json.loads(koerper.decode("utf-8") or "{}")
            if isinstance(neu, dict):
                # aeltere Seiten kennen die Sender-Adressen nicht: dann bleiben sie, wie sie sind
                for schluessel in ("adressen", "adressen_quelle", "epg_grabber", "frei"):
                    neu.setdefault(schluessel, self.app.livetv[schluessel])
            self.app.setze_livetv(neu)
        except (ValueError, UnicodeDecodeError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        log.info("Live-TV-Einstellungen gespeichert")
        return 200, "application/json", self.livetv_lesen()

    def xtream_url(self, koerper):
        """Baut aus {server, benutzer, passwort} die M3U-Adresse; speichert nichts."""
        try:
            daten = json.loads(koerper.decode("utf-8") or "{}")
            url = livetv.xtream_m3u_url(daten.get("server"), daten.get("benutzer"), daten.get("passwort"))
        except (ValueError, UnicodeDecodeError, livetv.LiveTvFehler) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
        return 200, "application/json", {"url": url}
