"""Sammlungen (Collections) nach ARVIO 2.2: importieren, verwalten und als Ordner abrufen.

  * Eingebaute Reihen (Entdecken, Genres, Streaming, Themen, Franchises, Jahrzehnte) in
    sammlungen_standards.py – eigene Abfragen, keine fremde Sammlung uebernommen.
  * Import per JSON oder Adresse im Nuvio-/ARVIO-Format {name, collections:[{id,title,folders:[...]}]}.
    Ein Pack wird als Ganzes ersetzt (gleiche Adresse = gleiches Pack) oder entfernt.
  * Ordner-Quellen: TMDb (Discover, Collection, Liste, Person/Regie), Trakt-Liste, MDBList-Liste,
    Katalog eines Stremio-Addons sowie die eingebauten Cinemeta-/Streaming-/Themen-Quellen.

Nutzerdaten "sammlungen": {"standard": true, "aus": ["standard/genres", ...],
                           "packs": [{"id", "name", "url", "importiert", "rails": [...]}]}
"""

import time
from urllib.parse import urlsplit

from . import tmdb
from .kataloge_grund import THEMEN, KatalogFehler
from .netz import NetzFehler
from .sammlungen_grund import (SCHLUESSEL, STANDARD, MAX_PACKS, SammlungenFehler, _s, braucht, braucht_reihe,
                               einstellung, ordner_key, pack_lesen, rail_key, zugang)
from .sammlungen_standards import standard_rails


class Sammlungen:
    def __init__(self, abrufer, kataloge, entdecken, tmdb_klient, uhr=time.time):
        self.abrufer = abrufer
        self.kataloge = kataloge
        self.entdecken = entdecken
        self.tmdb = tmdb_klient
        self.uhr = uhr

    # --- Import und Verwaltung -------------------------------------------------------------------
    def pack_bauen(self, wunsch):
        if not isinstance(wunsch, dict):
            raise SammlungenFehler("JSON-Objekt erwartet")
        url = _s(wunsch.get("url"), 500)
        if url:
            teile = urlsplit(url)
            if teile.scheme not in ("http", "https") or not teile.hostname:
                raise SammlungenFehler("Adresse muss mit http(s):// beginnen")
            try:
                text = self.abrufer.abruf(url)
            except NetzFehler as fehler:
                raise SammlungenFehler("Sammlung nicht erreichbar: %s" % fehler)
        else:
            text = wunsch.get("json")
            if not isinstance(text, str) or not text.strip():
                raise SammlungenFehler("JSON oder Adresse angeben")
        return pack_lesen(text, url, self.uhr(), _s(wunsch.get("name"), 80))

    def speichern(self, daten, pack):
        e = einstellung(daten)
        packs = [p for p in e["packs"] if p.get("id") != pack["id"]]
        if len(packs) >= MAX_PACKS:
            raise SammlungenFehler("Hoechstens %d importierte Sammlungen" % MAX_PACKS)
        e["packs"] = packs + [pack]
        self._schreiben(daten, e)
        return {"pack": self._pack_kurz(pack)}

    def entfernen(self, daten, pack_id):
        e = einstellung(daten)
        e["packs"] = [p for p in e["packs"] if p.get("id") != pack_id]
        self._schreiben(daten, e)
        return {"entfernt": str(pack_id)}

    def standard(self, daten, an):
        e = einstellung(daten)
        e["standard"] = an is not False
        self._schreiben(daten, e)
        return {"standard": e["standard"]}

    def sichtbar(self, daten, key, an):
        e = einstellung(daten)
        key = _s(key, 200)
        if not key:
            raise SammlungenFehler("Sammlung fehlt")
        e["aus"] = [x for x in e["aus"] if x != key]
        if an is False:
            e["aus"].append(key)
        self._schreiben(daten, e)
        return {"aus": e["aus"]}

    @staticmethod
    def _schreiben(daten, e):
        daten[SCHLUESSEL] = {"standard": e["standard"], "aus": e["aus"], "packs": e["packs"]}

    @staticmethod
    def _pack_kurz(pack):
        return {"id": pack["id"], "name": pack["name"], "url": pack.get("url", ""),
                "importiert": pack.get("importiert", 0), "sammlungen": len(pack.get("rails") or []),
                "ordner": sum(len(r.get("ordner") or []) for r in pack.get("rails") or [])}

    # --- Uebersicht ------------------------------------------------------------------------------
    def uebersicht(self, daten=None):
        e = einstellung(daten)
        reihen = []
        if e["standard"]:
            reihen.extend(dict(r, pack=STANDARD) for r in standard_rails())
        for pack in e["packs"]:
            for rail in pack.get("rails") or []:
                reihen.append(dict(rail, pack=pack["id"], pack_name=pack.get("name") or ""))
        aus = set(e["aus"])
        ergebnis = []
        for rail in reihen:
            if rail_key(rail) in aus:
                continue
            ordner = []
            for o in rail.get("ordner") or []:
                ordner.append({"key": ordner_key(rail, o), "id": o.get("id"), "titel": o.get("titel"),
                               "beschreibung": o.get("beschreibung", ""), "bild": o.get("bild", ""),
                               "hero": o.get("hero", ""), "logo": o.get("logo", ""), "form": o.get("form", "quer"),
                               "anzahl": len(o.get("quellen") or []), "braucht": braucht(o)})
            if not ordner:
                continue
            ergebnis.append({"key": rail_key(rail), "titel": rail.get("titel") or rail.get("id"),
                             "beschreibung": rail.get("beschreibung", ""), "bild": rail.get("bild", ""),
                             "pack": rail.get("pack") or STANDARD, "pack_name": rail.get("pack_name", ""),
                             "braucht": ([rail["braucht"]] if rail.get("braucht") else braucht_reihe(rail)),
                             "ordner": ordner})
        return {"rails": ergebnis, "standard": e["standard"], "aus": sorted(aus),
                "packs": [self._pack_kurz(p) for p in e["packs"]], "zugang": zugang(daten)}

    # --- Ordner abrufen --------------------------------------------------------------------------
    def ordner(self, key, typ="", skip=0, daten=None):
        teile = str(key or "").split("/")
        if len(teile) != 3:
            raise SammlungenFehler("Ordner-Schluessel: sammlung/reihe/ordner")
        rail = self._rail(teile[0], teile[1], daten)
        o = next((x for x in rail.get("ordner") or [] if x.get("id") == teile[2]), None)
        if not o:
            raise SammlungenFehler("Ordner nicht gefunden")
        typ = typ if typ in ("movie", "series") else ""
        try:
            skip = max(0, min(10000, int(skip or 0)))
        except (TypeError, ValueError):
            skip = 0
        quellen = [q for q in o.get("quellen") or [] if not typ or not q.get("typ") or q["typ"] == typ]
        if not quellen:
            raise SammlungenFehler("Fuer diesen Typ gibt es in diesem Ordner keine Quelle")
        titel, gesehen, fehler, mehr, weiter = [], set(), [], False, skip
        for q in quellen:
            try:
                karten, q_mehr, q_weiter = self._laden(q, typ or q.get("typ") or "", skip, daten)
            except (SammlungenFehler, KatalogFehler, tmdb.TmdbFehler, NetzFehler, ValueError) as problem:
                fehler.append(str(problem))
                continue
            for karte in karten:
                kennung = (karte.get("typ"), karte.get("id"))
                if karte.get("id") and kennung not in gesehen:
                    gesehen.add(kennung)
                    titel.append(karte)
            mehr = mehr or bool(q_mehr)
            weiter = max(weiter, int(q_weiter or skip))
        if not titel and fehler and len(fehler) == len(quellen):
            raise SammlungenFehler(fehler[0])
        return {"name": o["titel"], "titel": titel[:100], "mehr": mehr, "weiter": weiter, "fehler": fehler}

    def _rail(self, owner, rail_id, daten):
        if owner == STANDARD:
            reihen = standard_rails()
        else:
            e = einstellung(daten)
            pack = next((p for p in e["packs"] if p.get("id") == owner), None)
            reihen = pack.get("rails") if pack else []
        gefunden = next((r for r in reihen or [] if r.get("id") == rail_id), None)
        if not gefunden:
            raise SammlungenFehler("Sammlung nicht gefunden")
        return gefunden

    def _laden(self, q, typ, skip, daten):
        art = q.get("art")
        if art == "entdecken":
            if not self.entdecken:
                raise SammlungenFehler("Entdecken ist nicht eingerichtet")
            d = self.entdecken.katalog(typ or q.get("typ") or "movie", q.get("sortierung") or "top",
                                       q.get("genre") or "", q.get("jahr") or "", skip, q.get("bewertung") or "")
            return d.get("titel") or [], d.get("mehr"), d.get("weiter", skip + 20)
        if art == "thema":
            if q.get("id") not in THEMEN:
                raise SammlungenFehler("Unbekanntes Thema")
            _, thema_typ, _ = THEMEN[q["id"]]
            if typ and typ != thema_typ:
                return [], False, skip
            d = self.kataloge.thema(q["id"], skip)
            return d.get("titel") or [], d.get("mehr"), d.get("weiter", skip + 20)
        if art == "streaming":
            d = self.kataloge.streaming(q["id"], typ or q.get("typ") or "movie")
            return d.get("titel") or [], False, skip
        if art == "tmdb":
            return self._tmdb_laden(q, typ, skip, daten)
        if art == "trakt":
            if not self.kataloge:
                raise SammlungenFehler("Kataloge sind nicht eingerichtet")
            karten = self.kataloge.trakt_liste(q["id"], skip // 100 + 1, daten)
            return [k for k in karten if not typ or k.get("typ") == typ], len(karten) >= 100, skip + 100
        if art == "mdblist":
            if not self.kataloge:
                raise SammlungenFehler("Kataloge sind nicht eingerichtet")
            karten = self.kataloge.mdblist_liste(q["slug"], skip // 200 + 1, daten)
            return [k for k in karten if not typ or k.get("typ") == typ], len(karten) >= 200, skip + 200
        if art == "addon":
            addon = q.get("addon") or self._addon_fuer(q.get("katalog"), typ or q.get("typ"))
            if not addon:
                raise SammlungenFehler("Kein passendes Addon fuer diesen Katalog eingetragen")
            d = self.kataloge.addon(addon, typ or q.get("typ") or "movie", q.get("katalog"), q.get("genre") or "", skip)
            return d.get("titel") or [], d.get("mehr"), d.get("weiter", skip + 20)
        raise SammlungenFehler("Unbekannte Quelle")

    def _tmdb_laden(self, q, typ, skip, daten):
        schluessel = tmdb.schluessel(daten)
        if not schluessel:
            raise SammlungenFehler("Fuer diese Sammlung erst den TMDb-Schluessel eintragen "
                                   "(Einstellungen → Trakt, MDBList & Google Drive)")
        if not self.tmdb:
            raise SammlungenFehler("TMDb ist auf diesem Server nicht eingerichtet")
        typ = typ or q.get("typ") or "movie"
        art = q.get("quelle")
        if art == "discover":
            parameter = dict(q.get("params") or {})
            parameter["page"] = skip // 20 + 1
            karten, seiten = self.tmdb.discover_seite(typ, schluessel, **parameter)
            return karten, parameter["page"] < seiten, skip + 20
        if art == "collection":
            if typ != "movie":
                return [], False, skip
            return self.tmdb.collection(q["id"], schluessel), False, skip
        if art == "list":
            karten = self.tmdb.liste(q["id"], schluessel)
            return [k for k in karten if k.get("typ") == typ], len(karten) >= 20, skip + 20
        if art == "person":
            karten = self.tmdb.person_werke(q["id"], q.get("rolle") or "cast", typ, schluessel)
            return karten, len(karten) >= 20, skip + 20
        raise SammlungenFehler("Unbekannte TMDb-Quelle")

    def _addon_fuer(self, katalog, typ):
        try:
            liste = self.kataloge.addon_liste()
        except Exception:  # noqa: BLE001 - ein defektes Addon darf die Sammlung nicht unsichtbar machen
            return ""
        for eintrag in liste:
            if eintrag.get("katalog") == katalog and (not typ or eintrag.get("typ") == typ):
                return eintrag.get("addon", "")
        return ""
