"""TMDb (The Movie Database): zusaetzliche Entdeckungs-/Detaildaten, die Cinemeta (entdecken.py) nicht
liefert - Budget, Altersfreigabe (FSK), Streaming-Anbieter, echte Top-10-Tagesrangliste, Franchise-
Sammlungen. Rein optional: ohne eigenen, kostenlosen API-Schluessel (themoviedb.org/settings/api) bleiben
die darauf aufbauenden Reihen/Detailfelder einfach aus, kein Fehler fuer den Rest der Seite. Derselbe
einfache "API Key (v3 auth)"-Schluesseltyp, den H0rSt schon fuer die ARVIO-Selbsthosting-Installation
abfragt (arvio_web.py) - ein Nutzer mit ARVIO-Schluessel kann ihn hier wiederverwenden.

TMDb liefert nur Entdeckungsdaten; Abspielen/Details laufen weiter ueber Cinemeta. Jede TMDb-Karte wird
deshalb ueber external_ids auf eine IMDb-Id gebracht und in derselben Form wie entdecken.karte()
ausgegeben (gleiche Felder id/typ/titel/jahr/bewertung/poster/hintergrund/logo/genres/beschreibung/
laufzeit) - Klick/Abspielen laeuft dadurch unveraendert ueber den bestehenden, schon funktionierenden
Cinemeta-Weg. Ohne IMDb-Zuordnung wird eine TMDb-Karte uebersprungen, nie mit einer erfundenen Id gezeigt.
"""

import json
import re
import time
from concurrent.futures import ThreadPoolExecutor
from urllib.parse import urlencode

from . import streaming_dienste
from .netz import NetzFehler

TMDB = "https://api.themoviedb.org/3"
BILD = "https://image.tmdb.org/t/p/"
ZWISCHENSPEICHER = 1800
MAX_SPEICHER = 300
TYP_TMDB = {"movie": "movie", "series": "tv"}
SCHLUESSEL = "tmdb"
# Bekannte Franchise-Namen als Sucheinstieg fuer collection_suche() - echte TMDb-Collection-Daten je
# Treffer, keine erfundene Liste von Titeln.
FRANCHISES = ["Star Wars", "Herr der Ringe", "Marvel Cinematic Universe", "Harry Potter", "Fast & Furious",
              "James Bond", "Jurassic Park", "Mission: Impossible", "John Wick", "Avatar"]

# Hauptadressen legaler Streaming-Dienste in Deutschland (oeffentliche Startseiten der Anbieter; auf Android oeffnet das
# Betriebssystem damit die installierte App, sonst die Webseite). Kein Zugriff auf Daten der Dienste, keine geratenen Tiefenlinks.
ANBIETER_SEITEN = {
    "netflix": "https://www.netflix.com/de/", "joyn": "https://www.joyn.de/", "amazon prime video": "https://www.primevideo.com/",
    "disney plus": "https://www.disneyplus.com/de-de", "sky go": "https://www.skygo.sky.de/", "sky ticket": "https://www.sky.de/",
    "sky": "https://www.sky.de/", "wow": "https://www.wowtv.de/", "rtl+": "https://plus.rtl.de/", "rtl plus": "https://plus.rtl.de/",
    "apple tv+": "https://tv.apple.com/de", "apple tv plus": "https://tv.apple.com/de", "apple tv": "https://tv.apple.com/de",
    "paramount plus": "https://www.paramountplus.com/de/", "paramount+": "https://www.paramountplus.com/de/",
    "magentatv": "https://www.magentatv.de/", "magenta tv": "https://www.magentatv.de/",
    "ard mediathek": "https://www.ardmediathek.de/", "ardmediathek": "https://www.ardmediathek.de/",
    "zdf": "https://www.zdf.de/", "zdfmediathek": "https://www.zdf.de/", "zdf mediathek": "https://www.zdf.de/",
    "arte": "https://www.arte.tv/de/", "mubi": "https://mubi.com/", "crunchyroll": "https://www.crunchyroll.com/",
    "pluto tv": "https://pluto.tv/de", "rakuten tv": "https://rakuten.tv/de", "youtube": "https://www.youtube.com/movies",
    "wow tv": "https://www.wowtv.de/", "sky x": "https://www.sky.de/", "dazn": "https://www.dazn.com/de-DE",
    "waipu.tv": "https://www.waipu.tv/", "waipu tv": "https://www.waipu.tv/", "waipu": "https://www.waipu.tv/"}
_ANBIETER_ZUSATZ = re.compile(r"(?i)\s+(?:basic\s+)?with\s+ads$|\s+amazon\s+channel$|\s+standard\s+with\s+ads$")


def anbieter_seite(name):
    """Startseite eines TMDb-Anbieters (Name egal in welcher Schreibweise, auch "Netflix basic with Ads"), sonst ""."""
    schluessel = _ANBIETER_ZUSATZ.sub("", " ".join(str(name or "").split())).lower()
    return ANBIETER_SEITEN.get(schluessel, "") or streaming_dienste.seite(schluessel)


def anbieter_suche(name):
    """Oeffentliche Suchadresse eines Anbieters mit {titel}-Platzhalter, sonst "" (keine geratenen Links)."""
    schluessel = _ANBIETER_ZUSATZ.sub("", " ".join(str(name or "").split())).lower()
    return streaming_dienste.suche(schluessel)


class TmdbFehler(Exception):
    pass


def konfiguriert(daten):
    return bool(schluessel(daten))


def schluessel(daten):
    return str(((daten or {}).get(SCHLUESSEL) or {}).get("api_key") or "")


def einstellen(daten, wunsch):
    """{"api_key": text} - leer entfernt den Schluessel wieder (Reihen/Detailfelder blenden sich dann aus)."""
    neu = str((wunsch or {}).get("api_key") or "").strip()
    daten[SCHLUESSEL] = {"api_key": neu}
    return {"konfiguriert": bool(neu)}


def _karte(roh, tmdb_art, imdb_id):
    datum = str(roh.get("release_date") or roh.get("first_air_date") or "")
    bewertung = roh.get("vote_average")
    return {
        "id": imdb_id, "typ": "series" if tmdb_art == "tv" else "movie",
        "titel": str(roh.get("title") or roh.get("name") or ""), "jahr": datum[:4], "datum": datum,
        "bewertung": ("%.1f" % bewertung) if bewertung else "",
        "poster": (BILD + "w500" + roh["poster_path"]) if roh.get("poster_path") else "",
        "hintergrund": (BILD + "w1280" + roh["backdrop_path"]) if roh.get("backdrop_path") else "",
        "logo": "", "genres": [], "beschreibung": str(roh.get("overview") or "")[:400], "laufzeit": "",
    }


class Tmdb:
    """Zugriff auf die TMDb-API v3. 30 Minuten Zwischenspeicher je Pfad+Parameter (Muster entdecken.py)."""

    def __init__(self, abrufer, uhr=time.time):
        self.abrufer = abrufer
        self.uhr = uhr
        self._speicher = {}
        self._pool = ThreadPoolExecutor(max_workers=4, thread_name_prefix="tmdb")

    def _holen(self, pfad, api_key, **params):
        if not api_key:
            raise TmdbFehler("Kein TMDb-Schlüssel eingetragen")
        cache_key = (pfad, tuple(sorted(params.items())))
        alt = self._speicher.get(cache_key)
        if alt and self.uhr() - alt[0] < ZWISCHENSPEICHER:
            return alt[1]
        url = TMDB + pfad + "?" + urlencode(dict(params, api_key=api_key, language="de-DE"))
        try:
            text = self.abrufer.abruf(url)
        except NetzFehler as fehler:  # Abrufer.abruf() wirft bei HTTP >= 400 (z. B. falscher Schluessel, 404)
            raise TmdbFehler(str(fehler))
        try:
            daten = json.loads(text)
        except ValueError:
            raise TmdbFehler("TMDb liefert kein JSON")
        if isinstance(daten, dict) and daten.get("success") is False:
            raise TmdbFehler(str(daten.get("status_message") or "TMDb-Fehler"))
        if len(self._speicher) >= MAX_SPEICHER:
            self._speicher.clear()
        self._speicher[cache_key] = (self.uhr(), daten)
        return daten

    def _external_id(self, tmdb_art, tmdb_id, api_key):
        try:
            d = self._holen("/%s/%s/external_ids" % (tmdb_art, tmdb_id), api_key)
        except TmdbFehler:
            return ""
        return str(d.get("imdb_id") or "")

    def _karten_mit_imdb(self, roh_liste, typ, api_key):
        tmdb_art = TYP_TMDB.get(typ, "movie")
        roh_liste = [e for e in roh_liste if isinstance(e, dict) and e.get("id")][:20]
        imdb_ids = list(self._pool.map(lambda e: self._external_id(tmdb_art, e["id"], api_key), roh_liste))
        return [_karte(roh, tmdb_art, imdb_id) for roh, imdb_id in zip(roh_liste, imdb_ids) if imdb_id]

    def discover(self, typ, api_key, **extra):
        """Entdecken-Abfrage - z. B. Jahrzehnt per primary_release_date.gte/lte, Dienst per
        with_watch_providers=&watch_region=DE (siehe TMDb-Doku /discover/movie|tv)."""
        tmdb_art = TYP_TMDB.get(typ, "movie")
        daten = self._holen("/discover/%s" % tmdb_art, api_key, **extra)
        return self._karten_mit_imdb(daten.get("results") or [], typ, api_key)

    def trending(self, typ, api_key, fenster="day"):
        """Echte TMDb-Tagesrangliste (/trending/movie|tv/day) - Reihenfolge der Antwort ist der Rang."""
        tmdb_art = TYP_TMDB.get(typ, "movie")
        daten = self._holen("/trending/%s/%s" % (tmdb_art, fenster), api_key)
        return self._karten_mit_imdb(daten.get("results") or [], typ, api_key)

    def collection_suche(self, name, api_key):
        """Erster Treffer zu einem Franchise-Namen (z. B. 'Star Wars') oder None."""
        daten = self._holen("/search/collection", api_key, query=name)
        treffer = daten.get("results") or []
        return treffer[0] if treffer and isinstance(treffer[0], dict) else None

    def collection(self, collection_id, api_key):
        daten = self._holen("/collection/%s" % collection_id, api_key)
        return self._karten_mit_imdb(daten.get("parts") or [], "movie", api_key)

    def find_by_imdb(self, imdb_id, typ, api_key):
        """Umkehrung von _external_id(): IMDb-Id (tt...) -> TMDb-Id als String, oder "" ohne Treffer/
        Schluessel/Fehler (nie werfen - genau wie _external_id() reicht ein leeres Ergebnis, die
        aufrufende Stelle blendet die darauf aufbauende Funktion dann einfach aus). Nutzt TMDbs "Find by
        ID"-Endpunkt (/find/{external_id}?external_source=imdb_id, verifiziert gegen die offizielle
        TMDb-API-Doku: liefert movie_results/tv_results-Arrays mit je einem "id"-Feld)."""
        imdb_id = str(imdb_id or "")
        if not imdb_id:
            return ""
        try:
            daten = self._holen("/find/%s" % imdb_id, api_key, external_source="imdb_id")
        except TmdbFehler:
            return ""
        feld = "tv_results" if typ == "series" else "movie_results"
        treffer = daten.get(feld) or []
        if treffer and isinstance(treffer[0], dict) and treffer[0].get("id"):
            return str(treffer[0]["id"])
        return ""

    def discover_seite(self, typ, api_key, **extra):
        """Wie discover(), dazu die Gesamtzahl der TMDb-Seiten (fuer "Mehr laden" in Sammlungen)."""
        tmdb_art = TYP_TMDB.get(typ, "movie")
        daten = self._holen("/discover/%s" % tmdb_art, api_key, **extra)
        return (self._karten_mit_imdb(daten.get("results") or [], typ, api_key),
                int(daten.get("total_pages") or 1))

    def liste(self, liste_id, api_key):
        """Oeffentliche TMDb-Liste (/list/{id}) -> Karten in der Reihenfolge der Liste."""
        daten = self._holen("/list/%s" % int(liste_id), api_key)
        ergebnis = []
        for e in daten.get("items") or []:
            if not isinstance(e, dict) or not e.get("id"):
                continue
            art = "tv" if e.get("media_type") == "tv" else "movie"
            imdb = self._external_id(art, e["id"], api_key)
            if imdb:
                ergebnis.append(_karte(e, art, imdb))
        return ergebnis[:100]

    def person_werke(self, person_id, rolle, typ, api_key, hoechstens=20):
        """Filme/Serien einer Person (Besetzung oder Regie) aus den kombinierten Credits."""
        daten = self._holen("/person/%s/combined_credits" % int(person_id), api_key)
        roh = [e for e in daten.get("crew" if rolle == "director" else "cast") or []
               if isinstance(e, dict) and e.get("id")]
        if rolle == "director":
            roh = [e for e in roh if str(e.get("job") or "") == "Director"]
        if typ:
            gewuenscht = "tv" if typ == "series" else "movie"
            roh = [e for e in roh if (e.get("media_type") or "movie") == gewuenscht]
        roh.sort(key=lambda e: float(e.get("popularity") or 0), reverse=True)
        paare = [(e, "tv" if e.get("media_type") == "tv" else "movie") for e in roh[:hoechstens]]
        imdb_ids = list(self._pool.map(lambda p: self._external_id(p[1], p[0]["id"], api_key), paare))
        return [_karte(e, art, imdb) for (e, art), imdb in zip(paare, imdb_ids) if imdb]

    def zertifizierungen(self, typ, imdb_id, api_key):
        """Altersfreigaben je Land {"DE": "12", "US": "PG-13"} zu einer IMDb-Kennung (ARVIO 2.3: Kinderprofile).
        Leer = TMDb kennt den Titel oder eine Angabe nicht. Netz- und Schluesselfehler werfen TmdbFehler, damit
        der Aufrufer nichts als "unbekannt" festhaelt."""
        gefunden = self._holen("/find/%s" % imdb_id, api_key, external_source="imdb_id")
        art = "movie" if typ == "movie" else "tv"
        treffer = gefunden.get(art + "_results") or gefunden.get("movie_results" if art == "tv" else "tv_results") or []
        if treffer and not gefunden.get(art + "_results"):
            art = "tv" if art == "movie" else "movie"
        if not treffer or not isinstance(treffer[0], dict) or not treffer[0].get("id"):
            return {}
        tmdb_id = treffer[0]["id"]
        ergebnis = {}
        if art == "movie":
            for land in self._holen("/movie/%s/release_dates" % tmdb_id, api_key).get("results") or []:
                for e in land.get("release_dates") or []:
                    if e.get("certification") and land.get("iso_3166_1") not in ergebnis:
                        ergebnis[str(land.get("iso_3166_1"))] = str(e["certification"])
        else:
            for land in self._holen("/tv/%s/content_ratings" % tmdb_id, api_key).get("results") or []:
                if land.get("rating") and land.get("iso_3166_1"):
                    ergebnis[str(land["iso_3166_1"])] = str(land["rating"])
        return ergebnis

    def trailer(self, typ, imdb_id, api_key):
        """YouTube-Kennung des besten Trailers (offiziell, Deutsch vor Englisch, Trailer vor Teaser) oder ''.
        Netz- und Schluesselfehler werfen TmdbFehler."""
        gefunden = self._holen("/find/%s" % imdb_id, api_key, external_source="imdb_id")
        art = "movie" if typ == "movie" else "tv"
        treffer = gefunden.get(art + "_results") or []
        if not treffer:
            art = "tv" if art == "movie" else "movie"
            treffer = gefunden.get(art + "_results") or []
        if not treffer or not isinstance(treffer[0], dict) or not treffer[0].get("id"):
            return ""
        videos = self._holen("/%s/%s/videos" % (art, treffer[0]["id"]), api_key, include_video_language="de,en,null").get("results") or []

        def wert(v):
            return (0 if v.get("type") == "Trailer" else 1, 0 if v.get("official") else 1,
                    {"de": 0, "en": 1}.get(v.get("iso_639_1"), 2), str(v.get("published_at") or ""))
        gut = [v for v in videos if isinstance(v, dict) and v.get("site") == "YouTube" and v.get("type") in ("Trailer", "Teaser")
               and re.fullmatch(r"[\w-]{11}", str(v.get("key") or ""))]
        return min(gut, key=wert)["key"] if gut else ""

    def film_zusatz(self, tmdb_id, typ, api_key):
        """Budget, Altersfreigabe (DE) und Streaming-Anbieter (DE) zu einem bereits bekannten TMDb-Titel.
        Fehlschlagende Teilabfragen (z. B. keine DE-Zertifizierung hinterlegt) werfen nicht, liefern nur
        ein leeres Feld - die Detailseite funktioniert unveraendert auch ohne diese Zusatzdaten."""
        tmdb_art = TYP_TMDB.get(typ, "movie")
        basis = self._holen("/%s/%s" % (tmdb_art, tmdb_id), api_key)
        ergebnis = {"budget": int(basis.get("budget") or 0) if tmdb_art == "movie" else 0, "fsk": "", "anbieter": [],
                    "gratis": [], "anbieter_links": [], "tmdb_link": ""}
        try:
            if tmdb_art == "movie":
                zertifikate = self._holen("/movie/%s/release_dates" % tmdb_id, api_key)
                for land in zertifikate.get("results") or []:
                    if land.get("iso_3166_1") == "DE":
                        for eintrag in land.get("release_dates") or []:
                            if eintrag.get("certification"):
                                ergebnis["fsk"] = str(eintrag["certification"])
                                break
            else:
                zertifikate = self._holen("/tv/%s/content_ratings" % tmdb_id, api_key)
                for land in zertifikate.get("results") or []:
                    if land.get("iso_3166_1") == "DE" and land.get("rating"):
                        ergebnis["fsk"] = str(land["rating"])
        except TmdbFehler:
            pass
        try:
            anbieter = self._holen("/%s/%s/watch/providers" % (tmdb_art, tmdb_id), api_key)
            de = (anbieter.get("results") or {}).get("DE") or {}
            def namen_von(art):
                return sorted({a.get("provider_name") for a in (de.get(art) or [])
                               if isinstance(a, dict) and a.get("provider_name")})
            ergebnis["anbieter"] = namen_von("flatrate")
            ergebnis["gratis"] = [n for n in sorted(set(namen_von("free")) | set(namen_von("ads"))) if n not in ergebnis["anbieter"]]
            ergebnis["anbieter_links"] = [{"name": n, "url": anbieter_seite(n), "suche": anbieter_suche(n)}
                                          for n in ergebnis["anbieter"] + ergebnis["gratis"] if anbieter_seite(n)]
            link = str(de.get("link") or "")
            if link.startswith("https://www.themoviedb.org/"):  # TMDb-Seite "Wo ansehen" (Daten von JustWatch)
                ergebnis["tmdb_link"] = link
        except TmdbFehler:
            pass
        return ergebnis
