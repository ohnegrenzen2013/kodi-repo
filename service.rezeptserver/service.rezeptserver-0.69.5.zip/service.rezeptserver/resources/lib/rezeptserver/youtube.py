"""YouTube ohne Werbung: Suche, Kanal-Abos, Abspielen und SponsorBlock.

  * Suche ueber yt-dlp ("ytsearch"), ohne Konto. Fehlt yt-dlp, geht nur der Abo-Feed.
  * Abos: die oeffentlichen RSS-Feeds der Kanaele (youtube.com/feeds/videos.xml?channel_id=...), kein Konto,
    kein Google-Tracking ueber eine Anmeldung. Kanal per Adresse, @Name oder UC-Kennung hinzufuegen.
  * Abspielen: yt-dlp liefert die HLS-Gesamtliste von YouTube (alle Aufloesungen, Ton als eigene Gruppe,
    etwa 6 Stunden gueltig). Sie braucht keinen JavaScript-Loeser und laeuft in ExoPlayer, Kodi, VLC und
    im Browser (hls.js ueber H0rSt). Werbung gibt es so nicht, sie steckt nur im YouTube-Player.
  * SponsorBlock (sponsor.ajay.app): gemeldete Sponsor-, Eigenwerbungs- und Abo-Aufrufe werden uebersprungen.
  * Download (Originaltempo) und REC (mit eingestelltem Tempo, 0,25x bis 4x) als zwei getrennte Funktionen.
    Server/PC/Pi: yt-dlp und ffmpeg (YouTube liefert Bild und Ton getrennt, ffmpeg fuehrt sie zusammen); REC per
    setpts/atempo (Tonhoehe bleibt). Ohne ffmpeg geht auf dem Server weder Download noch REC.
    In der App erledigt das Media3 Transformer (PlayerActivity-Nachbar YoutubeSpeichern.java).
Einstellungen in den Nutzerdaten unter "youtube": {"kanaele": [{"id", "name"}], "sponsorblock": true}.
"""

from .youtube_grund import *
from .youtube_grund import _KANAL, _KEKS, _KENNUNG, _NS
from .youtube_kanal import Youtube, bild, pruefe, _holen, _video, _ytdlp
from .youtube_speichern import Speichern, dateiname, ffmpeg, _atempo
