"""NNTP-Verbindungsaufbau (geteilt mit anbindungen_pruefen._nntp_pruefen()) und Artikel-Stichprobenpruefung
fuer die Usenet-Gesundheitspruefung (usenet_triage.py). Reiner Socket-Client - kein nntplib (seit Python
3.13 entfernt, PEP 594)."""

import socket
import ssl


class NntpFehler(Exception):
    pass


class NntpVerbindung:
    """Eine offene, angemeldete NNTP-Verbindung mit zeilenbasiertem Senden/Lesen."""

    def __init__(self, verbindung, roh, host, port):
        self._verbindung = verbindung
        self._roh = roh
        self._datei = verbindung.makefile("rwb")
        self.host, self.port = host, port

    def zeile(self):
        return self._datei.readline(2048).decode("utf-8", "replace").strip()

    def senden(self, text):
        self._datei.write(text.encode("utf-8") + b"\r\n")
        self._datei.flush()
        return self.zeile()

    def schliessen(self):
        try:
            self.senden("QUIT")
        except OSError:
            pass
        self._roh.close()


def _nntp_verbinden(werte, zeit=10.0):
    """Socket/SSL-Verbindungsaufbau + AUTHINFO-Anmeldung. Wirft immer NntpFehler bei jedem Problem -
    auch bei Verbindungs-/TLS-Fehlern (ssl.SSLError ist in Python eine OSError-Unterklasse, hier aber
    trotzdem mitgefangen, falls sich das je aendert) - nie das rohe OSError, damit artikel_vorhanden()s
    "wirft nie"-Zusage zuverlaessig gilt. Die Verbindung bleibt bei Erfolg offen und muss vom Aufrufer
    per .schliessen() beendet werden."""
    host = werte.get("host", "").strip()
    port = int(werte.get("port") or 563) if str(werte.get("port") or "563").isdigit() else 563
    if not host:
        raise NntpFehler("Server fehlt")
    roh = None
    try:
        roh = socket.create_connection((host, port), timeout=zeit)
        verbindung = ssl.create_default_context().wrap_socket(roh, server_hostname=host) \
            if werte.get("ssl", "1") == "1" else roh
        nntp = NntpVerbindung(verbindung, roh, host, port)
        gruss = nntp.zeile()
        nntp.gruss = gruss
        if not gruss.startswith(("200", "201")):
            raise NntpFehler("Server meldet: " + gruss)
        antwort = nntp.senden("AUTHINFO USER " + werte.get("user", ""))
        if antwort.startswith("381"):
            antwort = nntp.senden("AUTHINFO PASS " + werte.get("pass", ""))
        if not antwort.startswith("281"):
            raise NntpFehler("Anmeldung abgelehnt: " + antwort)
        return nntp
    except NntpFehler:
        if roh is not None:
            roh.close()
        raise
    except (OSError, ssl.SSLError) as fehler:
        if roh is not None:
            roh.close()
        raise NntpFehler(str(fehler) or fehler.__class__.__name__) from fehler


_PROBE = "<h0rst-probe@invalid>"


def sitzung_pruefen(nntp):
    """Nach der Anmeldung: Lesemodus, Serverdatum, eine Artikelsuche.

    MODE READER darf 200/201 (Leser), 500 (kennt den Befehl nicht) oder 502 (schon Leser) sein.
    DATE muss 111 sein. STAT auf eine erfundene Kennung muss 223 oder 430 sein: der Server spricht
    Artikelbefehle, auch wenn die Kennung fehlt. Wirft NntpFehler, wenn das Passwort galt, die
    Sitzung aber keine Artikel liefert."""
    leser = nntp.senden("MODE READER")
    if leser.startswith("480"):
        raise NntpFehler("Lesemodus verlangt erneut Anmeldung: " + leser)
    if not leser.startswith(("200", "201", "500", "502")):
        raise NntpFehler("Lesemodus abgelehnt: " + leser)
    datum = nntp.senden("DATE")
    if not datum.startswith("111"):
        raise NntpFehler("Datum abgelehnt: " + datum)
    probe = nntp.senden("STAT " + _PROBE)
    if not probe.startswith(("223", "430")):
        raise NntpFehler("Artikelsuche abgelehnt: " + probe)
    teile = datum.split()
    return {"leser": leser[:3], "datum": teile[1] if len(teile) > 1 else "", "artikel": probe[:3]}


def artikel_vorhanden(werte, message_ids, zeit=10.0):
    """Prueft per STAT, ob Message-IDs beim konfigurierten NNTP-Server vorhanden sind. message_ids: Liste
    von reinen Strings oder (message_id, gruppe)-Tupeln (GROUP wird einmal je Newsgroup gesendet, Gruppen
    aus nzb_lesen.stichprobe()). Verbindung wird fuer alle Stichproben wiederverwendet, nicht pro Artikel
    neu aufgebaut. Wirft nie - bei Verbindungs-/Auth-Fehler werden alle angefragten IDs als None
    (unbekannt, nicht 'fehlt') zurueckgegeben, damit ein Provider-Ausfall nicht alle Kandidaten faelschlich
    als kaputt markiert."""
    eintraege = [(e, "") if isinstance(e, str) else e for e in message_ids]
    if not eintraege:
        return {}
    try:
        nntp = _nntp_verbinden(werte, zeit)
    except NntpFehler:
        return {mid: None for mid, _ in eintraege}
    ergebnis = {}
    gruppe_aktiv = None
    try:
        for message_id, gruppe in eintraege:
            try:
                if gruppe and gruppe != gruppe_aktiv:
                    nntp.senden("GROUP " + gruppe)
                    gruppe_aktiv = gruppe
                kennung = message_id if message_id.startswith("<") else "<%s>" % message_id
                antwort = nntp.senden("STAT " + kennung)
                ergebnis[message_id] = antwort.startswith("223")
            except OSError:
                ergebnis[message_id] = None
    finally:
        nntp.schliessen()
    for message_id, _ in eintraege:
        ergebnis.setdefault(message_id, None)
    return ergebnis
