"""Kuratierter Stremio-Community-Addon-Katalog.

Quelle ist der offizielle Community-Katalog von Cinemeta
(https://v3-cinemeta.strem.io/addon_catalog/all/community.json). Die Datei
community_addons.json haelt eine gepruefte Auswahl ohne Adult-Kennzeichnung;
installiert wird nur ein Eintrag aus dieser Liste, ueber den bestehenden Weg
anbieter.hinzufuegen(..., typ="stremio-addon"). Fremde Addons sind Programme mit
den Rechten von H0rSt; die Oberflaeche weist darauf hin.
"""

import base64
import json
import os
from urllib.parse import urlsplit

from . import anbieter

DATEI = os.path.join(os.path.dirname(os.path.abspath(__file__)), "community_addons.json")
_cache = None


def daten():
    global _cache
    if _cache is None:
        with open(DATEI, encoding="utf-8") as f:
            _cache = json.load(f)
    return _cache


def _adresse(url):
    try:
        teile = urlsplit(str(url or ""))
    except ValueError:
        return ""
    if teile.scheme not in ("http", "https") or not teile.hostname:
        return ""
    return str(url)


def alle():
    ergebnis = []
    for eintrag in daten().get("addons") or []:
        manifest = eintrag.get("manifest") or {}
        url = _adresse(eintrag.get("transportUrl"))
        if not url or not manifest.get("id") or not str(manifest.get("name") or "").strip():
            continue
        if (manifest.get("behaviorHints") or {}).get("adult"):
            continue
        ergebnis.append({"transportUrl": url, "manifest": manifest,
                         "empfohlen": bool(eintrag.get("empfohlen"))})
    return ergebnis


def liste(suche="", typ=""):
    text = " ".join(str(suche or "").lower().split())
    ergebnis = []
    for eintrag in alle():
        m = eintrag["manifest"]
        if typ and typ not in (m.get("types") or []):
            continue
        heu = " ".join(str(m.get(k) or "") for k in ("id", "name", "description")).lower()
        if text and text not in heu:
            continue
        ergebnis.append(eintrag)
    return ergebnis


def finde(url):
    url = _adresse(url)
    return next((e for e in alle() if e["transportUrl"] == url), None)


def installiert(daten_):
    vorhanden = {}
    werte = (daten_ or {}).get("einstellungen") or {}
    for anbieter_id, eintrag in ((daten_ or {}).get("anbieter") or {}).items():
        if eintrag.get("typ") != "stremio-addon":
            continue
        url = _adresse((werte.get(anbieter_id) or {}).get("url"))
        if url:
            vorhanden[url] = anbieter_id
    return vorhanden


def installieren(daten_, module, url):
    eintrag = finde(url)
    if not eintrag:
        raise anbieter.AnbieterFehler("Addon steht nicht im kuratierten Community-Katalog")
    if eintrag["transportUrl"] in installiert(daten_):
        raise anbieter.AnbieterFehler("Addon ist schon eingetragen")
    name = str(eintrag["manifest"].get("name") or "").strip()
    anbieter_id = anbieter.freie_id(daten_, module, name)
    anbieter.hinzufuegen(daten_, module, name, "addons", "url", {"url": eintrag["transportUrl"]},
                         typ="stremio-addon", anbieter_id=anbieter_id)
    return anbieter_id


def empfohlen():
    """Addons der Grundausstattung: Metadaten, Untertitel und Kataloge ohne eigenes Konto."""
    return [e for e in alle() if e.get("empfohlen")]


def grundausstattung(daten_, module):
    """Trägt die empfohlenen Addons ein, die noch fehlen. Liefert die neuen Anbieter-Ids."""
    vorhanden = installiert(daten_)
    neu = []
    for eintrag in empfohlen():
        if eintrag["transportUrl"] in vorhanden:
            continue
        neu.append(installieren(daten_, module, eintrag["transportUrl"]))
    return neu


def entfernen(daten_, anbieter_id):
    anbieter.entfernen(daten_, str(anbieter_id or ""))
    return True


STREAMBRIDGE_BASIS = "https://39427cdac546-streambridge.baby-beamup.club"
TRAKT_ADDON_BASIS = "https://2ecbbd610840-trakt.baby-beamup.club"


def _blob(cfg):
    roh = json.dumps(cfg, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
    return base64.urlsafe_b64encode(roh).decode("ascii").rstrip("=")


def streambridge_adresse(server, user_id, token):
    """Manifest-Adresse von StreamBridge aus Emby-Adresse, User-ID und Zugriffsschlüssel."""
    server = str(server or "").strip().rstrip("/")
    user_id, token = str(user_id or "").strip(), str(token or "").strip()
    teile = urlsplit(server)
    if teile.scheme not in ("http", "https") or not teile.hostname:
        raise anbieter.AnbieterFehler("Emby-Adresse fehlt oder ist ungültig")
    if not user_id or not token:
        raise anbieter.AnbieterFehler("User-ID und Zugriffsschlüssel fehlen")
    cfg = {"serverType": "emby", "serverUrl": server, "userId": user_id, "accessToken": token}
    return "%s/%s/manifest.json" % (STREAMBRIDGE_BASIS, _blob(cfg))


def trakt_addon_adresse(daten_):
    """Manifest-Adresse des Trakt-Addons aus dem verbundenen H0rSt-Konto. Der Schlüssel bleibt in der Adresse,
    das Addon ist zustandslos und speichert ihn sonst nirgends."""
    konten = ((daten_ or {}).get("trakt") or {}).get("konten") or {}
    konto = next((k for k in konten.values() if isinstance(k, dict) and k.get("access_token") and k.get("refresh_token")), None)
    if not konto:
        raise anbieter.AnbieterFehler("Zuerst ein Profil mit Trakt verbinden")
    cfg = {"lists": [], "ids": [], "access_token": str(konto["access_token"]),
           "refresh_token": str(konto["refresh_token"]), "expires": int(float(konto.get("ablauf") or 0)),
           "removePrefix": False}
    return "%s/%s/manifest.json" % (TRAKT_ADDON_BASIS, _blob(cfg))


def einrichten(daten_, module, name, url, kennung):
    """Legt das Addon an oder ersetzt die Adresse, wenn dieselbe Gegenstelle schon eingetragen ist."""
    for aid, eintrag in (daten_.get("anbieter") or {}).items():
        if eintrag.get("typ") != "stremio-addon":
            continue
        alt = str(((daten_.get("einstellungen") or {}).get(aid) or {}).get("url") or "")
        if kennung and kennung in alt:
            daten_.setdefault("einstellungen", {}).setdefault(aid, {})["url"] = url
            return aid
    return anbieter.hinzufuegen(daten_, module, name, "addons", "url", {"url": url}, typ="stremio-addon",
                                anbieter_id=anbieter.freie_id(daten_, module, name))
