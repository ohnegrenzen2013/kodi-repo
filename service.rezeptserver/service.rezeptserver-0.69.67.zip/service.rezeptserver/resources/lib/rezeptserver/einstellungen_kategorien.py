"""Einstellungen der Oberflaeche: Kategorien und ihre Zeilen."""

from .einstellungen_aiostreams import AIOSTREAMS_KATEGORIE
from .einstellungen_bilddatensatz import BILDDATENSATZ_KATEGORIE
from .einstellungen_discord import DISCORD_KATEGORIE
from .einstellungen_emberp2p import EMBERP2P_KATEGORIE
from .einstellungen_ed2knetz import ED2KNETZ_KATEGORIE
from .einstellungen_emuleese import EMULEESE_KATEGORIE
from .einstellungen_iptvquellen import IPTVQUELLEN_KATEGORIE
from .einstellungen_ipvpn import IPVPN_KATEGORIE
from .einstellungen_keepadb import KEEPADB_KATEGORIE
from .einstellungen_lbry import LBRY_KATEGORIE
from .einstellungen_magicwx import MAGICWX_KATEGORIE
from .einstellungen_mtmanager import MTMANAGER_KATEGORIE
from .einstellungen_nuvio import NUVIO_KATEGORIE
from .einstellungen_qwen_pose import QWEN_POSE_KATEGORIE
from .einstellungen_videowerkstatt import VIDEOWERKSTATT_KATEGORIE
from .einstellungen_shizuku import SHIZUKU_KATEGORIE

SPRACHEN = "sprachen"

KATEGORIEN = [
    {"id": "sprachen", "name": "Sprachen", "symbol": "文", "gruppe": "Sprachen",
     "beschreibung": "In welcher Sprache Ton und Untertitel bevorzugt werden. Passende Streams stehen dann oben.", "zeilen": [
        {"key": "audio", "abschnitt": SPRACHEN, "typ": "text", "titel": "Bevorzugte Tonspur",
         "hinweis": "Sprachkürzel in Wunsch-Reihenfolge: de = Deutsch, en = Englisch, fr = Französisch … Beispiel „de, en“: "
                    "erst deutscher Ton, sonst englischer. Gilt auch in Stremio und Jacktook.", "platzhalter": "de, en", "standard": ""},
        {"key": "untertitel", "abschnitt": SPRACHEN, "typ": "text", "titel": "Untertitel-Sprachen",
         "hinweis": "Erste und zweite Untertitelsprache, z. B. „de, en“ (Kürzel wie oben).", "platzhalter": "de, en", "standard": ""},
    ]},
    {"id": "wiedergabe", "name": "Wiedergabe & Steuerung", "symbol": "▶", "gruppe": "Wiedergabe",
     "beschreibung": "Wie Filme und Folgen starten: automatisch abspielen, nächste Folge, Trailer, unerwünschte Versionen ausblenden.", "zeilen": [
        {"key": "autoplay", "typ": "schalter", "titel": "Automatisch abspielen", "standard": True,
         "hinweis": "Öffnest du einen Film oder eine Folge, startet sofort die erste passende Quelle – ohne Auswahl. Welche passt, legen die drei Zeilen darunter fest."},
        {"key": "autoplay_min", "typ": "wahl", "titel": "Automatisch abspielen: mindestens", "standard": "alle",
         "werte": [["alle", "Alle"], ["720p", "720p"], ["1080p", "1080p"], ["4k", "4K"]]},
        {"key": "autoplay_max", "typ": "wahl", "titel": "Automatisch abspielen: höchstens", "standard": "4k",
         "werte": [["4k", "4K"], ["1080p", "1080p"], ["720p", "720p"], ["sd", "SD"]]},
        {"key": "autoplay_groesse", "typ": "wahl", "titel": "Automatisch abspielen: größte Datei", "standard": "0",
         "hinweis": "Begrenzt große Dateien, z. B. bei langsamer Leitung. Quellen ohne Größenangabe zählen als passend.",
         "werte": [["0", "Unbegrenzt"], ["2", "2 GB"], ["5", "5 GB"], ["10", "10 GB"], ["20", "20 GB"], ["50", "50 GB"]]},
        {"key": "naechste_folge", "typ": "schalter", "titel": "Nächste Folge automatisch", "standard": True,
         "hinweis": "Ist eine Folge zu Ende, startet die nächste von selbst (bei der Wiedergabe im Browser). In „Ab 18“ "
                    "startet ebenso das nächste Video derselben Reihe."},
        {"key": "trailer", "typ": "wahl", "titel": "Trailer in den Details", "standard": "knopf",
         "hinweis": "Zeigt den Trailer eines Films in der Detailansicht. „Automatisch“ spielt ihn stumm im großen Bild oben ab – ohne Werbung.",
         "werte": [["aus", "Aus"], ["knopf", "Mit Knopf"], ["auto", "Automatisch (stumm)"]]},
        {"key": "dlna_server", "typ": "schalter", "titel": "Medienserver im Heimnetz (DLNA)", "standard": True,
         "hinweis": "Fernseher, Receiver (Dreambox), Kodi und VLC sehen H0rSt als Quelle „H0rSt“ und spielen Radio-Favoriten "
                    "Live-TV und deine eigenen Speicher (Musik, Filme, Fotos) direkt ab – ohne dass du hier etwas antippst. Nur, wenn H0rSt im Heimnetz erreichbar ist."},
        {"key": "bildanpassung", "typ": "wahl", "titel": "Bildanpassung bei der Wiedergabe im Browser", "standard": "einpassen",
         "hinweis": "Einpassen zeigt das ganze Bild, Zoom füllt den Bildschirm (Ränder fallen weg), Strecken verzerrt. "
                    "Der App-Player hat dafür eigene Optionen (⚙ im Player).",
         "werte": [["einpassen", "Einpassen"], ["zoom", "Zoom (füllen)"], ["strecken", "Strecken"]]},
        {"key": "ausschliessen", "typ": "text", "titel": "Versionen ausblenden", "standard": "",
         "hinweis": "Quellen, deren Name dieses Muster enthält, werden nicht angezeigt. Beispiel „CAM|HDTS|TELESYNC“ blendet "
                    "abgefilmte Kinoaufnahmen aus. Mehrere Wörter mit | trennen; für Fortgeschrittene ein regulärer Ausdruck.", "platzhalter": "CAM|HDTS|TELESYNC"},
    ]},
    {"id": "markenerkennung", "name": "Intro/Abspann automatisch erkennen", "symbol": "⏱", "gruppe": "Wiedergabe",
     "beschreibung": "Erkennt Intro-Ende und Abspann-Anfang automatisch, statt sie von Hand zu markieren (⏱ Marken im Player).",
     "zeilen": [
        {"key": "markenerkennung_an", "typ": "schalter", "titel": "Automatisch erkennen (XDCC-Downloads)", "standard": False,
         "hinweis": "Läuft im Hintergrund, sobald ein XDCC-Download fertig ist und der Dateiname eine Folge erkennen lässt "
                    "(Serie + Staffel/Folge). Kostet keine zusätzliche Bandbreite – die Datei liegt schon da. Der Vorschlag "
                    "muss im Player unter „⏱ Marken“ erst bestätigt werden, nichts wird automatisch übernommen."},
        {"key": "markenerkennung_download_an", "typ": "schalter", "titel": "Auch für Stremio/Debrid/Usenet-Streaming erlauben",
         "standard": False,
         "hinweis": "Lädt dafür eine Folge vorübergehend herunter (und löscht sie danach wieder) – kostet Speicherplatz und "
                    "Bandbreite. Nur je Folge über den Knopf bei den Streams, nie automatisch für alle Folgen."},
        {"key": "markenerkennung_download_mb", "typ": "wahl", "titel": "Höchstens herunterladen", "standard": "500",
         "werte": [["200", "200 MB"], ["500", "500 MB"], ["1000", "1 GB"], ["2000", "2 GB"]]},
        {"key": "marken_introdb", "typ": "schalter", "titel": "IntroDB fragen (Internet)", "standard": False,
         "hinweis": "Holt zu einer IMDb-Kennung die von der Community gemeldeten Intro-, Recap- und Abspann-Zeiten von "
                    "introdb.app. Es werden nur Titel-Kennung, Staffel und Folge übertragen. Der Vorschlag erscheint im "
                    "Player unter „⏱ Marken“ und wird erst nach Bestätigung übernommen."},
        {"key": "marken_aniskip", "typ": "schalter", "titel": "AniSkip fragen (Anime)", "standard": False,
         "hinweis": "Holt zu Anime-Folgen die Op/Ed-Zeiten von api.aniskip.com. Die MAL-Kennung stammt aus dem "
                    "SIMKL-Abgleich oder aus einer Kennung der Form „mal:12345:1:2“."},
        {"key": "marken_theintrodb", "typ": "schalter", "titel": "TheIntroDB fragen", "standard": False,
         "hinweis": "Holt Intro-, Recap-, Abspann- und Vorschau-Segmente von api.theintrodb.org – mehrere Segmente je "
                    "Folge. Der Vorschlag erscheint unter „⏱ Marken“ und wird erst nach Bestätigung aktiv."},
    ]},
    {"id": "darstellung", "name": "Darstellung", "symbol": "◐", "gruppe": "Darstellung & Bedienung",
     "beschreibung": "Wie H0rSt aussieht: Hintergrundbild, Farben, Größen, Abstände und Bewegung.", "zeilen": [
        {"key": "stil", "typ": "wahl", "titel": "Heim-Style", "standard": "klassisch",
         "hinweis": "Das ganze Zuhause in einem Zug: Warmes Heim (Kaminlicht, Holz, weich), Elegantes Heim (Schwarz, Elfenbein, Gold), "
                    "Futuristisches Heim (Neon, Raster, Cockpit) oder Super Heim – dort dockst du Bereiche als Fenster an "
                    "Seiten und Ecken an, markierst sie mit den Farbtasten der Fernbedienung und H0rSt hört auf Zuruf. "
                    "Dazu zweiundzwanzig Styles als Dank an die Apps, von denen H0rSt gelernt hat, jeweils als [ \"Name\" @ H0rSt ]: "
                    "ARVIO (Schwarz, weißer Fokus), Stremio (Violett, Leiste links), Nuvio (Graphit, schwebende Leiste), "
                    "StreamCloud (Schwarz und Lachs, Leiste unten), ROGplay (Glas, Himmelblau bis Violett), Vyxel Apps (Lavendel, Pillen, schwebende Leiste), "
                    "Jellyfin (Blau auf fast Schwarz, eckige Karten), Winlator (Blau-Grau, nicht aus dem Quellcode belegt), "
                    "MT Manager (Azurblau, VIP-Gold, scharfe Kanten), Web Video Caster (Material-Blau, weiße Knöpfe), "
                    "Netflix (Rot auf Schwarz, kleine Rundungen), MX Player (Schwarz mit Markenblau, Leiste unten), "
                    "Goon (Creme und Karminrot, Versalien), Open Generative AI (Schwarzglas, Cyan und Violett), "
                    "Opera GX (Neonrot auf Schwarz, GX-Control-Optik), NOVA (Tiefblau, hellblauer Akzent, Leiste links) und "
                    "GNUnet (helles Grau, dunkler Balken, Blau und Grün), MagicWX (dunkles Material-3-Grün), "
                     "Shizuku (Material 3, Periwinkel und Flieder), Ember-P2P (helles Blau, Ember-Rosé) und "
                     "eSE LiveTV (Schwarz mit Orange-Pink-Verlauf) und OmniSearch (Schieferglas, Himmelblau) "
                     "und KeepADB (Schwarz, Rot und Titelgelb) und YouTube (fast Schwarz, weiße Pillen, Rot als Akzent) "
                     "sehen wie das Original aus. "
                    "Kodi-Skin: Farben, Schriften und Hintergrund eines Kodi-Skins (unten unter „Kodi-Skins“ wählen).",
         "werte": [["klassisch", "H0rSt klassisch"], ["warm", "Warmes Heim"], ["elegant", "Elegantes Heim"],
                   ["futur", "Futuristisches Heim"], ["super", "Super Heim"], ["arvio", "[ \"ARVIO\" @ H0rSt ]"],
                   ["stremio", "[ \"Stremio\" @ H0rSt ]"], ["nuvio", "[ \"Nuvio\" @ H0rSt ]"],
                   ["nuviotv", "[ \"NuvioTV\" @ H0rSt ]"], ["nuviomobil", "[ \"NuvioMobil\" @ H0rSt ]"],
                   ["streamcloud", "[ \"StreamCloud\" @ H0rSt ]"],
                   ["rogplay", "[ \"ROGplay\" @ H0rSt ]"], ["vyxel", "[ \"Vyxel Apps\" @ H0rSt ]"],
                   ["jellyfin", "[ \"Jellyfin\" @ H0rSt ]"], ["winlator", "[ \"Winlator\" @ H0rSt ]"],
                   ["mtmanager", "[ \"MT Manager\" @ H0rSt ]"], ["webvideocaster", "[ \"Web Video Caster\" @ H0rSt ]"],
                   ["netflix", "[ \"Netflix\" @ H0rSt ]"], ["mxplayer", "[ \"MX Player\" @ H0rSt ]"],
                   ["goon", "[ \"Goon\" @ H0rSt ]"], ["opengenerativeai", "[ \"Open Generative AI\" @ H0rSt ]"], ["operagx", "[ \"Opera GX\" @ H0rSt ]"],
                   ["nova", "[ \"NOVA\" @ H0rSt ]"], ["gnunet", "[ \"GNUnet\" @ H0rSt ]"], ["magicwx", "[ \"MagicWX\" @ H0rSt ]"],
                   ["shizuku", "[ \"Shizuku\" @ H0rSt ]"], ["emberp2p", "[ \"Ember-P2P\" @ H0rSt ]"],
                    ["emuleese", "[ \"eSE LiveTV\" @ H0rSt ]"], ["omnisearch", "[ \"OmniSearch\" @ H0rSt ]"],
                    ["keepadb", "[ \"KeepADB\" @ H0rSt ]"], ["youtube", "[ \"YouTube\" @ H0rSt ]"], ["kodiskin", "Kodi-Skin"]]},
        {"key": "winlator_stil", "typ": "schalter", "titel": "Winlator-Stil anzeigen", "standard": True,
         "hinweis": "Winlator [ @ H0rSt ] im Stil-Picker anzeigen. Deaktivieren blendet den Stil aus der Auswahl aus."},
        {"key": "karten", "typ": "wahl", "titel": "Kartenlayout", "standard": "breit",
         "hinweis": "Breite 16:9-Karten mit Titel-Logo oder Poster. Jedes Gerät kann in „Durchsuchen“ umschalten.",
         "werte": [["breit", "Breit"], ["poster", "Poster"]]},
        {"key": "hintergrund", "typ": "wahl", "titel": "Hintergrund", "standard": "oled",
         "hinweis": "Reines Schwarz spart auf OLED-Bildschirmen Strom.",
         "werte": [["oled", "Schwarz (OLED)"], ["grau", "Dunkelgrau"]]},
        {"key": "hintergrund_bild", "typ": "wahl", "titel": "Hintergrundbild", "standard": "aus",
         "hinweis": "Wechselnde Filmszenen (aus Entdecken), ein eigenes Bild per Adresse oder hochgeladen (unten).",
         "werte": [["aus", "Aus"], ["film", "Filmszenen, wechselnd"], ["adresse", "Eigenes Bild (Adresse)"],
                   ["upload", "Eigenes Bild (hochgeladen)"]]},
        {"key": "hintergrund_url", "typ": "text", "titel": "Adresse des Hintergrundbilds", "standard": "",
         "platzhalter": "https://…/bild.jpg", "hinweis": "Für „Eigenes Bild (Adresse)“."},
        {"key": "hintergrund_unschaerfe", "typ": "wahl", "titel": "Hintergrund: Unschärfe", "standard": "6",
         "werte": [["0", "Scharf"], ["3", "Leicht"], ["6", "Mittel"], ["14", "Stark"]]},
        {"key": "hintergrund_dunkel", "typ": "wahl", "titel": "Hintergrund: Abdunkeln", "standard": "70",
         "hinweis": "Damit Schrift gut lesbar bleibt.",
         "werte": [["40", "Wenig"], ["55", "Etwas"], ["70", "Mittel"], ["85", "Stark"]]},
        {"key": "hintergrund_wechsel", "typ": "wahl", "titel": "Filmszenen wechseln alle", "standard": "30",
         "werte": [["15", "15 Sekunden"], ["30", "30 Sekunden"], ["60", "1 Minute"], ["300", "5 Minuten"]]},
        {"key": "glas", "typ": "schalter", "titel": "Glaseffekt", "standard": True,
         "hinweis": "Flächen sind leicht durchsichtig, das Hintergrundbild schimmert verschwommen durch."},
        {"key": "ecken", "typ": "wahl", "titel": "Ecken", "standard": "rund",
         "werte": [["eckig", "Eckig"], ["rund", "Rund"], ["sehr", "Sehr rund"]]},
        {"key": "dichte", "typ": "wahl", "titel": "Abstände", "standard": "normal",
         "werte": [["kompakt", "Kompakt"], ["normal", "Normal"], ["luftig", "Luftig"]]},
        {"key": "kartengroesse", "typ": "wahl", "titel": "Kartengröße", "standard": "mittel",
         "hinweis": "Größe der Film- und Serienkarten in den Reihen.",
         "werte": [["klein", "Klein"], ["mittel", "Mittel"], ["gross", "Groß"]]},
        {"key": "poster_groesse", "typ": "wahl", "titel": "Poster-Größe", "standard": "karte",
         "hinweis": "Hochformat-Poster in allen Reihen und Raster dieses Profils (S bis XL). „Wie Kartengröße“ lässt es bei der Einstellung darüber.",
         "werte": [["karte", "Wie Kartengröße"], ["s", "S"], ["m", "M"], ["l", "L"], ["xl", "XL"]]},
        {"key": "quer_groesse", "typ": "wahl", "titel": "Querbild-Größe", "standard": "karte",
         "hinweis": "Querformat-Bilder (Landscape-Karten) in allen Reihen und Raster dieses Profils (S bis XL).",
         "werte": [["karte", "Wie Kartengröße"], ["s", "S"], ["m", "M"], ["l", "L"], ["xl", "XL"]]},
        {"key": "akzent", "typ": "farbe", "titel": "Akzentfarbe", "standard": "gruen",
         "werte": [["gruen", "Grün"], ["blau", "Blau"], ["violett", "Violett"], ["pink", "Pink"], ["rot", "Rot"],
                   ["orange", "Orange"], ["gelb", "Gelb"]]},
        {"key": "schrift", "typ": "wahl", "titel": "Schriftgröße", "standard": "normal",
         "hinweis": "„Fernseher“ für große Abstände mit der Fernbedienung.",
         "werte": [["klein", "Klein"], ["normal", "Normal"], ["gross", "Groß"], ["tv", "Fernseher"]]},
        {"key": "anpassen", "typ": "wahl", "titel": "Größe ans Fenster anpassen", "standard": "fenster",
         "hinweis": "Die Oberfläche wächst mit großen Fenstern und Fernsehern mit und schrumpft auf sehr kleinen Bildschirmen – "
                    "ohne seitliches Verrutschen. „Feste Größe“ nimmt nur die Schriftgröße oben.",
         "werte": [["fenster", "An die Fenstergröße anpassen"], ["fest", "Feste Größe"]]},
        {"key": "screenfit_rand", "typ": "wahl", "titel": "Sicherheitsrand für Fernseher", "standard": "0",
         "hinweis": "Blendet an allen Seiten einen Rand ein, damit Menüs und Karten nicht im Overscan des Fernsehers verschwinden. "
                    "Mit „Bildschirm einpassen“ unter der Liste prüfen und so weit erhöhen, bis der grüne Rahmen überall sichtbar ist.",
         "werte": [["0", "Aus"], ["1", "1 % (schmal)"], ["2", "2 %"], ["3", "3 % (mittel)"], ["4", "4 %"], ["5", "5 % (breit)"]]},
        {"key": "screenfit_zoom", "typ": "wahl", "titel": "Feinjustierung der Größe", "standard": "100",
         "hinweis": "Zusätzlich zur Schriftgröße und Fensteranpassung. Für Fernseher, die trotzdem noch zu groß oder zu klein wirken, "
                    "in 5-%-Schritten feinjustieren.",
         "werte": [["90", "90 %"], ["95", "95 %"], ["100", "100 %"], ["105", "105 %"], ["110", "110 %"], ["115", "115 %"]]},
        {"key": "screenfit_fokus", "typ": "schalter", "titel": "Kräftiger Fokus für die Fernbedienung", "standard": False,
         "hinweis": "Dickerer Fokusrahmen mit Leuchtrand – hilft auf dem TV, den aktuell gewählten Knopf auch aus der Entfernung zu sehen."},
        {"key": "uhr", "typ": "wahl", "titel": "Uhr in der Kopfzeile", "standard": "aus",
         "werte": [["aus", "Aus"], ["24", "24 Stunden"], ["12", "12 Stunden"]]},
        {"key": "animationen", "typ": "schalter", "titel": "Lebendige Bilder", "standard": True,
         "hinweis": "Langsamer Kamerazoom im Kopfbild, Karten blenden weich ein und bewegen sich beim Auswählen. "
                    "Aus, wenn das Gerät „Bewegung reduzieren“ verlangt."},
        {"key": "rampenlicht", "typ": "schalter", "titel": "Kopfbild in Filme und Serien", "standard": True,
         "hinweis": "Oben in Entdecken ein großes Bild der beliebtesten Titel mit Logo, Inhalt und „Ansehen“ – wie in ARVIO, "
                    "Nuvio und StreamCloud. Wechselt alle paar Sekunden (mit „Lebendige Bilder“), ◀ ▶ blättern von Hand."},
        {"key": "netflix_home", "typ": "schalter", "titel": "Netflix-Startseite", "standard": True,
         "hinweis": "Große Banner-Bühne mit Hintergrundbild, Logo und Inhalt des hervorgehobenen Titels, Karten, die beim Auswählen "
                    "größer werden und ihre Daten zeigen, weiche Übergänge. Mit Maus, Touch und Fernbedienung (Pfeiltasten, OK); "
                    "Zurück lange gedrückt springt zum Anfang der Reihen. Aus = die bisherige Startseite."},
        {"key": "netflix_trailer", "typ": "schalter", "titel": "Trailer im Banner abspielen", "standard": True,
         "hinweis": "Im Banner der Netflix-Startseite startet nach kurzer Pause der Trailer des Titels, stumm (Quelle: TMDb-Videos, "
                    "sonst Cinemeta). Braucht „Netflix-Startseite“; aus, wenn das Gerät „Bewegung reduzieren“ verlangt."},
        {"key": "sammlung_vorschau", "typ": "schalter", "titel": "Sammlungs-Vorschau in der Bibliothek", "standard": True,
         "hinweis": "In Weiterschauen, Merkliste, Verlauf und in Listen-Katalogen zeigt eine Vorschau oben Bild, Logo, Inhalt und Daten "
                    "des Titels, den du gerade auswählst (soweit die Daten vorliegen)."},
        {"key": "merkliste_reihe", "typ": "schalter", "titel": "Merkliste direkt unter „Weiterschauen“", "standard": False,
         "hinweis": "Zeigt in Entdecken unter „Weiterschauen“ eine Reihe mit der Merkliste (wie die optionale Watchlist-Reihe in ARVIO)."},
        {"key": "reihen_rang", "typ": "schalter", "titel": "Rangzahlen in „Beliebt“-Reihen", "standard": False,
         "hinweis": "Große Zahlen 1, 2, 3 … neben den Karten der „Beliebt“-Reihen (Rangliste wie bei Vavoo und den Streamingdiensten). "
                    "Die Rangfolge ist die der Quelle (Cinemeta/TMDb), keine Tageswertung."},
        {"key": "ambient_min", "typ": "wahl", "titel": "Ambient-Modus (Bildschirmschoner)", "standard": "aus",
         "hinweis": "Bleibt H0rSt so lange unberührt, zeigt es Hintergrundbilder der beliebtesten Titel mit Uhr, ganz ohne Ton und ohne Player. "
                    "Jede Taste, jeder Klick oder jede Berührung beendet ihn (Idee: Nuvios Ambient Mode). Nicht während ein Video läuft.",
         "werte": [["aus", "Aus"], ["2", "Nach 2 Minuten"], ["5", "Nach 5 Minuten"], ["10", "Nach 10 Minuten"], ["20", "Nach 20 Minuten"]]},
        {"key": "livetv_liste", "typ": "schalter", "titel": "Live-TV als Senderliste", "standard": True,
         "hinweis": "„Alle Kanäle“ erscheint als Liste mit Rang, Logo, laufender Sendung, Fortschritt, Suche und Sortierung (Vorbild: Vavoos Kanalliste) "
                    "statt als Kachelraster. Aus = die bisherigen Kacheln."},
        {"key": "livetv_taste", "typ": "wahl", "titel": "Live-TV: Vollbild ⇄ kompakt per Taste", "standard": "menue",
         "hinweis": "Zurück lange gedrückt wechselt immer zwischen Vollbild und kleinem Bild mit der Senderliste (der laufende Sender ist markiert, "
                    "ähnlich TiviMate). Android 13 und neuer liefert langes Zurück nicht auf jedem Gerät – darum hier eine zweite Taste.",
         "werte": [["keine", "Nur Zurück lang"], ["menue", "Zusätzlich Menü-Taste"], ["info", "Zusätzlich Info-Taste (i)"],
                   ["ok", "Zusätzlich OK lang"]]},
    ]},
    {"id": "bedienung", "name": "Bedienung & Tasten", "symbol": "⌨", "gruppe": "Darstellung & Bedienung",
     "beschreibung": "Mit welchen Tasten du H0rSt steuerst: Fernbedienung (auch Farbtasten), Zahlentasten oder Tastatur – oder ein "
                     "eigenes Schema, in dem du jede Aktion selbst belegst. Dazu „H0rSt hört“: Sprachbefehle wie „öffne Sicherheit“.", "zeilen": [
        {"key": "tasten_schema", "typ": "wahl", "titel": "Tastatur-Schema", "standard": "fernbedienung",
         "hinweis": "Pfeiltasten, OK und Zurück gehen immer. Das Schema legt die Extratasten fest; „Eigenes“ belegst du unten frei.",
         "werte": [["fernbedienung", "Fernbedienung (Farbtasten)"], ["zahlen", "Zahlentasten"], ["tastatur", "Tastatur (Alt + …)"],
                   ["eigenes", "Eigenes Schema"]]},
        {"key": "zuhoeren", "typ": "schalter", "titel": "H0rSt hört (Mikrofon-Knopf)", "standard": True,
         "hinweis": "🎙 oben in der Kopfzeile: sag „öffne Filme“, „suche Matrix“, „Fenster links“, „zurück“ oder „Licht aus“. "
                    "Im Browser über dessen Spracherkennung, in der App über die Android-Spracheingabe."},
        {"key": "spoiler", "typ": "schalter", "titel": "Spoiler-Schutz", "standard": False,
         "hinweis": "Titel noch nicht gesehener Folgen verbergen."},
        {"key": "gesehene_aus", "typ": "schalter", "titel": "Gesehene ausblenden", "standard": False,
         "hinweis": "Bereits gesehene Titel in Suche und Entdecken weglassen (Gerät kann abweichen)."},
        {"key": "sanft", "typ": "schalter", "titel": "Sanftes Scrollen", "standard": True,
         "hinweis": "Weiche Übergänge beim Wechseln durch die Kartenreihen."},
    ]},
    {"id": "ansichten", "name": "Ansichten je Reiter", "symbol": "▦", "gruppe": "Darstellung & Bedienung",
     "beschreibung": "Jeder Reiter merkt sich seine eigene Ansicht: Bildgröße, bewegte Vorschau, Trailer und wie viele Inhalte "
                     "auf einmal erscheinen – und ob die Filter links in einer Seitenleiste oder oben stehen. Auch direkt in der Seitenleiste des Reiters einstellbar.", "zeilen": [
        {"key": "filme_bild", "typ": "wahl", "titel": "Filme: Bildgröße", "standard": "standard",
         "hinweis": "„Wie überall“ nimmt die Kartengröße aus Darstellung.",
         "werte": [["standard", "Wie überall"], ["klein", "Klein"], ["mittel", "Mittel"], ["gross", "Groß"], ["riesig", "Riesig"]]},
        {"key": "filme_vorschau", "typ": "wahl", "titel": "Filme: Vorschau beim Auswählen", "standard": "bilder",
         "hinweis": "Bleibt eine Karte kurz ausgewählt, bewegt sich das Bild (Kamerafahrt) oder der Trailer läuft stumm in der Karte – ohne Werbung.",
         "werte": [["aus", "Aus"], ["bilder", "Bewegtes Bild"], ["trailer", "Trailer (stumm)"]]},
        {"key": "filme_anzahl", "typ": "wahl", "titel": "Filme: Inhalte auf einmal", "standard": "alle",
         "hinweis": "Wie viele Karten je Reihe bzw. je „Mehr laden“ erscheinen.",
         "werte": [["12", "12"], ["24", "24"], ["48", "48"], ["96", "96"], ["alle", "Alle"]]},
        {"key": "serien_bild", "typ": "wahl", "titel": "Serien: Bildgröße", "standard": "standard",
         "hinweis": "„Wie überall“ nimmt die Kartengröße aus Darstellung.",
         "werte": [["standard", "Wie überall"], ["klein", "Klein"], ["mittel", "Mittel"], ["gross", "Groß"], ["riesig", "Riesig"]]},
        {"key": "serien_vorschau", "typ": "wahl", "titel": "Serien: Vorschau beim Auswählen", "standard": "bilder",
         "hinweis": "Wie bei Filmen: Kamerafahrt oder stummer Trailer in der ausgewählten Karte.",
         "werte": [["aus", "Aus"], ["bilder", "Bewegtes Bild"], ["trailer", "Trailer (stumm)"]]},
        {"key": "serien_anzahl", "typ": "wahl", "titel": "Serien: Inhalte auf einmal", "standard": "alle",
         "hinweis": "Wie viele Karten je Reihe bzw. je „Mehr laden“ erscheinen.",
         "werte": [["12", "12"], ["24", "24"], ["48", "48"], ["96", "96"], ["alle", "Alle"]]},
        {"key": "ab18_bild", "typ": "wahl", "titel": "Ab 18: Bildgröße", "standard": "standard",
         "hinweis": "„Wie überall“ nimmt die Kartengröße aus Darstellung.",
         "werte": [["standard", "Wie überall"], ["klein", "Klein"], ["mittel", "Mittel"], ["gross", "Groß"], ["riesig", "Riesig"]]},
        {"key": "ab18_vorschau", "typ": "wahl", "titel": "Ab 18: Vorschau beim Auswählen", "standard": "bilder",
         "hinweis": "Bilderfolge aus den Vorschaubildern der Seite oder ein kurzer Clip, wenn die Seite einen liefert (RedGifs). Ohne Ton.",
         "werte": [["aus", "Aus"], ["bilder", "Bilderfolge"], ["clip", "Clip (wenn vorhanden)"]]},
        {"key": "ab18_anzahl", "typ": "wahl", "titel": "Ab 18: Inhalte auf einmal", "standard": "alle",
         "hinweis": "Wie viele Karten je Reihe bzw. je „Mehr laden“ erscheinen.",
         "werte": [["12", "12"], ["24", "24"], ["48", "48"], ["96", "96"], ["alle", "Alle"]]},
        {"key": "leiste", "typ": "wahl", "titel": "Einstellungen in den Reitern", "standard": "links",
         "hinweis": "Filter und Ansicht von Filme, Serien und Ab 18 stehen links in einer Seitenleiste – mit der Fernbedienung "
                    "einmal nach links, und du bist dort, statt in einer langen Zeile festzuhängen. Auf schmalen Bildschirmen immer oben.",
         "werte": [["links", "Links (Seitenleiste)"], ["oben", "Oben (eine Zeile)"]]},
    ]},
    {"id": "start", "name": "Start & Baukasten", "symbol": "✦", "gruppe": "Darstellung & Bedienung",
     "beschreibung": "Was beim Öffnen der App passiert: die Startanimation (eigenes Bild oder Video), der Autostart "
                     "(welche Dienste beim Start mitlaufen) und der m0dul-Baukasten, mit dem du Module an- und abdockst.", "zeilen": [
        {"key": "startanimation", "typ": "wahl", "titel": "Startanimation", "standard": "standard",
         "hinweis": "Läuft in der App, während H0rSt startet. „Eigene“ nimmt das Bild oder Video, das du unten "
                    "hochlädst – die Dateiendung ist egal, erkannt wird am Inhalt. Antippen oder OK überspringt sie.",
         "werte": [["standard", "H0rSt-Animation"], ["eigene", "Eigenes Bild oder Video"], ["aus", "Aus"]]},
        {"key": "startanimation_laenge", "typ": "wahl", "titel": "Startanimation: höchstens", "standard": "8",
         "hinweis": "Ein Bild bleibt so lange stehen, ein Video endet spätestens dann (oder vorher, wenn es kürzer ist).",
         "werte": [["3", "3 Sekunden"], ["5", "5 Sekunden"], ["8", "8 Sekunden"], ["15", "15 Sekunden"],
                   ["30", "30 Sekunden"]]},
        {"key": "startanimation_ton", "typ": "schalter", "titel": "Startanimation mit Ton", "standard": False,
         "hinweis": "Spielt den Ton eines eigenen Videos mit ab."},
    ]},
    {"id": "profil", "name": "Profil", "symbol": "☺", "gruppe": "Profile & Zugriff",
     "beschreibung": "Dein Name und Profilbild – erscheinen oben rechts in der Kopfzeile.", "zeilen": [
        {"key": "profilname", "typ": "text", "titel": "Name", "standard": "", "platzhalter": "z. B. Lin",
         "hinweis": "Erscheint mit dem Profilbild oben in der Kopfzeile."},
    ]},
    {"id": "profile", "name": "Profile & Rechte", "symbol": "👥", "gruppe": "Profile & Zugriff", "eigen": True,
     "beschreibung": "Mehrere Menschen, ein H0rSt: jeder mit eigener Ansicht. Rollen und Rechte, Gruppen, Einladungen "
                     "und Beitrittsanfragen – und wer externe Speicher wählen darf. Dazu Kinderprofile mit Altersgrenze und Eltern-PIN."},
    {"id": "admin", "name": "Admin-Panel", "symbol": "🛠", "gruppe": "Profile & Zugriff", "eigen": True,
     "beschreibung": "Mitgliederliste wie im Forum: Traffic, Anfragen, Verbindungen und Zeit je Profil. Grenzen setzen, "
                     "Profile sperren, Speicher-Kontingente des Servers (Listen, Uploads) – und die Top-Module, -Anbieter und -Addons."},
    {"id": "menue", "name": "Menü (Rezepte-StammBaum)", "symbol": "🌳", "gruppe": "Darstellung & Bedienung", "eigen": True,
     "beschreibung": "Alle Module, Reiter, eigenen Tabs und Rezepte als Stammbaum. Frei sortierbar, mit einem Klick "
                     "angedockt oder abgedockt; löschst du einen Eintrag, rückt der nächste automatisch nach."},
    {"id": "navigation", "name": "Navigation", "symbol": "☰", "gruppe": "Darstellung & Bedienung",
     "beschreibung": "Welche Reiter oben stehen, in welcher Reihenfolge, und was beim Öffnen erscheint. Dazu eigene Reiter für Apps und Webseiten.", "zeilen": [
        {"key": "startbereich", "typ": "wahl", "titel": "Beim Öffnen zeigen", "standard": "start",
         "hinweis": "Welcher Bereich erscheint, wenn H0rSt (oder der Startbildschirm der App) geöffnet wird.",
         "werte": [["start", "Start"], ["filme", "Filme"], ["serien", "Serien"], ["livetv", "Live-TV"], ["youtube", "YouTube"], ["radio", "Radio"], ["kodiaddons", "Kodi-Addons"], ["gamehub", "GameHub"], ["brause", "Brause"], ["lesehalle", "Lesehalle (nur App)"], ["portal", '("_• )—*'], ["gemeinsam", "Gemeinsam schauen"], ["daumenkino", "Daumenkino"], ["localdream", "LocalDream"], ["karaoke", "Karaoke"],
                   ["apps", "Apps (nur App)"], ["dateisuche", "Dateisuche"], ["easynews", "Easynews"], ["usenet", "Usenet-Stream"], ["dienste", "Herunterladen"], ["tresor", "Tresor"],
                   ["heim", "Heim"], ["kameras", "Kameras"], ["videochat", "Videochat"], ["licht", "Smart Home"], ["webhosting", "Webhosting"]]},
    ]},
    {"id": "tresor", "name": "Passwort-Tresor", "symbol": "🔐", "gruppe": "Verbindungen & Geräte", "eigen": True,
     "beschreibung": "pass-kompatible Passwörter, Einmalcodes und Git-Abgleich. Pfad intern oder extern wählen, "
                     "Darstellung als Reiter, Verknüpfung oder im Seitenmenü – der Tresor erscheint auch im Menü-Baum."},
    {"id": "telegram", "name": "Telegram", "symbol": "✈", "gruppe": "Verbindungen & Geräte", "eigen": True,
     "beschreibung": "H0rSt schickt dir Nachrichten aufs Handy (Störungen, fertige Downloads, Updates) und nimmt Befehle an."},
    {"id": "konten", "name": "Trakt, SIMKL, MDBList & Google Drive", "symbol": "🔗", "gruppe": "Verbindungen & Geräte", "eigen": True,
     "beschreibung": "Merkliste, Verlauf und Weiterschauen mit Trakt und SIMKL abgleichen, Listen von MDBList und Trakt als Kataloge, eigene YouTube-Reihen, Sicherungen in Google Drive."},
    {"id": "cloudstream", "name": "CloudStream-Repositories", "symbol": "☁", "gruppe": "Verbindungen & Geräte", "eigen": True,
     "beschreibung": "CloudStream-Repositories lesen und .cs3-Extensions mit SHA-256-Prüfung laden. H0rSt führt den Android-DEX-Code nicht aus – die Dateien sind für eine CloudStream-Installation gedacht.",
     "zeilen": []},
    {"id": "untertitel_quellen", "name": "Zusätzliche Untertitelquellen", "symbol": "⌨", "gruppe": "Verbindungen & Geräte", "eigen": True,
     "beschreibung": "Untertitel von SubSource, SubDL und Addic7ed zusätzlich zu den Rezepten und Addons. ZIP-Pakete entpackt H0rSt und liefert die erste Untertiteldatei über /api/untertitel aus.",
     "zeilen": [
        {"key": "subsource_an", "typ": "schalter", "titel": "SubSource fragen", "standard": True,
         "hinweis": "Kostenlos, ohne Schlüssel, Sucht über die IMDb-Kennung."},
        {"key": "subdl_key", "typ": "passwort", "titel": "SubDL-API-Schlüssel", "standard": "",
         "hinweis": "Kostenlos auf subdl.com/panel/register; ohne Schlüssel wird SubDL nicht gefragt."},
        {"key": "addic7ed_an", "typ": "schalter", "titel": "Addic7ed fragen", "standard": False,
         "hinweis": "Liest die öffentliche Suchseite; übernimmt nur Links zu Original-/Updated-Untertiteln."},
    ]},
    {"id": "sammlungen", "name": "Sammlungen (Collections)", "symbol": "▦", "gruppe": "Verbindungen & Geräte", "eigen": True,
     "beschreibung": "Wie ARVIO: eigene Sammlungen als Reihen mit Ordnern anlegen oder importieren (Nuvio-/ARVIO-JSON per Adresse "
                     "oder Text). Quellen: TMDb (Discover, Franchise, Liste, Person), Trakt- und MDBList-Listen, Kataloge "
                     "eingetragener Stremio-Addons. Dazu das Collection Studio zum Zusammenklicken und Teilen."},
    {"id": "addons", "name": "Anbieter & Addons", "symbol": "⧉", "gruppe": "Verbindungen & Geräte", "eigen": True,
     "beschreibung": "Woher Filme, Serien und Downloads kommen: Zugänge zu Diensten eintragen, aus Vorlagen mit wenigen Klicks.",
     "text": "Stremio-Addons, Usenet, Indexer, Debrid, Downloader, Pi-hole, Kodi und Stream-Badges – aus Vorlagen oder per JSON.",
    },
    {"id": "usenet_healthcheck", "name": "Usenet-Gesundheitsprüfung", "symbol": "🩺", "gruppe": "Verbindungen & Geräte",
     "beschreibung": "Prüft NZB-Kandidaten per NNTP-Stichprobe, bevor sie als Usenet-Stream angezeigt werden (Vorbild "
                     "UsenetStreamer) – deckt den häufigsten Ausfall ab (abgelaufene Artikel beim Provider), kein "
                     "Archiv-Inhalts-Check. Nutzt den ersten eingetragenen Usenet-Server (Anbieter & Addons).",
     "zeilen": [
        {"key": "usenet_healthcheck_an", "typ": "schalter", "titel": "Gesundheitsprüfung aktivieren", "standard": False,
         "hinweis": "Ohne eingetragenen Usenet-Server (Anbieter & Addons) bleibt diese Einstellung wirkungslos."},
        {"key": "usenet_healthcheck_modus", "typ": "wahl", "titel": "Modus", "standard": "vorab",
         "hinweis": "„Vorab“ prüft, bevor die Trefferliste erscheint, und zeigt nur geprüfte Kandidaten. „Im Hintergrund“ "
                    "zeigt die Liste sofort, prüft nebenbei weiter – ein Abzeichen (✅/⚠/🚫) erscheint nachträglich, nur im "
                    "eigenen Web-Player (nicht in Stremio, ARVIO, Jacktook).",
         "werte": [["vorab", "Vorab prüfen"], ["hintergrund", "Im Hintergrund prüfen (\"Smart Play\")"]]},
        {"key": "usenet_healthcheck_stichproben", "typ": "wahl", "titel": "Stichproben je NZB", "standard": "6",
         "werte": [["2", "2"], ["4", "4"], ["6", "6"], ["10", "10"], ["20", "20"]]},
    ]},
    {"id": "p2p_torrent", "name": "P2P-Torrent", "symbol": "🧲", "gruppe": "Verbindungen & Geräte",
     "beschreibung": "Magnet-Links/infoHash über ein selbst betriebenes aria2c (--enable-rpc) laden – lädt "
                     "vollständig lokal herunter und spielt danach ab, kein Streaming während des Ladens "
                     "(aria2 unterstützt bei BitTorrent kein zuverlässiges sequenzielles Laden). Alternative "
                     "ohne eigenen Torrent-Client: „Über Debrid“ bei den Streams.",
     "zeilen": [
        {"key": "p2p_torrent_an", "typ": "schalter", "titel": "P2P-Torrent aktivieren", "standard": False,
         "hinweis": "Braucht ein selbst laufendes aria2c mit --enable-rpc; H0rSt startet es nicht selbst."},
        {"key": "p2p_aria2_adresse", "typ": "text", "titel": "aria2c-RPC-Adresse",
         "standard": "http://127.0.0.1:6800/jsonrpc"},
        {"key": "p2p_aria2_geheim", "typ": "text", "titel": "aria2c-RPC-Geheimnis", "standard": "",
         "hinweis": "Nur nötig, wenn aria2c mit --rpc-secret gestartet wurde."},
    ]},
    {"id": "usenet", "name": "Usenet-Streaming", "symbol": "⚡", "gruppe": "Verbindungen & Geräte",
     "beschreibung": "Usenet-Filme und -Serien direkt in Stremio abspielen, ohne sie erst herunterzuladen: H0rSt sucht bei deinen "
                     "Indexern, bindet die gewählte NZB in NzbDAV oder AltMount ein und reicht die Datei per WebDAV mit "
                     "Range-Anfragen durch. Vorbild: UsenetStreamer. Was noch fehlt, zeigt der Reiter „Usenet-Stream“.",
     "zeilen": [
        {"key": "usenet_modus_an", "typ": "schalter", "titel": "Streaming-Modus", "standard": False,
         "hinweis": "Ordnet und filtert die Usenet-Treffer vor Stremio, markiert fertig eingebundene Releases mit ⚡, "
                    "bietet „Usenet Auto“ an und sucht bei leerem Ergebnis mit anderer Kennung weiter. Ab Werk aus: "
                    "dann bleibt alles wie bisher (je ein NzbDAV-Stream je Treffer)."},
        {"key": "usenet_sortierung", "typ": "wahl", "titel": "Reihenfolge", "standard": "qualitaet", "wenn": "usenet_modus_an",
         "hinweis": "Schon fertig eingebundene Releases (⚡) stehen immer vorn.",
         "werte": [["qualitaet", "Beste Qualität zuerst (Auflösung, Quelle, Größe)"], ["groesse", "Größte Datei zuerst"],
                   ["klein", "Kleinste Datei zuerst (spart Daten)"], ["neu", "Neueste zuerst"]]},
        {"key": "usenet_min_aufloesung", "typ": "wahl", "titel": "Mindestauflösung", "standard": "0", "wenn": "usenet_modus_an",
         "hinweis": "Releases ohne erkennbare Auflösung fallen weg, sobald hier etwas gewählt ist.",
         "werte": [["0", "egal"], ["720", "ab 720p"], ["1080", "ab 1080p"], ["2160", "nur 4K"]]},
        {"key": "usenet_max_aufloesung", "typ": "wahl", "titel": "Höchstauflösung", "standard": "0", "wenn": "usenet_modus_an",
         "hinweis": "Sinnvoll auf dem Handy oder bei schwacher Leitung: 4K gar nicht erst anbieten.",
         "werte": [["0", "egal"], ["720", "bis 720p"], ["1080", "bis 1080p"]]},
        {"key": "usenet_max_gb", "typ": "wahl", "titel": "Größtes Release", "standard": "0", "wenn": "usenet_modus_an",
         "hinweis": "Größere Releases werden nicht angeboten.",
         "werte": [["0", "unbegrenzt"]] + [[str(n), "bis %d GB" % n] for n in (5, 10, 15, 20, 30, 50, 80)]},
        {"key": "usenet_je_aufloesung", "typ": "wahl", "titel": "Höchstens je Auflösung", "standard": "0", "wenn": "usenet_modus_an",
         "hinweis": "Hält die Liste kurz: von jeder Auflösung nur die besten Treffer.",
         "werte": [["0", "alle"]] + [[str(n), str(n)] for n in (1, 2, 3, 4, 5, 8)]},
        {"key": "usenet_ausschluss", "typ": "text", "titel": "Ausschließen", "standard": "", "wenn": "usenet_modus_an",
         "platzhalter": "z. B. cam, hdcam, telesync, 3d",
         "hinweis": "Wörter im Release-Namen, durch Komma getrennt. Kurze Wörter müssen als ganzes Wort vorkommen."},
        {"key": "usenet_deutsch", "typ": "wahl", "titel": "Deutsch-Wertung", "standard": "aus", "wenn": "usenet_modus_an",
         "hinweis": "Nach dem Punkteschema des Usenet-Kompass (German DL 1500, German 1000, German Forced 200): Releases mit "
                    "deutscher Tonspur stehen vor dem Original, Kinomitschnitte (CAM, TS, Line Dubbed) fallen weg. "
                    "„Nur Deutsch“ blendet alles ohne deutsche Kennung aus. Gelesen wird der Release-Name, nicht die Datei.",
         "werte": [["aus", "Aus"], ["bevorzugen", "Deutsch bevorzugen"], ["nur", "Nur Deutsch"]]},
        {"key": "usenet_dedupe", "typ": "schalter", "titel": "Doppelte zusammenfassen", "standard": True, "wenn": "usenet_modus_an",
         "hinweis": "Gleicher Release-Name bei mehreren Indexern: nur der erste (beste) bleibt."},
        {"key": "usenet_sofort", "typ": "schalter", "titel": "⚡ Sofort-Streams erkennen", "standard": True, "wenn": "usenet_modus_an",
         "hinweis": "Fragt NzbDAV/AltMount (WebDAV, höchstens einmal pro Minute), welche Releases schon eingebunden sind. "
                    "Diese starten ohne Wartezeit und stehen ganz oben."},
        {"key": "usenet_auto_an", "typ": "schalter", "titel": "„Usenet Auto“-Stream", "standard": True, "wenn": "usenet_modus_an",
         "hinweis": "Ein zusätzlicher Stream ganz oben: probiert die besten Releases nacheinander (jeweils bis 45 s), "
                    "bis eines startet. Vorbild: Smart Play / Auto-Advance bei UsenetStreamer."},
        {"key": "usenet_auto_anzahl", "typ": "wahl", "titel": "Versuche bei „Usenet Auto“", "standard": "4",
         "wenn": "usenet_auto_an", "hinweis": "Wie viele Releases höchstens nacheinander probiert werden.",
         "werte": [[str(n), str(n)] for n in range(2, 9)]},
        {"key": "usenet_ersatzsuche", "typ": "schalter", "titel": "Ersatzsuche bei Newznab", "standard": True, "wenn": "usenet_modus_an",
         "hinweis": "Bringt die Suche mit IMDb-Kennung nichts, sucht H0rSt noch einmal nach „Titel Jahr“ "
                    "(Serien: Kennung mit Staffel/Folge, dann „Titel S01E02“). Höchstens drei Anfragen je Indexer."},
        {"key": "usenet_basis_url", "typ": "text", "titel": "Eigene HTTPS-Adresse", "standard": "", "wenn": "usenet_modus_an",
         "platzhalter": "z. B. https://name.duckdns.org",
         "hinweis": "Nur nötig, wenn Stremio von außerhalb zugreift: unter dieser Adresse (HTTPS, mit Caddy oder nginx davor) "
                    "erreichen Stremio und Player die Streams. Leer: H0rSt nimmt die Adresse der Anfrage."},
    ]},
    {"id": "tv", "name": "TV", "symbol": "📺", "gruppe": "Verbindungen & Geräte", "verweis": "livetv",
     "text": "Senderlisten, kostenlose Sender, eigene M3U-Listen, Xtream und EPG."},
    {"id": "heimserver", "name": "Heimserver", "symbol": "⌂", "gruppe": "Verbindungen & Geräte", "verweis": "heim",
     "text": "ASUS AiCloud, Nextcloud, Synology und andere WebDAV-Speicher, dazu Heim-Links."},
    {"id": "sicherheit", "name": "Sicherheit", "symbol": "🛡", "gruppe": "Profile & Zugriff", "verweis": "sicherheit",
      "text": "VPN (WireGuard), Tor (Orbot), I2P (i2pd, MuWire, I2PChat, OnionCat), IP-Filter, afwall (Netz-Freigaben je App), Proxy, Notbremse und Private DNS."},
    {"id": "lesezeichen18", "name": "Ab 18 · Lesezeichen", "symbol": "🔖", "gruppe": "Profile & Zugriff", "eigen": True,
     "beschreibung": "Eigene Adressen für Erwachsene – nur eine Liste, ab Werk aus, mit Eltern-PIN, für Kinderprofile unsichtbar."},
    {"id": "aktualisierung", "name": "Aktualisierung", "symbol": "⟳", "gruppe": "System & Pflege", "eigen": True,
     "beschreibung": "H0rSt holt neue Versionen selbst aus GitHub – auf Wunsch automatisch."},
    {"id": "fehler", "name": "Fehlerliste", "symbol": "🐞", "gruppe": "System & Pflege", "eigen": True,
     "beschreibung": "Alle Fehler von Server und Oberfläche gesammelt – als Datei exportieren oder kopieren und zum Beheben einspeisen."},
    {"id": "daten", "name": "Datenschutz & Daten", "symbol": "⛁", "gruppe": "System & Pflege", "eigen": True,
     "beschreibung": "Alles in einer Datei sichern und auf einem anderen Gerät wiederherstellen."},
    {"id": "speicher", "name": "Speicher & Aufräumen", "symbol": "🧹", "gruppe": "System & Pflege", "eigen": True,
     "beschreibung": "Was H0rSt auf dem Gerät belegt, wie oft und wie lange du die Module nutzt – und was weg kann, um Platz zu schaffen."},
    {"id": "uniqx", "name": "UNiQuanteX", "symbol": "✦", "gruppe": "KI, Automatisierung & Backup", "eigen": True,
     "beschreibung": "Visuellen Stil einer App analysieren und als body.stil-<key> in H0rSt einbinden. KI-Anbieter stehen unter „KI & Werkzeuge“."},
    {"id": "ki", "name": "KI & Werkzeuge", "symbol": "🤖", "gruppe": "KI, Automatisierung & Backup", "eigen": True,
     "beschreibung": "KI-Anbieter für UNiQuanteX (Claude, OpenAI-kompatibel, Ollama, eigener Server) und das KI-Diff-Werkzeug "
                     "für Review und Merge-Konflikte."},
    {"id": "brille", "name": "Brille", "symbol": "🥽", "gruppe": "Verbindungen & Geräte", "eigen": True,
     "beschreibung": "HeyCyan-kompatible Smart Glasses: Modelle und Endpunkte."},
    {"id": "komplettbackup", "name": "Komplett-Backup", "symbol": "💾", "gruppe": "KI, Automatisierung & Backup", "eigen": True,
     "beschreibung": "Alle Ordner und Daten im Datenordner, einzeln wählbar, nach lokal und/oder Google Drive. "
                     "Anders als die Komplettsicherung (Einstellungen → Aktualisierung), die nur die Nutzerdaten "
                     "(eine Datei) sichert."},
    {"id": "nuvio_plugins", "name": "Nuvio-Plugins", "symbol": "🧩", "gruppe": "KI, Automatisierung & Backup", "eigen": True,
     "beschreibung": "⚠ Alpha/experimentell: admin-eigene JS-Plugins (getStreams()) mit eigenem Netzzugriff, "
                     "liefern zusätzliche Streams für Filme/Serien. Ab Werk aus."},
    {"id": "geraete_abgleich", "name": "Geräte-Abgleich", "symbol": "🔄", "gruppe": "KI, Automatisierung & Backup", "eigen": True,
     "beschreibung": "Profile, Merkliste/Verlauf/Weiterschauen, eigene Anbieter und Einstellungen mit einer "
                     "anderen, unabhängigen H0rSt-Installation abgleichen (z. B. PC-Server zu Hause und die "
                     "App mit eigenem Server unterwegs) – über einen eigenen Google-Drive-Ordner."},
    {"id": "ueber", "name": "Über", "symbol": "ⓘ", "gruppe": "System & Pflege", "eigen": True, "beschreibung": "Version und verwendete Quellen."},
]

# MagicWX gehoert zu KI & Werkzeuge, direkt hinter die KI-Anbieter.
KATEGORIEN.insert(next(i for i, k in enumerate(KATEGORIEN) if k["id"] == "ki") + 1, MAGICWX_KATEGORIE)
KATEGORIEN.insert(next(i for i, k in enumerate(KATEGORIEN) if k["id"] == "magicwx") + 1, BILDDATENSATZ_KATEGORIE)
KATEGORIEN.insert(next(i for i, k in enumerate(KATEGORIEN) if k["id"] == "bilddatensatz") + 1, MTMANAGER_KATEGORIE)
KATEGORIEN.insert(next(i for i, k in enumerate(KATEGORIEN) if k["id"] == "mtmanager") + 1, QWEN_POSE_KATEGORIE)
KATEGORIEN.insert(next(i for i, k in enumerate(KATEGORIEN) if k["id"] == "qwen_pose") + 1, VIDEOWERKSTATT_KATEGORIE)
KATEGORIEN.insert(next(i for i, k in enumerate(KATEGORIEN) if k["id"] == "mtmanager") + 1, SHIZUKU_KATEGORIE)
KATEGORIEN.insert(next(i for i, k in enumerate(KATEGORIEN) if k["id"] == "shizuku") + 1, KEEPADB_KATEGORIE)
# Ember-P2P und eMule eSE LiveTV gehoeren zu Verbindungen & Geraete, direkt hinter den TV-Verweis.
KATEGORIEN.insert(next(i for i, k in enumerate(KATEGORIEN) if k["id"] == "tv") + 1, EMBERP2P_KATEGORIE)
KATEGORIEN.insert(next(i for i, k in enumerate(KATEGORIEN) if k["id"] == "emberp2p") + 1, EMULEESE_KATEGORIE)
KATEGORIEN.insert(next(i for i, k in enumerate(KATEGORIEN) if k["id"] == "emuleese") + 1, ED2KNETZ_KATEGORIE)
KATEGORIEN.insert(next(i for i, k in enumerate(KATEGORIEN) if k["id"] == "ed2knetz") + 1, IPTVQUELLEN_KATEGORIE)
KATEGORIEN.insert(next(i for i, k in enumerate(KATEGORIEN) if k["id"] == "addons") + 1, AIOSTREAMS_KATEGORIE)
KATEGORIEN.insert(next(i for i, k in enumerate(KATEGORIEN) if k["id"] == "iptvquellen") + 1, LBRY_KATEGORIE)
KATEGORIEN.insert(next(i for i, k in enumerate(KATEGORIEN) if k["id"] == "lbry") + 1, IPVPN_KATEGORIE)
KATEGORIEN.insert(next(i for i, k in enumerate(KATEGORIEN) if k["id"] == "ipvpn") + 1, DISCORD_KATEGORIE)
# Nuvio Mobile ist der Client zum Modul-Host: Schalter und feste Server-Adresse.
KATEGORIEN.insert(next(i for i, k in enumerate(KATEGORIEN) if k["id"] == "emberp2p") + 1, NUVIO_KATEGORIE)
