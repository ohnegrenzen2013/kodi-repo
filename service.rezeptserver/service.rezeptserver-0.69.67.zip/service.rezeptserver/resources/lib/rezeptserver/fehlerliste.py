"""Fehlerliste: alle Fehler an einer Stelle, zum Exportieren und Einspeisen (Chat mit Claude, Issue, anderes Geraet).

Quellen:
  * Server: jede Meldung ab WARNING im Log "rezeptserver", Ausnahmen mit Traceback (auch die 500er jeder Anfrage).
  * Oberflaeche: JavaScript-Fehler, abgelehnte Promises, API-Aufrufe mit 5xx oder ohne Antwort und jede
    sichtbare Fehlermeldung (POST /api/fehler/melden).

Gleiche Fehler (gleiche Quelle, Art, Ort und Text bis auf Zahlen) werden ein Eintrag mit Anzahl, erstem und letztem
Auftreten. Zugangsdaten werden vor dem Speichern geschwaerzt (Token, Passwoerter, Schluessel in Adressen).

Export: Markdown (zum Einspeisen, mit Version und Plattform), JSON (wieder einlesbar, auch auf einem anderen Geraet)
oder Text. Datei: <Datenordner>/fehler.json {"eintraege": [...]}
"""

import hashlib
import json
import logging
import os
import platform
import re
import sys
import threading
import time
import traceback

from . import __version__

DATEI = "fehler.json"
MAX_EINTRAEGE = 300
MAX_TEXT = 600
MAX_DETAILS = 8000
MAX_JE_MELDUNG = 25
QUELLEN = ("server", "oberflaeche", "app", "import")
_SPEICHERN_ALLE = 3.0

_MUSTER = [
    (re.compile(r"github_pat_\w{20,}|gh[pousr]_[A-Za-z0-9]{20,}"), "***"),
    (re.compile(r"\b\d{6,12}:[\w-]{30,}\b"), "***"),  # Telegram-Bot-Token
    (re.compile(r"(?i)\b(bearer|basic)\s+[\w.~+/=-]{8,}"), r"\1 ***"),
    (re.compile(r"(?i)([?&;\s\"'](?:token|apikey|api_key|key|passwort|password|pass|pwd|sitzung|secret|auth|sid)=)[^&\s\"']+"), r"\1***"),
    (re.compile(r"(?i)(\"(?:token|apikey|api_key|passwort|password|pass|secret|pin)\"\s*:\s*\")[^\"]*"), r"\1***"),
    (re.compile(r"(//)[^/\s:@]+:[^/\s@]+@"), r"\1***@"),  # Zugang in der Adresse
]


class FehlerlisteFehler(ValueError):
    pass


def _gruppentext(text):
    """Gleicher Fehler trotz anderer Pfade und Zahlen: die Adresse zählt nur mit dem Host."""
    text = re.sub(r"https?://([^/\s?#]+)\S*", r"https://\1/…", text)
    return re.sub(r"\d+", "#", text)


def _zeit(t):
    return time.strftime("%Y-%m-%d %H:%M:%S", time.localtime(t))


def _plattform():
    if os.environ.get("ANDROID_ROOT") or hasattr(sys, "getandroidapilevel"):
        return "Android"
    return platform.system() or sys.platform


class Fehlerliste:

    def __init__(self, ordner=None, uhr=time.time):
        self.ordner = ordner
        self.uhr = uhr
        self.geheim = set()
        self._sperre = threading.Lock()
        self._eintraege = {}
        self._gespeichert = 0.0
        self._offen = False
        self._laden()

    # --- Grundlagen -----------------------------------------------------------------------------------
    def _pfad(self):
        return os.path.join(self.ordner, DATEI) if self.ordner else None

    def _laden(self):
        pfad = self._pfad()
        if not pfad or not os.path.exists(pfad):
            return
        try:
            with open(pfad, encoding="utf-8") as f:
                for e in (json.load(f) or {}).get("eintraege", [])[-MAX_EINTRAEGE:]:
                    if isinstance(e, dict) and e.get("id"):
                        self._eintraege[e["id"]] = e
        except (OSError, ValueError, AttributeError):
            pass

    def _speichern(self, sofort=False):
        """Unter der Sperre aufrufen. Schreibt hoechstens alle paar Sekunden, sonst beim naechsten Lesen."""
        pfad = self._pfad()
        if not pfad:
            return
        self._offen = True
        if not sofort and self.uhr() - self._gespeichert < _SPEICHERN_ALLE:
            return
        try:
            os.makedirs(self.ordner, exist_ok=True)
            neu = pfad + ".neu"
            with open(neu, "w", encoding="utf-8") as f:
                json.dump({"eintraege": list(self._eintraege.values())}, f, ensure_ascii=False)
            os.replace(neu, pfad)
            self._gespeichert, self._offen = self.uhr(), False
        except OSError:
            pass

    def schwaerzen(self, text):
        text = str(text or "")
        for g in self.geheim:
            if g and len(g) >= 6:
                text = text.replace(g, "***")
        for muster, ersatz in _MUSTER:
            text = muster.sub(ersatz, text)
        return text

    # --- Sammeln --------------------------------------------------------------------------------------
    def hinzu(self, quelle, art, text, ort="", details="", bereich="", geraet="", anzahl=1, zeit=None):
        quelle = quelle if quelle in QUELLEN else "oberflaeche"
        art = re.sub(r"[^\w./ -]", "", str(art or "fehler"))[:40] or "fehler"
        text = self.schwaerzen(" ".join(str(text or "").split()))[:MAX_TEXT]
        if not text:
            return None
        ort = self.schwaerzen(str(ort or ""))[:200]
        details = self.schwaerzen(str(details or "")).strip()[:MAX_DETAILS]
        bereich = re.sub(r"[^\w-]", "", str(bereich or ""))[:30]
        geraet = self.schwaerzen(" ".join(str(geraet or "").split()))[:120]
        schluessel = "|".join((quelle, art, ort, _gruppentext(text)))
        eid = hashlib.sha1(schluessel.encode("utf-8")).hexdigest()[:12]
        jetzt = float(zeit or self.uhr())
        anzahl = max(1, min(int(anzahl or 1), 10 ** 6))
        with self._sperre:
            e = self._eintraege.pop(eid, None)  # neu einsortieren: zuletzt Aufgetretenes steht hinten
            if e:
                e.update(anzahl=e["anzahl"] + anzahl, zuletzt=max(e["zuletzt"], jetzt), erst=min(e["erst"], jetzt), text=text,
                         version=__version__)
                if details:
                    e["details"] = details
                if bereich:
                    e["bereich"] = bereich
                if geraet:
                    e["geraet"] = geraet
            else:
                e = {"id": eid, "quelle": quelle, "art": art, "text": text, "ort": ort, "details": details, "bereich": bereich,
                     "geraet": geraet, "anzahl": anzahl, "erst": jetzt, "zuletzt": jetzt, "version": __version__}
            self._eintraege[eid] = e
            while len(self._eintraege) > MAX_EINTRAEGE:
                self._eintraege.pop(next(iter(self._eintraege)))
            self._speichern()
        return eid

    def melden(self, roh, geraet=""):
        """Meldungen der Oberflaeche: {"eintraege": [{art, text, ort, details, bereich}]}."""
        if not isinstance(roh, dict) or not isinstance(roh.get("eintraege"), list):
            raise FehlerlisteFehler("{\"eintraege\": [...]} erwartet")
        ids = []
        for e in roh["eintraege"][:MAX_JE_MELDUNG]:
            if isinstance(e, dict):
                quelle = e.get("quelle") if e.get("quelle") in ("oberflaeche", "app") else "oberflaeche"
                eid = self.hinzu(quelle, e.get("art"), e.get("text"), e.get("ort"), e.get("details"), e.get("bereich"), geraet)
                if eid:
                    ids.append(eid)
        return {"ok": True, "ids": ids}

    def einlesen(self, roh):
        """Export (JSON) eines anderen Geraets oder von frueher dazunehmen; Anzahl und Zeiten bleiben."""
        if isinstance(roh, list):
            roh = {"eintraege": roh}
        if not isinstance(roh, dict) or not isinstance(roh.get("eintraege"), list):
            raise FehlerlisteFehler("Keine Fehlerliste (JSON-Export von H0rSt erwartet)")
        neu = 0
        for e in roh["eintraege"][:MAX_EINTRAEGE]:
            if not isinstance(e, dict):
                continue
            try:
                anzahl, zeit = int(e.get("anzahl") or 1), float(e.get("zuletzt") or 0) or None
            except (TypeError, ValueError):
                anzahl, zeit = 1, None
            quelle = e.get("quelle") if e.get("quelle") in QUELLEN else "import"
            if self.hinzu(quelle, e.get("art"), e.get("text"), e.get("ort"), e.get("details"), e.get("bereich"),
                          e.get("geraet"), anzahl, zeit):
                neu += 1
        return {"ok": True, "eingelesen": neu}

    def leeren(self, ids=None):
        with self._sperre:
            if ids:
                for i in ids:
                    self._eintraege.pop(str(i), None)
            else:
                self._eintraege.clear()
            self._speichern(sofort=True)
            return {"ok": True, "anzahl": len(self._eintraege)}

    # --- Lesen und Export -----------------------------------------------------------------------------
    def liste(self):
        with self._sperre:
            if self._offen:
                self._speichern(sofort=True)
            eintraege = sorted((dict(e) for e in self._eintraege.values()), key=lambda e: -e["zuletzt"])
        return {"eintraege": eintraege, "anzahl": len(eintraege), "meldungen": sum(e["anzahl"] for e in eintraege),
                "version": __version__, "plattform": _plattform()}

    def export(self, format_="md", ids=None):
        """(Inhaltstyp, Text, Dateiname) – md zum Einspeisen, json zum Wiedereinlesen, txt schlicht."""
        d = self.liste()
        eintraege = [e for e in d["eintraege"] if not ids or e["id"] in ids]
        stempel = time.strftime("%Y-%m-%d-%H%M", time.localtime(self.uhr()))
        if format_ == "json":
            daten = {"h0rst": __version__, "plattform": d["plattform"], "exportiert": int(self.uhr()), "eintraege": eintraege}
            return "application/json", json.dumps(daten, ensure_ascii=False, indent=1), "h0rst-fehler-%s.json" % stempel
        if format_ == "txt":
            zeilen = ["H0rSt %s (%s) - %d Fehler" % (__version__, d["plattform"], len(eintraege)), ""]
            for e in eintraege:
                zeilen.append("[%s] %s %s/%s %dx: %s%s" % (_zeit(e["zuletzt"]), e["quelle"], e["art"], e.get("bereich") or "-", e["anzahl"],
                                                         e["text"], (" @ " + e["ort"]) if e.get("ort") else ""))
            return "text/plain", "\n".join(zeilen) + "\n", "h0rst-fehler-%s.txt" % stempel
        teile = ["# H0rSt – Fehlerliste", "",
                 "H0rSt %s · %s · Python %s · exportiert %s" % (__version__, d["plattform"], platform.python_version(), _zeit(self.uhr())),
                 "%d Fehler, zusammen %d-mal aufgetreten. Neueste zuerst. Zugangsdaten sind geschwärzt." % (
                     len(eintraege), sum(e["anzahl"] for e in eintraege)), ""]
        for n, e in enumerate(eintraege, 1):
            teile.append("## %d. %s · %s – %s" % (n, e["quelle"], e["art"], e["text"][:140]))
            teile.append("")
            info = ["**%d×**" % e["anzahl"], "zuerst %s" % _zeit(e["erst"]), "zuletzt %s" % _zeit(e["zuletzt"])]
            if e.get("version"):
                info.append("Version %s" % e["version"])
            teile.append("- " + " · ".join(info))
            if e.get("ort"):
                teile.append("- Ort: `%s`" % e["ort"])
            if e.get("bereich"):
                teile.append("- Bereich: %s" % e["bereich"])
            if e.get("geraet"):
                teile.append("- Gerät: %s" % e["geraet"])
            if len(e["text"]) > 140:
                teile += ["", e["text"]]
            if e.get("details"):
                teile += ["", "```", e["details"].replace("```", "'''"), "```"]
            teile.append("")
        return "text/markdown", "\n".join(teile), "h0rst-fehler-%s.md" % stempel


# --- Log-Sammler: haengt am Logger "rezeptserver", schreibt in die zuletzt eingerichtete Liste -------------
_ziel = None


class _LogSammler(logging.Handler):

    def emit(self, record):
        liste = _ziel
        if liste is None or record.name.startswith("rezeptserver.fehlerliste"):
            return
        try:
            details = "".join(traceback.format_exception(*record.exc_info)) if record.exc_info else ""
            pfad = record.pathname or ""
            i = pfad.rfind("rezeptserver" + os.sep)
            ort = "%s:%d" % (pfad[i:] if i >= 0 else os.path.basename(pfad), record.lineno)
            liste.hinzu("server", record.levelname.lower(), record.getMessage(), ort, details)
        except Exception:  # Der Sammler darf das Loggen nie stoeren
            pass


_sammler = _LogSammler(logging.WARNING)


def einrichten(liste, *geheim):
    """Server-Fehler ab jetzt in diese Liste sammeln (eine Liste je Prozess; die zuletzt eingerichtete gilt)."""
    global _ziel
    liste.geheim.update(g for g in geheim if g)
    _ziel = liste
    log = logging.getLogger("rezeptserver")
    if _sammler not in log.handlers:
        log.addHandler(_sammler)
    return liste
