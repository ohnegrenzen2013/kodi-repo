"""Netzwerkzugriff mit Berechtigungspruefung.

Module kommen nur ueber einen Abrufer ins Netz. Der Abrufer laesst nur
Domains aus `darf.netz` des jeweiligen Moduls zu, auch bei Weiterleitungen.
"""

import base64
import errno
import http.client
import ipaddress
import socket
import threading
import urllib.error
import urllib.request
from urllib.parse import urljoin, urlsplit

from . import __version__

USER_AGENT = "Rezeptserver/" + __version__
_kopf_ablage = threading.local()


def koepfe_merken(werte):
    """Letzte Antwort-Kopfzeilen dieses Threads (Mhub-Config-Set)."""
    _kopf_ablage.werte = {str(k): str(v) for k, v in (werte or {}).items()}


def letzte_koepfe():
    return dict(getattr(_kopf_ablage, "werte", {}) or {})


MAX_BYTES = 5 * 1024 * 1024
MAX_WEITERLEITUNGEN = 5

# Netze, die nie Ziel eines oeffentlichen Abrufs sind. Zusaetzlich zu den
# Eigenschaften von ipaddress, weil Python 3.8 CGNAT, Multicast und Teile von
# 0.0.0.0/8 nicht zuverlaessig als privat erkennt (IPv4.is_global gibt es erst ab 3.9).
_GESPERRT = tuple(ipaddress.ip_network(n) for n in (
    "0.0.0.0/8", "10.0.0.0/8", "100.64.0.0/10", "127.0.0.0/8",
    "169.254.0.0/16", "172.16.0.0/12", "192.0.0.0/24", "192.0.2.0/24",
    "192.168.0.0/16", "198.18.0.0/15", "198.51.100.0/24", "203.0.113.0/24",
    "224.0.0.0/4", "240.0.0.0/4",
    "::/128", "::1/128", "fc00::/7", "fe80::/10", "fec0::/10", "ff00::/8",
    "2001:db8::/32",
))


class NetzFehler(Exception):
    pass


class NichtErlaubt(NetzFehler):
    pass


class NichtOeffentlich(NichtErlaubt):
    pass


class Weiterleitung(Exception):
    """Die Antwort leitet weiter. Der Abrufer prueft das Ziel, bevor er ihm folgt."""

    def __init__(self, status, ziel):
        super().__init__("HTTP %d nach %s" % (status, ziel))
        self.status = status
        self.ziel = ziel


class _NichtFolgen(urllib.request.HTTPRedirectHandler):
    # urllib wuerde sonst jeder Weiterleitung folgen, samt Authorization-Header an fremde Domains
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        return None


_OEFFNER = urllib.request.build_opener(_NichtFolgen)


def domain_erlaubt(url, erlaubt):
    teile = urlsplit(url)
    if teile.scheme not in ("http", "https"):
        return False
    host = (teile.hostname or "").lower()
    for domain in erlaubt:
        domain = domain.lower().lstrip(".")
        if host == domain or host.endswith("." + domain):
            return True
    return False


def gesperrt(ip):
    """True fuer Loopback, Link-Local, CGNAT, Multicast, Dokumentation und alles Private."""
    if ip.version == 6 and getattr(ip, "ipv4_mapped", None) is not None:
        return gesperrt(ip.ipv4_mapped)
    if any(ip in netz for netz in _GESPERRT):
        return True
    return bool(ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved
                or ip.is_multicast or ip.is_unspecified)


def ips_von(host):
    """Alle Adressen eines Hosts. Literale ohne DNS. Ist gethostbyname ein Mock (Tests), nur den.

    Sonst getaddrinfo fuer A und AAAA. Eine einzige gesperrte Adresse reicht spaeter zum Ablehnen."""
    host = (host or "").strip().strip("[]")
    if not host:
        raise NichtOeffentlich("Host nicht aufloesbar: %r" % host)
    try:
        return [ipaddress.ip_address(host)]
    except ValueError:
        pass
    # Tests patchen socket.gethostbyname. Ein Mock darf nicht von der echten Aufloesung ueberholt werden.
    if type(socket.gethostbyname).__name__ != "builtin_function_or_method":
        try:
            return [ipaddress.ip_address(socket.gethostbyname(host))]
        except (socket.gaierror, OSError, ValueError):
            raise NichtOeffentlich("Host nicht aufloesbar: %r" % host)
    try:
        infos = socket.getaddrinfo(host, None, socket.AF_UNSPEC, socket.SOCK_STREAM)
    except socket.gaierror:
        raise NichtOeffentlich("Host nicht aufloesbar: %r" % host)
    ips, gesehen = [], set()
    for info in infos:
        roh = str(info[4][0]).split("%", 1)[0]
        try:
            ip = ipaddress.ip_address(roh)
        except ValueError:
            continue
        if ip not in gesehen:
            gesehen.add(ip)
            ips.append(ip)
    if not ips:
        raise NichtOeffentlich("Host nicht aufloesbar: %r" % host)
    return ips


def gepruefte_ips(url):
    """Adressen von url, wenn jede davon global erreichbar ist. Sonst NichtOeffentlich."""
    teile = urlsplit(url)
    if teile.scheme not in ("http", "https"):
        raise NichtOeffentlich("Nur http/https erlaubt.")
    ips = ips_von(teile.hostname or "")
    if any(gesperrt(ip) for ip in ips):
        raise NichtOeffentlich("Private/interne Adressen sind nicht erlaubt.")
    return ips


def ip_oeffentlich_pruefen(url):
    """Blockt private/loopback-Adressen (SSRF-Schutz), fuer Adressen, die der Nutzer selbst eintraegt."""
    gepruefte_ips(url)


def _pin_klassen(pin):
    """HTTP(S)-Verbindungen, die pin waehlen statt den Hostnamen noch einmal aufzuloesen."""

    def _sock(self):
        self.sock = socket.create_connection((pin, self.port), self.timeout, self.source_address)
        try:
            self.sock.setsockopt(socket.IPPROTO_TCP, socket.TCP_NODELAY, 1)
        except OSError as fehler:
            if getattr(fehler, "errno", None) != errno.ENOPROTOOPT:
                raise
        if self._tunnel_host:
            self._tunnel()

    class PinHTTP(http.client.HTTPConnection):
        def connect(self):
            _sock(self)

    class PinHTTPS(http.client.HTTPSConnection):
        def connect(self):
            _sock(self)
            name = self._tunnel_host or self.host
            self.sock = self._context.wrap_socket(self.sock, server_hostname=name)

    return PinHTTP, PinHTTPS


def _pin_opener(pin):
    klasse_http, klasse_https = _pin_klassen(str(pin))

    class HandlerHTTP(urllib.request.HTTPHandler):
        def http_open(self, req):
            return self.do_open(klasse_http, req)

    class HandlerHTTPS(urllib.request.HTTPSHandler):
        def https_open(self, req):
            # HTTPSHandler kennt kein _check_hostname; die Pruefung steckt im Kontext.
            return self.do_open(klasse_https, req, context=self._context)

    # kein Proxy: der wuerde den Namen erneut aufloesen und die Bindung an pin umgehen
    return urllib.request.build_opener(_NichtFolgen, HandlerHTTP, HandlerHTTPS, urllib.request.ProxyHandler({}))


def pin_oeffner(url):
    """Opener, der nur an die erste gepruefte Adresse von url verbindet. Host und TLS-Name bleiben."""
    return _pin_opener(gepruefte_ips(url)[0])


def oeffentlich_oeffnen(anfrage, timeout=20):
    """Wie urlopen, aber an die gepruefte Adresse gebunden."""
    return pin_oeffner(anfrage.full_url).open(anfrage, timeout=timeout)


def urllib_holen(url, methode="GET", header=None, daten=None, zeitgrenze=10.0, ziel_ip=None):
    """Standard-Abruf ueber urllib. Gibt (status, text) zurueck, Weiterleitungen als Ausnahme.

    ziel_ip bindet die Verbindung an diese Adresse; Host-Kopf und TLS-Name bleiben der Hostname."""
    kopf = {"User-Agent": USER_AGENT}
    kopf.update(header or {})
    koerper = daten.encode("utf-8") if isinstance(daten, str) else daten
    anfrage = urllib.request.Request(url, data=koerper, headers=kopf, method=methode)
    oeffner = _pin_opener(ziel_ip) if ziel_ip else _OEFFNER
    try:
        with oeffner.open(anfrage, timeout=zeitgrenze) as antwort:
            inhalt = antwort.read(MAX_BYTES + 1)
            if len(inhalt) > MAX_BYTES:
                raise NetzFehler("Antwort groesser als %d Bytes: %s" % (MAX_BYTES, url))
            koepfe_merken(antwort.headers)
            zeichensatz = antwort.headers.get_content_charset() or "utf-8"
            return antwort.status, inhalt.decode(zeichensatz, errors="replace")
    except urllib.error.HTTPError as fehler:
        roh = b""
        if fehler.code == 428:
            try:
                roh = fehler.read(800)
            except OSError:
                roh = b""
        koepfe_merken(fehler.headers)
        fehler.close()  # haelt sonst die Verbindung offen, bis der Muellsammler kommt
        ziel = fehler.headers.get("Location") if fehler.headers else None
        if fehler.code in (301, 302, 303, 307, 308) and ziel:
            raise Weiterleitung(fehler.code, urljoin(url, ziel))
        extra = (": " + roh.decode("utf-8", "replace")[:200]) if roh else ""
        raise NetzFehler("HTTP %d bei %s%s" % (fehler.code, url, extra))
    except (urllib.error.URLError, OSError) as fehler:
        raise NetzFehler("Abruf fehlgeschlagen (%s): %s" % (fehler, url))


def oeffentlich_holen(holen=None):
    """Huelle um einen holen()-Aufruf, die vor jedem Abruf die Adressen prueft.

    Der eingebaute urllib_holen verbindet danach an genau diese Adresse. Ein fremdes holen
    (Tests) wird nur aufgerufen, wenn keine Adresse gesperrt ist. Abrufer.abruf() ruft holen()
    bei jeder Weiterleitung neu auf, damit ist auch das Weiterleitungsziel geprueft."""
    basis = holen or urllib_holen

    def _holen(url, **kwargs):
        ips = gepruefte_ips(url)
        if basis is urllib_holen:
            kwargs["ziel_ip"] = str(ips[0])
        return basis(url, **kwargs)

    return _holen


def antwort_holen(url, methode="GET", header=None, daten=None, zeitgrenze=20.0, ziel_ip=None):
    """Wie urllib_holen, liefert aber auch bei HTTP-Fehlern (status, text), weil APIs den Grund im
    Fehlertext melden. Folgt keinen Weiterleitungen (3xx kommen als status zurueck)."""
    kopf = {"User-Agent": USER_AGENT}
    kopf.update(header or {})
    koerper = daten.encode("utf-8") if isinstance(daten, str) else daten
    oeffner = _pin_opener(ziel_ip) if ziel_ip else _OEFFNER
    try:
        with oeffner.open(urllib.request.Request(url, data=koerper, headers=kopf, method=methode),
                          timeout=zeitgrenze) as antwort:
            return antwort.status, antwort.read(MAX_BYTES).decode("utf-8", "replace")
    except urllib.error.HTTPError as fehler:
        try:
            return fehler.code, fehler.read(64 * 1024).decode("utf-8", "replace")
        finally:
            fehler.close()
    except (urllib.error.URLError, OSError) as fehler:
        raise NetzFehler("Abruf fehlgeschlagen (%s): %s" % (fehler, urlsplit(url).hostname))


def oeffentlich_antwort_holen(holen=None):
    """Wie oeffentlich_holen, aber auch HTTP-Fehler kommen als (status, text) zurueck."""
    basis = holen or antwort_holen

    def _holen(url, **kwargs):
        ips = gepruefte_ips(url)
        if basis is antwort_holen or basis is urllib_holen:
            kwargs["ziel_ip"] = str(ips[0])
        return basis(url, **kwargs)

    return _holen


def antwort_holen_roh(url, methode="GET", header=None, daten=None, zeitgrenze=20.0, ziel_ip=None,
                      grenze=MAX_BYTES):
    """Wie antwort_holen, aber liefert Bytes (ZIPs, Untertitel, Downloads); hoechstens grenze Bytes."""
    kopf = {"User-Agent": USER_AGENT}
    kopf.update(header or {})
    koerper = daten.encode("utf-8") if isinstance(daten, str) else daten
    oeffner = _pin_opener(ziel_ip) if ziel_ip else _OEFFNER
    try:
        with oeffner.open(urllib.request.Request(url, data=koerper, headers=kopf, method=methode),
                          timeout=zeitgrenze) as antwort:
            return antwort.status, antwort.read(grenze)
    except urllib.error.HTTPError as fehler:
        try:
            return fehler.code, fehler.read(64 * 1024)
        finally:
            fehler.close()
    except (urllib.error.URLError, OSError) as fehler:
        raise NetzFehler("Abruf fehlgeschlagen (%s): %s" % (fehler, urlsplit(url).hostname))


def oeffentlich_antwort_holen_roh(holen=None):
    basis = holen or antwort_holen_roh

    def _holen(url, **kwargs):
        ips = gepruefte_ips(url)
        if basis is antwort_holen_roh:
            kwargs["ziel_ip"] = str(ips[0])
        return basis(url, **kwargs)

    return _holen


class Abrufer:
    """Abrufer fuer genau ein Modul (oder den Host selbst)."""

    def __init__(self, erlaubt=None, holen=urllib_holen, zeitgrenze=10.0):
        self.erlaubt = None if erlaubt is None else list(erlaubt)
        self.holen = holen
        self.zeitgrenze = zeitgrenze

    def abruf(self, url, methode="GET", header=None, daten=None, basic=None):
        if self.erlaubt is not None and not domain_erlaubt(url, self.erlaubt):
            raise NichtErlaubt("Domain nicht in darf.netz: %s" % url)
        header = dict(header or {})
        if basic:
            paar = ("%s:%s" % basic).encode("utf-8")
            header["Authorization"] = "Basic " + base64.b64encode(paar).decode("ascii")
        for _ in range(MAX_WEITERLEITUNGEN + 1):
            try:
                status, text = self.holen(url, methode=methode, header=header, daten=daten,
                                          zeitgrenze=self.zeitgrenze)
                break
            except Weiterleitung as weiter:
                if self.erlaubt is not None and not domain_erlaubt(weiter.ziel, self.erlaubt):
                    raise NichtErlaubt("Weiterleitung ausserhalb von darf.netz: %s -> %s" % (url, weiter.ziel))
                if weiter.status == 303 or (weiter.status in (301, 302) and methode == "POST"):
                    methode, daten = "GET", None
                url = weiter.ziel
        else:
            raise NetzFehler("Zu viele Weiterleitungen: %s" % url)
        if status >= 400:
            raise NetzFehler("HTTP %d bei %s" % (status, url))
        return text
