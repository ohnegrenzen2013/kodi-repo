"""KernMixin-Mixin
"""

import os
from . import beobachtungen as beobachtungen_modul, musik_dienste, szene_infos
from .stremio_grund import (
    Abrufer,
    _DEBRID,
    _LISTE,
    _LOGO,
    _PORTAL,
    _ROUTE,
    _USENET,
    ab18_bereich,
    aktualisierung_modul,
    badges_modul,
    debrid_dienst,
    ed2k_modul,
    ed2k_suche_modul,
    einstellungen_modul,
    entdecken,
    filtern,
    ftp_modul,
    heimlinks,
    heimspeicher_modul,
    hmac,
    kameras_modul,
    livetv,
    markenerkennung_lauf,
    mcp_server,
    oberflaeche,
    p2p_torrent,
    sprachen,
    telegram_modul,
    threading,
    unquote,
    urllib_holen,
    vxparser,
    waechter_modul,
    xdcc_modul,
    xtream,
    youtube_modul,
)
from . import fernsteuerung, mhub_addon
from .stremio_kern_aufgaben import AufgabenMixin, _FeedAbrufer


class KernMixin(AufgabenMixin):
    def __init__(self, kette, token=None, holen=None, wunsch_sprachen=None, filter=None, filter_speichern=None,
                 anbieter_namen=None, livetv_einstellung=None, livetv_speichern=None, datenordner=None, epg_holen=None,
                 links=None, links_speichern=None, epg_sitzung=None, addons=None, usenet_server=None,
                 verwaltung=None, debrid=None, rustnzb=None, dienste=None, ab18=None, badges=None, youtube=None,
                 telegram=None, heimspeicher=None, oberflaeche_werte=None, ftp_einstellung=None, ftp_speichern=None,
                 aktualisierung=None, kameras=None):
        self.kette = kette
        # Bereich "Ab 18": Videoseiten fuer Erwachsene, nur nach Freigabe (/api/ab18/...)
        self.ab18 = ab18 or ab18_bereich.Ab18()
        # eigene Anbieter: fremde Stremio-Addons, Usenet-Server fuer NZB-Streams, Verwaltung fuer /api/anbieter
        self.addons = addons
        self.usenet_server = list(usenet_server or [])
        self.verwaltung = verwaltung
        # Debrid-Dienste schalten Hoster-Links frei (/debrid/...)
        self.debrid = debrid or debrid_dienst.Debrid()
        # rustnzb: NZB-Streams ueber dessen Mediathek in jedem Player (/usenet/...)
        self.rustnzb = rustnzb
        self._usenet = {}
        # Dienste-Zentrale (wie nzb360): {anbieter_id: dienste.Client}
        self.dienste = dict(dienste or {})
        self.token = token or None
        from . import anbieter
        # adult-Hinweis im Manifest: nur wahr, wenn Rezepte der Kategorie ab18 geladen sind (nach Freigabe)
        self._adult = any(anbieter.kategorie_von(m) == anbieter.AB18 for m in getattr(kette, "module", []))
        # gespeicherter Filter: gilt fuer Kataloge, Streams und die Oberflaeche
        self.filter = filtern.pruefe(filter)
        self.filter_speichern = filter_speichern
        self.anbieter_namen = anbieter_namen or {m.konto: m.name for m in getattr(kette, "module", [])}
        # Live-TV: Senderliste und EPG-Weitergabe (/tv.m3u, /epg.xml[.gz])
        self.livetv = livetv.pruefe(livetv_einstellung)
        self.livetv_speichern = livetv_speichern
        self.datenordner = datenordner or "."
        self._epg_holen = epg_holen
        self._epg_sitzung = epg_sitzung
        self.epg = livetv.epg_abholer(self.datenordner, self.livetv, holen=epg_holen, grabber_sitzung=epg_sitzung,
                                      playlist_epg=self._playlist_epg)
        self.adressen = livetv.Adressen(self.datenordner, self.livetv["adressen_quelle"], holen=epg_holen)
        self.adressen.bei_bedarf_erneuern()
        self.logos = livetv.Logos()
        # Heim-Links: Lesezeichen zu Geraeten und Diensten im Netzwerk
        self.links = heimlinks.pruefe(links)
        self.links_speichern = links_speichern
        self.listen = {}
        self._listen_aufbauen()
        self.oberflaeche = oberflaeche.Oberflaeche(self)
        # Waechter: Anbieter und Dienste regelmaessig pruefen (Hintergrund startet dienst.baue)
        self.waechter = waechter_modul.Waechter(verwaltung, self.datenordner)
        # Beobachtungen (Idee autofetch.de): Quellen regelmaessig pruefen, neue Treffer melden/uebergeben; ab Werk aus
        self.beobachtungen = beobachtungen_modul.Beobachtungen(verwaltung, self.datenordner, holen=holen)
        # Release-Infos (xREL, predb.net; ab Werk aus) und Musik (SoundCloud/Mixcloud)
        self.szene = szene_infos.Szene(holen=holen)
        self.musik = musik_dienste.Musik(holen=holen)
        # Stream-Badges wie Nuvio (4K, HDR, Atmos ... an den Streams der Oberflaeche)
        self.badges = badges or badges_modul.Badges({}, self.datenordner)
        # Automatische Intro/Abspann-Erkennung: nur dort, wo eine Datei wirklich auf der Platte liegt
        self.markenerkennung = markenerkennung_lauf.MarkenErkennung(verwaltung, self.datenordner)
        # Usenet-Gesundheitspruefung: NZB-Kandidaten per NNTP-Stichprobe pruefen (usenet_kandidaten_pruefen())
        from . import usenet_triage
        self.usenet_triage = usenet_triage.standard()
        # XDCC: Pakete von IRC-Bots suchen und laden (Tab XDCC)
        self.xdcc = xdcc_modul.Xdcc(self.datenordner, fertig=self._xdcc_fertig)
        # P2P-Torrent (NV4): Magnet/infoHash ueber ein extern laufendes aria2c laden, danach abspielen
        self.p2p_torrent = p2p_torrent.P2pTorrent(self.datenordner, holen=holen)
        # YouTube ohne Werbung: Suche, Abos (RSS), Abspielen, SponsorBlock
        self.youtube = youtube or youtube_modul.Youtube({})
        self.youtube_speichern = youtube_modul.Speichern(self.datenordner)  # Download und REC auf dem Server
        # Ember (eD2K): Links sammeln und an Ember geben, neueste Ember-Version
        self.ember = ed2k_modul.Ember()
        # Telegram als Kommunikationsmodul: Meldungen und Befehle (startet dienst.baue)
        if telegram is None and verwaltung is not None:
            def tg_speichern(neu, v=verwaltung):
                v.abschnitt(telegram_modul.SCHLUESSEL, neu)
            try:
                telegram = telegram_modul.Telegram(verwaltung.daten().get(telegram_modul.SCHLUESSEL), tg_speichern)
            except telegram_modul.TelegramFehler:
                telegram = telegram_modul.Telegram({}, tg_speichern)
        self.telegram = telegram or telegram_modul.Telegram({})
        self.telegram.kontext = self
        # Heimspeicher: ASUS AiCloud und andere WebDAV-Speicher (Bereich Heim)
        try:
            self.heimspeicher = heimspeicher_modul.pruefe(heimspeicher)
        except heimspeicher_modul.SpeicherFehler:
            self.heimspeicher = []
        # IP-Kameras: live, Snaps, Ueberwachung (startet dienst.baue)
        try:
            self.kameras = kameras_modul.pruefe(kameras)
        except kameras_modul.KameraFehler:
            self.kameras = []
        self.snaps = kameras_modul.Snaps(self.datenordner, lambda: self.kameras)
        # Videochat zwischen den eigenen Geraeten (nur Vermittlung, Bild und Ton direkt von Geraet zu Geraet)
        # Fehlerliste: Server- und Oberflaechen-Fehler sammeln, zum Exportieren und Einspeisen (Einstellungen → Fehlerliste)
        from . import fehlerliste as fehlerliste_modul
        self.fehler = fehlerliste_modul.einrichten(fehlerliste_modul.Fehlerliste(datenordner and self.datenordner), self.token)
        from . import videochat as videochat_modul
        self.videochat = videochat_modul.Videochat()
        self.cast_geraete = []  # zuletzt gefundene Fernseher & Geraete (fernseher.py)
        from . import radio as radio_modul
        self.radio = radio_modul.Radio()  # Internetradio (radio-browser.info)
        # LocalDream: Bilder ueber Local Dream oder einen Bildserver, Galerie im Datenordner, Quellen per Adresse
        from . import traum as traum_modul
        self.traum = traum_modul.Traum(self.datenordner, holen=holen or urllib_holen)
        from . import qwen_pose as qwen_pose_modul
        self.qwen_pose = qwen_pose_modul.QwenPose(self.datenordner)
        from . import videowerkstatt as videowerkstatt_modul
        self.videowerkstatt = videowerkstatt_modul.Videowerkstatt(self.datenordner, holen=holen)
        # Einstellungen wie ARVIO (Darstellung, Autoplay, Release-Ausschluss ...), gelten fuer alle Geraete
        self.ui = einstellungen_modul.pruefe(oberflaeche_werte)
        self.https_port = 0           # gesetzt von dienst.baue, wenn HTTPS laeuft
        self.https_fingerabdruck = ""
        # ed2k-Suche ueber eD2K-Server (Treffer gehen als Links an Ember)
        self.ed2k_suche = ed2k_suche_modul.Ed2kSuche(self.datenordner)
        # Kad-Knoten (nodes.dat) fuer eMule/Ember und der IP-Filter fuer P2P (Sicherheit); Einstellungen setzt dienst.baue
        from . import ed2k_listen as ed2k_listen_modul, ipfilter as ipfilter_modul
        self.kadliste = ed2k_listen_modul.Kadliste(self.datenordner)
        self.ipfilter = ipfilter_modul.Verwaltung(self.datenordner)
        # Tor & I2P (Sicherheit): neueste Fassungen der Werkzeuge von GitHub
        from . import anonym as anonym_modul
        self.anonym_releases = anonym_modul.Releases()
        # Party: Daumenkino-Projekte (Datenordner) und Raeume fuer Karaoke und Synchron-Spiel (im Speicher)
        from . import daumenkino as daumenkino_modul, gemeinsam as gemeinsam_modul, party as party_modul
        self.daumenkino = daumenkino_modul.Daumenkino(self.datenordner)
        self.party = party_modul.Party()
        self.gemeinsam = gemeinsam_modul.Gemeinsam(datenordner=self.datenordner)  # Raeume im Speicher, Gutscheine in gutscheine.json
        self.fernsteuerung = fernsteuerung.Fernsteuerung()  # Handy steuert den Fernseher (im Speicher)
        # FTP-Server: Download-Ordner (XDCC, YouTube) und ein eigener Ordner im Heimnetz (startet dienst.baue)
        # Aktualisierung aus GitHub (startet dienst.baue)
        self.aktualisierung = aktualisierung or aktualisierung_modul.Aktualisierung(self.datenordner)
        self.ftp_server = ftp_modul.FtpServer(ftp_einstellung, {"xdcc": self.xdcc.ordner, "youtube": self.youtube_speichern.ordner},
                                              ftp_speichern)
        self.xtream = xtream.Xtream(self)
        self.mcp_server = mcp_server.McpServer(self)  # H0rSt als MCP-Server fuer eine externe KI (Phase 3)
        # Dateibrowser fuer die Downloads und Ablage (auch auf externem Speicher); Einstellung setzt dienst.baue
        from . import dateien as dateien_modul
        self.dateien = dateien_modul.Dateien(self._datei_orte)
        # Nutzung je Profil (Traffic, Anfragen, Verbindungen, Zeit) und Ranglisten der Module und Addons (Admin-Panel)
        from . import nutzung as nutzung_modul
        self.nutzung = nutzung_modul.Nutzung(datenordner)
        for quelle in (kette, addons):
            if quelle is not None and hasattr(quelle, "zaehler"):
                quelle.zaehler = self.nutzung.zaehler
        wunsch = wunsch_sprachen or {}
        self.audio_wunsch = sprachen.als_liste(wunsch.get("audio")) or ["de"]
        self.untertitel_wunsch = sprachen.als_liste(wunsch.get("untertitel")) or ["de"]
        # v3-cinemeta leitet auf cinemeta-live.strem.io weiter, deshalb die ganze Domain
        self._cinemeta = Abrufer(["strem.io"], holen=holen or urllib_holen)
        self._binsearch = Abrufer(["binsearch.info"], holen=holen or urllib_holen)  # /binsearch/api
        # Titelsuche und Entdecken (wie ARVIO) ueber Cinemeta und die Suchkataloge der Addons
        self.entdecken = entdecken.Entdecken(Abrufer(["strem.io"], holen=holen or urllib_holen, zeitgrenze=15.0),
                                             lambda: self.addons)
        # TMDb (Budget/FSK/Provider/Top-10/Jahrzehnte/Franchises) - optional, nur mit eingetragenem Schluessel
        from . import tmdb as tmdb_modul
        self.tmdb = tmdb_modul.Tmdb(Abrufer(["api.themoviedb.org"], holen=holen or urllib_holen, zeitgrenze=15.0))
        # Altersfreigabe fuer Kinderprofile (TMDb-Zertifizierung, Zwischenspeicher im Datenordner; unbekannt = ausgeblendet)
        from . import altersfreigabe as altersfreigabe_modul
        self.altersfreigabe = altersfreigabe_modul.Altersfreigabe(
            self.tmdb, lambda: tmdb_modul.schluessel(self.verwaltung.daten() if self.verwaltung else {}),
            os.path.join(self.datenordner, "altersfreigabe.json"))
        # oEmbed fuer eigene YouTube-Reihen (Titel/Vorschaubild eines Links) und MDBList-Schreibzugriff (Listen)
        self.yt_oembed = Abrufer(["www.youtube.com"], holen=holen or urllib_holen, zeitgrenze=8.0)
        self.mdblist_abrufer = Abrufer(["api.mdblist.com"], holen=holen or urllib_holen, zeitgrenze=15.0)
        # Kataloge (Streaming-Anbieter, Reality, Shows, Konzerte, xREL, eigene Feeds): feste Quellen plus eingetragene Feeds
        from . import kataloge as kataloge_modul
        self.kataloge = kataloge_modul.Kataloge(_FeedAbrufer(holen or urllib_holen), addons=lambda: self.addons,
                                                tmdb_klient=lambda: self.tmdb)
        # Sammlungen (ARVIO 2.2 Collections): eingebaute Reihen, Import per JSON/Adresse, Ordner aus TMDb/Trakt/MDBList/Addons
        from . import sammlungen as sammlungen_modul
        self.sammlungen = sammlungen_modul.Sammlungen(_FeedAbrufer(holen or urllib_holen), self.kataloge,
                                                       self.entdecken, self.tmdb)
        # Eigene Quelle fuer Filme/Serien: eine Webseite eintragen, Titel werden gegen Cinemeta abgeglichen (entdecken)
        from . import eigene_quelle as eigene_quelle_modul
        self.eigene_quellen = eigene_quelle_modul.EigeneQuellen(holen or urllib_holen, self.entdecken)
        # Trakt.tv: Merkliste, Verlauf und Weiterschauen je Profil abgleichen (holen liefert auch bei 4xx den Status)
        from . import trakt as trakt_modul
        self.trakt = trakt_modul.Trakt(lambda: self.verwaltung, holen=holen)
        # SIMKL: Watchlist, Verlauf und Weiterschauen (PIN-Anmeldung wie NuvioTV)
        from . import simkl as simkl_modul
        self.simkl = simkl_modul.Simkl(lambda: self.verwaltung, holen=holen)
        # Nuvio-kompatible getStreams()-Plugins mit eigener Fetch-Bridge (NuvioMobile-Plan NV5-To-Do) -
        # optional, ab Werk aus, braucht einen TMDb-Schluessel fuer die IMDb->TMDb-Aufloesung
        from . import nuvio_plugin as nuvio_plugin_modul
        self.nuvio_plugins = nuvio_plugin_modul.NuvioPlugins(tmdb_klient=lambda: self.tmdb, holen=holen or urllib_holen)
        # AniList, MyAnimeList und Kitsu: Watchlist/Fortschritt aus H0rSt
        from . import anime_tracker as anime_modul
        self.anime_tracker = anime_modul.AnimeTracker(lambda: self.verwaltung, holen=holen)
        # Zusaetzliche Untertitelquellen (SubSource, SubDL, Addic7ed)
        from . import untertitel_quellen as untertitel_modul
        self.untertitel_quellen = untertitel_modul.UntertitelQuellen(self.datenordner, holen=holen)
        # Nativer Downloader (direkte Adressen, Warteschlange, Offline-Dateien)
        from . import download_manager as download_modul
        self.downloads = download_modul.DownloadManager(self.datenordner)
        # CloudStream-Repositories: nur verwalten und .cs3 laden, nicht ausfuehren
        from . import cloudstream_repo as cloudstream_modul
        self.cloudstream = cloudstream_modul.CloudStreamRepos(self.datenordner, holen=holen)
        # IntroDB/AniSkip: automatische Intro-/Abspann-Vorschlaege (nutzt die MAL-Kennungen aus SIMKL)
        from . import skip_segmente as skip_modul
        self.skip_segmente = skip_modul.Segmente(holen=holen, simkl=self.simkl)
        # App-Store (Vyxel-Apps-Plan): Instanz schon hier anlegen, nicht erst beim ersten Oberflaechen-Aufruf -
        # die Hintergrund-Update-Pruefung braucht sie unabhaengig davon, ob je ein Admin die Seite oeffnet
        from . import appstore as appstore_modul
        self.appstore = appstore_modul.AppStore(self.datenordner, lambda: self.verwaltung)
        # Google Drive: Sicherungen nach jeder lokalen Sicherung, Orte taeglich spiegeln, Drive als Speicherort
        from . import gdrive as gdrive_modul
        self.gdrive = gdrive_modul.GDrive(lambda: self.verwaltung)
        gdrive_modul.AKTIV = self.gdrive
        self.aktualisierung.nach_sicherung = self.gdrive.nach_sicherung
        # Komplett-Backup: alle Ordner und Daten (einzeln waehlbar) nach lokal und/oder Google Drive
        from . import komplettbackup as komplettbackup_modul
        self.komplettbackup = komplettbackup_modul.KomplettBackup(lambda: self.verwaltung, gdrive=self.gdrive,
                                                                   datenordner=self.datenordner)

        # Geraete-Abgleich: Profile/Merkliste/Verlauf/Weiterschauen/Anbieter/Einstellungen mit anderen,
        # unabhaengigen H0rSt-Installationen abgleichen (NuvioMobile-Plan NV6), ueber einen eigenen
        # Google-Drive-Ordner (NV6b geraete_sync.py macht den eigentlichen Merge, hier nur der Transport)
        from . import geraete_sync_drive as geraete_sync_drive_modul
        self.geraete_abgleich = geraete_sync_drive_modul.GeraeteAbgleich(lambda: self.verwaltung, gdrive=self.gdrive)
        self.aktualisierung.nebenbei = self._hintergrundaufgaben
        self._cache = {}
        self._sperre = threading.Lock()

    # --- Routing --------------------------------------------------------
    def ohne_token(self, pfad):
        """Pfad ohne Token-Praefix, None bei falschem Token."""
        pfad = pfad.split("?", 1)[0]
        if not self.token:
            return pfad
        praefix = "/%s/" % self.token
        if not hmac.compare_digest(pfad[:len(praefix)].encode("utf-8"), praefix.encode("utf-8")):
            return None
        return pfad[len(praefix) - 1:]

    def ist_stremio(self, pfad):
        """Addon-Pfade (Stremio, mHub) bekommen CORS-Header, die Oberflaeche und /api/ nicht."""
        pfad = self.ohne_token(pfad)
        if pfad is None:
            return False
        pfad = pfad.split("?", 1)[0]
        return pfad == "/manifest.json" or _ROUTE.match(pfad) is not None or \
            (mhub_addon.ist_route(pfad) and pfad not in mhub_addon.SEITEN)

    def ist_privat(self, pfad):
        """Antworten mit dem Stand eines Profils (mHub /playback, Kataloge mit Gesehen-Marken): nie zwischenspeichern."""
        pfad = self.ohne_token(pfad)
        return pfad is not None and mhub_addon.privat(pfad.split("?", 1)[0])

    def bearbeite(self, pfad, methode="GET", koerper=b"", kopf=None):
        """Gibt (status, inhaltstyp, koerper) zurueck."""
        abfrage = pfad.split("?", 1)[1] if "?" in pfad else ""
        roh, pfad = pfad.split("?", 1)[0], self.ohne_token(pfad)
        # Xtream-Pfade auch ohne Token-Praefix, dort meldet das Passwort an
        if xtream.ist_route(roh if pfad is None else pfad):
            return self.xtream.bearbeite(roh if pfad is None else pfad, abfrage, methode, koerper, kopf or {})
        # binsearch als Newznab-Indexer. Mit Token nur ueber den Pfad oder ?apikey=<token>,
        # damit NZBHydra2/Prowlarr/Sonarr ihn eintragen koennen, ohne die Oberflaeche offenzulegen.
        # Ohne Token (Tests, alte Aufrufe von neue_app) bleibt die Schnittstelle offen.
        if (roh if pfad is None else pfad).rstrip("/") == "/binsearch/api" and methode in ("GET", "HEAD"):
            if self.token and pfad is None:
                from urllib.parse import parse_qs
                schluessel = (parse_qs(abfrage).get("apikey") or [""])[0]
                gegeben = str(schluessel).encode("utf-8")
                erwartet = self.token.encode("utf-8")
                if len(gegeben) != len(erwartet) or not hmac.compare_digest(gegeben, erwartet):
                    return 404, "application/json", {"err": "not found"}
            return self.binsearch_newznab(abfrage)
        # H0rSt als MCP-Server (Phase 3): auch ohne Token, eine externe KI kann keinen Pfad-Praefix im
        # Server-URL-Feld unterbringen - eigene Authentifizierung per Bearer-Schluessel in mcp_server.py
        if self.mcp_server.ist_route(roh if pfad is None else pfad):
            return self.mcp_server.bearbeite(roh if pfad is None else pfad, methode, koerper, kopf or {})
        # ("_• )—*: durchgereichte Seiten ausserhalb des Tokens – der Schluessel gilt nur fuer einen Reiter
        m = _PORTAL.match(roh if pfad is None else pfad)
        if m:
            return self.oberflaeche.portal_durch(m.group(1), m.group(2), abfrage, methode, koerper, kopf or {})
        if pfad is not None and mhub_addon.ist_v1_route(pfad):
            return self.mhub_v1(pfad, koerper, kopf or {})
        if pfad is None:
            return 404, "application/json", {"err": "not found"}
        if pfad in ("/", "", "/hls.js", "/logo.svg", "/brause/start", "/brause/gx") or pfad.startswith(("/api/", "/tmdbhelper/", "/schriften/")):
            return self.oberflaeche.bearbeite(pfad, abfrage, methode, koerper, kopf or {})
        if pfad.startswith("/dlna/"):  # Medienserver: Fernseher fragen per POST (SOAP)
            return self.dlna_bearbeite(pfad, methode, koerper, kopf, abfrage)
        if mhub_addon.ist_route(pfad):  # mHub-Addon (MediaHubMX v2), auch POST /playback
            return self.mhub_bearbeite(pfad, abfrage, methode, koerper, kopf or {})
        if methode != "GET":
            return 405, "application/json", {"err": "method not allowed"}
        if pfad == "/manifest.json":
            return 200, "application/json", self.manifest()
        if pfad == "/vxparser/urls.json":
            # Links fuer vxparsers url_list (Links (Domains & API's) => url_list)
            daten = self.verwaltung.daten() if self.verwaltung else {}
            return 200, "application/json", vxparser.urls_json(daten)
        if pfad == "/radio.m3u":  # Radio-Favoriten fuer Kodi, IPTV-Apps und VLC
            return self.oberflaeche.radio_m3u()
        if pfad == "/tv.m3u":
            zusatz = []
            for liste in self.listen.values():
                liste.bei_bedarf_erneuern()
                zusatz.extend(liste.eintraege())
            self.adressen.bei_bedarf_erneuern()
            return 200, "audio/x-mpegurl", livetv.m3u(self.livetv, self.epg_adresse(kopf or {}),
                                                      self.eigene_basis(kopf or {}), zusatz,
                                                      fern=self.adressen.adressen())
        eigene = _LISTE.match(pfad)
        if eigene:
            liste = self.listen.get(eigene.group(1))
            if not liste:
                return 404, "application/json", {"err": "unbekannte oder ausgeschaltete Liste"}
            liste.bei_bedarf_erneuern(warten=liste.alter() is None)
            if liste.alter() is None:
                return 503, "application/json", {"err": "Liste noch nicht geladen: %s" % (liste.fehler or "bitte warten")}
            return 200, "audio/x-mpegurl", "\n".join(["#EXTM3U"] + livetv.m3u_eintraege(liste.eintraege())) + "\n"
        hoster = _DEBRID.match(pfad)
        if hoster:
            return self.debrid_weiter(hoster.group(1))
        usenet = _USENET.match(pfad)
        if usenet:
            return self.usenet_weiter(usenet.group(1))
        logo = _LOGO.match(pfad)
        if logo:
            datei = self.logos.pfad(logo.group(1))
            if not datei:
                return 404, "application/json", {"err": "kein Logo"}
            return "logo", datei
        if pfad in ("/epg.xml", "/epg.xml.gz"):
            if not (self.epg.quelle or self.epg.zusatz):
                return 404, "application/json", {"err": "keine EPG-Quelle eingetragen"}
            self.epg.bei_bedarf_erneuern(warten=self.epg.alter() is None)
            if self.epg.alter() is None:
                return 503, "application/json", {"err": "EPG noch nicht geladen: %s" % (self.epg.fehler or "bitte warten")}
            return "datei", self.epg.pfad, pfad == "/epg.xml"
        treffer = _ROUTE.match(pfad)
        if not treffer:
            return 404, "application/json", {"err": "not found"}
        art, typ, stremio_id, extra_roh = treffer.groups()
        typ, stremio_id = unquote(typ), unquote(stremio_id)
        extra = {}
        for teil in (extra_roh or "").split("&"):
            if "=" in teil:
                schluessel, wert = teil.split("=", 1)
                extra[unquote(schluessel)] = unquote(wert)
        if art == "catalog":
            return 200, "application/json", self.katalog(typ, stremio_id, extra)
        if art == "meta":
            return 200, "application/json", self.meta(typ, stremio_id)
        if art == "stream":
            return 200, "application/json", self.stream(typ, stremio_id, kopf or {})
        return 200, "application/json", self.untertitel(typ, stremio_id, kopf or {})
