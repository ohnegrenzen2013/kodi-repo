"""NNTP-Verbindungsaufbau (geteilt mit anbindungen_pruefen._nntp_pruefen()) und Artikel-Stichprobenpruefung
fuer die Usenet-Gesundheitspruefung (usenet_triage.py). Reiner Socket-Client - kein nntplib (seit Python
3.13 entfernt, PEP 594)."""

import _ssl
import socket
import ssl
import time


class NntpFehler(Exception):
    pass


class NntpVerbindung:
    """Eine offene, angemeldete NNTP-Verbindung mit zeilenbasiertem Senden/Lesen."""

    def __init__(self, verbindung, roh, host, port):
        self._verbindung = verbindung
        self._roh = roh
        self._datei = verbindung.makefile("rwb")
        self.host, self.port = host, port

    def zeile(self):
        return self._datei.readline(2048).decode("utf-8", "replace").strip()

    def senden(self, text):
        self._datei.write(text.encode("utf-8") + b"\r\n")
        self._datei.flush()
        return self.zeile()

    def schliessen(self):
        try:
            self.senden("QUIT")
        except OSError:
            pass
        self._roh.close()


def tls_kontext():
    """Prüfung gegen den Systemspeicher, Name muss passen, keine lockeren Altlasten.

    VERIFY_X509_STRICT schaltet die Ausnahmen ab, mit denen OpenSSL kaputte Zwischenzertifikate
    sonst durchwinkt. Eine unvollständige Kette scheitert schon am Handshake."""
    kontext = ssl.create_default_context()
    kontext.verify_flags |= ssl.VERIFY_X509_STRICT
    kontext.minimum_version = ssl.TLSVersion.TLSv1_2
    return kontext


def _nntp_verbinden(werte, zeit=10.0):
    """Socket/SSL-Verbindungsaufbau + AUTHINFO-Anmeldung. Wirft immer NntpFehler bei jedem Problem -
    auch bei Verbindungs-/TLS-Fehlern (ssl.SSLError ist in Python eine OSError-Unterklasse, hier aber
    trotzdem mitgefangen, falls sich das je aendert) - nie das rohe OSError, damit artikel_vorhanden()s
    "wirft nie"-Zusage zuverlaessig gilt. Die Verbindung bleibt bei Erfolg offen und muss vom Aufrufer
    per .schliessen() beendet werden."""
    host = werte.get("host", "").strip()
    port = int(werte.get("port") or 563) if str(werte.get("port") or "563").isdigit() else 563
    if not host:
        raise NntpFehler("Server fehlt")
    roh = None
    try:
        roh = socket.create_connection((host, port), timeout=zeit)
        verbindung = tls_kontext().wrap_socket(roh, server_hostname=host) \
            if werte.get("ssl", "1") == "1" else roh
        nntp = NntpVerbindung(verbindung, roh, host, port)
        gruss = nntp.zeile()
        nntp.gruss = gruss
        if not gruss.startswith(("200", "201")):
            raise NntpFehler("Server meldet: " + gruss)
        antwort = nntp.senden("AUTHINFO USER " + werte.get("user", ""))
        if antwort.startswith("381"):
            antwort = nntp.senden("AUTHINFO PASS " + werte.get("pass", ""))
        if not antwort.startswith("281"):
            raise NntpFehler("Anmeldung abgelehnt: " + antwort)
        return nntp
    except NntpFehler:
        if roh is not None:
            roh.close()
        raise
    except (OSError, ssl.SSLError) as fehler:
        if roh is not None:
            roh.close()
        raise NntpFehler(str(fehler) or fehler.__class__.__name__) from fehler


_PROBE = "<h0rst-probe@invalid>"


def sitzung_pruefen(nntp):
    """Nach der Anmeldung: Lesemodus, Serverdatum, eine Artikelsuche.

    MODE READER darf 200/201 (Leser), 500 (kennt den Befehl nicht) oder 502 (schon Leser) sein.
    DATE muss 111 sein. STAT auf eine erfundene Kennung muss 223 oder 430 sein: der Server spricht
    Artikelbefehle, auch wenn die Kennung fehlt. Wirft NntpFehler, wenn das Passwort galt, die
    Sitzung aber keine Artikel liefert."""
    leser = nntp.senden("MODE READER")
    if leser.startswith("480"):
        raise NntpFehler("Lesemodus verlangt erneut Anmeldung: " + leser)
    if not leser.startswith(("200", "201", "500", "502")):
        raise NntpFehler("Lesemodus abgelehnt: " + leser)
    datum = nntp.senden("DATE")
    if not datum.startswith("111"):
        raise NntpFehler("Datum abgelehnt: " + datum)
    probe = nntp.senden("STAT " + _PROBE)
    if not probe.startswith(("223", "430")):
        raise NntpFehler("Artikelsuche abgelehnt: " + probe)
    teile = datum.split()
    return {"leser": leser[:3], "datum": teile[1] if len(teile) > 1 else "", "artikel": probe[:3]}


def _zertifikat_name(cert):
    for art, wert in cert.get("subjectAltName") or ():
        if art == "DNS" and wert:
            return wert
    for paar in cert.get("subject") or ():
        for name, wert in paar:
            if name == "commonName" and wert:
                return wert
    return ""


def _zertifikat_aussteller(cert):
    firma, kurz = "", ""
    for paar in cert.get("issuer") or ():
        for name, wert in paar:
            if name == "organizationName" and wert:
                firma = wert
            elif name == "commonName" and wert:
                kurz = wert
    return firma or kurz


def zertifikat_stand(verbindung, jetzt=None):
    """Kurztext zum geprüften Server-Zertifikat. Wirft NntpFehler, wenn keins da ist oder es abgelaufen ist.

    Der Handshake mit create_default_context hat Name und Kette schon geprüft. Hier bleibt die
    Restlaufzeit, damit ein Zertifikat, das morgen abläuft, in der Meldung steht."""
    cert = verbindung.getpeercert() if hasattr(verbindung, "getpeercert") else None
    if not cert:
        raise NntpFehler("TLS ohne geprüftes Zertifikat")
    ende = cert.get("notAfter") or ""
    try:
        bis = ssl.cert_time_to_seconds(ende) if ende else 0
    except ValueError:
        bis = 0
    jetzt = time.time() if jetzt is None else jetzt
    name = _zertifikat_name(cert) or "geprüft"
    aussteller = _zertifikat_aussteller(cert) or "Aussteller unbekannt"
    if not bis:
        return "Zertifikat %s, %s" % (name, aussteller)
    tage = int((bis - jetzt) // 86400)
    if tage < 0:
        raise NntpFehler("Zertifikat abgelaufen (%s)" % ende)
    return "Zertifikat %s, noch %d Tage, %s" % (name, tage, aussteller)


def _dn(cert, feld):
    teile = []
    for paar in cert.get(feld) or ():
        for schluessel, wert in paar:
            teile.append("%s=%s" % (schluessel, wert))
    return ",".join(teile)


def kette_passt(infos):
    """Jedes Glied muss vom nächsten ausgestellt sein. Das letzte ist die Vertrauensstelle."""
    for blatt, stelle in zip(infos, infos[1:]):
        if not _dn(blatt, "issuer") or _dn(blatt, "issuer") != _dn(stelle, "subject"):
            return False
    return True


def _glied_name(cert):
    return _zertifikat_name(cert) or _zertifikat_aussteller(cert) or "?"


def kette_lesen(verbindung):
    """Geprüfte Kette als Zertifikats-Dicts, leer wenn diese Python-Version sie nicht herausgibt.

    Ab 3.13 liefert der Socket die Kette, die OpenSSL schon akzeptiert hat. Davor bleibt nur das Blatt,
    die Prüfung selbst hat der Handshake trotzdem gemacht."""
    holen = getattr(verbindung, "get_verified_chain", None)
    if not holen:
        return []
    import os
    import tempfile
    infos = []
    for der in holen() or []:
        fd, pfad = tempfile.mkstemp(suffix=".pem")
        try:
            os.write(fd, ssl.DER_cert_to_PEM_cert(der).encode("ascii"))
            os.close(fd)
            fd = None
            infos.append(_ssl._test_decode_cert(pfad))
        finally:
            if fd is not None:
                os.close(fd)
            try:
                os.unlink(pfad)
            except OSError:
                pass
    if not kette_passt(infos):
        raise NntpFehler("Zertifikatskette unterbrochen")
    return infos


def kette_stand(verbindung, jetzt=None):
    """Blatt plus Kette. Ohne herausgegebene Glieder: die strenge Handshake-Prüfung hat gereicht."""
    blatt = zertifikat_stand(verbindung, jetzt)
    version = verbindung.version() if hasattr(verbindung, "version") else ""
    infos = kette_lesen(verbindung)
    if infos:
        namen = " → ".join(_glied_name(info) for info in infos)
        kette = "Kette %d: %s" % (len(infos), namen)
    else:
        kette = "Kette geprüft"
    return ", ".join(teil for teil in (version, kette, blatt) if teil)


def artikel_vorhanden(werte, message_ids, zeit=10.0):
    """Prueft per STAT, ob Message-IDs beim konfigurierten NNTP-Server vorhanden sind. message_ids: Liste
    von reinen Strings oder (message_id, gruppe)-Tupeln (GROUP wird einmal je Newsgroup gesendet, Gruppen
    aus nzb_lesen.stichprobe()). Verbindung wird fuer alle Stichproben wiederverwendet, nicht pro Artikel
    neu aufgebaut. Wirft nie - bei Verbindungs-/Auth-Fehler werden alle angefragten IDs als None
    (unbekannt, nicht 'fehlt') zurueckgegeben, damit ein Provider-Ausfall nicht alle Kandidaten faelschlich
    als kaputt markiert."""
    eintraege = [(e, "") if isinstance(e, str) else e for e in message_ids]
    if not eintraege:
        return {}
    try:
        nntp = _nntp_verbinden(werte, zeit)
    except NntpFehler:
        return {mid: None for mid, _ in eintraege}
    ergebnis = {}
    gruppe_aktiv = None
    try:
        for message_id, gruppe in eintraege:
            try:
                if gruppe and gruppe != gruppe_aktiv:
                    nntp.senden("GROUP " + gruppe)
                    gruppe_aktiv = gruppe
                kennung = message_id if message_id.startswith("<") else "<%s>" % message_id
                antwort = nntp.senden("STAT " + kennung)
                ergebnis[message_id] = antwort.startswith("223")
            except OSError:
                ergebnis[message_id] = None
    finally:
        nntp.schliessen()
    for message_id, _ in eintraege:
        ergebnis.setdefault(message_id, None)
    return ergebnis
