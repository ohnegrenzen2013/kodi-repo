"""NNTP-Verbindungsaufbau (geteilt mit anbindungen_pruefen._nntp_pruefen()) und Artikel-Stichprobenpruefung
fuer die Usenet-Gesundheitspruefung (usenet_triage.py). Reiner Socket-Client - kein nntplib (seit Python
3.13 entfernt, PEP 594)."""

import _ssl
import socket
import ssl
import time


class NntpFehler(Exception):
    pass


class NntpVerbindung:
    """Eine offene, angemeldete NNTP-Verbindung mit zeilenbasiertem Senden/Lesen."""

    def __init__(self, verbindung, roh, host, port):
        self._verbindung = verbindung
        self._roh = roh
        self._datei = verbindung.makefile("rwb")
        self.host, self.port = host, port

    def zeile(self):
        return self._datei.readline(2048).decode("utf-8", "replace").strip()

    def senden(self, text):
        self._datei.write(text.encode("utf-8") + b"\r\n")
        self._datei.flush()
        return self.zeile()

    def schliessen(self):
        try:
            self.senden("QUIT")
        except OSError:
            pass
        self._roh.close()


def tls_kontext():
    """Prüfung gegen den Systemspeicher, Name muss passen, keine lockeren Altlasten.

    VERIFY_X509_STRICT schaltet die Ausnahmen ab, mit denen OpenSSL kaputte Zwischenzertifikate
    sonst durchwinkt. Eine unvollständige Kette scheitert schon am Handshake."""
    kontext = ssl.create_default_context()
    kontext.verify_flags |= ssl.VERIFY_X509_STRICT
    kontext.minimum_version = ssl.TLSVersion.TLSv1_2
    return kontext


def _nntp_verbinden(werte, zeit=10.0):
    """Socket/SSL-Verbindungsaufbau + AUTHINFO-Anmeldung. Wirft immer NntpFehler bei jedem Problem -
    auch bei Verbindungs-/TLS-Fehlern (ssl.SSLError ist in Python eine OSError-Unterklasse, hier aber
    trotzdem mitgefangen, falls sich das je aendert) - nie das rohe OSError, damit artikel_vorhanden()s
    "wirft nie"-Zusage zuverlaessig gilt. Die Verbindung bleibt bei Erfolg offen und muss vom Aufrufer
    per .schliessen() beendet werden."""
    host = werte.get("host", "").strip()
    port = int(werte.get("port") or 563) if str(werte.get("port") or "563").isdigit() else 563
    if not host:
        raise NntpFehler("Server fehlt")
    roh = None
    try:
        roh = socket.create_connection((host, port), timeout=zeit)
        verbindung = tls_kontext().wrap_socket(roh, server_hostname=host) \
            if werte.get("ssl", "1") == "1" else roh
        nntp = NntpVerbindung(verbindung, roh, host, port)
        gruss = nntp.zeile()
        nntp.gruss = gruss
        if not gruss.startswith(("200", "201")):
            raise NntpFehler("Server meldet: " + gruss)
        antwort = nntp.senden("AUTHINFO USER " + werte.get("user", ""))
        if antwort.startswith("381"):
            antwort = nntp.senden("AUTHINFO PASS " + werte.get("pass", ""))
        if not antwort.startswith("281"):
            raise NntpFehler("Anmeldung abgelehnt: " + antwort)
        return nntp
    except NntpFehler:
        if roh is not None:
            roh.close()
        raise
    except (OSError, ssl.SSLError) as fehler:
        if roh is not None:
            roh.close()
        raise NntpFehler(str(fehler) or fehler.__class__.__name__) from fehler


_PROBE = "<h0rst-probe@invalid>"


def sitzung_pruefen(nntp):
    """Nach der Anmeldung: Lesemodus, Serverdatum, eine Artikelsuche.

    MODE READER darf 200/201 (Leser), 500 (kennt den Befehl nicht) oder 502 (schon Leser) sein.
    DATE muss 111 sein. STAT auf eine erfundene Kennung muss 223 oder 430 sein: der Server spricht
    Artikelbefehle, auch wenn die Kennung fehlt. Wirft NntpFehler, wenn das Passwort galt, die
    Sitzung aber keine Artikel liefert."""
    leser = nntp.senden("MODE READER")
    if leser.startswith("480"):
        raise NntpFehler("Lesemodus verlangt erneut Anmeldung: " + leser)
    if not leser.startswith(("200", "201", "500", "502")):
        raise NntpFehler("Lesemodus abgelehnt: " + leser)
    datum = nntp.senden("DATE")
    if not datum.startswith("111"):
        raise NntpFehler("Datum abgelehnt: " + datum)
    probe = nntp.senden("STAT " + _PROBE)
    if not probe.startswith(("223", "430")):
        raise NntpFehler("Artikelsuche abgelehnt: " + probe)
    teile = datum.split()
    return {"leser": leser[:3], "datum": teile[1] if len(teile) > 1 else "", "artikel": probe[:3]}


def _zertifikat_name(cert):
    for art, wert in cert.get("subjectAltName") or ():
        if art == "DNS" and wert:
            return wert
    for paar in cert.get("subject") or ():
        for name, wert in paar:
            if name == "commonName" and wert:
                return wert
    return ""


def _zertifikat_aussteller(cert):
    firma, kurz = "", ""
    for paar in cert.get("issuer") or ():
        for name, wert in paar:
            if name == "organizationName" and wert:
                firma = wert
            elif name == "commonName" and wert:
                kurz = wert
    return firma or kurz


def zertifikat_stand(verbindung, jetzt=None):
    """Kurztext zum geprüften Server-Zertifikat. Wirft NntpFehler, wenn keins da ist oder es abgelaufen ist.

    Der Handshake mit create_default_context hat Name und Kette schon geprüft. Hier bleibt die
    Restlaufzeit, damit ein Zertifikat, das morgen abläuft, in der Meldung steht."""
    cert = verbindung.getpeercert() if hasattr(verbindung, "getpeercert") else None
    if not cert:
        raise NntpFehler("TLS ohne geprüftes Zertifikat")
    ende = cert.get("notAfter") or ""
    try:
        bis = ssl.cert_time_to_seconds(ende) if ende else 0
    except ValueError:
        bis = 0
    jetzt = time.time() if jetzt is None else jetzt
    name = _zertifikat_name(cert) or "geprüft"
    aussteller = _zertifikat_aussteller(cert) or "Aussteller unbekannt"
    if not bis:
        return "Zertifikat %s, %s" % (name, aussteller)
    tage = int((bis - jetzt) // 86400)
    if tage < 0:
        raise NntpFehler("Zertifikat abgelaufen (%s)" % ende)
    return "Zertifikat %s, noch %d Tage, %s" % (name, tage, aussteller)


def _dn(cert, feld):
    teile = []
    for paar in cert.get(feld) or ():
        for schluessel, wert in paar:
            teile.append("%s=%s" % (schluessel, wert))
    return ",".join(teile)


def kette_passt(infos):
    """Jedes Glied muss vom nächsten ausgestellt sein. Das letzte ist die Vertrauensstelle."""
    for blatt, stelle in zip(infos, infos[1:]):
        if not _dn(blatt, "issuer") or _dn(blatt, "issuer") != _dn(stelle, "subject"):
            return False
    return True


def _glied_name(cert):
    return _zertifikat_name(cert) or _zertifikat_aussteller(cert) or "?"


def _info_aus_der(der):
    import os
    import tempfile
    fd, pfad = tempfile.mkstemp(suffix=".pem")
    try:
        os.write(fd, ssl.DER_cert_to_PEM_cert(der).encode("ascii"))
        os.close(fd)
        fd = None
        return _ssl._test_decode_cert(pfad)
    finally:
        if fd is not None:
            os.close(fd)
        try:
            os.unlink(pfad)
        except OSError:
            pass


def _openssl():
    if _openssl.paar is not None or _openssl.fehl:
        return _openssl.paar
    import ctypes
    import ctypes.util
    ssl_name, crypto_name = ctypes.util.find_library("ssl"), ctypes.util.find_library("crypto")
    if not ssl_name or not crypto_name:
        _openssl.fehl = True
        return None
    lib, crypto = ctypes.CDLL(ssl_name), ctypes.CDLL(crypto_name)
    lib.SSL_get_version.argtypes = [ctypes.c_void_p]
    lib.SSL_get_version.restype = ctypes.c_char_p
    lib.SSL_get0_verified_chain.argtypes = [ctypes.c_void_p]
    lib.SSL_get0_verified_chain.restype = ctypes.c_void_p
    for name, args, rest in (
        ("OPENSSL_sk_num", [ctypes.c_void_p], ctypes.c_int),
        ("OPENSSL_sk_value", [ctypes.c_void_p, ctypes.c_int], ctypes.c_void_p),
        ("i2d_X509", [ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p)], ctypes.c_int),
        ("X509_get_pubkey", [ctypes.c_void_p], ctypes.c_void_p),
        ("X509_verify", [ctypes.c_void_p, ctypes.c_void_p], ctypes.c_int),
        ("X509_check_ca", [ctypes.c_void_p], ctypes.c_int),
        ("d2i_X509", [ctypes.c_void_p, ctypes.POINTER(ctypes.c_char_p), ctypes.c_long], ctypes.c_void_p),
    ):
        fn = getattr(crypto, name)
        fn.argtypes, fn.restype = args, rest
    crypto.EVP_PKEY_free.argtypes = [ctypes.c_void_p]
    crypto.X509_free.argtypes = [ctypes.c_void_p]
    _openssl.paar = (lib, crypto)
    return _openssl.paar


_openssl.paar = None
_openssl.fehl = False


def _ssl_zeiger(verbindung, lib):
    import ctypes
    obj = getattr(verbindung, "_sslobj", None)
    if obj is None:
        return None
    erwartet = (verbindung.version() or "").encode() if hasattr(verbindung, "version") else b""
    basis = id(obj)
    for off in (16, 24, 32):
        ptr = ctypes.c_void_p.from_address(basis + off).value
        if not ptr:
            continue
        text = lib.SSL_get_version(ptr)
        if text and (not erwartet or text == erwartet):
            return ptr
    return None


def _der_von_x509(crypto, x509):
    import ctypes
    laenge = crypto.i2d_X509(x509, None)
    if laenge <= 0:
        return b""
    puff = ctypes.create_string_buffer(laenge)
    zeiger = ctypes.c_void_p(ctypes.addressof(puff))
    if crypto.i2d_X509(x509, ctypes.byref(zeiger)) != laenge:
        return b""
    return puff.raw


def _x509_aus_der(crypto, der):
    import ctypes
    puff = ctypes.create_string_buffer(der)
    zeiger = ctypes.c_char_p(ctypes.addressof(puff))
    return crypto.d2i_X509(None, ctypes.byref(zeiger), len(der))


def signaturen_ok(ders):
    """Jedes Zertifikat muss vom Schlüssel des nächsten Glieds unterschrieben sein, und das nächste muss eine Stelle sein."""
    paar = _openssl()
    if not paar or len(ders) < 2:
        return True
    _, crypto = paar
    certs = []
    try:
        for der in ders:
            cert = _x509_aus_der(crypto, der)
            if not cert:
                raise NntpFehler("Zertifikatskette nicht lesbar")
            certs.append(cert)
        for nummer in range(len(certs) - 1):
            pub = crypto.X509_get_pubkey(certs[nummer + 1])
            if not pub:
                raise NntpFehler("Zertifikatskette ohne Schlüssel")
            try:
                if crypto.X509_verify(certs[nummer], pub) != 1:
                    raise NntpFehler("Signatur in der Zertifikatskette ungültig")
            finally:
                crypto.EVP_PKEY_free(pub)
            if crypto.X509_check_ca(certs[nummer + 1]) == 0:
                raise NntpFehler("Zwischenzertifikat ist keine Stelle")
        return True
    finally:
        for cert in certs:
            crypto.X509_free(cert)


def _ders_von_openssl(verbindung):
    paar = _openssl()
    if not paar:
        return []
    lib, crypto = paar
    zeiger = _ssl_zeiger(verbindung, lib)
    if not zeiger:
        return []
    stapel = lib.SSL_get0_verified_chain(zeiger)
    if not stapel:
        return []
    anzahl = crypto.OPENSSL_sk_num(stapel)
    if anzahl <= 0 or anzahl > 12:
        return []
    ders = []
    for nummer in range(anzahl):
        x509 = crypto.OPENSSL_sk_value(stapel, nummer)
        der = _der_von_x509(crypto, x509) if x509 else b""
        if not der:
            raise NntpFehler("Zertifikatskette nicht lesbar")
        ders.append(der)
    signaturen_ok(ders)
    return ders


def kette_lesen(verbindung):
    """Geprüfte Kette. Python 3.13 gibt sie direkt, davor liest OpenSSL sie aus der Sitzung.

    Zusätzlich zur Handshake-Prüfung: der Ausstellername muss stimmen, die Signatur muss zum
    Schlüssel der nächsten Stelle passen, und diese Stelle muss eine CA sein."""
    holen = getattr(verbindung, "get_verified_chain", None)
    ders = list(holen() or []) if holen else _ders_von_openssl(verbindung)
    if not ders:
        return []
    if holen:
        signaturen_ok(ders)
    infos = [_info_aus_der(der) for der in ders]
    if not kette_passt(infos):
        raise NntpFehler("Zertifikatskette unterbrochen")
    return infos


def kette_stand(verbindung, jetzt=None):
    """Blatt plus Kette. Ohne herausgegebene Glieder: die strenge Handshake-Prüfung hat gereicht."""
    blatt = zertifikat_stand(verbindung, jetzt)
    version = verbindung.version() if hasattr(verbindung, "version") else ""
    infos = kette_lesen(verbindung)
    if infos:
        namen = " → ".join(_glied_name(info) for info in infos)
        kette = "Kette %d: %s" % (len(infos), namen)
    else:
        kette = "Kette geprüft"
    return ", ".join(teil for teil in (version, kette, blatt) if teil)


def artikel_vorhanden(werte, message_ids, zeit=10.0):
    """Prueft per STAT, ob Message-IDs beim konfigurierten NNTP-Server vorhanden sind. message_ids: Liste
    von reinen Strings oder (message_id, gruppe)-Tupeln (GROUP wird einmal je Newsgroup gesendet, Gruppen
    aus nzb_lesen.stichprobe()). Verbindung wird fuer alle Stichproben wiederverwendet, nicht pro Artikel
    neu aufgebaut. Wirft nie - bei Verbindungs-/Auth-Fehler werden alle angefragten IDs als None
    (unbekannt, nicht 'fehlt') zurueckgegeben, damit ein Provider-Ausfall nicht alle Kandidaten faelschlich
    als kaputt markiert."""
    eintraege = [(e, "") if isinstance(e, str) else e for e in message_ids]
    if not eintraege:
        return {}
    try:
        nntp = _nntp_verbinden(werte, zeit)
    except NntpFehler:
        return {mid: None for mid, _ in eintraege}
    ergebnis = {}
    gruppe_aktiv = None
    try:
        for message_id, gruppe in eintraege:
            try:
                if gruppe and gruppe != gruppe_aktiv:
                    nntp.senden("GROUP " + gruppe)
                    gruppe_aktiv = gruppe
                kennung = message_id if message_id.startswith("<") else "<%s>" % message_id
                antwort = nntp.senden("STAT " + kennung)
                ergebnis[message_id] = antwort.startswith("223")
            except OSError:
                ergebnis[message_id] = None
    finally:
        nntp.schliessen()
    for message_id, _ in eintraege:
        ergebnis.setdefault(message_id, None)
    return ergebnis
