"""Anbieter: Dienste mit Kategorie und Anmeldeart.

Ein Anbieter ist ein Konto im Sinne der Rezepte (manifest.json, Feld konto, sonst id).
Mitgelieferte Anbieter ergeben sich aus den Rezepten, eigene stehen in den Nutzerdaten
unter "anbieter": {id: {"name", "kategorie", "anmeldung", "geaendert"[, "typ", "vorlage"]}}.
"geaendert" ist nur ein Zeitstempel fuers Geraete-Abgleichen (NuvioMobile-Plan NV6). Zugangsdaten
liegen fuer beide unter einstellungen.<id>. Ein eigenes Rezept nutzt einen eigenen Anbieter
ueber "konto": "<id>" und dieselben Schluessel (api_key, user/pass, url ...).

typ sagt, wie der Server einen eigenen Anbieter selbst nutzt (siehe anbindungen.py), z. B.
newznab (Usenet-Indexer), nntp (Usenet-Provider), stremio-addon; vorlage nennt die Vorlage,
aus der er angelegt wurde (siehe vorlagen.py).
"""

import logging
import re
import time
import unicodedata

log = logging.getLogger("rezeptserver")

# Reihenfolge = Anzeige-Reihenfolge
KATEGORIEN = {"streams": "Streams", "usenet": "Usenet-Provider", "indexer": "Indexer (Usenet & Torrent)",
              "hoster": "Hoster & Debrid", "addons": "Stremio-Addons", "iptv": "IPTV & vxparser",
              "heimserver": "Eigene Medienserver (Jellyfin, Emby, Plex)",
              "vxparser": "vxparser-Links (Domains & APIs)", "downloader": "Downloader",
              "medien": "Medienverwaltung (Sonarr, Radarr, Seerr …)", "metadaten": "Metadaten",
              "untertitel": "Untertitel", "ab18": "Ab 18", "sicherheit": "Sicherheit (VPN, Proxy, Tor, I2P)",
              "sonstige": "Sonstige"}
# Rezepte dieser Kategorie laufen nur mit "ab18": true in den Nutzerdaten (Jugendschutz)
AB18 = "ab18"
ANMELDUNGEN = {"keine": "ohne Anmeldung", "api": "API-Schlüssel", "login": "Benutzer und Passwort",
               "url": "Adresse (URL)", "url_api": "Adresse und API-Schlüssel",
               "url_login": "Adresse, Benutzer und Passwort", "nntp": "Usenet-Server (NNTP)",
               "rustnzb": "Adresse, API-Schlüssel und Mediathek", "nzbdav": "Adresse, API-Schlüssel und WebDAV-Zugang", "url_pass": "Adresse und Passwort",
               "url_login_optional": "Adresse (Benutzer und Passwort optional)",
               "wireguard": "WireGuard-Konfiguration", "proxy": "Proxy (Server, Port, Anmeldung optional)"}
# eigene Anbieter melden sich per API-Schluessel, Login, Adresse oder als NNTP-Server an
EIGENE_ANMELDUNGEN = ("api", "login", "url", "url_api", "url_login", "nntp", "rustnzb", "nzbdav", "url_pass", "url_login_optional",
                      "wireguard", "proxy")
# Typen, die ohne jede Anmeldung arbeiten (sonst waere ein eigener Anbieter ohne Zugang sinnlos)
OHNE_ANMELDUNG = ("binsearch",)
_URL = {"key": "url", "label": "Adresse (URL)", "typ": "text"}
_API = {"key": "api_key", "label": "API-Schlüssel", "typ": "passwort"}
_USER = {"key": "user", "label": "Benutzername", "typ": "text"}
_PASS = {"key": "pass", "label": "Passwort", "typ": "passwort"}
# nur fuer Typen, die eine vom Nutzer eingetragene Adresse selbst abrufen (stremio-addon, mhub-addon):
# ohne diesen Schalter sind private/interne Adressen gesperrt (SSRF-Schutz)
_HEIMNETZ = {"key": "heimnetz_erlaubt", "label": "Auch im Heimnetz erlauben (private/interne Adressen wie 192.168.x.x)",
             "typ": "schalter", "optional": True}
# Typen, deren eigene Anbieter eine selbst eingetragene Adresse abrufen - siehe _HEIMNETZ
_HEIMNETZ_TYPEN = ("stremio-addon", "mhub-addon")
_MHUB_KONFIG = {"key": "konfig", "label": "mHub-Konfiguration (JSON, z. B. {\"token\": \"…\"})", "typ": "passwort",
                "optional": True, "mehrzeilig": True}
_MHUB_TRACKING = {"key": "tracking", "label": "Tracking einschalten (die App meldet Fortschritt an dieses Addon)",
                  "typ": "schalter", "optional": True}


def _felder_fuer(eigen):
    """Felder eines eigenen Anbieters: Anmelde-Felder plus Heimnetz/mHub-Zusätze."""
    felder = [dict(f) for f in FELDER[eigen["anmeldung"]]]
    if eigen.get("typ") in _HEIMNETZ_TYPEN:
        felder.append(dict(_HEIMNETZ))
    if eigen.get("typ") == "mhub-addon":
        felder.extend((dict(_MHUB_KONFIG), dict(_MHUB_TRACKING)))
    return felder


FELDER = {
    "keine": [],
    "api": [_API],
    "login": [_USER, _PASS],
    "url": [_URL],
    "url_api": [_URL, _API],
    "url_login": [_URL, _USER, _PASS],
    "nntp": [{"key": "host", "label": "Server", "typ": "text"},
             {"key": "port", "label": "Port", "typ": "zahl"},
             {"key": "ssl", "label": "SSL/TLS", "typ": "schalter", "optional": True},
             {"key": "ocsp", "label": "OCSP-Stapling", "typ": "wahl", "optional": True,
              "optionen": [{"wert": "an", "name": "an, Widerruf fällt durch"},
                           {"wert": "pflicht", "name": "Pflicht, ohne Antwort kein Zugang"},
                           {"wert": "aus", "name": "aus"}]},
             {"key": "ocsp_url", "label": "OCSP-Responder", "typ": "text", "optional": True},
             _USER, _PASS,
             {"key": "verbindungen", "label": "Verbindungen", "typ": "zahl", "optional": True}],
    "url_pass": [_URL, _PASS],
    "nzbdav": [_URL, {"key": "api_key", "label": "API-Schlüssel (Settings → SABnzbd)", "typ": "passwort"},
               {"key": "webdav_user", "label": "WebDAV-Benutzer (Settings → WebDAV)", "typ": "text", "optional": True},
               {"key": "webdav_pass", "label": "WebDAV-Passwort", "typ": "passwort", "optional": True}],
    "url_login_optional": [_URL, dict(_USER, optional=True), dict(_PASS, optional=True)],
    "rustnzb": [_URL, {"key": "api_key", "label": "API-Schlüssel (general.api_key)", "typ": "passwort"},
                {"key": "kategorie", "label": "Kategorie für Downloads", "typ": "text", "optional": True},
                {"key": "dav_user", "label": "Mediathek-Benutzer ([dav] username)", "typ": "text", "optional": True},
                {"key": "dav_pass", "label": "Mediathek-Passwort", "typ": "passwort", "optional": True},
                {"key": "dav_key", "label": "Mediathek-API-Schlüssel ([dav] api_key)", "typ": "passwort",
                 "optional": True}],
    # der Inhalt der .conf-Datei; enthaelt den privaten Schluessel, deshalb wie ein Passwort behandelt
    "wireguard": [{"key": "konfig", "label": "WireGuard-Konfiguration (Inhalt der .conf-Datei)", "typ": "passwort",
                   "mehrzeilig": True}],
    "proxy": [{"key": "host", "label": "Server", "typ": "text"},
              {"key": "port", "label": "Port", "typ": "zahl"},
              dict(_USER, optional=True), dict(_PASS, optional=True)],
}
# Wie der Server einen eigenen Anbieter selbst nutzt; "" = nur Zugangsdaten fuer eigene Rezepte
TYPEN = {"": "nur Zugangsdaten", "newznab": "Usenet-Indexer (Newznab)", "torznab": "Torrent-Indexer (Torznab)",
         "nntp": "Usenet-Server", "debrid": "Debrid-Dienst", "stremio-addon": "Stremio-Addon", "mhub-addon": "mHub-Addon (MediaHubMX v2)",
         "xtream": "Xtream Codes", "vxparser": "vxparser-Server", "vxparser-link": "vxparser-Link",
         "jellyfin": "Jellyfin (eigener Medienserver)", "emby": "Emby (eigener Medienserver)", "plex": "Plex (eigener Medienserver)",
         "sabnzbd": "SABnzbd", "nzbdav": "NzbDAV (Usenet-Streaming per WebDAV)", "altmount": "AltMount (Usenet-Streaming per WebDAV)",
         "binsearch": "Usenet-Suche binsearch (ohne Konto)", "nzbget": "NZBGet", "rustnzb": "rustnzb (Usenet-Downloader und -Streaming)",
         "qbittorrent": "qBittorrent", "transmission": "Transmission", "deluge": "Deluge",
         "downloadmaster": "ASUS Download Master (Router)", "sonarr": "Sonarr",
         "radarr": "Radarr", "lidarr": "Lidarr", "seerr": "Seerr (Overseerr/Jellyseerr)",
         "prowlarr": "Prowlarr (Suche & Holen)", "tautulli": "Tautulli", "bazarr": "Bazarr",
         "wireguard": "WireGuard-VPN", "socks5": "SOCKS5-Proxy", "http-proxy": "HTTP-Proxy", "tor": "Tor",
         "i2p": "I2P", "kodi": "Kodi (Fernsteuerung)", "pihole": "Pi-hole (Werbe- und Trackerfilter)"}
_ID = re.compile(r"^[a-z0-9][a-z0-9\-]{0,63}$")
_VORLAGE = re.compile(r"^[a-z0-9][a-z0-9_:\-]{0,79}$")
_UMLAUTE = {"ä": "ae", "ö": "oe", "ü": "ue", "ß": "ss"}


class AnbieterFehler(ValueError):
    pass


def kategorie_von(modul):
    if modul.daten.get("kategorie"):
        return modul.daten["kategorie"]
    if modul.rolle in ("finder", "aufloeser", "abspieler"):
        return "streams"
    if "untertitel" in modul.gibt and "metadaten" not in modul.gibt:
        return "untertitel"
    if "metadaten" in modul.gibt:
        return "metadaten"
    return "sonstige"


def anmeldung_von(felder):
    """keine ohne Felder, login mit Text- und Passwortfeld, sonst api."""
    if not felder:
        return "keine"
    typen = {f.get("typ", "text") for f in felder}
    return "login" if {"text", "passwort"} <= typen else "api"


def aus_rezepten(module):
    """Mitgelieferte Anbieter, je Konto einmal; Felder aller Rezepte des Kontos zusammengefasst."""
    reihenfolge = list(KATEGORIEN)
    gefunden = {}
    for modul in module:
        eintrag = gefunden.setdefault(modul.konto, {"id": modul.konto, "name": modul.name, "kategorie": None,
                                                    "anmeldung": None, "felder": [], "rezepte": [], "eigen": False,
                                                    "typ": "", "vorlage": ""})
        eintrag["rezepte"].append(modul.id)
        kategorie = kategorie_von(modul)
        if eintrag["kategorie"] is None or reihenfolge.index(kategorie) < reihenfolge.index(eintrag["kategorie"]):
            eintrag["kategorie"] = kategorie
        eintrag["anmeldung"] = eintrag["anmeldung"] or modul.daten.get("anmeldung")
        bekannt = {f["key"] for f in eintrag["felder"]}
        eintrag["felder"].extend(dict(f) for f in modul.einstellungen if f["key"] not in bekannt)
    for eintrag in gefunden.values():
        eintrag["anmeldung"] = eintrag["anmeldung"] or anmeldung_von(eintrag["felder"])
    return gefunden


def liste(module, daten):
    """Alle Anbieter (mitgelieferte und eigene), sortiert nach Kategorie und Name.

    Jeder Eintrag: id, name, kategorie, anmeldung, eigen, rezepte, felder (mit wert)
    und vollstaendig (alle Pflichtfelder ausgefuellt)."""
    alle = aus_rezepten(module)
    for anbieter_id, eigen in (daten.get("anbieter") or {}).items():
        if anbieter_id in alle:
            continue  # ein Rezept mit gleichem Konto geht vor
        felder = _felder_fuer(eigen)
        alle[anbieter_id] = {"id": anbieter_id, "name": eigen["name"], "kategorie": eigen["kategorie"],
                             "anmeldung": eigen["anmeldung"], "felder": felder,
                             "rezepte": [], "eigen": True, "typ": eigen.get("typ", ""),
                             "vorlage": eigen.get("vorlage", "")}
    for modul in module:
        if modul.konto in alle and alle[modul.konto]["eigen"]:
            alle[modul.konto]["rezepte"].append(modul.id)
    werte = daten.get("einstellungen") or {}
    for eintrag in alle.values():
        gesetzt = werte.get(eintrag["id"]) or {}
        for feld in eintrag["felder"]:
            feld["wert"] = str(gesetzt.get(feld["key"], ""))
        eintrag["vollstaendig"] = all(feld["wert"].strip() for feld in eintrag["felder"] if not feld.get("optional"))
    reihenfolge = list(KATEGORIEN)
    return sorted(alle.values(), key=lambda a: (reihenfolge.index(a["kategorie"]), a["name"].lower(), a["id"]))


def freigegeben(module, daten):
    """Rezepte ohne die der Kategorie ab18, solange ab18 in den Nutzerdaten nicht freigegeben ist."""
    if daten.get(AB18) is True:
        return list(module)
    erlaubt = [m for m in module if kategorie_von(m) != AB18]
    if len(erlaubt) < len(module):
        log.info("%d Rezepte ab 18 ausgeblendet (Jugendschutz, freigeben mit --ab18 an)", len(module) - len(erlaubt))
    return erlaubt


def neue_id(name):
    text = name.strip().lower()
    for alt, neu in _UMLAUTE.items():
        text = text.replace(alt, neu)
    text = unicodedata.normalize("NFKD", text).encode("ascii", "ignore").decode("ascii")
    text = re.sub(r"[^a-z0-9]+", "-", text).strip("-")[:64].strip("-")
    if not text:
        raise AnbieterFehler("Name braucht mindestens einen Buchstaben oder eine Ziffer")
    return text


def pruefe_eigene(eigene):
    """Prueft den Abschnitt "anbieter" der Nutzerdaten, wirft AnbieterFehler."""
    if not isinstance(eigene, dict):
        raise AnbieterFehler("anbieter muss die Form {id: {name, kategorie, anmeldung}} haben")
    for anbieter_id, eintrag in eigene.items():
        if not _ID.match(anbieter_id):
            raise AnbieterFehler("Anbieter-ID nur a-z, 0-9 und Bindestrich: %r" % anbieter_id)
        if not isinstance(eintrag, dict) or not str(eintrag.get("name", "")).strip():
            raise AnbieterFehler("Anbieter %s braucht einen Namen" % anbieter_id)
        if eintrag.get("kategorie") not in KATEGORIEN:
            raise AnbieterFehler("Anbieter %s: unbekannte Kategorie %r (erlaubt: %s)"
                                 % (anbieter_id, eintrag.get("kategorie"), ", ".join(KATEGORIEN)))
        if eintrag.get("anmeldung") not in EIGENE_ANMELDUNGEN and not (
                eintrag.get("anmeldung") == "keine" and eintrag.get("typ") in OHNE_ANMELDUNG):
            raise AnbieterFehler("Anbieter %s: Anmeldung muss %s sein, nicht %r"
                                 % (anbieter_id, " oder ".join(EIGENE_ANMELDUNGEN), eintrag.get("anmeldung")))
        if eintrag.get("typ", "") not in TYPEN:
            raise AnbieterFehler("Anbieter %s: unbekannter Typ %r (erlaubt: %s)"
                                 % (anbieter_id, eintrag.get("typ"), ", ".join(t for t in TYPEN if t)))
        vorlage = eintrag.get("vorlage", "")
        if vorlage and not (isinstance(vorlage, str) and _VORLAGE.match(vorlage)):
            raise AnbieterFehler("Anbieter %s: ungueltige Vorlage %r" % (anbieter_id, vorlage))
        if set(eintrag) - {"name", "kategorie", "anmeldung", "typ", "vorlage", "geaendert"}:
            raise AnbieterFehler("Anbieter %s: unbekannte Angaben %s" % (
                anbieter_id, ", ".join(sorted(set(eintrag) - {"name", "kategorie", "anmeldung", "typ", "vorlage", "geaendert"}))))


def freie_id(daten, module, name):
    """id aus dem Namen; ist sie belegt, mit -2, -3 ... dahinter."""
    basis = neue_id(name)
    belegt = set(aus_rezepten(module)) | set(daten.get("anbieter") or {})
    kandidat, nummer = basis, 2
    while kandidat in belegt:
        endung = "-%d" % nummer
        kandidat = basis[:64 - len(endung)].rstrip("-") + endung
        nummer += 1
    return kandidat


def hinzufuegen(daten, module, name, kategorie, anmeldung, werte=None, typ="", vorlage="", anbieter_id=None, uhr=time.time):
    """Legt einen eigenen Anbieter in daten an (daten danach speichern). Gibt die id zurueck."""
    anbieter_id = anbieter_id or neue_id(name)
    if anbieter_id in aus_rezepten(module) or anbieter_id in (daten.get("anbieter") or {}):
        raise AnbieterFehler("Anbieter %s gibt es schon" % anbieter_id)
    eintrag = {"name": name.strip(), "kategorie": kategorie, "anmeldung": anmeldung, "geaendert": int(uhr())}
    if typ:
        eintrag["typ"] = typ
    if vorlage:
        eintrag["vorlage"] = vorlage
    pruefe_eigene({anbieter_id: eintrag})
    daten.setdefault("anbieter", {})[anbieter_id] = eintrag
    erlaubt = {f["key"] for f in _felder_fuer({"anmeldung": anmeldung, "typ": typ})}
    zugang = {k: str(w).strip() for k, w in (werte or {}).items() if k in erlaubt}
    if zugang:
        daten.setdefault("einstellungen", {})[anbieter_id] = zugang
    return anbieter_id


def entfernen(daten, anbieter_id):
    """Entfernt einen eigenen Anbieter samt Zugangsdaten. Mitgelieferte lassen sich nicht entfernen."""
    if anbieter_id not in (daten.get("anbieter") or {}):
        raise AnbieterFehler("%s ist kein eigener Anbieter" % anbieter_id)
    del daten["anbieter"][anbieter_id]
    (daten.get("einstellungen") or {}).pop(anbieter_id, None)


def zugang_setzen(daten, module, anbieter_id, werte, uhr=time.time):
    """Setzt Zugangsdaten eines Anbieters; leere Passwortfelder behalten den bisherigen Wert."""
    eintrag = next((a for a in liste(module, daten) if a["id"] == anbieter_id), None)
    if eintrag is None:
        raise AnbieterFehler("Unbekannter Anbieter: %s" % anbieter_id)
    felder = {f["key"]: f for f in eintrag["felder"]}
    ziel = daten.setdefault("einstellungen", {}).setdefault(anbieter_id, {})
    for k, w in werte.items():
        if k not in felder:
            continue
        neu = str(w).strip()
        if not neu and felder[k].get("typ") == "passwort" and ziel.get(k):
            continue
        ziel[k] = neu
    eigener = (daten.get("anbieter") or {}).get(anbieter_id)
    if isinstance(eigener, dict):
        eigener["geaendert"] = int(uhr())
