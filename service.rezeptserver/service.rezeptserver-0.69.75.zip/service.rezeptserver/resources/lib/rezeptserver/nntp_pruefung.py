"""NNTP-Verbindungsaufbau (geteilt mit anbindungen_pruefen._nntp_pruefen()) und Artikel-Stichprobenpruefung
fuer die Usenet-Gesundheitspruefung (usenet_triage.py). Reiner Socket-Client - kein nntplib (seit Python
3.13 entfernt, PEP 594)."""

import _ssl
import hashlib
import socket
import ssl
import threading
import time


class NntpFehler(Exception):
    pass


class NntpVerbindung:
    """Eine offene, angemeldete NNTP-Verbindung mit zeilenbasiertem Senden/Lesen."""

    def __init__(self, verbindung, roh, host, port):
        self._verbindung = verbindung
        self._roh = roh
        self._datei = verbindung.makefile("rwb")
        self.host, self.port = host, port

    def zeile(self):
        return self._datei.readline(2048).decode("utf-8", "replace").strip()

    def senden(self, text):
        self._datei.write(text.encode("utf-8") + b"\r\n")
        self._datei.flush()
        return self.zeile()

    def schliessen(self):
        try:
            self.senden("QUIT")
        except OSError:
            pass
        self._roh.close()


def tls_kontext():
    """Prüfung gegen den Systemspeicher, Name muss passen, keine lockeren Altlasten.

    VERIFY_X509_STRICT schaltet die Ausnahmen ab, mit denen OpenSSL kaputte Zwischenzertifikate
    sonst durchwinkt. Eine unvollständige Kette scheitert schon am Handshake."""
    kontext = ssl.create_default_context()
    kontext.verify_flags |= ssl.VERIFY_X509_STRICT
    kontext.minimum_version = ssl.TLSVersion.TLSv1_2
    return kontext


def _nntp_verbinden(werte, zeit=10.0):
    """Socket/SSL-Verbindungsaufbau + AUTHINFO-Anmeldung. Wirft immer NntpFehler bei jedem Problem -
    auch bei Verbindungs-/TLS-Fehlern (ssl.SSLError ist in Python eine OSError-Unterklasse, hier aber
    trotzdem mitgefangen, falls sich das je aendert) - nie das rohe OSError, damit artikel_vorhanden()s
    "wirft nie"-Zusage zuverlaessig gilt. Die Verbindung bleibt bei Erfolg offen und muss vom Aufrufer
    per .schliessen() beendet werden."""
    host = werte.get("host", "").strip()
    port = int(werte.get("port") or 563) if str(werte.get("port") or "563").isdigit() else 563
    if not host:
        raise NntpFehler("Server fehlt")
    roh = None
    try:
        roh = socket.create_connection((host, port), timeout=zeit)
        verbindung = tls_kontext().wrap_socket(roh, server_hostname=host, do_handshake_on_connect=False) \
            if werte.get("ssl", "1") == "1" else roh
        if werte.get("ssl", "1") == "1":
            if ocsp_modus(werte) != "aus":
                ocsp_anfordern(verbindung)
            verbindung.do_handshake()
        nntp = NntpVerbindung(verbindung, roh, host, port)
        if werte.get("ssl", "1") == "1":
            nntp.ocsp = ocsp_nach_handshake(verbindung, werte, zeit)
        gruss = nntp.zeile()
        nntp.gruss = gruss
        if not gruss.startswith(("200", "201")):
            raise NntpFehler("Server meldet: " + gruss)
        antwort = nntp.senden("AUTHINFO USER " + werte.get("user", ""))
        if antwort.startswith("381"):
            antwort = nntp.senden("AUTHINFO PASS " + werte.get("pass", ""))
        if not antwort.startswith("281"):
            raise NntpFehler("Anmeldung abgelehnt: " + antwort)
        return nntp
    except NntpFehler:
        if roh is not None:
            roh.close()
        raise
    except (OSError, ssl.SSLError) as fehler:
        if roh is not None:
            roh.close()
        raise NntpFehler(str(fehler) or fehler.__class__.__name__) from fehler


_PROBE = "<h0rst-probe@invalid>"


def sitzung_pruefen(nntp):
    """Nach der Anmeldung: Lesemodus, Serverdatum, eine Artikelsuche.

    MODE READER darf 200/201 (Leser), 500 (kennt den Befehl nicht) oder 502 (schon Leser) sein.
    DATE muss 111 sein. STAT auf eine erfundene Kennung muss 223 oder 430 sein: der Server spricht
    Artikelbefehle, auch wenn die Kennung fehlt. Wirft NntpFehler, wenn das Passwort galt, die
    Sitzung aber keine Artikel liefert."""
    leser = nntp.senden("MODE READER")
    if leser.startswith("480"):
        raise NntpFehler("Lesemodus verlangt erneut Anmeldung: " + leser)
    if not leser.startswith(("200", "201", "500", "502")):
        raise NntpFehler("Lesemodus abgelehnt: " + leser)
    datum = nntp.senden("DATE")
    if not datum.startswith("111"):
        raise NntpFehler("Datum abgelehnt: " + datum)
    probe = nntp.senden("STAT " + _PROBE)
    if not probe.startswith(("223", "430")):
        raise NntpFehler("Artikelsuche abgelehnt: " + probe)
    teile = datum.split()
    return {"leser": leser[:3], "datum": teile[1] if len(teile) > 1 else "", "artikel": probe[:3]}


def _zertifikat_name(cert):
    for art, wert in cert.get("subjectAltName") or ():
        if art == "DNS" and wert:
            return wert
    for paar in cert.get("subject") or ():
        for name, wert in paar:
            if name == "commonName" and wert:
                return wert
    return ""


def _zertifikat_aussteller(cert):
    firma, kurz = "", ""
    for paar in cert.get("issuer") or ():
        for name, wert in paar:
            if name == "organizationName" and wert:
                firma = wert
            elif name == "commonName" and wert:
                kurz = wert
    return firma or kurz


def zertifikat_stand(verbindung, jetzt=None):
    """Kurztext zum geprüften Server-Zertifikat. Wirft NntpFehler, wenn keins da ist oder es abgelaufen ist.

    Der Handshake mit create_default_context hat Name und Kette schon geprüft. Hier bleibt die
    Restlaufzeit, damit ein Zertifikat, das morgen abläuft, in der Meldung steht."""
    cert = verbindung.getpeercert() if hasattr(verbindung, "getpeercert") else None
    if not cert:
        raise NntpFehler("TLS ohne geprüftes Zertifikat")
    ende = cert.get("notAfter") or ""
    try:
        bis = ssl.cert_time_to_seconds(ende) if ende else 0
    except ValueError:
        bis = 0
    jetzt = time.time() if jetzt is None else jetzt
    name = _zertifikat_name(cert) or "geprüft"
    aussteller = _zertifikat_aussteller(cert) or "Aussteller unbekannt"
    if not bis:
        return "Zertifikat %s, %s" % (name, aussteller)
    tage = int((bis - jetzt) // 86400)
    if tage < 0:
        raise NntpFehler("Zertifikat abgelaufen (%s)" % ende)
    return "Zertifikat %s, noch %d Tage, %s" % (name, tage, aussteller)


def _dn(cert, feld):
    teile = []
    for paar in cert.get(feld) or ():
        for schluessel, wert in paar:
            teile.append("%s=%s" % (schluessel, wert))
    return ",".join(teile)


def kette_passt(infos):
    """Jedes Glied muss vom nächsten ausgestellt sein. Das letzte ist die Vertrauensstelle."""
    for blatt, stelle in zip(infos, infos[1:]):
        if not _dn(blatt, "issuer") or _dn(blatt, "issuer") != _dn(stelle, "subject"):
            return False
    return True


def _glied_name(cert):
    return _zertifikat_name(cert) or _zertifikat_aussteller(cert) or "?"


def _info_aus_der(der):
    import os
    import tempfile
    fd, pfad = tempfile.mkstemp(suffix=".pem")
    try:
        os.write(fd, ssl.DER_cert_to_PEM_cert(der).encode("ascii"))
        os.close(fd)
        fd = None
        return _ssl._test_decode_cert(pfad)
    finally:
        if fd is not None:
            os.close(fd)
        try:
            os.unlink(pfad)
        except OSError:
            pass


def _openssl():
    if _openssl.paar is not None or _openssl.fehl:
        return _openssl.paar
    import ctypes
    import ctypes.util
    ssl_name, crypto_name = ctypes.util.find_library("ssl"), ctypes.util.find_library("crypto")
    if not ssl_name or not crypto_name:
        _openssl.fehl = True
        return None
    lib, crypto = ctypes.CDLL(ssl_name), ctypes.CDLL(crypto_name)
    lib.SSL_get_version.argtypes = [ctypes.c_void_p]
    lib.SSL_get_version.restype = ctypes.c_char_p
    lib.SSL_get0_verified_chain.argtypes = [ctypes.c_void_p]
    lib.SSL_get0_verified_chain.restype = ctypes.c_void_p
    lib.SSL_ctrl.argtypes = [ctypes.c_void_p, ctypes.c_int, ctypes.c_long, ctypes.POINTER(ctypes.c_void_p)]
    lib.SSL_ctrl.restype = ctypes.c_long
    for name, args, rest in (
        ("OPENSSL_sk_num", [ctypes.c_void_p], ctypes.c_int),
        ("OPENSSL_sk_value", [ctypes.c_void_p, ctypes.c_int], ctypes.c_void_p),
        ("OPENSSL_sk_new_null", [], ctypes.c_void_p),
        ("OPENSSL_sk_push", [ctypes.c_void_p, ctypes.c_void_p], ctypes.c_int),
        ("i2d_X509", [ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p)], ctypes.c_int),
        ("X509_get_pubkey", [ctypes.c_void_p], ctypes.c_void_p),
        ("X509_verify", [ctypes.c_void_p, ctypes.c_void_p], ctypes.c_int),
        ("X509_check_ca", [ctypes.c_void_p], ctypes.c_int),
        ("d2i_X509", [ctypes.c_void_p, ctypes.POINTER(ctypes.c_char_p), ctypes.c_long], ctypes.c_void_p),
        ("d2i_OCSP_RESPONSE", [ctypes.c_void_p, ctypes.POINTER(ctypes.c_char_p), ctypes.c_long], ctypes.c_void_p),
        ("OCSP_response_status", [ctypes.c_void_p], ctypes.c_int),
        ("OCSP_response_get1_basic", [ctypes.c_void_p], ctypes.c_void_p),
        ("OCSP_cert_to_id", [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p], ctypes.c_void_p),
        ("OCSP_resp_find_status", [ctypes.c_void_p, ctypes.c_void_p, ctypes.POINTER(ctypes.c_int),
                                   ctypes.POINTER(ctypes.c_int), ctypes.POINTER(ctypes.c_void_p),
                                   ctypes.POINTER(ctypes.c_void_p), ctypes.POINTER(ctypes.c_void_p)], ctypes.c_int),
        ("OCSP_check_validity", [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_long, ctypes.c_long], ctypes.c_int),
        ("OCSP_basic_verify", [ctypes.c_void_p, ctypes.c_void_p, ctypes.c_void_p, ctypes.c_ulong], ctypes.c_int),
        ("X509_STORE_new", [], ctypes.c_void_p),
        ("X509_STORE_add_cert", [ctypes.c_void_p, ctypes.c_void_p], ctypes.c_int),
        ("OCSP_REQUEST_new", [], ctypes.c_void_p),
        ("OCSP_request_add0_id", [ctypes.c_void_p, ctypes.c_void_p], ctypes.c_void_p),
        ("i2d_OCSP_REQUEST", [ctypes.c_void_p, ctypes.POINTER(ctypes.c_void_p)], ctypes.c_int),
        ("EVP_sha1", [], ctypes.c_void_p),
        ("ASN1_STRING_get0_data", [ctypes.c_void_p], ctypes.c_void_p),
        ("ASN1_STRING_length", [ctypes.c_void_p], ctypes.c_int),
    ):
        fn = getattr(crypto, name)
        fn.argtypes, fn.restype = args, rest
    for name in ("EVP_PKEY_free", "X509_free", "OCSP_RESPONSE_free", "OCSP_BASICRESP_free",
                 "OCSP_CERTID_free", "X509_STORE_free", "OPENSSL_sk_free", "OCSP_REQUEST_free"):
        getattr(crypto, name).argtypes = [ctypes.c_void_p]
    _openssl.paar = (lib, crypto)
    return _openssl.paar


_openssl.paar = None
_openssl.fehl = False


def _ssl_zeiger(verbindung, lib):
    import ctypes
    obj = getattr(verbindung, "_sslobj", None)
    if obj is None:
        return None
    erwartet = (verbindung.version() or "").encode() if hasattr(verbindung, "version") else b""
    basis = id(obj)
    for off in (16, 24, 32):
        ptr = ctypes.c_void_p.from_address(basis + off).value
        if not ptr:
            continue
        text = lib.SSL_get_version(ptr)
        if not text or not text.startswith(b"TLS"):
            continue
        if erwartet.startswith(b"TLS") and text != erwartet:
            continue
        return ptr
    return None


def _der_von_x509(crypto, x509):
    import ctypes
    laenge = crypto.i2d_X509(x509, None)
    if laenge <= 0:
        return b""
    puff = ctypes.create_string_buffer(laenge)
    zeiger = ctypes.c_void_p(ctypes.addressof(puff))
    if crypto.i2d_X509(x509, ctypes.byref(zeiger)) != laenge:
        return b""
    return puff.raw


def _x509_aus_der(crypto, der):
    import ctypes
    puff = ctypes.create_string_buffer(der)
    zeiger = ctypes.c_char_p(ctypes.addressof(puff))
    return crypto.d2i_X509(None, ctypes.byref(zeiger), len(der))


def signaturen_ok(ders):
    """Jedes Zertifikat muss vom Schlüssel des nächsten Glieds unterschrieben sein, und das nächste muss eine Stelle sein."""
    paar = _openssl()
    if not paar or len(ders) < 2:
        return True
    _, crypto = paar
    certs = []
    try:
        for der in ders:
            cert = _x509_aus_der(crypto, der)
            if not cert:
                raise NntpFehler("Zertifikatskette nicht lesbar")
            certs.append(cert)
        for nummer in range(len(certs) - 1):
            pub = crypto.X509_get_pubkey(certs[nummer + 1])
            if not pub:
                raise NntpFehler("Zertifikatskette ohne Schlüssel")
            try:
                if crypto.X509_verify(certs[nummer], pub) != 1:
                    raise NntpFehler("Signatur in der Zertifikatskette ungültig")
            finally:
                crypto.EVP_PKEY_free(pub)
            if crypto.X509_check_ca(certs[nummer + 1]) == 0:
                raise NntpFehler("Zwischenzertifikat ist keine Stelle")
        return True
    finally:
        for cert in certs:
            crypto.X509_free(cert)


def _ders_von_openssl(verbindung):
    paar = _openssl()
    if not paar:
        return []
    lib, crypto = paar
    zeiger = _ssl_zeiger(verbindung, lib)
    if not zeiger:
        return []
    stapel = lib.SSL_get0_verified_chain(zeiger)
    if not stapel:
        return []
    anzahl = crypto.OPENSSL_sk_num(stapel)
    if anzahl <= 0 or anzahl > 12:
        return []
    ders = []
    for nummer in range(anzahl):
        x509 = crypto.OPENSSL_sk_value(stapel, nummer)
        der = _der_von_x509(crypto, x509) if x509 else b""
        if not der:
            raise NntpFehler("Zertifikatskette nicht lesbar")
        ders.append(der)
    signaturen_ok(ders)
    return ders


def kette_lesen(verbindung):
    """Geprüfte Kette. Python 3.13 gibt sie direkt, davor liest OpenSSL sie aus der Sitzung.

    Zusätzlich zur Handshake-Prüfung: der Ausstellername muss stimmen, die Signatur muss zum
    Schlüssel der nächsten Stelle passen, und diese Stelle muss eine CA sein."""
    holen = getattr(verbindung, "get_verified_chain", None)
    ders = list(holen() or []) if holen else _ders_von_openssl(verbindung)
    if not ders:
        return []
    if holen:
        signaturen_ok(ders)
    infos = [_info_aus_der(der) for der in ders]
    if not kette_passt(infos):
        raise NntpFehler("Zertifikatskette unterbrochen")
    return infos


def kette_stand(verbindung, jetzt=None):
    """Blatt plus Kette. Ohne herausgegebene Glieder: die strenge Handshake-Prüfung hat gereicht."""
    blatt = zertifikat_stand(verbindung, jetzt)
    version = verbindung.version() if hasattr(verbindung, "version") else ""
    infos = kette_lesen(verbindung)
    if infos:
        namen = " → ".join(_glied_name(info) for info in infos)
        kette = "Kette %d: %s" % (len(infos), namen)
    else:
        kette = "Kette geprüft"
    return ", ".join(teil for teil in (version, kette, blatt) if teil)


_OCSP_TYP = 1
_OCSP_SETZEN = 65
_OCSP_LESEN = 70


def ocsp_modus(werte):
    """an: Staple mitlesen, Widerruf fällt durch. pflicht: ohne Antwort kein Zugang. aus: nichts davon."""
    modus = str((werte or {}).get("ocsp", "an") or "an").strip().lower()
    if modus in ("0", "aus", "nein", "off"):
        return "aus"
    if modus in ("pflicht", "erzwingen", "2"):
        return "pflicht"
    return "an"


def ocsp_anfordern(verbindung):
    """Vor dem Handshake: status_request mitschicken. Ohne OpenSSL bleibt es still."""
    paar = _openssl()
    if not paar:
        return
    lib, _crypto = paar
    zeiger = _ssl_zeiger(verbindung, lib)
    if zeiger:
        lib.SSL_ctrl(zeiger, _OCSP_SETZEN, _OCSP_TYP, None)


def _ocsp_bytes(verbindung):
    import ctypes
    paar = _openssl()
    if not paar:
        return b""
    lib, _crypto = paar
    zeiger = _ssl_zeiger(verbindung, lib)
    if not zeiger:
        return b""
    aus = ctypes.c_void_p()
    laenge = lib.SSL_ctrl(zeiger, _OCSP_LESEN, 0, ctypes.byref(aus))
    if laenge <= 0 or not aus.value:
        return b""
    return ctypes.string_at(aus.value, laenge)


def ocsp_aus_x509(crypto, antwort, blatt, aussteller, weitere=()):
    """Staple gegen Blatt und Aussteller. 'gut' oder 'unbekannt'. Widerruf und kaputte Signatur werfen.

    Die Stellen aus der schon geprüften Kette gelten als Vertrauensanker (OCSP_TRUSTOTHER), sonst
    scheitert ein Zwischenzertifikat an einem leeren Speicher."""
    import ctypes
    puff = ctypes.create_string_buffer(antwort)
    zeiger = ctypes.c_char_p(ctypes.addressof(puff))
    resp = crypto.d2i_OCSP_RESPONSE(None, ctypes.byref(zeiger), len(antwort))
    if not resp:
        raise NntpFehler("OCSP-Staple nicht lesbar")
    basic = certid = speicher = stapel = None
    try:
        if crypto.OCSP_response_status(resp) != 0:
            raise NntpFehler("OCSP-Staple abgelehnt")
        basic = crypto.OCSP_response_get1_basic(resp)
        if not basic:
            raise NntpFehler("OCSP-Staple ohne Inhalt")
        certid = crypto.OCSP_cert_to_id(crypto.EVP_sha1(), blatt, aussteller)
        if not certid:
            raise NntpFehler("OCSP-Staple ohne Kennung")
        status, grund = ctypes.c_int(), ctypes.c_int()
        widerruf, dieses, naechstes = ctypes.c_void_p(), ctypes.c_void_p(), ctypes.c_void_p()
        if crypto.OCSP_resp_find_status(basic, certid, ctypes.byref(status), ctypes.byref(grund),
                                        ctypes.byref(widerruf), ctypes.byref(dieses), ctypes.byref(naechstes)) != 1:
            raise NntpFehler("OCSP-Staple gilt nicht für dieses Zertifikat")
        if crypto.OCSP_check_validity(dieses, naechstes, 300, -1) != 1:
            raise NntpFehler("OCSP-Staple veraltet")
        bis = _zeit_aus_asn1(crypto, naechstes.value)
        speicher = crypto.X509_STORE_new()
        stapel = crypto.OPENSSL_sk_new_null()
        if not speicher or not stapel:
            raise NntpFehler("OCSP-Staple nicht prüfbar")
        for cert in (list(weitere) or [aussteller]):
            if crypto.X509_STORE_add_cert(speicher, cert) != 1 or crypto.OPENSSL_sk_push(stapel, cert) < 1:
                raise NntpFehler("OCSP-Staple nicht prüfbar")
        if crypto.OCSP_basic_verify(basic, stapel, speicher, 0x200) != 1:
            raise NntpFehler("OCSP-Staple Signatur ungültig")
        if status.value == 1:
            raise NntpFehler("Zertifikat widerrufen (OCSP)")
        stand = "unbekannt" if status.value == 2 else "gut"
        return stand, bis
    finally:
        if certid:
            crypto.OCSP_CERTID_free(certid)
        if basic:
            crypto.OCSP_BASICRESP_free(basic)
        crypto.OCSP_RESPONSE_free(resp)
        if stapel:
            crypto.OPENSSL_sk_free(stapel)
        if speicher:
            crypto.X509_STORE_free(speicher)


def ocsp_aus_der(antwort, blatt_der, aussteller_der):
    """Dieselbe Prüfung, aber mit DER-Zertifikaten. Für den Verbindungstest und die Tests."""
    paar = _openssl()
    if not paar:
        raise NntpFehler("OCSP-Staple nicht prüfbar")
    _, crypto = paar
    blatt, aussteller = _x509_aus_der(crypto, blatt_der), _x509_aus_der(crypto, aussteller_der)
    if not blatt or not aussteller:
        if blatt:
            crypto.X509_free(blatt)
        if aussteller:
            crypto.X509_free(aussteller)
        raise NntpFehler("OCSP-Staple nicht prüfbar")
    try:
        return ocsp_aus_x509(crypto, antwort, blatt, aussteller)[0]
    finally:
        crypto.X509_free(blatt)
        crypto.X509_free(aussteller)


def _zeit_aus_asn1(crypto, zeiger):
    """GENERALIZEDTIME als Unixzeit, oder None."""
    import ctypes
    if not zeiger:
        return None
    daten = crypto.ASN1_STRING_get0_data(zeiger)
    laenge = crypto.ASN1_STRING_length(zeiger)
    if not daten or laenge < 14:
        return None
    text = ctypes.string_at(daten, laenge).decode("ascii", "replace").rstrip("Z")
    try:
        import datetime
        return datetime.datetime.strptime(text[:14], "%Y%m%d%H%M%S").replace(
            tzinfo=datetime.timezone.utc).timestamp()
    except ValueError:
        return None


_OCSP_CACHE = {}
_OCSP_CACHE_SPERRE = threading.Lock()
_OCSP_CACHE_GRENZE = 32
_OCSP_CACHE_OHNE_ENDE = 600


def ocsp_cache_leeren():
    with _OCSP_CACHE_SPERRE:
        _OCSP_CACHE.clear()


def _ocsp_schluessel(antwort, blatt_der):
    return hashlib.sha256(blatt_der + b"\0" + antwort).digest()


def ocsp_cache_lesen(antwort, blatt_der, jetzt=None):
    """(fehler, text) oder None. Abgelaufene Einträge fallen weg."""
    jetzt = time.time() if jetzt is None else jetzt
    schluessel = _ocsp_schluessel(antwort, blatt_der)
    with _OCSP_CACHE_SPERRE:
        eintrag = _OCSP_CACHE.get(schluessel)
        if not eintrag or eintrag[0] <= jetzt:
            if eintrag:
                _OCSP_CACHE.pop(schluessel, None)
            return None
        return eintrag[1], eintrag[2]


def ocsp_cache_schreiben(antwort, blatt_der, text, fehler, bis, jetzt=None):
    jetzt = time.time() if jetzt is None else jetzt
    if not bis or bis <= jetzt:
        bis = jetzt + _OCSP_CACHE_OHNE_ENDE
    schluessel = _ocsp_schluessel(antwort, blatt_der)
    with _OCSP_CACHE_SPERRE:
        if schluessel not in _OCSP_CACHE and len(_OCSP_CACHE) >= _OCSP_CACHE_GRENZE:
            aeltester = min(_OCSP_CACHE, key=lambda k: _OCSP_CACHE[k][0])
            _OCSP_CACHE.pop(aeltester, None)
        _OCSP_CACHE[schluessel] = (bis, bool(fehler), text)


def _ocsp_auswerten(crypto, antwort, blatt, aussteller, weitere, blatt_der, quelle=""):
    """Prüft die Antwort, nutzt den Cache und hängt die Quelle an, wenn es der Responder war."""
    getroffen = ocsp_cache_lesen(antwort, blatt_der) if blatt_der else None
    if getroffen is not None:
        if getroffen[0]:
            raise NntpFehler(getroffen[1])
        return getroffen[1]
    try:
        stand, bis = ocsp_aus_x509(crypto, antwort, blatt, aussteller, weitere)
    except NntpFehler as fehler:
        if blatt_der:
            ocsp_cache_schreiben(antwort, blatt_der, str(fehler), fehler=True, bis=None)
        raise
    text = "OCSP " + stand + (" (Responder)" if quelle else "")
    if blatt_der:
        ocsp_cache_schreiben(antwort, blatt_der, text, fehler=False, bis=bis)
    return text


def ocsp_stand(verbindung):
    """Kurztext nach dem Handshake. Kein Staple ist kein Fehler, Widerruf schon.

    Dieselbe Antwort zum selben Blatt wird bis nextUpdate nicht noch einmal geprüft."""
    antwort = _ocsp_bytes(verbindung)
    if not antwort:
        return "kein OCSP-Staple"
    paar = _openssl()
    lib, crypto = paar
    zeiger = _ssl_zeiger(verbindung, lib)
    stapel = lib.SSL_get0_verified_chain(zeiger) if zeiger else None
    anzahl = crypto.OPENSSL_sk_num(stapel) if stapel else 0
    if anzahl < 1:
        raise NntpFehler("OCSP-Staple ohne Zertifikat")
    blatt = crypto.OPENSSL_sk_value(stapel, 0)
    blatt_der = _der_von_x509(crypto, blatt)
    aussteller = crypto.OPENSSL_sk_value(stapel, 1) if anzahl > 1 else blatt
    weitere = [crypto.OPENSSL_sk_value(stapel, nummer) for nummer in range(anzahl)]
    return _ocsp_auswerten(crypto, antwort, blatt, aussteller, weitere, blatt_der)


def ocsp_anfrage(crypto, blatt, aussteller):
    """DER-Anfrage für Blatt und Aussteller. Der CertID geht in die Anfrage über."""
    import ctypes
    certid = crypto.OCSP_cert_to_id(crypto.EVP_sha1(), blatt, aussteller)
    anfrage = crypto.OCSP_REQUEST_new()
    if not certid or not anfrage:
        if certid:
            crypto.OCSP_CERTID_free(certid)
        if anfrage:
            crypto.OCSP_REQUEST_free(anfrage)
        raise NntpFehler("OCSP-Anfrage nicht baubar")
    if not crypto.OCSP_request_add0_id(anfrage, certid):
        crypto.OCSP_REQUEST_free(anfrage)
        raise NntpFehler("OCSP-Anfrage nicht baubar")
    laenge = crypto.i2d_OCSP_REQUEST(anfrage, None)
    if laenge <= 0:
        crypto.OCSP_REQUEST_free(anfrage)
        raise NntpFehler("OCSP-Anfrage nicht baubar")
    puff = ctypes.create_string_buffer(laenge)
    zeiger = ctypes.c_void_p(ctypes.addressof(puff))
    try:
        if crypto.i2d_OCSP_REQUEST(anfrage, ctypes.byref(zeiger)) != laenge:
            raise NntpFehler("OCSP-Anfrage nicht baubar")
        return puff.raw
    finally:
        crypto.OCSP_REQUEST_free(anfrage)


def ocsp_post(url, anfrage, zeit=10.0):
    """Schickt die Anfrage an den Responder. Nur http und https."""
    import urllib.error
    import urllib.request
    adresse = str(url or "").strip()
    if not adresse.startswith(("http://", "https://")):
        raise NntpFehler("OCSP-Responder braucht http oder https")
    ruf = urllib.request.Request(adresse, data=anfrage, method="POST", headers={
        "Content-Type": "application/ocsp-request", "Accept": "application/ocsp-response"})
    try:
        with urllib.request.urlopen(ruf, timeout=zeit) as antwort:
            return antwort.read(65536)
    except (OSError, urllib.error.URLError) as fehler:
        grund = getattr(fehler, "reason", fehler)
        raise NntpFehler("OCSP-Responder nicht erreichbar: %s" % str(grund)[:160]) from fehler


def ocsp_vom_responder(blatt_der, aussteller_der, url, zeit=10.0):
    """Fragt den konfigurierten Responder und prüft die Antwort wie einen Staple."""
    paar = _openssl()
    if not paar:
        raise NntpFehler("OCSP-Responder nicht prüfbar")
    _, crypto = paar
    blatt, aussteller = _x509_aus_der(crypto, blatt_der), _x509_aus_der(crypto, aussteller_der)
    if not blatt or not aussteller:
        if blatt:
            crypto.X509_free(blatt)
        if aussteller:
            crypto.X509_free(aussteller)
        raise NntpFehler("OCSP-Responder nicht prüfbar")
    try:
        anfrage = ocsp_anfrage(crypto, blatt, aussteller)
        antwort = ocsp_post(url, anfrage, zeit)
        if not antwort:
            raise NntpFehler("OCSP-Responder ohne Antwort")
        return _ocsp_auswerten(crypto, antwort, blatt, aussteller, (), blatt_der, quelle="Responder")
    finally:
        crypto.X509_free(blatt)
        crypto.X509_free(aussteller)


def ocsp_abfragen(verbindung, url, zeit=10.0):
    """Kein Staple: Blatt und Aussteller der Sitzung beim Responder nachfragen."""
    paar = _openssl()
    if not paar:
        raise NntpFehler("OCSP-Responder nicht prüfbar")
    lib, crypto = paar
    zeiger = _ssl_zeiger(verbindung, lib)
    stapel = lib.SSL_get0_verified_chain(zeiger) if zeiger else None
    anzahl = crypto.OPENSSL_sk_num(stapel) if stapel else 0
    if anzahl < 1:
        raise NntpFehler("OCSP-Responder ohne Zertifikat")
    blatt = crypto.OPENSSL_sk_value(stapel, 0)
    aussteller = crypto.OPENSSL_sk_value(stapel, 1) if anzahl > 1 else blatt
    blatt_der = _der_von_x509(crypto, blatt)
    aussteller_der = _der_von_x509(crypto, aussteller)
    if not blatt_der or not aussteller_der:
        raise NntpFehler("OCSP-Responder nicht prüfbar")
    return ocsp_vom_responder(blatt_der, aussteller_der, url, zeit)


def ocsp_nach_handshake(verbindung, werte, zeit=10.0):
    """Wendet den konfigurierten Modus auf die gelesene Antwort an.

    Fehlt der Staple und ist ein Responder eingetragen, wird der gefragt."""
    modus = ocsp_modus(werte)
    if modus == "aus":
        return ""
    if str(werte.get("ssl", "1")) != "1":
        if modus == "pflicht":
            raise NntpFehler("OCSP-Staple braucht SSL")
        return ""
    text = ocsp_stand(verbindung)
    adresse = str((werte or {}).get("ocsp_url") or "").strip()
    if text == "kein OCSP-Staple" and adresse:
        text = ocsp_abfragen(verbindung, adresse, zeit)
    if modus == "pflicht" and text == "kein OCSP-Staple":
        raise NntpFehler("OCSP-Staple fehlt")
    return text


def artikel_vorhanden(werte, message_ids, zeit=10.0):
    """Prueft per STAT, ob Message-IDs beim konfigurierten NNTP-Server vorhanden sind. message_ids: Liste
    von reinen Strings oder (message_id, gruppe)-Tupeln (GROUP wird einmal je Newsgroup gesendet, Gruppen
    aus nzb_lesen.stichprobe()). Verbindung wird fuer alle Stichproben wiederverwendet, nicht pro Artikel
    neu aufgebaut. Wirft nie - bei Verbindungs-/Auth-Fehler werden alle angefragten IDs als None
    (unbekannt, nicht 'fehlt') zurueckgegeben, damit ein Provider-Ausfall nicht alle Kandidaten faelschlich
    als kaputt markiert."""
    eintraege = [(e, "") if isinstance(e, str) else e for e in message_ids]
    if not eintraege:
        return {}
    try:
        nntp = _nntp_verbinden(werte, zeit)
    except NntpFehler:
        return {mid: None for mid, _ in eintraege}
    ergebnis = {}
    gruppe_aktiv = None
    try:
        for message_id, gruppe in eintraege:
            try:
                if gruppe and gruppe != gruppe_aktiv:
                    nntp.senden("GROUP " + gruppe)
                    gruppe_aktiv = gruppe
                kennung = message_id if message_id.startswith("<") else "<%s>" % message_id
                antwort = nntp.senden("STAT " + kennung)
                ergebnis[message_id] = antwort.startswith("223")
            except OSError:
                ergebnis[message_id] = None
    finally:
        nntp.schliessen()
    for message_id, _ in eintraege:
        ergebnis.setdefault(message_id, None)
    return ergebnis
