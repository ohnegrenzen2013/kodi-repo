"""Termux: Befehle, Werkzeuge und die RUN_COMMAND-Bruecke (nur lesend).

  GET /api/termux   Stand der Termux-Installation, Werkzeuge und feste Befehlsliste

H0rSt fuehrt auf dem Server nichts aus. Die App schickt einen gewaehlten Befehl ueber die
vorhandene Bruecke an Termux; freie Kommandozeilen werden nicht angenommen.
"""

from . import termux


class TermuxMixin:

    def termux_lesen(self):
        return 200, "application/json", termux.zustand()
