"""Termux anbinden: Befehle, Werkzeuge und die RUN_COMMAND-Bruecke der Android-App.

Vorbild: termux/termux-app (GPL-3.0). H0rSt startet Termux nicht selbst und fuehrt auf dem
Server nichts aus. Es erkennt eine Termux-Installation (TERMUX_VERSION/TERMUX_APP_PID oder
ein PREFIX unter com.termux), prueft, welche
Werkzeuge dort liegen, und liefert eine feste Liste sicherer Befehle. In der H0rSt-App gehen
die Befehle ueber die vorhandene RUN_COMMAND-Bruecke an Termux (TermuxSteuerung.java); im
Browser lassen sie sich kopieren. Freie Kommandozeilen nimmt H0rSt bewusst nicht an.
"""

import os
import shutil

NAME = "Termux"
REPO = "https://github.com/termux/termux-app"
LIZENZ = "GPL-3.0"
PAKET = "com.termux"
PREFIX = "/data/data/com.termux/files/usr"
HOME = "/data/data/com.termux/files/home"
ANLEITUNG = "https://github.com/termux/termux-app/wiki/RUN_COMMAND-Intent"

WERKZEUGE = [
    ("python", "Python", "pkg install -y python"),
    ("pip", "pip", "pkg install -y python"),
    ("git", "Git", "pkg install -y git"),
    ("ffmpeg", "ffmpeg (Download und REC)", "pkg install -y ffmpeg"),
    ("yt-dlp", "yt-dlp (YouTube)", "pkg install -y yt-dlp"),
    ("tmux", "tmux (Hintergrundsitzungen)", "pkg install -y tmux"),
    ("ssh", "OpenSSH", "pkg install -y openssh"),
    ("ollama", "Ollama (lokale KI)", "pkg install -y ollama"),
    ("vxparser", "vxparser (Live-TV und Portale)", "pip install --upgrade vxparser"),
    ("node", "Node.js", "pkg install -y nodejs"),
    ("sqlite3", "SQLite", "pkg install -y sqlite"),
]

BEFEHLE = [
    {"id": "info", "name": "Termux-Info", "gruppe": "Status",
     "befehl": "termux-info 2>&1 | head -n 40", "aendert": False,
     "text": "Version, Android und Paketquellen von Termux."},
    {"id": "werkzeuge", "name": "Werkzeuge pruefen", "gruppe": "Status", "aendert": False,
     "befehl": "for c in python pip git ffmpeg yt-dlp tmux ssh sshd ollama vxparser node sqlite3; do "
               "p=$(command -v \"$c\" 2>/dev/null) && printf '%-10s %s\\n' \"$c\" \"$p\" || printf '%-10s -\\n' \"$c\"; done",
     "text": "Zeigt, welche Werkzeuge installiert sind und wo sie liegen."},
    {"id": "update", "name": "Pakete aktualisieren", "gruppe": "Einrichtung",
     "befehl": "pkg update -y && pkg upgrade -y", "aendert": True,
     "text": "Aktualisiert die Paketlisten und alle installierten Termux-Pakete."},
    {"id": "speicher", "name": "Speicher freigeben", "gruppe": "Einrichtung",
     "befehl": "termux-setup-storage", "aendert": True,
     "text": "Android fragt nach Zugriff auf Fotos, Downloads und Speicher; danach zeigt ~/storage dorthin."},
    {"id": "wake", "name": "Wach halten", "gruppe": "Einrichtung",
     "befehl": "termux-wake-lock", "aendert": True,
     "text": "Verhindert, dass Android Termux und laufende Dienste im Hintergrund beendet."},
    {"id": "unwake", "name": "Wach halten aus", "gruppe": "Einrichtung",
     "befehl": "termux-wake-unlock", "aendert": True,
     "text": "Gibt die Wachhaltung wieder frei."},
    {"id": "python", "name": "Python installieren", "gruppe": "Werkzeuge",
     "befehl": "pkg install -y python", "aendert": True,
     "text": "Python und pip fuer H0rSt, vxparser und eigene Skripte."},
    {"id": "git", "name": "Git installieren", "gruppe": "Werkzeuge",
     "befehl": "pkg install -y git", "aendert": True,
     "text": "Git fuer Repository-Abgleich und die KI-Freigabe."},
    {"id": "ffmpeg", "name": "ffmpeg installieren", "gruppe": "Werkzeuge",
     "befehl": "pkg install -y ffmpeg", "aendert": True,
     "text": "Noetig fuer YouTube-Download und REC auf dem Geraet."},
    {"id": "ytdlp", "name": "yt-dlp installieren", "gruppe": "Werkzeuge",
     "befehl": "pkg install -y yt-dlp", "aendert": True,
     "text": "YouTube-Suche, Abos, Live, Shorts und Wiedergabe."},
    {"id": "tmux", "name": "tmux installieren", "gruppe": "Werkzeuge",
     "befehl": "pkg install -y tmux", "aendert": True,
     "text": "Hintergrundsitzungen, in denen vxparser und andere Dienste laufen."},
    {"id": "openssh", "name": "OpenSSH installieren", "gruppe": "Werkzeuge",
     "befehl": "pkg install -y openssh", "aendert": True,
     "text": "SSH-Server und ssh-Befehl; der Startbefehl steht darunter."},
    {"id": "sshd", "name": "SSH starten", "gruppe": "Dienste",
     "befehl": "command -v sshd >/dev/null 2>&1 || pkg install -y openssh\nsshd", "aendert": True,
     "text": "Startet den SSH-Server auf Port 8022 (Termux-Standard)."},
    {"id": "ollama", "name": "Ollama installieren", "gruppe": "Dienste",
     "befehl": "pkg install -y ollama", "aendert": True,
     "text": "Lokale KI fuer den Modus Ollama; H0rSt verbindet sich danach auf 127.0.0.1:11434."},
    {"id": "vxparser", "name": "vxparser installieren", "gruppe": "Dienste",
     "befehl": "python -m pip install --upgrade vxparser", "aendert": True,
     "text": "Installiert oder aktualisiert vxparser; Start und Menue stehen im vxparser-Kasten."},
    {"id": "node", "name": "Node.js installieren", "gruppe": "Werkzeuge",
     "befehl": "pkg install -y nodejs", "aendert": True,
     "text": "Node.js fuer Werkzeuge, die JavaScript brauchen."},
    {"id": "sqlite", "name": "SQLite installieren", "gruppe": "Werkzeuge",
     "befehl": "pkg install -y sqlite", "aendert": True,
     "text": "sqlite3 fuer lokale Datenbanken und Pruefungen."},
]

GRUPPEN = ["Status", "Einrichtung", "Werkzeuge", "Dienste"]


class TermuxFehler(ValueError):
    pass


def _umgebung(umgebung=None):
    return umgebung if umgebung is not None else os.environ


def termux_aktiv(umgebung=None):
    env = _umgebung(umgebung)
    if env.get("TERMUX_VERSION") or env.get("TERMUX_APP_PID"):
        return True
    # PREFIX allein setzen auch andere Umgebungen; erst der Termux-Paketpfad macht daraus Termux.
    prefix = str(env.get("PREFIX") or "")
    return bool(PAKET in prefix and os.path.isdir(prefix))


def werkzeuge(umgebung=None, which=None):
    """Welche Werkzeuge liegen in Termux? which/umgebung sind fuer Tests austauschbar."""
    env = _umgebung(umgebung)
    prefix = str(env.get("PREFIX") or PREFIX)
    finden = which or shutil.which
    ergebnis = []
    for kennung, name, paket in WERKZEUGE:
        pfad = ""
        try:
            pfad = finden(kennung) or ""
        except (OSError, TypeError):
            pfad = ""
        if not pfad:
            kandidat = os.path.join(prefix, "bin", kennung)
            if os.path.isfile(kandidat):
                pfad = kandidat
        ergebnis.append({"id": kennung, "name": name, "paket": paket, "pfad": pfad, "da": bool(pfad)})
    return ergebnis


def befehl(kennung):
    for eintrag in BEFEHLE:
        if eintrag["id"] == kennung:
            return dict(eintrag)
    raise TermuxFehler("Unbekannter Termux-Befehl: %s" % kennung)


def zustand(umgebung=None, which=None):
    env = _umgebung(umgebung)
    aktiv = termux_aktiv(env)
    # Nur in Termux beschreibt shutil.which die Termux-Werkzeuge. Ausserhalb (Docker, Pi,
    # Android-App) waeren es die Werkzeuge des Servers bzw. Android-Systembinaries.
    gefunden = werkzeuge(env, which) if aktiv else []
    return {
        "name": NAME, "termux": aktiv, "paket": PAKET,
        "prefix": str(env.get("PREFIX") or PREFIX),
        "home": str(env.get("HOME") or HOME),
        "version": str(env.get("TERMUX_VERSION") or ""),
        "werkzeuge": gefunden, "werkzeuge_da": sum(1 for w in gefunden if w["da"]),
        "werkzeuge_bekannt": aktiv,
        "befehle": BEFEHLE, "gruppen": GRUPPEN,
        "repo": REPO, "lizenz": LIZENZ, "anleitung": ANLEITUNG,
        "hinweis": ("Termux erkannt: Befehle lassen sich hier direkt ausfuehren."
                    if aktiv else
                    "H0rSt laeuft nicht in Termux. In der App gehen die Befehle an die "
                    "Termux-App auf demselben Geraet, im Browser lassen sie sich kopieren. "
                    "Der Werkzeugstand ist nur in Termux bekannt; in der App zeigt ihn "
                    "\"Werkzeuge pruefen\"."),
    }
