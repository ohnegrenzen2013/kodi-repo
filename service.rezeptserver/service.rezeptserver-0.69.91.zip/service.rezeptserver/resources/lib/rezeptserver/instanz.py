"""Nur eine Instanz je Nutzerdaten-Datei: zwei H0rSt auf derselben Datenbank gaebe es sonst.

Zwei Server auf derselben SQLite-Datei schreiben gleichzeitig (Anbieter, Einstellungen, Verlauf) und
belegen dieselben Ports. Die Sperre ist eine Dateisperre neben der Datenbank (`nutzerdaten.db.sperre`):
Sie gilt fuer alle Prozesse desselben Systems, haelt nur, solange der Prozess lebt, und braucht keine
Aufraeumroutine. Geprueft wird vor dem Aufbau des Servers in Dienst.starte(); damit gilt sie fuer
Kommandozeile, Raspberry Pi, Docker, Kodi, Termux und die Android-App gleichermassen.
"""

import errno
import logging
import os

log = logging.getLogger("rezeptserver")

ENDUNG = ".sperre"


class InstanzFehler(RuntimeError):
    """H0rSt laeuft fuer diese Nutzerdaten bereits."""


def pfad(datenbank):
    """Sperrdatei neben der Nutzerdaten-Datei (alte .../konfig.json zeigen auf nutzerdaten.db)."""
    return datenbank + ENDUNG


class Sperre:
    """Dateisperre fuer eine Nutzerdaten-Datei; erwerben() oder mit with benutzen."""

    def __init__(self, datenbank):
        self.datenbank = datenbank
        self.pfad = pfad(datenbank)
        self._datei = None

    def erwerben(self):
        if self._datei is not None:
            return self
        os.makedirs(os.path.dirname(os.path.abspath(self.pfad)), exist_ok=True)
        datei = os.open(self.pfad, os.O_RDWR | os.O_CREAT, 0o600)
        try:
            _sperren(datei)
        except OSError as fehler:
            fremd = _pid(datei)
            os.close(datei)
            if fehler.errno not in (errno.EACCES, errno.EAGAIN, errno.EWOULDBLOCK, errno.EDEADLK):
                raise
            raise InstanzFehler("H0rSt laeuft bereits%s (Sperre %s)" % (
                " als Prozess %s" % fremd if fremd else "", self.pfad)) from None
        try:
            os.ftruncate(datei, 0)
            os.write(datei, ("%d\n" % os.getpid()).encode("ascii"))
        except OSError:  # die Sperre haelt auch ohne Prozessnummer; sie ist nur fuer die Meldung da
            log.warning("Prozessnummer nicht in die Sperre %s geschrieben", self.pfad)
        self._datei = datei
        return self

    def gib_frei(self):
        datei, self._datei = self._datei, None
        if datei is None:
            return
        try:
            _entsperren(datei)
        finally:
            os.close(datei)

    def __enter__(self):
        return self.erwerben()

    def __exit__(self, *fehler):
        self.gib_frei()


try:
    import fcntl
except ImportError:  # Windows
    fcntl = None


def _sperren(datei):
    if fcntl is not None:
        fcntl.flock(datei, fcntl.LOCK_EX | fcntl.LOCK_NB)
        return
    import msvcrt
    os.lseek(datei, 0, os.SEEK_SET)
    msvcrt.locking(datei, msvcrt.LK_NBLCK, 1)


def _entsperren(datei):
    if fcntl is not None:
        fcntl.flock(datei, fcntl.LOCK_UN)
        return
    import msvcrt
    os.lseek(datei, 0, os.SEEK_SET)
    msvcrt.locking(datei, msvcrt.LK_UNLCK, 1)


def _pid(datei):
    try:
        os.lseek(datei, 0, os.SEEK_SET)
        roh = os.read(datei, 64).decode("ascii", "replace").strip()
    except OSError:
        return ""
    return roh if roh.isdigit() else ""
