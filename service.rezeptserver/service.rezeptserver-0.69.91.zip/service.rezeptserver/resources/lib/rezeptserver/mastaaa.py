"""Mastaaa1987.github.io anbinden: Kodi-Repository, Vavoo-veclist und vxparser-Anleitung.

Vorbild und Quelle: Mastaaa1987/Mastaaa1987.github.io (keine Lizenzdatei). Die Seite ist ein
GitHub-Pages-Repository mit einem Kodi-Repository (VAVOO.TO, xStream, MastaaaTV Installer,
SlyGuy/xVault, Michaz), einer Vavoo-Senderliste fuer vxparser, der vxparser-Anleitung und
Build-Releases. H0rSt laedt keine Sammelbuilds automatisch. Es prueft addons.xml und veclist,
zeigt die Addons und traegt das Repository auf Wunsch als Kodi-Quelle ein. Die Funktionen des
mitgelieferten SQL.js-Demos sind bewusst nicht uebernommen (kein Bezug zu H0rSt).

  GET  /api/mastaaa                 Quellen, Addons aus der mitgelieferten addons.xml, vxparser
  POST /api/mastaaa                 {aktion: pruefen | kodi_quelle}
"""

import hashlib
import json
import urllib.request
import xml.etree.ElementTree as ET

from .netz import USER_AGENT

NAME = "Mastaaa1987"
SEITE = "https://mastaaa1987.github.io/"
REPO = "https://github.com/Mastaaa1987/Mastaaa1987.github.io"
REPO_URL = "https://mastaaa1987.github.io/repo/"
ADDONS_XML = REPO_URL + "addons.xml"
VECLIST = REPO_URL + "veclist.json"
ANLEITUNG = SEITE + "vxparser/"
VX_APK = SEITE + "vxparser.apk"
BUILDS = REPO + "/releases"
LIZENZ = "keine Lizenzdatei"
ZEITGRENZE = 10.0
ZEITGRENZE_VECLIST = 30.0  # die veclist ist rund 5 MB gross und braucht laenger als addons.xml
MAX_XML = 1024 * 1024
MAX_VECLIST = 8 * 1024 * 1024

ARTEN = {"repository": "Kodi-Repository", "addons": "addons.xml", "veclist": "Vavoo-Liste",
         "anleitung": "vxparser-Anleitung", "apk": "vxparser-APK", "builds": "Builds"}

QUELLEN = [
    {"id": "mastaaa-repo", "name": "Mastaaa Repository", "art": "repository", "url": REPO_URL,
     "addons": ADDONS_XML, "hinweis": "Als Kodi-Quelle eintragen; das Repository bringt VAVOO.TO, "
     "xStream, MastaaaTV Installer, SlyGuy, xVault und Michaz mit."},
    {"id": "mastaaa-addons", "name": "Mastaaa addons.xml", "art": "addons", "url": ADDONS_XML,
     "hinweis": "Katalog aller Addons im Repository, mit Version und Kurzbeschreibung."},
    {"id": "mastaaa-veclist", "name": "Vavoo-veclist", "art": "veclist", "url": VECLIST,
     "hinweis": "Verschluesselte Vavoo-Senderliste, die vxparser als Link vavoo_veclist liest."},
    {"id": "mastaaa-vxparser", "name": "vxparser-Anleitung", "art": "anleitung", "url": ANLEITUNG,
     "hinweis": "Schritt fuer Schritt mit Screenshots: Termux vorbereiten, vxparser starten, TiviMate."},
    {"id": "mastaaa-apk", "name": "vxparser-APK (Termux)", "art": "apk", "url": VX_APK,
     "hinweis": "Fertige Termux-App mit vxparser; H0rSt installiert sie nur nach Klick in der App."},
    {"id": "mastaaa-builds", "name": "Builds und Testfassungen", "art": "builds", "url": BUILDS,
     "hinweis": "Offizielle Release-Seite. H0rSt laedt keine Sammelbuilds automatisch."},
]


class MastaaaFehler(ValueError):
    pass


def _grenzen(url):
    """Zeitgrenze und Groessenlimit passend zur Quelle (veclist ist deutlich groesser)."""
    if str(url).endswith("veclist.json"):
        return ZEITGRENZE_VECLIST, MAX_VECLIST
    return ZEITGRENZE, MAX_XML


def _holen(url, zeitgrenze=None, grenze=None):
    standard_zeit, standard_grenze = _grenzen(url)
    zeitgrenze = standard_zeit if zeitgrenze is None else zeitgrenze
    grenze = standard_grenze if grenze is None else grenze
    anfrage = urllib.request.Request(url, headers={"User-Agent": USER_AGENT})
    with urllib.request.urlopen(anfrage, timeout=zeitgrenze) as antwort:
        status = int(getattr(antwort, "status", 0) or antwort.getcode() or 0)
        inhalt = antwort.read(grenze + 1)
    if len(inhalt) > grenze:
        raise MastaaaFehler("Antwort groesser als %d Byte" % grenze)
    return status, inhalt


def _text(daten, grenze=None):
    if isinstance(daten, bytes):
        text = daten.decode("utf-8-sig", "replace")
    else:
        text = str(daten or "")
    if grenze and len(text.encode("utf-8")) > grenze:
        raise MastaaaFehler("Antwort groesser als %d Byte" % grenze)
    return text


def addons_lesen(daten):
    """addons.xml in eine Liste {id, name, version, provider, summary, license} verwandeln."""
    text = _text(daten, MAX_XML)
    try:
        wurzel = ET.fromstring(text)
    except ET.ParseError as fehler:
        raise MastaaaFehler("addons.xml nicht lesbar: %s" % fehler)
    if wurzel.tag != "addons":
        raise MastaaaFehler("addons.xml hat kein <addons>-Wurzelelement")
    ergebnis = []
    for addon in wurzel.findall("addon"):
        kennung = str(addon.get("id") or "").strip()
        if not kennung:
            continue
        summary = license_ = ""
        for erweiterung in addon.findall("extension"):
            if erweiterung.get("point") != "xbmc.addon.metadata":
                continue
            summary = (erweiterung.findtext("summary[@lang='de_DE']")
                       or erweiterung.findtext("summary[@lang='en_GB']")
                       or erweiterung.findtext("summary") or "")
            license_ = erweiterung.findtext("license") or ""
            break
        ergebnis.append({
            "id": kennung, "name": str(addon.get("name") or kennung),
            "version": str(addon.get("version") or ""),
            "provider": str(addon.get("provider-name") or ""),
            "summary": " ".join(str(summary).split())[:240],
            "license": " ".join(str(license_).split())[:80],
        })
    ergebnis.sort(key=lambda a: a["name"].lower())
    return ergebnis


def veclist_lesen(daten):
    """Vavoo-veclist zusammenfassen; die verschluesselten Werte selbst bleiben unangetastet."""
    roh = _text(daten, MAX_VECLIST)
    try:
        daten = json.loads(roh)
    except ValueError:
        raise MastaaaFehler("veclist.json ist kein JSON")
    werte = daten.get("value") if isinstance(daten, dict) else None
    if not isinstance(werte, list):
        raise MastaaaFehler("veclist.json hat keine Liste unter 'value'")
    return {"eintraege": len(werte), "bytes": len(roh.encode("utf-8")),
            "sha256": hashlib.sha256(roh.encode("utf-8")).hexdigest()[:16]}


def pruefen(holen=None):
    """addons.xml und veclist frisch holen und auswerten. holen(url) -> (status, bytes)."""
    holen = holen or _holen
    ergebnis = {"stand": "", "addons_xml": {"url": ADDONS_XML, "status": 0, "erreichbar": False,
                                             "anzahl": 0, "fehler": ""},
                "addons": [], "veclist": {"url": VECLIST, "status": 0, "erreichbar": False,
                                           "eintraege": 0, "fehler": ""},
                "fehler": []}
    try:
        status, inhalt = holen(ADDONS_XML)
        ergebnis["addons_xml"]["status"] = int(status)
        ergebnis["addons_xml"]["erreichbar"] = 200 <= int(status) < 400
        if ergebnis["addons_xml"]["erreichbar"] and inhalt:
            addons = addons_lesen(inhalt)
            ergebnis["addons"] = addons
            ergebnis["addons_xml"]["anzahl"] = len(addons)
        elif not ergebnis["addons_xml"]["erreichbar"]:
            ergebnis["fehler"].append("addons.xml: HTTP %s" % status)
    except (OSError, ValueError, MastaaaFehler) as fehler:
        ergebnis["addons_xml"]["fehler"] = str(fehler)
        ergebnis["fehler"].append("addons.xml: %s" % fehler)
    try:
        status, inhalt = holen(VECLIST)
        ergebnis["veclist"]["status"] = int(status)
        ergebnis["veclist"]["erreichbar"] = 200 <= int(status) < 400
        if ergebnis["veclist"]["erreichbar"] and inhalt:
            ergebnis["veclist"].update(veclist_lesen(inhalt))
        elif not ergebnis["veclist"]["erreichbar"]:
            ergebnis["fehler"].append("veclist: HTTP %s" % status)
    except (OSError, ValueError, MastaaaFehler) as fehler:
        ergebnis["veclist"]["fehler"] = str(fehler)
        ergebnis["fehler"].append("veclist: %s" % fehler)
    ergebnis["stand"] = "geprueft"
    return ergebnis


def _lokale_addons():
    """Mitgelieferter Katalog fuer die Anzeige ohne Netz (nur lesen, keine Verbindung)."""
    import os
    pfad = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))),
                        "Mastaaa1987.github.io", "repo", "addons.xml")
    try:
        with open(pfad, "rb") as f:
            return addons_lesen(f.read())
    except (OSError, MastaaaFehler):
        return []


def kodi_quelle():
    return {"name": "Mastaaa Repository", "url": REPO_URL, "addons": ADDONS_XML}


def vxparser():
    return {"veclist": VECLIST, "anleitung": ANLEITUNG, "apk": VX_APK, "repo": REPO}


def zustand(pruefen_lassen=False, holen=None):
    daten = {"name": NAME, "seite": SEITE, "repo": REPO, "lizenz": LIZENZ,
             "arten": ARTEN, "quellen": QUELLEN, "kodi": kodi_quelle(), "vxparser": vxparser(),
             "addons": _lokale_addons(), "addons_xml": {"url": ADDONS_XML, "status": 0,
                                                         "erreichbar": None, "anzahl": 0, "fehler": ""},
             "veclist": {"url": VECLIST, "status": 0, "erreichbar": None, "eintraege": 0, "fehler": ""},
             "fehler": [], "stand": "mitgeliefert",
             "hinweis": "Das Repository wird als Kodi-Quelle eingetragen; Builds und APK nur verlinkt. "
                        "Fremde Addons stehen unter ihren eigenen Lizenzen."}
    if pruefen_lassen:
        daten.update(pruefen(holen=holen))
        if not daten["addons"]:
            daten["addons"] = _lokale_addons()
    return daten
