"""Kuratierter Stremio-Community-Addon-Katalog: Liste, Installation und Entfernen."""

import json

from . import community_addons
from .anbindungen_grund import _basis, _host, eigene
from .anbindungen_heimserver import emby_anmelden, emby_ich
from .netz import Abrufer, urllib_holen


class CommunityAddonsMixin:
    def community_addons_lesen(self, werte):
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        vorhanden = community_addons.installiert(daten)
        eintraege = []
        for eintrag in community_addons.liste(werte.get("q", ""), werte.get("typ", "")):
            m = eintrag["manifest"]
            eintraege.append({"transportUrl": eintrag["transportUrl"], "manifest": m,
                              "empfohlen": bool(eintrag.get("empfohlen")),
                              "installiert": eintrag["transportUrl"] in vorhanden,
                              "anbieter_id": vorhanden.get(eintrag["transportUrl"], "")})
        return 200, "application/json", {"quelle": community_addons.daten().get("quelle", ""),
                                         "geprueft": community_addons.daten().get("geprueft", ""),
                                         "hinweis": community_addons.daten().get("hinweis", ""),
                                         "addons": eintraege}

    def community_addons_post(self, koerper):
        if not self.app.verwaltung:
            return 503, "application/json", {"fehler": "Anbieter-Verwaltung nicht verfuegbar"}
        if not self.darf("anbieter"):
            return 403, "application/json", {"fehler": "Kein Recht auf Anbieter", "recht": True}
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
        except (ValueError, UnicodeDecodeError):
            return 400, "application/json", {"fehler": "JSON-Fehler"}
        if not isinstance(wunsch, dict):
            return 400, "application/json", {"fehler": "JSON-Objekt erwartet"}
        try:
            aktion = str(wunsch.get("aktion") or "")
            verwaltung = self.app.verwaltung
            if aktion == "grundausstattung":
                ids = verwaltung.aendern(lambda d: community_addons.grundausstattung(d, verwaltung.module))
                return 200, "application/json", {"ok": True, "neu": len(ids or []), "ids": ids or []}
            if aktion == "emby":
                zugang = self._emby_zugang(wunsch)
                url = community_addons.streambridge_adresse(zugang["server"], zugang["user_id"], zugang["token"])
                aid = ""
                if wunsch.get("eintragen", True):
                    aid = verwaltung.aendern(lambda d: community_addons.einrichten(
                        d, verwaltung.module, "StreamBridge", url, "streambridge.baby-beamup.club"))
                return 200, "application/json", {"ok": True, "anbieter_id": aid, "url": url, "name": zugang["name"]}
            if aktion == "streambridge":
                url = community_addons.streambridge_adresse(wunsch.get("server"), wunsch.get("user_id"), wunsch.get("token"))
                aid = ""
                if wunsch.get("eintragen", True):
                    aid = verwaltung.aendern(lambda d: community_addons.einrichten(
                        d, verwaltung.module, "StreamBridge", url, "streambridge.baby-beamup.club"))
                return 200, "application/json", {"ok": True, "anbieter_id": aid, "url": url}
            if aktion == "trakt":
                def _trakt(d):
                    url = community_addons.trakt_addon_adresse(d)
                    return community_addons.einrichten(d, verwaltung.module, "Trakt Tv", url, "trakt.baby-beamup.club")
                aid = verwaltung.aendern(_trakt)
                return 200, "application/json", {"ok": True, "anbieter_id": aid}
            if aktion == "installieren":
                anbieter_id = verwaltung.aendern(lambda d: community_addons.installieren(
                    d, verwaltung.module, wunsch.get("url", "")))
                return 200, "application/json", {"ok": True, "anbieter_id": anbieter_id}
            if aktion == "entfernen":
                verwaltung.aendern(lambda d: community_addons.entfernen(d, wunsch.get("id")))
                return 200, "application/json", {"ok": True}
            return 400, "application/json", {"fehler": "aktion: installieren, entfernen, grundausstattung, streambridge, emby oder trakt"}
        except (ValueError, FileNotFoundError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}

    def _emby_zugang(self, wunsch):
        """Benutzer und Passwort an der Emby-API, sonst der schon eingetragene Emby (API-Schlüssel, /Users/Me)."""
        holen = getattr(self.app.verwaltung, "holen", None) or urllib_holen
        server = str(wunsch.get("server") or "").strip()
        benutzer = str(wunsch.get("user") or "").strip()
        if server or benutzer:
            url = _basis(server)
            return emby_anmelden(url, benutzer, str(wunsch.get("pass") or ""), Abrufer([_host(url)], holen=holen))
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        for _aid, _eintrag, werte in eigene(daten, "emby"):
            if werte.get("url") and werte.get("api_key"):
                url = _basis(werte["url"])
                return emby_ich(url, werte["api_key"], Abrufer([_host(url)], holen=holen))
        raise ValueError("Kein Emby eingetragen. Adresse und Benutzer angeben.")
