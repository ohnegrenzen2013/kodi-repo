"""Mastaaa1987.github.io: Kodi-Repository, Vavoo-veclist und vxparser-Anleitung.

  GET  /api/mastaaa   Quellen, mitgelieferte Addons und vxparser-Hinweise
  POST /api/mastaaa   {aktion: pruefen | kodi_quelle}
"""

from . import kodi_addons, mastaaa

from .oberflaeche_grund import json


class MastaaaMixin:

    def mastaaa_lesen(self):
        return 200, "application/json", mastaaa.zustand()

    def mastaaa_post(self, koerper):
        try:
            wunsch = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(wunsch, dict):
                raise mastaaa.MastaaaFehler("JSON-Objekt erwartet")
            aktion = wunsch.get("aktion")
            if aktion == "pruefen":
                return 200, "application/json", mastaaa.zustand(pruefen_lassen=True)
            if aktion == "kodi_quelle":
                kodi = self._kodiaddons()
                quelle = kodi.quelle_hinzufuegen(mastaaa.REPO_URL, "Mastaaa Repository")
                return 200, "application/json", {
                    "ok": True, "quelle": quelle, "uebersicht": kodi.uebersicht(),
                    "addons": mastaaa.zustand()["addons"],
                    "meldung": "Mastaaa Repository ist als Kodi-Quelle eingetragen. "
                               "Unter Kodi-Addons → Addon holen die gewünschte Erweiterung wählen.",
                }
            raise mastaaa.MastaaaFehler("aktion: pruefen oder kodi_quelle")
        except (ValueError, UnicodeDecodeError, kodi_addons.KodiFehler) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
