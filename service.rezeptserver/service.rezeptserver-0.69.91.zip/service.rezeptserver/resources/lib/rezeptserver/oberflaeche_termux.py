"""Termux: Befehle, Werkzeuge und die RUN_COMMAND-Bruecke.

  GET  /api/termux   Stand der Termux-Installation, Werkzeuge und feste Befehlsliste
  POST /api/termux   {aktion, text} -> {ok, text}; nur feste Aktionen, nur in Termux

Laeuft H0rSt selbst in Termux, fuehrt der Server die festen Aktionen aus (termux.ausfuehren).
Sonst bleibt es beim Kopieren bzw. bei der Bruecke der H0rSt-App; freie Kommandozeilen werden
nicht angenommen.
"""

import json

from . import termux


class TermuxMixin:

    def termux_lesen(self):
        return 200, "application/json", termux.zustand()

    def termux_ausfuehren(self, koerper):
        try:
            daten = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(daten, dict):
                raise ValueError("JSON-Objekt erwartet")
        except (ValueError, UnicodeDecodeError) as f:
            return 400, "application/json", {"fehler": "Ungültige Anfrage: %s" % f}
        return 200, "application/json", termux.ausfuehren(str(daten.get("aktion") or ""),
                                                          str(daten.get("text") or ""))
