"""Termux anbinden: Befehle, Werkzeuge und die RUN_COMMAND-Bruecke der Android-App.

Vorbild: termux/termux-app (GPL-3.0). H0rSt startet Termux nicht selbst. Es erkennt eine
Termux-Installation (TERMUX_VERSION/TERMUX_APP_PID oder ein PREFIX unter com.termux), prueft,
welche Werkzeuge dort liegen, und liefert eine feste Liste sicherer Befehle. Laeuft H0rSt selbst
in Termux, fuehrt der Server genau diese festen Aktionen aus (ausfuehren()). In der H0rSt-App
gehen sie ueber die RUN_COMMAND-Bruecke an Termux (TermuxSteuerung.java); im Browser lassen sie
sich kopieren. Freie Kommandozeilen nimmt H0rSt bewusst nicht an.
"""

import os
import shutil
import subprocess

NAME = "Termux"
REPO = "https://github.com/termux/termux-app"
LIZENZ = "GPL-3.0"
PAKET = "com.termux"
PREFIX = "/data/data/com.termux/files/usr"
HOME = "/data/data/com.termux/files/home"
ANLEITUNG = "https://github.com/termux/termux-app/wiki/RUN_COMMAND-Intent"

WERKZEUGE = [
    ("python", "Python", "pkg install -y python"),
    ("pip", "pip", "pkg install -y python"),
    ("git", "Git", "pkg install -y git"),
    ("ffmpeg", "ffmpeg (Download und REC)", "pkg install -y ffmpeg"),
    ("yt-dlp", "yt-dlp (YouTube)", "pkg install -y yt-dlp"),
    ("tmux", "tmux (Hintergrundsitzungen)", "pkg install -y tmux"),
    ("ssh", "OpenSSH", "pkg install -y openssh"),
    ("ollama", "Ollama (lokale KI)", "pkg install -y ollama"),
    ("vxparser", "vxparser (Live-TV und Portale)", "pip install --upgrade vxparser"),
    ("node", "Node.js", "pkg install -y nodejs"),
    ("sqlite3", "SQLite", "pkg install -y sqlite"),
]

BEFEHLE = [
    {"id": "info", "name": "Termux-Info", "gruppe": "Status",
     "befehl": "termux-info 2>&1 | head -n 40", "aendert": False,
     "text": "Version, Android und Paketquellen von Termux."},
    {"id": "werkzeuge", "name": "Werkzeuge pruefen", "gruppe": "Status", "aendert": False,
     "befehl": "for c in python pip git ffmpeg yt-dlp tmux ssh sshd ollama vxparser node sqlite3; do "
               "p=$(command -v \"$c\" 2>/dev/null) && printf '%-10s %s\\n' \"$c\" \"$p\" || printf '%-10s -\\n' \"$c\"; done",
     "text": "Zeigt, welche Werkzeuge installiert sind und wo sie liegen."},
    {"id": "update", "name": "Pakete aktualisieren", "gruppe": "Einrichtung",
     "befehl": "pkg update -y && pkg upgrade -y", "aendert": True,
     "text": "Aktualisiert die Paketlisten und alle installierten Termux-Pakete."},
    {"id": "speicher", "name": "Speicher freigeben", "gruppe": "Einrichtung",
     "befehl": "termux-setup-storage", "aendert": True,
     "text": "Android fragt nach Zugriff auf Fotos, Downloads und Speicher; danach zeigt ~/storage dorthin."},
    {"id": "wake", "name": "Wach halten", "gruppe": "Einrichtung",
     "befehl": "termux-wake-lock", "aendert": True,
     "text": "Verhindert, dass Android Termux und laufende Dienste im Hintergrund beendet."},
    {"id": "unwake", "name": "Wach halten aus", "gruppe": "Einrichtung",
     "befehl": "termux-wake-unlock", "aendert": True,
     "text": "Gibt die Wachhaltung wieder frei."},
    {"id": "python", "name": "Python installieren", "gruppe": "Werkzeuge",
     "befehl": "pkg install -y python", "aendert": True,
     "text": "Python und pip fuer H0rSt, vxparser und eigene Skripte."},
    {"id": "git", "name": "Git installieren", "gruppe": "Werkzeuge",
     "befehl": "pkg install -y git", "aendert": True,
     "text": "Git fuer Repository-Abgleich und die KI-Freigabe."},
    {"id": "ffmpeg", "name": "ffmpeg installieren", "gruppe": "Werkzeuge",
     "befehl": "pkg install -y ffmpeg", "aendert": True,
     "text": "Noetig fuer YouTube-Download und REC auf dem Geraet."},
    {"id": "ytdlp", "name": "yt-dlp installieren", "gruppe": "Werkzeuge",
     "befehl": "pkg install -y yt-dlp", "aendert": True,
     "text": "YouTube-Suche, Abos, Live, Shorts und Wiedergabe."},
    {"id": "tmux", "name": "tmux installieren", "gruppe": "Werkzeuge",
     "befehl": "pkg install -y tmux", "aendert": True,
     "text": "Hintergrundsitzungen, in denen vxparser und andere Dienste laufen."},
    {"id": "openssh", "name": "OpenSSH installieren", "gruppe": "Werkzeuge",
     "befehl": "pkg install -y openssh", "aendert": True,
     "text": "SSH-Server und ssh-Befehl; der Startbefehl steht darunter."},
    {"id": "sshd", "name": "SSH starten", "gruppe": "Dienste",
     "befehl": "command -v sshd >/dev/null 2>&1 || pkg install -y openssh\nsshd", "aendert": True,
     "text": "Startet den SSH-Server auf Port 8022 (Termux-Standard)."},
    {"id": "ollama", "name": "Ollama installieren", "gruppe": "Dienste",
     "befehl": "pkg install -y ollama", "aendert": True,
     "text": "Lokale KI fuer den Modus Ollama; H0rSt verbindet sich danach auf 127.0.0.1:11434."},
    {"id": "vxparser", "name": "vxparser installieren", "gruppe": "Dienste",
     "befehl": "python -m pip install --upgrade vxparser", "aendert": True,
     "text": "Installiert oder aktualisiert vxparser; Start und Menue stehen im vxparser-Kasten."},
    {"id": "node", "name": "Node.js installieren", "gruppe": "Werkzeuge",
     "befehl": "pkg install -y nodejs", "aendert": True,
     "text": "Node.js fuer Werkzeuge, die JavaScript brauchen."},
    {"id": "sqlite", "name": "SQLite installieren", "gruppe": "Werkzeuge",
     "befehl": "pkg install -y sqlite", "aendert": True,
     "text": "sqlite3 fuer lokale Datenbanken und Pruefungen."},
]

GRUPPEN = ["Status", "Einrichtung", "Werkzeuge", "Dienste"]

# --- Feste Aktionen, die H0rSt in Termux selbst ausfuehren darf (kein freier Shell-Text) ----------
SITZUNG = "vxparser"
TASTEN = frozenset(("Up", "Down", "Left", "Right", "Space", "Enter", "Escape", "BSpace", "Tab", "C-c",
                    "PageUp", "PageDown", "Home", "End"))
ZEITGRENZE = 20
API_ZEITGRENZE = 3 * 60
INSTALL_ZEITGRENZE = 35 * 60
LANGE_BEFEHLE = frozenset(("update", "speicher", "python", "git", "ffmpeg", "ytdlp", "tmux", "openssh", "sshd",
                           "ollama", "vxparser", "node", "sqlite"))

_STATUS = (
    "command -v vxparser >/dev/null 2>&1 || { echo 'vxparser ist in Termux nicht installiert'; exit 1; }\n"
    "if tmux has-session -t " + SITZUNG + " 2>/dev/null; then echo 'vxparser läuft (tmux-Sitzung " + SITZUNG + ")';"
    " else echo 'vxparser läuft nicht'; fi\n"
    "command -v termux-battery-status >/dev/null 2>&1 && echo 'termux-api-Paket: da' || echo 'termux-api-Paket: fehlt'\n"
    "if command -v termux-battery-status >/dev/null 2>&1; then termux-battery-status; fi"
)
_START = (
    "command -v vxparser >/dev/null 2>&1 || { echo 'vxparser ist in Termux nicht installiert'; exit 1; }\n"
    "if command -v termux-wake-lock >/dev/null 2>&1; then termux-wake-lock"
    " || echo 'Wachhalten fehlgeschlagen (Termux:API-App?)';"
    " else echo 'Ohne termux-api schläft das Gerät ein'; fi\n"
    "if tmux has-session -t " + SITZUNG + " 2>/dev/null; then echo 'vxparser läuft bereits';"
    " else tmux new-session -d -s " + SITZUNG + " vxparser && echo 'vxparser gestartet'; fi\n"
    "if command -v termux-notification >/dev/null 2>&1; then "
    "termux-notification --id h0rst-vx --title vxparser --content 'Sitzung läuft' --priority high; fi"
)
_STOPP = (
    "tmux kill-session -t " + SITZUNG + " 2>/dev/null\n"
    "for d in /proc/[0-9]*; do tr '\\0' ' ' < \"$d/cmdline\" 2>/dev/null | grep -q 'bin/vx[p]arser'"
    " && kill \"${d#/proc/}\" 2>/dev/null; done\n"
    "if command -v termux-wake-unlock >/dev/null 2>&1; then termux-wake-unlock; fi\n"
    "if command -v termux-notification-remove >/dev/null 2>&1; then termux-notification-remove h0rst-vx; fi\n"
    "echo 'vxparser gestoppt'"
)
_INSTALLIEREN = (
    "echo 'Installiere native Pakete …'\n"
    "pkg install -y python python-pip tmux rust binutils 2>&1 | tail -n 25\n"
    "command -v vxparser >/dev/null 2>&1 && { echo 'vxparser ist bereits installiert'; exit 0; }\n"
    "echo 'Installiere vxparser (PyPI, kann mehrere Minuten dauern) …'\n"
    "pip install --no-cache-dir vxparser 2>&1 | tail -n 60\n"
    "command -v vxparser >/dev/null 2>&1 && echo 'vxparser installiert'"
    " || { echo 'Installation fehlgeschlagen – siehe Ausgabe oben'; exit 1; }"
)
_API_FEHLT = ("command -v termux-battery-status >/dev/null 2>&1"
              " || { echo 'termux-api-Paket fehlt. „API installieren“ und die App Termux:API.'; exit 1; }\n")
_API_INSTALLIEREN = (
    "if command -v termux-battery-status >/dev/null 2>&1; then echo 'termux-api-Paket ist schon da'; "
    "else echo 'Installiere termux-api …'; pkg install -y termux-api 2>&1 | tail -n 30; fi\n"
    "command -v termux-battery-status >/dev/null 2>&1 && echo 'Paket: da'"
    " || { echo 'Paket: Installation fehlgeschlagen'; exit 1; }\n"
    "echo 'Die App com.termux.api ist getrennt. Ohne sie antworten Akku, WLAN und Wachhalten nicht.'"
)
_OLLAMA_INSTALLIEREN = (
    "command -v ollama >/dev/null 2>&1 && { echo 'Ollama ist bereits installiert'; exit 0; }\n"
    "pkg install -y ollama 2>&1 | tail -n 40\n"
    "command -v ollama >/dev/null 2>&1 && echo 'Ollama installiert' || echo 'Installation fehlgeschlagen – siehe Ausgabe oben'"
)
_NEUSTART = _STOPP + "\nsleep 2\n" + _START
# Diese Aktionen brauchen die H0rSt-App (Android-Intent, Paket-Signaturen, Boot/Widget/Tasker).
_NUR_APP = {
    "oeffnen": "Termux öffnen",
    "dienst": "Hintergrunddienst, Boot und Widget",
    "signatur": "Signaturkonflikt",
    "signatur-sichern": "Signatur sichern",
}


class TermuxFehler(ValueError):
    pass


def _umgebung(umgebung=None):
    return umgebung if umgebung is not None else os.environ


def termux_aktiv(umgebung=None):
    env = _umgebung(umgebung)
    if env.get("TERMUX_VERSION") or env.get("TERMUX_APP_PID"):
        return True
    # PREFIX allein setzen auch andere Umgebungen; erst der Termux-Paketpfad macht daraus Termux.
    prefix = str(env.get("PREFIX") or "")
    return bool(PAKET in prefix and os.path.isdir(prefix))


def werkzeuge(umgebung=None, which=None):
    """Welche Werkzeuge liegen in Termux? which/umgebung sind fuer Tests austauschbar."""
    env = _umgebung(umgebung)
    prefix = str(env.get("PREFIX") or PREFIX)
    finden = which or shutil.which
    ergebnis = []
    for kennung, name, paket in WERKZEUGE:
        pfad = ""
        try:
            pfad = finden(kennung) or ""
        except (OSError, TypeError):
            pfad = ""
        if not pfad:
            kandidat = os.path.join(prefix, "bin", kennung)
            if os.path.isfile(kandidat):
                pfad = kandidat
        ergebnis.append({"id": kennung, "name": name, "paket": paket, "pfad": pfad, "da": bool(pfad)})
    return ergebnis


def befehl(kennung):
    for eintrag in BEFEHLE:
        if eintrag["id"] == kennung:
            return dict(eintrag)
    raise TermuxFehler("Unbekannter Termux-Befehl: %s" % kennung)


def zustand(umgebung=None, which=None):
    env = _umgebung(umgebung)
    aktiv = termux_aktiv(env)
    # Nur in Termux beschreibt shutil.which die Termux-Werkzeuge. Ausserhalb (Docker, Pi,
    # Android-App) waeren es die Werkzeuge des Servers bzw. Android-Systembinaries.
    gefunden = werkzeuge(env, which) if aktiv else []
    return {
        "name": NAME, "termux": aktiv, "paket": PAKET,
        "prefix": str(env.get("PREFIX") or PREFIX),
        "home": str(env.get("HOME") or HOME),
        "version": str(env.get("TERMUX_VERSION") or ""),
        "werkzeuge": gefunden, "werkzeuge_da": sum(1 for w in gefunden if w["da"]),
        "werkzeuge_bekannt": aktiv,
        "befehle": BEFEHLE, "gruppen": GRUPPEN,
        "repo": REPO, "lizenz": LIZENZ, "anleitung": ANLEITUNG,
        "hinweis": ("Termux erkannt: Befehle lassen sich hier direkt ausfuehren."
                    if aktiv else
                    "H0rSt laeuft nicht in Termux. In der App gehen die Befehle an die "
                    "Termux-App auf demselben Geraet, im Browser lassen sie sich kopieren. "
                    "Der Werkzeugstand ist nur in Termux bekannt; in der App zeigt ihn "
                    "\"Werkzeuge pruefen\"."),
    }


def ausfuehren(aktion, text="", umgebung=None, laufen=None):
    """Eine feste Termux-Aktion ausfuehren - nur wenn H0rSt selbst in Termux laeuft.

    laufen und umgebung sind fuer Tests austauschbar. Freie Kommandozeilen gibt es nicht:
    aktion ist eine feste Kennung, text nur bei taste/text/befehl erlaubt.
    """
    env = _umgebung(umgebung)
    if not termux_aktiv(env):
        return {"ok": False, "text": "H0rSt läuft nicht in Termux. In der App gehen die Befehle an die "
                                    "Termux-App; hier lassen sie sich nur kopieren."}
    text = "" if text is None else str(text)
    pfad = str(env.get("PREFIX") or PREFIX)
    home = str(env.get("HOME") or HOME)
    bash = os.path.join(pfad, "bin", "bash")
    tmux = os.path.join(pfad, "bin", "tmux")

    if aktion in _NUR_APP:
        return {"ok": False, "text": "„%s“ geht nur in der H0rSt-App." % _NUR_APP[aktion]}
    if aktion == "befehl":
        try:
            eintrag = befehl(text)
        except TermuxFehler as f:
            return {"ok": False, "text": str(f)}
        befehl_pfad, argumente = bash, ["-c", eintrag["befehl"]]
        frist = INSTALL_ZEITGRENZE if text in LANGE_BEFEHLE else ZEITGRENZE
    elif aktion == "taste":
        if text not in TASTEN:
            return {"ok": False, "text": "Unbekannte Taste: " + text}
        befehl_pfad, argumente, frist = tmux, ["send-keys", "-t", SITZUNG, text], ZEITGRENZE
    elif aktion == "text":
        if not text or len(text) > 500:
            return {"ok": False, "text": "Text fehlt oder ist zu lang"}
        befehl_pfad, argumente, frist = tmux, ["send-keys", "-t", SITZUNG, "-l", "--", text], ZEITGRENZE
    elif aktion == "bildschirm":
        befehl_pfad, argumente, frist = tmux, ["capture-pane", "-p", "-t", SITZUNG], ZEITGRENZE
    else:
        skripte = {
            "status": (_STATUS, ZEITGRENZE),
            "start": (_START, ZEITGRENZE),
            "stopp": (_STOPP, ZEITGRENZE),
            "neustart": (_NEUSTART, ZEITGRENZE),
            "installieren": (_INSTALLIEREN, INSTALL_ZEITGRENZE),
            "api-installieren": (_API_INSTALLIEREN, API_ZEITGRENZE),
            "ollama_installieren": (_OLLAMA_INSTALLIEREN, INSTALL_ZEITGRENZE),
            "akku": (_API_FEHLT + "termux-battery-status", ZEITGRENZE),
            "wlan": (_API_FEHLT + "termux-wifi-connectioninfo", ZEITGRENZE),
            "hinweis": (_API_FEHLT + "termux-toast -s 'H0rSt: vxparser'", ZEITGRENZE),
            "meldung": (_API_FEHLT + "termux-notification --id h0rst-vx --title H0rSt --content vxparser "
                                     "--priority high", ZEITGRENZE),
        }
        if aktion not in skripte:
            return {"ok": False, "text": "Unbekannte Aktion: " + str(aktion)}
        skript, frist = skripte[aktion]
        befehl_pfad, argumente = bash, ["-c", skript]

    if laufen is None and not os.path.isfile(befehl_pfad):
        return {"ok": False, "text": "Termux-Befehl nicht gefunden: %s. Fehlt das passende Paket?" % befehl_pfad}
    umgebung_lauf = dict(env)
    umgebung_lauf.setdefault("PREFIX", pfad)
    umgebung_lauf.setdefault("HOME", home)
    pfade = [os.path.join(pfad, "bin")]
    if env.get("PATH"):
        pfade.append(str(env["PATH"]))
    umgebung_lauf["PATH"] = os.pathsep.join(pfade)
    try:
        ergebnis = (laufen or subprocess.run)([befehl_pfad] + argumente, capture_output=True, text=True,
                                              timeout=frist, env=umgebung_lauf,
                                              cwd=home if os.path.isdir(home) else None)
    except FileNotFoundError:
        return {"ok": False, "text": "Termux-Befehl nicht gefunden: " + befehl_pfad}
    except subprocess.TimeoutExpired:
        return {"ok": False, "text": "Keine Antwort nach %d s. Läuft Termux noch? Sonst die Aktion erneut starten." % frist}
    ausgabe = (ergebnis.stdout or "").strip()
    fehler = (ergebnis.stderr or "").strip()
    inhalt = ausgabe or fehler
    if ergebnis.returncode != 0 and fehler and fehler not in inhalt:
        inhalt = (inhalt + "\n" + fehler).strip()
    if ergebnis.returncode != 0 and "can't find session" in inhalt:
        inhalt = "vxparser läuft nicht (keine tmux-Sitzung " + SITZUNG + "). „Starten“ drücken."
    elif ergebnis.returncode != 0 and not inhalt:
        inhalt = "Befehl endete mit Code %d" % ergebnis.returncode
    return {"ok": ergebnis.returncode == 0, "text": inhalt}
