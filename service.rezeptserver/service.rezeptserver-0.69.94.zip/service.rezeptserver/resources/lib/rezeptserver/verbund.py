"""Verbund: H0rSt und seine Clients als ein Geraet (HDM - H0rSt Das Modulhost).

H0rSt ist das Herz. NuvioTV auf dem Fernseher, Nuvio Mobile am Handy und ARVIO auf
Fernseher und Web sind Glieder davor. Bisher wusste jedes Glied nur von sich: Nuvio Mobile
hat eine eigene Bruecke (/api/nuvio), ARVIO wird nur gehostet, NuvioTV kennt H0rSt gar
nicht. Dieses Modul fuehrt alle an einer Stelle zusammen:

  - TEILE sagt, welche Glieder es gibt, auf welchem Geraet sie laufen und ueber welche
    Wege sie andocken. Ein Glied hat oft mehrere: Nuvio Mobile haengt H0rSt als Addon ein
    UND nutzt die Bruecke, ARVIO spricht das Addon-Protokoll UND wird gehostet.
  - FAEHIGKEITEN sagt, welche H0rSt-Schnittstelle welche Funktion bedient. Die Liste gilt
    fuer alle Glieder; nuvio_mobil.py nimmt daraus seine eigenen, statt sie zu wiederholen.
  - Das Register haelt fest, welches Geraet sich gerade gemeldet hat. Es liegt im Speicher
    (wie die Fernsteuerung), nichts davon auf der Platte.

  GET  /api/verbund                                  Stand: Kern, Teile, Faehigkeiten, Geraete
  POST /api/verbund {aktion: "anmelden", teil, …}    Glied meldet sich, bekommt eine Kennung
  POST /api/verbund {aktion: "abmelden", kennung}    Glied meldet sich ab
"""

import secrets
import threading
import time

from . import __version__

SCHLUESSEL = "verbund"
NAME = "HDM - H0rSt Das Modulhost"
SYMBOL = "🜁"

# Ein Geraet gilt als weg, wenn es sich so lange nicht gemeldet hat (Sekunden).
VERFALL = 10 * 60
MAX_GERAETE = 50
MAX_TEXT = 80

# --- Die Wege ans Herz ---------------------------------------------------------------------------
# Ein Glied kann mehrere gehen. "rang" sagt, wie fest der Weg ist; der hoechste zaehlt.
WEGE = {
    "kern": {"name": "Herz", "rang": 3, "was": "ist H0rSt selbst"},
    "bruecke": {"name": "verdrahtet", "rang": 2,
                "was": "eigenes H0rSt-Modul, beidseitig (Stand, Funktionen, Einstellungen)"},
    "stremio": {"name": "als Addon", "rang": 1,
                "was": "spricht das Stremio-Protokoll und haengt H0rSt als Quelle ein"},
    "gehostet": {"name": "gehostet", "rang": 0,
                 "was": "H0rSt baut und liefert es aus, kennt es aber nicht als Client"},
}
# Ab diesem Rang gilt ein Glied als fest verdrahtet.
FEST_AB = 2

# --- Die Glieder ---------------------------------------------------------------------------------
TEILE = [
    {"id": "h0rst", "name": "H0rSt", "art": "kern", "geraet": "Server", "ordner": "rezeptserver/",
     "wege": ["kern"], "modul": None, "paket": "io.github.cr0c0d0c.rezeptserver", "symbol": "🫀",
     "app_version": __version__,
     "repo": "https://github.com/CR0C0d0C/modulhorst", "lizenz": "eigen",
     "was": "Modul-Host: Kataloge, Streams, Untertitel, Fortschritt, Downloads, Tracker."},
    {"id": "nuviotv", "name": "NuvioTV", "art": "client", "geraet": "Fernseher", "ordner": "NuvioTV/",
     "wege": ["bruecke", "stremio"], "modul": "nuviotv", "paket": "com.nuvio.tv", "symbol": "📺",
     "app_version": "1.2.0-beta.2", "repo": "https://github.com/NuvioMedia/NuvioTV", "lizenz": "GPL-3.0",
     "was": "TV-Client: eigene Bruecke (/api/nuviotv) und H0rSt als Addon. Vorbild fuer Menue und Style."},
    {"id": "nuvio", "name": "Nuvio Mobile", "art": "client", "geraet": "Handy, iOS", "ordner": "NuvioMobile/",
     "wege": ["bruecke", "stremio"], "modul": "nuvio", "paket": "com.nuvio.app", "symbol": "🎬",
     "app_version": "0.6.10",
     "repo": "https://github.com/NuvioMedia/NuvioMobile", "lizenz": "GPL-3.0",
     "was": "Handy-Client: haengt H0rSt als Addon ein und nutzt dazu die Bruecke /api/nuvio."},
    {"id": "arvio", "name": "ARVIO", "art": "client", "geraet": "Fernseher, Web", "ordner": "ARVIO/",
     "wege": ["bruecke", "stremio", "gehostet"], "modul": "arvio", "paket": "com.arflix.tv", "symbol": "🜛",
     "app_version": "2.3.1", "repo": "https://github.com/ProdigyV21/ARVIO", "lizenz": "Apache-2.0",
     "was": "TV- und Web-Client: eigene Bruecke (/api/arvio), H0rSt als Addon, und H0rSt hostet ARVIO Web."},
]

# --- Was der Kern allen Gliedern anbietet --------------------------------------------------------
# Eine Liste fuer alle: jedes Glied nimmt daraus, was es bedient (siehe nuvio_mobil.FUNKTIONEN).
FAEHIGKEITEN = [
    {"id": "katalog", "name": "Kataloge & Suche", "app": "Start, Entdecken, Suche",
     "h0rst": ["/api/kataloge", "/api/titelsuche", "/api/titel", "/api/entdecken", "/api/genres"]},
    {"id": "streams", "name": "Streams & Wiedergabe", "app": "Player, Quellenwahl, Autoplay",
     "h0rst": ["/api/titelstreams", "/api/streams", "/api/sehen"]},
    {"id": "addon", "name": "Stremio-Addon-Bruecke", "app": "Addons, Manifest, Kataloge, Streams",
     "h0rst": ["/manifest.json", "/catalog/…", "/meta/…", "/stream/…"]},
    {"id": "untertitel", "name": "Untertitel", "app": "Untertitelquellen, Sprache, Stil",
     "h0rst": ["/api/untertitel/<sprache>/<imdb>"]},
    {"id": "fortschritt", "name": "Weiterschauen & Verlauf", "app": "Weiterschauen, gesehen, Resume",
     "h0rst": ["/api/sehen", "/api/titel"]},
    {"id": "downloads", "name": "Downloads", "app": "Offline-Speicher, Fortschritt",
     "h0rst": ["/api/downloads"]},
    {"id": "tracker", "name": "Tracker", "app": "Trakt, SIMKL, MDBList",
     "h0rst": ["/api/trakt", "/api/simkl", "/api/mdblist"]},
    {"id": "debrid", "name": "Debrid & Cloud", "app": "TorBox, Premiumize, Aufloeser",
     "h0rst": ["/api/debrid", "/api/debrid/cloud", "/api/einstellungen"]},
    {"id": "livetv", "name": "Live-TV & EPG", "app": "Sender, Programm, Xtream",
     "h0rst": ["/api/livetv", "/tv.m3u", "/epg.xml.gz"]},
    {"id": "heimserver", "name": "Heimserver", "app": "Plex, Jellyfin, Emby, FTP, WebDAV",
     "h0rst": ["/api/heim", "/api/dateien"]},
]

_sperre = threading.Lock()
_geraete = {}  # kennung -> {teil, name, version, seit, zuletzt}


def teil(kennung):
    """Das Glied mit dieser Kennung, sonst None."""
    for t in TEILE:
        if t["id"] == str(kennung or ""):
            return t
    return None


def faehigkeiten(ids=None):
    """Alle Faehigkeiten, oder nur die mit diesen Kennungen (in der Reihenfolge der Liste)."""
    if ids is None:
        return [dict(f) for f in FAEHIGKEITEN]
    gewollt = {str(i) for i in ids}
    return [dict(f) for f in FAEHIGKEITEN if f["id"] in gewollt]


def _text(wert, grenze=MAX_TEXT):
    """Kurzer, einzeiliger Text ohne Steuerzeichen - so wie er in die Liste darf."""
    roh = str(wert or "").strip()
    sauber = "".join(z for z in roh if z.isprintable())
    return sauber[:grenze]


def _aufraeumen(jetzt):
    """Geraete vergessen, die sich zu lange nicht gemeldet haben. Ruft nur, wer die Sperre haelt."""
    for kennung in [k for k, g in _geraete.items() if jetzt - g["zuletzt"] > VERFALL]:
        del _geraete[kennung]


def anmelden(wunsch, uhr=time.time):
    """Ein Glied meldet sich. Liefert die Kennung; dieselbe Kennung meldet sich erneut (Auffrischen)."""
    gewollt = teil(wunsch.get("teil"))
    if gewollt is None:
        raise ValueError("Unbekanntes Teil")
    if gewollt["art"] == "kern":
        raise ValueError("Der Kern meldet sich nicht an")
    jetzt = uhr()
    with _sperre:
        _aufraeumen(jetzt)
        kennung = _text(wunsch.get("kennung"), 40)
        eintrag = _geraete.get(kennung) if kennung else None
        if eintrag is None:
            if len(_geraete) >= MAX_GERAETE:
                raise ValueError("Zu viele Geraete")
            kennung = secrets.token_urlsafe(9)
            eintrag = {"teil": gewollt["id"], "seit": jetzt}
            _geraete[kennung] = eintrag
        eintrag["teil"] = gewollt["id"]
        eintrag["name"] = _text(wunsch.get("name")) or gewollt["geraet"]
        eintrag["version"] = _text(wunsch.get("version"), 20)
        eintrag["zuletzt"] = jetzt
        return kennung


def abmelden(kennung):
    """Ein Glied meldet sich ab. True, wenn es im Register stand."""
    with _sperre:
        return _geraete.pop(_text(kennung, 40), None) is not None


def geraete(uhr=time.time, mit_kennung=False):
    """Die gemeldeten Geraete, juengstes zuerst; abgelaufene fallen dabei weg.

    Die Kennung bleibt draussen: wer sie kennt, kann ein Geraet abmelden oder umbenennen.
    Jedes Glied bekommt seine eigene nur als Antwort auf die eigene Anmeldung.
    """
    jetzt = uhr()
    with _sperre:
        _aufraeumen(jetzt)
        liste = [dict(g, seit_sekunden=int(jetzt - g["seit"]),
                      still_sekunden=int(jetzt - g["zuletzt"]),
                      **({"kennung": k} if mit_kennung else {})) for k, g in _geraete.items()]
    return sorted(liste, key=lambda g: g["still_sekunden"])


def leeren():
    """Register leeren (Tests und Neustart des Dienstes)."""
    with _sperre:
        _geraete.clear()


def bester_weg(wege):
    """Der festeste Weg eines Glieds (hoechster Rang), sonst "" bei leerer Liste."""
    bekannt = [w for w in (wege or []) if w in WEGE]
    return max(bekannt, key=lambda w: WEGE[w]["rang"]) if bekannt else ""


def fest(wege):
    """Haengt das Glied fest am Herz (Kern oder eigene Bruecke)?"""
    bester = bester_weg(wege)
    return bool(bester) and WEGE[bester]["rang"] >= FEST_AB


def _adressen(t, basis):
    """Je Weg die Adresse, ueber die das Glied andockt (leer ohne eigene Basis)."""
    wohin = {}
    if not basis:
        return wohin
    for weg in t.get("wege") or []:
        if weg == "stremio":
            wohin[weg] = basis + "manifest.json"
        elif weg == "bruecke" and t.get("modul"):
            wohin[weg] = basis + "api/" + str(t["modul"])
    return wohin


def _teil_stand(t, basis, gemeldet):
    """Ein Glied mit seinem Stand: welche Wege, welche Adressen, welche Geraete sind da."""
    meine = [g for g in gemeldet if g["teil"] == t["id"]]
    wohin = _adressen(t, basis)
    bester = bester_weg(t.get("wege"))
    return dict(t, adressen=wohin, adresse=wohin.get(bester, ""), bester_weg=bester,
                weg_name=WEGE[bester]["name"] if bester else "",
                fest=fest(t.get("wege")), geraete=meine, aktiv=bool(meine))


def stand(basis="", uhr=time.time):
    """Antwort fuer GET /api/verbund: der ganze Verbund auf einen Blick."""
    basis = str(basis or "")
    if basis and not basis.endswith("/"):
        basis += "/"
    gemeldet = geraete(uhr)
    teile = [_teil_stand(t, basis, gemeldet) for t in TEILE]
    return {
        "modul": SCHLUESSEL,
        "name": NAME,
        "symbol": SYMBOL,
        "h0rst": __version__,
        "basis": basis,
        "addon": basis + "manifest.json" if basis else "",
        "api": basis + "api/" if basis else "",
        "teile": teile,
        "wege": {k: dict(v) for k, v in WEGE.items()},
        "faehigkeiten": faehigkeiten(),
        "geraete": gemeldet,
        "zahlen": {
            "teile": len(teile),
            "clients": sum(1 for t in teile if t["art"] == "client"),
            "verdrahtet": sum(1 for t in teile if t["fest"]),
            "geraete": len(gemeldet),
        },
    }
