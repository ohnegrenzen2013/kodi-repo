"""Rezeptserver: JSON-Rezepte als Stremio-Addon."""

__version__ = "0.70.2"
