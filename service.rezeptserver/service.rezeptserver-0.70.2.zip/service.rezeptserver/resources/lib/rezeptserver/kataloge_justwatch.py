"""Kataloge: freie Anbieter-Kataloge ueber JustWatch (ohne Schluessel).

JustWatch fuehrt die Kataloge der deutschen Streaming-Dienste zusammen und nennt zu jedem
Titel die IMDb-Kennung. Damit bekommen Joyn, RTL+, WOW und Pluto TV eine echte Katalogreihe,
ohne dass ein TMDb-Schluessel noetig ist; die Titel erscheinen mit denselben Karten wie die
uebrigen Kataloge und lassen sich ueber die vorhandenen Streams abspielen.

waipu.tv fehlt bei JustWatch in Deutschland und bleibt beim TMDb-Discover (kataloge_anbieter.py).

  GET /api/katalog?art=anbieter&id=joyn&typ=movie   (ueber oberflaeche_kataloge.py)
"""

import json

from .kataloge_grund import POSTER, ZEIT, KatalogFehler

JUSTWATCH = "https://apis.justwatch.com/graphql"
# Kennung in H0rSt -> (JustWatch-Paketname, Anzeigename)
ANBIETER = {
    "joyn": ("jyn", "Joyn"),
    "rtlplus": ("rps", "RTL+"),
    "wow": ("sko", "WOW"),
    "pluto": ("ptv", "Pluto TV"),
}
TYPEN = {"movie": "MOVIE", "series": "SHOW"}
SEITE = 20
KOPF = {"Content-Type": "application/json", "Accept": "application/json"}


class KatalogeJustwatchMixin:
    def _justwatch(self, koerper):
        """GraphQL-Abfrage mit Zwischenspeicher; KatalogFehler bei kaputter Antwort."""
        stelle = ("justwatch", koerper)
        with self._sperre:
            alt = self._speicher.get(stelle)
            if alt and self.uhr() - alt[0] < ZEIT:
                return alt[1]
        try:
            text = self.abrufer.abruf(JUSTWATCH, methode="POST", header=dict(KOPF),
                                      daten=koerper.encode("utf-8"))
            antwort = json.loads(text)
        except (ValueError, TypeError):
            raise KatalogFehler("JustWatch liefert keine gültige Antwort")
        if not isinstance(antwort, dict) or antwort.get("errors"):
            raise KatalogFehler("JustWatch hat die Abfrage abgelehnt")
        with self._sperre:
            if len(self._speicher) > 200:
                self._speicher.clear()
            self._speicher[stelle] = (self.uhr(), antwort)
        return antwort

    def anbieter_frei(self):
        """Die Anbieter, die ohne TMDb-Schluessel einen Katalog haben."""
        return [{"id": kennung, "name": name} for kennung, (_paket, name) in ANBIETER.items()]

    def justwatch(self, kennung, typ, skip=0):
        if kennung not in ANBIETER:
            raise KatalogFehler("Kein freier Katalog fuer %s" % kennung)
        if typ not in TYPEN:
            raise KatalogFehler("Typ movie oder series")
        try:
            skip = max(0, int(skip or 0))
        except (TypeError, ValueError):
            skip = 0
        paket = ANBIETER[kennung][0]
        abfrage = ('query { popularTitles(country: DE, first: %d, offset: %d, '
                   'filter: {packages: ["%s"], objectTypes: [%s]}) { totalCount edges { node { '
                   'content(country: DE, language: de) { title originalReleaseYear shortDescription '
                   'externalIds { imdbId } } } } } }') % (SEITE, skip, paket, TYPEN[typ])
        antwort = self._justwatch(json.dumps({"query": abfrage}))
        beliebt = ((antwort.get("data") or {}).get("popularTitles")) or {}
        titel = []
        for kante in beliebt.get("edges") or []:
            inhalt = (((kante or {}).get("node") or {}).get("content")) or {}
            imdb = str((inhalt.get("externalIds") or {}).get("imdbId") or "")
            if not imdb.startswith("tt"):
                continue  # ohne IMDb-Kennung keine Karte (und kein Abspielen)
            beschreibung = str(inhalt.get("shortDescription") or "")
            titel.append({
                "id": imdb, "typ": typ, "titel": str(inhalt.get("title") or imdb),
                "jahr": str(inhalt.get("originalReleaseYear") or ""), "bewertung": "",
                "poster": POSTER % imdb, "hintergrund": "", "logo": "", "genres": [],
                "beschreibung": beschreibung[:400] + ("…" if len(beschreibung) > 400 else ""),
                "laufzeit": "",
            })
        try:
            gesamt = int(beliebt.get("totalCount") or 0)
        except (TypeError, ValueError):
            gesamt = 0
        return {"titel": titel, "mehr": skip + SEITE < gesamt, "weiter": skip + SEITE,
                "name": "Bei %s" % ANBIETER[kennung][1]}
