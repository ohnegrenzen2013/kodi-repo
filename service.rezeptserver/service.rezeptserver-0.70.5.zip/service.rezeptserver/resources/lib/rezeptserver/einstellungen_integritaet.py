"""Einstellungen: Integritaetspruefung aller Bausteine (eigene Seite in der Oberflaeche)."""

INTEGRITAET_KATEGORIE = {
    "id": "integritaet", "name": "Integrität", "symbol": "🩺", "gruppe": "System & Pflege", "eigen": True,
    "beschreibung": "Prüft Module, Rezepte, Anbieter, Addons, Plugins, Links und Verweise auf fehlende "
                    "oder doppelte Einträge. Die Prüfung ist strukturell und braucht kein Netz.",
}
