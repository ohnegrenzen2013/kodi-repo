"""Einstellungen: Live-KI-Untertitel (Gemini) fuer die laufende Wiedergabe."""

LIVEUNTERTITEL_KATEGORIE = {
    "id": "liveuntertitel", "name": "Live-KI-Untertitel", "symbol": "💬",
    "gruppe": "Wiedergabe", "eigen": True,
    "beschreibung": "H0rSt hoert bei der laufenden Wiedergabe in kurzen Abschnitten mit und laesst sie von Gemini "
                    "in die Zielsprache uebersetzen. Der Schluessel bleibt auf dem Server; die Tonspur schneidet "
                    "der Client heraus. Das ist die Live-Fassung von ARVIOS Gemini-Untertiteln.",
    "zeilen": [
        {"key": "liveut_an", "typ": "schalter", "titel": "Live-KI-Untertitel anbieten",
         "standard": False,
         "hinweis": "Blendet im Live-TV-Player den Knopf „KI-UT“ ein. Aus = keine Anfragen, kein Verbrauch."},
        {"key": "liveut_schluessel", "typ": "passwort", "titel": "Gemini-API-Schluessel",
         "standard": "", "platzhalter": "AIza …",
         "hinweis": "Aus Google AI Studio. Nur auf dem Server gespeichert und nie an die Oberflaeche "
                    "zurueckgegeben; jede Tonanfrage kostet Kontingent des Schluessels."},
        {"key": "liveut_modell", "typ": "text", "titel": "Modell",
         "standard": "gemini-3.5-flash-lite", "platzhalter": "gemini-3.5-flash-lite",
         "hinweis": "Muss Spracheingabe annehmen (Flash-Modelle tun das). Ein falscher Name wird als "
                    "Anfragefehler gemeldet."},
        {"key": "liveut_basis", "typ": "text", "titel": "Basis-Adresse",
         "standard": "https://generativelanguage.googleapis.com/v1beta",
         "hinweis": "Nur aendern, wenn ein eigener Proxy dieselbe API anbietet. Der Pfad "
                    "/models/<modell>:generateContent wird angehaengt."},
        {"key": "liveut_sprache", "typ": "wahl", "titel": "Zielsprache",
         "standard": "de",
         "werte": [["de", "Deutsch"], ["en", "Englisch"], ["fr", "Franzoesisch"], ["es", "Spanisch"],
                   ["it", "Italienisch"], ["pt", "Portugiesisch"], ["nl", "Niederlaendisch"],
                   ["pl", "Polnisch"], ["ru", "Russisch"], ["tr", "Tuerkisch"], ["ar", "Arabisch"],
                   ["he", "Hebraeisch"], ["ja", "Japanisch"], ["ko", "Koreanisch"], ["zh", "Chinesisch"]],
         "hinweis": "In dieser Sprache erscheinen die Untertitel, auch wenn der Sender eine andere spricht."},
        {"key": "liveut_segment", "typ": "wahl", "titel": "Tonabschnitt",
         "standard": "4",
         "werte": [["3", "3 Sekunden"], ["4", "4 Sekunden"], ["6", "6 Sekunden"]],
         "hinweis": "Kuerzer = aktueller, aber mehr Anfragen. Laenger = fluessiger, aber traeger."},
        {"key": "liveut_kontext", "typ": "wahl", "titel": "Kontextzeilen",
         "standard": "3",
         "werte": [["0", "Ohne"], ["3", "3 Zeilen"], ["5", "5 Zeilen"]],
         "hinweis": "Die letzten Zeilen gehen als Zusammenhang mit, damit Namen und Anrede gleich bleiben."},
    ],
}
