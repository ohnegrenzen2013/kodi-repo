"""Einstellungen: Stream-Rangfolge nach NuvioTV-Vorbild."""

STREAMRANG_KATEGORIE = {
    "id": "streamrang", "name": "Stream-Rangfolge", "symbol": "🏆",
    "gruppe": "Wiedergabe", "eigen": True,
    "beschreibung": "NuvioTV bewertet Quellen anhand des Release-Namens: Auflösung, Remux/Blu-ray/WEB, "
                    "HDR, Ton, Release-Gruppe, Sprache und Dateigröße. H0rSt sortiert damit die Streams "
                    "und bietet die beste Quelle mit einem Knopf an – im Browser, in der App und am Fernseher.",
    "zeilen": [
        {"key": "stream_rang", "typ": "wahl", "titel": "Rangfolge der Quellen", "standard": "original",
         "werte": [["original", "Original (wie geliefert)"], ["balanced", "Ausgewogen (NuvioTV)"],
                   ["best", "Beste Qualität"], ["smaller", "Kleinere Dateien"], ["hdsdr", "1080p / SDR"]],
         "hinweis": "„Original“ lässt die Reihenfolge der Quellen unverändert. Die anderen Profile bewerten "
                    "den Release-Namen wie NuvioTV: Remux vor Blu-ray vor WEB, bevorzugte Gruppen und "
                    "Sprachen zuerst; unbekannte Quellen bleiben wählbar."},
        {"key": "stream_rang_sprache", "typ": "wahl", "titel": "Bevorzugte Sprache in der Rangfolge",
         "standard": "",
         "werte": [["", "Keine"], ["de", "Deutsch"], ["en", "Englisch"], ["fr", "Französisch"],
                   ["es", "Spanisch"], ["it", "Italienisch"], ["pt", "Portugiesisch"], ["nl", "Niederländisch"],
                   ["pl", "Polnisch"], ["ru", "Russisch"], ["tr", "Türkisch"], ["ja", "Japanisch"],
                   ["ko", "Koreanisch"], ["zh", "Chinesisch"], ["hi", "Hindi"], ["ar", "Arabisch"],
                   ["multi", "Mehrsprachig"], ["dual", "Zweisprachig"]],
         "hinweis": "Quellen mit dieser Sprache stehen vor Quellen ohne Sprachangabe. Erst wenn ein Profil "
                    "gewählt ist, wirkt die Sprache; „Keine“ lässt die Qualität entscheiden."},
        {"key": "stream_rang_ansicht", "typ": "wahl", "titel": "Darstellung der Quellen", "standard": "beides",
         "werte": [["beides", "Beste Quellen oben, dann nach Anbieter"], ["rang", "Nur Rangfolge"],
                   ["gruppen", "Nur nach Anbieter"]],
         "hinweis": "Am Fernseher ist „Beste Quellen oben“ gedacht: ein Knopf startet die beste Quelle, "
                    "darunter stehen alle Quellen nach Anbieter gruppiert."},
        {"key": "stream_rang_fallback", "typ": "schalter", "titel": "Nächste Usenet-Quelle bei Fehler",
         "standard": True,
         "hinweis": "Scheitert eine Usenet-Quelle beim Öffnen, versucht H0rSt automatisch die nächste "
                    "passende Quelle aus der Rangfolge (höchstens fünf Versuche). Für normale Links, "
                    "Torrents und Debrid ändert sich nichts."},
    ],
}
