"""emberd: Ember ohne Fenster (Ember-P2P ab 1.8, GPL-3.0) herunterladen, starten und steuern.

Ember selbst hat keine Fernsteuerung. Seit 1.8 bringt es `emberd` mit: denselben Kern ohne Fenster,
mit einer Web-Oberflaeche (Standard 127.0.0.1:4711) und einer Steuerung ueber einen Unix-Socket
(`emberd ctl` spricht dieselben Routen wie die Web-Seiten). H0rSt startet und stoppt diesen Dienst,
redet ueber den Socket mit ihm (Status, Suche, Downloads) und kann ihn aus den GitHub-Releases
herunterladen - mit Pruefsumme, sicherem Entpacken und einem Probelauf vor der Uebernahme.

  * Programm: eigener Eintrag, sonst der eigene Einbau unter <Datenordner>/emberd/aktuell, sonst
    emberd aus PATH bzw. /usr/bin, /usr/local/bin, /opt/emberd.
  * Daten: eigener Ordner <Datenordner>/emberd/daten (oder ein vorhandener Ember-Ordner). Der
    Socket liegt darin (`emberd.sock`); ein systemd-emberd wird ueber /run/emberd/emberd.sock
    mitbenutzt, ohne ihn zu besitzen.
  * Start/Stop: nur ein von H0rSt gestarteter emberd wird auch wieder gestoppt (SIGTERM, Ember
    speichert beim Beenden). Laeuft bereits ein fremder emberd, wird nur gelesen/gesteuert.
  * Web-Oberflaeche: standardmaessig nur auf diesem Rechner; im Heimnetz auf Wunsch (dann mit
    Passwort). Ein eigenes Passwort setzt H0rSt beim ersten Start ueber `emberd passwd --stdin`.

Nutzerdaten "emberd": {"programm", "datenordner", "downloadordner", "port", "netz", "autostart",
"passwort", "pid", "gestartet_von_h0rst", "version"} - als Datei <Datenordner>/emberd.json (0600).
"""

import hashlib
import io
import json
import os
import platform
import secrets
import shutil
import signal
import socket
import subprocess
import sys
import tarfile
import threading
import time
import urllib.error
import urllib.request
from pathlib import PurePosixPath
from urllib.parse import urljoin

from .ed2k import link_bauen
from .netz import USER_AGENT, NetzFehler, gepruefte_ips, oeffentlich_holen, pin_oeffner, urllib_holen

DATEI = "emberd.json"
STANDARD_PORT = 4711
STANDARD_MIN_PORT = 1024
MAX_PORT = 65535
MAX_ANTWORT = 8 * 1024 * 1024
MAX_TARBALL = 250 * 1024 * 1024
MAX_ENTPACKT = 500 * 1024 * 1024
MAX_DATEIEN = 5000
MAX_PASSWORT = 200
MIN_PASSWORT = 8
RELEASES = "https://api.github.com/repos/untaimed18/Ember-P2P/releases/latest"
SUMMEN_NAME = "SHA256SUMS"
ARCHEN = {"x86_64": "x86_64", "amd64": "x86_64", "aarch64": "aarch64", "arm64": "aarch64"}
FELDER = ("programm", "datenordner", "downloadordner", "port", "netz", "autostart", "passwort")
STANDARD = {"programm": "", "datenordner": "", "downloadordner": "", "port": STANDARD_PORT,
            "netz": False, "autostart": False, "passwort": "", "pid": 0,
            "gestartet_von_h0rst": False, "version": ""}


class EmberdFehler(ValueError):
    pass


def pruefe(roh):
    """Einstellungen lesen und begrenzen (Port, Ordner, Schalter)."""
    roh = roh if isinstance(roh, dict) else {}
    e = dict(STANDARD)
    e["programm"] = str(roh.get("programm") or "").strip()[:1000]
    e["datenordner"] = str(roh.get("datenordner") or "").strip()[:1000]
    e["downloadordner"] = str(roh.get("downloadordner") or "").strip()[:1000]
    e["passwort"] = str(roh.get("passwort") or "")[:MAX_PASSWORT]
    try:
        e["port"] = int(roh.get("port") or STANDARD_PORT)
    except (TypeError, ValueError):
        raise EmberdFehler("Port: Zahl zwischen %d und %d" % (STANDARD_MIN_PORT, MAX_PORT))
    if not STANDARD_MIN_PORT <= e["port"] <= MAX_PORT:
        raise EmberdFehler("Port: Zahl zwischen %d und %d" % (STANDARD_MIN_PORT, MAX_PORT))
    e["netz"] = (roh.get("netz", False) is True)
    e["autostart"] = (roh.get("autostart", False) is True)
    e["pid"] = int(roh.get("pid") or 0)
    e["gestartet_von_h0rst"] = (roh.get("gestartet_von_h0rst", False) is True)
    e["version"] = str(roh.get("version") or "")[:40]
    return e


def arch():
    return ARCHEN.get((platform.machine() or "").lower(), "")


def programm_kandidaten():
    """emberd, ohne den Desktop-App-Eintrag: nur der Dienst kann kopflos laufen."""
    liste = [shutil.which("emberd") or "", "/usr/bin/emberd", "/usr/local/bin/emberd",
             "/opt/emberd/emberd", os.path.join(os.path.expanduser("~"), "emberd")]
    return [p for p in liste if p]


def socket_antwortet(pfad):
    s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
    s.settimeout(0.4)
    try:
        s.connect(pfad)
        return True
    except (OSError, ValueError):
        return False
    finally:
        s.close()


class Emberd:
    """Der emberd-Dienst und die Wege zu ihm. Eine Instanz je H0rSt."""

    def __init__(self, datenordner, holen=None, roh_holen=None, uhr=time.time, maschine=None):
        self.basis = os.path.abspath(datenordner or ".")
        self.datenordner = self.basis
        self.konfig_pfad = os.path.join(self.basis, DATEI)
        self.uhr = uhr
        self.maschine = maschine
        self._sperre = threading.RLock()
        self._holen = holen or oeffentlich_holen(urllib_holen)
        self._roh_holen = roh_holen
        self._release = (0, None)
        self._version = (0, "", "")
        self._programm_fehler = ""
        self._prozess = None
        self._installation = {"laeuft": False, "stand": "", "prozent": 0, "fehler": ""}
        self._letzter_fehler = ""
        self.einstellung = pruefe(self._laden())

    # --- Einstellungen ----------------------------------------------------------------------------
    def _laden(self):
        try:
            with open(self.konfig_pfad, encoding="utf-8") as f:
                daten = json.load(f)
            return daten if isinstance(daten, dict) else {}
        except (OSError, ValueError):
            return {}

    def _sichern(self):
        os.makedirs(self.basis, exist_ok=True)
        text = json.dumps(self.einstellung, indent=2, ensure_ascii=False)
        pfad = self.konfig_pfad + ".neu"
        with open(pfad, "w", encoding="utf-8") as f:
            f.write(text + "\n")
        try:
            os.chmod(pfad, 0o600)
        except OSError:  # Windows
            pass
        os.replace(pfad, self.konfig_pfad)

    def einstellen(self, werte):
        if not isinstance(werte, dict):
            raise EmberdFehler("Einstellungen muessen ein Objekt sein")
        roh = dict(self.einstellung)
        for feld in FELDER:
            if feld in werte:
                roh[feld] = werte[feld]
        neu = pruefe(roh)
        if neu["programm"] and "emberd" not in os.path.basename(neu["programm"]).lower():
            raise EmberdFehler("Als Programm geht nur emberd (der Dateiname muss „emberd“ enthalten)")
        if neu["datenordner"] and not os.path.isabs(neu["datenordner"]):
            raise EmberdFehler("Der Datenordner braucht einen vollstaendigen Pfad")
        if neu["downloadordner"] and not os.path.isabs(neu["downloadordner"]):
            raise EmberdFehler("Der Downloadordner braucht einen vollstaendigen Pfad")
        laeuft = bool(self._laufender_socket())
        wichtig = ("port", "netz", "datenordner", "programm")
        neustart = laeuft and self.einstellung.get("gestartet_von_h0rst") and any(
            self.einstellung.get(f) != neu.get(f) for f in wichtig)
        with self._sperre:
            self.einstellung = neu
            self._sichern()
        if neustart:
            self.stoppen()
            if neu["programm"] or self.programm():
                self.starten()
        return self.einstellungen_oeffentlich()

    def einstellungen_oeffentlich(self, verwalten=False):
        e = dict(self.einstellung)
        e.pop("passwort", None)
        e["passwort_gesetzt"] = bool(self.einstellung.get("passwort"))
        e["verwalten"] = bool(verwalten)
        e["datenordner"] = self.datenordner_aktuell()
        e["downloadordner"] = self.downloadordner()
        return e

    # --- Orte -------------------------------------------------------------------------------------
    def _eigener_einbau(self):
        return os.path.join(self.basis, "emberd")

    def programm(self):
        eigen = self.einstellung.get("programm") or ""
        if eigen and os.path.isfile(eigen):
            return eigen
        aktuell = os.path.join(self._eigener_einbau(), "aktuell", "emberd")
        if os.path.isfile(aktuell) and os.access(aktuell, os.X_OK):
            return aktuell
        return next((p for p in programm_kandidaten() if os.path.isfile(p)), "")

    def datenordner_aktuell(self):
        eigen = self.einstellung.get("datenordner") or ""
        return eigen or os.path.join(self.basis, "emberd", "daten")

    def socket_pfad(self, daten=None):
        return os.path.join(daten or self.datenordner_aktuell(), "emberd.sock")

    def _socket_kandidaten(self):
        liste = [self.socket_pfad()]
        for pfad in (os.environ.get("EMBERD_SOCKET") or "", "/run/emberd/emberd.sock",
                     os.path.join(os.path.expanduser("~"), ".local", "share", "p2p", "emberd.sock"),
                     os.path.join(os.path.expanduser("~"), ".local", "share", "ember", "p2p", "emberd.sock")):
            if pfad and pfad not in liste:
                liste.append(pfad)
        return liste

    def _laufender_socket(self):
        for pfad in self._socket_kandidaten():
            if os.path.exists(pfad) and socket_antwortet(pfad):
                return pfad
        return ""

    @staticmethod
    def _pid_lebt(pid):
        """Auch Zombies zaehlen als beendet - sonst wartet Stoppen 60 s auf einen toten Prozess."""
        try:
            os.kill(pid, 0)
        except OSError:
            return False
        try:
            with open("/proc/%d/stat" % pid, encoding="utf-8", errors="replace") as f:
                text = f.read()
            zustand = text.rsplit(")", 1)[1].strip().split(" ", 1)[0]
            return zustand not in ("Z", "X", "x")
        except (OSError, IndexError):
            return True

    def _eigenes_pid(self):
        pid = int(self.einstellung.get("pid") or 0)
        if pid <= 0:
            return 0
        return pid if self._pid_lebt(pid) else 0

    def laeuft(self):
        return bool(self._laufender_socket())

    def downloadordner(self):
        """Wurzel, wie Ember sie in config.json fuehrt; fertige Dateien liegen in Downloads/."""
        eigen = self.einstellung.get("downloadordner") or ""
        if eigen:
            return eigen
        daten = self.datenordner_aktuell()
        try:
            from . import ember_steuerung
            basis = (ember_steuerung.EmberSteuerung({"ordner": daten}).konfig().get("download_folder") or "").strip()
        except Exception:
            basis = ""
        return basis or os.path.join(self.basis, "emberd", "downloads")

    def fertige_downloads(self):
        basis = self.downloadordner()
        if not basis:
            return ""
        unter = os.path.join(basis, "Downloads")
        return unter if os.path.isdir(unter) else basis

    # --- Socket-Client ----------------------------------------------------------------------------
    def _anfrage(self, socket_pfad, methode, pfad, koerper=None, zeitgrenze=30.0):
        s = socket.socket(socket.AF_UNIX, socket.SOCK_STREAM)
        s.settimeout(zeitgrenze)
        try:
            s.connect(socket_pfad)
            daten = json.dumps(koerper).encode("utf-8") if koerper is not None else b""
            kopf = ("%s %s HTTP/1.1\r\nHost: emberd\r\nConnection: close\r\n"
                    "Content-Type: application/json\r\nContent-Length: %d\r\n\r\n" % (methode, pfad, len(daten)))
            s.sendall(kopf.encode("ascii") + daten)
            roh = bytearray()
            while True:
                stueck = s.recv(65536)
                if not stueck:
                    break
                roh += stueck
                if len(roh) > MAX_ANTWORT:
                    raise EmberdFehler("emberd antwortet mit mehr als %d Bytes" % MAX_ANTWORT)
        except (OSError, ValueError) as fehler:
            raise EmberdFehler("emberd ist nicht erreichbar (%s): %s" % (socket_pfad, fehler))
        finally:
            s.close()
        antwort = self._antwort_lesen(bytes(roh))
        if "error" in antwort:
            raise EmberdFehler(self._fehlertext(antwort["error"]))
        return antwort

    @staticmethod
    def _antwort_lesen(roh):
        stelle = roh.find(b"\r\n\r\n")
        if stelle < 0:
            raise EmberdFehler("emberd hat unvollstaendig geantwortet")
        kopf = roh[:stelle].decode("utf-8", "replace").split("\r\n")
        teile = kopf[0].split(" ")
        if len(teile) < 2 or not teile[1].isdigit():
            raise EmberdFehler("emberd hat ohne Status geantwortet")
        status = int(teile[1])
        koepfe = {}
        for zeile in kopf[1:]:
            if ":" in zeile:
                name, wert = zeile.split(":", 1)
                koepfe[name.strip().lower()] = wert.strip()
        rumpf = roh[stelle + 4:]
        if "chunked" in (koepfe.get("transfer-encoding") or "").lower():
            rumpf = Emberd._entstueckeln(rumpf)
        if status != 200:
            try:
                daten = json.loads(rumpf.decode("utf-8"))
                fehler = daten.get("error") if isinstance(daten, dict) else None
            except (ValueError, UnicodeDecodeError):
                fehler = None
            raise EmberdFehler(Emberd._fehlertext(fehler) if fehler else "emberd antwortet mit HTTP %d" % status)
        try:
            daten = json.loads(rumpf.decode("utf-8"))
        except (ValueError, UnicodeDecodeError):
            raise EmberdFehler("emberd hat keine JSON-Antwort geschickt")
        if not isinstance(daten, dict):
            raise EmberdFehler("emberd hat etwas anderes als ein JSON-Objekt geschickt")
        return daten

    @staticmethod
    def _entstueckeln(rumpf):
        aus = bytearray()
        while True:
            ende = rumpf.find(b"\r\n")
            if ende < 0:
                raise EmberdFehler("emberd hat unvollstaendig geantwortet")
            groesse = int(rumpf[:ende].split(b";")[0].strip() or b"0", 16)
            rumpf = rumpf[ende + 2:]
            if groesse == 0:
                return bytes(aus)
            if len(rumpf) < groesse + 2:
                raise EmberdFehler("emberd hat unvollstaendig geantwortet")
            aus += rumpf[:groesse]
            rumpf = rumpf[groesse + 2:]

    @staticmethod
    def _fehlertext(fehler):
        text = fehler if isinstance(fehler, str) else json.dumps(fehler, ensure_ascii=False)
        try:
            daten = json.loads(text)
        except (TypeError, ValueError):
            return str(text)[:500]
        if isinstance(daten, dict) and daten.get("message"):
            kontext = daten.get("context")
            return ("%s (%s)" % (daten["message"], kontext)) if kontext else str(daten["message"])
        return str(text)[:500]

    def _invoke(self, socket_pfad, befehl, argumente=None, zeitgrenze=30.0):
        antwort = self._anfrage(socket_pfad, "POST", "/api/invoke/" + befehl, argumente or {},
                                zeitgrenze=zeitgrenze)
        if "error" in antwort:
            raise EmberdFehler(self._fehlertext(antwort["error"]))
        return antwort.get("ok")

    def _session(self, socket_pfad, zeitgrenze=10.0):
        return self._anfrage(socket_pfad, "GET", "/api/session", None, zeitgrenze=zeitgrenze)

    def _laufend(self):
        pfad = self._laufender_socket()
        if not pfad:
            raise EmberdFehler("emberd läuft nicht – bitte zuerst starten oder einrichten")
        return pfad

    # --- Betrieb ----------------------------------------------------------------------------------
    def version(self):
        """Laufende Fassung (aus der Sitzung), sonst die des Programms (60 s zwischengespeichert)."""
        pfad = self._laufender_socket()
        if pfad:
            try:
                return str(self._session(pfad).get("version") or "")
            except EmberdFehler:
                pass
        programm = self.programm()
        if not programm:
            return ""
        zeit, pfad_alt, text = self._version
        if pfad_alt == programm and text and self.uhr() - zeit < 60:
            return text
        text, fehler = self._programm_version(programm)
        with self._sperre:
            self._version = (self.uhr(), programm, text)
            self._programm_fehler = fehler
        return text

    @staticmethod
    def _programm_version(programm):
        """(fassung, fehler) - fuehrt `emberd --version` aus und meldet ehrlich, wenn es nicht laeuft."""
        try:
            aus = subprocess.run([programm, "--version"], capture_output=True, text=True,
                                 timeout=20, env=dict(os.environ))
        except OSError as fehler:
            return "", "emberd laesst sich nicht ausfuehren: %s" % fehler
        except subprocess.SubprocessError as fehler:
            return "", "emberd --version antwortet nicht: %s" % fehler
        text = ((aus.stdout or "") + (aus.stderr or "")).strip()
        if aus.returncode != 0:
            return "", "emberd --version scheitert: %s" % (text[:400] or "unbekannter Fehler")
        zeile = text.splitlines()[0].strip() if text else ""
        if not zeile.startswith("emberd "):
            return "", "emberd --version meldet nicht „emberd“: %s" % (zeile[:200] or "nichts")
        return zeile[len("emberd "):].strip(), ""

    def _umgebung(self, daten=None, port=None, netzwerk=None, programm=None):
        daten = daten or self.datenordner_aktuell()
        port = int(port or self.einstellung["port"])
        netzwerk = self.einstellung["netz"] if netzwerk is None else bool(netzwerk)
        env = dict(os.environ)
        env["EMBER_DATA_DIR"] = daten
        env["EMBERD_LISTEN"] = ("0.0.0.0:%d" if netzwerk else "127.0.0.1:%d") % port
        env["EMBERD_SOCKET"] = self.socket_pfad(daten)
        ordner = self.downloadordner()
        if ordner:
            env["EMBERD_DOWNLOAD_DIR"] = ordner
        if programm:
            lauf = os.path.dirname(programm)
            if os.path.isdir(os.path.join(lauf, "web")):
                env["EMBERD_WEB_ROOT"] = os.path.join(lauf, "web")
            if os.path.isdir(os.path.join(lauf, "resources")):
                env["EMBERD_RESOURCE_DIR"] = os.path.join(lauf, "resources")
        return env

    def _passwort_setzen(self, programm, daten, passwort=None):
        passwort = passwort or self.einstellung.get("passwort") or self._neues_passwort()
        aus = subprocess.run([programm, "passwd", "--stdin"], input=passwort + "\n", text=True,
                             capture_output=True, timeout=60, env=self._umgebung(daten=daten, programm=programm))
        if aus.returncode != 0:
            text = ((aus.stdout or "") + (aus.stderr or "")).strip()
            raise EmberdFehler("Passwort laesst sich nicht setzen: %s" % (text[:400] or "unbekannter Fehler"))
        with self._sperre:
            self.einstellung["passwort"] = passwort
            self._sichern()
        return passwort

    @staticmethod
    def _neues_passwort():
        return secrets.token_urlsafe(12)

    def _passwort_noetig(self, daten):
        auth = os.path.join(daten, "emberd-auth.json")
        if not os.path.isfile(auth):
            return True
        try:
            with open(auth, encoding="utf-8") as f:
                return not (json.load(f) or {}).get("password")
        except (OSError, ValueError):
            return False

    def starten(self):
        if self._laufender_socket():
            return self.zustand()
        if sys.platform == "win32" or os.environ.get("ANDROID_ROOT"):
            raise EmberdFehler("emberd gibt es nur für Linux (Debian/Ubuntu, Raspberry Pi OS) – "
                              "auf Windows die Ember-App benutzen, auf Android läuft der Linux-Dienst nicht")
        programm = self.programm()
        if not programm:
            raise EmberdFehler("emberd ist nicht eingerichtet – bitte zuerst herunterladen")
        fassung, fehler = self._programm_version(programm)
        if fehler:
            self._programm_fehler = fehler
            raise EmberdFehler(fehler)
        self._programm_fehler = ""
        daten = self.datenordner_aktuell()
        os.makedirs(daten, exist_ok=True)
        try:
            os.chmod(daten, 0o700)
        except OSError:
            pass
        if not self.einstellung.get("passwort") and self._passwort_noetig(daten):
            self._passwort_setzen(programm, daten)
        log_pfad = os.path.join(self.basis, "emberd.log")
        os.makedirs(os.path.dirname(log_pfad), exist_ok=True)
        with open(log_pfad, "ab") as log:
            log.write(("\n=== H0rSt startet emberd %s (%s) ===\n" % (fassung, time.strftime("%Y-%m-%d %H:%M:%S"))).encode())
            log.flush()
            try:
                prozess = subprocess.Popen([programm], stdin=subprocess.DEVNULL, stdout=log, stderr=log,
                                           env=self._umgebung(daten=daten, programm=programm),
                                           start_new_session=True, close_fds=True)
            except OSError as fehler:
                raise EmberdFehler("emberd startet nicht: %s" % fehler)
        socket_pfad = self.socket_pfad(daten)
        ende = time.time() + 45
        while time.time() < ende:
            if prozess.poll() is not None:
                self._letzter_fehler = self._log_ende(log_pfad)
                raise EmberdFehler("emberd ist beim Start beendet: %s" % (self._letzter_fehler or "ohne Meldung"))
            if socket_antwortet(socket_pfad):
                with self._sperre:
                    self._prozess = prozess
                    self.einstellung.update({"pid": prozess.pid, "gestartet_von_h0rst": True,
                                             "version": fassung, "datenordner": daten})
                    self._sichern()
                self._letzter_fehler = ""
                return self.zustand()
            time.sleep(0.3)
        try:
            os.kill(prozess.pid, signal.SIGTERM)
        except OSError:
            pass
        raise EmberdFehler("emberd meldet sich nicht (45 s) – Log: %s" % log_pfad)

    @staticmethod
    def _log_ende(pfad):
        try:
            with open(pfad, "rb") as f:
                f.seek(0, os.SEEK_END)
                f.seek(max(0, f.tell() - 4000))
                text = f.read().decode("utf-8", "replace")
        except OSError:
            return ""
        zeilen = [z.strip() for z in text.splitlines() if z.strip() and not z.startswith("===")]
        return " | ".join(zeilen[-3:])[:800]

    def stoppen(self):
        pid = self._eigenes_pid()
        if not pid:
            if self._laufender_socket():
                raise EmberdFehler("emberd läuft, wurde aber nicht von H0rSt gestartet – "
                                  "bitte dort beenden (systemd, Docker oder emberd ctl)")
            raise EmberdFehler("emberd läuft nicht")
        with self._sperre:
            prozess = self._prozess if self._prozess is not None and self._prozess.pid == pid else None
        try:
            os.kill(pid, signal.SIGTERM)
        except OSError as fehler:
            raise EmberdFehler("emberd laesst sich nicht beenden: %s" % fehler)
        if prozess is not None:
            try:
                prozess.wait(timeout=60)
            except subprocess.TimeoutExpired:
                raise EmberdFehler("emberd beendet sich nicht (60 s) – bitte im Log nachsehen")
        else:
            ende = time.time() + 60
            while time.time() < ende:
                if not self._pid_lebt(pid):
                    break
                time.sleep(0.3)
            else:
                raise EmberdFehler("emberd beendet sich nicht (60 s) – bitte im Log nachsehen")
        with self._sperre:
            self._prozess = None
            self.einstellung.update({"pid": 0, "gestartet_von_h0rst": False})
            self._sichern()
        return self.zustand()

    def beenden(self):
        """Beim Beenden von H0rSt: nur den selbst gestarteten Dienst mitnehmen."""
        if self._eigenes_pid():
            try:
                self.stoppen()
            except EmberdFehler:
                pass

    def bei_start(self):
        if not self.einstellung.get("autostart"):
            return
        if not self.programm() or self._laufender_socket():
            return

        def tun():
            try:
                self.starten()
            except EmberdFehler as fehler:
                with self._sperre:
                    self._letzter_fehler = str(fehler)

        threading.Thread(target=tun, name="emberd-start", daemon=True).start()

    # --- Installation -----------------------------------------------------------------------------
    def release(self):
        with self._sperre:
            zeit, daten = self._release
        if daten and self.uhr() - zeit < 6 * 3600:
            return daten
        try:
            status, text = self._holen(RELEASES, header={"Accept": "application/vnd.github+json"},
                                       zeitgrenze=20)
            if status != 200:
                raise EmberdFehler("GitHub antwortet mit HTTP %d" % status)
            roh = json.loads(text)
            dateien = []
            for a in roh.get("assets") or []:
                name = a.get("name") or ""
                if name:
                    dateien.append({"name": name, "url": a.get("browser_download_url") or "",
                                    "groesse": int(a.get("size") or 0)})
            daten = {"version": str(roh.get("tag_name") or "").lstrip("vV"),
                     "datum": str(roh.get("published_at") or "")[:10], "dateien": dateien, "fehler": ""}
        except (EmberdFehler, ValueError, UnicodeDecodeError, OSError) as fehler:
            daten = {"version": "", "datum": "", "dateien": [], "fehler": str(fehler)[:400]}
        with self._sperre:
            self._release = (self.uhr(), daten)
        return daten

    def _arch(self):
        return ARCHEN.get((self.maschine or platform.machine() or "").lower(), "")

    @staticmethod
    def _finde(dateien, name):
        return next((d for d in dateien if d["name"] == name), None)

    def _release_waehlen(self, release):
        if release.get("fehler"):
            raise EmberdFehler("Release nicht abrufbar: %s" % release["fehler"])
        ar = self._arch()
        if not ar:
            raise EmberdFehler("Für diese Architektur (%s) gibt es kein emberd – nur x86_64 und aarch64"
                               % (self.maschine or platform.machine() or "?"))
        version = release.get("version") or ""
        if not version:
            raise EmberdFehler("GitHub nennt keine Fassung")
        tarball = self._finde(release["dateien"], "emberd-%s-linux-%s.tar.gz" % (version, ar))
        if not tarball:
            namen = ", ".join(d["name"] for d in release["dateien"] if d["name"].startswith("emberd-"))
            raise EmberdFehler("Kein emberd-Archiv für %s in der Fassung %s (gefunden: %s)"
                               % (ar, version, namen or "nichts"))
        summen = self._finde(release["dateien"], "emberd-%s-%s" % (version, SUMMEN_NAME))
        if not summen:
            raise EmberdFehler("Prüfsummendatei %s fehlt im Release %s" % (SUMMEN_NAME, version))
        return version, tarball, summen

    def roh_holen(self, url, grenze, fortschritt=None):
        if self._roh_holen is not None:
            return self._roh_holen(url, grenze, fortschritt)
        aktuell = url
        for _ in range(6):
            gepruefte_ips(aktuell)  # wirft, wenn der Host nicht oeffentlich ist
            anfrage = urllib.request.Request(aktuell, headers={"User-Agent": USER_AGENT,
                                                               "Accept": "application/octet-stream"})
            try:
                with pin_oeffner(aktuell).open(anfrage, timeout=60) as antwort:
                    gesamt = int(antwort.headers.get("Content-Length") or 0)
                    teile, gelesen = [], 0
                    while True:
                        stueck = antwort.read(65536)
                        if not stueck:
                            break
                        gelesen += len(stueck)
                        if gelesen > grenze:
                            raise EmberdFehler("Download größer als %d Bytes" % grenze)
                        teile.append(stueck)
                        if fortschritt is not None and gesamt:
                            fortschritt(gelesen, gesamt)
                    return b"".join(teile)
            except urllib.error.HTTPError as fehler:
                ziel = fehler.headers.get("Location") if fehler.headers else None
                if fehler.code in (301, 302, 303, 307, 308) and ziel:
                    fehler.close()
                    aktuell = urljoin(aktuell, ziel)
                    continue
                fehler.close()
                raise EmberdFehler("Download fehlgeschlagen: HTTP %d" % fehler.code)
            except (urllib.error.URLError, OSError) as fehler:
                raise EmberdFehler("Download fehlgeschlagen: %s" % fehler)
        raise EmberdFehler("Zu viele Weiterleitungen beim Download")

    @staticmethod
    def _pruefsumme(text, name):
        for zeile in str(text or "").splitlines():
            teile = zeile.replace("*", " ").split()
            if len(teile) >= 2 and teile[1] == name and len(teile[0]) == 64:
                return teile[0].lower()
        return ""

    def installation_zustand(self):
        with self._sperre:
            return dict(self._installation)

    def installieren(self):
        """Herunterladen, pruefen, entpacken und uebernehmen (synchron; die Oberflaeche startet das im Faden)."""
        if sys.platform == "win32" or os.environ.get("ANDROID_ROOT"):
            raise EmberdFehler("emberd gibt es nur für Linux – hier nicht verfügbar")
        version, tarball, summen = self._release_waehlen(self.release())
        with self._sperre:
            self._installation.update({"laeuft": True, "stand": "Lade Prüfsummen", "prozent": 0, "fehler": ""})
        try:
            text = self.roh_holen(summen["url"], 1024 * 1024).decode("utf-8", "replace")
            erwartet = self._pruefsumme(text, tarball["name"])
            if not erwartet:
                raise EmberdFehler("Prüfsumme für %s fehlt in %s" % (tarball["name"], SUMMEN_NAME))
            with self._sperre:
                self._installation.update({"stand": "Lade emberd %s" % version})

            def fortschritt(gelesen, gesamt):
                with self._sperre:
                    self._installation["prozent"] = min(99, int(gelesen * 100 / max(1, gesamt)))

            daten = self.roh_holen(tarball["url"], MAX_TARBALL, fortschritt)
            ist = hashlib.sha256(daten).hexdigest()
            if ist != erwartet:
                raise EmberdFehler("Prüfsumme stimmt nicht (erwartet %s, bekommen %s)" % (erwartet, ist))
            with self._sperre:
                self._installation.update({"stand": "Entpacke und prüfe", "prozent": 100})
            pfad = self.installiere_aus_daten(daten, version, tarball["name"])
            with self._sperre:
                self._installation.update({"laeuft": False, "stand": "Fertig", "prozent": 100, "fehler": ""})
            return pfad
        except (EmberdFehler, NetzFehler, OSError, ValueError) as fehler:
            with self._sperre:
                self._installation.update({"laeuft": False, "fehler": str(fehler), "stand": "Fehlgeschlagen"})
            raise

    def installation_starten(self):
        with self._sperre:
            if self._installation.get("laeuft"):
                return dict(self._installation)
            self._installation = {"laeuft": True, "stand": "Starte", "prozent": 0, "fehler": ""}

        def tun():
            try:
                self.installieren()
            except Exception as fehler:  # noqa: BLE001 - der Faden darf nie still sterben
                with self._sperre:
                    self._installation.update({"laeuft": False, "fehler": str(fehler),
                                               "stand": "Fehlgeschlagen"})

        threading.Thread(target=tun, name="emberd-installation", daemon=True).start()
        return self.installation_zustand()

    def installiere_aus_daten(self, daten, version, name):
        """Ein bereits geprueftes tar.gz uebernehmen; die Fassung im Programmordner wird ersetzt."""
        if len(daten) > MAX_TARBALL:
            raise EmberdFehler("Archiv größer als %d Bytes" % MAX_TARBALL)
        basis = self._eigener_einbau()
        os.makedirs(basis, exist_ok=True)
        neu = os.path.join(basis, ".neu-%d-%d" % (os.getpid(), int(time.time() * 1000)))
        os.makedirs(neu, exist_ok=True)
        try:
            self._entpacken(daten, neu)
            eintraege = [e for e in os.listdir(neu) if not e.startswith(".")]
            wurzel = os.path.join(neu, eintraege[0]) if len(eintraege) == 1 and os.path.isdir(
                os.path.join(neu, eintraege[0])) else neu
            programm = os.path.join(wurzel, "emberd")
            if not os.path.isfile(programm):
                raise EmberdFehler("Im Archiv fehlt das Programm emberd")
            os.chmod(programm, 0o755)
            fassung, fehler = self._programm_version(programm)
            if fehler:
                raise EmberdFehler(fehler)
            if fassung and version and fassung != version:
                raise EmberdFehler("Archiv meldet emberd %s statt %s" % (fassung, version))
            aktuell = os.path.join(basis, "aktuell")
            alt = None
            if os.path.isdir(aktuell):
                alt = os.path.join(basis, ".alt-%d" % int(time.time() * 1000))
                os.replace(aktuell, alt)
            os.replace(wurzel, aktuell)
            if alt:
                shutil.rmtree(alt, ignore_errors=True)
            with self._sperre:
                self.einstellung.update({"programm": "", "version": fassung or version})
                self._sichern()
                self._version = (self.uhr(), programm, fassung or version)
            return os.path.join(aktuell, "emberd")
        finally:
            shutil.rmtree(neu, ignore_errors=True)

    @staticmethod
    def _entpacken(daten, ziel):
        try:
            archiv = tarfile.open(fileobj=io.BytesIO(daten), mode="r:gz")
        except tarfile.TarError as fehler:
            raise EmberdFehler("Kein gültiges .tar.gz: %s" % fehler)
        ziel = os.path.abspath(ziel)
        gesamt, anzahl = 0, 0
        with archiv:
            for eintrag in archiv.getmembers():
                anzahl += 1
                if anzahl > MAX_DATEIEN:
                    raise EmberdFehler("Archiv enthält mehr als %d Dateien" % MAX_DATEIEN)
                p = PurePosixPath(eintrag.name.replace("\\", "/"))
                if p.is_absolute() or ".." in p.parts:
                    raise EmberdFehler("Archiv enthält einen unsicheren Pfad: %s" % eintrag.name)
                if not (eintrag.isfile() or eintrag.isdir()) or eintrag.issym() or eintrag.islnk():
                    raise EmberdFehler("Archiv enthält etwas anderes als Dateien und Ordner: %s" % eintrag.name)
                if eintrag.isfile():
                    gesamt += int(eintrag.size or 0)
                    if gesamt > MAX_ENTPACKT:
                        raise EmberdFehler("Archiv entpackt mehr als %d Bytes" % MAX_ENTPACKT)
                pfad = os.path.abspath(os.path.join(ziel, *p.parts))
                if pfad != ziel and not pfad.startswith(ziel + os.sep):
                    raise EmberdFehler("Archiv enthält einen unsicheren Pfad: %s" % eintrag.name)
                if eintrag.isdir():
                    os.makedirs(pfad, exist_ok=True)
                else:
                    os.makedirs(os.path.dirname(pfad), exist_ok=True)
                    quelle = archiv.extractfile(eintrag)
                    if quelle is None:
                        raise EmberdFehler("Archivdatei fehlt: %s" % eintrag.name)
                    with quelle, open(pfad, "wb") as zieldatei:
                        shutil.copyfileobj(quelle, zieldatei)
                    os.chmod(pfad, 0o755 if eintrag.mode & 0o111 else 0o644)

    # --- Suche und Downloads ----------------------------------------------------------------------
    def suchen(self, begriff, methode="global", art="", grenze=50):
        begriff = " ".join(str(begriff or "").split())[:300]
        if not begriff:
            raise EmberdFehler("Bitte einen Suchbegriff angeben")
        methode = methode if methode in ("global", "server", "kad", "ember") else "global"
        arten = {"Audio", "Video", "Image", "Pro", "Doc", "Arc", "Iso", "EmuleCollection"}
        art = art if art in arten else None
        try:
            grenze = max(1, min(200, int(grenze or 50)))
        except (TypeError, ValueError):
            grenze = 50
        socket_pfad = self._laufend()
        anfrage = int(self.uhr() * 1000)
        ergebnis = self._invoke(socket_pfad, "search_files",
                                {"query": begriff, "method": methode, "requestId": anfrage,
                                 "fileType": art}, zeitgrenze=150)
        treffer = []
        for r in ergebnis if isinstance(ergebnis, list) else []:
            if not isinstance(r, dict) or r.get("is_spam"):
                continue
            datei = r.get("file") if isinstance(r.get("file"), dict) else {}
            name = str(datei.get("name") or "")
            md4 = str(datei.get("hash") or "")
            if not name or len(md4) != 32:
                continue
            groesse = int(datei.get("size") or 0)
            aich = str(datei.get("aich_hash") or "")
            medium = datei.get("media") if isinstance(datei.get("media"), dict) else {}
            treffer.append({
                "name": name, "sauber": str(r.get("clean_name") or ""), "groesse": groesse,
                "hash": md4.upper(), "aich": aich, "link": link_bauen(name, groesse, md4, aich),
                "quellen": int(r.get("availability") or 0),
                "komplett": int(datei.get("complete_sources") or 0),
                "art": str(r.get("file_type") or ""), "herkunft": str(r.get("result_origin") or ""),
                "codec": str(medium.get("codec") or ""),
                "laenge": int(medium.get("duration_secs") or medium.get("duration") or 0)})
        treffer.sort(key=lambda t: (-t["quellen"], t["name"].lower()))
        return treffer[:grenze]

    def links_herunterladen(self, links):
        if isinstance(links, str):
            links = [links]
        if not isinstance(links, list) or not links:
            raise EmberdFehler("Bitte einen ed2k-Link angeben")
        text = "\n".join(str(l) for l in links)[:200000]
        socket_pfad = self._laufend()
        geparst = self._invoke(socket_pfad, "parse_ed2k_links", {"text": text})
        gefunden = geparst.get("links") if isinstance(geparst, dict) else []
        if not gefunden:
            raise EmberdFehler("Kein ed2k-Dateilink in der Eingabe")
        hinzu, fehler = [], []
        gesehen = set()
        for link in gefunden:
            md4 = str(link.get("hash") or "").lower()
            if not md4 or md4 in gesehen:
                continue
            gesehen.add(md4)
            try:
                antwort = self._invoke(socket_pfad, "start_download", {
                    "fileHash": md4, "fileName": str(link.get("name") or ""),
                    "fileSize": int(link.get("size") or 0), "peerIp": "", "peerPort": 0,
                    "extraSources": None, "emberFileHash": None,
                    "expectedAich": link.get("aich"), "friendEmberHash": None,
                    "webSources": link.get("web_sources")}, zeitgrenze=30)
                hinzu.append({"name": str(link.get("name") or ""),
                              "schon": bool((antwort or {}).get("already_queued")),
                              "id": str((antwort or {}).get("transfer_id") or "")})
            except EmberdFehler as e:
                fehler.append({"name": str(link.get("name") or ""), "fehler": str(e)})
        return {"hinzugefuegt": hinzu, "fehler": fehler, "ungueltig": int(geparst.get("invalid") or 0)}

    def download_aktion(self, aktion, ids):
        if isinstance(ids, str):
            ids = [ids]
        ids = [str(i) for i in (ids or []) if str(i)]
        socket_pfad = self._laufend()
        befehle = {"pause": "pause_transfer", "fortsetzen": "resume_transfer",
                   "stoppen": "stop_transfer", "abbrechen": "cancel_transfers_batch"}
        if aktion not in befehle or not ids:
            raise EmberdFehler("aktion: pause, fortsetzen, stoppen oder abbrechen – mit id")
        befehl = befehle[aktion]
        fehler = []
        for kennung in ids:
            try:
                if aktion == "abbrechen":
                    self._invoke(socket_pfad, befehl, {"transferIds": [kennung]})
                else:
                    self._invoke(socket_pfad, befehl, {"transferId": kennung})
            except EmberdFehler as e:
                fehler.append({"id": kennung, "fehler": str(e)})
        return {"fehler": fehler}

    # --- Zustand ----------------------------------------------------------------------------------
    def zustand(self, verwalten=False):
        programm = self.programm()
        socket_pfad = self._laufender_socket()
        daten = self.datenordner_aktuell()
        fassung = ""
        netzwerk, downloads, binding = {}, [], {}
        if socket_pfad:
            try:
                fassung = str(self._session(socket_pfad).get("version") or "")
            except EmberdFehler as fehler:
                self._letzter_fehler = str(fehler)
            try:
                netzwerk = self._invoke(socket_pfad, "get_network_stats", {}, zeitgrenze=10) or {}
            except EmberdFehler:
                netzwerk = {}
            try:
                binding = self._invoke(socket_pfad, "get_network_binding", {}, zeitgrenze=10) or {}
            except EmberdFehler:
                binding = {}
            try:
                alle = self._invoke(socket_pfad, "get_transfers", {}, zeitgrenze=15)
                downloads = [d for d in (alle if isinstance(alle, list) else [])
                             if isinstance(d, dict) and d.get("direction") == "download"]
            except EmberdFehler as fehler:
                self._letzter_fehler = str(fehler)
        if not fassung:
            fassung = self.version()
        if socket_pfad:
            self._letzter_fehler = ""
        return {
            "an": True,
            "verwalten": bool(verwalten),
            "installiert": bool(programm and os.path.isfile(programm) and not self._programm_fehler),
            "programm": programm,
            "version": fassung,
            "eigene_version": str(self.einstellung.get("version") or ""),
            "laeuft": bool(socket_pfad),
            "socket": socket_pfad,
            "gestartet_von_h0rst": bool(self._eigenes_pid()),
            "datenordner": daten,
            "downloadordner": self.downloadordner(),
            "fertige_downloads": self.fertige_downloads(),
            "port": self.einstellung["port"],
            "netz": bool(self.einstellung["netz"]),
            "autostart": bool(self.einstellung["autostart"]),
            "web_lokal": "http://127.0.0.1:%d/" % self.einstellung["port"],
            "passwort_gesetzt": bool(self.einstellung.get("passwort")),
            "passwort_von_h0rst": bool(self.einstellung.get("passwort")),
            "setup_code": self._setup_code(daten) if socket_pfad and self._eigenes_pid() else "",
            "netzwerk": netzwerk,
            "binding": binding,
            "downloads": downloads,
            "kandidaten": [p for p in programm_kandidaten() if p],
            "installation": self.installation_zustand(),
            "meldung": self._letzter_fehler or self._programm_fehler,
            "einstellungen": self.einstellungen_oeffentlich(verwalten),
        }

    @staticmethod
    def _setup_code(daten):
        try:
            with open(os.path.join(daten, "emberd-setup-code"), encoding="utf-8") as f:
                return f.read().strip()[:60]
        except OSError:
            return ""

    def passwort_zeigen(self):
        if self.einstellung.get("passwort"):
            return {"passwort": self.einstellung["passwort"], "von_h0rst": True}
        return {"passwort": "", "von_h0rst": False,
                "meldung": "Das Passwort wurde nicht von H0rSt gesetzt. Im Ember-Log steht beim ersten Start "
                           "ein Einrichtungscode, oder du setzt mit „Neues Passwort“ eines."}

    def passwort_neu(self):
        """Neues Passwort setzen; der eigene Dienst wird dafuer kurz gestoppt und danach gestartet."""
        programm = self.programm()
        if not programm:
            raise EmberdFehler("emberd ist nicht eingerichtet")
        if self._laufender_socket() and not self._eigenes_pid():
            raise EmberdFehler("emberd läuft nicht unter H0rSt – das Passwort dort ändern")
        war_an = bool(self._laufender_socket())
        if war_an:
            self.stoppen()
        passwort = self._neues_passwort()
        try:
            self._passwort_setzen(programm, self.datenordner_aktuell(), passwort)
        finally:
            if war_an:
                self.starten()
        return {"passwort": passwort, "von_h0rst": True}
