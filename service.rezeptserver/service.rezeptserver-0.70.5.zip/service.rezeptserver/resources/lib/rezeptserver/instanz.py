"""Nur eine Instanz auf dem System: zwei H0rSt gleichzeitig gaebe es sonst.

Zwei Server schreiben gleichzeitig in dieselbe SQLite-Datei (Anbieter, Einstellungen, Verlauf)
und belegen dieselben Ports. Gesperrt wird deshalb zweifach:

  * eine System-Sperre fuer den ganzen Rechner (je Systembenutzer, damit sich mehrere
    Benutzerkonten nicht gegenseitig aussperren) - unabhaengig davon, welche --daten-Datei
    gestartet wird. Sie liegt im Temp-Ordner; H0RST_INSTANZ_SPERRE ueberschreibt den Ort.
  * eine Daten-Sperre neben der Nutzerdaten-Datei (nutzerdaten.db.sperre), damit auch
    verschiedene Benutzerkonten nicht dieselbe Datenbank gleichzeitig oeffnen.

Beide sind Dateisperren: Sie gelten fuer alle Prozesse desselben Systems, halten nur, solange
der Prozess lebt, und brauchen keine Aufraeumroutine. Geprueft wird vor dem Aufbau des Servers
in Dienst.starte(); damit gilt die Sperre fuer Kommandozeile, Raspberry Pi, Docker, Kodi,
Termux und die Android-App gleichermassen.
"""

import errno
import logging
import os
import tempfile

log = logging.getLogger("rezeptserver")

ENDUNG = ".sperre"
SYSTEMNAME = "h0rst.sperre"
FEHLERNUMMERN = (errno.EACCES, errno.EAGAIN, errno.EWOULDBLOCK, errno.EDEADLK)


class InstanzFehler(RuntimeError):
    """H0rSt laeuft bereits."""


def pfad(datenbank):
    """Daten-Sperrdatei neben der Nutzerdaten-Datei (alte .../konfig.json zeigen auf nutzerdaten.db)."""
    return datenbank + ENDUNG


def systempfad():
    """System-Sperrdatei: eine fuer den Rechner, getrennt je Systembenutzer.

    H0RST_INSTANZ_SPERRE setzt den Ort (Tests, Container mit eigenem Laufzeitordner).
    """
    eigen = os.environ.get("H0RST_INSTANZ_SPERRE", "").strip()
    if eigen:
        return eigen
    name = SYSTEMNAME
    if hasattr(os, "getuid"):
        name = "h0rst-%d.sperre" % os.getuid()
    return os.path.join(tempfile.gettempdir(), name)


class Sperre:
    """System- und Daten-Sperre; erwerben() oder mit with benutzen."""

    def __init__(self, datenbank):
        self.datenbank = datenbank
        self.pfad = pfad(datenbank)
        self.system = systempfad()
        self._dateien = []

    def erwerben(self):
        if self._dateien:
            return self
        self._erwerbe(self.system, "System", self.system)
        try:
            self._erwerbe(self.pfad, "Daten", self.pfad)
        except Exception:
            self.gib_frei()
            raise
        return self

    def _erwerbe(self, pfad, art, anzeige):
        os.makedirs(os.path.dirname(os.path.abspath(pfad)), exist_ok=True)
        try:
            datei = os.open(pfad, os.O_RDWR | os.O_CREAT, 0o600)
        except OSError as fehler:
            if fehler.errno in FEHLERNUMMERN:
                raise InstanzFehler("H0rSt laeuft bereits oder die %s-Sperre ist nicht zugaenglich "
                                    "(%s; Daten %s)" % (art, anzeige, self.pfad)) from None
            raise
        try:
            _sperren(datei)
        except OSError as fehler:
            fremd = _pid(datei)
            os.close(datei)
            if fehler.errno not in FEHLERNUMMERN:
                raise
            raise InstanzFehler("H0rSt laeuft bereits%s (%s-Sperre %s; Daten %s)" % (
                " als Prozess %s" % fremd if fremd else "", art, anzeige, self.pfad)) from None
        try:
            os.ftruncate(datei, 0)
            os.write(datei, ("%d\n" % os.getpid()).encode("ascii"))
        except OSError:  # die Sperre haelt auch ohne Prozessnummer; sie ist nur fuer die Meldung da
            log.warning("Prozessnummer nicht in die Sperre %s geschrieben", anzeige)
        self._dateien.append(datei)

    def gib_frei(self):
        while self._dateien:
            datei = self._dateien.pop()
            try:
                _entsperren(datei)
            finally:
                os.close(datei)

    def __enter__(self):
        return self.erwerben()

    def __exit__(self, *fehler):
        self.gib_frei()


try:
    import fcntl
except ImportError:  # Windows
    fcntl = None


def _sperren(datei):
    if fcntl is not None:
        fcntl.flock(datei, fcntl.LOCK_EX | fcntl.LOCK_NB)
        return
    import msvcrt
    os.lseek(datei, 0, os.SEEK_SET)
    msvcrt.locking(datei, msvcrt.LK_NBLCK, 1)


def _entsperren(datei):
    if fcntl is not None:
        fcntl.flock(datei, fcntl.LOCK_UN)
        return
    import msvcrt
    os.lseek(datei, 0, os.SEEK_SET)
    msvcrt.locking(datei, msvcrt.LK_UNLCK, 1)


def _pid(datei):
    try:
        os.lseek(datei, 0, os.SEEK_SET)
        roh = os.read(datei, 64).decode("ascii", "replace").strip()
    except OSError:
        return ""
    return roh if roh.isdigit() else ""
