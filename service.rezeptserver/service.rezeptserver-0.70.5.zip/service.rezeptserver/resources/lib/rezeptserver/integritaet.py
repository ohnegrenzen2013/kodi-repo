"""Integritaetspruefung: alle Funktionen, Rezepte, Anbieter, Addons, Plugins, Links und Verweise.

Die Pruefung ist absichtlich strukturell und ohne Netz: Sie beantwortet, ob H0rSt seine eigenen
Bausteine sauber verdrahtet hat, nicht ob ein fremder Dienst gerade erreichbar ist. Fuer die
Erreichbarkeit gibt es den Verbindungstest je Anbieter (anbindungen_pruefen.py).

Geprueft werden:

  * Module und Reiter (Register, Navigation, doppelte IDs)
  * Rezepte (Manifeste, Konten, Skripte)
  * Anbieter und Provider (Kategorie, Anmeldeart, Typ, Vorlage, Rezept-Verweise)
  * Addons, Plugins und eigene Quellen (Stremio/mHub, Nuvio-JS, Katalogseiten)
  * Links und Verweise (Heim-Links, Zugangsdaten ohne Anbieter, Netzweg, Waechter-Ersatz)
  * Adressen (alle eingetragenen http(s)-Werte auf Form und Schema)
  * die zusammengesetzte Oberflaeche (doppelte IDs, data-kopie, aria- und label-Verweise)
  * Versionen (rezeptserver/__init__.py gegen kodi/service.rezeptserver/addon.xml)
"""

import os
import re
from html.parser import HTMLParser
from urllib.parse import urlsplit
from xml.etree import ElementTree

from . import __version__, anbieter, links, modul, modulregister, verweise

FEHLER = "fehler"
WARNUNG = "warnung"
HINWEIS = "hinweis"
URL_PLATZHALTER = ("…", "<", ">", "{", "}", "DEINNAME", "example.invalid")
_URL = re.compile(r"^https?://[^\s]+$", re.I)


def _befund(ziel, pruefung, schwere, text, **felder):
    ziel.append(dict(felder, pruefung=pruefung, schwere=schwere, text=text))


def _adresse(wert):
    """(ok, meldung) fuer eine eingetragene Adresse; Platzhalter gelten als absichtlich leer."""
    roh = str(wert or "").strip()
    if not roh or any(z in roh for z in URL_PLATZHALTER):
        return True, ""
    if not _URL.match(roh):
        return False, "keine http(s)-Adresse"
    teile = urlsplit(roh)
    if not teile.netloc:
        return False, "Adresse ohne Rechner"
    return True, ""


def _strings(daten, pfad=""):
    """Alle Zeichenketten in Nutzerdaten mit ihrem Pfad (nur dict/list, ohne Geheimniswerte)."""
    if isinstance(daten, dict):
        for schluessel, wert in daten.items():
            name = "%s.%s" % (pfad, schluessel) if pfad else str(schluessel)
            yield from _strings(wert, name)
    elif isinstance(daten, list):
        for nummer, wert in enumerate(daten):
            yield from _strings(wert, "%s[%d]" % (pfad, nummer))
    elif isinstance(daten, str):
        yield pfad, daten


def _module(befunde, module):
    register = modulregister.pruefe()
    for text in register.get("fehler") or []:
        _befund(befunde, "module", FEHLER, text)
    ids = [m.id for m in module]
    for doppelt in sorted({i for i in ids if ids.count(i) > 1}):
        _befund(befunde, "module", FEHLER, "Modul %s kommt mehrfach vor" % doppelt)
    for m in module:
        for text in modul.pruefe(m.daten):
            _befund(befunde, "module", FEHLER, "%s: %s" % (m.id, text))
        if m.skript and not os.path.isfile(os.path.join(m.ordner, m.skript)):
            _befund(befunde, "module", FEHLER, "%s: Skript %s fehlt" % (m.id, m.skript))
    return {"module": len(module), "tabs": register.get("tabs", 0)}


def _anbieter(befunde, module, daten):
    try:
        liste = anbieter.liste(module, daten)
    except (anbieter.AnbieterFehler, ValueError, KeyError) as fehler:
        _befund(befunde, "anbieter", FEHLER, "Anbieterliste nicht lesbar: %s" % fehler)
        return {"anbieter": 0, "addons": 0}
    modul_ids = {m.id for m in module}
    known = {a["id"] for a in liste}
    addons = 0
    for a in liste:
        name = a.get("name") or a.get("id")
        if a.get("kategorie") not in anbieter.KATEGORIEN:
            _befund(befunde, "anbieter", FEHLER, "%s: unbekannte Kategorie %s" % (name, a.get("kategorie")))
        if a.get("anmeldung") not in anbieter.ANMELDUNGEN:
            _befund(befunde, "anbieter", FEHLER, "%s: unbekannte Anmeldeart %s" % (name, a.get("anmeldung")))
        if a.get("eigen"):
            if a.get("typ") not in anbieter.TYPEN:
                _befund(befunde, "anbieter", FEHLER, "%s: unbekannter Typ %s" % (name, a.get("typ")))
            if a.get("vorlage") and not _vorlage_ok(a.get("vorlage")):
                _befund(befunde, "anbieter", WARNUNG, "%s: Vorlage %s nicht gefunden" % (name, a.get("vorlage")))
        elif not a.get("rezepte"):
            _befund(befunde, "anbieter", WARNUNG, "%s: kein Rezept mit diesem Konto" % name)
        for rezept in a.get("rezepte") or []:
            if rezept not in modul_ids:
                _befund(befunde, "anbieter", FEHLER, "%s: Rezept %s fehlt" % (name, rezept))
        if a.get("typ") in ("stremio-addon", "mhub-addon"):
            addons += 1
        for feld in a.get("felder") or []:
            if feld.get("key") in ("url", "api_url", "manifest") and feld.get("wert"):
                ok, text = _adresse(feld["wert"])
                if not ok:
                    _befund(befunde, "links", FEHLER, "%s: %s (%s)" % (name, text, feld["key"]))
    return {"anbieter": len(liste), "addons": addons, "konten": len(known)}


def _vorlage_ok(vorlage):
    try:
        from . import vorlagen
        return str(vorlage) in getattr(vorlagen, "NACH_ID", {})
    except (ImportError, AttributeError):
        return True


def _plugins(befunde, daten):
    anzahl = 0
    try:
        from . import nuvio_plugin
        plugins = nuvio_plugin.plugins(daten)
        anzahl = len(plugins)
        ids = [p.get("id") for p in plugins]
        for doppelt in sorted({i for i in ids if i and ids.count(i) > 1}):
            _befund(befunde, "plugins", FEHLER, "Nuvio-Plugin %s kommt doppelt vor" % doppelt)
        if anzahl > nuvio_plugin.MAX_PLUGINS:
            _befund(befunde, "plugins", FEHLER, "Mehr als %d Nuvio-Plugins" % nuvio_plugin.MAX_PLUGINS)
    except (ImportError, ValueError, KeyError) as fehler:
        _befund(befunde, "plugins", FEHLER, "Nuvio-Plugins nicht lesbar: %s" % fehler)
    try:
        from . import eigene_quelle
        for quelle in eigene_quelle.quellen(daten):
            ok, text = _adresse(quelle.get("url"))
            if not ok:
                _befund(befunde, "plugins", FEHLER, "Eigene Quelle %s: %s" % (quelle.get("name") or "?", text))
    except (ImportError, ValueError, KeyError) as fehler:
        _befund(befunde, "plugins", FEHLER, "Eigene Quellen nicht lesbar: %s" % fehler)
    return {"plugins": anzahl}


def _links(befunde, daten, eingebaut):
    anzahl = 0
    try:
        anzahl = len(links.pruefe(daten.get("links")))
    except links.LinkFehler as fehler:
        _befund(befunde, "links", FEHLER, "Heim-Links: %s" % fehler)
    for problem in verweise.pruefen(daten, eingebaut):
        _befund(befunde, "verweise", WARNUNG, problem.get("text") or str(problem),
                art=problem.get("art", ""))
    for pfad, wert in _strings(daten):
        if not wert.lower().startswith(("http://", "https://")):
            continue
        ok, text = _adresse(wert)
        if not ok:
            _befund(befunde, "links", WARNUNG, "%s: %s" % (pfad, text))
    return {"links": anzahl}


class _Seite(HTMLParser):
    """Sammelt IDs und die Verweise, die auf sie zeigen."""

    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.ids = []
        self.kopien = []
        self.aria = []
        self.labels = []
        self.anker = []

    def handle_starttag(self, tag, attrs):
        a = dict(attrs)
        if a.get("id"):
            self.ids.append(a["id"])
        if a.get("data-kopie"):
            self.kopien.append((tag, a["data-kopie"]))
        if a.get("for"):
            self.labels.append((tag, a["for"]))
        for schluessel in ("aria-controls", "aria-labelledby", "aria-describedby"):
            for ziel in str(a.get(schluessel) or "").split():
                self.aria.append((schluessel, ziel))
        if tag == "a":
            href = str(a.get("href") or "")
            if href.startswith("#") and len(href) > 1:
                self.anker.append(href[1:])


def _seite(befunde, seite):
    if not seite:
        return {"ids": 0, "verweise": 0}
    p = _Seite()
    try:
        p.feed(seite)
        p.close()
    except Exception as fehler:  # HTMLParser ist robust, aber die Meldung soll nie den Bericht kippen
        _befund(befunde, "seite", WARNUNG, "Oberflaeche nicht lesbar: %s" % fehler)
        return {"ids": 0, "verweise": 0}
    ids = set(p.ids)
    for doppelt in sorted({i for i in p.ids if p.ids.count(i) > 1}):
        _befund(befunde, "seite", FEHLER, "ID %s kommt in der Oberflaeche doppelt vor" % doppelt)
    for _tag, ziel in p.kopien:
        if ziel not in ids:
            _befund(befunde, "seite", FEHLER, "Kopierknopf zeigt auf fehlende ID %s" % ziel)
    for art, ziel in p.aria:
        if ziel not in ids:
            _befund(befunde, "seite", WARNUNG, "%s zeigt auf fehlende ID %s" % (art, ziel))
    for _tag, ziel in p.labels:
        if ziel not in ids:
            _befund(befunde, "seite", WARNUNG, "label for zeigt auf fehlende ID %s" % ziel)
    for ziel in p.anker:
        if ziel not in ids:
            _befund(befunde, "seite", WARNUNG, "Sprungmarke #%s fehlt" % ziel)
    return {"ids": len(p.ids), "verweise": len(p.kopien) + len(p.aria) + len(p.labels) + len(p.anker)}


def _kodi_pfad():
    """addon.xml im Quellstand oder im installierten Kodi-Addon; leer, wenn keins mitgeliefert ist."""
    paket = os.path.dirname(os.path.abspath(__file__))
    kandidaten = (
        os.path.join(os.path.dirname(paket), "kodi", "service.rezeptserver", "addon.xml"),
        os.path.join(paket, os.pardir, os.pardir, os.pardir, "addon.xml"),
    )
    for pfad in kandidaten:
        pfad = os.path.normpath(pfad)
        if os.path.isfile(pfad):
            return pfad
    return ""


def _version(befunde):
    pfad = _kodi_pfad()
    if not pfad:
        # Android, pip und andere Betriebsarten ohne Kodi-Addon: dann gibt es nichts zu vergleichen.
        return {}
    try:
        wurzel = ElementTree.parse(pfad).getroot()
    except (OSError, ElementTree.ParseError) as fehler:
        _befund(befunde, "version", FEHLER, "Kodi-addon.xml nicht lesbar: %s" % fehler)
        return {}
    kodi = wurzel.get("version") or ""
    if kodi != __version__:
        _befund(befunde, "version", FEHLER,
                "Versionen passen nicht: rezeptserver %s, Kodi %s" % (__version__, kodi))
    return {"kodi": kodi}


def _gruppe(pid, name, befunde, zahlen=None):
    eigen = [b for b in befunde if b["pruefung"] == pid]
    return {"id": pid, "name": name, "befunde": eigen,
            "ok": not any(b["schwere"] == FEHLER for b in eigen),
            "fehler": sum(b["schwere"] == FEHLER for b in eigen),
            "warnungen": sum(b["schwere"] == WARNUNG for b in eigen),
            "zahlen": zahlen or {}}


def bericht(daten=None, module=None, seite=""):
    """Vollstaendiger Integritaetsbericht; `daten` sind die Nutzerdaten, `module` die geladenen Rezepte."""
    daten = daten if isinstance(daten, dict) else {}
    module = list(module or [])
    befunde = []
    zahlen = {}
    zahlen.update(_module(befunde, module))
    zahlen.update(_anbieter(befunde, module, daten))
    zahlen.update(_plugins(befunde, daten))
    try:
        eingebaut = [a["id"] for a in anbieter.liste(module, daten) if not a.get("eigen")]
    except (anbieter.AnbieterFehler, ValueError, KeyError):
        eingebaut = []
    zahlen.update(_links(befunde, daten, eingebaut))
    zahlen.update(_seite(befunde, seite))
    zahlen.update(_version(befunde))
    gruppen = [
        _gruppe("module", "Module und Reiter", befunde),
        _gruppe("anbieter", "Anbieter und Provider", befunde),
        _gruppe("plugins", "Addons, Plugins und Quellen", befunde),
        _gruppe("verweise", "Links und Verweise", befunde),
        _gruppe("seite", "Oberflaeche und Verweise", befunde),
        _gruppe("version", "Versionen", befunde),
    ]
    # Rezepte/Module und Anbieter teilen sich die Befundart "anbieter"; die Gruppe "module" nennt nur Module.
    return {"version": __version__, "gesund": not any(b["schwere"] == FEHLER for b in befunde),
            "befunde": befunde, "pruefungen": gruppen, "zahlen": dict(zahlen, befunde=len(befunde),
            fehler=sum(b["schwere"] == FEHLER for b in befunde),
            warnungen=sum(b["schwere"] == WARNUNG for b in befunde))}
