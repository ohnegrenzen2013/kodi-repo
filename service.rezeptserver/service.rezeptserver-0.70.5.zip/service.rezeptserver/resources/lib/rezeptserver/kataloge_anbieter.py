"""Kataloge: TMDb-Discover je Streaming-Anbieter in Deutschland.

Joyn, RTL+, WOW und Pluto TV haben seit 0.70.1 einen freien Katalog ueber JustWatch
(kataloge_justwatch.py, ohne Schluessel). waipu.tv fehlt dort; dafuer bleiben die
Anbieter-IDs aus TMDbs Anbieterliste fuer DE (/watch/providers/movie?watch_region=DE),
zugeordnet ueber das bestehende streaming_dienste-Verzeichnis. Fehlt ein Anbieter bei
TMDb, bleibt seine Reihe einfach aus.
"""

from . import streaming_dienste
from .kataloge_grund import ZEIT, KatalogFehler
from .kataloge_justwatch import ANBIETER as JW_ANBIETER
from .tmdb import TmdbFehler

ANBIETER = ("joyn", "rtlplus", "wow", "waipu", "pluto")


class KatalogeAnbieterMixin:
    def _tmdb_anbieter(self, daten):
        klient, schluessel = self._tmdb(daten)
        stelle = ("tmdb-anbieter", "DE")
        with self._sperre:
            alt = self._speicher.get(stelle)
            if alt and self.uhr() - alt[0] < ZEIT:
                return alt[1]
        try:
            roh = klient.watch_providers("movie", schluessel)
        except TmdbFehler as fehler:
            raise KatalogFehler(str(fehler))
        ids = {}
        for eintrag in roh:
            dienst = streaming_dienste.finde(eintrag.get("provider_name"))
            if dienst and dienst["id"] in ANBIETER and dienst["id"] not in ids:
                ids[dienst["id"]] = {"provider_id": eintrag.get("provider_id"), "name": dienst["name"]}
        with self._sperre:
            self._speicher[stelle] = (self.uhr(), ids)
        return ids

    def anbieter_liste(self, daten=None):
        """Alle Anbieter-Reihen: die vier freien immer, waipu.tv nur mit TMDb-Schluessel."""
        try:
            ids = self._tmdb_anbieter(daten)
        except KatalogFehler:
            ids = {}
        liste = []
        for kennung in ANBIETER:
            if kennung in JW_ANBIETER:
                name = JW_ANBIETER[kennung][1]
            elif kennung in ids:
                name = ids[kennung]["name"]
            else:
                continue
            liste.append({"id": kennung, "name": name})
        return liste

    def tmdb_anbieter(self, kennung, typ, skip=0, daten=None):
        if typ not in ("movie", "series"):
            raise KatalogFehler("Typ movie oder series")
        if kennung in JW_ANBIETER:
            return self.justwatch(kennung, typ, skip)
        try:
            skip = max(0, int(skip or 0))
        except (TypeError, ValueError):
            skip = 0
        ids = self._tmdb_anbieter(daten)
        if kennung not in ids:
            raise KatalogFehler("Kein TMDb-Anbieter fuer %s in Deutschland" % kennung)
        klient, schluessel = self._tmdb(daten)
        seite = skip // 20 + 1
        try:
            titel, seiten = klient.discover_seite(
                typ, schluessel, with_watch_providers=str(ids[kennung]["provider_id"]),
                watch_region="DE", sort_by="popularity.desc", page=seite)
        except TmdbFehler as fehler:
            raise KatalogFehler(str(fehler))
        return {"titel": titel, "mehr": seite < seiten, "weiter": skip + 20,
                "name": "Bei %s" % ids[kennung]["name"]}

