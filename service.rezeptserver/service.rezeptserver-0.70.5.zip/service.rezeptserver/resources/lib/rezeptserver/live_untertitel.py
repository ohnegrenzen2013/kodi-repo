"""Live-KI-Untertitel: Sprachabschnitte transkribieren und in die Zielsprache uebersetzen.

Vorbild ist ARVIOS ``GeminiSegmentEngine`` (Apache-2.0): Der Client schneidet wenige Sekunden
Ton aus der laufenden Wiedergabe, H0rSt schickt sie an Gemini und bekommt getimte Zeilen zurueck.
Der Schluessel bleibt auf dem Server, damit Fernseher und andere Clients ohne eigenen Zugang
denselben Dienst nutzen koennen. Die Pruefung ist absichtlich strukturell und ohne feste Bindung
an ein Geraet; die Aufnahme selbst macht der Client.
"""

import base64
import json
import re
from urllib.parse import urlsplit

from .netz import NetzFehler, oeffentlich_antwort_holen

GEMINI_BASIS = "https://generativelanguage.googleapis.com/v1beta"
STANDARD_MODELL = "gemini-3.5-flash-lite"
ZEITGRENZE = 20.0
MAX_AUDIO_BYTES = 6_000_000
MAX_TEXT = 4000
MAX_KONTEXT = 8
MAX_KONTEXT_ZEILE = 200
MAX_LINES = 24
MAX_LINE = 200
MAX_OFFSET_MS = 600_000

SPRACHEN = {
    "de": "Deutsch", "en": "Englisch", "fr": "Franzoesisch", "es": "Spanisch", "it": "Italienisch",
    "pt": "Portugiesisch", "nl": "Niederlaendisch", "pl": "Polnisch", "ru": "Russisch", "tr": "Tuerkisch",
    "ar": "Arabisch", "he": "Hebraeisch", "fa": "Persisch", "ur": "Urdu", "hi": "Hindi", "ja": "Japanisch",
    "ko": "Koreanisch", "zh": "Chinesisch", "sv": "Schwedisch", "da": "Daenisch", "no": "Norwegisch",
    "fi": "Finnisch", "cs": "Tschechisch", "el": "Griechisch", "hu": "Ungarisch", "ro": "Rumaenisch",
    "uk": "Ukrainisch", "vi": "Vietnamesisch", "th": "Thai", "id": "Indonesisch",
}
RTL = {"ar", "he", "fa", "ur", "yi"}
_MODELL = re.compile(r"^[A-Za-z0-9._-]{1,80}$")


class LutFehler(ValueError):
    """Der Wunsch ist nicht erfuellbar (Eingabe, Schalter oder Modell)."""


class SchluesselFehler(LutFehler):
    """Der API-Schluessel fehlt oder wird abgewiesen."""


class KontingentFehler(LutFehler):
    """Das Kontingent ist erschoepft (HTTP 429); spaeter erneut versuchen."""


def sprachkuerzel(werte):
    """Kuerzel wie ``de`` oder ``de-DE``; ein ausgeschriebener Name bleibt als Name."""
    roh = str((werte or {}).get("liveut_sprache") or "de").strip()
    kuerzel = roh.split("-")[0].split("_")[0].lower()
    return kuerzel if kuerzel in SPRACHEN else "de"


def sprach_name(werte):
    return SPRACHEN[sprachkuerzel(werte)]


def sprache_aus_eingabe(eingabe):
    """Zielsprache einer einzelnen Anfrage (``sprache``), sonst ``None``.

    Clients wie ARVIO kennen die Sprache ihres Profils und schicken sie mit; ohne Angabe
    bleibt es bei der Einstellung des Servers. Unbekannte Werte werden nicht uebernommen.
    """
    roh = str((eingabe or {}).get("sprache") or "").strip()
    kuerzel = roh.split("-")[0].split("_")[0].lower()
    return kuerzel if kuerzel in SPRACHEN else None


def ist_rtl(werte):
    return sprachkuerzel(werte) in RTL


def modell(werte):
    roh = str((werte or {}).get("liveut_modell") or STANDARD_MODELL).strip()
    return roh if _MODELL.match(roh) else STANDARD_MODELL


def basis(werte):
    """Basis-Adresse ohne Schraegstrich am Ende; nur http(s) ohne Zugangsdaten."""
    roh = str((werte or {}).get("liveut_basis") or GEMINI_BASIS).strip().rstrip("/")
    try:
        teile = urlsplit(roh)
        host = teile.hostname
        teile.port  # noqa: B018 - ungueltige Ports werfen ValueError
    except ValueError:
        return GEMINI_BASIS
    if teile.scheme not in ("http", "https") or not host or teile.username or teile.password:
        return GEMINI_BASIS
    return roh


def segment_sekunden(werte):
    roh = str((werte or {}).get("liveut_segment") or "4")
    return int(roh) if roh in ("3", "4", "6") else 4


def kontext_zeilen(werte):
    roh = str((werte or {}).get("liveut_kontext") or "3")
    return int(roh) if roh in ("0", "3", "5") else 3


def zustand(werte):
    """Stand ohne Geheimnis: nur ob ein Schluessel gesetzt ist."""
    werte = werte or {}
    schluessel = bool(str(werte.get("liveut_schluessel") or "").strip())
    an = werte.get("liveut_an") is True
    if not an:
        meldung = "Ausgeschaltet. Einschalten unter Einstellungen → Live-KI-Untertitel."
    elif not schluessel:
        meldung = "Kein API-Schluessel eingetragen."
    else:
        meldung = "Bereit: %s, Zielsprache %s." % (modell(werte), sprach_name(werte))
    return {"an": an, "schluessel_gesetzt": schluessel, "modell": modell(werte),
            "basis": basis(werte), "sprache": sprachkuerzel(werte), "sprache_name": sprach_name(werte),
            "rtl": ist_rtl(werte), "segment_sekunden": segment_sekunden(werte),
            "kontext_zeilen": kontext_zeilen(werte), "meldung": meldung,
            "grenzen": {"audio_bytes": MAX_AUDIO_BYTES, "text": MAX_TEXT, "lines": MAX_LINES}}


def wav_pruefen(roh):
    """Rohbytes einer WAV-Datei; wirft bei fremdem Format oder Ueberlaenge."""
    if len(roh) < 44 or roh[:4] != b"RIFF" or roh[8:12] != b"WAVE":
        raise LutFehler("Nur WAV-Ton wird angenommen.")
    if len(roh) > MAX_AUDIO_BYTES:
        raise LutFehler("Tonabschnitt zu gross (%d Bytes, hoechstens %d)." % (len(roh), MAX_AUDIO_BYTES))
    return roh


def audio_lesen(text):
    """Base64-WAV aus der Anfrage; leer, wenn kein Ton mitkam."""
    roh = "".join(str(text or "").split())
    if not roh:
        return b""
    if len(roh) > MAX_AUDIO_BYTES * 2:
        raise LutFehler("Tonabschnitt zu gross.")
    try:
        daten = base64.b64decode(roh, validate=True)
    except (ValueError, TypeError):
        raise LutFehler("Ton ist kein gueltiges Base64.") from None
    return wav_pruefen(daten)


def text_lesen(text):
    roh = " ".join(str(text or "").split())
    if len(roh) > MAX_TEXT:
        raise LutFehler("Text zu lang (hoechstens %d Zeichen)." % MAX_TEXT)
    return roh


def kontext_lesen(kontext):
    if not isinstance(kontext, list):
        return []
    return [" ".join(str(z).split())[:MAX_KONTEXT_ZEILE] for z in kontext[-MAX_KONTEXT:] if str(z).strip()]


def system_prompt(name):
    return (
        "Du schreibst Live-Untertitel. Der Ton ist ein paar Sekunden einer Fernsehsendung. "
        "Schreibe das Gesagte mit und uebersetze es nach %s. Ist die Sprache schon %s, gib die "
        "Abschrift zurueck. Formuliere natuerliches, idiomatisches %s wie ein Berufsuntertitler: "
        "kurze Zeilen, richtiges Geschlecht, Namen so, wie sie gesprochen werden. Teile den Text in "
        "Untertitelzeilen von etwa 42 Zeichen in Sprechreihenfolge. Gib je Zeile startOffsetMs an, "
        "die Zeit vom Anfang des Tons. Ohne verstaendliche Sprache (Musik, Rauschen) antworte mit "
        "einer leeren Liste. Beschreibe keine Geraeusche und ergaenze keine Hinweise. Antworte nur "
        "mit JSON: {\"lines\":[{\"text\":\"...\",\"startOffsetMs\":0}],\"sourceLanguage\":\"en\"}"
    ) % (name, name, name)


def anfrage_koerper(werte, eingabe):
    """Gemini-``generateContent``-Koerper (JSON) aus Ton oder Text."""
    name = sprach_name(werte)
    ton = audio_lesen((eingabe or {}).get("audio"))
    text = text_lesen((eingabe or {}).get("text"))
    if not ton and not text:
        raise LutFehler("Ohne Ton oder Text gibt es nichts zu untertiteln.")
    kontext = kontext_lesen((eingabe or {}).get("kontext"))
    hinweis = "Untertitele diesen Ton in %s." % name if ton else "Untertitele diesen Text in %s." % name
    if kontext:
        hinweis = ("Bisherige Untertitel, nur als Zusammenhang (nicht wiederholen):\n- %s\n%s"
                   % ("\n- ".join(kontext), hinweis))
    teile = []
    if ton:
        teile.append({"inline_data": {"mime_type": "audio/wav", "data": base64.b64encode(ton).decode("ascii")}})
    teile.append({"text": hinweis if not text else "%s\n\n%s" % (hinweis, text)})
    return json.dumps({
        "system_instruction": {"parts": [{"text": system_prompt(name)}]},
        "contents": [{"parts": teile}],
        "generationConfig": {"temperature": 0.2, "responseMimeType": "application/json"},
    }, ensure_ascii=False)


def _json_aus(text):
    roh = str(text or "").strip()
    if roh.startswith("```"):
        roh = re.sub(r"^```[a-zA-Z]*\s*", "", roh)
        roh = re.sub(r"\s*```$", "", roh).strip()
    try:
        return json.loads(roh)
    except (ValueError, TypeError):
        pass
    for auf, zu in (("{", "}"), ("[", "]")):
        anfang, ende = roh.find(auf), roh.rfind(zu)
        if anfang >= 0 and ende > anfang:
            try:
                return json.loads(roh[anfang:ende + 1])
            except (ValueError, TypeError):
                continue
    return None


def _zeile(text):
    roh = " ".join(str(text or "").replace("\n", " ").split())
    roh = "".join(z for z in roh if z >= " " or z == "\t")
    return roh[:MAX_LINE]


def antwort_lesen(text, werte, modell_name=None):
    """Gemini-Antwort → getimte Zeilen; leere Liste, wenn nichts gesprochen wurde."""
    daten = _json_aus(text)
    if not isinstance(daten, dict):
        raise LutFehler("Antwort des Modells ist kein JSON-Objekt.")
    kandidaten = daten.get("candidates")
    if not isinstance(kandidaten, list) or not kandidaten:
        grund = str((daten.get("promptFeedback") or {}).get("blockReason") or "").strip()
        raise LutFehler("Antwort ohne Ergebnis%s." % (": " + grund if grund else ""))
    kandidat = kandidaten[0] if isinstance(kandidaten[0], dict) else {}
    inhalt = kandidat.get("content") if isinstance(kandidat.get("content"), dict) else {}
    rohteile = inhalt.get("parts") if isinstance(inhalt.get("parts"), list) else []
    gesamt = "".join(str(t.get("text") or "") for t in rohteile
                     if isinstance(t, dict) and not t.get("thought"))
    gesamt = gesamt.strip()
    if not gesamt:
        grund = str(kandidat.get("finishReason") or "").strip()
        raise LutFehler("Leere Antwort des Modells%s." % (": " + grund if grund else ""))
    inhalt_json = _json_aus(gesamt)
    if isinstance(inhalt_json, dict):
        rohzeilen = inhalt_json.get("lines")
        quelle = str(inhalt_json.get("sourceLanguage") or "").strip()
    else:
        rohzeilen, quelle = None, ""
    if not isinstance(rohzeilen, list):
        # Manche Antworten lassen die Huelle weg; eine nackte Liste genuegt ebenfalls.
        rohzeilen = inhalt_json if isinstance(inhalt_json, list) else []
        if not rohzeilen:
            rohzeilen = re.findall(r'"text"\s*:\s*"((?:[^"\\]|\\.)*)"', gesamt)
    zeilen = []
    for eintrag in rohzeilen[:MAX_LINES]:
        if isinstance(eintrag, dict):
            text_zeile = _zeile(eintrag.get("text"))
            try:
                offset = int(eintrag.get("startOffsetMs", eintrag.get("start_ms", -1)))
            except (TypeError, ValueError):
                offset = -1
        else:
            text_zeile, offset = _zeile(eintrag), -1
        if not text_zeile:
            continue
        if offset < 0 or offset > MAX_OFFSET_MS:
            offset = None
        zeilen.append({"text": text_zeile, "start_ms": offset})
    return {"lines": zeilen, "quelle_sprache": quelle, "modell": modell_name or modell(werte),
            "sprache": sprachkuerzel(werte), "rtl": ist_rtl(werte)}


def anfrage(werte, eingabe, holen=None):
    """Ton oder Text an Gemini schicken und getimte Zeilen zurueckgeben."""
    werte = dict(werte or {})
    wunsch_sprache = sprache_aus_eingabe(eingabe)
    if wunsch_sprache:
        werte["liveut_sprache"] = wunsch_sprache
    if werte.get("liveut_an") is not True:
        raise LutFehler("Live-KI-Untertitel sind ausgeschaltet.")
    schluessel = str(werte.get("liveut_schluessel") or "").strip()
    if not schluessel:
        raise SchluesselFehler("Kein API-Schluessel eingetragen.")
    koerper = anfrage_koerper(werte, eingabe)
    adresse = "%s/models/%s:generateContent" % (basis(werte), modell(werte))
    abruf = holen or oeffentlich_antwort_holen()
    try:
        status, antwort = abruf(adresse, methode="POST", header={
            "Content-Type": "application/json", "x-goog-api-key": schluessel}, daten=koerper,
            zeitgrenze=ZEITGRENZE)
    except NetzFehler as fehler:
        raise LutFehler("Dienst nicht erreichbar (%s)." % fehler) from None
    if status == 429:
        raise KontingentFehler("Kontingent erschoepft; bitte spaeter erneut versuchen.")
    if status in (401, 403) or (status == 400 and ("API_KEY_INVALID" in antwort or "API key not valid" in antwort)):
        raise SchluesselFehler("API-Schluessel wird abgewiesen.")
    if status >= 400:
        grund = _json_aus(antwort) or {}
        meldung = str(((grund.get("error") or {}) if isinstance(grund, dict) else {}).get("message") or "").strip()
        raise LutFehler("Anfrage abgewiesen (HTTP %d%s)." % (status, ": " + meldung[:200] if meldung else ""))
    return antwort_lesen(antwort, werte)



def pruefen(werte, holen=None):
    """Schluessel und Modell bei Gemini pruefen, ohne Ton zu senden.

    Liefert ein Ergebnis statt zu werfen, damit die Oberflaeche auch einen abgewiesenen
    Schluessel anzeigen kann; fehlt der Schluessel ganz, bleibt es bei SchluesselFehler.
    """
    werte = werte or {}
    schluessel = str(werte.get("liveut_schluessel") or "").strip()
    if not schluessel:
        raise SchluesselFehler("Kein API-Schluessel eingetragen.")
    adresse = "%s/models/%s" % (basis(werte), modell(werte))
    abruf = holen or oeffentlich_antwort_holen()
    try:
        status, antwort = abruf(adresse, header={"x-goog-api-key": schluessel}, zeitgrenze=ZEITGRENZE)
    except NetzFehler as fehler:
        return {"ok": None, "meldung": "Dienst nicht erreichbar (%s)." % fehler,
                "modell": modell(werte), "sprache": sprachkuerzel(werte)}
    if status == 200:
        return {"ok": True, "meldung": "Schluessel gueltig, Modell %s erreichbar." % modell(werte),
                "modell": modell(werte), "sprache": sprachkuerzel(werte)}
    if status in (401, 403) or (status == 400 and ("API_KEY_INVALID" in antwort or "API key not valid" in antwort)):
        return {"ok": False, "meldung": "API-Schluessel wird abgewiesen.", "modell": modell(werte)}
    if status == 404:
        return {"ok": False, "meldung": "Modell %s gibt es an dieser Adresse nicht." % modell(werte),
                "modell": modell(werte)}
    if status == 429:
        return {"ok": None, "meldung": "Kontingent erschoepft; bitte spaeter erneut versuchen.",
                "modell": modell(werte)}
    return {"ok": None, "meldung": "Antwort HTTP %d." % status, "modell": modell(werte)}
