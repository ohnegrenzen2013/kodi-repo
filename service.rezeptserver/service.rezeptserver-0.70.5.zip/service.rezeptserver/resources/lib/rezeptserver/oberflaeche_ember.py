"""Ember steuern: die Desktop-App ueber ihre Dateien (ember_steuerung.py) und emberd ohne Fenster.

  GET  /api/ember/steuerung    Ember-App: laeuft?, Ports, Downloads mit Fortschritt, Einstellungen, Ordner, Programm
  POST /api/ember/steuerung    {aktion: starten|stoppen} | {aktion: einstellen, werte: {...}} |
                               {aktion: orte, ordner, programm} | {aktion: listen}
  GET  /api/emberd             emberd: Installation, Lauf, Netzwerk, Web-Oberflaeche, Downloads
  POST /api/emberd             {aktion: installieren|starten|stoppen|einstellen|passwort_zeigen|passwort_neu|
                                suchen|q|methode|art|laden|links|download_aktion|aktion|ids|listen}
"""

import json

from . import ember_steuerung, emberd as emberd_modul, ipfilter


class EmberMixin:

    def _emberp2p_an(self):
        """Ember-P2P in den Einstellungen eingeschaltet? (Standard: an, wie bisher)"""
        try:
            return (self._einstellungen_lesen().get("werte") or {}).get("emberp2p_an", True) is not False
        except Exception:
            return True

    def _ember(self, daten=None):
        daten = daten if daten is not None else (self.app.verwaltung.daten() if self.app.verwaltung else {})
        return ember_steuerung.EmberSteuerung(ember_steuerung.pruefe(daten.get(ember_steuerung.SCHLUESSEL)))

    def ember_lesen(self):
        if not self._emberp2p_an():
            return 200, "application/json", {"an": False, "laeuft": False, "gefunden": False, "transfers": [],
                                             "ports": {"tcp": 0, "udp": 0, "tcp_offen": False}, "einstellungen": {},
                                             "ordner": "", "programm": "", "kandidaten": [], "listen": {},
                                             "meldung": "Ember-P2P ist in den Einstellungen ausgeschaltet."}
        return 200, "application/json", self._ember().zustand()

    def ember_post(self, koerper):
        if not self._emberp2p_an():
            return 403, "application/json", {"fehler": "Ember-P2P ist in den Einstellungen ausgeschaltet."}
        try:
            w = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(w, dict):
                raise ValueError("JSON-Objekt erwartet")
            a = w.get("aktion")
            if a == "orte":
                if not self.app.verwaltung:
                    raise ValueError("Nutzerdaten nicht verfügbar")
                neu = ember_steuerung.pruefe({"ordner": w.get("ordner"), "programm": w.get("programm")}, streng=True)

                def setzen(d):
                    d[ember_steuerung.SCHLUESSEL] = neu
                self.app.verwaltung.aendern(setzen)
                return self.ember_lesen()
            e = self._ember()
            if a == "starten":
                return 200, "application/json", e.starten()
            if a == "stoppen":
                return 200, "application/json", e.stoppen()
            if a == "einstellen":
                return 200, "application/json", e.einstellen(w.get("werte"))
            if a == "listen":
                geschrieben = e.listen_geben(self._listen_dateien())
                return 200, "application/json", dict(e.zustand(), meldung="An Ember gegeben: " + (", ".join(geschrieben) or "nichts (Listen leer)") +
                                                     ". Ember liest sie beim nächsten Start.")
            raise ValueError("aktion: starten, stoppen, einstellen, orte oder listen")
        except (ValueError, UnicodeDecodeError, OSError) as fehler:  # EmberFehler ist ValueError
            return 400, "application/json", {"fehler": str(fehler)}

    # --- emberd (Ember ohne Fenster, ab 1.8) ------------------------------------------------------
    def _listen_dateien(self):
        server = self.app.ed2k_suche.serverliste
        return {"server.met": server.datei() if server.eintraege() else b"",
                "nodes.dat": self.app.kadliste.datei() if self.app.kadliste.eintraege() else b"",
                "ipfilter.dat": ipfilter.AKTIV.als_dat() if len(ipfilter.AKTIV) else b""}

    def _emberd_verwalten(self, aktion):
        """Installieren, starten, stoppen und Einstellungen sind Sache des Admins."""
        if aktion in ("installieren", "starten", "stoppen", "einstellen", "passwort_zeigen",
                      "passwort_neu", "listen", "pruefen") and not self.darf("einstellungen"):
            return False
        return True

    def _emberd_zustand(self):
        d = self.app.emberd.zustand(verwalten=self.darf("einstellungen"))
        from .dienst import eigene_adresse
        adresse = eigene_adresse()
        d["web"] = ("http://%s:%d/" % (adresse, d["port"])) if d["netz"] else d["web_lokal"]
        d["web_netz"] = "http://%s:%d/" % (adresse, d["port"])
        return d

    def emberd_lesen(self):
        if not self._emberp2p_an():
            return 200, "application/json", {"an": False, "laeuft": False, "installiert": False,
                                             "downloads": [], "verwalten": False,
                                             "meldung": "Ember-P2P ist in den Einstellungen ausgeschaltet."}
        return 200, "application/json", self._emberd_zustand()

    def emberd_post(self, koerper):
        if not self._emberp2p_an():
            return 403, "application/json", {"fehler": "Ember-P2P ist in den Einstellungen ausgeschaltet."}
        try:
            w = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(w, dict):
                raise ValueError("JSON-Objekt erwartet")
            aktion = str(w.get("aktion") or "")
            if not self._emberd_verwalten(aktion):
                return 403, "application/json", {"fehler": "Dafür fehlt das Recht „Einstellungen“"}
            e = self.app.emberd
            if aktion in ("installieren", "aktualisieren"):
                installation = e.installation_starten()
                return 200, "application/json", dict(self._emberd_zustand(), installation=installation)
            if aktion == "pruefen":
                release = e.release()
                return 200, "application/json", dict(self._emberd_zustand(), release=release)
            if aktion == "starten":
                return 200, "application/json", e.starten()
            if aktion == "stoppen":
                return 200, "application/json", e.stoppen()
            if aktion == "einstellen":
                e.einstellen(w.get("werte") or {})
                return 200, "application/json", self._emberd_zustand()
            if aktion == "passwort_zeigen":
                return 200, "application/json", e.passwort_zeigen()
            if aktion == "passwort_neu":
                return 200, "application/json", e.passwort_neu()
            if aktion == "suchen":
                treffer = e.suchen(w.get("q"), w.get("methode") or "global", w.get("art") or "",
                                   w.get("grenze") or 50)
                return 200, "application/json", dict(self._emberd_zustand(), treffer=treffer)
            if aktion == "laden":
                links = w.get("links") if isinstance(w.get("links"), list) else [w.get("link") or ""]
                return 200, "application/json", dict(self._emberd_zustand(), ergebnis=e.links_herunterladen(links))
            if aktion == "download_aktion":
                ergebnis = e.download_aktion(w.get("unteraktion"), w.get("ids"))
                return 200, "application/json", dict(self._emberd_zustand(), ergebnis=ergebnis)
            if aktion == "listen":
                ziel = ember_steuerung.EmberSteuerung({"ordner": e.datenordner_aktuell()})
                geschrieben = ziel.listen_geben(self._listen_dateien())
                return 200, "application/json", dict(self._emberd_zustand(), meldung="An emberd gegeben: " + (
                    ", ".join(geschrieben) or "nichts (Listen leer)") + ". Ember liest sie beim nächsten Start.")
            raise ValueError("aktion: installieren, pruefen, starten, stoppen, einstellen, passwort_zeigen, "
                             "passwort_neu, suchen, laden, download_aktion oder listen")
        except (ValueError, UnicodeDecodeError, OSError, emberd_modul.EmberdFehler) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
