"""Integritaetspruefung der Oberflaeche: Module, Rezepte, Anbieter, Addons, Plugins, Links und Verweise.

  GET /api/integritaet   struktureller Bericht (ohne Netz); braucht das Recht "einstellungen"
"""

from . import integritaet
from .seite import SEITE


class IntegritaetMixin:

    def integritaet_lesen(self):
        daten = self.app.verwaltung.daten() if self.app.verwaltung else {}
        # Alle geladenen Rezepte, nicht nur die nutzbaren der Kette: sonst fehlten Module ohne
        # vollstaendige Zugangsdaten und ihre Konten gaelten faelschlich als verwaist.
        verwaltung = getattr(self.app, "verwaltung", None)
        module = list(getattr(verwaltung, "module", None) or [])
        if not module:
            kette = getattr(self.app, "kette", None)
            module = list(getattr(kette, "module", None) or [])
        return 200, "application/json", integritaet.bericht(daten, module=module, seite=SEITE)
