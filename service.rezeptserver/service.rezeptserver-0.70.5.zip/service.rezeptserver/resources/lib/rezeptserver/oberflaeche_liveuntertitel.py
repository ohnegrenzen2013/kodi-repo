"""Live-KI-Untertitel: Stand lesen und Ton-/Textabschnitte uebersetzen.

  GET  /api/liveuntertitel          Stand (an, Schluessel gesetzt, Modell, Zielsprache, Grenzen)
  POST /api/liveuntertitel          {audio: <base64-WAV> | text, kontext: [...], sprache?}
"""

import json

from . import live_untertitel


class LiveUntertitelMixin:

    def liveuntertitel_lesen(self):
        werte = self._einstellungen_lesen().get("werte") or {}
        return 200, "application/json", live_untertitel.zustand(werte)

    def liveuntertitel_post(self, koerper):
        werte = self._einstellungen_lesen().get("werte") or {}
        try:
            daten = json.loads(koerper.decode("utf-8") or "{}")
        except (ValueError, UnicodeDecodeError):
            return 400, "application/json", {"fehler": "JSON-Fehler"}
        if not isinstance(daten, dict):
            return 400, "application/json", {"fehler": "JSON-Objekt erwartet"}
        try:
            if daten.get("aktion") == "pruefen":
                return 200, "application/json", live_untertitel.pruefen(werte)
            return 200, "application/json", live_untertitel.anfrage(werte, daten)
        except live_untertitel.SchluesselFehler as fehler:
            return 401, "application/json", {"fehler": str(fehler), "schluessel": True}
        except live_untertitel.KontingentFehler as fehler:
            return 429, "application/json", {"fehler": str(fehler), "kontingent": True}
        except live_untertitel.LutFehler as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
