"""Soulseek-Oberflaeche: Suche, Downloads, Freigaben und Einstellungen des Tausch-Netzes."""

from .oberflaeche_grund import json, soulseek


class _SoulseekMixin:

    def soulseek_post(self, pfad, koerper):
        try:
            daten = json.loads(koerper.decode("utf-8") or "{}")
            if not isinstance(daten, dict):
                raise ValueError("JSON-Objekt erwartet")
            s = self.app.soulseek
            if pfad == "/api/soulseek/verbinden":
                s.verbinden()
            elif pfad == "/api/soulseek/trennen":
                s.trennen()
            elif pfad == "/api/soulseek/suchen":
                s.suchen(daten.get("q"))
            elif pfad == "/api/soulseek/laden":
                s.laden(daten.get("id"))
            elif pfad == "/api/soulseek/abbrechen":
                s.abbrechen(daten.get("id"))
            elif pfad == "/api/soulseek/fortsetzen":
                s.fortsetzen(daten.get("id"))
            elif pfad == "/api/soulseek/entfernen":
                s.entfernen(daten.get("id"))
            elif pfad == "/api/soulseek/einstellen":
                s.einstellen(daten)
            elif pfad == "/api/soulseek/freigabe":
                s.freigaben(daten)
            elif pfad == "/api/soulseek/loeschen":
                s.loeschen(daten.get("name"))
            else:
                return 404, "application/json", {"fehler": "nicht gefunden"}
            return 200, "application/json", s.zustand()
        except (ValueError, UnicodeDecodeError, soulseek.SoulseekFehler, OSError) as fehler:
            return 400, "application/json", {"fehler": str(fehler)}
