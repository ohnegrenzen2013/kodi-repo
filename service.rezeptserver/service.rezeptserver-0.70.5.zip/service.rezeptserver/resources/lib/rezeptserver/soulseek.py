"""Soulseek: Dateien im Tausch-Netz suchen und laden (Tab Soulseek).

Der Bereich treibt den mitgelieferten Quellstand `nicotine-plus/` (GPL-3.0-or-later) kopflos an:
H0rSt uebernimmt Konto, Downloadordner und Freigaben in dessen Konfiguration, startet den Kern im
Hintergrund und reicht Suche, Treffer, Downloads und Dateien als JSON an die Oberflaeche weiter.
Ohne Python 3.11 bleibt der Bereich sichtbar, meldet aber ehrlich, dass der Motor hier nicht laeuft.

  GET  /api/soulseek            Zustand: Verbindung, letzte Suche, Treffer, Downloads, Dateien, Einstellungen
  POST /api/soulseek/verbinden  verbinden; /trennen; /einstellen {…}; /freigabe {aktion, pfad, name}
  POST /api/soulseek/suchen     {q} Suche starten; /laden {id}; /abbrechen {id}; /fortsetzen {id}; /entfernen {id}
  POST /api/soulseek/loeschen   {name} geladene Datei entfernen
  GET  /api/soulseek/datei/<name>  geladene Datei abspielen (mit Range)
"""

from .soulseek_grund import *
from .soulseek_grund import (
    DATEI,
    MAX_DATEIEN,
    MAX_FREIGABEN,
    MAX_TREFFER,
    ORDNER,
    STANDARD,
    UNTERORDNER_DOWNLOADS,
    UNTERORDNER_UNVOLLSTAENDIG,
    _AUDIO,
    _BENUTZER,
    _HOST,
    _NAME,
    _text,
    _zahl,
)
from .soulseek_dienst import Soulseek
