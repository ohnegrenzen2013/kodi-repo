"""Soulseek-Dienst: Einstellungen, Motor-Lebenszyklus und die Schnittstelle fuer die Oberflaeche."""

import os
import threading
import time

from .soulseek_grund import (
    DATEI,
    ORDNER,
    SoulseekFehler,
    dateien,
    laden,
    oeffentlich,
    pruefe,
    sichere_datei,
    sichern,
    zustand_leer,
)
from .soulseek_nicotine import NicotineBackend, verfuegbar as motor_verfuegbar


class Soulseek:
    """Ein Dienst je H0rSt: der Nicotine+-Kern laeuft im Hintergrund, die Oberflaeche spricht nur JSON."""

    def __init__(self, datenordner, backend=None, uhr=time.time):
        self.datenordner = os.path.abspath(datenordner or ".")
        self.ordner = os.path.join(self.datenordner, ORDNER)
        self.konfig_pfad = os.path.join(self.datenordner, DATEI)
        self.uhr = uhr
        self._sperre = threading.RLock()
        self.einstellung = laden(self.konfig_pfad, self.datenordner)
        self._backend = backend
        self._startfehler = ""
        self._startet = False

    # --- Motor -----------------------------------------------------------------------------------
    def verfuegbarkeit(self):
        if self._backend is not None:
            return True, ""
        return motor_verfuegbar()

    def _backend_holen(self):
        verfuegbar, grund = self.verfuegbarkeit()
        if not verfuegbar:
            raise SoulseekFehler(grund)
        with self._sperre:
            if self._backend is None:
                self._backend = NicotineBackend(self.ordner, self.einstellung)
            return self._backend

    def starten(self):
        backend = self._backend_holen()
        with self._sperre:
            if self._startet:
                return backend
            self._startfehler = ""
        try:
            backend.starten()
        except Exception as fehler:
            with self._sperre:
                self._startfehler = str(fehler)
            raise SoulseekFehler("Soulseek startet nicht: %s" % fehler)
        with self._sperre:
            self._startet = True
        return backend

    def verbinden(self):
        backend = self.starten()
        with self._sperre:
            self._startfehler = ""
        backend.verbinden()
        return self.zustand()

    def trennen(self):
        with self._sperre:
            backend = self._backend
        if backend is not None:
            backend.trennen()
        return self.zustand()

    def beenden(self):
        with self._sperre:
            backend = self._backend
            self._startet = False
        if backend is not None:
            backend.beenden()

    def bei_start(self):
        """Beim Serverstart im Hintergrund verbinden, wenn Konto und Auto-Verbindung eingestellt sind."""
        e = self.einstellung
        if not (e["an"] and e["auto"] and e["benutzer"] and e["passwort"]):
            return

        def tun():
            try:
                self.verbinden()
            except Exception as fehler:
                with self._sperre:
                    self._startfehler = str(fehler)

        threading.Thread(target=tun, name="Soulseek-Start", daemon=True).start()

    # --- Suche und Downloads ---------------------------------------------------------------------
    def suchen(self, begriff):
        backend = self.starten()
        self._verbindung_sichern(backend)
        return backend.suchen(begriff)

    def laden(self, kennung):
        backend = self.starten()
        self._verbindung_sichern(backend)
        return backend.laden(kennung)

    def _verbindung_sichern(self, backend):
        try:
            zustand = backend.zustand()
        except Exception:
            return
        if zustand.get("verbunden"):
            return
        if self.einstellung["benutzer"] and self.einstellung["passwort"]:
            backend.verbinden()
            raise SoulseekFehler("Verbindung wird aufgebaut – bitte gleich noch einmal versuchen")
        raise SoulseekFehler("Benutzername und Passwort fehlen")

    def abbrechen(self, kennung):
        self._backend_pflicht().abbrechen(kennung)

    def fortsetzen(self, kennung):
        self._backend_pflicht().fortsetzen(kennung)

    def entfernen(self, kennung):
        self._backend_pflicht().entfernen(kennung)

    def _backend_pflicht(self):
        with self._sperre:
            backend = self._backend
        if backend is None:
            raise SoulseekFehler("Soulseek läuft noch nicht")
        return backend

    # --- Einstellungen ---------------------------------------------------------------------------
    def einstellen(self, werte):
        if not isinstance(werte, dict):
            raise SoulseekFehler("Einstellungen muessen ein Objekt sein")
        roh = dict(self.einstellung)
        for feld in ("an", "auto", "benutzer", "server", "port", "listen_port", "downloadordner", "freigaben",
                     "max_treffer"):
            if feld in werte:
                roh[feld] = werte[feld]
        if werte.get("passwort"):
            roh["passwort"] = str(werte["passwort"])[:200]
        if werte.get("passwort_loeschen"):
            roh["passwort"] = ""
        neu = pruefe(roh, self.datenordner)
        sichern(self.konfig_pfad, neu)
        with self._sperre:
            self.einstellung = neu
            backend = self._backend
        if backend is not None:
            backend.einstellen(neu)
        return oeffentlich(neu)

    def setze_downloadordner(self, pfad):
        if not pfad or pfad == self.einstellung["downloadordner"]:
            return self.einstellung["downloadordner"]
        neu = pruefe(dict(self.einstellung, downloadordner=pfad), self.datenordner)
        sichern(self.konfig_pfad, neu)
        with self._sperre:
            self.einstellung = neu
            backend = self._backend
        if backend is not None:
            backend.einstellen(neu)
        return neu["downloadordner"]

    def freigaben(self, wunsch):
        if not isinstance(wunsch, dict):
            raise SoulseekFehler("Freigabe muss ein Objekt sein")
        aktion = str(wunsch.get("aktion") or "")
        freigaben = [dict(f) for f in self.einstellung["freigaben"]]
        if aktion == "hinzu":
            pfad = os.path.abspath(os.path.expanduser(str(wunsch.get("pfad") or "").strip()))
            if not pfad or not os.path.isdir(pfad):
                raise SoulseekFehler("Ordner gibt es nicht: %s" % (pfad or "?"))
            if any(f["pfad"] == pfad for f in freigaben):
                return oeffentlich(self.einstellung)
            freigaben.append({"name": str(wunsch.get("name") or ""), "pfad": pfad})
        elif aktion == "weg":
            pfad = os.path.abspath(os.path.expanduser(str(wunsch.get("pfad") or "").strip()))
            freigaben = [f for f in freigaben if f["pfad"] != pfad]
        elif aktion != "scannen":
            raise SoulseekFehler("Unbekannte Aktion")
        if aktion != "scannen":
            neu = pruefe(dict(self.einstellung, freigaben=freigaben), self.datenordner)
            sichern(self.konfig_pfad, neu)
            with self._sperre:
                self.einstellung = neu
                backend = self._backend
            if backend is not None:
                backend.einstellen(neu)
        with self._sperre:
            backend = self._backend
        if backend is not None:
            backend.freigaben_scannen()
        return oeffentlich(self.einstellung)

    # --- Geladene Dateien ------------------------------------------------------------------------
    def dateien(self):
        return dateien(self.einstellung["downloadordner"])

    def pfad(self, name):
        return sichere_datei(self.einstellung["downloadordner"], name)

    def loeschen(self, name):
        ziel = sichere_datei(self.einstellung["downloadordner"], name)
        os.remove(ziel)
        ordner = os.path.dirname(ziel)
        wurzel = os.path.abspath(self.einstellung["downloadordner"])
        while ordner != wurzel and ordner.startswith(wurzel + os.sep):
            try:
                os.rmdir(ordner)
            except OSError:
                break
            ordner = os.path.dirname(ordner)
        return self.dateien()

    # --- Zustand ---------------------------------------------------------------------------------
    def zustand(self):
        verfuegbar, grund = self.verfuegbarkeit()
        with self._sperre:
            backend = self._backend
            startfehler = self._startfehler
            einstellung = self.einstellung
        daten = zustand_leer(einstellung)
        daten.update({"verfuegbar": verfuegbar, "grund": grund, "pfad": einstellung["downloadordner"],
                      "einstellungen": oeffentlich(einstellung)})
        if backend is not None:
            try:
                daten.update(backend.zustand())
            except Exception as fehler:
                daten["fehler"] = "Zustand nicht lesbar: %s" % fehler
        if startfehler:
            daten["fehler"] = startfehler
        daten["dateien"] = dateien(einstellung["downloadordner"])
        daten["laeuft"] = bool(backend is not None)
        daten["zeit"] = int(self.uhr())
        return daten
