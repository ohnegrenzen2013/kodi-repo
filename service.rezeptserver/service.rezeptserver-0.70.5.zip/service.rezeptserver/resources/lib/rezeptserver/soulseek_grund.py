"""Soulseek: Konstanten, Fehler, Einstellungen und gemeinsame Helfer.

Der Bereich nutzt den mitgelieferten Quellstand `nicotine-plus/` als Motor (GPL-3.0-or-later) und
spricht ihn nur ueber `soulseek_nicotine.py` an. Dieses Modul bleibt bei Python 3.8 importierbar.
"""

import hashlib
import json
import os
import re
import time
import unicodedata

SCHLUESSEL = "soulseek"
DATEI = "soulseek.json"
ORDNER = "soulseek"
UNTERORDNER_DOWNLOADS = "downloads"
UNTERORDNER_UNVOLLSTAENDIG = "unvollstaendig"
MAX_FREIGABEN = 10
MAX_TREFFER = 500
MAX_DATEIEN = 400
MAX_BENUTZER = 30
MAX_PASSWORT = 200
STANDARD = {
    "an": True,
    "auto": True,
    "benutzer": "",
    "passwort": "",
    "server": "server.slsknet.org",
    "port": 2242,
    "listen_port": 2234,
    "downloadordner": "",
    "freigaben": [],
    "max_treffer": 500,
}

_BENUTZER = re.compile(r"^[A-Za-z0-9][A-Za-z0-9 ._-]{0,29}$")
_HOST = re.compile(r"^[A-Za-z0-9]([A-Za-z0-9.-]{0,252}[A-Za-z0-9])?$")
_NAME = re.compile(r"[^\w .,()\[\]+&'!@#%=~ -]")
_AUDIO = {".mp3", ".flac", ".ogg", ".opus", ".m4a", ".aac", ".wav", ".wma", ".ape", ".wv", ".aiff", ".aif"}


class SoulseekFehler(ValueError):
    pass


def _text(wert, grenze):
    return " ".join(str(wert or "").split())[:grenze]


def _zahl(wert, standard, klein, gross):
    try:
        zahl = int(wert)
    except (TypeError, ValueError):
        return standard
    return max(klein, min(gross, zahl))


def _downloadordner(einstellung, datenordner):
    ordner = _text(einstellung.get("downloadordner"), 500)
    if not ordner:
        return os.path.join(datenordner or ".", ORDNER, UNTERORDNER_DOWNLOADS)
    ordner = os.path.abspath(os.path.expanduser(ordner))
    if ordner == os.sep:
        raise SoulseekFehler("Der Downloadordner darf nicht das Wurzelverzeichnis sein")
    return ordner


def pruefe(roh, datenordner=None):
    """Einstellungen lesen und pruefen; unbekannte Felder fallen weg, fehlende kommen dazu."""
    if roh is None:
        roh = {}
    if not isinstance(roh, dict):
        raise SoulseekFehler("Einstellungen muessen ein Objekt sein")
    e = dict(STANDARD)

    benutzer = _text(roh.get("benutzer"), MAX_BENUTZER + 1)
    if benutzer and not _BENUTZER.match(benutzer):
        raise SoulseekFehler("Benutzername: 1 bis 30 Zeichen, Buchstaben, Zahlen, Leerzeichen, Punkt, Strich, Unterstrich")
    e["benutzer"] = benutzer
    e["passwort"] = str(roh.get("passwort") or "")[:MAX_PASSWORT]

    server = _text(roh.get("server"), 253).lower() or STANDARD["server"]
    if not _HOST.match(server):
        raise SoulseekFehler("Server: Hostname oder IP-Adresse eintragen")
    e["server"] = server
    e["port"] = _zahl(roh.get("port"), STANDARD["port"], 1, 65535)
    e["listen_port"] = _zahl(roh.get("listen_port"), STANDARD["listen_port"], 1024, 65535)
    e["an"] = roh.get("an") is not False
    e["auto"] = roh.get("auto") is not False
    e["max_treffer"] = _zahl(roh.get("max_treffer"), STANDARD["max_treffer"], 50, 1000)

    e["downloadordner"] = _downloadordner(roh, datenordner)
    try:
        os.makedirs(e["downloadordner"], exist_ok=True)
    except OSError as fehler:
        raise SoulseekFehler("Downloadordner nicht anlegbar: %s" % fehler)

    freigaben, gesehen = [], set()
    roh_freigaben = roh.get("freigaben")
    if roh_freigaben is None:
        roh_freigaben = []
    if not isinstance(roh_freigaben, list):
        raise SoulseekFehler("Freigaben muessen eine Liste sein")
    for eintrag in roh_freigaben:
        if isinstance(eintrag, dict):
            name, pfad = eintrag.get("name"), eintrag.get("pfad")
        elif isinstance(eintrag, (list, tuple)) and len(eintrag) >= 2:
            name, pfad = eintrag[0], eintrag[1]
        elif isinstance(eintrag, str):
            name, pfad = "", eintrag
        else:
            continue
        pfad = os.path.abspath(os.path.expanduser(str(pfad or "").strip()))
        if not pfad or not os.path.isdir(pfad):
            raise SoulseekFehler("Freigabe-Ordner gibt es nicht: %s" % pfad)
        if pfad in gesehen:
            continue
        gesehen.add(pfad)
        name = _NAME.sub("_", _text(name, 60)) or os.path.basename(pfad.rstrip(os.sep)) or "Freigabe"
        freigaben.append({"name": name, "pfad": pfad})
        if len(freigaben) >= MAX_FREIGABEN:
            break
    e["freigaben"] = freigaben
    return e


def oeffentlich(e):
    """Einstellungen fuer die Oberflaeche; das Passwort verlaesst den Server nie."""
    return {"an": e["an"], "auto": e["auto"], "benutzer": e["benutzer"], "passwort_gesetzt": bool(e["passwort"]),
            "server": e["server"], "port": e["port"], "listen_port": e["listen_port"],
            "downloadordner": e["downloadordner"], "freigaben": [dict(f) for f in e["freigaben"]],
            "max_treffer": e["max_treffer"]}


def laden(pfad, datenordner=None):
    try:
        with open(pfad, encoding="utf-8") as f:
            roh = json.load(f)
    except (OSError, ValueError):
        roh = {}
    return pruefe(roh, datenordner)


def sichern(pfad, einstellung):
    ordner = os.path.dirname(os.path.abspath(pfad))
    os.makedirs(ordner, exist_ok=True)
    temp = pfad + ".neu"
    with open(temp, "w", encoding="utf-8") as f:
        json.dump(einstellung, f, ensure_ascii=False, indent=1)
    try:
        os.chmod(temp, 0o600)
    except OSError:
        pass
    os.replace(temp, pfad)


def treffer_id(benutzer, pfad):
    return hashlib.sha1(("%s\x00%s" % (benutzer, pfad)).encode("utf-8", "replace")).hexdigest()[:16]


def mensch_groesse(groesse):
    groesse = int(groesse or 0)
    for einheit in ("B", "KB", "MB", "GB", "TB"):
        if groesse < 1024 or einheit == "TB":
            return ("%d %s" % (groesse, einheit)) if einheit == "B" else ("%.1f %s" % (groesse, einheit))
        groesse = groesse / 1024.0
    return "0 B"


def dateiname(pfad):
    return unicodedata.normalize("NFC", str(pfad or "").replace("\\", "/").rsplit("/", 1)[-1])


def ordner_von(pfad):
    pfad = str(pfad or "").replace("/", "\\")
    return pfad.rsplit("\\", 1)[0] if "\\" in pfad else ""


def sichere_datei(ordner, name):
    """Pfad einer geladenen Datei innerhalb des Downloadordners (kein Weg aus ihm heraus)."""
    name = str(name or "").replace("\\", "/").strip("/")
    if not name or name in (".", "..") or ".." in name.split("/"):
        raise SoulseekFehler("Dateiname ungueltig")
    wurzel = os.path.realpath(ordner)
    ziel = os.path.realpath(os.path.join(wurzel, *name.split("/")))
    if ziel != wurzel and not ziel.startswith(wurzel + os.sep):
        raise SoulseekFehler("Dateiname ungueltig")
    if not os.path.isfile(ziel):
        raise SoulseekFehler("Datei gibt es nicht: %s" % name)
    return ziel


def dateien(ordner, max_dateien=MAX_DATEIEN):
    """Geladene Dateien im Downloadordner (rekursiv, ohne Verstecktes und ohne .part)."""
    ergebnis = []
    wurzel = os.path.abspath(ordner or ".")
    if not os.path.isdir(wurzel):
        return ergebnis
    for pfad, unterordner, namen in os.walk(wurzel):
        unterordner[:] = sorted(u for u in unterordner if not u.startswith("."))
        for name in sorted(namen):
            if name.startswith(".") or name.endswith(".part"):
                continue
            voll = os.path.join(pfad, name)
            try:
                stat = os.stat(voll)
            except OSError:
                continue
            if not os.path.isfile(voll):
                continue
            relativ = os.path.relpath(voll, wurzel).replace(os.sep, "/")
            endung = os.path.splitext(name)[1].lower()
            ergebnis.append({"name": relativ, "datei": name, "groesse": stat.st_size,
                             "groesse_text": mensch_groesse(stat.st_size), "zeit": int(stat.st_mtime),
                             "art": "audio" if endung in _AUDIO else "datei"})
            if len(ergebnis) >= max_dateien:
                return ergebnis
    return sorted(ergebnis, key=lambda e: e["zeit"], reverse=True)


def zustand_leer(einstellung):
    return {"verfuegbar": False, "grund": "", "laeuft": False, "startet": False, "verbunden": False,
            "benutzer": einstellung["benutzer"], "server": einstellung["server"], "port": einstellung["port"],
            "suche": {"begriff": "", "token": None, "zeit": 0, "anzahl": 0}, "treffer": [], "downloads": [],
            "statistik": {}, "fehler": "", "meldung": "", "einstellungen": oeffentlich(einstellung),
            "pfad": einstellung["downloadordner"], "zeit": int(time.time())}
