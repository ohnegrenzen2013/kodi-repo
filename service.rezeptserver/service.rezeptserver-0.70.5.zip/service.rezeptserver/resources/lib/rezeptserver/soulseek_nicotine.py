"""Soulseek-Motor: treibt den mitgelieferten Nicotine+-Kern (nicotine-plus/, GPL-3.0-or-later) kopflos.

Der Kern wird erst beim ersten Start importiert; die Rezeptserver-Module bleiben bei Python 3.8
importierbar, waehrend der Motor Python 3.11 oder neuer braucht (so wie Nicotine+ selbst).
"""

import importlib.util
import os
import sys
import threading
import time

from .soulseek_grund import (
    SoulseekFehler,
    dateiname,
    mensch_groesse,
    ordner_von,
    treffer_id,
)

WURZEL = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
QUELLSTAND = os.path.join(WURZEL, "nicotine-plus")
ERGEBNISSE_MAX = 5000
STATUS_TEXT = {
    "Finished": "fertig",
    "Paused": "pausiert",
    "Transferring": "lädt",
    "Getting status": "holt Status",
    "Queued": "wartet",
    "Queued (prioritized)": "wartet (vorgezogen)",
    "Queued (privileged)": "wartet (bevorzugt)",
    "Filtered": "gefiltert",
    "Cancelled": "abgebrochen",
    "User logged off": "Benutzer offline",
    "Connection closed": "Verbindung beendet",
    "Connection timeout": "Zeitüberschreitung",
    "Download folder error": "Downloadordner-Fehler",
    "Local file error": "Dateifehler",
}


def motor_pfad():
    """Ordner des mitgelieferten Quellstands, falls vorhanden."""
    return QUELLSTAND if os.path.isdir(os.path.join(QUELLSTAND, "pynicotine")) else ""


def verfuegbar():
    """(bool, Grund) - kann der Motor in dieser Umgebung laufen?"""
    if sys.version_info < (3, 11):
        return False, "Soulseek braucht Python 3.11 oder neuer (hier %s)" % ".".join(
            str(t) for t in sys.version_info[:3])
    if motor_pfad():
        return True, ""
    try:
        if importlib.util.find_spec("pynicotine") is not None:
            return True, ""
    except (ImportError, ValueError):
        pass
    return False, "Der Quellstand nicotine-plus/ fehlt"


def _numerisch(wert):
    try:
        return int(wert or 0)
    except (TypeError, ValueError):
        return 0


class NicotineBackend:
    """Duenne Bruecke: oeffentliche Methoden sind thread-sicher, der Kern laeuft in seinem eigenen Faden."""

    def __init__(self, ordner, einstellung):
        self.ordner = os.path.abspath(ordner)
        self.einstellung = einstellung
        self._sperre = threading.RLock()
        self._lauf = threading.Event()
        self._faden = None
        self._gestartet = False
        self._verbunden = False
        self._benutzer = ""
        self._server = ""
        self._fehler = ""
        self._meldung = ""
        self._token = None
        self._begriff = ""
        self._suchzeit = 0
        self._treffer = {}
        self._reihenfolge = []
        self._erwartet = ""
        self._downloads = {}
        self._transfer_objekte = {}
        self._core = None
        self._events = None
        self._config = None
        self._search_mode = None

    # --- Start und Faden -------------------------------------------------------------------------
    def starten(self):
        with self._sperre:
            if self._gestartet:
                return
            if sys.version_info < (3, 11):
                raise SoulseekFehler("Soulseek braucht Python 3.11 oder neuer")
            pfad = motor_pfad()
            if pfad and pfad not in sys.path:
                sys.path.insert(0, pfad)
            try:
                from pynicotine.config import config
                from pynicotine.core import core
                from pynicotine.events import events
                from pynicotine.search import SearchMode
            except ImportError as fehler:
                raise SoulseekFehler("Nicotine+ nicht ladbar: %s" % fehler)

            os.makedirs(os.path.join(self.ordner, "daten"), exist_ok=True)
            config.set_config_file(os.path.join(self.ordner, "config"))
            config.set_data_folder(os.path.join(self.ordner, "daten"))
            core.init_components(
                enabled_components={"error_handler", "network_thread", "shares", "users", "notifications",
                                    "network_filter", "statistics", "search", "downloads", "uploads",
                                    "interests", "userbrowse", "userinfo", "buddies", "chatrooms",
                                    "privatechat", "pluginhandler"},
                isolated_mode=True)
            self._config, self._core, self._events, self._search_mode = config, core, events, SearchMode
            self._config_anwenden()

            for name, callback in (
                ("add-search", self._add_search),
                ("file-search-response", self._search_response),
                ("server-login", self._server_login),
                ("server-disconnect", self._server_disconnect),
                ("invalid-password", self._invalid_password),
                ("invalid-username", self._invalid_username),
                ("search-failed", self._search_failed),
                ("update-download", self._update_download),
                ("clear-download", self._clear_download),
            ):
                events.connect(name, callback)

            self._lauf.set()
            core.start()
            self._gestartet = True
            self._faden = threading.Thread(target=self._schleife, name="Soulseek", daemon=True)
            self._faden.start()
            events.invoke_main_thread(self._bestand_uebernehmen)

    def _schleife(self):
        while self._lauf.is_set():
            try:
                if not self._events.process_thread_events():
                    break
            except Exception as fehler:  # der Kern darf H0rSt nicht mitnehmen
                with self._sperre:
                    self._fehler = "Soulseek-Fehler: %s" % fehler
                break
            time.sleep(0.1)
        self._lauf.clear()

    def _bestand_uebernehmen(self):
        try:
            for transfer in self._core.downloads.transfers.values():
                self._update_download(transfer)
        except Exception as fehler:
            self._fehler = "Bestand nicht lesbar: %s" % fehler

    def _config_anwenden(self):
        e = self.einstellung
        s = self._config.sections
        s["server"].update({
            "server": (e["server"], int(e["port"])), "login": e["benutzer"], "passw": e["passwort"],
            "auto_connect_startup": False, "portrange": (int(e["listen_port"]), int(e["listen_port"])),
        })
        s["transfers"].update({
            "downloaddir": e["downloadordner"], "incompletedir": os.path.join(self.ordner, "unvollstaendig"),
            "usernamesubfolders": False, "rescanonstartup": False, "rescan_shares_daily": False,
            "afterfinish": "", "afterfolder": "", "shared": [[f["name"], f["pfad"]] for f in e["freigaben"]],
        })
        s["searches"].update({"enable_history": False, "maxresults": int(e["max_treffer"])})
        s["notifications"].update({"notification_popup_file": False, "notification_popup_folder": False,
                                   "notification_popup_queued_upload": False})
        try:
            self._config.write_configuration()
        except OSError:
            pass

    # --- Verbindung ------------------------------------------------------------------------------
    def verbinden(self):
        self.starten()
        if not self.einstellung["benutzer"] or not self.einstellung["passwort"]:
            raise SoulseekFehler("Benutzername und Passwort fehlen")
        with self._sperre:
            self._fehler = ""
            self._meldung = "Verbinde mit Soulseek …"
        self._events.invoke_main_thread(self._core.connect)

    def trennen(self):
        if not self._gestartet:
            return
        self._events.invoke_main_thread(self._core.disconnect)

    def _server_login(self, msg):
        with self._sperre:
            self._verbunden = bool(getattr(msg, "success", False))
            if self._verbunden:
                self._benutzer = str(getattr(msg, "username", "") or self.einstellung["benutzer"])
                server = getattr(msg, "server_address", None)
                if server:
                    self._server = "%s:%s" % (server[0], server[1])
                self._meldung = "Mit Soulseek verbunden."
                self._fehler = ""
            else:
                self._fehler = "Anmeldung abgelehnt"

    def _server_disconnect(self, _msg):
        with self._sperre:
            war = self._verbunden
            self._verbunden = False
            self._benutzer = ""
            if war:
                self._meldung = "Verbindung zu Soulseek getrennt."

    def _invalid_password(self, *_args):
        with self._sperre:
            self._fehler = "Benutzer oder Passwort falsch"

    def _invalid_username(self, *_args):
        with self._sperre:
            self._fehler = "Benutzername ungueltig"

    # --- Suche -----------------------------------------------------------------------------------
    def suchen(self, begriff):
        self.starten()
        if not self._verbunden:
            raise SoulseekFehler("Noch nicht mit Soulseek verbunden")
        begriff = " ".join(str(begriff or "").split())[:200]
        if len(begriff) < 2:
            raise SoulseekFehler("Mindestens zwei Zeichen suchen")
        with self._sperre:
            self._erwartet = begriff.lower()
            self._reihenfolge = []
            self._token = None
            self._begriff = begriff
            self._suchzeit = int(time.time())
            self._fehler = ""
            self._meldung = "Suche läuft …"
        self._events.invoke_main_thread(self._suche_starten, begriff)
        return {"begriff": begriff, "zeit": self._suchzeit}

    def _suche_starten(self, begriff):
        try:
            self._core.search.do_search(begriff, self._search_mode.GLOBAL, switch_page=False)
        except Exception as fehler:
            with self._sperre:
                self._fehler = "Suche fehlgeschlagen: %s" % fehler

    def _add_search(self, token, search, _switch_page=False):
        try:
            begriff = str(getattr(search, "term", "") or "")
            if begriff.lower() != self._erwartet:
                return
            with self._sperre:
                self._token = int(token)
        except Exception:
            pass

    def _search_failed(self, token, is_offline=False):
        with self._sperre:
            if self._token is not None and int(token) != self._token:
                return
            self._fehler = "Suche nicht möglich: nicht mit Soulseek verbunden" if is_offline else "Suche fehlgeschlagen"

    def _search_response(self, msg):
        try:
            with self._sperre:
                if self._token is None or _numerisch(getattr(msg, "token", -1)) != self._token:
                    return
            benutzer = str(getattr(msg, "username", "") or getattr(msg, "search_username", ""))
            if not benutzer:
                return
            slots = bool(getattr(msg, "slot_available", False))
            schlange = _numerisch(getattr(msg, "num_queued_uploads", 0))
            tempo = _numerisch(getattr(msg, "upload_speed", 0))
            neue = []
            for datei in list(getattr(msg, "public_files", None) or []):
                pfad = str(getattr(datei, "path", "") or "")
                if not pfad:
                    continue
                kennung = treffer_id(benutzer, pfad)
                groesse = _numerisch(getattr(datei, "size", 0))
                attribute = getattr(datei, "attributes", None)
                eintrag = {"id": kennung, "benutzer": benutzer, "pfad": pfad, "datei": dateiname(pfad),
                           "ordner": ordner_von(pfad), "groesse": groesse,
                           "groesse_text": mensch_groesse(groesse), "slots": slots, "schlange": schlange,
                           "tempo": tempo, "bitrate": getattr(attribute, "bitrate", None),
                           "laenge": getattr(attribute, "length", None),
                           "samplerate": getattr(attribute, "sample_rate", None)}
                with self._sperre:
                    if kennung not in self._treffer:
                        self._treffer[kennung] = eintrag
                        self._reihenfolge.append(kennung)
                        neue.append(kennung)
                    else:
                        self._treffer[kennung].update(eintrag)
            if not neue:
                return
            with self._sperre:
                grenze = max(50, int(self.einstellung.get("max_treffer") or 500))
                while len(self._reihenfolge) > grenze:
                    alt = self._reihenfolge.pop(0)
                    if alt in self._treffer:
                        del self._treffer[alt]
                if len(self._treffer) > ERGEBNISSE_MAX:
                    for kennung in list(self._treffer)[:len(self._treffer) - ERGEBNISSE_MAX]:
                        if kennung not in self._reihenfolge:
                            del self._treffer[kennung]
                self._meldung = "%d Treffer" % len(self._reihenfolge)
        except Exception as fehler:
            with self._sperre:
                self._fehler = "Treffer nicht lesbar: %s" % fehler

    # --- Downloads -------------------------------------------------------------------------------
    def laden(self, kennung):
        self.starten()
        with self._sperre:
            treffer = self._treffer.get(str(kennung))
            if not treffer:
                raise SoulseekFehler("Treffer nicht mehr vorhanden – bitte neu suchen")
        self._events.invoke_main_thread(self._laden_starten, dict(treffer))
        return {"id": str(kennung), "status": "angenommen"}

    def _laden_starten(self, treffer):
        try:
            self._core.downloads.enqueue_download(treffer["benutzer"], treffer["pfad"])
        except Exception as fehler:
            with self._sperre:
                self._fehler = "Download nicht angenommen: %s" % fehler

    def _update_download(self, transfer, _update_parent=True):
        try:
            benutzer = str(getattr(transfer, "username", ""))
            pfad = str(getattr(transfer, "virtual_path", ""))
            if not benutzer or not pfad:
                return
            kennung = treffer_id(benutzer, pfad)
            status = str(getattr(transfer, "status", "") or "")
            groesse = _numerisch(getattr(transfer, "size", 0))
            geladen = _numerisch(getattr(transfer, "current_byte_offset", 0))
            if status == "Finished":
                geladen = groesse
            eintrag = {"id": kennung, "benutzer": benutzer, "pfad": pfad, "datei": dateiname(pfad),
                       "ordner": ordner_von(pfad), "groesse": groesse, "groesse_text": mensch_groesse(groesse),
                       "geladen": geladen, "prozent": round(100.0 * geladen / groesse, 1) if groesse else 0.0,
                       "tempo": _numerisch(getattr(transfer, "speed", 0)), "status": status,
                       "status_text": STATUS_TEXT.get(status, status or "wartet"),
                       "schlange": _numerisch(getattr(transfer, "queue_position", 0)),
                       "fertig": status == "Finished", "pausiert": status == "Paused"}
            with self._sperre:
                self._downloads[kennung] = eintrag
                self._transfer_objekte[kennung] = transfer
        except Exception as fehler:
            with self._sperre:
                self._fehler = "Download-Status nicht lesbar: %s" % fehler

    def _clear_download(self, transfer, _update_parent=True):
        try:
            kennung = treffer_id(str(getattr(transfer, "username", "")), str(getattr(transfer, "virtual_path", "")))
            with self._sperre:
                self._downloads.pop(kennung, None)
                self._transfer_objekte.pop(kennung, None)
        except Exception:
            pass

    def _transfer(self, kennung):
        with self._sperre:
            transfer = self._transfer_objekte.get(str(kennung))
        if transfer is None:
            raise SoulseekFehler("Download gibt es nicht mehr")
        return transfer

    def abbrechen(self, kennung):
        transfer = self._transfer(kennung)
        self._events.invoke_main_thread(self._core.downloads.abort_downloads, {transfer: None})

    def fortsetzen(self, kennung):
        transfer = self._transfer(kennung)
        self._events.invoke_main_thread(self._core.downloads.retry_download, transfer)

    def entfernen(self, kennung):
        transfer = self._transfer(kennung)
        self._events.invoke_main_thread(self._core.downloads.clear_downloads, {transfer: None})

    # --- Freigaben und Einstellungen -------------------------------------------------------------
    def freigaben_scannen(self):
        self.starten()
        self._events.invoke_main_thread(self._scannen)

    def _scannen(self):
        try:
            self._core.shares.rescan_shares()
        except Exception as fehler:
            with self._sperre:
                self._fehler = "Freigaben nicht scanbar: %s" % fehler

    def einstellen(self, neu):
        alt = self.einstellung
        self.einstellung = neu
        if not self._gestartet:
            return
        neu_verbinden = any(alt.get(feld) != neu.get(feld) for feld in ("benutzer", "passwort", "server", "port"))
        freigaben = alt.get("freigaben") != neu.get("freigaben")
        self._events.invoke_main_thread(self._einstellen_anwenden, neu_verbinden, freigaben)

    def _einstellen_anwenden(self, neu_verbinden, freigaben):
        try:
            self._config_anwenden()
            if freigaben:
                self._core.shares.rescan_shares()
            if neu_verbinden:
                if self._verbunden:
                    self._core.disconnect()
                self._core.connect()
        except Exception as fehler:
            with self._sperre:
                self._fehler = "Einstellungen nicht übernommen: %s" % fehler

    # --- Zustand ---------------------------------------------------------------------------------
    def zustand(self):
        with self._sperre:
            treffer = [dict(self._treffer[k]) for k in self._reihenfolge if k in self._treffer]
            downloads = sorted(self._downloads.values(), key=lambda d: (d["fertig"], d["datei"].lower()))
            return {"verbunden": self._verbunden, "benutzer": self._benutzer or self.einstellung["benutzer"],
                    "server": self._server or "%s:%s" % (self.einstellung["server"], self.einstellung["port"]),
                    "suche": {"begriff": self._begriff, "token": self._token, "zeit": self._suchzeit,
                              "anzahl": len(treffer)},
                    "treffer": treffer, "downloads": downloads, "fehler": self._fehler, "meldung": self._meldung,
                    "statistik": {"treffer": len(treffer), "downloads": len(downloads),
                                  "fertig": sum(1 for d in downloads if d["fertig"])}}

    def beenden(self):
        if not self._gestartet:
            return
        try:
            self._events.invoke_main_thread(self._core.quit)
        except Exception:
            pass
        faden = self._faden
        if faden is not None:
            faden.join(3)
        self._lauf.clear()
        try:
            self._config.write_configuration()
        except OSError:
            pass
        self._gestartet = False
