"""Stream-Rangfolge nach NuvioTV-Vorbild.

NuvioTV bewertet eine Quelle anhand ihres Release-Namens: Auflösung, Qualitätsstufe
(Remux, Blu-ray, WEB-DL …), Codec, HDR-/DV- und Tonmerkmale, Release-Gruppe, Sprache
und Dateigröße. Daraus entstehen eine Rangstufe, Punkte aus Regeln und eine feste
Reihenfolge. Dieses Modul bildet die Regeln und Presets von NuvioTV in Python nach,
damit H0rSt dieselbe Reihenfolge im Browser, in der App und am Fernseher anbietet.

Die Profile sind reine Daten (dieselben Schlüssel wie in NuvioTV), nie ausführbarer
Code. Ein eigenes Profil kann als JSON übernommen werden; reguläre Ausdrücke werden
vor der Verwendung auf teure Konstruktionen geprüft.
"""

import copy
import functools
import json
import math
import re
from datetime import datetime, timezone

GIB = 1073741824.0

SPRACHEN = (
    "en", "ja", "de", "fr", "nl", "es", "it", "pt", "ko", "zh",
    "hi", "ru", "uk", "ar", "pl", "tr", "multi", "dual",
)
QUALITAETEN = ("REMUX", "BLURAY", "WEB_DL", "WEBRIP", "HDTV", "DVD", "CAM", "UNKNOWN")
QUALITAETS_WERTE = {
    "REMUX": 7, "BLURAY": 6, "WEB_DL": 5, "WEBRIP": 4, "HDTV": 3, "DVD": 2, "CAM": 1,
}
FELDER = (
    "TITLE", "GROUP", "QUALITY", "RESOLUTION", "CODEC", "VISUAL", "AUDIO", "LANGUAGE",
    "INDEXER", "SIZE_GB", "AGE_DAYS", "MEDIA_TYPE",
)
ZAHLENFELDER = ("SIZE_GB", "AGE_DAYS", "RESOLUTION")
OPERATOREN = ("IS", "IS_NOT", "CONTAINS", "MATCHES", "AT_LEAST", "AT_MOST")
AKTIONEN = ("BOOST", "EXCLUDE", "REQUIRE")
SORTIERUNGEN = ("TIER", "SCORE", "LANGUAGE", "RESOLUTION", "QUALITY", "SIZE", "AGE", "INDEXER",
                "SIZE_PREFERENCE")
AUFLOESUNGEN = (0, 360, 480, 576, 720, 1080, 1440, 2160)
MAX_REGELN = 80
MAX_BEDINGUNGEN = 8
MAX_TEXT = 2048


class ProfilFehler(ValueError):
    """Ein Rangfolge-Profil ist unvollständig oder unsicher."""


# --- Release-Name lesen ------------------------------------------------------

def _token(muster):
    return re.compile(r"(?:^|[^a-z0-9])(?:%s)(?:\Z|[^a-z0-9])" % muster, re.I)


_AUFLOSUNG = re.compile(r"(?:^|[^0-9])(2160|1440|1080|720|576|480|360)p?(?:\Z|[^0-9])", re.I)
_UHD = _token("4k|uhd")
_REMUX = _token("remux")
_BLURAY = _token(r"blu[ ._-]?ray|b[dr]rip|bdremux|b[dr]mv")
_WEB_DL = _token(r"web[ ._-]?dl|webdl")
_WEB = _token("web")
_WEBRIP = _token(r"web[ ._-]?rip")
_HDTV = _token("hdtv")
_DVD = _token(r"dvd|dvdrip|dvdremux")
_CAM = _token(r"cam|hdcam|telesync|telecine|hdts|ts|tc|scr|dvdscr")
_HEVC = _token(r"hevc|[xh][ ._-]?265|h265")
_AVC = _token(r"avc|[xh][ ._-]?264|h264")
_AV1 = _token("av1")
_DV = _token(r"dv|dovi|dolby[ ._-]?vision")
_HDR = _token(r"hdr|hdr10|hdr10plus|hdr10\+|hlg")
_HDR_PLUS = _token(r"hdr10plus|hdr10\+")
_SDR = _token("sdr")
_ATMOS = _token("atmos")
_TRUEHD = _token(r"true[ ._-]?hd")
_DTS_HD = _token(r"dts[ ._-]?(?:hd|x)")
_DDP = _token(r"ddp|e[ ._-]?ac3|dd\+")
_AAC = _token("aac")
_GRUPPE = re.compile(r"-((?:D-Z0N3)|[a-z0-9][a-z0-9._]{1,31})\Z", re.I)
_ANIME_GRUPPE = re.compile(r"^\[([a-z][a-z0-9 _-]{1,30})\]", re.I)
_ENDUNG = re.compile(r"\.(?:mkv|mp4|m2ts|ts|nzb)\Z", re.I)
_GROESSE = re.compile(r"([\d.,]+)\s*([KMGT])i?B", re.I)
_EINHEITEN = {"K": 1 << 10, "M": 1 << 20, "G": 1 << 30, "T": 1 << 40}

_SPRACHMUSTER = {
    "en": _token("english|eng|en"),
    "ja": _token("japanese|jpn|ja"),
    "de": _token("german|ger|deu|de"),
    "fr": _token(r"french|fre|fra|vff|vfq|truefrench|fr"),
    "nl": _token("dutch|nld|nederlands|nl"),
    "es": _token("spanish|spa|castellano|es"),
    "it": _token("italian|ita|it"),
    "pt": _token("portuguese|por|ptbr|pt"),
    "ko": _token("korean|kor|ko"),
    "zh": _token("chinese|chi|zho|mandarin|zh"),
    "hi": _token("hindi|hin|hi"),
    "ru": _token("russian|rus|ru"),
    "uk": _token("ukrainian|ukr"),
    "ar": _token("arabic|ara"),
    "pl": _token("polish|pol"),
    "tr": _token("turkish|tur"),
    "multi": _token(r"multi|multi[ ._-]?audio"),
    "dual": _token(r"dual|dual[ ._-]?audio"),
}
_DREI = {
    "ger": "de", "deu": "de", "eng": "en", "fre": "fr", "fra": "fr", "spa": "es", "ita": "it",
    "dut": "nl", "nld": "nl", "pol": "pl", "por": "pt", "rus": "ru", "jpn": "ja", "kor": "ko",
    "chi": "zh", "zho": "zh", "ara": "ar", "tur": "tr", "ukr": "uk", "hin": "hi", "heb": "he",
    "cze": "cs", "ces": "cs", "hun": "hu", "gre": "el", "ell": "el", "swe": "sv", "dan": "da",
    "fin": "fi", "nor": "no",
}


def groesse_bytes(wert):
    """Dateigröße als Bytes: Zahl oder Text wie „2,5 GB“ / „700 MB“."""
    if isinstance(wert, bool) or wert is None:
        return None
    if isinstance(wert, (int, float)):
        return int(wert) if math.isfinite(float(wert)) and wert >= 0 else None
    treffer = _GROESSE.search(str(wert))
    if not treffer:
        return None
    try:
        zahl = float(treffer.group(1).replace(",", "."))
    except ValueError:
        return None
    return int(zahl * _EINHEITEN[treffer.group(2).upper()])


def sprachcodes(werte):
    """Sprachanzeigen wie „DE+EN“ oder ISO-Codes in ein Set aus kleinen Codes übersetzen."""
    if not werte:
        return None
    codes = set()
    for wert in werte if isinstance(werte, (list, tuple, set)) else [werte]:
        for teil in re.split(r"[+,\s/]+", str(wert or "")):
            code = teil.strip().lower()
            code = _DREI.get(code, code)
            if code == "mul":
                code = "multi"
            if code in ("multi", "dual"):
                codes.add(code)
            elif code in SPRACHEN or (len(code) == 2 and code.isalpha()):
                codes.add(code)
    return codes or None


def _sprachen_aus_titel(text):
    return {code for code, muster in _SPRACHMUSTER.items() if muster.search(text)}


def fakten(titel, groesse=None, sprachen=None, quelle="", typ="movie", veroeffentlicht=None):
    """Fakten aus einem Release-Namen lesen. `sprachen` (aus der Quelle) hat Vorrang."""
    original = str(titel or "")[:MAX_TEXT]
    text = _ENDUNG.sub("", original)
    treffer = _AUFLOSUNG.search(text)
    aufloesung = int(treffer.group(1)) if treffer else (2160 if _UHD.search(text) else 0)
    if _CAM.search(text):
        qualitaet = "CAM"
    elif _REMUX.search(text):
        qualitaet = "REMUX"
    elif _BLURAY.search(text):
        qualitaet = "BLURAY"
    elif _WEBRIP.search(text):
        qualitaet = "WEBRIP"
    elif _WEB_DL.search(text):
        qualitaet = "WEB_DL"
    elif _HDTV.search(text):
        qualitaet = "HDTV"
    elif _DVD.search(text):
        qualitaet = "DVD"
    elif _WEB.search(text):
        qualitaet = "WEB_DL"
    else:
        qualitaet = "UNKNOWN"
    hat_dv, hat_hdr = bool(_DV.search(text)), bool(_HDR.search(text))
    bild = set()
    if hat_dv:
        bild.add("HDR_DV" if hat_hdr else "DV_ONLY")
        bild.add("DV")
    if hat_hdr:
        bild.add("HDR")
    if _HDR_PLUS.search(text):
        bild.add("HDR10_PLUS")
    if _SDR.search(text):
        bild.add("SDR")
    if not hat_dv and not hat_hdr:
        bild.add("NO_HDR_LABEL")
    ton = set()
    for name, muster in (("ATMOS", _ATMOS), ("TRUEHD", _TRUEHD), ("DTS_HD", _DTS_HD),
                         ("DDP", _DDP), ("AAC", _AAC)):
        if muster.search(text):
            ton.add(name)
    gruppe = ""
    suffix, prefix = _GRUPPE.search(text), _ANIME_GRUPPE.search(text)
    if suffix:
        gruppe = suffix.group(1)
    elif prefix:
        gruppe = prefix.group(1)
    return {
        "title": original,
        "resolution": aufloesung,
        "quality": qualitaet,
        "codec": "HEVC" if _HEVC.search(text) else "AV1" if _AV1.search(text) else
                 "AVC" if _AVC.search(text) else "UNKNOWN",
        "visual": bild,
        "audio": ton,
        "languages": set(sprachen) if sprachen is not None else _sprachen_aus_titel(text),
        "group": gruppe,
        "sizeBytes": groesse_bytes(groesse),
        "publishedAt": int(veroeffentlicht) if isinstance(veroeffentlicht, (int, float)) else None,
        "indexer": str(quelle or ""),
        "mediaType": "series" if str(typ or "").lower() in ("series", "serie", "episode") else "movie",
    }


# --- Profile (dieselben Schlüssel wie NuvioTV) ------------------------------

def _b(feld, wert, operator="IS"):
    return {"field": feld, "operator": operator, "value": wert}


def _regel(name, score=100, conditions=None, action="BOOST", match_any=False, minimum_remaining=0,
           enabled=True):
    return {"name": name, "enabled": enabled, "action": action, "score": score,
            "matchAny": match_any, "conditions": conditions or [], "minimumRemaining": minimum_remaining}


def _stufe(name, resolutions=None, qualities=None):
    return {"name": name, "resolutions": list(resolutions or []), "qualities": list(qualities or [])}


def _gruppe(name, qualitaeten, gruppen, score):
    return _regel(name, score, [_b("QUALITY", qualitaeten), _b("GROUP", gruppen)])


_GRUPPENREGELN = [
    _gruppe("Remux • leading groups", "REMUX",
            "3L,ATELiER,BiZKiT,BLURANiUM,BMF,CiNEPHiLES,FraMeSToR,PiRAMiDHEAD,PmP,WiLDCAT,ZQ", 300),
    _gruppe("Remux • established groups", "REMUX", "NCmt,playBD,SiCFoI,SURFINBIRD,TEPES", 200),
    _gruppe("Remux • other recommended groups", "REMUX",
            "12GaugeShotgun,decibeL,EPSiLON,HiFi,iFT,KRaLiMaRKo,NTb,PTP,SumVision,TOA,TRiToN", 100),
    _gruppe("WEB • leading groups", "WEB_DL,WEBRIP",
            "ABBIE,AJP69,APEX,PAXA,PEXA,XEPA,BLUTONiUM,BYNDR,CMRG,CRFW,CRUD,FLUX,GNOME,HONE,KiNGS,"
            "Kitsune,MADSKY,NOSiViD,NTb,NTG,RAWR,SiC,TEPES,TheFarm,ZoroSenpai", 300),
    _gruppe("WEB • established groups", "WEB_DL,WEBRIP",
            "dB,Flights,MiU,monkee,MZABI,PHOENiX,playWEB,SbR,SMURF,TOMMY,XEBEC,4KBEC,CEBEX", 200),
    _gruppe("WEB • other recommended groups", "WEB_DL,WEBRIP",
            "BLOOM,Dooky,GNOMiSSiON,NINJACENTRAL,NPMS,ROCCaT,SiGMA,SLiGNOME,SwAgLaNdEr", 100),
    _gruppe("Blu-ray • leading groups", "BLURAY",
            "ATELiER,BBQ,BMF,c0kE,Chotab,CRiSC,CtrlHD,D-Z0N3,Dariush,decibeL,DON,EbP,EDPH,Geek,LolHD,"
            "NCmt,PTer,TayTO,TDD,TnP,VietHD,ZQ,ZoroSenpai,MainFrame,W4NK3R", 250),
]
_KOMPRIMIERT = "aXXo,MeGusta,mSD,mHD,nHD,nSD,YIFY,YTS"
_UPSCALE = r"(?:^|[ ._-])(?:upscaled?|ai[ ._-]?enhanced|ai[ ._-]?upscale)(?:$|[ ._-])"
_BASISREGELN = _GRUPPENREGELN + [
    _regel("Avoid heavily compressed groups when alternatives exist", action="EXCLUDE", minimum_remaining=5,
           conditions=[_b("GROUP", _KOMPRIMIERT)]),
    _regel("Avoid labelled upscales when alternatives exist", action="EXCLUDE", minimum_remaining=5,
           conditions=[_b("TITLE", _UPSCALE, "MATCHES")]),
    _regel("Heavily compressed release group", score=-1000,
           conditions=[_b("GROUP", _KOMPRIMIERT)]),
    _regel("Repack / proper", score=15,
           conditions=[_b("TITLE", r"(?:^|[ ._-])(?:repack[0-9]*|proper[0-9]*)(?:$|[ ._-])", "MATCHES")]),
    _regel("Hybrid HDR / Dolby Vision", score=10, conditions=[_b("VISUAL", "HDR_DV")]),
    _regel("Lossless / immersive audio", score=10, conditions=[_b("AUDIO", "ATMOS,TRUEHD,DTS_HD")]),
    _regel("Upscale / AI label", score=-500, conditions=[_b("TITLE", _UPSCALE, "MATCHES")]),
]
_QUALITAETSSTUFEN = [
    _stufe("4K remux", (2160,), ("REMUX",)),
    _stufe("4K Blu-ray encode", (2160,), ("BLURAY",)),
    _stufe("1080p remux", (1080,), ("REMUX",)),
    _stufe("4K WEB-DL", (2160,), ("WEB_DL",)),
    _stufe("4K WEBRip", (2160,), ("WEBRIP",)),
    _stufe("1080p Blu-ray encode", (1080,), ("BLURAY",)),
    _stufe("1080p WEB-DL", (1080,), ("WEB_DL",)),
    _stufe("1080p WEBRip", (1080,), ("WEBRIP",)),
    _stufe("720p and HD", (720,), ("REMUX", "BLURAY", "WEB_DL", "WEBRIP", "HDTV")),
    _stufe("Other known HD", (2160, 1440, 1080), ("REMUX", "BLURAY", "WEB_DL", "WEBRIP", "HDTV")),
]
_STANDARDSORT = [
    {"key": "SIZE_PREFERENCE", "descending": True},
    {"key": "TIER", "descending": True},
    {"key": "SCORE", "descending": True},
    {"key": "LANGUAGE", "descending": True},
    {"key": "SIZE", "descending": False},
]
_AUSGEWOGEN = {
    "version": 1, "name": "Balanced", "tiers": _QUALITAETSSTUFEN, "sort": _STANDARDSORT,
    "preferredLanguages": [], "preferredMovieSizeGb": 30.0, "preferredEpisodeSizeGb": 5.0,
    "topPerBucket": 3, "rules": _BASISREGELN,
}
_BESTE = dict(_AUSGEWOGEN, name="Best Quality", preferredMovieSizeGb=0.0, preferredEpisodeSizeGb=0.0,
              topPerBucket=4, sort=[
                  {"key": "TIER", "descending": True}, {"key": "SCORE", "descending": True},
                  {"key": "LANGUAGE", "descending": True}, {"key": "SIZE", "descending": True},
              ])
_KLEINERE = dict(
    _AUSGEWOGEN, name="Smaller Files", preferredMovieSizeGb=12.0, preferredEpisodeSizeGb=2.0,
    topPerBucket=2,
    tiers=[
        _stufe("1080p WEB-DL", (1080,), ("WEB_DL",)),
        _stufe("1080p WEBRip", (1080,), ("WEBRIP",)),
        _stufe("1080p Blu-ray encode", (1080,), ("BLURAY",)),
        _stufe("4K WEB-DL", (2160,), ("WEB_DL",)),
        _stufe("4K WEBRip", (2160,), ("WEBRIP",)),
        _stufe("720p and HD", (720,), ("REMUX", "BLURAY", "WEB_DL", "WEBRIP", "HDTV")),
        _stufe("1080p remux", (1080,), ("REMUX",)),
        _stufe("4K Blu-ray encode", (2160,), ("BLURAY",)),
        _stufe("4K remux", (2160,), ("REMUX",)),
    ],
    rules=_BASISREGELN + [_regel("Efficient video codec", score=30,
                                 conditions=[_b("CODEC", "HEVC,AV1")])])
_HD_SDR = dict(
    _KLEINERE, name="1080p / SDR",
    tiers=[
        _stufe("1080p WEB-DL", (1080,), ("WEB_DL",)),
        _stufe("1080p Blu-ray encode", (1080,), ("BLURAY",)),
        _stufe("1080p WEBRip", (1080,), ("WEBRIP",)),
        _stufe("720p and HD", (720,), ("WEB_DL", "BLURAY", "WEBRIP", "HDTV")),
    ] + _QUALITAETSSTUFEN,
    sort=[{"key": "SCORE", "descending": True}] + [s for s in _KLEINERE["sort"] if s["key"] != "SCORE"],
    rules=_BASISREGELN + [
        _regel("Prefer HD without HDR or Dolby Vision labels", score=3000,
               conditions=[_b("RESOLUTION", "720", "AT_LEAST"), _b("RESOLUTION", "1080", "AT_MOST"),
                           _b("VISUAL", "NO_HDR_LABEL")]),
        _regel("Prefer AVC video", score=30, conditions=[_b("CODEC", "AVC")]),
        _regel("Prefer AAC or Dolby Digital Plus audio", score=20, conditions=[_b("AUDIO", "AAC,DDP")]),
    ])
PRESETS = {
    "balanced": _AUSGEWOGEN,
    "best": _BESTE,
    "smaller": _KLEINERE,
    "hdsdr": _HD_SDR,
}


def _normalisiere(profil):
    if not isinstance(profil, dict):
        raise ProfilFehler("Profil muss ein JSON-Objekt sein")
    p = copy.deepcopy(profil)
    p.setdefault("version", 1)
    p.setdefault("name", "My profile")
    p.setdefault("tiers", [])
    p.setdefault("sort", copy.deepcopy(_STANDARDSORT))
    p.setdefault("preferredLanguages", [])
    p.setdefault("preferredMovieSizeGb", 0.0)
    p.setdefault("preferredEpisodeSizeGb", 0.0)
    p.setdefault("topPerBucket", 3)
    p.setdefault("rules", [])
    if not isinstance(p["sort"], list) or not isinstance(p["rules"], list):
        raise ProfilFehler("sort und rules müssen Listen sein")
    if any(not isinstance(s, dict) for s in p["sort"]) or any(not isinstance(r, dict) for r in p["rules"]):
        raise ProfilFehler("Jede Sortierpriorität und jede Regel muss ein Objekt sein")
    p["sort"] = [dict(s, descending=s.get("descending", True)) for s in p["sort"]]
    p["rules"] = [dict(r) for r in p["rules"]]
    for regel in p["rules"]:
        regel.setdefault("name", "New rule")
        regel.setdefault("enabled", True)
        regel.setdefault("action", "BOOST")
        regel.setdefault("score", 100)
        regel.setdefault("matchAny", False)
        regel.setdefault("minimumRemaining", 0)
        regel.setdefault("conditions", [])
        if not isinstance(regel["conditions"], list) or any(not isinstance(b, dict) for b in regel["conditions"]):
            raise ProfilFehler("Bedingungen müssen Objekte sein")
        regel["conditions"] = [dict(b) for b in regel["conditions"]]
        for bedingung in regel["conditions"]:
            bedingung.setdefault("field", "TITLE")
            bedingung.setdefault("operator", "CONTAINS")
            bedingung.setdefault("value", "")
    return p


_UNSICHER = re.compile(r"\(\?=|\(\?!|\(\?<=|\(\?<!|\(\?P=|\(\?>|\(\?\(|\\[1-9]")
_VERSCHACHTELT = re.compile(r"\([^)]*[+*][^)]*\)[+*{]")
_WIEDERHOLTE_GRUPPE = re.compile(r"\)[+*{]")


def _regex_sicher(muster):
    if len(muster) > 256:
        raise ProfilFehler("Reguläre Ausdrücke dürfen höchstens 256 Zeichen haben")
    if _UNSICHER.search(muster):
        raise ProfilFehler("Reguläre Ausdrücke ohne Lookaround und Rückverweise verwenden")
    if _VERSCHACHTELT.search(muster):
        raise ProfilFehler("Reguläre Ausdrücke ohne verschachtelte Wiederholungen verwenden")
    # Jede wiederholte Gruppe mit einer Alternative ist in CPython ein ReDoS-Risiko – auch verschachtelt
    # wie ((a|aa))+. NuvioTV nutzt RE2J; Python hat das nicht, also wird die Form abgewiesen.
    if "|" in muster and _WIEDERHOLTE_GRUPPE.search(muster):
        raise ProfilFehler("Wiederholte Alternativen sind zu teuer (z. B. (a|aa)+)")
    try:
        re.compile(muster, re.I)
    except re.error as fehler:
        raise ProfilFehler("Regulärer Ausdruck ungültig: %s" % fehler)


def pruefe(profil):
    """Profil prüfen und normalisiert zurückgeben (wirft ProfilFehler)."""
    p = _normalisiere(profil)
    if p["version"] != 1:
        raise ProfilFehler("Unbekannte Profil-Version")
    if not isinstance(p["name"], str) or not 1 <= len(p["name"]) <= 80:
        raise ProfilFehler("Der Profilname muss 1–80 Zeichen haben")
    if not isinstance(p["tiers"], list) or len(p["tiers"]) > 24:
        raise ProfilFehler("Höchstens 24 Qualitätsstufen")
    for stufe in p["tiers"]:
        if not isinstance(stufe, dict):
            raise ProfilFehler("Jede Qualitätsstufe muss ein Objekt sein")
        if not isinstance(stufe.get("name"), str) or not 1 <= len(stufe["name"]) <= 80:
            raise ProfilFehler("Jede Qualitätsstufe braucht einen kurzen Namen")
        aufloesungen = stufe.get("resolutions") or []
        if not isinstance(aufloesungen, list) or len(aufloesungen) > 10 or \
                any(not isinstance(a, int) or isinstance(a, bool) or a not in AUFLOESUNGEN for a in aufloesungen):
            raise ProfilFehler("Ungültige Auflösung in einer Qualitätsstufe")
        qualitaeten = stufe.get("qualities") or []
        if not isinstance(qualitaeten, list) or any(not isinstance(q, str) for q in qualitaeten):
            raise ProfilFehler("Ungültige Qualität in einer Qualitätsstufe")
        if len(set(qualitaeten)) != len(qualitaeten) or any(q not in QUALITAETEN for q in qualitaeten):
            raise ProfilFehler("Ungültige oder doppelte Qualität in einer Qualitätsstufe")
    if not isinstance(p["sort"], list) or not 1 <= len(p["sort"]) <= len(SORTIERUNGEN):
        raise ProfilFehler("Bitte 1 bis %d Sortierprioritäten wählen" % len(SORTIERUNGEN))
    schluessel = [s.get("key") if isinstance(s, dict) else None for s in p["sort"]]
    if any(k not in SORTIERUNGEN for k in schluessel) or len(set(schluessel)) != len(schluessel):
        raise ProfilFehler("Sortierprioritäten müssen verschieden und bekannt sein")
    if any(not isinstance(s.get("descending"), bool) for s in p["sort"]):
        raise ProfilFehler("Sortierprioritäten brauchen eine Richtung")
    sprachen = p["preferredLanguages"]
    if not isinstance(sprachen, list) or len(sprachen) > 24 or \
            any(not isinstance(s, str) or not re.match(r"^[a-z]{2,8}$", s) for s in sprachen):
        raise ProfilFehler("Sprachen sind kleine Kürzel wie en, ja oder multi")
    for feld in ("preferredMovieSizeGb", "preferredEpisodeSizeGb"):
        wert = p[feld]
        if not isinstance(wert, (int, float)) or isinstance(wert, bool) or \
                not math.isfinite(wert) or not 0 <= wert <= 1000:
            raise ProfilFehler("Bevorzugte Größen liegen zwischen 0 und 1000 GB")
    if not isinstance(p["topPerBucket"], int) or not 0 <= p["topPerBucket"] <= 20:
        raise ProfilFehler("Ergebnisse je Kategorie liegen zwischen 0 und 20")
    if not isinstance(p["rules"], list) or len(p["rules"]) > MAX_REGELN:
        raise ProfilFehler("Höchstens %d Regeln" % MAX_REGELN)
    for nummer, regel in enumerate(p["rules"], 1):
        if not isinstance(regel.get("name"), str) or not 1 <= len(regel["name"]) <= 80:
            raise ProfilFehler("Regel %d braucht einen Namen mit höchstens 80 Zeichen" % nummer)
        if not isinstance(regel.get("score"), int) or not -10000 <= regel["score"] <= 10000:
            raise ProfilFehler("Regel %d: Punkte liegen zwischen -10000 und 10000" % nummer)
        if regel.get("action") not in AKTIONEN:
            raise ProfilFehler("Regel %d: unbekannte Aktion" % nummer)
        if not isinstance(regel.get("minimumRemaining"), int) or not 0 <= regel["minimumRemaining"] <= 200:
            raise ProfilFehler("Regel %d: Mindestrest liegt zwischen 0 und 200" % nummer)
        bedingungen = regel["conditions"]
        if not isinstance(bedingungen, list) or not 1 <= len(bedingungen) <= MAX_BEDINGUNGEN:
            raise ProfilFehler("Regel %d braucht 1–%d Bedingungen" % (nummer, MAX_BEDINGUNGEN))
        for bedingung in bedingungen:
            feld, operator, wert = bedingung.get("field"), bedingung.get("operator"), bedingung.get("value")
            if feld not in FELDER:
                raise ProfilFehler("Regel %d: unbekanntes Feld %s" % (nummer, feld))
            if operator not in OPERATOREN:
                raise ProfilFehler("Regel %d: unbekannter Operator %s" % (nummer, operator))
            if not isinstance(wert, str) or not wert.strip() or len(wert) > 512:
                raise ProfilFehler("Regel %d: Bedingungen brauchen einen Wert" % nummer)
            if feld in ZAHLENFELDER:
                if operator not in ("IS", "IS_NOT", "AT_LEAST", "AT_MOST"):
                    raise ProfilFehler("Regel %d: Operator passt nicht zum Zahlenfeld" % nummer)
                try:
                    zahl = float(wert)
                except ValueError:
                    raise ProfilFehler("Regel %d: Zahl erwartet" % nummer)
                if not math.isfinite(zahl) or zahl < 0:
                    raise ProfilFehler("Regel %d: positive Zahl oder null erwartet" % nummer)
            elif operator in ("AT_LEAST", "AT_MOST"):
                raise ProfilFehler("Regel %d: Operator passt nicht zum Textfeld" % nummer)
            if operator == "MATCHES":
                try:
                    _regex_sicher(wert)
                except ProfilFehler as fehler:
                    raise ProfilFehler("Regel %d (%s): %s" % (nummer, regel["name"][:80], fehler))
    return p


def profil(preset, sprache=""):
    """Ein eingebautes Profil, oder None für die unveränderte Quellen-Reihenfolge."""
    basis = PRESETS.get(str(preset or ""))
    if basis is None:
        return None
    p = copy.deepcopy(basis)
    if sprache in SPRACHEN:
        p["preferredLanguages"] = [sprache]
        p["sort"] = [{"key": "LANGUAGE", "descending": True}] + \
                    [s for s in p["sort"] if s["key"] != "LANGUAGE"]
    return p


def profil_aus_json(text):
    """Ein NuvioTV-Profil (JSON-Text) übernehmen und prüfen."""
    try:
        roh = json.loads(text)
    except (TypeError, ValueError) as fehler:
        raise ProfilFehler("Profil ist kein gültiges JSON: %s" % fehler)
    return pruefe(roh)


# --- Regelwerk ---------------------------------------------------------------

@functools.lru_cache(maxsize=256)
def _regex(muster):
    return re.compile(muster, re.I)


def _bedingung_passt(bedingung, f, jetzt):
    feld, operator, wert = bedingung["field"], bedingung["operator"], bedingung["value"]
    if feld in ZAHLENFELDER:
        if feld == "RESOLUTION":
            zahl = float(f["resolution"]) if f.get("resolution") is not None else None
        elif feld == "SIZE_GB":
            groesse = f.get("sizeBytes")
            zahl = float(groesse) / GIB if groesse is not None else None
        else:
            zeit = f.get("publishedAt")
            zahl = max(0.0, (jetzt - float(zeit)) / 86400000.0) if zeit is not None else None
        if zahl is None:
            return False
        soll = float(wert)
        if operator == "IS":
            return zahl == soll
        if operator == "IS_NOT":
            return zahl != soll
        if operator == "AT_LEAST":
            return zahl >= soll
        return zahl <= soll if operator == "AT_MOST" else False
    if feld == "TITLE":
        werte = [f.get("title") or ""]
    elif feld == "GROUP":
        werte = [f.get("group") or ""]
    elif feld == "QUALITY":
        werte = [f.get("quality") or ""]
    elif feld == "CODEC":
        werte = [f.get("codec") or ""]
    elif feld == "VISUAL":
        werte = list(f.get("visual") or ())
    elif feld == "AUDIO":
        werte = list(f.get("audio") or ())
    elif feld == "LANGUAGE":
        werte = list(f.get("languages") or ())
    elif feld == "INDEXER":
        werte = [f.get("indexer") or ""]
    else:  # MEDIA_TYPE
        werte = [f.get("mediaType") or ""]
    if feld in ("GROUP", "INDEXER"):
        werte = [w for w in werte if w]
    if not werte:
        return False
    if operator == "IS":
        gesucht = {teil.strip().lower() for teil in wert.split(",") if teil.strip()}
        return any(str(w).lower() in gesucht for w in werte)
    if operator == "IS_NOT":
        gesucht = {teil.strip().lower() for teil in wert.split(",") if teil.strip()}
        return all(str(w).lower() not in gesucht for w in werte)
    if operator == "CONTAINS":
        return any(wert.lower() in str(w).lower() for w in werte)
    if operator == "MATCHES":
        muster = _regex(wert)
        return any(muster.search(str(w)) for w in werte)
    return False


def _regel_passt(regel, f, jetzt):
    treffer = (_bedingung_passt(b, f, jetzt) for b in regel["conditions"])
    return any(treffer) if regel.get("matchAny") else all(treffer)


def rangfolge(kandidaten, profil_daten, jetzt=None):
    """Kandidaten (dict mit value, facts, key, reliability, indexerOrder) rangieren.

    Gibt dieselben Kandidaten mit rank, score, tier, matches und overflow zurück.
    """
    p = profil_daten
    jetzt = int(datetime.now(timezone.utc).timestamp() * 1000) if jetzt is None else jetzt
    regeln = [r for r in p["rules"] if r.get("enabled", True)]
    punkte = [r for r in regeln if r["action"] == "BOOST"]
    filter_regeln = [r for r in regeln if r["action"] != "BOOST"]
    angenommen = list(kandidaten)
    for regel in filter_regeln:
        gefiltert = [k for k in angenommen
                     if _regel_passt(regel, k["facts"], jetzt) == (regel["action"] == "REQUIRE")]
        if regel.get("minimumRemaining", 0) == 0 or \
                sum(1 for k in gefiltert if k.get("reliability", 1) < 2) >= regel["minimumRemaining"]:
            angenommen = gefiltert
    gerankt = []
    for kandidat in angenommen:
        f = kandidat["facts"]
        passende = [r for r in punkte if _regel_passt(r, f, jetzt)]
        score = sum(r["score"] for r in passende)
        stufe = -1
        for nummer, tier in enumerate(p["tiers"]):
            if (not tier["resolutions"] or f["resolution"] in tier["resolutions"]) and \
                    (not tier["qualities"] or f["quality"] in tier["qualities"]):
                stufe = nummer
                break
        sprache = -1
        for nummer, code in enumerate(p["preferredLanguages"]):
            if code in (f.get("languages") or ()):
                sprache = nummer
                break
        bevorzugt = p["preferredEpisodeSizeGb"] if f["mediaType"] == "series" else p["preferredMovieSizeGb"]
        groesse = f.get("sizeBytes")
        werte = {
            "TIER": float(len(p["tiers"]) - stufe) if stufe >= 0 else 0.0,
            "SCORE": float(score),
            "LANGUAGE": float(len(p["preferredLanguages"]) - sprache) if sprache >= 0 else 0.0,
            "SIZE_PREFERENCE": 0.0 if (bevorzugt > 0 and groesse is not None and groesse > bevorzugt * GIB) else 1.0,
            "RESOLUTION": float(f["resolution"]) if f["resolution"] > 0 else None,
            "QUALITY": float(QUALITAETS_WERTE[f["quality"]]) if f["quality"] in QUALITAETS_WERTE else None,
            "SIZE": float(groesse) if groesse is not None else None,
            "AGE": float(f["publishedAt"]) if f.get("publishedAt") is not None else None,
            "INDEXER": -float(kandidat.get("indexerOrder", 0)),
        }
        gerankt.append({
            "candidate": kandidat, "score": score, "tier": p["tiers"][stufe]["name"] if stufe >= 0 else None,
            "matches": [r["name"] for r in passende], "keys": werte, "overflow": False,
        })
    gerankt.sort(key=functools.cmp_to_key(lambda a, b: _vergleiche(a, b, p["sort"])))
    grenze = p["topPerBucket"]
    if grenze == 0:
        return [dict(r, rank=nummer) for nummer, r in enumerate(gerankt, 1)]
    zaehler, fuehrer, rest = {}, [], []
    for eintrag in gerankt:
        f = eintrag["candidate"]["facts"]
        schluessel = (eintrag["candidate"].get("reliability", 1), f["resolution"], f["quality"])
        anzahl = zaehler.get(schluessel, 0)
        zaehler[schluessel] = anzahl + 1
        if anzahl < grenze:
            fuehrer.append(eintrag)
        else:
            rest.append(dict(eintrag, overflow=True))
    return [dict(r, rank=nummer) for nummer, r in
            enumerate(sorted(fuehrer + rest, key=lambda r: r["candidate"].get("reliability", 1)), 1)]


def _vergleiche(a, b, sortierung):
    zaehler_a, zaehler_b = a["candidate"].get("reliability", 1), b["candidate"].get("reliability", 1)
    if zaehler_a != zaehler_b:
        return -1 if zaehler_a < zaehler_b else 1
    for sort in sortierung:
        links, rechts = a["keys"].get(sort["key"]), b["keys"].get(sort["key"])
        if links is None and rechts is None:
            continue
        if links is None:
            return 1
        if rechts is None:
            return -1
        if links != rechts:
            ergebnis = -1 if links < rechts else 1
            return -ergebnis if sort.get("descending", True) else ergebnis
    titel_a = (a["candidate"]["facts"].get("title") or "").casefold()
    titel_b = (b["candidate"]["facts"].get("title") or "").casefold()
    if titel_a != titel_b:
        return -1 if titel_a < titel_b else 1
    schluessel_a, schluessel_b = a["candidate"].get("key", ""), b["candidate"].get("key", "")
    return (schluessel_a > schluessel_b) - (schluessel_a < schluessel_b)


# --- Anschluss an die Oberfläche --------------------------------------------

def _zuverlaessig(eintrag):
    urteil = (eintrag.get("usenet") or {}).get("urteil") if isinstance(eintrag.get("usenet"), dict) else None
    if urteil == "blockiert":
        return 2
    if urteil == "verifiziert":
        return 0
    return 1


def _text(eintrag):
    teile = [eintrag.get("titel"), eintrag.get("aufloesung"), eintrag.get("_text")]
    text = " ".join(str(t) for t in teile if t)
    return text or str(eintrag.get("name") or "")


def anwenden(streams, typ, ui=None):
    """Stream-Einträge der Oberfläche rangieren und mit `rang` beschriften.

    Gibt (Liste, info) zurück. Bei "original" bleibt die Reihenfolge unverändert und
    die Einträge bekommen kein rang-Feld.
    """
    ui = ui if isinstance(ui, dict) else {}
    preset = str(ui.get("stream_rang") or "original")
    ansicht = str(ui.get("stream_rang_ansicht") or "beides")
    info = {"preset": preset, "view": ansicht}
    p = profil(preset, str(ui.get("stream_rang_sprache") or ""))
    if p is None:
        return list(streams), info
    info["profile"] = p["name"]
    kandidaten = []
    for nummer, eintrag in enumerate(streams):
        if not isinstance(eintrag, dict):
            continue
        f = fakten(_text(eintrag), groesse=eintrag.get("groesse"), sprachen=sprachcodes(eintrag.get("sprachen")),
                   quelle=eintrag.get("quelle") or eintrag.get("name") or "", typ=typ)
        kandidaten.append({"value": eintrag, "facts": f, "key": str(nummer),
                           "reliability": _zuverlaessig(eintrag), "indexerOrder": nummer})
    liste = []
    for eintrag in rangfolge(kandidaten, p):
        neu = dict(eintrag["candidate"]["value"])
        neu["rang"] = {"rank": eintrag["rank"], "score": eintrag["score"], "tier": eintrag["tier"] or "",
                       "matches": eintrag["matches"], "overflow": eintrag["overflow"]}
        liste.append(neu)
    return liste, info
