"""Kodi-Dienst: startet den Rezeptserver und beendet ihn mit Kodi.

Rezepte und Konfiguration liegen im Profilordner des Addons:
  userdata/addon_data/service.rezeptserver/rezepte/
  userdata/addon_data/service.rezeptserver/nutzerdaten.db
"""

import logging
import os
import sys

import xbmc
import xbmcaddon
import xbmcvfs

ADDON = xbmcaddon.Addon()
ADDON_PFAD = ADDON.getAddonInfo("path")
sys.path.insert(0, os.path.join(ADDON_PFAD, "resources", "lib"))


def _neuere_fassung(aktuell, eingebaut):
    """Systemweite Aktualisierung aus GitHub (rezeptserver/aktualisierung.py): die Fassung in aktuell/ nehmen,
    wenn sie neuer ist als die mitgelieferte. Steht hier, weil es vor dem ersten Import von rezeptserver laufen muss."""
    import re as _re

    def version(ordner):
        try:
            with open(os.path.join(ordner, "rezeptserver", "__init__.py"), encoding="utf-8") as f:
                return tuple(int(x) for x in _re.findall(r"\d+", _re.search(r'__version__\s*=\s*"([^"]+)"', f.read()).group(1))[:4])
        except (OSError, AttributeError, ValueError):
            return ()
    neu = version(aktuell)
    if neu and neu > version(eingebaut):
        sys.path.insert(0, aktuell)


_neuere_fassung(os.path.join(xbmcvfs.translatePath(ADDON.getAddonInfo("profile")), "aktuell"),
                os.path.join(ADDON_PFAD, "resources", "lib"))

from rezeptserver import konfig  # noqa: E402
from rezeptserver.dienst import Dienst, rezepte_uebernehmen  # noqa: E402


class KodiLog(logging.Handler):
    STUFEN = {logging.DEBUG: xbmc.LOGDEBUG, logging.INFO: xbmc.LOGINFO,
              logging.WARNING: xbmc.LOGWARNING, logging.ERROR: xbmc.LOGERROR}

    def emit(self, record):
        xbmc.log("[Rezeptserver] " + self.format(record), self.STUFEN.get(record.levelno, xbmc.LOGINFO))


def main():
    log = logging.getLogger("rezeptserver")
    log.addHandler(KodiLog())
    log.setLevel(logging.INFO)

    profil = xbmcvfs.translatePath(ADDON.getAddonInfo("profile"))
    rezepte = os.path.join(profil, "rezepte")
    konfig_pfad = os.path.join(profil, konfig.DATEINAME)  # alte konfig.json wird uebernommen
    # nach einem Addon-Update kommen neuere Rezepte dazu, eigene bleiben erhalten
    rezepte_uebernehmen(os.path.join(ADDON_PFAD, "resources", "rezepte"), rezepte)

    daten = konfig.lade(konfig_pfad)
    dienst = Dienst(rezepte, konfig_pfad)
    try:
        dienst.starte(daten.get("host", "127.0.0.1"), int(daten.get("port", 7000)))
    except Exception:
        return  # Grund steht schon im Log

    monitor = xbmc.Monitor()
    while not monitor.abortRequested():
        if monitor.waitForAbort(1):
            break
    dienst.stoppe()


if __name__ == "__main__":
    main()
